var tweet_index =  [ {
  "file_name" : "data\/js\/tweets\/2017_11.js",
  "year" : 2017,
  "var_name" : "tweets_2017_11",
  "tweet_count" : 179,
  "month" : 11
}, {
  "file_name" : "data\/js\/tweets\/2017_10.js",
  "year" : 2017,
  "var_name" : "tweets_2017_10",
  "tweet_count" : 237,
  "month" : 10
}, {
  "file_name" : "data\/js\/tweets\/2017_09.js",
  "year" : 2017,
  "var_name" : "tweets_2017_09",
  "tweet_count" : 278,
  "month" : 9
}, {
  "file_name" : "data\/js\/tweets\/2017_08.js",
  "year" : 2017,
  "var_name" : "tweets_2017_08",
  "tweet_count" : 217,
  "month" : 8
}, {
  "file_name" : "data\/js\/tweets\/2017_07.js",
  "year" : 2017,
  "var_name" : "tweets_2017_07",
  "tweet_count" : 351,
  "month" : 7
}, {
  "file_name" : "data\/js\/tweets\/2017_06.js",
  "year" : 2017,
  "var_name" : "tweets_2017_06",
  "tweet_count" : 281,
  "month" : 6
}, {
  "file_name" : "data\/js\/tweets\/2017_05.js",
  "year" : 2017,
  "var_name" : "tweets_2017_05",
  "tweet_count" : 469,
  "month" : 5
}, {
  "file_name" : "data\/js\/tweets\/2017_04.js",
  "year" : 2017,
  "var_name" : "tweets_2017_04",
  "tweet_count" : 512,
  "month" : 4
}, {
  "file_name" : "data\/js\/tweets\/2017_03.js",
  "year" : 2017,
  "var_name" : "tweets_2017_03",
  "tweet_count" : 409,
  "month" : 3
}, {
  "file_name" : "data\/js\/tweets\/2017_02.js",
  "year" : 2017,
  "var_name" : "tweets_2017_02",
  "tweet_count" : 328,
  "month" : 2
}, {
  "file_name" : "data\/js\/tweets\/2017_01.js",
  "year" : 2017,
  "var_name" : "tweets_2017_01",
  "tweet_count" : 461,
  "month" : 1
}, {
  "file_name" : "data\/js\/tweets\/2016_12.js",
  "year" : 2016,
  "var_name" : "tweets_2016_12",
  "tweet_count" : 267,
  "month" : 12
}, {
  "file_name" : "data\/js\/tweets\/2016_11.js",
  "year" : 2016,
  "var_name" : "tweets_2016_11",
  "tweet_count" : 370,
  "month" : 11
}, {
  "file_name" : "data\/js\/tweets\/2016_10.js",
  "year" : 2016,
  "var_name" : "tweets_2016_10",
  "tweet_count" : 465,
  "month" : 10
}, {
  "file_name" : "data\/js\/tweets\/2016_09.js",
  "year" : 2016,
  "var_name" : "tweets_2016_09",
  "tweet_count" : 502,
  "month" : 9
}, {
  "file_name" : "data\/js\/tweets\/2016_08.js",
  "year" : 2016,
  "var_name" : "tweets_2016_08",
  "tweet_count" : 528,
  "month" : 8
}, {
  "file_name" : "data\/js\/tweets\/2016_07.js",
  "year" : 2016,
  "var_name" : "tweets_2016_07",
  "tweet_count" : 464,
  "month" : 7
}, {
  "file_name" : "data\/js\/tweets\/2016_06.js",
  "year" : 2016,
  "var_name" : "tweets_2016_06",
  "tweet_count" : 305,
  "month" : 6
}, {
  "file_name" : "data\/js\/tweets\/2016_05.js",
  "year" : 2016,
  "var_name" : "tweets_2016_05",
  "tweet_count" : 369,
  "month" : 5
}, {
  "file_name" : "data\/js\/tweets\/2016_04.js",
  "year" : 2016,
  "var_name" : "tweets_2016_04",
  "tweet_count" : 569,
  "month" : 4
}, {
  "file_name" : "data\/js\/tweets\/2016_03.js",
  "year" : 2016,
  "var_name" : "tweets_2016_03",
  "tweet_count" : 605,
  "month" : 3
}, {
  "file_name" : "data\/js\/tweets\/2016_02.js",
  "year" : 2016,
  "var_name" : "tweets_2016_02",
  "tweet_count" : 544,
  "month" : 2
}, {
  "file_name" : "data\/js\/tweets\/2016_01.js",
  "year" : 2016,
  "var_name" : "tweets_2016_01",
  "tweet_count" : 510,
  "month" : 1
}, {
  "file_name" : "data\/js\/tweets\/2015_12.js",
  "year" : 2015,
  "var_name" : "tweets_2015_12",
  "tweet_count" : 507,
  "month" : 12
}, {
  "file_name" : "data\/js\/tweets\/2015_11.js",
  "year" : 2015,
  "var_name" : "tweets_2015_11",
  "tweet_count" : 794,
  "month" : 11
}, {
  "file_name" : "data\/js\/tweets\/2015_10.js",
  "year" : 2015,
  "var_name" : "tweets_2015_10",
  "tweet_count" : 679,
  "month" : 10
}, {
  "file_name" : "data\/js\/tweets\/2015_09.js",
  "year" : 2015,
  "var_name" : "tweets_2015_09",
  "tweet_count" : 667,
  "month" : 9
}, {
  "file_name" : "data\/js\/tweets\/2015_08.js",
  "year" : 2015,
  "var_name" : "tweets_2015_08",
  "tweet_count" : 555,
  "month" : 8
}, {
  "file_name" : "data\/js\/tweets\/2015_07.js",
  "year" : 2015,
  "var_name" : "tweets_2015_07",
  "tweet_count" : 630,
  "month" : 7
}, {
  "file_name" : "data\/js\/tweets\/2015_06.js",
  "year" : 2015,
  "var_name" : "tweets_2015_06",
  "tweet_count" : 612,
  "month" : 6
}, {
  "file_name" : "data\/js\/tweets\/2015_05.js",
  "year" : 2015,
  "var_name" : "tweets_2015_05",
  "tweet_count" : 437,
  "month" : 5
}, {
  "file_name" : "data\/js\/tweets\/2015_04.js",
  "year" : 2015,
  "var_name" : "tweets_2015_04",
  "tweet_count" : 322,
  "month" : 4
}, {
  "file_name" : "data\/js\/tweets\/2015_03.js",
  "year" : 2015,
  "var_name" : "tweets_2015_03",
  "tweet_count" : 192,
  "month" : 3
}, {
  "file_name" : "data\/js\/tweets\/2015_02.js",
  "year" : 2015,
  "var_name" : "tweets_2015_02",
  "tweet_count" : 171,
  "month" : 2
}, {
  "file_name" : "data\/js\/tweets\/2015_01.js",
  "year" : 2015,
  "var_name" : "tweets_2015_01",
  "tweet_count" : 286,
  "month" : 1
}, {
  "file_name" : "data\/js\/tweets\/2014_12.js",
  "year" : 2014,
  "var_name" : "tweets_2014_12",
  "tweet_count" : 334,
  "month" : 12
}, {
  "file_name" : "data\/js\/tweets\/2014_11.js",
  "year" : 2014,
  "var_name" : "tweets_2014_11",
  "tweet_count" : 305,
  "month" : 11
}, {
  "file_name" : "data\/js\/tweets\/2014_10.js",
  "year" : 2014,
  "var_name" : "tweets_2014_10",
  "tweet_count" : 391,
  "month" : 10
}, {
  "file_name" : "data\/js\/tweets\/2014_09.js",
  "year" : 2014,
  "var_name" : "tweets_2014_09",
  "tweet_count" : 332,
  "month" : 9
}, {
  "file_name" : "data\/js\/tweets\/2014_08.js",
  "year" : 2014,
  "var_name" : "tweets_2014_08",
  "tweet_count" : 296,
  "month" : 8
}, {
  "file_name" : "data\/js\/tweets\/2014_07.js",
  "year" : 2014,
  "var_name" : "tweets_2014_07",
  "tweet_count" : 239,
  "month" : 7
}, {
  "file_name" : "data\/js\/tweets\/2014_06.js",
  "year" : 2014,
  "var_name" : "tweets_2014_06",
  "tweet_count" : 267,
  "month" : 6
}, {
  "file_name" : "data\/js\/tweets\/2014_05.js",
  "year" : 2014,
  "var_name" : "tweets_2014_05",
  "tweet_count" : 535,
  "month" : 5
}, {
  "file_name" : "data\/js\/tweets\/2014_04.js",
  "year" : 2014,
  "var_name" : "tweets_2014_04",
  "tweet_count" : 545,
  "month" : 4
}, {
  "file_name" : "data\/js\/tweets\/2014_03.js",
  "year" : 2014,
  "var_name" : "tweets_2014_03",
  "tweet_count" : 617,
  "month" : 3
}, {
  "file_name" : "data\/js\/tweets\/2014_02.js",
  "year" : 2014,
  "var_name" : "tweets_2014_02",
  "tweet_count" : 503,
  "month" : 2
}, {
  "file_name" : "data\/js\/tweets\/2014_01.js",
  "year" : 2014,
  "var_name" : "tweets_2014_01",
  "tweet_count" : 696,
  "month" : 1
}, {
  "file_name" : "data\/js\/tweets\/2013_12.js",
  "year" : 2013,
  "var_name" : "tweets_2013_12",
  "tweet_count" : 635,
  "month" : 12
}, {
  "file_name" : "data\/js\/tweets\/2013_11.js",
  "year" : 2013,
  "var_name" : "tweets_2013_11",
  "tweet_count" : 529,
  "month" : 11
}, {
  "file_name" : "data\/js\/tweets\/2013_10.js",
  "year" : 2013,
  "var_name" : "tweets_2013_10",
  "tweet_count" : 685,
  "month" : 10
}, {
  "file_name" : "data\/js\/tweets\/2013_09.js",
  "year" : 2013,
  "var_name" : "tweets_2013_09",
  "tweet_count" : 459,
  "month" : 9
}, {
  "file_name" : "data\/js\/tweets\/2013_08.js",
  "year" : 2013,
  "var_name" : "tweets_2013_08",
  "tweet_count" : 828,
  "month" : 8
}, {
  "file_name" : "data\/js\/tweets\/2013_07.js",
  "year" : 2013,
  "var_name" : "tweets_2013_07",
  "tweet_count" : 990,
  "month" : 7
}, {
  "file_name" : "data\/js\/tweets\/2013_06.js",
  "year" : 2013,
  "var_name" : "tweets_2013_06",
  "tweet_count" : 1149,
  "month" : 6
}, {
  "file_name" : "data\/js\/tweets\/2013_05.js",
  "year" : 2013,
  "var_name" : "tweets_2013_05",
  "tweet_count" : 926,
  "month" : 5
}, {
  "file_name" : "data\/js\/tweets\/2013_04.js",
  "year" : 2013,
  "var_name" : "tweets_2013_04",
  "tweet_count" : 971,
  "month" : 4
}, {
  "file_name" : "data\/js\/tweets\/2013_03.js",
  "year" : 2013,
  "var_name" : "tweets_2013_03",
  "tweet_count" : 913,
  "month" : 3
}, {
  "file_name" : "data\/js\/tweets\/2013_02.js",
  "year" : 2013,
  "var_name" : "tweets_2013_02",
  "tweet_count" : 806,
  "month" : 2
}, {
  "file_name" : "data\/js\/tweets\/2013_01.js",
  "year" : 2013,
  "var_name" : "tweets_2013_01",
  "tweet_count" : 913,
  "month" : 1
}, {
  "file_name" : "data\/js\/tweets\/2012_12.js",
  "year" : 2012,
  "var_name" : "tweets_2012_12",
  "tweet_count" : 780,
  "month" : 12
}, {
  "file_name" : "data\/js\/tweets\/2012_11.js",
  "year" : 2012,
  "var_name" : "tweets_2012_11",
  "tweet_count" : 1358,
  "month" : 11
}, {
  "file_name" : "data\/js\/tweets\/2012_10.js",
  "year" : 2012,
  "var_name" : "tweets_2012_10",
  "tweet_count" : 1256,
  "month" : 10
}, {
  "file_name" : "data\/js\/tweets\/2012_09.js",
  "year" : 2012,
  "var_name" : "tweets_2012_09",
  "tweet_count" : 982,
  "month" : 9
}, {
  "file_name" : "data\/js\/tweets\/2012_08.js",
  "year" : 2012,
  "var_name" : "tweets_2012_08",
  "tweet_count" : 839,
  "month" : 8
}, {
  "file_name" : "data\/js\/tweets\/2012_07.js",
  "year" : 2012,
  "var_name" : "tweets_2012_07",
  "tweet_count" : 941,
  "month" : 7
}, {
  "file_name" : "data\/js\/tweets\/2012_06.js",
  "year" : 2012,
  "var_name" : "tweets_2012_06",
  "tweet_count" : 923,
  "month" : 6
}, {
  "file_name" : "data\/js\/tweets\/2012_05.js",
  "year" : 2012,
  "var_name" : "tweets_2012_05",
  "tweet_count" : 932,
  "month" : 5
}, {
  "file_name" : "data\/js\/tweets\/2012_04.js",
  "year" : 2012,
  "var_name" : "tweets_2012_04",
  "tweet_count" : 996,
  "month" : 4
}, {
  "file_name" : "data\/js\/tweets\/2012_03.js",
  "year" : 2012,
  "var_name" : "tweets_2012_03",
  "tweet_count" : 622,
  "month" : 3
}, {
  "file_name" : "data\/js\/tweets\/2012_02.js",
  "year" : 2012,
  "var_name" : "tweets_2012_02",
  "tweet_count" : 481,
  "month" : 2
}, {
  "file_name" : "data\/js\/tweets\/2012_01.js",
  "year" : 2012,
  "var_name" : "tweets_2012_01",
  "tweet_count" : 640,
  "month" : 1
}, {
  "file_name" : "data\/js\/tweets\/2011_12.js",
  "year" : 2011,
  "var_name" : "tweets_2011_12",
  "tweet_count" : 1143,
  "month" : 12
}, {
  "file_name" : "data\/js\/tweets\/2011_11.js",
  "year" : 2011,
  "var_name" : "tweets_2011_11",
  "tweet_count" : 836,
  "month" : 11
}, {
  "file_name" : "data\/js\/tweets\/2011_10.js",
  "year" : 2011,
  "var_name" : "tweets_2011_10",
  "tweet_count" : 891,
  "month" : 10
}, {
  "file_name" : "data\/js\/tweets\/2011_09.js",
  "year" : 2011,
  "var_name" : "tweets_2011_09",
  "tweet_count" : 1075,
  "month" : 9
}, {
  "file_name" : "data\/js\/tweets\/2011_08.js",
  "year" : 2011,
  "var_name" : "tweets_2011_08",
  "tweet_count" : 939,
  "month" : 8
}, {
  "file_name" : "data\/js\/tweets\/2011_07.js",
  "year" : 2011,
  "var_name" : "tweets_2011_07",
  "tweet_count" : 1021,
  "month" : 7
}, {
  "file_name" : "data\/js\/tweets\/2011_06.js",
  "year" : 2011,
  "var_name" : "tweets_2011_06",
  "tweet_count" : 1090,
  "month" : 6
}, {
  "file_name" : "data\/js\/tweets\/2011_05.js",
  "year" : 2011,
  "var_name" : "tweets_2011_05",
  "tweet_count" : 1068,
  "month" : 5
}, {
  "file_name" : "data\/js\/tweets\/2011_04.js",
  "year" : 2011,
  "var_name" : "tweets_2011_04",
  "tweet_count" : 1143,
  "month" : 4
}, {
  "file_name" : "data\/js\/tweets\/2011_03.js",
  "year" : 2011,
  "var_name" : "tweets_2011_03",
  "tweet_count" : 1327,
  "month" : 3
}, {
  "file_name" : "data\/js\/tweets\/2011_02.js",
  "year" : 2011,
  "var_name" : "tweets_2011_02",
  "tweet_count" : 1279,
  "month" : 2
}, {
  "file_name" : "data\/js\/tweets\/2011_01.js",
  "year" : 2011,
  "var_name" : "tweets_2011_01",
  "tweet_count" : 1193,
  "month" : 1
}, {
  "file_name" : "data\/js\/tweets\/2010_12.js",
  "year" : 2010,
  "var_name" : "tweets_2010_12",
  "tweet_count" : 1393,
  "month" : 12
}, {
  "file_name" : "data\/js\/tweets\/2010_11.js",
  "year" : 2010,
  "var_name" : "tweets_2010_11",
  "tweet_count" : 1901,
  "month" : 11
}, {
  "file_name" : "data\/js\/tweets\/2010_10.js",
  "year" : 2010,
  "var_name" : "tweets_2010_10",
  "tweet_count" : 1354,
  "month" : 10
}, {
  "file_name" : "data\/js\/tweets\/2010_09.js",
  "year" : 2010,
  "var_name" : "tweets_2010_09",
  "tweet_count" : 1553,
  "month" : 9
}, {
  "file_name" : "data\/js\/tweets\/2010_08.js",
  "year" : 2010,
  "var_name" : "tweets_2010_08",
  "tweet_count" : 1839,
  "month" : 8
}, {
  "file_name" : "data\/js\/tweets\/2010_07.js",
  "year" : 2010,
  "var_name" : "tweets_2010_07",
  "tweet_count" : 1652,
  "month" : 7
}, {
  "file_name" : "data\/js\/tweets\/2010_06.js",
  "year" : 2010,
  "var_name" : "tweets_2010_06",
  "tweet_count" : 1200,
  "month" : 6
}, {
  "file_name" : "data\/js\/tweets\/2010_05.js",
  "year" : 2010,
  "var_name" : "tweets_2010_05",
  "tweet_count" : 2304,
  "month" : 5
}, {
  "file_name" : "data\/js\/tweets\/2010_04.js",
  "year" : 2010,
  "var_name" : "tweets_2010_04",
  "tweet_count" : 2012,
  "month" : 4
}, {
  "file_name" : "data\/js\/tweets\/2010_03.js",
  "year" : 2010,
  "var_name" : "tweets_2010_03",
  "tweet_count" : 1672,
  "month" : 3
}, {
  "file_name" : "data\/js\/tweets\/2010_02.js",
  "year" : 2010,
  "var_name" : "tweets_2010_02",
  "tweet_count" : 1644,
  "month" : 2
}, {
  "file_name" : "data\/js\/tweets\/2010_01.js",
  "year" : 2010,
  "var_name" : "tweets_2010_01",
  "tweet_count" : 2354,
  "month" : 1
}, {
  "file_name" : "data\/js\/tweets\/2009_12.js",
  "year" : 2009,
  "var_name" : "tweets_2009_12",
  "tweet_count" : 2359,
  "month" : 12
}, {
  "file_name" : "data\/js\/tweets\/2009_11.js",
  "year" : 2009,
  "var_name" : "tweets_2009_11",
  "tweet_count" : 1533,
  "month" : 11
}, {
  "file_name" : "data\/js\/tweets\/2009_10.js",
  "year" : 2009,
  "var_name" : "tweets_2009_10",
  "tweet_count" : 1097,
  "month" : 10
}, {
  "file_name" : "data\/js\/tweets\/2009_09.js",
  "year" : 2009,
  "var_name" : "tweets_2009_09",
  "tweet_count" : 1300,
  "month" : 9
}, {
  "file_name" : "data\/js\/tweets\/2009_08.js",
  "year" : 2009,
  "var_name" : "tweets_2009_08",
  "tweet_count" : 1278,
  "month" : 8
}, {
  "file_name" : "data\/js\/tweets\/2009_07.js",
  "year" : 2009,
  "var_name" : "tweets_2009_07",
  "tweet_count" : 1181,
  "month" : 7
}, {
  "file_name" : "data\/js\/tweets\/2009_06.js",
  "year" : 2009,
  "var_name" : "tweets_2009_06",
  "tweet_count" : 1027,
  "month" : 6
}, {
  "file_name" : "data\/js\/tweets\/2009_05.js",
  "year" : 2009,
  "var_name" : "tweets_2009_05",
  "tweet_count" : 801,
  "month" : 5
}, {
  "file_name" : "data\/js\/tweets\/2009_04.js",
  "year" : 2009,
  "var_name" : "tweets_2009_04",
  "tweet_count" : 826,
  "month" : 4
}, {
  "file_name" : "data\/js\/tweets\/2009_03.js",
  "year" : 2009,
  "var_name" : "tweets_2009_03",
  "tweet_count" : 814,
  "month" : 3
}, {
  "file_name" : "data\/js\/tweets\/2009_02.js",
  "year" : 2009,
  "var_name" : "tweets_2009_02",
  "tweet_count" : 654,
  "month" : 2
}, {
  "file_name" : "data\/js\/tweets\/2009_01.js",
  "year" : 2009,
  "var_name" : "tweets_2009_01",
  "tweet_count" : 885,
  "month" : 1
}, {
  "file_name" : "data\/js\/tweets\/2008_12.js",
  "year" : 2008,
  "var_name" : "tweets_2008_12",
  "tweet_count" : 527,
  "month" : 12
}, {
  "file_name" : "data\/js\/tweets\/2008_11.js",
  "year" : 2008,
  "var_name" : "tweets_2008_11",
  "tweet_count" : 407,
  "month" : 11
}, {
  "file_name" : "data\/js\/tweets\/2008_10.js",
  "year" : 2008,
  "var_name" : "tweets_2008_10",
  "tweet_count" : 273,
  "month" : 10
}, {
  "file_name" : "data\/js\/tweets\/2008_09.js",
  "year" : 2008,
  "var_name" : "tweets_2008_09",
  "tweet_count" : 130,
  "month" : 9
}, {
  "file_name" : "data\/js\/tweets\/2008_08.js",
  "year" : 2008,
  "var_name" : "tweets_2008_08",
  "tweet_count" : 78,
  "month" : 8
}, {
  "file_name" : "data\/js\/tweets\/2008_07.js",
  "year" : 2008,
  "var_name" : "tweets_2008_07",
  "tweet_count" : 30,
  "month" : 7
}, {
  "file_name" : "data\/js\/tweets\/2008_06.js",
  "year" : 2008,
  "var_name" : "tweets_2008_06",
  "tweet_count" : 53,
  "month" : 6
}, {
  "file_name" : "data\/js\/tweets\/2008_05.js",
  "year" : 2008,
  "var_name" : "tweets_2008_05",
  "tweet_count" : 113,
  "month" : 5
}, {
  "file_name" : "data\/js\/tweets\/2008_04.js",
  "year" : 2008,
  "var_name" : "tweets_2008_04",
  "tweet_count" : 140,
  "month" : 4
} ]