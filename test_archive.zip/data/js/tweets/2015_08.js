Grailbird.data.tweets_2015_08 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "setient",
      "screen_name" : "setient",
      "indices" : [ 0, 8 ],
      "id_str" : "15851858",
      "id" : 15851858
    }, {
      "name" : "samantha based clark",
      "screen_name" : "eltonjohn",
      "indices" : [ 9, 19 ],
      "id_str" : "15661851",
      "id" : 15661851
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "638457663731269632",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.08595869347537, 8.575221342015858 ]
  },
  "id_str" : "638470253303975936",
  "in_reply_to_user_id" : 15851858,
  "text" : "@setient @eltonjohn +1 to both.",
  "id" : 638470253303975936,
  "in_reply_to_status_id" : 638457663731269632,
  "created_at" : "2015-08-31 21:55:45 +0000",
  "in_reply_to_screen_name" : "setient",
  "in_reply_to_user_id_str" : "15851858",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angelica Maga\u00F1a",
      "screen_name" : "angmags319",
      "indices" : [ 3, 14 ],
      "id_str" : "3260499620",
      "id" : 3260499620
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/rndcGODniN",
      "expanded_url" : "http:\/\/www.upworthy.com\/what-happens-when-you-give-100-homeless-people-disposable-cameras-you-get-true-works-of-art?g=2&c=ufb1",
      "display_url" : "upworthy.com\/what-happens-w\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "638465819459063808",
  "text" : "RT @angmags319: What happens when you give 100 homeless people disposable cameras? You get true works of art. http:\/\/t.co\/rndcGODniN",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 94, 116 ],
        "url" : "http:\/\/t.co\/rndcGODniN",
        "expanded_url" : "http:\/\/www.upworthy.com\/what-happens-when-you-give-100-homeless-people-disposable-cameras-you-get-true-works-of-art?g=2&c=ufb1",
        "display_url" : "upworthy.com\/what-happens-w\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "638364685641863168",
    "text" : "What happens when you give 100 homeless people disposable cameras? You get true works of art. http:\/\/t.co\/rndcGODniN",
    "id" : 638364685641863168,
    "created_at" : "2015-08-31 14:56:15 +0000",
    "user" : {
      "name" : "Angelica Maga\u00F1a",
      "screen_name" : "angmags319",
      "protected" : false,
      "id_str" : "3260499620",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/922985222106382337\/8awJO4WT_normal.jpg",
      "id" : 3260499620,
      "verified" : false
    }
  },
  "id" : 638465819459063808,
  "created_at" : "2015-08-31 21:38:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "malech maltz",
      "screen_name" : "malech",
      "indices" : [ 0, 7 ],
      "id_str" : "784085846391713793",
      "id" : 784085846391713793
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 8, 14 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 38 ],
      "url" : "https:\/\/t.co\/PiGL6mf4c2",
      "expanded_url" : "https:\/\/giphy.com\/gifs\/funny-home-video-kid-ZPW36An5sA9l6",
      "display_url" : "giphy.com\/gifs\/funny-hom\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "638465329128185856",
  "text" : "@malech @Lobot https:\/\/t.co\/PiGL6mf4c2",
  "id" : 638465329128185856,
  "created_at" : "2015-08-31 21:36:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "malech maltz",
      "screen_name" : "malech",
      "indices" : [ 0, 7 ],
      "id_str" : "784085846391713793",
      "id" : 784085846391713793
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 8, 14 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.08595275878905, 8.575119018554684 ]
  },
  "id_str" : "638464845323616257",
  "text" : "@malech @Lobot ich finde leider kein gif von Leuten die in Skyr baden.",
  "id" : 638464845323616257,
  "created_at" : "2015-08-31 21:34:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christophe Dessimoz",
      "screen_name" : "cdessimoz",
      "indices" : [ 0, 10 ],
      "id_str" : "274388734",
      "id" : 274388734
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "638442073465712640",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.08595275878865, 8.575119018554359 ]
  },
  "id_str" : "638463175499845632",
  "in_reply_to_user_id" : 274388734,
  "text" : "@cdessimoz of course, we should drink to it on the next occasion. :)",
  "id" : 638463175499845632,
  "in_reply_to_status_id" : 638442073465712640,
  "created_at" : "2015-08-31 21:27:37 +0000",
  "in_reply_to_screen_name" : "cdessimoz",
  "in_reply_to_user_id_str" : "274388734",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "malech maltz",
      "screen_name" : "malech",
      "indices" : [ 0, 7 ],
      "id_str" : "784085846391713793",
      "id" : 784085846391713793
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 8, 14 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.08615401604952, 8.57548964248289 ]
  },
  "id_str" : "638401863126286337",
  "text" : "@malech @Lobot beides! Wir sollten mal eine Skyr-Party werfen!",
  "id" : 638401863126286337,
  "created_at" : "2015-08-31 17:23:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "malech maltz",
      "screen_name" : "malech",
      "indices" : [ 0, 7 ],
      "id_str" : "784085846391713793",
      "id" : 784085846391713793
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 8, 14 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.08683270702172, 8.575311610071175 ]
  },
  "id_str" : "638395727417315328",
  "text" : "@malech @Lobot do want.",
  "id" : 638395727417315328,
  "created_at" : "2015-08-31 16:59:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Saladin Ahmed",
      "screen_name" : "saladinahmed",
      "indices" : [ 0, 13 ],
      "id_str" : "29995782",
      "id" : 29995782
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "638358323549573120",
  "geo" : { },
  "id_str" : "638358507960565760",
  "in_reply_to_user_id" : 29995782,
  "text" : "@saladinahmed but you can\u2019t marry the cake and eat it!",
  "id" : 638358507960565760,
  "in_reply_to_status_id" : 638358323549573120,
  "created_at" : "2015-08-31 14:31:43 +0000",
  "in_reply_to_screen_name" : "saladinahmed",
  "in_reply_to_user_id_str" : "29995782",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "638356847959928833",
  "text" : "My ~ is in desperate need of a housekeeping Gene. I even stopped caring whether it\u2019s Simmons or Hackman.",
  "id" : 638356847959928833,
  "created_at" : "2015-08-31 14:25:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "638353296151945216",
  "geo" : { },
  "id_str" : "638353350514315264",
  "in_reply_to_user_id" : 14286491,
  "text" : "\u00ABAll data leaks. This is not a property of the internet, but a property of data\u200A\u2014\u200Ajust ask the Pharaohs of Egypt about their secret tombs\u00BB",
  "id" : 638353350514315264,
  "in_reply_to_status_id" : 638353296151945216,
  "created_at" : "2015-08-31 14:11:13 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 53 ],
      "url" : "https:\/\/t.co\/MOQqjwBLRm",
      "expanded_url" : "https:\/\/medium.com\/message\/hello-future-pastebin-readers-39d9b4eb935f",
      "display_url" : "medium.com\/message\/hello-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "638353296151945216",
  "text" : "Hello Future Pastebin Readers https:\/\/t.co\/MOQqjwBLRm",
  "id" : 638353296151945216,
  "created_at" : "2015-08-31 14:11:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 69 ],
      "url" : "https:\/\/t.co\/PT8NMe0Zgq",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=Uox-t4OB6hE",
      "display_url" : "youtube.com\/watch?v=Uox-t4\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "638342292013715457",
  "geo" : { },
  "id_str" : "638350471305011200",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot use what you learned over the weekend? https:\/\/t.co\/PT8NMe0Zgq",
  "id" : 638350471305011200,
  "in_reply_to_status_id" : 638342292013715457,
  "created_at" : "2015-08-31 13:59:46 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "638334395154329600",
  "geo" : { },
  "id_str" : "638340369328025601",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot kannst du die die Werkstatt fragen ob sie die bei mir auch noch einbauen k\u00F6nnen? \uD83D\uDE3B",
  "id" : 638340369328025601,
  "in_reply_to_status_id" : 638334395154329600,
  "created_at" : "2015-08-31 13:19:38 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "638329746120667136",
  "geo" : { },
  "id_str" : "638339497822941184",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot blood, sweat and tears?",
  "id" : 638339497822941184,
  "in_reply_to_status_id" : 638329746120667136,
  "created_at" : "2015-08-31 13:16:10 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "638336515093962752",
  "geo" : { },
  "id_str" : "638336730714755072",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot would make a great cat gif!",
  "id" : 638336730714755072,
  "in_reply_to_status_id" : 638336515093962752,
  "created_at" : "2015-08-31 13:05:10 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "638335264243499008",
  "geo" : { },
  "id_str" : "638336233660399616",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot I\u2019m sure they can\u2019t open doors :p",
  "id" : 638336233660399616,
  "in_reply_to_status_id" : 638335264243499008,
  "created_at" : "2015-08-31 13:03:12 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "638330651276636160",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17242248666215, 8.627504456241208 ]
  },
  "id_str" : "638333211840524288",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot I think they like the construction sites much more. :3",
  "id" : 638333211840524288,
  "in_reply_to_status_id" : 638330651276636160,
  "created_at" : "2015-08-31 12:51:12 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gero Nagel",
      "screen_name" : "zweifeln",
      "indices" : [ 3, 12 ],
      "id_str" : "170420130",
      "id" : 170420130
    }, {
      "name" : "openmind #om17",
      "screen_name" : "openmindkonf",
      "indices" : [ 38, 51 ],
      "id_str" : "158112993",
      "id" : 158112993
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "om15",
      "indices" : [ 120, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "638291027338653696",
  "text" : "RT @zweifeln: In 11 Tagen beginnt die @openmindkonf und sie wird sehr gut werden. Und: es gibt noch Tickets \\o\/ \\o\/ \\o\/\n#om15\nhttps:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "openmind #om17",
        "screen_name" : "openmindkonf",
        "indices" : [ 24, 37 ],
        "id_str" : "158112993",
        "id" : 158112993
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "om15",
        "indices" : [ 106, 111 ]
      } ],
      "urls" : [ {
        "indices" : [ 112, 135 ],
        "url" : "https:\/\/t.co\/APNeRl0zEV",
        "expanded_url" : "https:\/\/15.openmind-konferenz.de\/",
        "display_url" : "15.openmind-konferenz.de"
      } ]
    },
    "geo" : { },
    "id_str" : "638289550587109376",
    "text" : "In 11 Tagen beginnt die @openmindkonf und sie wird sehr gut werden. Und: es gibt noch Tickets \\o\/ \\o\/ \\o\/\n#om15\nhttps:\/\/t.co\/APNeRl0zEV",
    "id" : 638289550587109376,
    "created_at" : "2015-08-31 09:57:42 +0000",
    "user" : {
      "name" : "Gero Nagel",
      "screen_name" : "zweifeln",
      "protected" : false,
      "id_str" : "170420130",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/792075587921870848\/9Pu-OVPG_normal.jpg",
      "id" : 170420130,
      "verified" : false
    }
  },
  "id" : 638291027338653696,
  "created_at" : "2015-08-31 10:03:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christophe Dessimoz",
      "screen_name" : "cdessimoz",
      "indices" : [ 0, 10 ],
      "id_str" : "274388734",
      "id" : 274388734
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "638283980995956736",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17237141520165, 8.627504225229789 ]
  },
  "id_str" : "638286927024812032",
  "in_reply_to_user_id" : 274388734,
  "text" : "@cdessimoz congratulations, and all the best for the move!",
  "id" : 638286927024812032,
  "in_reply_to_status_id" : 638283980995956736,
  "created_at" : "2015-08-31 09:47:16 +0000",
  "in_reply_to_screen_name" : "cdessimoz",
  "in_reply_to_user_id_str" : "274388734",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul-Olivier Dehaye",
      "screen_name" : "podehaye",
      "indices" : [ 0, 9 ],
      "id_str" : "2219841242",
      "id" : 2219841242
    }, {
      "name" : "Ernst Hafen",
      "screen_name" : "ehafen",
      "indices" : [ 10, 17 ],
      "id_str" : "159891548",
      "id" : 159891548
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "638277626625413124",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17232083736499, 8.627521836800325 ]
  },
  "id_str" : "638280322606567428",
  "in_reply_to_user_id" : 2219841242,
  "text" : "@podehaye @ehafen i think you're not allowed on a TED stage if you\u2019re not at least a bit too optimistic. ;)",
  "id" : 638280322606567428,
  "in_reply_to_status_id" : 638277626625413124,
  "created_at" : "2015-08-31 09:21:02 +0000",
  "in_reply_to_screen_name" : "podehaye",
  "in_reply_to_user_id_str" : "2219841242",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "638271073356783616",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17232103458751, 8.62753212704933 ]
  },
  "id_str" : "638272064449839104",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot not sure whether that applies for free roaming ones as well ;)",
  "id" : 638272064449839104,
  "in_reply_to_status_id" : 638271073356783616,
  "created_at" : "2015-08-31 08:48:13 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/7kIxfJCvCz",
      "expanded_url" : "http:\/\/www.washingtonian.com\/blogs\/openhouse\/pets\/ask-a-vet-why-does-the-cat-poop-on-the-bed.php",
      "display_url" : "washingtonian.com\/blogs\/openhous\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "638269221902880768",
  "geo" : { },
  "id_str" : "638269498902994944",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot let me help you out with your \u201Cpressing\u201D pet questions! http:\/\/t.co\/7kIxfJCvCz",
  "id" : 638269498902994944,
  "in_reply_to_status_id" : 638269221902880768,
  "created_at" : "2015-08-31 08:38:01 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "638267806044266496",
  "geo" : { },
  "id_str" : "638268052967149568",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot yes, but are you familiar with cats? :P",
  "id" : 638268052967149568,
  "in_reply_to_status_id" : 638267806044266496,
  "created_at" : "2015-08-31 08:32:16 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "638265000658903041",
  "geo" : { },
  "id_str" : "638265584434679809",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot shed, shat\u2026 you say tomato, i say tomato?",
  "id" : 638265584434679809,
  "in_reply_to_status_id" : 638265000658903041,
  "created_at" : "2015-08-31 08:22:28 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 62 ],
      "url" : "http:\/\/t.co\/2eQPmsyVhw",
      "expanded_url" : "http:\/\/orig02.deviantart.net\/40ea\/f\/2012\/337\/0\/7\/cameron___cam___tucker_in_cat_costume_by_marhutchy-d5mx07n.gif",
      "display_url" : "orig02.deviantart.net\/40ea\/f\/2012\/33\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "638263758985560064",
  "geo" : { },
  "id_str" : "638264344019644416",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot sorry, but this is more my style http:\/\/t.co\/2eQPmsyVhw",
  "id" : 638264344019644416,
  "in_reply_to_status_id" : 638263758985560064,
  "created_at" : "2015-08-31 08:17:32 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 83 ],
      "url" : "https:\/\/t.co\/UKxR08RLm7",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/638254784148054016",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "638254589796421632",
  "geo" : { },
  "id_str" : "638254893405487104",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer it\u2019s summer time here, so quite similar, c.f. https:\/\/t.co\/UKxR08RLm7",
  "id" : 638254893405487104,
  "in_reply_to_status_id" : 638254589796421632,
  "created_at" : "2015-08-31 07:39:59 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/0Mlj2bUmj7",
      "expanded_url" : "http:\/\/media.giphy.com\/media\/3oEduFvRuMqQdjCfXq\/giphy.gif",
      "display_url" : "media.giphy.com\/media\/3oEduFvR\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "638254784148054016",
  "text" : "right now the campus feels like \u2018last man on earth\u2019. i guess that can mean only one thing: http:\/\/t.co\/0Mlj2bUmj7",
  "id" : 638254784148054016,
  "created_at" : "2015-08-31 07:39:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "638252610382753793",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17230537249596, 8.627526720893298 ]
  },
  "id_str" : "638252943435808768",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer thanks, just started reading the scaffolding thing from your last tweet. Might have to give impromptu journal club on Wed. ;)",
  "id" : 638252943435808768,
  "in_reply_to_status_id" : 638252610382753793,
  "created_at" : "2015-08-31 07:32:14 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 92 ],
      "url" : "https:\/\/t.co\/3Ti8SMxl51",
      "expanded_url" : "https:\/\/twitter.com\/KateClancy\/status\/638250869725732864",
      "display_url" : "twitter.com\/KateClancy\/sta\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "637212766261112832",
  "geo" : { },
  "id_str" : "638252061931479040",
  "in_reply_to_user_id" : 14286491,
  "text" : "Following \u201Cviolin plot or sex toy?\u201D: \u201Cwet lab equipment or sex toy?\u201D https:\/\/t.co\/3Ti8SMxl51",
  "id" : 638252061931479040,
  "in_reply_to_status_id" : 637212766261112832,
  "created_at" : "2015-08-31 07:28:44 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 58 ],
      "url" : "http:\/\/t.co\/PcueYq7oJr",
      "expanded_url" : "http:\/\/blogs.scientificamerican.com\/beautiful-minds\/confessions-of-a-neurotic-extravert\/?utm_source=feedburner&utm_medium=feed&utm_campaign=Feed%3A+all-blogs%2Ffeed+%28Blog%3A+Scientific+American+Blogs+Posts%29",
      "display_url" : "blogs.scientificamerican.com\/beautiful-mind\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "638245210015854592",
  "text" : "Confessions of a Neurotic Extravert http:\/\/t.co\/PcueYq7oJr",
  "id" : 638245210015854592,
  "created_at" : "2015-08-31 07:01:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fiona Nielsen",
      "screen_name" : "glyn_dk",
      "indices" : [ 3, 11 ],
      "id_str" : "32340834",
      "id" : 32340834
    }, {
      "name" : "Fiona Nielsen",
      "screen_name" : "glyn_dk",
      "indices" : [ 63, 71 ],
      "id_str" : "32340834",
      "id" : 32340834
    }, {
      "name" : "LinkedIn",
      "screen_name" : "LinkedIn",
      "indices" : [ 75, 84 ],
      "id_str" : "13058772",
      "id" : 13058772
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/uoYnGNwjs7",
      "expanded_url" : "https:\/\/www.linkedin.com\/pulse\/death-loss-oliver-sacks-uncle-louis-fiona-nielsen",
      "display_url" : "linkedin.com\/pulse\/death-lo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "638236490070364160",
  "text" : "RT @glyn_dk: \"Death and loss: Oliver Sacks and Uncle Louis\" by @glyn_dk on @LinkedIn https:\/\/t.co\/uoYnGNwjs7",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Fiona Nielsen",
        "screen_name" : "glyn_dk",
        "indices" : [ 50, 58 ],
        "id_str" : "32340834",
        "id" : 32340834
      }, {
        "name" : "LinkedIn",
        "screen_name" : "LinkedIn",
        "indices" : [ 62, 71 ],
        "id_str" : "13058772",
        "id" : 13058772
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 72, 95 ],
        "url" : "https:\/\/t.co\/uoYnGNwjs7",
        "expanded_url" : "https:\/\/www.linkedin.com\/pulse\/death-loss-oliver-sacks-uncle-louis-fiona-nielsen",
        "display_url" : "linkedin.com\/pulse\/death-lo\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "638117703866294272",
    "text" : "\"Death and loss: Oliver Sacks and Uncle Louis\" by @glyn_dk on @LinkedIn https:\/\/t.co\/uoYnGNwjs7",
    "id" : 638117703866294272,
    "created_at" : "2015-08-30 22:34:50 +0000",
    "user" : {
      "name" : "Fiona Nielsen",
      "screen_name" : "glyn_dk",
      "protected" : false,
      "id_str" : "32340834",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3409523398\/35ae8a97e778ebb56089e9a9b58ab9b1_normal.png",
      "id" : 32340834,
      "verified" : false
    }
  },
  "id" : 638236490070364160,
  "created_at" : "2015-08-31 06:26:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nazeefa",
      "screen_name" : "NazeefaFatima",
      "indices" : [ 0, 14 ],
      "id_str" : "37054704",
      "id" : 37054704
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "638112437380775936",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17233522558431, 8.627521842996652 ]
  },
  "id_str" : "638235121154424832",
  "in_reply_to_user_id" : 37054704,
  "text" : "@NazeefaFatima yet another plan b in case academia doesn\u2019t work out. :)",
  "id" : 638235121154424832,
  "in_reply_to_status_id" : 638112437380775936,
  "created_at" : "2015-08-31 06:21:25 +0000",
  "in_reply_to_screen_name" : "NazeefaFatima",
  "in_reply_to_user_id_str" : "37054704",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nazeefa",
      "screen_name" : "NazeefaFatima",
      "indices" : [ 0, 14 ],
      "id_str" : "37054704",
      "id" : 37054704
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "638105029266796545",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11408333590535, 8.753374460769436 ]
  },
  "id_str" : "638106406332317696",
  "in_reply_to_user_id" : 37054704,
  "text" : "@NazeefaFatima same here, we should start a scientific collaboration on baking and eating cake. \uD83D\uDCCA\uD83D\uDD2C",
  "id" : 638106406332317696,
  "in_reply_to_status_id" : 638105029266796545,
  "created_at" : "2015-08-30 21:49:57 +0000",
  "in_reply_to_screen_name" : "NazeefaFatima",
  "in_reply_to_user_id_str" : "37054704",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nazeefa",
      "screen_name" : "NazeefaFatima",
      "indices" : [ 0, 14 ],
      "id_str" : "37054704",
      "id" : 37054704
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "638097115483389952",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11408284841108, 8.753374960345042 ]
  },
  "id_str" : "638098559183757312",
  "in_reply_to_user_id" : 37054704,
  "text" : "@NazeefaFatima \uD83C\uDF70\uD83D\uDC96",
  "id" : 638098559183757312,
  "in_reply_to_status_id" : 638097115483389952,
  "created_at" : "2015-08-30 21:18:46 +0000",
  "in_reply_to_screen_name" : "NazeefaFatima",
  "in_reply_to_user_id_str" : "37054704",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mairav Zonszein",
      "screen_name" : "MairavZ",
      "indices" : [ 3, 11 ],
      "id_str" : "217708411",
      "id" : 217708411
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/xOZTSbCbD9",
      "expanded_url" : "http:\/\/ind.pn\/1NtMMEx",
      "display_url" : "ind.pn\/1NtMMEx"
    } ]
  },
  "geo" : { },
  "id_str" : "638083997709561856",
  "text" : "RT @MairavZ: wow. German couple starts website to match asylum seekers with potential housemates  http:\/\/t.co\/xOZTSbCbD9",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 85, 107 ],
        "url" : "http:\/\/t.co\/xOZTSbCbD9",
        "expanded_url" : "http:\/\/ind.pn\/1NtMMEx",
        "display_url" : "ind.pn\/1NtMMEx"
      } ]
    },
    "geo" : { },
    "id_str" : "638020097932554240",
    "text" : "wow. German couple starts website to match asylum seekers with potential housemates  http:\/\/t.co\/xOZTSbCbD9",
    "id" : 638020097932554240,
    "created_at" : "2015-08-30 16:06:59 +0000",
    "user" : {
      "name" : "Mairav Zonszein",
      "screen_name" : "MairavZ",
      "protected" : false,
      "id_str" : "217708411",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/919086828052889600\/OR2Qs4h3_normal.jpg",
      "id" : 217708411,
      "verified" : true
    }
  },
  "id" : 638083997709561856,
  "created_at" : "2015-08-30 20:20:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "beau",
      "screen_name" : "beaugunderson",
      "indices" : [ 0, 14 ],
      "id_str" : "5746882",
      "id" : 5746882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "638024444519190528",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.10368997257363, 8.766597719523586 ]
  },
  "id_str" : "638062199865503744",
  "in_reply_to_user_id" : 5746882,
  "text" : "@beaugunderson should have added \u2018streaming\u2019 as another buzz word.",
  "id" : 638062199865503744,
  "in_reply_to_status_id" : 638024444519190528,
  "created_at" : "2015-08-30 18:54:17 +0000",
  "in_reply_to_screen_name" : "beaugunderson",
  "in_reply_to_user_id_str" : "5746882",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Techniktagebuch",
      "screen_name" : "techniktagebuch",
      "indices" : [ 3, 19 ],
      "id_str" : "2359474651",
      "id" : 2359474651
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "638008422676492289",
  "text" : "RT @techniktagebuch: \"Every time I go to a new country, I buy a SIM card and activate the Internet and download the map to locate myself\u201D h\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/tuqERuN2RW",
        "expanded_url" : "http:\/\/mobile.nytimes.com\/2015\/08\/26\/world\/europe\/a-21st-century-migrants-checklist-water-shelter-smartphone.html",
        "display_url" : "mobile.nytimes.com\/2015\/08\/26\/wor\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "637996336000946176",
    "text" : "\"Every time I go to a new country, I buy a SIM card and activate the Internet and download the map to locate myself\u201D http:\/\/t.co\/tuqERuN2RW",
    "id" : 637996336000946176,
    "created_at" : "2015-08-30 14:32:34 +0000",
    "user" : {
      "name" : "Techniktagebuch",
      "screen_name" : "techniktagebuch",
      "protected" : false,
      "id_str" : "2359474651",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/438042100852981760\/VsxZxnQH_normal.png",
      "id" : 2359474651,
      "verified" : false
    }
  },
  "id" : 638008422676492289,
  "created_at" : "2015-08-30 15:20:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Maarten den Braber",
      "screen_name" : "mdbraber",
      "indices" : [ 0, 9 ],
      "id_str" : "9938952",
      "id" : 9938952
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "637993579848290304",
  "geo" : { },
  "id_str" : "637996245622095872",
  "in_reply_to_user_id" : 9938952,
  "text" : "@mdbraber maybe, you have to watch out with those hackers ;)",
  "id" : 637996245622095872,
  "in_reply_to_status_id" : 637993579848290304,
  "created_at" : "2015-08-30 14:32:13 +0000",
  "in_reply_to_screen_name" : "mdbraber",
  "in_reply_to_user_id_str" : "9938952",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Maarten den Braber",
      "screen_name" : "mdbraber",
      "indices" : [ 0, 9 ],
      "id_str" : "9938952",
      "id" : 9938952
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "637993399900078080",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11407718423077, 8.753295635783797 ]
  },
  "id_str" : "637993496272633856",
  "in_reply_to_user_id" : 9938952,
  "text" : "@mdbraber same here.",
  "id" : 637993496272633856,
  "in_reply_to_status_id" : 637993399900078080,
  "created_at" : "2015-08-30 14:21:17 +0000",
  "in_reply_to_screen_name" : "mdbraber",
  "in_reply_to_user_id_str" : "9938952",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 65 ],
      "url" : "https:\/\/t.co\/cYAUTDAQ32",
      "expanded_url" : "https:\/\/m.youtube.com\/watch?v=pr7z-M7WgDY",
      "display_url" : "m.youtube.com\/watch?v=pr7z-M\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11408272372681, 8.753374730111396 ]
  },
  "id_str" : "637992343891771392",
  "text" : "Revealed: Donald Trump Was An Anchor Baby https:\/\/t.co\/cYAUTDAQ32",
  "id" : 637992343891771392,
  "created_at" : "2015-08-30 14:16:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "liebtdiekuchen",
      "indices" : [ 7, 22 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "637989847693701120",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11408292471153, 8.753377350277125 ]
  },
  "id_str" : "637990577020215296",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot #liebtdiekuchen",
  "id" : 637990577020215296,
  "in_reply_to_status_id" : 637989847693701120,
  "created_at" : "2015-08-30 14:09:41 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "637989847693701120",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11408292471153, 8.753377350277125 ]
  },
  "id_str" : "637990486867865600",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot alles was man \u00FCber mich wissen muss in &lt;140 Zeichen.",
  "id" : 637990486867865600,
  "in_reply_to_status_id" : 637989847693701120,
  "created_at" : "2015-08-30 14:09:20 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 48 ],
      "url" : "http:\/\/t.co\/XB5a0YWkCx",
      "expanded_url" : "http:\/\/feeds.boingboing.net\/~r\/boingboing\/iBag\/~3\/wW0lNuP_qag\/put-nutella-on-everything.html",
      "display_url" : "feeds.boingboing.net\/~r\/boingboing\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "637984388362432513",
  "text" : "Put Nutella on everything http:\/\/t.co\/XB5a0YWkCx",
  "id" : 637984388362432513,
  "created_at" : "2015-08-30 13:45:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brookings Governance",
      "screen_name" : "BrookingsGov",
      "indices" : [ 3, 16 ],
      "id_str" : "87712431",
      "id" : 87712431
    }, {
      "name" : "Lessig",
      "screen_name" : "lessig",
      "indices" : [ 29, 36 ],
      "id_str" : "11388132",
      "id" : 11388132
    }, {
      "name" : "Medium",
      "screen_name" : "Medium",
      "indices" : [ 63, 70 ],
      "id_str" : "571202103",
      "id" : 571202103
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/QOamrTYkNk",
      "expanded_url" : "http:\/\/brook.gs\/1LAKaTM",
      "display_url" : "brook.gs\/1LAKaTM"
    } ]
  },
  "geo" : { },
  "id_str" : "637979582176567296",
  "text" : "RT @BrookingsGov: Don't miss @lessig's response to Tom Mann on @Medium: \"On 'dumbing down' the Democratic debate\" http:\/\/t.co\/QOamrTYkNk #F\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Lessig",
        "screen_name" : "lessig",
        "indices" : [ 11, 18 ],
        "id_str" : "11388132",
        "id" : 11388132
      }, {
        "name" : "Medium",
        "screen_name" : "Medium",
        "indices" : [ 45, 52 ],
        "id_str" : "571202103",
        "id" : 571202103
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "FixGov",
        "indices" : [ 119, 126 ]
      } ],
      "urls" : [ {
        "indices" : [ 96, 118 ],
        "url" : "http:\/\/t.co\/QOamrTYkNk",
        "expanded_url" : "http:\/\/brook.gs\/1LAKaTM",
        "display_url" : "brook.gs\/1LAKaTM"
      } ]
    },
    "geo" : { },
    "id_str" : "637975073383579649",
    "text" : "Don't miss @lessig's response to Tom Mann on @Medium: \"On 'dumbing down' the Democratic debate\" http:\/\/t.co\/QOamrTYkNk #FixGov",
    "id" : 637975073383579649,
    "created_at" : "2015-08-30 13:08:05 +0000",
    "user" : {
      "name" : "Brookings Governance",
      "screen_name" : "BrookingsGov",
      "protected" : false,
      "id_str" : "87712431",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/926153238201724928\/5VmftNx8_normal.jpg",
      "id" : 87712431,
      "verified" : true
    }
  },
  "id" : 637979582176567296,
  "created_at" : "2015-08-30 13:26:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amelia Marshall",
      "screen_name" : "amelia___m",
      "indices" : [ 3, 14 ],
      "id_str" : "301279449",
      "id" : 301279449
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "637974326290042880",
  "text" : "RT @amelia___m: Julian Assange's current look is very \"audience member at a talk who pretends his statement is a question\" http:\/\/t.co\/iYP4\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/amelia___m\/status\/637752049262833664\/photo\/1",
        "indices" : [ 107, 129 ],
        "url" : "http:\/\/t.co\/iYP4K77RR7",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CNnAG9rWsAAacy9.png",
        "id_str" : "637752048117788672",
        "id" : 637752048117788672,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CNnAG9rWsAAacy9.png",
        "sizes" : [ {
          "h" : 357,
          "resize" : "fit",
          "w" : 539
        }, {
          "h" : 357,
          "resize" : "fit",
          "w" : 539
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 357,
          "resize" : "fit",
          "w" : 539
        }, {
          "h" : 357,
          "resize" : "fit",
          "w" : 539
        } ],
        "display_url" : "pic.twitter.com\/iYP4K77RR7"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "637752049262833664",
    "text" : "Julian Assange's current look is very \"audience member at a talk who pretends his statement is a question\" http:\/\/t.co\/iYP4K77RR7",
    "id" : 637752049262833664,
    "created_at" : "2015-08-29 22:21:52 +0000",
    "user" : {
      "name" : "Amelia Marshall",
      "screen_name" : "amelia___m",
      "protected" : false,
      "id_str" : "301279449",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/929520088847302656\/E4QNLN3G_normal.jpg",
      "id" : 301279449,
      "verified" : true
    }
  },
  "id" : 637974326290042880,
  "created_at" : "2015-08-30 13:05:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fiona Nielsen",
      "screen_name" : "glyn_dk",
      "indices" : [ 3, 11 ],
      "id_str" : "32340834",
      "id" : 32340834
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "neuroscience",
      "indices" : [ 93, 106 ]
    }, {
      "text" : "metastatic",
      "indices" : [ 107, 118 ]
    }, {
      "text" : "cancer",
      "indices" : [ 119, 126 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "637940849532383232",
  "text" : "RT @glyn_dk: Many of my best reading moments and human insights were thanks to Oliver Sacks. #neuroscience #metastatic #cancer\n\nhttp:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "neuroscience",
        "indices" : [ 80, 93 ]
      }, {
        "text" : "metastatic",
        "indices" : [ 94, 105 ]
      }, {
        "text" : "cancer",
        "indices" : [ 106, 113 ]
      } ],
      "urls" : [ {
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/kO2XPOZAPj",
        "expanded_url" : "http:\/\/mobile.nytimes.com\/2015\/08\/31\/science\/oliver-sacks-dies-at-82-neurologist-and-author-explored-the-brains-quirks.html",
        "display_url" : "mobile.nytimes.com\/2015\/08\/31\/sci\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "637929395206926337",
    "text" : "Many of my best reading moments and human insights were thanks to Oliver Sacks. #neuroscience #metastatic #cancer\n\nhttp:\/\/t.co\/kO2XPOZAPj",
    "id" : 637929395206926337,
    "created_at" : "2015-08-30 10:06:34 +0000",
    "user" : {
      "name" : "Fiona Nielsen",
      "screen_name" : "glyn_dk",
      "protected" : false,
      "id_str" : "32340834",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3409523398\/35ae8a97e778ebb56089e9a9b58ab9b1_normal.png",
      "id" : 32340834,
      "verified" : false
    }
  },
  "id" : 637940849532383232,
  "created_at" : "2015-08-30 10:52:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Narender Ramnani",
      "screen_name" : "n_ramnani",
      "indices" : [ 3, 13 ],
      "id_str" : "604675580",
      "id" : 604675580
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/aeMqYKBKy2",
      "expanded_url" : "http:\/\/nyti.ms\/1MVmNG3",
      "display_url" : "nyti.ms\/1MVmNG3"
    } ]
  },
  "geo" : { },
  "id_str" : "637939364534857728",
  "text" : "RT @n_ramnani: Oliver Sacks Dies at 82; Neurologist and Author Explored the Brain\u2019s Quirks   http:\/\/t.co\/aeMqYKBKy2",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 78, 100 ],
        "url" : "http:\/\/t.co\/aeMqYKBKy2",
        "expanded_url" : "http:\/\/nyti.ms\/1MVmNG3",
        "display_url" : "nyti.ms\/1MVmNG3"
      } ]
    },
    "geo" : { },
    "id_str" : "637920970293006337",
    "text" : "Oliver Sacks Dies at 82; Neurologist and Author Explored the Brain\u2019s Quirks   http:\/\/t.co\/aeMqYKBKy2",
    "id" : 637920970293006337,
    "created_at" : "2015-08-30 09:33:05 +0000",
    "user" : {
      "name" : "Narender Ramnani",
      "screen_name" : "n_ramnani",
      "protected" : false,
      "id_str" : "604675580",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747015374386823168\/8lG-2NdH_normal.jpg",
      "id" : 604675580,
      "verified" : false
    }
  },
  "id" : 637939364534857728,
  "created_at" : "2015-08-30 10:46:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katha",
      "screen_name" : "kathakatze",
      "indices" : [ 0, 11 ],
      "id_str" : "541170257",
      "id" : 541170257
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "637915999480639488",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11408113542993, 8.753366150472571 ]
  },
  "id_str" : "637934215145881600",
  "in_reply_to_user_id" : 541170257,
  "text" : "@kathakatze die Zusammenstellung gef\u00E4llt mir sehr. Dazu vielleicht noch ein \uD83C\uDF66?",
  "id" : 637934215145881600,
  "in_reply_to_status_id" : 637915999480639488,
  "created_at" : "2015-08-30 10:25:43 +0000",
  "in_reply_to_screen_name" : "kathakatze",
  "in_reply_to_user_id_str" : "541170257",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katha",
      "screen_name" : "kathakatze",
      "indices" : [ 0, 11 ],
      "id_str" : "541170257",
      "id" : 541170257
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "637910707107950592",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11408269633039, 8.75337245948337 ]
  },
  "id_str" : "637911141243617280",
  "in_reply_to_user_id" : 541170257,
  "text" : "@kathakatze digitales Fr\u00FChst\u00FCck im Bett?",
  "id" : 637911141243617280,
  "in_reply_to_status_id" : 637910707107950592,
  "created_at" : "2015-08-30 08:54:02 +0000",
  "in_reply_to_screen_name" : "kathakatze",
  "in_reply_to_user_id_str" : "541170257",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katha",
      "screen_name" : "kathakatze",
      "indices" : [ 0, 11 ],
      "id_str" : "541170257",
      "id" : 541170257
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "637909697354403840",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11408269633039, 8.75337245948337 ]
  },
  "id_str" : "637910463762812928",
  "in_reply_to_user_id" : 541170257,
  "text" : "@kathakatze so eine gute Vorlage f\u00FCr sexual innuendos und ich bin noch nicht wach genug. \uD83D\uDE33",
  "id" : 637910463762812928,
  "in_reply_to_status_id" : 637909697354403840,
  "created_at" : "2015-08-30 08:51:21 +0000",
  "in_reply_to_screen_name" : "kathakatze",
  "in_reply_to_user_id_str" : "541170257",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katha",
      "screen_name" : "kathakatze",
      "indices" : [ 0, 11 ],
      "id_str" : "541170257",
      "id" : 541170257
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "637355000436518913",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11408285834868, 8.7533747995719 ]
  },
  "id_str" : "637909501635653632",
  "in_reply_to_user_id" : 541170257,
  "text" : "@kathakatze seitdem als Loop in meinem Kopf, danke :3",
  "id" : 637909501635653632,
  "in_reply_to_status_id" : 637355000436518913,
  "created_at" : "2015-08-30 08:47:31 +0000",
  "in_reply_to_screen_name" : "kathakatze",
  "in_reply_to_user_id_str" : "541170257",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fiona Nielsen",
      "screen_name" : "glyn_dk",
      "indices" : [ 3, 11 ],
      "id_str" : "32340834",
      "id" : 32340834
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "637908963330236416",
  "text" : "RT @glyn_dk: taxi drivers and Uber drivers find themselves in the same boat\u2014working as indpendnt contractors, logging brutal hours\nhttp:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/zsyZndGe9u",
        "expanded_url" : "http:\/\/www.bloomberg.com\/features\/2015-taxi-medallion-king\/",
        "display_url" : "bloomberg.com\/features\/2015-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "637898542703607808",
    "text" : "taxi drivers and Uber drivers find themselves in the same boat\u2014working as indpendnt contractors, logging brutal hours\nhttp:\/\/t.co\/zsyZndGe9u",
    "id" : 637898542703607808,
    "created_at" : "2015-08-30 08:03:58 +0000",
    "user" : {
      "name" : "Fiona Nielsen",
      "screen_name" : "glyn_dk",
      "protected" : false,
      "id_str" : "32340834",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3409523398\/35ae8a97e778ebb56089e9a9b58ab9b1_normal.png",
      "id" : 32340834,
      "verified" : false
    }
  },
  "id" : 637908963330236416,
  "created_at" : "2015-08-30 08:45:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Denker",
      "screen_name" : "Phaidr0s",
      "indices" : [ 0, 9 ],
      "id_str" : "40466433",
      "id" : 40466433
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "637901962663624704",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11408407673262, 8.75338275064489 ]
  },
  "id_str" : "637903471165972480",
  "in_reply_to_user_id" : 40466433,
  "text" : "@Phaidr0s i have the same expression most of the time. No wonder given all the shit that\u2019s happening.",
  "id" : 637903471165972480,
  "in_reply_to_status_id" : 637901962663624704,
  "created_at" : "2015-08-30 08:23:33 +0000",
  "in_reply_to_screen_name" : "Phaidr0s",
  "in_reply_to_user_id_str" : "40466433",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ann Loraine",
      "screen_name" : "aloraine205",
      "indices" : [ 3, 15 ],
      "id_str" : "114142293",
      "id" : 114142293
    }, {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 80, 88 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 75 ],
      "url" : "https:\/\/t.co\/k4FhvogT3N",
      "expanded_url" : "https:\/\/youtu.be\/Xv-FOSJIwrU",
      "display_url" : "youtu.be\/Xv-FOSJIwrU"
    } ]
  },
  "geo" : { },
  "id_str" : "637903231197278208",
  "text" : "RT @aloraine205: I'm not that good at breathing in. https:\/\/t.co\/k4FhvogT3N via @YouTube",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "YouTube",
        "screen_name" : "YouTube",
        "indices" : [ 63, 71 ],
        "id_str" : "10228272",
        "id" : 10228272
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 35, 58 ],
        "url" : "https:\/\/t.co\/k4FhvogT3N",
        "expanded_url" : "https:\/\/youtu.be\/Xv-FOSJIwrU",
        "display_url" : "youtu.be\/Xv-FOSJIwrU"
      } ]
    },
    "geo" : { },
    "id_str" : "637816721513037829",
    "text" : "I'm not that good at breathing in. https:\/\/t.co\/k4FhvogT3N via @YouTube",
    "id" : 637816721513037829,
    "created_at" : "2015-08-30 02:38:51 +0000",
    "user" : {
      "name" : "Ann Loraine",
      "screen_name" : "aloraine205",
      "protected" : false,
      "id_str" : "114142293",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2525523774\/olxn00n8niqsbbuq2ful_normal.jpeg",
      "id" : 114142293,
      "verified" : false
    }
  },
  "id" : 637903231197278208,
  "created_at" : "2015-08-30 08:22:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 75 ],
      "url" : "https:\/\/t.co\/6yPRJ2NXiY",
      "expanded_url" : "https:\/\/twitter.com\/tumbIerposts\/status\/635302648191696896",
      "display_url" : "twitter.com\/tumbIerposts\/s\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1140836493883, 8.753377181974278 ]
  },
  "id_str" : "637901305101590528",
  "text" : "My cat has the same puzzled facial expression 24\/7\u2026 https:\/\/t.co\/6yPRJ2NXiY",
  "id" : 637901305101590528,
  "created_at" : "2015-08-30 08:14:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Berufsquerulant",
      "screen_name" : "Stefan51278",
      "indices" : [ 0, 12 ],
      "id_str" : "18631049",
      "id" : 18631049
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "637771219555741697",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1140836493883, 8.753377181974278 ]
  },
  "id_str" : "637900798270283776",
  "in_reply_to_user_id" : 18631049,
  "text" : "@Stefan51278 der totale Widerstand marschiert? I don\u2019t even\u2026",
  "id" : 637900798270283776,
  "in_reply_to_status_id" : 637771219555741697,
  "created_at" : "2015-08-30 08:12:56 +0000",
  "in_reply_to_screen_name" : "Stefan51278",
  "in_reply_to_user_id_str" : "18631049",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 36 ],
      "url" : "https:\/\/t.co\/oWUAMWE0Pv",
      "expanded_url" : "https:\/\/instagram.com\/p\/69pJMFBwr4\/",
      "display_url" : "instagram.com\/p\/69pJMFBwr4\/"
    } ]
  },
  "geo" : { },
  "id_str" : "637565626014412800",
  "text" : "Two Ju 52\/3m https:\/\/t.co\/oWUAMWE0Pv",
  "id" : 637565626014412800,
  "created_at" : "2015-08-29 10:01:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Keith Bradnam",
      "screen_name" : "kbradnam",
      "indices" : [ 3, 12 ],
      "id_str" : "17061155",
      "id" : 17061155
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/1LdNcMl1Wn",
      "expanded_url" : "http:\/\/buff.ly\/1hK1f3Y",
      "display_url" : "buff.ly\/1hK1f3Y"
    } ]
  },
  "geo" : { },
  "id_str" : "637545048192757760",
  "text" : "RT @kbradnam: New blog post: \n\nMicrosoft's vision for bioinformatics research (caution: NSFW) http:\/\/t.co\/1LdNcMl1Wn",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 80, 102 ],
        "url" : "http:\/\/t.co\/1LdNcMl1Wn",
        "expanded_url" : "http:\/\/buff.ly\/1hK1f3Y",
        "display_url" : "buff.ly\/1hK1f3Y"
      } ]
    },
    "geo" : { },
    "id_str" : "637376398055837696",
    "text" : "New blog post: \n\nMicrosoft's vision for bioinformatics research (caution: NSFW) http:\/\/t.co\/1LdNcMl1Wn",
    "id" : 637376398055837696,
    "created_at" : "2015-08-28 21:29:09 +0000",
    "user" : {
      "name" : "Keith Bradnam",
      "screen_name" : "kbradnam",
      "protected" : false,
      "id_str" : "17061155",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/583756306919489538\/D2fFCYq4_normal.jpg",
      "id" : 17061155,
      "verified" : false
    }
  },
  "id" : 637545048192757760,
  "created_at" : "2015-08-29 08:39:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 36 ],
      "url" : "https:\/\/t.co\/HqUxffkZJB",
      "expanded_url" : "https:\/\/instagram.com\/p\/69d2U-hwrv\/",
      "display_url" : "instagram.com\/p\/69d2U-hwrv\/"
    } ]
  },
  "geo" : { },
  "id_str" : "637540788172419072",
  "text" : "gone fishing https:\/\/t.co\/HqUxffkZJB",
  "id" : 637540788172419072,
  "created_at" : "2015-08-29 08:22:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Pickrell",
      "screen_name" : "joe_pickrell",
      "indices" : [ 3, 16 ],
      "id_str" : "314758565",
      "id" : 314758565
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/fPsesCn2yK",
      "expanded_url" : "http:\/\/simplystatistics.org\/2013\/08\/01\/the-roc-curves-of-science\/",
      "display_url" : "simplystatistics.org\/2013\/08\/01\/the\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "637514417832337408",
  "text" : "RT @joe_pickrell: Looks like psychologists are in a not-too-bad spot on the ROC curves of science (http:\/\/t.co\/fPsesCn2yK) http:\/\/t.co\/9rAO\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 81, 103 ],
        "url" : "http:\/\/t.co\/fPsesCn2yK",
        "expanded_url" : "http:\/\/simplystatistics.org\/2013\/08\/01\/the-roc-curves-of-science\/",
        "display_url" : "simplystatistics.org\/2013\/08\/01\/the\u2026"
      }, {
        "indices" : [ 105, 127 ],
        "url" : "http:\/\/t.co\/9rAOdZWvzv",
        "expanded_url" : "http:\/\/www.sciencemag.org\/content\/349\/6251\/aac4716",
        "display_url" : "sciencemag.org\/content\/349\/62\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "637304244538896384",
    "text" : "Looks like psychologists are in a not-too-bad spot on the ROC curves of science (http:\/\/t.co\/fPsesCn2yK) http:\/\/t.co\/9rAOdZWvzv",
    "id" : 637304244538896384,
    "created_at" : "2015-08-28 16:42:27 +0000",
    "user" : {
      "name" : "Joe Pickrell",
      "screen_name" : "joe_pickrell",
      "protected" : false,
      "id_str" : "314758565",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/923000443105611776\/g88uZpgr_normal.jpg",
      "id" : 314758565,
      "verified" : false
    }
  },
  "id" : 637514417832337408,
  "created_at" : "2015-08-29 06:37:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/hpuf8DmuTT",
      "expanded_url" : "http:\/\/chapmangamo.tumblr.com\/post\/127789707100\/how-to-sound-like-youre-hacking-into-the#notes",
      "display_url" : "chapmangamo.tumblr.com\/post\/127789707\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1138653688329, 8.75327840515016 ]
  },
  "id_str" : "637510154691420160",
  "text" : "How to sound like you\u2019re hacking into the mainframe in seven languages. http:\/\/t.co\/hpuf8DmuTT",
  "id" : 637510154691420160,
  "created_at" : "2015-08-29 06:20:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/ahaN2l5tqh",
      "expanded_url" : "https:\/\/twitter.com\/melissamcewen\/status\/637354546986123264",
      "display_url" : "twitter.com\/melissamcewen\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11404672164611, 8.753359633203122 ]
  },
  "id_str" : "637356244622274560",
  "text" : "Paleozoic diet: \u00ABgood rule of thumb:if your synapsid great-grandmother wouldn\u2019t have eaten it, you shouldn\u2019t either\u00BB https:\/\/t.co\/ahaN2l5tqh",
  "id" : 637356244622274560,
  "created_at" : "2015-08-28 20:09:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nyborg",
      "screen_name" : "ny_borg",
      "indices" : [ 0, 8 ],
      "id_str" : "570156398",
      "id" : 570156398
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "637353764249317376",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11402633842277, 8.75340937136553 ]
  },
  "id_str" : "637354003823755264",
  "in_reply_to_user_id" : 570156398,
  "text" : "@ny_borg \uD83D\uDE0D Danke!",
  "id" : 637354003823755264,
  "in_reply_to_status_id" : 637353764249317376,
  "created_at" : "2015-08-28 20:00:10 +0000",
  "in_reply_to_screen_name" : "ny_borg",
  "in_reply_to_user_id_str" : "570156398",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katha",
      "screen_name" : "kathakatze",
      "indices" : [ 0, 11 ],
      "id_str" : "541170257",
      "id" : 541170257
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "637352518994034689",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11402930369546, 8.753301412420385 ]
  },
  "id_str" : "637352650397339648",
  "in_reply_to_user_id" : 541170257,
  "text" : "@kathakatze kann halt nicht alles vor Madagaskar sein.",
  "id" : 637352650397339648,
  "in_reply_to_status_id" : 637352518994034689,
  "created_at" : "2015-08-28 19:54:47 +0000",
  "in_reply_to_screen_name" : "kathakatze",
  "in_reply_to_user_id_str" : "541170257",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katha",
      "screen_name" : "kathakatze",
      "indices" : [ 0, 11 ],
      "id_str" : "541170257",
      "id" : 541170257
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "637352041132769281",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11402930369546, 8.753301412420385 ]
  },
  "id_str" : "637352413268213760",
  "in_reply_to_user_id" : 541170257,
  "text" : "@kathakatze sitzt wie die Nazis damals in Stalingrad. [i\u2019ll show myself out]",
  "id" : 637352413268213760,
  "in_reply_to_status_id" : 637352041132769281,
  "created_at" : "2015-08-28 19:53:51 +0000",
  "in_reply_to_screen_name" : "kathakatze",
  "in_reply_to_user_id_str" : "541170257",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "gegengewalt",
      "screen_name" : "ekelias",
      "indices" : [ 0, 8 ],
      "id_str" : "15890805",
      "id" : 15890805
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "637351387270107137",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11402930369546, 8.753301412420385 ]
  },
  "id_str" : "637351696235143169",
  "in_reply_to_user_id" : 15890805,
  "text" : "@ekelias wart seit 42\/43 so nicht mehr gesehen!",
  "id" : 637351696235143169,
  "in_reply_to_status_id" : 637351387270107137,
  "created_at" : "2015-08-28 19:51:00 +0000",
  "in_reply_to_screen_name" : "ekelias",
  "in_reply_to_user_id_str" : "15890805",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 84 ],
      "url" : "https:\/\/t.co\/cIV2FcIgGP",
      "expanded_url" : "https:\/\/twitter.com\/thememorypalace\/status\/637325199994544128",
      "display_url" : "twitter.com\/thememorypalac\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.10421912795799, 8.749544497012462 ]
  },
  "id_str" : "637339134793789441",
  "text" : "And once again I cry a bit while shopping groceries. Thanks! https:\/\/t.co\/cIV2FcIgGP",
  "id" : 637339134793789441,
  "created_at" : "2015-08-28 19:01:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arikia\uD83D\uDCAB",
      "screen_name" : "arikia",
      "indices" : [ 0, 7 ],
      "id_str" : "71654283",
      "id" : 71654283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "637331962542338048",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.10853263057532, 8.754084470516519 ]
  },
  "id_str" : "637334204234252288",
  "in_reply_to_user_id" : 71654283,
  "text" : "@arikia it\u2019s even worse if you can understand what they are yelling\u2026",
  "id" : 637334204234252288,
  "in_reply_to_status_id" : 637331962542338048,
  "created_at" : "2015-08-28 18:41:30 +0000",
  "in_reply_to_screen_name" : "arikia",
  "in_reply_to_user_id_str" : "71654283",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nyborg",
      "screen_name" : "ny_borg",
      "indices" : [ 0, 8 ],
      "id_str" : "570156398",
      "id" : 570156398
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "637325550193876992",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11404629716046, 8.75336011846702 ]
  },
  "id_str" : "637325739528949760",
  "in_reply_to_user_id" : 570156398,
  "text" : "@ny_borg \uD83D\uDC96",
  "id" : 637325739528949760,
  "in_reply_to_status_id" : 637325550193876992,
  "created_at" : "2015-08-28 18:07:51 +0000",
  "in_reply_to_screen_name" : "ny_borg",
  "in_reply_to_user_id_str" : "570156398",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nyborg",
      "screen_name" : "ny_borg",
      "indices" : [ 0, 8 ],
      "id_str" : "570156398",
      "id" : 570156398
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "637312581586264069",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11404571813508, 8.753360108541763 ]
  },
  "id_str" : "637313309180604417",
  "in_reply_to_user_id" : 570156398,
  "text" : "@ny_borg hatte ich eigentlich nicht vor, aber wenn du welche bestellen solltest w\u00FCrde ich auch einen nehmen :3",
  "id" : 637313309180604417,
  "in_reply_to_status_id" : 637312581586264069,
  "created_at" : "2015-08-28 17:18:28 +0000",
  "in_reply_to_screen_name" : "ny_borg",
  "in_reply_to_user_id_str" : "570156398",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Konrad Rudolph \uD83D\uDC68\u200D\uD83D\uDD2C\uD83D\uDCBB\uD83C\uDDEA\uD83C\uDDFA",
      "screen_name" : "klmr",
      "indices" : [ 0, 5 ],
      "id_str" : "773450",
      "id" : 773450
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "637292949525688320",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11395760901154, 8.753304141097573 ]
  },
  "id_str" : "637299893304979456",
  "in_reply_to_user_id" : 773450,
  "text" : "@klmr congrats. For me it will be vice versa, having failed math at all possible occasions. :)",
  "id" : 637299893304979456,
  "in_reply_to_status_id" : 637292949525688320,
  "created_at" : "2015-08-28 16:25:09 +0000",
  "in_reply_to_screen_name" : "klmr",
  "in_reply_to_user_id_str" : "773450",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "637288358226587649",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11399153901463, 8.753285003348356 ]
  },
  "id_str" : "637288509057945600",
  "in_reply_to_user_id" : 14286491,
  "text" : "Beatrix Potter writing about George Massee.",
  "id" : 637288509057945600,
  "in_reply_to_status_id" : 637288358226587649,
  "created_at" : "2015-08-28 15:39:55 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11399153901463, 8.753285003348356 ]
  },
  "id_str" : "637288358226587649",
  "text" : "\u00ABI opine that he has passed several stages of development into a fungus himself\u2014I\u2019m occasionally conscious of a similar transformation.\u00BB",
  "id" : 637288358226587649,
  "created_at" : "2015-08-28 15:39:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Edmunds",
      "screen_name" : "SCEdmunds",
      "indices" : [ 0, 10 ],
      "id_str" : "176024190",
      "id" : 176024190
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "637253016362479616",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11408465677722, 8.753375798580551 ]
  },
  "id_str" : "637257164038520832",
  "in_reply_to_user_id" : 176024190,
  "text" : "@SCEdmunds a true scot(t)!",
  "id" : 637257164038520832,
  "in_reply_to_status_id" : 637253016362479616,
  "created_at" : "2015-08-28 13:35:22 +0000",
  "in_reply_to_screen_name" : "SCEdmunds",
  "in_reply_to_user_id_str" : "176024190",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Edmunds",
      "screen_name" : "SCEdmunds",
      "indices" : [ 0, 10 ],
      "id_str" : "176024190",
      "id" : 176024190
    }, {
      "name" : "Peter Cock",
      "screen_name" : "pjacock",
      "indices" : [ 11, 19 ],
      "id_str" : "58756672",
      "id" : 58756672
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "637242285604769792",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11408340438835, 8.753375290689767 ]
  },
  "id_str" : "637243208683143170",
  "in_reply_to_user_id" : 176024190,
  "text" : "@SCEdmunds @pjacock show, don\u2019t tell! :D (have fun!)",
  "id" : 637243208683143170,
  "in_reply_to_status_id" : 637242285604769792,
  "created_at" : "2015-08-28 12:39:55 +0000",
  "in_reply_to_screen_name" : "SCEdmunds",
  "in_reply_to_user_id_str" : "176024190",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/rJqeJHXoB8",
      "expanded_url" : "http:\/\/boingboing.net\/2015\/08\/28\/the-unique-complications-of-pl.html",
      "display_url" : "boingboing.net\/2015\/08\/28\/the\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11404848736147, 8.75336027976012 ]
  },
  "id_str" : "637232946257260544",
  "text" : "The unique complications of playing VR games as a trans person http:\/\/t.co\/rJqeJHXoB8",
  "id" : 637232946257260544,
  "created_at" : "2015-08-28 11:59:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/Mwxok8fndw",
      "expanded_url" : "https:\/\/www.washingtonpost.com\/posteverything\/wp\/2015\/08\/26\/hookup-culture-isnt-the-problem-facing-singles-today-its-math\/",
      "display_url" : "washingtonpost.com\/posteverything\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1140476762129, 8.75335977542474 ]
  },
  "id_str" : "637227793420582912",
  "text" : "\u00ABHookup culture isn\u2019t the real problem facing singles today. It\u2019s math.\u00BB https:\/\/t.co\/Mwxok8fndw",
  "id" : 637227793420582912,
  "created_at" : "2015-08-28 11:38:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "malech maltz",
      "screen_name" : "malech",
      "indices" : [ 0, 7 ],
      "id_str" : "784085846391713793",
      "id" : 784085846391713793
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11404794748231, 8.75335882257109 ]
  },
  "id_str" : "637225650173161472",
  "text" : "@malech ich kenne viele Leute die das \u00FCber Tattoos gesagt haben, aber nur wenige die nur ein Tattoo haben ;)",
  "id" : 637225650173161472,
  "created_at" : "2015-08-28 11:30:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "malech maltz",
      "screen_name" : "malech",
      "indices" : [ 0, 7 ],
      "id_str" : "784085846391713793",
      "id" : 784085846391713793
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11404794748231, 8.75335882257109 ]
  },
  "id_str" : "637225224816230400",
  "text" : "@malech dann halt beim n\u00E4chsten Mal ;)",
  "id" : 637225224816230400,
  "created_at" : "2015-08-28 11:28:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "malech maltz",
      "screen_name" : "malech",
      "indices" : [ 0, 7 ],
      "id_str" : "784085846391713793",
      "id" : 784085846391713793
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11405067322404, 8.753374087932253 ]
  },
  "id_str" : "637224601819435008",
  "text" : "@malech das motiv wird dann hoffentlich \u2018i void warranties\u2019 of jiddish? :p",
  "id" : 637224601819435008,
  "created_at" : "2015-08-28 11:25:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "malech maltz",
      "screen_name" : "malech",
      "indices" : [ 0, 7 ],
      "id_str" : "784085846391713793",
      "id" : 784085846391713793
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11407767133548, 8.753376567316916 ]
  },
  "id_str" : "637223434376900608",
  "text" : "@malech was und wo? :3",
  "id" : 637223434376900608,
  "created_at" : "2015-08-28 11:21:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ed Yong",
      "screen_name" : "edyong209",
      "indices" : [ 0, 10 ],
      "id_str" : "19767193",
      "id" : 19767193
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "637205564469182465",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11404465376965, 8.753359137357808 ]
  },
  "id_str" : "637212766261112832",
  "in_reply_to_user_id" : 19767193,
  "text" : "@edyong209 new website idea: \u201Cviolin plot or sex toy?\u201D",
  "id" : 637212766261112832,
  "in_reply_to_status_id" : 637205564469182465,
  "created_at" : "2015-08-28 10:38:56 +0000",
  "in_reply_to_screen_name" : "edyong209",
  "in_reply_to_user_id_str" : "19767193",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/uzT9S3VUeM",
      "expanded_url" : "http:\/\/www.kitchensisters.org\/2015\/08\/13\/fugitive-waves-the-braveheart-womens-society\/",
      "display_url" : "kitchensisters.org\/2015\/08\/13\/fug\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "637204161021538304",
  "text" : "Fugitive Waves: The Braveheart Women\u2019s Society http:\/\/t.co\/uzT9S3VUeM",
  "id" : 637204161021538304,
  "created_at" : "2015-08-28 10:04:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 59 ],
      "url" : "https:\/\/t.co\/bODxkXFcU9",
      "expanded_url" : "https:\/\/medium.com\/@amandapalmer\/no-i-am-not-crowdfunding-this-baby-an-open-letter-to-a-worried-fan-9ca75cb0f938",
      "display_url" : "medium.com\/@amandapalmer\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11404185556484, 8.753355270484702 ]
  },
  "id_str" : "637165174714200064",
  "text" : "No, I Am Not Crowdfunding This Baby https:\/\/t.co\/bODxkXFcU9",
  "id" : 637165174714200064,
  "created_at" : "2015-08-28 07:29:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bodo Winter",
      "screen_name" : "BodoWinter",
      "indices" : [ 3, 14 ],
      "id_str" : "3239583325",
      "id" : 3239583325
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/PT6aBUmtYu",
      "expanded_url" : "http:\/\/languagegoldmine.com\/",
      "display_url" : "languagegoldmine.com"
    } ]
  },
  "geo" : { },
  "id_str" : "637161951865491456",
  "text" : "RT @BodoWinter: Just released The Language Goldmine: A lightweight list of linguistic databases, suggestions welcome: http:\/\/t.co\/PT6aBUmtYu",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 102, 124 ],
        "url" : "http:\/\/t.co\/PT6aBUmtYu",
        "expanded_url" : "http:\/\/languagegoldmine.com\/",
        "display_url" : "languagegoldmine.com"
      } ]
    },
    "geo" : { },
    "id_str" : "636536976007659520",
    "text" : "Just released The Language Goldmine: A lightweight list of linguistic databases, suggestions welcome: http:\/\/t.co\/PT6aBUmtYu",
    "id" : 636536976007659520,
    "created_at" : "2015-08-26 13:53:36 +0000",
    "user" : {
      "name" : "Bodo Winter",
      "screen_name" : "BodoWinter",
      "protected" : false,
      "id_str" : "3239583325",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/607801072879468544\/seKGk4SI_normal.png",
      "id" : 3239583325,
      "verified" : false
    }
  },
  "id" : 637161951865491456,
  "created_at" : "2015-08-28 07:17:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 42 ],
      "url" : "http:\/\/t.co\/XVfZoloj23",
      "expanded_url" : "http:\/\/boingboing.net\/2015\/08\/27\/politely-show-the-world-you-ha.html",
      "display_url" : "boingboing.net\/2015\/08\/27\/pol\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1140420030122, 8.753355708713782 ]
  },
  "id_str" : "637161875516588032",
  "text" : "*block block block* http:\/\/t.co\/XVfZoloj23",
  "id" : 637161875516588032,
  "created_at" : "2015-08-28 07:16:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Barton",
      "screen_name" : "bioinformatics",
      "indices" : [ 0, 15 ],
      "id_str" : "14126701",
      "id" : 14126701
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "636949840610496512",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11404675304922, 8.7533643810587 ]
  },
  "id_str" : "636959661569257472",
  "in_reply_to_user_id" : 14126701,
  "text" : "@bioinformatics congrats :)",
  "id" : 636959661569257472,
  "in_reply_to_status_id" : 636949840610496512,
  "created_at" : "2015-08-27 17:53:12 +0000",
  "in_reply_to_screen_name" : "bioinformatics",
  "in_reply_to_user_id_str" : "14126701",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "malech maltz",
      "screen_name" : "malech",
      "indices" : [ 0, 7 ],
      "id_str" : "784085846391713793",
      "id" : 784085846391713793
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11404149033631, 8.75335662736858 ]
  },
  "id_str" : "636957532901257216",
  "text" : "@malech ich weiss ja genau welcher Geheimdienst dir das beigebracht hat!",
  "id" : 636957532901257216,
  "created_at" : "2015-08-27 17:44:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "malech maltz",
      "screen_name" : "malech",
      "indices" : [ 0, 7 ],
      "id_str" : "784085846391713793",
      "id" : 784085846391713793
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11404172130958, 8.753357298914981 ]
  },
  "id_str" : "636955766558167040",
  "text" : "@malech das ist ja folter!",
  "id" : 636955766558167040,
  "created_at" : "2015-08-27 17:37:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "malech maltz",
      "screen_name" : "malech",
      "indices" : [ 0, 7 ],
      "id_str" : "784085846391713793",
      "id" : 784085846391713793
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11404172130958, 8.753357298914981 ]
  },
  "id_str" : "636955511544541184",
  "text" : "@malech ich werde deshalb ein bisschen in meinen Eisbecher weinen! \uD83C\uDF67",
  "id" : 636955511544541184,
  "created_at" : "2015-08-27 17:36:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11404172100484, 8.753357299393551 ]
  },
  "id_str" : "636955276709654528",
  "text" : "Today\u2019s reasonable deadline: our landlord asks us to get rid of broken electronics stuff in the front yard until 1st of September 2014 [sic]",
  "id" : 636955276709654528,
  "created_at" : "2015-08-27 17:35:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "malech maltz",
      "screen_name" : "malech",
      "indices" : [ 0, 7 ],
      "id_str" : "784085846391713793",
      "id" : 784085846391713793
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11404172100484, 8.753357299393551 ]
  },
  "id_str" : "636954316163690496",
  "text" : "@malech vrdmt, h\u00E4tte ich das gewusst h\u00E4tte ich geklingelt als ich vor deiner Haust\u00FCr vorbeigekommen bin! \uD83C\uDF6E",
  "id" : 636954316163690496,
  "created_at" : "2015-08-27 17:31:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : ".",
      "screen_name" : "punkish",
      "indices" : [ 0, 8 ],
      "id_str" : "15322269",
      "id" : 15322269
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "636914895141797888",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17232611441571, 8.627534016939784 ]
  },
  "id_str" : "636915065212506113",
  "in_reply_to_user_id" : 15322269,
  "text" : "@punkish sweet new avatar!",
  "id" : 636915065212506113,
  "in_reply_to_status_id" : 636914895141797888,
  "created_at" : "2015-08-27 14:55:59 +0000",
  "in_reply_to_screen_name" : "punkish",
  "in_reply_to_user_id_str" : "15322269",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "636913433099636736",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17232540635285, 8.627527248106228 ]
  },
  "id_str" : "636913686523854848",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer yes, sounds like a very cool idea!",
  "id" : 636913686523854848,
  "in_reply_to_status_id" : 636913433099636736,
  "created_at" : "2015-08-27 14:50:30 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 75 ],
      "url" : "https:\/\/t.co\/xAm7pThpvs",
      "expanded_url" : "https:\/\/medium.com\/@tpoi\/how-much-methodology-should-go-in-conference-talks-174029a3ebf2",
      "display_url" : "medium.com\/@tpoi\/how-much\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17237152212414, 8.627502459087577 ]
  },
  "id_str" : "636911711384117248",
  "text" : "How much methodology should go in conference talks? https:\/\/t.co\/xAm7pThpvs",
  "id" : 636911711384117248,
  "created_at" : "2015-08-27 14:42:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "636902946417037312",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17236571152139, 8.627505248624416 ]
  },
  "id_str" : "636903091347042305",
  "in_reply_to_user_id" : 14286491,
  "text" : "\u00ABYou can blow a raspberry at guys who are big into farting, but you have to be careful not to laugh.\u00BB",
  "id" : 636903091347042305,
  "in_reply_to_status_id" : 636902946417037312,
  "created_at" : "2015-08-27 14:08:24 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 65 ],
      "url" : "https:\/\/t.co\/j5oMoMUn0P",
      "expanded_url" : "https:\/\/broadly.vice.com\/en_us\/article\/when-your-mom-works-a-phone-sex-chat-line",
      "display_url" : "broadly.vice.com\/en_us\/article\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17237590877231, 8.627502784007737 ]
  },
  "id_str" : "636902946417037312",
  "text" : "When Your Mom Works a Phone Sex Chat Line https:\/\/t.co\/j5oMoMUn0P",
  "id" : 636902946417037312,
  "created_at" : "2015-08-27 14:07:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 0, 9 ],
      "id_str" : "14245811",
      "id" : 14245811
    }, {
      "name" : "Matt Shirley",
      "screen_name" : "mdshw5",
      "indices" : [ 10, 17 ],
      "id_str" : "16961966",
      "id" : 16961966
    }, {
      "name" : "Illumina",
      "screen_name" : "illumina",
      "indices" : [ 57, 66 ],
      "id_str" : "46145761",
      "id" : 46145761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "636889360072204289",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17232692318632, 8.62753222975752 ]
  },
  "id_str" : "636890279124013056",
  "in_reply_to_user_id" : 14245811,
  "text" : "@wilbanks @mdshw5 the only thing that\u2019s \u2018long read\u2019 with @illumina is their sequence adapter PDF\u2026",
  "id" : 636890279124013056,
  "in_reply_to_status_id" : 636889360072204289,
  "created_at" : "2015-08-27 13:17:30 +0000",
  "in_reply_to_screen_name" : "wilbanks",
  "in_reply_to_user_id_str" : "14245811",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 42 ],
      "url" : "http:\/\/t.co\/V7JgzxiUT3",
      "expanded_url" : "http:\/\/www.citylab.com\/city-makers-connections\/bike-share\/",
      "display_url" : "citylab.com\/city-makers-co\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17234373048302, 8.62752111180965 ]
  },
  "id_str" : "636878709270704128",
  "text" : "The Bike-Share Boom http:\/\/t.co\/V7JgzxiUT3",
  "id" : 636878709270704128,
  "created_at" : "2015-08-27 12:31:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nazeefa",
      "screen_name" : "NazeefaFatima",
      "indices" : [ 0, 14 ],
      "id_str" : "37054704",
      "id" : 37054704
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 15, 28 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "636845272916750336",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723299964849, 8.627521910710371 ]
  },
  "id_str" : "636845646247534592",
  "in_reply_to_user_id" : 37054704,
  "text" : "@NazeefaFatima @PhilippBayer i don\u2019t think it will get much worse than it\u2019s now. for me the despair lvl made sinoid waves all the time.",
  "id" : 636845646247534592,
  "in_reply_to_status_id" : 636845272916750336,
  "created_at" : "2015-08-27 10:20:08 +0000",
  "in_reply_to_screen_name" : "NazeefaFatima",
  "in_reply_to_user_id_str" : "37054704",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nazeefa",
      "screen_name" : "NazeefaFatima",
      "indices" : [ 0, 14 ],
      "id_str" : "37054704",
      "id" : 37054704
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 15, 28 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "636843879849984000",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723299964849, 8.627521910710371 ]
  },
  "id_str" : "636844672489533440",
  "in_reply_to_user_id" : 37054704,
  "text" : "@NazeefaFatima @PhilippBayer i was waiting for that quote to come up :)",
  "id" : 636844672489533440,
  "in_reply_to_status_id" : 636843879849984000,
  "created_at" : "2015-08-27 10:16:16 +0000",
  "in_reply_to_screen_name" : "NazeefaFatima",
  "in_reply_to_user_id_str" : "37054704",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 37 ],
      "url" : "https:\/\/t.co\/kqTEDZnBJf",
      "expanded_url" : "https:\/\/upload.wikimedia.org\/wikipedia\/commons\/thumb\/2\/21\/Science_1883_Cover.png\/429px-Science_1883_Cover.png",
      "display_url" : "upload.wikimedia.org\/wikipedia\/comm\u2026"
    }, {
      "indices" : [ 52, 74 ],
      "url" : "http:\/\/t.co\/pqXUqNZZeh",
      "expanded_url" : "http:\/\/jezebel.com\/science-magazine-covers-depiction-of-trans-sex-workers-1606854820",
      "display_url" : "jezebel.com\/science-magazi\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "636817323396059136",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17232258247009, 8.627539981475628 ]
  },
  "id_str" : "636818541283573760",
  "in_reply_to_user_id" : 14286491,
  "text" : "Science 1883: https:\/\/t.co\/kqTEDZnBJf Science 2014: http:\/\/t.co\/pqXUqNZZeh",
  "id" : 636818541283573760,
  "in_reply_to_status_id" : 636817323396059136,
  "created_at" : "2015-08-27 08:32:26 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 56 ],
      "url" : "https:\/\/t.co\/hH9V0jB9k2",
      "expanded_url" : "https:\/\/medium.com\/@karenxcheng\/the-evolution-of-magazine-covers-d55514210a57",
      "display_url" : "medium.com\/@karenxcheng\/t\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17227246881438, 8.627576827976236 ]
  },
  "id_str" : "636817323396059136",
  "text" : "The Evolution of Magazine Covers https:\/\/t.co\/hH9V0jB9k2",
  "id" : 636817323396059136,
  "created_at" : "2015-08-27 08:27:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 58, 71 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 53 ],
      "url" : "http:\/\/t.co\/UiJIaA6ArG",
      "expanded_url" : "http:\/\/journals.plos.org\/ploscompbiol\/article?id=10.1371\/journal.pcbi.1004349",
      "display_url" : "journals.plos.org\/ploscompbiol\/a\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17226772659221, 8.62756880729618 ]
  },
  "id_str" : "636813490079014912",
  "text" : "Asymmetric Evolutionary Games\n http:\/\/t.co\/UiJIaA6ArG \/cc @PhilippBayer",
  "id" : 636813490079014912,
  "created_at" : "2015-08-27 08:12:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/EqpsXpQo62",
      "expanded_url" : "http:\/\/whatshouldwecallgradschool.tumblr.com\/post\/127656695585\/when-the-sequencing-data-comes-in",
      "display_url" : "whatshouldwecallgradschool.tumblr.com\/post\/127656695\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17225993380016, 8.627580705823894 ]
  },
  "id_str" : "636808648216432640",
  "text" : "Looks about right to me. http:\/\/t.co\/EqpsXpQo62",
  "id" : 636808648216432640,
  "created_at" : "2015-08-27 07:53:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Nazeefa",
      "screen_name" : "NazeefaFatima",
      "indices" : [ 14, 28 ],
      "id_str" : "37054704",
      "id" : 37054704
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "636805994102677505",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17228391630799, 8.627555492157356 ]
  },
  "id_str" : "636807830159368192",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @NazeefaFatima besides: i\u2019d say go for it :D",
  "id" : 636807830159368192,
  "in_reply_to_status_id" : 636805994102677505,
  "created_at" : "2015-08-27 07:49:52 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Nazeefa",
      "screen_name" : "NazeefaFatima",
      "indices" : [ 14, 28 ],
      "id_str" : "37054704",
      "id" : 37054704
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "636786258539253760",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.16128505073054, 8.649480937172699 ]
  },
  "id_str" : "636802673099034624",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @NazeefaFatima wanna offer resilience as another qualifier. No one knows what they are doing and shit fails all the time.",
  "id" : 636802673099034624,
  "in_reply_to_status_id" : 636786258539253760,
  "created_at" : "2015-08-27 07:29:23 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Keith Robison",
      "screen_name" : "OmicsOmicsBlog",
      "indices" : [ 3, 18 ],
      "id_str" : "116867280",
      "id" : 116867280
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/GebNdtKxza",
      "expanded_url" : "http:\/\/omicsomics.blogspot.com\/2015\/08\/the-road-to-hell-is-paved-with.html",
      "display_url" : "omicsomics.blogspot.com\/2015\/08\/the-ro\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "636800881439154176",
  "text" : "RT @OmicsOmicsBlog: The Road to Hell is Paved with Bioinformatics Formats http:\/\/t.co\/GebNdtKxza",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 54, 76 ],
        "url" : "http:\/\/t.co\/GebNdtKxza",
        "expanded_url" : "http:\/\/omicsomics.blogspot.com\/2015\/08\/the-road-to-hell-is-paved-with.html",
        "display_url" : "omicsomics.blogspot.com\/2015\/08\/the-ro\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "636748522373652480",
    "text" : "The Road to Hell is Paved with Bioinformatics Formats http:\/\/t.co\/GebNdtKxza",
    "id" : 636748522373652480,
    "created_at" : "2015-08-27 03:54:12 +0000",
    "user" : {
      "name" : "Keith Robison",
      "screen_name" : "OmicsOmicsBlog",
      "protected" : false,
      "id_str" : "116867280",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/859776960058339329\/c0IznW_h_normal.jpg",
      "id" : 116867280,
      "verified" : false
    }
  },
  "id" : 636800881439154176,
  "created_at" : "2015-08-27 07:22:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zen Faulkes",
      "screen_name" : "DoctorZen",
      "indices" : [ 0, 10 ],
      "id_str" : "16486812",
      "id" : 16486812
    }, {
      "name" : "Brad Voytek",
      "screen_name" : "bradleyvoytek",
      "indices" : [ 11, 25 ],
      "id_str" : "162535413",
      "id" : 162535413
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 58 ],
      "url" : "http:\/\/t.co\/vO7Mt8HYlY",
      "expanded_url" : "http:\/\/songexploder.net\/unknown-mortal-orchestra",
      "display_url" : "songexploder.net\/unknown-mortal\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "636578996994441216",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11402532484349, 8.753411384129905 ]
  },
  "id_str" : "636584227509772288",
  "in_reply_to_user_id" : 16486812,
  "text" : "@DoctorZen @bradleyvoytek (heard in http:\/\/t.co\/vO7Mt8HYlY about repairing broken synths)",
  "id" : 636584227509772288,
  "in_reply_to_status_id" : 636578996994441216,
  "created_at" : "2015-08-26 17:01:21 +0000",
  "in_reply_to_screen_name" : "DoctorZen",
  "in_reply_to_user_id_str" : "16486812",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zen Faulkes",
      "screen_name" : "DoctorZen",
      "indices" : [ 0, 10 ],
      "id_str" : "16486812",
      "id" : 16486812
    }, {
      "name" : "Brad Voytek",
      "screen_name" : "bradleyvoytek",
      "indices" : [ 11, 25 ],
      "id_str" : "162535413",
      "id" : 162535413
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "636578996994441216",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11404802303561, 8.753358237914766 ]
  },
  "id_str" : "636583988807774209",
  "in_reply_to_user_id" : 16486812,
  "text" : "@DoctorZen @bradleyvoytek heard today: \u00ABeverybody that knows what they are doing, didn't know what they are doing in the beginning\u00BB",
  "id" : 636583988807774209,
  "in_reply_to_status_id" : 636578996994441216,
  "created_at" : "2015-08-26 17:00:24 +0000",
  "in_reply_to_screen_name" : "DoctorZen",
  "in_reply_to_user_id_str" : "16486812",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luc Henry",
      "screen_name" : "heluc",
      "indices" : [ 0, 6 ],
      "id_str" : "850645992",
      "id" : 850645992
    }, {
      "name" : "li5a",
      "screen_name" : "li5a",
      "indices" : [ 7, 12 ],
      "id_str" : "11712822",
      "id" : 11712822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "636537968019283968",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17222745911676, 8.627620041869923 ]
  },
  "id_str" : "636538397675360256",
  "in_reply_to_user_id" : 850645992,
  "text" : "@heluc @li5a basically: the larger your sample the more unlikely to hit one exact combination. but you get closer to expected value.",
  "id" : 636538397675360256,
  "in_reply_to_status_id" : 636537968019283968,
  "created_at" : "2015-08-26 13:59:14 +0000",
  "in_reply_to_screen_name" : "heluc",
  "in_reply_to_user_id_str" : "850645992",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luc Henry",
      "screen_name" : "heluc",
      "indices" : [ 0, 6 ],
      "id_str" : "850645992",
      "id" : 850645992
    }, {
      "name" : "li5a",
      "screen_name" : "li5a",
      "indices" : [ 7, 12 ],
      "id_str" : "11712822",
      "id" : 11712822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "636535563257008128",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17224097752937, 8.627606759908033 ]
  },
  "id_str" : "636536361034645504",
  "in_reply_to_user_id" : 850645992,
  "text" : "@heluc @li5a for p(exactly 1\/2) it shrinks as well: p(1\/2)=0.5 (surprise!). p(10\/20)=0.17",
  "id" : 636536361034645504,
  "in_reply_to_status_id" : 636535563257008128,
  "created_at" : "2015-08-26 13:51:09 +0000",
  "in_reply_to_screen_name" : "heluc",
  "in_reply_to_user_id_str" : "850645992",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luc Henry",
      "screen_name" : "heluc",
      "indices" : [ 0, 6 ],
      "id_str" : "850645992",
      "id" : 850645992
    }, {
      "name" : "li5a",
      "screen_name" : "li5a",
      "indices" : [ 45, 50 ],
      "id_str" : "11712822",
      "id" : 11712822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "636535563257008128",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17224097752937, 8.627606759908033 ]
  },
  "id_str" : "636536072009326592",
  "in_reply_to_user_id" : 850645992,
  "text" : "@heluc yes, but only p(close to 1\/2), that\u2019s @li5a\u2019s idea of the law of large numbers.",
  "id" : 636536072009326592,
  "in_reply_to_status_id" : 636535563257008128,
  "created_at" : "2015-08-26 13:50:00 +0000",
  "in_reply_to_screen_name" : "heluc",
  "in_reply_to_user_id_str" : "850645992",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "li5a",
      "screen_name" : "li5a",
      "indices" : [ 0, 5 ],
      "id_str" : "11712822",
      "id" : 11712822
    }, {
      "name" : "Luc Henry",
      "screen_name" : "heluc",
      "indices" : [ 6, 12 ],
      "id_str" : "850645992",
      "id" : 850645992
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "636534277736398852",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17222984089779, 8.62761840404325 ]
  },
  "id_str" : "636535263058128896",
  "in_reply_to_user_id" : 11712822,
  "text" : "@li5a @heluc p(7\/10)=0.1171875 p(70\/100)=2.31e-05, p(70k\/100k)=python interpreter fails ;)",
  "id" : 636535263058128896,
  "in_reply_to_status_id" : 636534277736398852,
  "created_at" : "2015-08-26 13:46:47 +0000",
  "in_reply_to_screen_name" : "li5a",
  "in_reply_to_user_id_str" : "11712822",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "li5a",
      "screen_name" : "li5a",
      "indices" : [ 0, 5 ],
      "id_str" : "11712822",
      "id" : 11712822
    }, {
      "name" : "Luc Henry",
      "screen_name" : "heluc",
      "indices" : [ 6, 12 ],
      "id_str" : "850645992",
      "id" : 850645992
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "636534277736398852",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17222984089779, 8.62761840404325 ]
  },
  "id_str" : "636535078009610240",
  "in_reply_to_user_id" : 11712822,
  "text" : "@li5a @heluc the general idea is that it\u2019s getting easier and easier to be at least off-by-one the larger N grows.",
  "id" : 636535078009610240,
  "in_reply_to_status_id" : 636534277736398852,
  "created_at" : "2015-08-26 13:46:03 +0000",
  "in_reply_to_screen_name" : "li5a",
  "in_reply_to_user_id_str" : "11712822",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "li5a",
      "screen_name" : "li5a",
      "indices" : [ 0, 5 ],
      "id_str" : "11712822",
      "id" : 11712822
    }, {
      "name" : "Luc Henry",
      "screen_name" : "heluc",
      "indices" : [ 6, 12 ],
      "id_str" : "850645992",
      "id" : 850645992
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 62 ],
      "url" : "https:\/\/t.co\/XfYJMZiZDW",
      "expanded_url" : "https:\/\/en.wikipedia.org\/wiki\/Bernoulli_trial#Example:_tossing_coins",
      "display_url" : "en.wikipedia.org\/wiki\/Bernoulli\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "636529866351976448",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17222424885072, 8.627619512304808 ]
  },
  "id_str" : "636532042382094338",
  "in_reply_to_user_id" : 11712822,
  "text" : "@li5a @heluc it\u2019s a Bernoulli trial :) https:\/\/t.co\/XfYJMZiZDW",
  "id" : 636532042382094338,
  "in_reply_to_status_id" : 636529866351976448,
  "created_at" : "2015-08-26 13:33:59 +0000",
  "in_reply_to_screen_name" : "li5a",
  "in_reply_to_user_id_str" : "11712822",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "636526282038185984",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17222462703607, 8.62761563195988 ]
  },
  "id_str" : "636527065265778688",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot more like feeling empty now. \u2205",
  "id" : 636527065265778688,
  "in_reply_to_status_id" : 636526282038185984,
  "created_at" : "2015-08-26 13:14:13 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/lRXJXan6C3",
      "expanded_url" : "https:\/\/applbio.biologie.uni-frankfurt.de\/recombcg2015\/",
      "display_url" : "applbio.biologie.uni-frankfurt.de\/recombcg2015\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722348999108, 8.627613766130425 ]
  },
  "id_str" : "636526937532444672",
  "text" : "I\u2019ll be at the Recomb Comparative Genomics from 4-7th of October. Your chance to leave Frankfurt Airport for once! https:\/\/t.co\/lRXJXan6C3",
  "id" : 636526937532444672,
  "created_at" : "2015-08-26 13:13:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "636525650434727940",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722348999108, 8.627613766130425 ]
  },
  "id_str" : "636525805800173569",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot feeling a bit small now? \uD83D\uDE8C .\/. \uD83C\uDF46",
  "id" : 636525805800173569,
  "in_reply_to_status_id" : 636525650434727940,
  "created_at" : "2015-08-26 13:09:12 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 70 ],
      "url" : "http:\/\/t.co\/DGOESq5xz1",
      "expanded_url" : "http:\/\/whatshouldwecallmedschool.tumblr.com\/post\/23409919115\/viewing-a-colonoscopy",
      "display_url" : "whatshouldwecallmedschool.tumblr.com\/post\/234099191\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "636519584607154176",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17221377246636, 8.62762632868933 ]
  },
  "id_str" : "636520980337270784",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot but apparently it includes driving a bus http:\/\/t.co\/DGOESq5xz1",
  "id" : 636520980337270784,
  "in_reply_to_status_id" : 636519584607154176,
  "created_at" : "2015-08-26 12:50:02 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 47 ],
      "url" : "https:\/\/t.co\/txoOVUfbPJ",
      "expanded_url" : "https:\/\/imgur.com\/4GZ3XKG",
      "display_url" : "imgur.com\/4GZ3XKG"
    }, {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/B73tLXn6Eu",
      "expanded_url" : "http:\/\/www.dailymail.co.uk\/news\/article-2540490\/This-chick-digs-hairy-men-Animal-lover-puts-facial-hair-good-use-raising-orphaned-chick-beard.html",
      "display_url" : "dailymail.co.uk\/news\/article-2\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17221551300225, 8.627625698375851 ]
  },
  "id_str" : "636516295006101505",
  "text" : "Mh, \u00ABAirbnb for Beards\u00BB https:\/\/t.co\/txoOVUfbPJ Damn, already somewhat taken: http:\/\/t.co\/B73tLXn6Eu",
  "id" : 636516295006101505,
  "created_at" : "2015-08-26 12:31:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 50 ],
      "url" : "http:\/\/t.co\/hABYNkgotf",
      "expanded_url" : "http:\/\/i.dailymail.co.uk\/i\/pix\/tm\/2008\/galleries\/potw270608\/potwsofiaAP270608_428x269_to_468x312.jpg",
      "display_url" : "i.dailymail.co.uk\/i\/pix\/tm\/2008\/\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "636499791833366528",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17223965201033, 8.627606160352624 ]
  },
  "id_str" : "636507133090136066",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot that would look like http:\/\/t.co\/hABYNkgotf i assume.",
  "id" : 636507133090136066,
  "in_reply_to_status_id" : 636499791833366528,
  "created_at" : "2015-08-26 11:55:00 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kriszta Berkes",
      "screen_name" : "KrisztaB",
      "indices" : [ 3, 12 ],
      "id_str" : "922402893411561472",
      "id" : 922402893411561472
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 14, 30 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "636471597222744064",
  "text" : "RT @Krisztab: @gedankenstuecke Correct, except you don't wake up, because you didn't even go to sleep",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 0, 16 ],
        "id_str" : "14286491",
        "id" : 14286491
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "636275931208916992",
    "geo" : { },
    "id_str" : "636471495175327744",
    "in_reply_to_user_id" : 14286491,
    "text" : "@gedankenstuecke Correct, except you don't wake up, because you didn't even go to sleep",
    "id" : 636471495175327744,
    "in_reply_to_status_id" : 636275931208916992,
    "created_at" : "2015-08-26 09:33:24 +0000",
    "in_reply_to_screen_name" : "gedankenstuecke",
    "in_reply_to_user_id_str" : "14286491",
    "user" : {
      "name" : "Kriszta Kezia V",
      "screen_name" : "kri_keziush",
      "protected" : false,
      "id_str" : "19334473",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/836703338775343104\/tM-WE4G6_normal.jpg",
      "id" : 19334473,
      "verified" : false
    }
  },
  "id" : 636471597222744064,
  "created_at" : "2015-08-26 09:33:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 60 ],
      "url" : "http:\/\/t.co\/d6PRH4Z6BU",
      "expanded_url" : "http:\/\/www.newyorker.com\/news\/sporting-scene\/using-math-to-catch-athletes-who-dope?mbid=rss",
      "display_url" : "newyorker.com\/news\/sporting-\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17226589818552, 8.627587634912118 ]
  },
  "id_str" : "636452830929383424",
  "text" : "Using Math to Catch Athletes Who Dope http:\/\/t.co\/d6PRH4Z6BU",
  "id" : 636452830929383424,
  "created_at" : "2015-08-26 08:19:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17222160863383, 8.62761391122213 ]
  },
  "id_str" : "636451809272406016",
  "text" : "\u00ABnow new! with shorter sentences and fewer details!\u00BB email subjects going all-in on marketingnese.",
  "id" : 636451809272406016,
  "created_at" : "2015-08-26 08:15:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Holcombe",
      "screen_name" : "ceptional",
      "indices" : [ 0, 10 ],
      "id_str" : "176371696",
      "id" : 176371696
    }, {
      "name" : "Fiona Nielsen",
      "screen_name" : "glyn_dk",
      "indices" : [ 11, 19 ],
      "id_str" : "32340834",
      "id" : 32340834
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "636074066663747584",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17222321911288, 8.627616975476881 ]
  },
  "id_str" : "636432171171975168",
  "in_reply_to_user_id" : 176371696,
  "text" : "@ceptional @glyn_dk like always in copyright matters the answer is a clear \u201Cmaybe\u201D. fwiw (not much): i\u2019d go for it.",
  "id" : 636432171171975168,
  "in_reply_to_status_id" : 636074066663747584,
  "created_at" : "2015-08-26 06:57:08 +0000",
  "in_reply_to_screen_name" : "ceptional",
  "in_reply_to_user_id_str" : "176371696",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.10362273617111, 8.752609194269077 ]
  },
  "id_str" : "636416839292178432",
  "text" : "First day of commuter trains moving again after a month-long break due to construction: of course trains are breaking down now\u2026 *slowclap*",
  "id" : 636416839292178432,
  "created_at" : "2015-08-26 05:56:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nazeefa",
      "screen_name" : "NazeefaFatima",
      "indices" : [ 0, 14 ],
      "id_str" : "37054704",
      "id" : 37054704
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "636324439093870592",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11402397603894, 8.753412076971461 ]
  },
  "id_str" : "636410250711728129",
  "in_reply_to_user_id" : 37054704,
  "text" : "@NazeefaFatima I guess the longer you play the game, the closer you sail the deadlines. Or at least that's my rationalization.",
  "id" : 636410250711728129,
  "in_reply_to_status_id" : 636324439093870592,
  "created_at" : "2015-08-26 05:30:02 +0000",
  "in_reply_to_screen_name" : "NazeefaFatima",
  "in_reply_to_user_id_str" : "37054704",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nazeefa",
      "screen_name" : "NazeefaFatima",
      "indices" : [ 0, 14 ],
      "id_str" : "37054704",
      "id" : 37054704
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "636322626395316224",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1140281159124, 8.753320472706601 ]
  },
  "id_str" : "636323346267938816",
  "in_reply_to_user_id" : 37054704,
  "text" : "@NazeefaFatima but first of all: good night, otherwise I won\u2019t function tomorrow. \uD83D\uDC36\uD83D\uDCA4",
  "id" : 636323346267938816,
  "in_reply_to_status_id" : 636322626395316224,
  "created_at" : "2015-08-25 23:44:42 +0000",
  "in_reply_to_screen_name" : "NazeefaFatima",
  "in_reply_to_user_id_str" : "37054704",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nazeefa",
      "screen_name" : "NazeefaFatima",
      "indices" : [ 0, 14 ],
      "id_str" : "37054704",
      "id" : 37054704
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "636322626395316224",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1140281159124, 8.753320472706601 ]
  },
  "id_str" : "636323072648286208",
  "in_reply_to_user_id" : 37054704,
  "text" : "@NazeefaFatima I feel you. Two deadlines are coming up on Friday, third one isn\u2019t that urgent so far.I\u2019ll keep my fingers crossed for yours!",
  "id" : 636323072648286208,
  "in_reply_to_status_id" : 636322626395316224,
  "created_at" : "2015-08-25 23:43:37 +0000",
  "in_reply_to_screen_name" : "NazeefaFatima",
  "in_reply_to_user_id_str" : "37054704",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11404556580322, 8.753356692856668 ]
  },
  "id_str" : "636319002164334592",
  "text" : "two drafts down, one to go\u2026",
  "id" : 636319002164334592,
  "created_at" : "2015-08-25 23:27:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11404582060295, 8.753358222498813 ]
  },
  "id_str" : "636280608508014592",
  "text" : "abstract.v4.final.asif.lol.\u00AF\\_(\u30C4)_\/\u00AF.docx",
  "id" : 636280608508014592,
  "created_at" : "2015-08-25 20:54:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 59 ],
      "url" : "http:\/\/t.co\/ID6lWuYtJB",
      "expanded_url" : "http:\/\/whatshouldwecallgradschool.tumblr.com\/post\/127566493808\/as-the-grant-submission-deadline-approaches",
      "display_url" : "whatshouldwecallgradschool.tumblr.com\/post\/127566493\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11404532321187, 8.753357312453204 ]
  },
  "id_str" : "636275931208916992",
  "text" : "basically every deadline every time. http:\/\/t.co\/ID6lWuYtJB",
  "id" : 636275931208916992,
  "created_at" : "2015-08-25 20:36:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/k7n5G6IJAI",
      "expanded_url" : "http:\/\/www.slate.com\/blogs\/quora\/2015\/08\/22\/stem_advanced_degree_what_s_it_like_to_get_a_ph_d_in_science.html",
      "display_url" : "slate.com\/blogs\/quora\/20\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11104588803473, 8.757579743887057 ]
  },
  "id_str" : "636218608662802432",
  "text" : "What it\u2019s like getting a PhD. Feels about right, except for the overly American things. http:\/\/t.co\/k7n5G6IJAI",
  "id" : 636218608662802432,
  "created_at" : "2015-08-25 16:48:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pixelrust",
      "screen_name" : "pixelrust",
      "indices" : [ 3, 13 ],
      "id_str" : "390616772",
      "id" : 390616772
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 67 ],
      "url" : "http:\/\/t.co\/6UULwPv0yU",
      "expanded_url" : "http:\/\/www.mattiebrice.com\/things-i-want-the-men-in-my-life-to-know",
      "display_url" : "mattiebrice.com\/things-i-want-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "636170592484519936",
  "text" : "RT @pixelrust: We men must talk about this. \nhttp:\/\/t.co\/6UULwPv0yU \"A conversation that's rarely had, and when it is, done in a particular\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 30, 52 ],
        "url" : "http:\/\/t.co\/6UULwPv0yU",
        "expanded_url" : "http:\/\/www.mattiebrice.com\/things-i-want-the-men-in-my-life-to-know",
        "display_url" : "mattiebrice.com\/things-i-want-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "636166914230906880",
    "text" : "We men must talk about this. \nhttp:\/\/t.co\/6UULwPv0yU \"A conversation that's rarely had, and when it is, done in a particularly divisive way\"",
    "id" : 636166914230906880,
    "created_at" : "2015-08-25 13:23:06 +0000",
    "user" : {
      "name" : "pixelrust",
      "screen_name" : "pixelrust",
      "protected" : false,
      "id_str" : "390616772",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/728016836713943040\/LSJdUU88_normal.jpg",
      "id" : 390616772,
      "verified" : false
    }
  },
  "id" : 636170592484519936,
  "created_at" : "2015-08-25 13:37:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Keith Bradnam",
      "screen_name" : "kbradnam",
      "indices" : [ 0, 9 ],
      "id_str" : "17061155",
      "id" : 17061155
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "636168631311712256",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17222710520043, 8.627615401398835 ]
  },
  "id_str" : "636168919246573569",
  "in_reply_to_user_id" : 17061155,
  "text" : "@kbradnam really hope we can all phase out cegma soonish. I just started supplying busco-results alongside to \u201Cestablish\u201D an alternative.",
  "id" : 636168919246573569,
  "in_reply_to_status_id" : 636168631311712256,
  "created_at" : "2015-08-25 13:31:04 +0000",
  "in_reply_to_screen_name" : "kbradnam",
  "in_reply_to_user_id_str" : "17061155",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Keith Bradnam",
      "screen_name" : "kbradnam",
      "indices" : [ 0, 9 ],
      "id_str" : "17061155",
      "id" : 17061155
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "636168508296957952",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17222710520043, 8.627615401398835 ]
  },
  "id_str" : "636168783485341696",
  "in_reply_to_user_id" : 17061155,
  "text" : "@kbradnam thanks, after tweeting I remember that I \u201Csolved\u201D this problem already once before. ;)",
  "id" : 636168783485341696,
  "in_reply_to_status_id" : 636168508296957952,
  "created_at" : "2015-08-25 13:30:32 +0000",
  "in_reply_to_screen_name" : "kbradnam",
  "in_reply_to_user_id_str" : "17061155",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 66 ],
      "url" : "http:\/\/t.co\/GNrqOsrVS9",
      "expanded_url" : "http:\/\/www.molecularecologist.com\/2015\/08\/another-uninterpretable-epigenetics-study\/",
      "display_url" : "molecularecologist.com\/2015\/08\/anothe\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17221551112154, 8.627622096941407 ]
  },
  "id_str" : "636165508191121408",
  "text" : "\u00ABAnother uninterpretable epigenetics study\u00BB http:\/\/t.co\/GNrqOsrVS9",
  "id" : 636165508191121408,
  "created_at" : "2015-08-25 13:17:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Keith Bradnam",
      "screen_name" : "kbradnam",
      "indices" : [ 130, 139 ],
      "id_str" : "17061155",
      "id" : 17061155
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17223085662362, 8.62760376567928 ]
  },
  "id_str" : "636149750832697344",
  "text" : "I know, we all shouldn\u2019t be using CEGMA any longer. But if you do it anyway: Remove \u201C|\u201D from the sequence-heads or it will crash. @kbradnam",
  "id" : 636149750832697344,
  "created_at" : "2015-08-25 12:14:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    }, {
      "name" : "\u24EA Gr\u24D0h\u24D0m Steel \uD83D\uDD2C\uD83C\uDF93",
      "screen_name" : "McDawg",
      "indices" : [ 10, 17 ],
      "id_str" : "12432262",
      "id" : 12432262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "636135375925301248",
  "geo" : { },
  "id_str" : "636135937278394368",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon @McDawg Bladerunner 2.0 will be about copyright infringement in the off-world colonies!",
  "id" : 636135937278394368,
  "in_reply_to_status_id" : 636135375925301248,
  "created_at" : "2015-08-25 11:20:00 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u24EA Gr\u24D0h\u24D0m Steel \uD83D\uDD2C\uD83C\uDF93",
      "screen_name" : "McDawg",
      "indices" : [ 68, 75 ],
      "id_str" : "12432262",
      "id" : 12432262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/D1liu4wmPo",
      "expanded_url" : "https:\/\/twitter.com\/earthowned\/status\/636117277562290176",
      "display_url" : "twitter.com\/earthowned\/sta\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17228075243098, 8.627618805002932 ]
  },
  "id_str" : "636129296331993088",
  "text" : "Well, who said the publishing industry wasn\u2019t forward thinking! \/HT @McDawg https:\/\/t.co\/D1liu4wmPo",
  "id" : 636129296331993088,
  "created_at" : "2015-08-25 10:53:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17222351728687, 8.627616520831342 ]
  },
  "id_str" : "636117425617027072",
  "text" : "Getting \u00ABthis paragraph is weak\u00BB as feedback is especially useful if the paragraph was written by the critic in the first place\u2026",
  "id" : 636117425617027072,
  "created_at" : "2015-08-25 10:06:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "636111201240530944",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17227110709121, 8.627569349611711 ]
  },
  "id_str" : "636112558466928640",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot size != cultural impact, once the latter attracts celebrities in addition to regular\/boring stoners it might?",
  "id" : 636112558466928640,
  "in_reply_to_status_id" : 636111201240530944,
  "created_at" : "2015-08-25 09:47:06 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 71, 77 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 66 ],
      "url" : "http:\/\/t.co\/hdZp1Hmw6M",
      "expanded_url" : "http:\/\/boingboing.net\/2015\/08\/24\/burning-man-the-musical.html",
      "display_url" : "boingboing.net\/2015\/08\/24\/bur\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17225803529276, 8.627592412706536 ]
  },
  "id_str" : "636108667956408320",
  "text" : "Burning Man: The Musical (Not a CAH answer) http:\/\/t.co\/hdZp1Hmw6M \/cc @Lobot",
  "id" : 636108667956408320,
  "created_at" : "2015-08-25 09:31:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/o4M3YkghD7",
      "expanded_url" : "http:\/\/boingboing.net\/2015\/08\/24\/lovecraft-with-adjectives-sim.html",
      "display_url" : "boingboing.net\/2015\/08\/24\/lov\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17226148325752, 8.627579565301389 ]
  },
  "id_str" : "636106459332378624",
  "text" : "Lovecraft with adjectives, similes and metaphors edited out http:\/\/t.co\/o4M3YkghD7",
  "id" : 636106459332378624,
  "created_at" : "2015-08-25 09:22:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "636088959471370240",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17226324482908, 8.62756923317536 ]
  },
  "id_str" : "636089428792975360",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot nah, esprit d\u2019escalier just got a new time horizon. ;)",
  "id" : 636089428792975360,
  "in_reply_to_status_id" : 636088959471370240,
  "created_at" : "2015-08-25 08:15:12 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "636088710879166464",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17225421026286, 8.6275857422459 ]
  },
  "id_str" : "636088825312333824",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot 4 days for a comeback? :D",
  "id" : 636088825312333824,
  "in_reply_to_status_id" : 636088710879166464,
  "created_at" : "2015-08-25 08:12:48 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722681586465, 8.62758290422665 ]
  },
  "id_str" : "636081244657352704",
  "text" : "Got 2 conference invites last night for \u00B1 same date &amp; already booked for a 3rd at the time. Can we have faster-than-light travel already?",
  "id" : 636081244657352704,
  "created_at" : "2015-08-25 07:42:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael R. Crusoe",
      "screen_name" : "biocrusoe",
      "indices" : [ 0, 10 ],
      "id_str" : "17645638",
      "id" : 17645638
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "635840726236925953",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0609657681082, 8.818399831660853 ]
  },
  "id_str" : "635970291957661696",
  "in_reply_to_user_id" : 17645638,
  "text" : "@biocrusoe yes, it\u2019s so different from my experiences in many aspects!",
  "id" : 635970291957661696,
  "in_reply_to_status_id" : 635840726236925953,
  "created_at" : "2015-08-25 00:21:48 +0000",
  "in_reply_to_screen_name" : "biocrusoe",
  "in_reply_to_user_id_str" : "17645638",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/tAn3wsYokE",
      "expanded_url" : "https:\/\/www.goodreads.com\/book\/show\/19040435-ludwig-wittgenstein",
      "display_url" : "goodreads.com\/book\/show\/1904\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11404628304498, 8.753359705088062 ]
  },
  "id_str" : "635906207069433856",
  "text" : "A bit baffled by how much this book teaches me about Wittgenstein\u2019s masturbation habits. https:\/\/t.co\/tAn3wsYokE",
  "id" : 635906207069433856,
  "created_at" : "2015-08-24 20:07:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "A Queer Has No Name",
      "screen_name" : "memeticsexgod",
      "indices" : [ 0, 14 ],
      "id_str" : "1451060280",
      "id" : 1451060280
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "635904852468568064",
  "geo" : { },
  "id_str" : "635905638753824768",
  "in_reply_to_user_id" : 1451060280,
  "text" : "@memeticsexgod someone will be in for a surprise! the city that always sleeps :3",
  "id" : 635905638753824768,
  "in_reply_to_status_id" : 635904852468568064,
  "created_at" : "2015-08-24 20:04:53 +0000",
  "in_reply_to_screen_name" : "memeticsexgod",
  "in_reply_to_user_id_str" : "1451060280",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/E83QqxPRt5",
      "expanded_url" : "https:\/\/apply.refline.ch\/673277\/0393\/pub\/1\/index.html",
      "display_url" : "apply.refline.ch\/673277\/0393\/pu\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11404505764322, 8.753360764599414 ]
  },
  "id_str" : "635892370232508416",
  "text" : "To the evo-bioinf crowd: friend of mine has an open PhD position on the genomics of rapid adaptation in Switzerland. https:\/\/t.co\/E83QqxPRt5",
  "id" : 635892370232508416,
  "created_at" : "2015-08-24 19:12:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "not best practice",
      "screen_name" : "moeffju",
      "indices" : [ 0, 8 ],
      "id_str" : "5618832",
      "id" : 5618832
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "asif",
      "indices" : [ 63, 68 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "635874098267209728",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11404506537879, 8.753363409857455 ]
  },
  "id_str" : "635875514369052672",
  "in_reply_to_user_id" : 5618832,
  "text" : "@moeffju \u2018cool guy, never forgot his password, not even once!\u2019 #asif",
  "id" : 635875514369052672,
  "in_reply_to_status_id" : 635874098267209728,
  "created_at" : "2015-08-24 18:05:11 +0000",
  "in_reply_to_screen_name" : "moeffju",
  "in_reply_to_user_id_str" : "5618832",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17226411526897, 8.627591051522563 ]
  },
  "id_str" : "635851539215740932",
  "text" : "\u00ABDid you get feedback on the abstract?\u00BB\u2013\u00ABYes, let me read it to you.\u00BB\u2013\u00ABOof, sounds like \u2018do it again\u2019 would have been equally good feedback\u00BB",
  "id" : 635851539215740932,
  "created_at" : "2015-08-24 16:29:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "635835127793381376",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17224555090111, 8.627608838136524 ]
  },
  "id_str" : "635835294324011009",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich ich h\u00E4tte jetzt noch mehr \u00FCber die Zyklopen erz\u00E4hlen k\u00F6nnen! \uD83D\uDC33\u25C9",
  "id" : 635835294324011009,
  "in_reply_to_status_id" : 635835127793381376,
  "created_at" : "2015-08-24 15:25:22 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "635833957616107521",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17224555090111, 8.627608838136524 ]
  },
  "id_str" : "635834826071900160",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich ich h\u00E4tte wieder was von Walpenisknochen fabuliert :D",
  "id" : 635834826071900160,
  "in_reply_to_status_id" : 635833957616107521,
  "created_at" : "2015-08-24 15:23:30 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "635832792555913217",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17223326779494, 8.62761979884161 ]
  },
  "id_str" : "635833471412367361",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich und diesmal bin ich nicht eingeladen! shocking! :D",
  "id" : 635833471412367361,
  "in_reply_to_status_id" : 635832792555913217,
  "created_at" : "2015-08-24 15:18:07 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Feminist Frequency",
      "screen_name" : "femfreq",
      "indices" : [ 3, 11 ],
      "id_str" : "56768257",
      "id" : 56768257
    }, {
      "name" : "(((Jonathan\uD83C\uDF39Mann)))",
      "screen_name" : "songadaymann",
      "indices" : [ 39, 52 ],
      "id_str" : "8632762",
      "id" : 8632762
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/EU1x6yV014",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=MLCDgQNnTB0",
      "display_url" : "youtube.com\/watch?v=MLCDgQ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "635825225926578176",
  "text" : "RT @femfreq: Watch this great video by @songadaymann about marriage and feminism https:\/\/t.co\/EU1x6yV014",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "(((Jonathan\uD83C\uDF39Mann)))",
        "screen_name" : "songadaymann",
        "indices" : [ 26, 39 ],
        "id_str" : "8632762",
        "id" : 8632762
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 68, 91 ],
        "url" : "https:\/\/t.co\/EU1x6yV014",
        "expanded_url" : "https:\/\/www.youtube.com\/watch?v=MLCDgQNnTB0",
        "display_url" : "youtube.com\/watch?v=MLCDgQ\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "631614066943889408",
    "text" : "Watch this great video by @songadaymann about marriage and feminism https:\/\/t.co\/EU1x6yV014",
    "id" : 631614066943889408,
    "created_at" : "2015-08-12 23:51:43 +0000",
    "user" : {
      "name" : "Feminist Frequency",
      "screen_name" : "femfreq",
      "protected" : false,
      "id_str" : "56768257",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/673657652837134336\/cJYFPbgZ_normal.png",
      "id" : 56768257,
      "verified" : true
    }
  },
  "id" : 635825225926578176,
  "created_at" : "2015-08-24 14:45:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Mulley",
      "screen_name" : "JohnMulley",
      "indices" : [ 33, 44 ],
      "id_str" : "115010550",
      "id" : 115010550
    }, {
      "name" : "Oxford Nanopore",
      "screen_name" : "nanopore",
      "indices" : [ 86, 95 ],
      "id_str" : "37732219",
      "id" : 37732219
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/IKcZTLvZkk",
      "expanded_url" : "http:\/\/wp.me\/p6nI6X-5t",
      "display_url" : "wp.me\/p6nI6X-5t"
    } ]
  },
  "geo" : { },
  "id_str" : "635808244187955200",
  "text" : "RT @dinopmcmahon: Great stuff by @JohnMulley: Snake venom gland cDNA sequencing using @nanopore tech http:\/\/t.co\/IKcZTLvZkk",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "John Mulley",
        "screen_name" : "JohnMulley",
        "indices" : [ 15, 26 ],
        "id_str" : "115010550",
        "id" : 115010550
      }, {
        "name" : "Oxford Nanopore",
        "screen_name" : "nanopore",
        "indices" : [ 68, 77 ],
        "id_str" : "37732219",
        "id" : 37732219
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 83, 105 ],
        "url" : "http:\/\/t.co\/IKcZTLvZkk",
        "expanded_url" : "http:\/\/wp.me\/p6nI6X-5t",
        "display_url" : "wp.me\/p6nI6X-5t"
      } ]
    },
    "geo" : { },
    "id_str" : "635788555332263936",
    "text" : "Great stuff by @JohnMulley: Snake venom gland cDNA sequencing using @nanopore tech http:\/\/t.co\/IKcZTLvZkk",
    "id" : 635788555332263936,
    "created_at" : "2015-08-24 12:19:38 +0000",
    "user" : {
      "name" : "Dino McMahon",
      "screen_name" : "strepsipterman",
      "protected" : false,
      "id_str" : "2800773981",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/518141839971344384\/_7jEkXh-_normal.jpeg",
      "id" : 2800773981,
      "verified" : false
    }
  },
  "id" : 635808244187955200,
  "created_at" : "2015-08-24 13:37:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 49 ],
      "url" : "http:\/\/t.co\/b2tTkSfdeG",
      "expanded_url" : "http:\/\/blogs.plos.org\/publichealth\/2015\/08\/24\/the-narrative-of-privilege\/",
      "display_url" : "blogs.plos.org\/publichealth\/2\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17224132859473, 8.627598151118889 ]
  },
  "id_str" : "635804784080064513",
  "text" : "The Narrative of Privilege http:\/\/t.co\/b2tTkSfdeG",
  "id" : 635804784080064513,
  "created_at" : "2015-08-24 13:24:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LGBTQ+ STEM",
      "screen_name" : "LGBTSTEM",
      "indices" : [ 3, 12 ],
      "id_str" : "2442015493",
      "id" : 2442015493
    }, {
      "name" : "christopher schmitt",
      "screen_name" : "fuzzyatelin",
      "indices" : [ 71, 83 ],
      "id_str" : "824000078",
      "id" : 824000078
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/G8288CTIBC",
      "expanded_url" : "https:\/\/lgbtstem.wordpress.com\/2015\/08\/24\/an-interview-with-christopher-a-schmitt\/",
      "display_url" : "lgbtstem.wordpress.com\/2015\/08\/24\/an-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "635796038423564288",
  "text" : "RT @LGBTSTEM: We've got a great new interview with Christopher Schmitt @fuzzyatelin, Assistant Prof at Boston U. https:\/\/t.co\/G8288CTIBC #L\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "christopher schmitt",
        "screen_name" : "fuzzyatelin",
        "indices" : [ 57, 69 ],
        "id_str" : "824000078",
        "id" : 824000078
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "LGBTSTEM",
        "indices" : [ 123, 132 ]
      } ],
      "urls" : [ {
        "indices" : [ 99, 122 ],
        "url" : "https:\/\/t.co\/G8288CTIBC",
        "expanded_url" : "https:\/\/lgbtstem.wordpress.com\/2015\/08\/24\/an-interview-with-christopher-a-schmitt\/",
        "display_url" : "lgbtstem.wordpress.com\/2015\/08\/24\/an-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "635762098493071360",
    "text" : "We've got a great new interview with Christopher Schmitt @fuzzyatelin, Assistant Prof at Boston U. https:\/\/t.co\/G8288CTIBC #LGBTSTEM",
    "id" : 635762098493071360,
    "created_at" : "2015-08-24 10:34:30 +0000",
    "user" : {
      "name" : "LGBTQ+ STEM",
      "screen_name" : "LGBTSTEM",
      "protected" : false,
      "id_str" : "2442015493",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/685082380223295488\/XGTcyfxo_normal.jpg",
      "id" : 2442015493,
      "verified" : false
    }
  },
  "id" : 635796038423564288,
  "created_at" : "2015-08-24 12:49:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Akshat Rathi",
      "screen_name" : "AkshatRathi",
      "indices" : [ 0, 12 ],
      "id_str" : "13766492",
      "id" : 13766492
    }, {
      "name" : "Luc Henry",
      "screen_name" : "heluc",
      "indices" : [ 13, 19 ],
      "id_str" : "850645992",
      "id" : 850645992
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "635791400878120960",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17222492207889, 8.62761696099811 ]
  },
  "id_str" : "635792830221434880",
  "in_reply_to_user_id" : 13766492,
  "text" : "@AkshatRathi @heluc cool, would love to meet &amp; catch up, after we missed in Frankfurt the last time.",
  "id" : 635792830221434880,
  "in_reply_to_status_id" : 635791400878120960,
  "created_at" : "2015-08-24 12:36:37 +0000",
  "in_reply_to_screen_name" : "AkshatRathi",
  "in_reply_to_user_id_str" : "13766492",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/uPLSMGMyZj",
      "expanded_url" : "http:\/\/liftconference.com\/lift-basel-15",
      "display_url" : "liftconference.com\/lift-basel-15"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17219048251241, 8.627665938854769 ]
  },
  "id_str" : "635792229790011392",
  "text" : "So, if you happen to be around in\/near Switzerland at 29\/30th of October: I\u2019ll be speaking at Lift. http:\/\/t.co\/uPLSMGMyZj",
  "id" : 635792229790011392,
  "created_at" : "2015-08-24 12:34:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luc Henry",
      "screen_name" : "heluc",
      "indices" : [ 0, 6 ],
      "id_str" : "850645992",
      "id" : 850645992
    }, {
      "name" : "Akshat Rathi",
      "screen_name" : "AkshatRathi",
      "indices" : [ 7, 19 ],
      "id_str" : "13766492",
      "id" : 13766492
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "635787948512968704",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17224191824216, 8.627605416802092 ]
  },
  "id_str" : "635788976612339712",
  "in_reply_to_user_id" : 850645992,
  "text" : "@heluc @AkshatRathi oh, and my speaker bio is up. thanks! :)",
  "id" : 635788976612339712,
  "in_reply_to_status_id" : 635787948512968704,
  "created_at" : "2015-08-24 12:21:19 +0000",
  "in_reply_to_screen_name" : "heluc",
  "in_reply_to_user_id_str" : "850645992",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luc Henry",
      "screen_name" : "heluc",
      "indices" : [ 0, 6 ],
      "id_str" : "850645992",
      "id" : 850645992
    }, {
      "name" : "Akshat Rathi",
      "screen_name" : "AkshatRathi",
      "indices" : [ 11, 23 ],
      "id_str" : "13766492",
      "id" : 13766492
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17224815772848, 8.627594929559159 ]
  },
  "id_str" : "635787701871116288",
  "in_reply_to_user_id" : 850645992,
  "text" : "@heluc oh, @AkshatRathi and I covered the Lindau Nobel Laureate Meetings some years back. 2010 I think. :-)",
  "id" : 635787701871116288,
  "created_at" : "2015-08-24 12:16:15 +0000",
  "in_reply_to_screen_name" : "heluc",
  "in_reply_to_user_id_str" : "850645992",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Akshat Rathi",
      "screen_name" : "AkshatRathi",
      "indices" : [ 0, 12 ],
      "id_str" : "13766492",
      "id" : 13766492
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "635785725162704896",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17224815772848, 8.627594929559159 ]
  },
  "id_str" : "635785874580574208",
  "in_reply_to_user_id" : 13766492,
  "text" : "@AkshatRathi thanks, well written in any case, just thought might make a nice addition :-)",
  "id" : 635785874580574208,
  "in_reply_to_status_id" : 635785725162704896,
  "created_at" : "2015-08-24 12:08:59 +0000",
  "in_reply_to_screen_name" : "AkshatRathi",
  "in_reply_to_user_id_str" : "13766492",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 7, 30 ],
      "url" : "https:\/\/t.co\/Q8uXAivJbc",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=pohDhVeS4L4",
      "display_url" : "youtube.com\/watch?v=pohDhV\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "635783487082078208",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17222529406614, 8.627628545118991 ]
  },
  "id_str" : "635784797537873921",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot https:\/\/t.co\/Q8uXAivJbc",
  "id" : 635784797537873921,
  "in_reply_to_status_id" : 635783487082078208,
  "created_at" : "2015-08-24 12:04:42 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Akshat Rathi",
      "screen_name" : "AkshatRathi",
      "indices" : [ 0, 12 ],
      "id_str" : "13766492",
      "id" : 13766492
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "635784143566184448",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17221625786897, 8.627629371024886 ]
  },
  "id_str" : "635784286138953728",
  "in_reply_to_user_id" : 13766492,
  "text" : "@AkshatRathi yes, and at least in my Twitter timeline this seems to have been the general conclusion. :)",
  "id" : 635784286138953728,
  "in_reply_to_status_id" : 635784143566184448,
  "created_at" : "2015-08-24 12:02:40 +0000",
  "in_reply_to_screen_name" : "AkshatRathi",
  "in_reply_to_user_id_str" : "13766492",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/b3SmFAzKeW",
      "expanded_url" : "https:\/\/twitter.com\/middleclassprob\/status\/635375876058779648",
      "display_url" : "twitter.com\/middleclasspro\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17225237523242, 8.62759893454002 ]
  },
  "id_str" : "635780251105292288",
  "text" : "On the other hand: If you\u2019re a bit clumsy and worry about your organ integrity, we recommend not slicing at home. https:\/\/t.co\/b3SmFAzKeW",
  "id" : 635780251105292288,
  "created_at" : "2015-08-24 11:46:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Akshat Rathi",
      "screen_name" : "AkshatRathi",
      "indices" : [ 0, 12 ],
      "id_str" : "13766492",
      "id" : 13766492
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/G3QTweJq9z",
      "expanded_url" : "http:\/\/epgntxeinstein.tumblr.com\/post\/127416455028\/over-interpreted-epigenetics-study-of-the-week",
      "display_url" : "epgntxeinstein.tumblr.com\/post\/127416455\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17226800104378, 8.62757647981822 ]
  },
  "id_str" : "635777785424965633",
  "in_reply_to_user_id" : 13766492,
  "text" : "@AkshatRathi did you see http:\/\/t.co\/G3QTweJq9z ? :)",
  "id" : 635777785424965633,
  "created_at" : "2015-08-24 11:36:50 +0000",
  "in_reply_to_screen_name" : "AkshatRathi",
  "in_reply_to_user_id_str" : "13766492",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/sU0awu2UtK",
      "expanded_url" : "https:\/\/events.ccc.de\/2015\/08\/21\/towards-a-greener-cccamp\/",
      "display_url" : "events.ccc.de\/2015\/08\/21\/tow\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722185444305, 8.627624506623988 ]
  },
  "id_str" : "635774730558140416",
  "text" : "\u00ABWe doubt you can\u2019t find a way to annoy everyone around you with loud 90ies techno without a wall plug socket.\u00BB https:\/\/t.co\/sU0awu2UtK",
  "id" : 635774730558140416,
  "created_at" : "2015-08-24 11:24:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/zOmTFJn0bA",
      "expanded_url" : "http:\/\/boingboing.net\/2015\/08\/24\/sploot-seagull-poop-game.html",
      "display_url" : "boingboing.net\/2015\/08\/24\/spl\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17215652329028, 8.62767628208126 ]
  },
  "id_str" : "635755864616529920",
  "text" : "this is the one big use case that so far was missing for wide VR adoption: \u00ABPoop on everyone as a beautiful seagull\u00BB http:\/\/t.co\/zOmTFJn0bA",
  "id" : 635755864616529920,
  "created_at" : "2015-08-24 10:09:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laura Schneider",
      "screen_name" : "alauraschneider",
      "indices" : [ 3, 19 ],
      "id_str" : "988539692",
      "id" : 988539692
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Weissach",
      "indices" : [ 124, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "635735666190602240",
  "text" : "RT @alauraschneider: After a weekend of anti-refugee riots another future refugee housing was set on fire in Germany today. #Weissach http:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/alauraschneider\/status\/635713184565985280\/photo\/1",
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/sh2cucrXXy",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CNKBxa8WgAEzxCo.jpg",
        "id_str" : "635713183458689025",
        "id" : 635713183458689025,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CNKBxa8WgAEzxCo.jpg",
        "sizes" : [ {
          "h" : 291,
          "resize" : "fit",
          "w" : 540
        }, {
          "h" : 291,
          "resize" : "fit",
          "w" : 540
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 291,
          "resize" : "fit",
          "w" : 540
        }, {
          "h" : 291,
          "resize" : "fit",
          "w" : 540
        } ],
        "display_url" : "pic.twitter.com\/sh2cucrXXy"
      } ],
      "hashtags" : [ {
        "text" : "Weissach",
        "indices" : [ 103, 112 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "635713184565985280",
    "text" : "After a weekend of anti-refugee riots another future refugee housing was set on fire in Germany today. #Weissach http:\/\/t.co\/sh2cucrXXy",
    "id" : 635713184565985280,
    "created_at" : "2015-08-24 07:20:08 +0000",
    "user" : {
      "name" : "Laura Schneider",
      "screen_name" : "alauraschneider",
      "protected" : false,
      "id_str" : "988539692",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/669919587580923906\/mMZv0zX9_normal.jpg",
      "id" : 988539692,
      "verified" : false
    }
  },
  "id" : 635735666190602240,
  "created_at" : "2015-08-24 08:49:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    }, {
      "name" : "Sebastian Greiner",
      "screen_name" : "Seb666",
      "indices" : [ 10, 17 ],
      "id_str" : "2365333778",
      "id" : 2365333778
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 18, 24 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "635732417559547904",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17223909530985, 8.627599977284468 ]
  },
  "id_str" : "635734003925020672",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich @Seb666 @Lobot in meiner Jugend war das die Standardprozedur um Dinge zu claimen: if you like it, lick it.",
  "id" : 635734003925020672,
  "in_reply_to_status_id" : 635732417559547904,
  "created_at" : "2015-08-24 08:42:52 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 7, 30 ],
      "url" : "https:\/\/t.co\/4ysmDqHb36",
      "expanded_url" : "https:\/\/instagram.com\/p\/6wn2zFhwh4\/",
      "display_url" : "instagram.com\/p\/6wn2zFhwh4\/"
    } ]
  },
  "geo" : { },
  "id_str" : "635733207669993472",
  "text" : "Blocks https:\/\/t.co\/4ysmDqHb36",
  "id" : 635733207669993472,
  "created_at" : "2015-08-24 08:39:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sebastian Greiner",
      "screen_name" : "Seb666",
      "indices" : [ 0, 7 ],
      "id_str" : "2365333778",
      "id" : 2365333778
    }, {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 8, 17 ],
      "id_str" : "371189071",
      "id" : 371189071
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 18, 24 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "635731845032841217",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17227367811517, 8.627577376825693 ]
  },
  "id_str" : "635732209454960640",
  "in_reply_to_user_id" : 2365333778,
  "text" : "@Seb666 @JP_Stich @Lobot meine Autokorrektur sagt es heisst \u201Cgeleckt\u201D.",
  "id" : 635732209454960640,
  "in_reply_to_status_id" : 635731845032841217,
  "created_at" : "2015-08-24 08:35:44 +0000",
  "in_reply_to_screen_name" : "Seb666",
  "in_reply_to_user_id_str" : "2365333778",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/yakExtrLOl",
      "expanded_url" : "http:\/\/sineof1.github.io\/fraction_magnitudes.html",
      "display_url" : "sineof1.github.io\/fraction_magni\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17227706464264, 8.627575365711412 ]
  },
  "id_str" : "635725388992352256",
  "text" : "Fractions: \u00ABAre You Smarter Than a Belgian 8th Grader?\u00BB http:\/\/t.co\/yakExtrLOl",
  "id" : 635725388992352256,
  "created_at" : "2015-08-24 08:08:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 58 ],
      "url" : "http:\/\/t.co\/hB2YtX9awA",
      "expanded_url" : "http:\/\/xkcd.com\/1568\/",
      "display_url" : "xkcd.com\/1568\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17226806277326, 8.627579010504299 ]
  },
  "id_str" : "635711875725029376",
  "text" : "Professor Whip is in another movie. http:\/\/t.co\/hB2YtX9awA",
  "id" : 635711875725029376,
  "created_at" : "2015-08-24 07:14:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "635578522518470656",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11404427138392, 8.753358558460253 ]
  },
  "id_str" : "635580393350152192",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez crying for the QS remake of \u2018the man who knew too much\u2019 is indeed getting rather tedious by now.",
  "id" : 635580393350152192,
  "in_reply_to_status_id" : 635578522518470656,
  "created_at" : "2015-08-23 22:32:28 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "635576770368897024",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1140456401384, 8.753359495381353 ]
  },
  "id_str" : "635577755191668736",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez \u00ABDid you know that \u2018the dose makes the poison\u2019 is a common adage! But can you apply it to too many topics?\u00BB",
  "id" : 635577755191668736,
  "in_reply_to_status_id" : 635576770368897024,
  "created_at" : "2015-08-23 22:21:59 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erin McKiern\u24D0n",
      "screen_name" : "emckiernan13",
      "indices" : [ 3, 16 ],
      "id_str" : "404442001",
      "id" : 404442001
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "openscience",
      "indices" : [ 115, 127 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/FfLXZckc72",
      "expanded_url" : "http:\/\/www.gigasciencejournal.com\/content\/4\/1\/31",
      "display_url" : "gigasciencejournal.com\/content\/4\/1\/31"
    } ]
  },
  "geo" : { },
  "id_str" : "635564497353207808",
  "text" : "RT @emckiernan13: Four aspects to make science open \u201Cby design\u201D and not as an after-thought http:\/\/t.co\/FfLXZckc72 #openscience",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "openscience",
        "indices" : [ 97, 109 ]
      } ],
      "urls" : [ {
        "indices" : [ 74, 96 ],
        "url" : "http:\/\/t.co\/FfLXZckc72",
        "expanded_url" : "http:\/\/www.gigasciencejournal.com\/content\/4\/1\/31",
        "display_url" : "gigasciencejournal.com\/content\/4\/1\/31"
      } ]
    },
    "geo" : { },
    "id_str" : "633366048541052928",
    "text" : "Four aspects to make science open \u201Cby design\u201D and not as an after-thought http:\/\/t.co\/FfLXZckc72 #openscience",
    "id" : 633366048541052928,
    "created_at" : "2015-08-17 19:53:28 +0000",
    "user" : {
      "name" : "Erin McKiern\u24D0n",
      "screen_name" : "emckiernan13",
      "protected" : false,
      "id_str" : "404442001",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/696004367640449024\/9-eZl3Dr_normal.jpg",
      "id" : 404442001,
      "verified" : false
    }
  },
  "id" : 635564497353207808,
  "created_at" : "2015-08-23 21:29:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/MzPZdgDN0B",
      "expanded_url" : "http:\/\/www.theglobeandmail.com\/life\/relationships\/tinder-gluttony-has-stoked-apathy-and-callousness-in-dating\/article26039023\/",
      "display_url" : "theglobeandmail.com\/life\/relations\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11404357121565, 8.75335747200603 ]
  },
  "id_str" : "635557206470078464",
  "text" : "On breadth-first searching in online dating: \u00ABSadly, most people never make it out to the alpaca farm\u00BB http:\/\/t.co\/MzPZdgDN0B",
  "id" : 635557206470078464,
  "created_at" : "2015-08-23 21:00:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "slippery stairs",
      "screen_name" : "nichtschubsen",
      "indices" : [ 3, 17 ],
      "id_str" : "1012814924",
      "id" : 1012814924
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/nichtschubsen\/status\/635517648462303237\/photo\/1",
      "indices" : [ 48, 70 ],
      "url" : "http:\/\/t.co\/CGZ2Dzd8sb",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CNHP7Y0WEAA0WMg.jpg",
      "id_str" : "635517641617182720",
      "id" : 635517641617182720,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CNHP7Y0WEAA0WMg.jpg",
      "sizes" : [ {
        "h" : 829,
        "resize" : "fit",
        "w" : 720
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 829,
        "resize" : "fit",
        "w" : 720
      }, {
        "h" : 829,
        "resize" : "fit",
        "w" : 720
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 591
      } ],
      "display_url" : "pic.twitter.com\/CGZ2Dzd8sb"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/v3sttpkxCF",
      "expanded_url" : "http:\/\/www.counterpunch.org\/2015\/08\/14\/the-refugees-are-coming\/",
      "display_url" : "counterpunch.org\/2015\/08\/14\/the\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "635532393177292801",
  "text" : "RT @nichtschubsen: This. http:\/\/t.co\/v3sttpkxCF http:\/\/t.co\/CGZ2Dzd8sb",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/nichtschubsen\/status\/635517648462303237\/photo\/1",
        "indices" : [ 29, 51 ],
        "url" : "http:\/\/t.co\/CGZ2Dzd8sb",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CNHP7Y0WEAA0WMg.jpg",
        "id_str" : "635517641617182720",
        "id" : 635517641617182720,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CNHP7Y0WEAA0WMg.jpg",
        "sizes" : [ {
          "h" : 829,
          "resize" : "fit",
          "w" : 720
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 829,
          "resize" : "fit",
          "w" : 720
        }, {
          "h" : 829,
          "resize" : "fit",
          "w" : 720
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 591
        } ],
        "display_url" : "pic.twitter.com\/CGZ2Dzd8sb"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 6, 28 ],
        "url" : "http:\/\/t.co\/v3sttpkxCF",
        "expanded_url" : "http:\/\/www.counterpunch.org\/2015\/08\/14\/the-refugees-are-coming\/",
        "display_url" : "counterpunch.org\/2015\/08\/14\/the\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "635517648462303237",
    "text" : "This. http:\/\/t.co\/v3sttpkxCF http:\/\/t.co\/CGZ2Dzd8sb",
    "id" : 635517648462303237,
    "created_at" : "2015-08-23 18:23:09 +0000",
    "user" : {
      "name" : "slippery stairs",
      "screen_name" : "nichtschubsen",
      "protected" : false,
      "id_str" : "1012814924",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/677964651540455426\/gXxZoNp4_normal.jpg",
      "id" : 1012814924,
      "verified" : false
    }
  },
  "id" : 635532393177292801,
  "created_at" : "2015-08-23 19:21:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "635516087031959552",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11408338374869, 8.753370554454248 ]
  },
  "id_str" : "635519076450869248",
  "in_reply_to_user_id" : 14286491,
  "text" : "I always (naively) assumed that written check-in with security on weekends had some purpose. Today the guard asked me what that list is for\u2026",
  "id" : 635519076450869248,
  "in_reply_to_status_id" : 635516087031959552,
  "created_at" : "2015-08-23 18:28:49 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11109919798894, 8.757579044544247 ]
  },
  "id_str" : "635516087031959552",
  "text" : "\u00ABWhy are you in the office, all dressed up?!\u00BB\u2014\u00ABBecause it\u2019s Sunday! But let me ask: why are you half-naked?!\u00BB\u2014\u00ABBecause, uh, it\u2019s Sunday?\u00BB",
  "id" : 635516087031959552,
  "created_at" : "2015-08-23 18:16:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "beau",
      "screen_name" : "beaugunderson",
      "indices" : [ 0, 14 ],
      "id_str" : "5746882",
      "id" : 5746882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 64 ],
      "url" : "https:\/\/t.co\/n7eIB9OaVj",
      "expanded_url" : "https:\/\/xkcd.com\/1053\/",
      "display_url" : "xkcd.com\/1053\/"
    } ]
  },
  "in_reply_to_status_id_str" : "635513856538742785",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1110997914448, 8.756484463501534 ]
  },
  "id_str" : "635514609273831424",
  "in_reply_to_user_id" : 5746882,
  "text" : "@beaugunderson before the snark sets in: https:\/\/t.co\/n7eIB9OaVj",
  "id" : 635514609273831424,
  "in_reply_to_status_id" : 635513856538742785,
  "created_at" : "2015-08-23 18:11:04 +0000",
  "in_reply_to_screen_name" : "beaugunderson",
  "in_reply_to_user_id_str" : "5746882",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Chin",
      "screen_name" : "infoecho",
      "indices" : [ 3, 12 ],
      "id_str" : "29575969",
      "id" : 29575969
    }, {
      "name" : "Homolog.us",
      "screen_name" : "homolog_us",
      "indices" : [ 27, 38 ],
      "id_str" : "290298526",
      "id" : 290298526
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/R3yS4jLG1u",
      "expanded_url" : "http:\/\/www.homolog.us\/blogs\/blog\/2015\/08\/19\/achilles-heel-of-big-data-science\/",
      "display_url" : "homolog.us\/blogs\/blog\/201\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "635501369508630529",
  "text" : "RT @infoecho: Well said by @homolog_us, \"Achilles Heel of \u2018Big Data\u2019 Science\" http:\/\/t.co\/R3yS4jLG1u",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Homolog.us",
        "screen_name" : "homolog_us",
        "indices" : [ 13, 24 ],
        "id_str" : "290298526",
        "id" : 290298526
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 64, 86 ],
        "url" : "http:\/\/t.co\/R3yS4jLG1u",
        "expanded_url" : "http:\/\/www.homolog.us\/blogs\/blog\/2015\/08\/19\/achilles-heel-of-big-data-science\/",
        "display_url" : "homolog.us\/blogs\/blog\/201\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "635501052679208961",
    "text" : "Well said by @homolog_us, \"Achilles Heel of \u2018Big Data\u2019 Science\" http:\/\/t.co\/R3yS4jLG1u",
    "id" : 635501052679208961,
    "created_at" : "2015-08-23 17:17:12 +0000",
    "user" : {
      "name" : "Jason Chin",
      "screen_name" : "infoecho",
      "protected" : false,
      "id_str" : "29575969",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1355717194\/image_normal.jpg",
      "id" : 29575969,
      "verified" : false
    }
  },
  "id" : 635501369508630529,
  "created_at" : "2015-08-23 17:18:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan (((Graur)))",
      "screen_name" : "DanGraur",
      "indices" : [ 3, 12 ],
      "id_str" : "1205345400",
      "id" : 1205345400
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "635494372369395712",
  "text" : "RT @DanGraur: The story of a first-generation student like me. The worst thing was not even knowing what you don\u2019t know. http:\/\/t.co\/Wqtqsj\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 107, 129 ],
        "url" : "http:\/\/t.co\/WqtqsjGrRn",
        "expanded_url" : "http:\/\/nyti.ms\/1PsySSf",
        "display_url" : "nyti.ms\/1PsySSf"
      } ]
    },
    "geo" : { },
    "id_str" : "635489637478195200",
    "text" : "The story of a first-generation student like me. The worst thing was not even knowing what you don\u2019t know. http:\/\/t.co\/WqtqsjGrRn",
    "id" : 635489637478195200,
    "created_at" : "2015-08-23 16:31:51 +0000",
    "user" : {
      "name" : "Dan (((Graur)))",
      "screen_name" : "DanGraur",
      "protected" : false,
      "id_str" : "1205345400",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/822591216776835072\/IO7mOPZQ_normal.jpg",
      "id" : 1205345400,
      "verified" : false
    }
  },
  "id" : 635494372369395712,
  "created_at" : "2015-08-23 16:50:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "herr_schrat",
      "screen_name" : "herr_schrat",
      "indices" : [ 0, 12 ],
      "id_str" : "16066591",
      "id" : 16066591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "635449951024226304",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11408663279386, 8.753379204753168 ]
  },
  "id_str" : "635455852003074048",
  "in_reply_to_user_id" : 16066591,
  "text" : "@herr_schrat Achso, na dann los. Zieht ihr m\u00E4chtigen Schlacht-Enten.",
  "id" : 635455852003074048,
  "in_reply_to_status_id" : 635449951024226304,
  "created_at" : "2015-08-23 14:17:35 +0000",
  "in_reply_to_screen_name" : "herr_schrat",
  "in_reply_to_user_id_str" : "16066591",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "herr_schrat",
      "screen_name" : "herr_schrat",
      "indices" : [ 0, 12 ],
      "id_str" : "16066591",
      "id" : 16066591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "635449182057287680",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17224098794429, 8.627608052404206 ]
  },
  "id_str" : "635449723533565952",
  "in_reply_to_user_id" : 16066591,
  "text" : "@herr_schrat die schaffen aber vermutlich keine 17t lift? :D",
  "id" : 635449723533565952,
  "in_reply_to_status_id" : 635449182057287680,
  "created_at" : "2015-08-23 13:53:14 +0000",
  "in_reply_to_screen_name" : "herr_schrat",
  "in_reply_to_user_id_str" : "16066591",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "herr_schrat",
      "screen_name" : "herr_schrat",
      "indices" : [ 0, 12 ],
      "id_str" : "16066591",
      "id" : 16066591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "635447836855914496",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17224098794429, 8.627608052404206 ]
  },
  "id_str" : "635448997596033024",
  "in_reply_to_user_id" : 16066591,
  "text" : "@herr_schrat du brauchst vielleicht mehr als zwei davon. Aber i\u2019m not a motorboating expert.",
  "id" : 635448997596033024,
  "in_reply_to_status_id" : 635447836855914496,
  "created_at" : "2015-08-23 13:50:21 +0000",
  "in_reply_to_screen_name" : "herr_schrat",
  "in_reply_to_user_id_str" : "16066591",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 31 ],
      "url" : "http:\/\/t.co\/9CfMdBEOkD",
      "expanded_url" : "http:\/\/www.smbc-comics.com\/index.php?id=3836",
      "display_url" : "smbc-comics.com\/index.php?id=3\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17224215317867, 8.627597836070528 ]
  },
  "id_str" : "635447392398123008",
  "text" : "smugness http:\/\/t.co\/9CfMdBEOkD",
  "id" : 635447392398123008,
  "created_at" : "2015-08-23 13:43:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 40 ],
      "url" : "http:\/\/t.co\/TFR7wCOp2V",
      "expanded_url" : "http:\/\/whatshouldwecallgradschool.tumblr.com\/post\/127271311281\/that-one-professor-in-the-department-who-gets-on",
      "display_url" : "whatshouldwecallgradschool.tumblr.com\/post\/127271311\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17225010584921, 8.627599530177612 ]
  },
  "id_str" : "635446260443516928",
  "text" : "full steam ahead\u2026 http:\/\/t.co\/TFR7wCOp2V",
  "id" : 635446260443516928,
  "created_at" : "2015-08-23 13:39:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Rupert",
      "screen_name" : "Meowdip",
      "indices" : [ 3, 11 ],
      "id_str" : "48883029",
      "id" : 48883029
    }, {
      "name" : "Real Vegan Cheese",
      "screen_name" : "realvegancheez",
      "indices" : [ 53, 68 ],
      "id_str" : "2588711785",
      "id" : 2588711785
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CCCamp15",
      "indices" : [ 40, 49 ]
    } ],
    "urls" : [ {
      "indices" : [ 69, 92 ],
      "url" : "https:\/\/t.co\/Q6bGhUqWv5",
      "expanded_url" : "https:\/\/media.ccc.de\/browse\/conferences\/camp2015\/camp2015-6702-real_vegan_cheese.html#video&t=15",
      "display_url" : "media.ccc.de\/browse\/confere\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "635066844047654913",
  "text" : "RT @Meowdip: Here is the talk I gave at #CCCamp15 on @realvegancheez https:\/\/t.co\/Q6bGhUqWv5 I've been told it's a good talk, can't watch m\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Real Vegan Cheese",
        "screen_name" : "realvegancheez",
        "indices" : [ 40, 55 ],
        "id_str" : "2588711785",
        "id" : 2588711785
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CCCamp15",
        "indices" : [ 27, 36 ]
      } ],
      "urls" : [ {
        "indices" : [ 56, 79 ],
        "url" : "https:\/\/t.co\/Q6bGhUqWv5",
        "expanded_url" : "https:\/\/media.ccc.de\/browse\/conferences\/camp2015\/camp2015-6702-real_vegan_cheese.html#video&t=15",
        "display_url" : "media.ccc.de\/browse\/confere\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "634901744133124096",
    "text" : "Here is the talk I gave at #CCCamp15 on @realvegancheez https:\/\/t.co\/Q6bGhUqWv5 I've been told it's a good talk, can't watch myself",
    "id" : 634901744133124096,
    "created_at" : "2015-08-22 01:35:46 +0000",
    "user" : {
      "name" : "Ben Rupert",
      "screen_name" : "Meowdip",
      "protected" : false,
      "id_str" : "48883029",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/590752486815838208\/j87LIlVT_normal.jpg",
      "id" : 48883029,
      "verified" : false
    }
  },
  "id" : 635066844047654913,
  "created_at" : "2015-08-22 12:31:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "635016420926062592",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.43721557133872, 8.69520287030255 ]
  },
  "id_str" : "635016848535363584",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot I read large enough a sample of the war diaries to know that only Corollas and donkeys make decent car bombs.",
  "id" : 635016848535363584,
  "in_reply_to_status_id" : 635016420926062592,
  "created_at" : "2015-08-22 09:13:09 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "635015501584957440",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.47974882652096, 8.706778027125361 ]
  },
  "id_str" : "635015873254825984",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot with?",
  "id" : 635015873254825984,
  "in_reply_to_status_id" : 635015501584957440,
  "created_at" : "2015-08-22 09:09:16 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "635014239913160705",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.52904690074013, 8.619525556340502 ]
  },
  "id_str" : "635015223641042944",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot if I were you I\u2019d tweet the same. ;) but you\u2019ll understand that I was in no position to be sure of that at the time. :D",
  "id" : 635015223641042944,
  "in_reply_to_status_id" : 635014239913160705,
  "created_at" : "2015-08-22 09:06:41 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TheConstructor",
      "screen_name" : "TheConstructor",
      "indices" : [ 0, 15 ],
      "id_str" : "14362840",
      "id" : 14362840
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "635014032165105664",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.56197056085855, 8.55594609864853 ]
  },
  "id_str" : "635014858442977281",
  "in_reply_to_user_id" : 14362840,
  "text" : "@TheConstructor interesting, still not too interested in fighting it in court. All I lost now are 10 minutes of my life. Law suits take more",
  "id" : 635014858442977281,
  "in_reply_to_status_id" : 635014032165105664,
  "created_at" : "2015-08-22 09:05:14 +0000",
  "in_reply_to_screen_name" : "TheConstructor",
  "in_reply_to_user_id_str" : "14362840",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "635012852613533696",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.56197056085855, 8.55594609864853 ]
  },
  "id_str" : "635014408205410304",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot I did and told them how their colleagues busted me a year ago (with the same neg. result)",
  "id" : 635014408205410304,
  "in_reply_to_status_id" : 635012852613533696,
  "created_at" : "2015-08-22 09:03:27 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "635012796321767424",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.56197056085855, 8.55594609864853 ]
  },
  "id_str" : "635014028373413888",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot nope, but this time I was much more at ease. As it was my guaranteed drug-free car and not yours. :D",
  "id" : 635014028373413888,
  "in_reply_to_status_id" : 635012796321767424,
  "created_at" : "2015-08-22 09:01:57 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TheConstructor",
      "screen_name" : "TheConstructor",
      "indices" : [ 0, 15 ],
      "id_str" : "14362840",
      "id" : 14362840
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "635012545431126016",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.56249539372563, 8.554021278404216 ]
  },
  "id_str" : "635013759266856960",
  "in_reply_to_user_id" : 14362840,
  "text" : "@TheConstructor one of them even confirmed when I asked whether it\u2019s the combination of a worn-down car and my looks. But in court \u2026",
  "id" : 635013759266856960,
  "in_reply_to_status_id" : 635012545431126016,
  "created_at" : "2015-08-22 09:00:52 +0000",
  "in_reply_to_screen_name" : "TheConstructor",
  "in_reply_to_user_id_str" : "14362840",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.72515200828269, 8.280496811501942 ]
  },
  "id_str" : "635009297836044289",
  "text" : "Guess who was again just \u2018randomly\u2019 pulled over by the drug squad\u2026",
  "id" : 635009297836044289,
  "created_at" : "2015-08-22 08:43:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Richard Edwards",
      "screen_name" : "cabbagesofdoom",
      "indices" : [ 3, 18 ],
      "id_str" : "326344080",
      "id" : 326344080
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/NnJrG9leAW",
      "expanded_url" : "http:\/\/cabbagesofdoom.blogspot.com\/2015\/08\/bioinformatics-is-just-like-bench.html?spref=tw",
      "display_url" : "cabbagesofdoom.blogspot.com\/2015\/08\/bioinf\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "634859006448812032",
  "text" : "RT @cabbagesofdoom: The Cabbages of Doom: Bioinformatics is just like bench science and should be treated as such http:\/\/t.co\/NnJrG9leAW",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 94, 116 ],
        "url" : "http:\/\/t.co\/NnJrG9leAW",
        "expanded_url" : "http:\/\/cabbagesofdoom.blogspot.com\/2015\/08\/bioinformatics-is-just-like-bench.html?spref=tw",
        "display_url" : "cabbagesofdoom.blogspot.com\/2015\/08\/bioinf\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "634709143589294080",
    "text" : "The Cabbages of Doom: Bioinformatics is just like bench science and should be treated as such http:\/\/t.co\/NnJrG9leAW",
    "id" : 634709143589294080,
    "created_at" : "2015-08-21 12:50:26 +0000",
    "user" : {
      "name" : "Richard Edwards",
      "screen_name" : "cabbagesofdoom",
      "protected" : false,
      "id_str" : "326344080",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/699496160965169152\/yeW0Mmre_normal.jpg",
      "id" : 326344080,
      "verified" : false
    }
  },
  "id" : 634859006448812032,
  "created_at" : "2015-08-21 22:45:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kit Stubbs, Ph.D.",
      "screen_name" : "vortacist",
      "indices" : [ 3, 13 ],
      "id_str" : "347340056",
      "id" : 347340056
    }, {
      "name" : "Edie Kleinman",
      "screen_name" : "EKleinman",
      "indices" : [ 104, 114 ],
      "id_str" : "884457082384154625",
      "id" : 884457082384154625
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "634857994870726656",
  "text" : "RT @vortacist: \"it\u2019s my job to hold the space for my child to express her gender however she wants to\": @ekleinman is my hero &lt;3 https:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Edie Kleinman",
        "screen_name" : "EKleinman",
        "indices" : [ 89, 99 ],
        "id_str" : "884457082384154625",
        "id" : 884457082384154625
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/NrZ5E1N2jA",
        "expanded_url" : "https:\/\/twitter.com\/Longreads\/status\/634383404935593984",
        "display_url" : "twitter.com\/Longreads\/stat\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "634855569963159552",
    "text" : "\"it\u2019s my job to hold the space for my child to express her gender however she wants to\": @ekleinman is my hero &lt;3 https:\/\/t.co\/NrZ5E1N2jA",
    "id" : 634855569963159552,
    "created_at" : "2015-08-21 22:32:17 +0000",
    "user" : {
      "name" : "Kit Stubbs, Ph.D.",
      "screen_name" : "vortacist",
      "protected" : false,
      "id_str" : "347340056",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/819220259148177408\/UYT71cyh_normal.jpg",
      "id" : 347340056,
      "verified" : false
    }
  },
  "id" : 634857994870726656,
  "created_at" : "2015-08-21 22:41:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "634849231895928832",
  "text" : "Russell on Wittgenstein: \u00ABI said he was mad &amp; he said God preserve him from sanity. (God certainly will.)\u00BB",
  "id" : 634849231895928832,
  "created_at" : "2015-08-21 22:07:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lena Schimmel",
      "screen_name" : "LenaSchimmel",
      "indices" : [ 0, 13 ],
      "id_str" : "547537624",
      "id" : 547537624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "634843996062400512",
  "geo" : { },
  "id_str" : "634844543519735812",
  "in_reply_to_user_id" : 547537624,
  "text" : "@LenaSchimmel Ich dr\u00FCck die Daumen, mich hat es gleich am Montag Abend\/Dienstag erwischt.",
  "id" : 634844543519735812,
  "in_reply_to_status_id" : 634843996062400512,
  "created_at" : "2015-08-21 21:48:28 +0000",
  "in_reply_to_screen_name" : "LenaSchimmel",
  "in_reply_to_user_id_str" : "547537624",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lena Schimmel",
      "screen_name" : "LenaSchimmel",
      "indices" : [ 0, 13 ],
      "id_str" : "547537624",
      "id" : 547537624
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cccamp15",
      "indices" : [ 47, 56 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "634841776956772353",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.49982077827031, 7.488447668935848 ]
  },
  "id_str" : "634842488264486912",
  "in_reply_to_user_id" : 547537624,
  "text" : "@LenaSchimmel gute Besserung, mich hat es post-#cccamp15 auch erwischt.",
  "id" : 634842488264486912,
  "in_reply_to_status_id" : 634841776956772353,
  "created_at" : "2015-08-21 21:40:18 +0000",
  "in_reply_to_screen_name" : "LenaSchimmel",
  "in_reply_to_user_id_str" : "547537624",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leon \uD83C\uDFF3\uFE0F\u200D\uD83C\uDF08\uD83C\uDF3F\uD83D\uDD2C",
      "screen_name" : "orchidhunter",
      "indices" : [ 0, 13 ],
      "id_str" : "21607925",
      "id" : 21607925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "634818528487473152",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.49987312969891, 7.488613408065856 ]
  },
  "id_str" : "634824745410777088",
  "in_reply_to_user_id" : 21607925,
  "text" : "@orchidhunter yes.",
  "id" : 634824745410777088,
  "in_reply_to_status_id" : 634818528487473152,
  "created_at" : "2015-08-21 20:29:48 +0000",
  "in_reply_to_screen_name" : "orchidhunter",
  "in_reply_to_user_id_str" : "21607925",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kollektiv Raufaser",
      "screen_name" : "insideX",
      "indices" : [ 0, 8 ],
      "id_str" : "14857351",
      "id" : 14857351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "634822461683539969",
  "geo" : { },
  "id_str" : "634822726243479552",
  "in_reply_to_user_id" : 14857351,
  "text" : "@insideX leider nein :(",
  "id" : 634822726243479552,
  "in_reply_to_status_id" : 634822461683539969,
  "created_at" : "2015-08-21 20:21:47 +0000",
  "in_reply_to_screen_name" : "insideX",
  "in_reply_to_user_id_str" : "14857351",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 35 ],
      "url" : "https:\/\/t.co\/6cleBHuyOt",
      "expanded_url" : "https:\/\/instagram.com\/p\/6qJAGZBwl8\/",
      "display_url" : "instagram.com\/p\/6qJAGZBwl8\/"
    } ]
  },
  "geo" : { },
  "id_str" : "634820932180287488",
  "text" : "Unimpressed https:\/\/t.co\/6cleBHuyOt",
  "id" : 634820932180287488,
  "created_at" : "2015-08-21 20:14:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 71 ],
      "url" : "https:\/\/t.co\/xZH7m5YnqQ",
      "expanded_url" : "https:\/\/instagram.com\/p\/6qG--ohwiI\/",
      "display_url" : "instagram.com\/p\/6qG--ohwiI\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.816410531, 7.587958262 ]
  },
  "id_str" : "634816496330493952",
  "text" : "blowing for 25 years and counting @ M\u00FCnsterland https:\/\/t.co\/xZH7m5YnqQ",
  "id" : 634816496330493952,
  "created_at" : "2015-08-21 19:57:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/634804708771803137\/photo\/1",
      "indices" : [ 41, 63 ],
      "url" : "http:\/\/t.co\/EDw9q0xH7Y",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CM9HhOhWIAAzSOz.jpg",
      "id_str" : "634804708641742848",
      "id" : 634804708641742848,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CM9HhOhWIAAzSOz.jpg",
      "sizes" : [ {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      }, {
        "h" : 1134,
        "resize" : "fit",
        "w" : 851
      }, {
        "h" : 1134,
        "resize" : "fit",
        "w" : 851
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1134,
        "resize" : "fit",
        "w" : 851
      } ],
      "display_url" : "pic.twitter.com\/EDw9q0xH7Y"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "634804708771803137",
  "text" : "It's the small things that give it away. http:\/\/t.co\/EDw9q0xH7Y",
  "id" : 634804708771803137,
  "created_at" : "2015-08-21 19:10:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "634801925091913728",
  "text" : "Funerals (or any family gatherings for that matter): the ideal place to figure out who taught you your toxic behavioral routines by example.",
  "id" : 634801925091913728,
  "created_at" : "2015-08-21 18:59:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.81695446374075, 7.588695818882068 ]
  },
  "id_str" : "634762766470021120",
  "text" : "\u00ABDo you want to take a copy of the death notice?\u00BB \u2014 \u00ABSure, in case the drug squad stops me again on my way back.\u00BB",
  "id" : 634762766470021120,
  "created_at" : "2015-08-21 16:23:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 10, 16 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "634760075064815616",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.81706876701537, 7.588629651004255 ]
  },
  "id_str" : "634760394331017216",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich @Lobot Goatse, in FSK6",
  "id" : 634760394331017216,
  "in_reply_to_status_id" : 634760075064815616,
  "created_at" : "2015-08-21 16:14:05 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    }, {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 7, 16 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "634757866667286528",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.81710117501375, 7.588629378012929 ]
  },
  "id_str" : "634759464986480642",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot @JP_Stich \uD83D\uDC48\uD83C\uDF69\uD83D\uDC49?",
  "id" : 634759464986480642,
  "in_reply_to_status_id" : 634757866667286528,
  "created_at" : "2015-08-21 16:10:24 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    }, {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 7, 16 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "634757866667286528",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.81697142315266, 7.588454196236644 ]
  },
  "id_str" : "634758836398747648",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot @JP_Stich hat der Hund einen Rei\u00DFverschluss?",
  "id" : 634758836398747648,
  "in_reply_to_status_id" : 634757866667286528,
  "created_at" : "2015-08-21 16:07:54 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    }, {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 7, 16 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "634755356762185729",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.81727212711763, 7.588718394653878 ]
  },
  "id_str" : "634757507756486656",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot @JP_Stich pics or didn\u2019t happen \uD83D\uDC36",
  "id" : 634757507756486656,
  "in_reply_to_status_id" : 634755356762185729,
  "created_at" : "2015-08-21 16:02:37 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "herr_schrat",
      "screen_name" : "herr_schrat",
      "indices" : [ 0, 12 ],
      "id_str" : "16066591",
      "id" : 16066591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "634732969941422080",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.81946779782809, 7.59172178271097 ]
  },
  "id_str" : "634733667521273856",
  "in_reply_to_user_id" : 16066591,
  "text" : "@herr_schrat die FahrerInnen vom B\u00FCrgerbus in COE.",
  "id" : 634733667521273856,
  "in_reply_to_status_id" : 634732969941422080,
  "created_at" : "2015-08-21 14:27:53 +0000",
  "in_reply_to_screen_name" : "herr_schrat",
  "in_reply_to_user_id_str" : "16066591",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.81946174095199, 7.591726099568109 ]
  },
  "id_str" : "634731670072074240",
  "text" : "\u00ABDer Bundestagsabgeordnete Schiewerling hat uns nach Berlin eingeladen!\u00BB \u2014 \u00ABCool Story, sein Sohn hat mich auf sein Hausboot eingeladen.\u00BB",
  "id" : 634731670072074240,
  "created_at" : "2015-08-21 14:19:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.81924342182634, 7.587924962870392 ]
  },
  "id_str" : "634710813664788480",
  "text" : "My grandpa got a recap of his life for his funeral. My grandma got \u2018she lost her will to live after her husband died\u2019. Well played church\u2026",
  "id" : 634710813664788480,
  "created_at" : "2015-08-21 12:57:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "634700420632440832",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.81870582389831, 7.591119218335322 ]
  },
  "id_str" : "634709553108623360",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot no expert on Christian theology. But rather sure \u2018all-knowing\u2019 wasn\u2019t followed by \u2018if there\u2019s connectivity\u2019.",
  "id" : 634709553108623360,
  "in_reply_to_status_id" : 634700420632440832,
  "created_at" : "2015-08-21 12:52:04 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.81881800794328, 7.591545466391559 ]
  },
  "id_str" : "634693515855970304",
  "text" : "Nothing to show your trust in God as CCTVs in the main church room.",
  "id" : 634693515855970304,
  "created_at" : "2015-08-21 11:48:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "634667606323167232",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.81841869565576, 7.59030864168924 ]
  },
  "id_str" : "634687179902570496",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon you don\u2019t want to explode prematurely. ;)",
  "id" : 634687179902570496,
  "in_reply_to_status_id" : 634667606323167232,
  "created_at" : "2015-08-21 11:23:10 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "634660360541356032",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.93952945999196, 7.608454713207933 ]
  },
  "id_str" : "634660635553464320",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon they give testament to Toyota\u2019s build-quality in the episode :3",
  "id" : 634660635553464320,
  "in_reply_to_status_id" : 634660360541356032,
  "created_at" : "2015-08-21 09:37:41 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 39, 48 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 71 ],
      "url" : "http:\/\/t.co\/w7oXb19UY4",
      "expanded_url" : "http:\/\/m.thisamericanlife.org\/radio-archives\/episode\/561\/nummi-2015",
      "display_url" : "m.thisamericanlife.org\/radio-archives\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.37974277143495, 7.524676797918533 ]
  },
  "id_str" : "634650716058066946",
  "text" : "The TAL about NUMMI features Corollas, @Senficon http:\/\/t.co\/w7oXb19UY4",
  "id" : 634650716058066946,
  "created_at" : "2015-08-21 08:58:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 0, 9 ],
      "id_str" : "14245811",
      "id" : 14245811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "634450733551648768",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11404369483864, 8.753359349178947 ]
  },
  "id_str" : "634472052410425344",
  "in_reply_to_user_id" : 14245811,
  "text" : "@wilbanks i\u2019m in.",
  "id" : 634472052410425344,
  "in_reply_to_status_id" : 634450733551648768,
  "created_at" : "2015-08-20 21:08:19 +0000",
  "in_reply_to_screen_name" : "wilbanks",
  "in_reply_to_user_id_str" : "14245811",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bet\u00FCl Kacar",
      "screen_name" : "betulland",
      "indices" : [ 3, 13 ],
      "id_str" : "1631690197",
      "id" : 1631690197
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "634470573826048000",
  "text" : "RT @betulland: Are you a computational biologist who would work based in Tokyo? Are you interested in origins of life &amp; synthetic bio? Plea\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "634448503314345984",
    "text" : "Are you a computational biologist who would work based in Tokyo? Are you interested in origins of life &amp; synthetic bio? Please contact me!",
    "id" : 634448503314345984,
    "created_at" : "2015-08-20 19:34:45 +0000",
    "user" : {
      "name" : "Bet\u00FCl Kacar",
      "screen_name" : "betulland",
      "protected" : false,
      "id_str" : "1631690197",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/635290751312621568\/nL8d2gso_normal.jpg",
      "id" : 1631690197,
      "verified" : false
    }
  },
  "id" : 634470573826048000,
  "created_at" : "2015-08-20 21:02:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arikia\uD83D\uDCAB",
      "screen_name" : "arikia",
      "indices" : [ 0, 7 ],
      "id_str" : "71654283",
      "id" : 71654283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "634395802350264321",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.10857669223758, 8.776195797303897 ]
  },
  "id_str" : "634398681173786624",
  "in_reply_to_user_id" : 71654283,
  "text" : "@arikia congrats!",
  "id" : 634398681173786624,
  "in_reply_to_status_id" : 634395802350264321,
  "created_at" : "2015-08-20 16:16:46 +0000",
  "in_reply_to_screen_name" : "arikia",
  "in_reply_to_user_id_str" : "71654283",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Logsdon",
      "screen_name" : "johnlogsdon",
      "indices" : [ 0, 12 ],
      "id_str" : "18414364",
      "id" : 18414364
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "634377657363271680",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.114044360805, 8.753359792864067 ]
  },
  "id_str" : "634388125708603392",
  "in_reply_to_user_id" : 18414364,
  "text" : "@johnlogsdon all the best for the trip. relax and enjoy the peanuts.",
  "id" : 634388125708603392,
  "in_reply_to_status_id" : 634377657363271680,
  "created_at" : "2015-08-20 15:34:50 +0000",
  "in_reply_to_screen_name" : "johnlogsdon",
  "in_reply_to_user_id_str" : "18414364",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "634374447718232068",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.114044360805, 8.753359792864067 ]
  },
  "id_str" : "634387608441888768",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer who would have guessed!",
  "id" : 634387608441888768,
  "in_reply_to_status_id" : 634374447718232068,
  "created_at" : "2015-08-20 15:32:46 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11404422786832, 8.7533586364658 ]
  },
  "id_str" : "634387380049461248",
  "text" : "Not saying the drain was super-clogged or anything. But I needed a crowbar to open it &amp; now I feel like I destroyed a growing civilization.",
  "id" : 634387380049461248,
  "created_at" : "2015-08-20 15:31:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 0, 9 ],
      "id_str" : "14245811",
      "id" : 14245811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "634372589582950400",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11404335003327, 8.753360301279965 ]
  },
  "id_str" : "634379525804158976",
  "in_reply_to_user_id" : 14245811,
  "text" : "@wilbanks \u201Cdata sharing in health? When Hell freezes over!\u201D how you ended up in that situation?",
  "id" : 634379525804158976,
  "in_reply_to_status_id" : 634372589582950400,
  "created_at" : "2015-08-20 15:00:39 +0000",
  "in_reply_to_screen_name" : "wilbanks",
  "in_reply_to_user_id_str" : "14245811",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "634368285639839744",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11405453202575, 8.75330664464268 ]
  },
  "id_str" : "634377997479485440",
  "in_reply_to_user_id" : 1710354776,
  "text" : "@HackerFeminist I\u2019m sad to have missed that!",
  "id" : 634377997479485440,
  "in_reply_to_status_id" : 634368285639839744,
  "created_at" : "2015-08-20 14:54:35 +0000",
  "in_reply_to_screen_name" : "witchbike",
  "in_reply_to_user_id_str" : "1710354776",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cccamp15",
      "indices" : [ 4, 13 ]
    } ],
    "urls" : [ {
      "indices" : [ 69, 92 ],
      "url" : "https:\/\/t.co\/He41M0dMUb",
      "expanded_url" : "https:\/\/twitter.com\/HackerFeminist\/status\/634366600662134784",
      "display_url" : "twitter.com\/HackerFeminist\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17224228649, 8.627601202888167 ]
  },
  "id_str" : "634367706029015040",
  "text" : "Any #cccamp15 attendees who took pictures at our village that night? https:\/\/t.co\/He41M0dMUb",
  "id" : 634367706029015040,
  "created_at" : "2015-08-20 14:13:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "634351324793016320",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17222944089333, 8.627612581493073 ]
  },
  "id_str" : "634351881335275520",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot aus der Kategorie: \u201CDinge die ich st\u00E4ndig behaupte\u201D \uD83D\uDE31",
  "id" : 634351881335275520,
  "in_reply_to_status_id" : 634351324793016320,
  "created_at" : "2015-08-20 13:10:48 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "634332063861211136",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17222643252545, 8.627616366596593 ]
  },
  "id_str" : "634333947439251456",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot making selfie shticks again?",
  "id" : 634333947439251456,
  "in_reply_to_status_id" : 634332063861211136,
  "created_at" : "2015-08-20 11:59:33 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 49 ],
      "url" : "http:\/\/t.co\/hhhVr4doAQ",
      "expanded_url" : "http:\/\/nnimgt-a.akamaihd.net\/transform\/v1\/crop\/frm\/storypad-rmy2vkrzxz656XjM5Qj3XQ\/7bd19542-eb20-40c6-89a9-17f68f784d99.jpg\/r0_0_1625_914_w1200_h678_fmax.jpg",
      "display_url" : "nnimgt-a.akamaihd.net\/transform\/v1\/c\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "634330539428868096",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17223970110518, 8.627599318906546 ]
  },
  "id_str" : "634331496518656000",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot nope, i\u2019m more like http:\/\/t.co\/hhhVr4doAQ",
  "id" : 634331496518656000,
  "in_reply_to_status_id" : 634330539428868096,
  "created_at" : "2015-08-20 11:49:48 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/BwQ11DQO9X",
      "expanded_url" : "http:\/\/boingboing.net\/2015\/08\/19\/cute-hamster-in-hammock-enjoyi.html",
      "display_url" : "boingboing.net\/2015\/08\/19\/cut\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17225540907938, 8.627585725148622 ]
  },
  "id_str" : "634326809849556992",
  "text" : "living the life. now i really want to take a nap in our office-hammock too. http:\/\/t.co\/BwQ11DQO9X",
  "id" : 634326809849556992,
  "created_at" : "2015-08-20 11:31:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    }, {
      "name" : "\u03B8ourkni\u02D0r\u0325",
      "screen_name" : "thorgnyr",
      "indices" : [ 7, 16 ],
      "id_str" : "38015980",
      "id" : 38015980
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "634304401746841601",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17224275976654, 8.627608292166098 ]
  },
  "id_str" : "634305129471180800",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot @thorgnyr knock yourself out :P",
  "id" : 634305129471180800,
  "in_reply_to_status_id" : 634304401746841601,
  "created_at" : "2015-08-20 10:05:02 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u03B8ourkni\u02D0r\u0325",
      "screen_name" : "thorgnyr",
      "indices" : [ 18, 27 ],
      "id_str" : "38015980",
      "id" : 38015980
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/PvgVuEidVS",
      "expanded_url" : "http:\/\/xkcd.com\/1566\/",
      "display_url" : "xkcd.com\/1566\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17224106126512, 8.627612261938665 ]
  },
  "id_str" : "634281545499582464",
  "text" : "Maybe I can trick @thorgnyr into doing my taxes next year. http:\/\/t.co\/PvgVuEidVS",
  "id" : 634281545499582464,
  "created_at" : "2015-08-20 08:31:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 45 ],
      "url" : "https:\/\/t.co\/M28L3ZMAwe",
      "expanded_url" : "https:\/\/i1.wp.com\/rack.1.mshcdn.com\/media\/ZgkyMDEzLzA2LzEzL2E4L3NtYXNoZWRjb21wLjVkMzdhLmdpZgpwCXRodW1iCTEyMDB4OTYwMD4\/46976450\/cf5\/smashed-computer.gif",
      "display_url" : "i1.wp.com\/rack.1.mshcdn.\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17223930996889, 8.627584895152516 ]
  },
  "id_str" : "634269120649936897",
  "text" : "the internet of dings https:\/\/t.co\/M28L3ZMAwe",
  "id" : 634269120649936897,
  "created_at" : "2015-08-20 07:41:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andreas Herten",
      "screen_name" : "AndiH",
      "indices" : [ 0, 6 ],
      "id_str" : "4586881",
      "id" : 4586881
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 71 ],
      "url" : "https:\/\/t.co\/A2nJb1kPrO",
      "expanded_url" : "https:\/\/instagram.com\/p\/rFf3zxhwps\/",
      "display_url" : "instagram.com\/p\/rFf3zxhwps\/"
    } ]
  },
  "in_reply_to_status_id_str" : "634127428445732864",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11408095254714, 8.753381373316131 ]
  },
  "id_str" : "634135115669590018",
  "in_reply_to_user_id" : 4586881,
  "text" : "@AndiH I offer you a real ice bucket challenge! https:\/\/t.co\/A2nJb1kPrO \uD83D\uDE0A",
  "id" : 634135115669590018,
  "in_reply_to_status_id" : 634127428445732864,
  "created_at" : "2015-08-19 22:49:27 +0000",
  "in_reply_to_screen_name" : "AndiH",
  "in_reply_to_user_id_str" : "4586881",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cccamp15",
      "indices" : [ 42, 51 ]
    } ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/YSqaZ4hdz5",
      "expanded_url" : "http:\/\/cdn.instructables.com\/FWT\/54M9\/GUKAQWT1\/FWT54M9GUKAQWT1.MEDIUM.jpg",
      "display_url" : "cdn.instructables.com\/FWT\/54M9\/GUKAQ\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11408335049332, 8.753377416210622 ]
  },
  "id_str" : "634107946415357953",
  "text" : "More behind the scenes footage of how the #cccamp15 thunderstorm was produced. http:\/\/t.co\/YSqaZ4hdz5",
  "id" : 634107946415357953,
  "created_at" : "2015-08-19 21:01:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul-Olivier Dehaye",
      "screen_name" : "podehaye",
      "indices" : [ 123, 132 ],
      "id_str" : "2219841242",
      "id" : 2219841242
    }, {
      "name" : "ciyer",
      "screen_name" : "ciyer",
      "indices" : [ 133, 139 ],
      "id_str" : "14533425",
      "id" : 14533425
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "makeopendata",
      "indices" : [ 81, 94 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17225221617706, 8.627600722942434 ]
  },
  "id_str" : "634023966974308355",
  "text" : "Wondering what is eating up 1.X TB of storage\u2026 Figured out it is the remnants of #makeopendata Research Hackdays at ETH w\/ @podehaye @ciyer.",
  "id" : 634023966974308355,
  "created_at" : "2015-08-19 15:27:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave-Kay",
      "screen_name" : "Dave_Kay",
      "indices" : [ 0, 9 ],
      "id_str" : "10487642",
      "id" : 10487642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "634022590403727360",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17225221617706, 8.627600722942434 ]
  },
  "id_str" : "634022649073659904",
  "in_reply_to_user_id" : 10487642,
  "text" : "@Dave_Kay 0 :D",
  "id" : 634022649073659904,
  "in_reply_to_status_id" : 634022590403727360,
  "created_at" : "2015-08-19 15:22:33 +0000",
  "in_reply_to_screen_name" : "Dave_Kay",
  "in_reply_to_user_id_str" : "10487642",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 39 ],
      "url" : "http:\/\/t.co\/SNC5Xe7tZ1",
      "expanded_url" : "http:\/\/www.nytimes.com\/interactive\/2015\/08\/13\/upshot\/are-you-smarter-than-other-new-york-times-readers.html?abt=0002&abg=0",
      "display_url" : "nytimes.com\/interactive\/20\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17221558219582, 8.627622744984928 ]
  },
  "id_str" : "634020836735864832",
  "text" : "Guess my number! http:\/\/t.co\/SNC5Xe7tZ1",
  "id" : 634020836735864832,
  "created_at" : "2015-08-19 15:15:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/SyBoLZnq3w",
      "expanded_url" : "http:\/\/fivethirtyeight.com\/features\/science-isnt-broken\/",
      "display_url" : "fivethirtyeight.com\/features\/scien\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17220275809613, 8.627634017091767 ]
  },
  "id_str" : "634015958038937600",
  "text" : "\u00ABThe state of our science is strong, but it\u2019s plagued by a universal problem: Science is hard \u2014 really fucking hard.\u00BB http:\/\/t.co\/SyBoLZnq3w",
  "id" : 634015958038937600,
  "created_at" : "2015-08-19 14:55:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 141 ],
      "url" : "http:\/\/t.co\/v1JYQI1igc",
      "expanded_url" : "http:\/\/www.ipscell.com\/2015\/08\/pinker\/",
      "display_url" : "ipscell.com\/2015\/08\/pinker\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17220755239029, 8.627639859712712 ]
  },
  "id_str" : "634011742230716417",
  "text" : "\u00ABWe might say, \u201CData is king\u201D &amp; data are glaringly absent from the writings\u00A0of those promoting human genetic mods\u00BB http:\/\/t.co\/v1JYQI1igc",
  "id" : 634011742230716417,
  "created_at" : "2015-08-19 14:39:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pierre Lindenbaum",
      "screen_name" : "yokofakun",
      "indices" : [ 3, 13 ],
      "id_str" : "7431072",
      "id" : 7431072
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/N794y0CupD",
      "expanded_url" : "https:\/\/c3bi.pasteur.fr\/research-teams-apply\/",
      "display_url" : "c3bi.pasteur.fr\/research-teams\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "633990640020365312",
  "text" : "RT @yokofakun: The Institut Pasteur is hiring group leaders for its new Center of\nBioinformatics, https:\/\/t.co\/N794y0CupD",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 83, 106 ],
        "url" : "https:\/\/t.co\/N794y0CupD",
        "expanded_url" : "https:\/\/c3bi.pasteur.fr\/research-teams-apply\/",
        "display_url" : "c3bi.pasteur.fr\/research-teams\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "633988664327045120",
    "text" : "The Institut Pasteur is hiring group leaders for its new Center of\nBioinformatics, https:\/\/t.co\/N794y0CupD",
    "id" : 633988664327045120,
    "created_at" : "2015-08-19 13:07:31 +0000",
    "user" : {
      "name" : "Pierre Lindenbaum",
      "screen_name" : "yokofakun",
      "protected" : false,
      "id_str" : "7431072",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/667105051664609280\/jQ6Ile6W_normal.jpg",
      "id" : 7431072,
      "verified" : false
    }
  },
  "id" : 633990640020365312,
  "created_at" : "2015-08-19 13:15:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matus Sotak",
      "screen_name" : "biomatushiq",
      "indices" : [ 3, 15 ],
      "id_str" : "122310304",
      "id" : 122310304
    }, {
      "name" : "Splice",
      "screen_name" : "Splice_MolBio",
      "indices" : [ 81, 95 ],
      "id_str" : "3083788462",
      "id" : 3083788462
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "phdchat",
      "indices" : [ 97, 105 ]
    }, {
      "text" : "ecrchat",
      "indices" : [ 106, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/uNUScBxBAz",
      "expanded_url" : "http:\/\/bit.ly\/1Pzhbkp",
      "display_url" : "bit.ly\/1Pzhbkp"
    } ]
  },
  "geo" : { },
  "id_str" : "633986516038066177",
  "text" : "RT @biomatushiq: Are you a scientist or a researcher? http:\/\/t.co\/uNUScBxBAz (at @Splice_MolBio) #phdchat #ecrchat",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Splice",
        "screen_name" : "Splice_MolBio",
        "indices" : [ 64, 78 ],
        "id_str" : "3083788462",
        "id" : 3083788462
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "phdchat",
        "indices" : [ 80, 88 ]
      }, {
        "text" : "ecrchat",
        "indices" : [ 89, 97 ]
      } ],
      "urls" : [ {
        "indices" : [ 37, 59 ],
        "url" : "http:\/\/t.co\/uNUScBxBAz",
        "expanded_url" : "http:\/\/bit.ly\/1Pzhbkp",
        "display_url" : "bit.ly\/1Pzhbkp"
      } ]
    },
    "geo" : { },
    "id_str" : "633985782072647680",
    "text" : "Are you a scientist or a researcher? http:\/\/t.co\/uNUScBxBAz (at @Splice_MolBio) #phdchat #ecrchat",
    "id" : 633985782072647680,
    "created_at" : "2015-08-19 12:56:03 +0000",
    "user" : {
      "name" : "Matus Sotak",
      "screen_name" : "biomatushiq",
      "protected" : false,
      "id_str" : "122310304",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2481824929\/qsqbsbw5o2vhe404u7f5_normal.jpeg",
      "id" : 122310304,
      "verified" : false
    }
  },
  "id" : 633986516038066177,
  "created_at" : "2015-08-19 12:58:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    }, {
      "name" : "\u03B8ourkni\u02D0r\u0325",
      "screen_name" : "thorgnyr",
      "indices" : [ 10, 19 ],
      "id_str" : "38015980",
      "id" : 38015980
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "633968172102721536",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17226552098811, 8.627579140600139 ]
  },
  "id_str" : "633968816557555712",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon @thorgnyr speaking off: there might be some halva in one of the bags \/w kitchen utensils in the living room if you want. \uD83C\uDF70",
  "id" : 633968816557555712,
  "in_reply_to_status_id" : 633968172102721536,
  "created_at" : "2015-08-19 11:48:39 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u03B8ourkni\u02D0r\u0325",
      "screen_name" : "thorgnyr",
      "indices" : [ 0, 9 ],
      "id_str" : "38015980",
      "id" : 38015980
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 10, 19 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "633966669178798080",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17226389861244, 8.627581207943141 ]
  },
  "id_str" : "633967604294660097",
  "in_reply_to_user_id" : 38015980,
  "text" : "@thorgnyr @Senficon the best thing is how little i\u2019m judged for my deep-seated tahina-love. \uD83C\uDF31",
  "id" : 633967604294660097,
  "in_reply_to_status_id" : 633966669178798080,
  "created_at" : "2015-08-19 11:43:50 +0000",
  "in_reply_to_screen_name" : "thorgnyr",
  "in_reply_to_user_id_str" : "38015980",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "himbeerkomplott",
      "screen_name" : "raspberryperson",
      "indices" : [ 0, 16 ],
      "id_str" : "2841131495",
      "id" : 2841131495
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 17, 23 ],
      "id_str" : "1492631",
      "id" : 1492631
    }, {
      "name" : "herr_schrat",
      "screen_name" : "herr_schrat",
      "indices" : [ 52, 64 ],
      "id_str" : "16066591",
      "id" : 16066591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "633944013641502720",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17224772067159, 8.627602496391216 ]
  },
  "id_str" : "633945558307196928",
  "in_reply_to_user_id" : 2841131495,
  "text" : "@raspberryperson @Lobot das erkl\u00E4rt dann auch wieso @herr_schrat so gerne gro\u00DFe Zelte mit gro\u00DFen Masten verleiht.",
  "id" : 633945558307196928,
  "in_reply_to_status_id" : 633944013641502720,
  "created_at" : "2015-08-19 10:16:13 +0000",
  "in_reply_to_screen_name" : "raspberryperson",
  "in_reply_to_user_id_str" : "2841131495",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "himbeerkomplott",
      "screen_name" : "raspberryperson",
      "indices" : [ 0, 16 ],
      "id_str" : "2841131495",
      "id" : 2841131495
    }, {
      "name" : "herr_schrat",
      "screen_name" : "herr_schrat",
      "indices" : [ 17, 29 ],
      "id_str" : "16066591",
      "id" : 16066591
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 30, 36 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "633941367425789952",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17223777699602, 8.627603776307538 ]
  },
  "id_str" : "633942633765847040",
  "in_reply_to_user_id" : 2841131495,
  "text" : "@raspberryperson @herr_schrat @Lobot wir haben es die ganze Zeit falsch verstanden. Es sind Amphibienmenschen, nicht Echsenmenschen!",
  "id" : 633942633765847040,
  "in_reply_to_status_id" : 633941367425789952,
  "created_at" : "2015-08-19 10:04:36 +0000",
  "in_reply_to_screen_name" : "raspberryperson",
  "in_reply_to_user_id_str" : "2841131495",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "633920550310707200",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17228209677149, 8.627591564425114 ]
  },
  "id_str" : "633941559361277952",
  "in_reply_to_user_id" : 14286491,
  "text" : "\u00ABWhy are your breakpoint graphs only showing kneecaps?\u00BB",
  "id" : 633941559361277952,
  "in_reply_to_status_id" : 633920550310707200,
  "created_at" : "2015-08-19 10:00:20 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    }, {
      "name" : "himbeerkomplott",
      "screen_name" : "raspberryperson",
      "indices" : [ 7, 23 ],
      "id_str" : "2841131495",
      "id" : 2841131495
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "633940608109953024",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17228209677149, 8.627591564425114 ]
  },
  "id_str" : "633940774313439232",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot @raspberryperson Blitzeinschl\u00E4ge r\u00FCtteln auch den Dreck von der Haut!",
  "id" : 633940774313439232,
  "in_reply_to_status_id" : 633940608109953024,
  "created_at" : "2015-08-19 09:57:13 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "himbeerkomplott",
      "screen_name" : "raspberryperson",
      "indices" : [ 0, 16 ],
      "id_str" : "2841131495",
      "id" : 2841131495
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 27, 33 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "633935908891435008",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17228209677149, 8.627591564425114 ]
  },
  "id_str" : "633939616660373504",
  "in_reply_to_user_id" : 2841131495,
  "text" : "@raspberryperson genau was @Lobot &amp; ich w\u00E4hrend der Evak diskutierten: \u201Ebitte alle Seife aus den Zelten holen, gleich wird 2tes Mal Evak.\u201C",
  "id" : 633939616660373504,
  "in_reply_to_status_id" : 633935908891435008,
  "created_at" : "2015-08-19 09:52:37 +0000",
  "in_reply_to_screen_name" : "raspberryperson",
  "in_reply_to_user_id_str" : "2841131495",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "633924589421219840",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17224147529129, 8.627590908129807 ]
  },
  "id_str" : "633925690031742976",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon yes, just the idea of counting it feels philosophically repulsive to me. :D",
  "id" : 633925690031742976,
  "in_reply_to_status_id" : 633924589421219840,
  "created_at" : "2015-08-19 08:57:16 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722514257028, 8.62759866879626 ]
  },
  "id_str" : "633920550310707200",
  "text" : "By now everyone who enters the office is interrogated on whether they crashed the cluster. Probably we\u2019ll try rubber-hose IT forensics soon.",
  "id" : 633920550310707200,
  "created_at" : "2015-08-19 08:36:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GET Conference",
      "screen_name" : "attendGET",
      "indices" : [ 11, 21 ],
      "id_str" : "3349342414",
      "id" : 3349342414
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17223430038318, 8.627597227193489 ]
  },
  "id_str" : "633916268962316288",
  "text" : "Flights to @attendGET in VIE \u2708\uFE0F\u2713",
  "id" : 633916268962316288,
  "created_at" : "2015-08-19 08:19:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ali",
      "screen_name" : "zoonpolitikon",
      "indices" : [ 0, 14 ],
      "id_str" : "13040652",
      "id" : 13040652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "633905315084378112",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17229993511403, 8.627567445994181 ]
  },
  "id_str" : "633906335566966784",
  "in_reply_to_user_id" : 13040652,
  "text" : "@zoonpolitikon \u201Cdoku\u201D :D",
  "id" : 633906335566966784,
  "in_reply_to_status_id" : 633905315084378112,
  "created_at" : "2015-08-19 07:40:22 +0000",
  "in_reply_to_screen_name" : "zoonpolitikon",
  "in_reply_to_user_id_str" : "13040652",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/Vu1XtEO9YQ",
      "expanded_url" : "http:\/\/www.slate.com\/articles\/technology\/future_tense\/2015\/08\/humans_should_be_able_to_marry_robots.html",
      "display_url" : "slate.com\/articles\/techn\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17224587495972, 8.62759510779936 ]
  },
  "id_str" : "633902238881202177",
  "text" : "I hope that this suggestion &amp; line of argument will be extended to Tahina for selfish reasons http:\/\/t.co\/Vu1XtEO9YQ",
  "id" : 633902238881202177,
  "created_at" : "2015-08-19 07:24:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Torsten Seemann",
      "screen_name" : "torstenseemann",
      "indices" : [ 0, 15 ],
      "id_str" : "42558652",
      "id" : 42558652
    }, {
      "name" : "Nick Loman",
      "screen_name" : "pathogenomenick",
      "indices" : [ 16, 32 ],
      "id_str" : "85906238",
      "id" : 85906238
    }, {
      "name" : "Matt Loose",
      "screen_name" : "mattloose",
      "indices" : [ 33, 43 ],
      "id_str" : "9325082",
      "id" : 9325082
    }, {
      "name" : "Mick Watson",
      "screen_name" : "BioMickWatson",
      "indices" : [ 44, 58 ],
      "id_str" : "228586748",
      "id" : 228586748
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "633789244507619328",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11404182734416, 8.753359207313352 ]
  },
  "id_str" : "633793677660409856",
  "in_reply_to_user_id" : 42558652,
  "text" : "@torstenseemann @pathogenomenick @mattloose @BioMickWatson half the size of a Starfleet TR-580 Tricorder VII?",
  "id" : 633793677660409856,
  "in_reply_to_status_id" : 633789244507619328,
  "created_at" : "2015-08-19 00:12:42 +0000",
  "in_reply_to_screen_name" : "torstenseemann",
  "in_reply_to_user_id_str" : "42558652",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "samantha based clark",
      "screen_name" : "eltonjohn",
      "indices" : [ 0, 10 ],
      "id_str" : "15661851",
      "id" : 15661851
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "633783610429063168",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11404010501973, 8.753354567073632 ]
  },
  "id_str" : "633783658281893888",
  "in_reply_to_user_id" : 15661851,
  "text" : "@eltonjohn thanks! :)",
  "id" : 633783658281893888,
  "in_reply_to_status_id" : 633783610429063168,
  "created_at" : "2015-08-18 23:32:53 +0000",
  "in_reply_to_screen_name" : "eltonjohn",
  "in_reply_to_user_id_str" : "15661851",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11403287674759, 8.753332188234204 ]
  },
  "id_str" : "633739961410306049",
  "text" : "good news. turns out i\u2019m not the one who crashed the queue system.",
  "id" : 633739961410306049,
  "created_at" : "2015-08-18 20:39:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Denker",
      "screen_name" : "Phaidr0s",
      "indices" : [ 0, 9 ],
      "id_str" : "40466433",
      "id" : 40466433
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "633710802072113152",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11404566962653, 8.753365756426495 ]
  },
  "id_str" : "633712002083483648",
  "in_reply_to_user_id" : 40466433,
  "text" : "@Phaidr0s ich will doch f\u00E4hige Betreuung bekommen :3",
  "id" : 633712002083483648,
  "in_reply_to_status_id" : 633710802072113152,
  "created_at" : "2015-08-18 18:48:09 +0000",
  "in_reply_to_screen_name" : "Phaidr0s",
  "in_reply_to_user_id_str" : "40466433",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/TPK4jTwg5n",
      "expanded_url" : "http:\/\/www.biomedcentral.com\/1471-2148\/15\/164",
      "display_url" : "biomedcentral.com\/1471-2148\/15\/1\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11404560166291, 8.753366827551282 ]
  },
  "id_str" : "633710879113146368",
  "text" : "writing this paper took longer than most of my relationships last(ed), but it\u2019s finally out\u2026 http:\/\/t.co\/TPK4jTwg5n",
  "id" : 633710879113146368,
  "created_at" : "2015-08-18 18:43:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Denker",
      "screen_name" : "Phaidr0s",
      "indices" : [ 0, 9 ],
      "id_str" : "40466433",
      "id" : 40466433
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "633709965581119489",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11404560166291, 8.753366827551282 ]
  },
  "id_str" : "633710367986855940",
  "in_reply_to_user_id" : 40466433,
  "text" : "@Phaidr0s dann wohl nicht in Darmstadt ;)",
  "id" : 633710367986855940,
  "in_reply_to_status_id" : 633709965581119489,
  "created_at" : "2015-08-18 18:41:40 +0000",
  "in_reply_to_screen_name" : "Phaidr0s",
  "in_reply_to_user_id_str" : "40466433",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Denker",
      "screen_name" : "Phaidr0s",
      "indices" : [ 0, 9 ],
      "id_str" : "40466433",
      "id" : 40466433
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "633709587863109634",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11404574475126, 8.753365713900344 ]
  },
  "id_str" : "633709820953149441",
  "in_reply_to_user_id" : 40466433,
  "text" : "@Phaidr0s h\u00E4ltst du dich ran und wirst dann mein Doktorvater? :D",
  "id" : 633709820953149441,
  "in_reply_to_status_id" : 633709587863109634,
  "created_at" : "2015-08-18 18:39:29 +0000",
  "in_reply_to_screen_name" : "Phaidr0s",
  "in_reply_to_user_id_str" : "40466433",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Denker",
      "screen_name" : "Phaidr0s",
      "indices" : [ 0, 9 ],
      "id_str" : "40466433",
      "id" : 40466433
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "633709360238170112",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11404574475126, 8.753365713900344 ]
  },
  "id_str" : "633709508628492288",
  "in_reply_to_user_id" : 40466433,
  "text" : "@Phaidr0s ich \u00FCberlege einen PhD in Ph zu machen, reicht das f\u00FCr die Absolution?",
  "id" : 633709508628492288,
  "in_reply_to_status_id" : 633709360238170112,
  "created_at" : "2015-08-18 18:38:15 +0000",
  "in_reply_to_screen_name" : "Phaidr0s",
  "in_reply_to_user_id_str" : "40466433",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Denker",
      "screen_name" : "Phaidr0s",
      "indices" : [ 0, 9 ],
      "id_str" : "40466433",
      "id" : 40466433
    }, {
      "name" : "Jonas",
      "screen_name" : "lsanoj",
      "indices" : [ 10, 17 ],
      "id_str" : "18918915",
      "id" : 18918915
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "633708868212772864",
  "geo" : { },
  "id_str" : "633709225705926656",
  "in_reply_to_user_id" : 40466433,
  "text" : "@Phaidr0s @lsanoj womit haben wir das verdient?",
  "id" : 633709225705926656,
  "in_reply_to_status_id" : 633708868212772864,
  "created_at" : "2015-08-18 18:37:07 +0000",
  "in_reply_to_screen_name" : "Phaidr0s",
  "in_reply_to_user_id_str" : "40466433",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonas",
      "screen_name" : "lsanoj",
      "indices" : [ 0, 7 ],
      "id_str" : "18918915",
      "id" : 18918915
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "633706091445153792",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11406215984761, 8.753286805657941 ]
  },
  "id_str" : "633708657377705985",
  "in_reply_to_user_id" : 18918915,
  "text" : "@lsanoj danke, ich weine mich deshalb auch oft in den Schlaf :(",
  "id" : 633708657377705985,
  "in_reply_to_status_id" : 633706091445153792,
  "created_at" : "2015-08-18 18:34:52 +0000",
  "in_reply_to_screen_name" : "lsanoj",
  "in_reply_to_user_id_str" : "18918915",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "punycode",
      "screen_name" : "punycode",
      "indices" : [ 0, 9 ],
      "id_str" : "14328131",
      "id" : 14328131
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "633677217730555904",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17223551282942, 8.627592344112365 ]
  },
  "id_str" : "633678405591035904",
  "in_reply_to_user_id" : 14328131,
  "text" : "@punycode After-Muskelkater kann schon sehr unangenehm sein! \u2738\uD83D\uDE05",
  "id" : 633678405591035904,
  "in_reply_to_status_id" : 633677217730555904,
  "created_at" : "2015-08-18 16:34:39 +0000",
  "in_reply_to_screen_name" : "punycode",
  "in_reply_to_user_id_str" : "14328131",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cccamp15",
      "indices" : [ 10, 19 ]
    } ],
    "urls" : [ {
      "indices" : [ 20, 43 ],
      "url" : "https:\/\/t.co\/vDJz99TfM0",
      "expanded_url" : "https:\/\/instagram.com\/p\/6hae4QBwmg\/",
      "display_url" : "instagram.com\/p\/6hae4QBwmg\/"
    } ]
  },
  "geo" : { },
  "id_str" : "633592735715475456",
  "text" : "Organized #cccamp15 https:\/\/t.co\/vDJz99TfM0",
  "id" : 633592735715475456,
  "created_at" : "2015-08-18 10:54:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/1xaPe0nfkb",
      "expanded_url" : "http:\/\/www.open-bio.org\/wiki\/Main_Page",
      "display_url" : "open-bio.org\/wiki\/Main_Page"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17223417707133, 8.627610590929859 ]
  },
  "id_str" : "633577340182900736",
  "text" : "Looks like I became a member of the Open Bioinformatics Foundation \\o\/ http:\/\/t.co\/1xaPe0nfkb",
  "id" : 633577340182900736,
  "created_at" : "2015-08-18 09:53:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "punycode",
      "screen_name" : "punycode",
      "indices" : [ 0, 9 ],
      "id_str" : "14328131",
      "id" : 14328131
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "633546021725990912",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17227166520882, 8.627573972268138 ]
  },
  "id_str" : "633546206774456320",
  "in_reply_to_user_id" : 14328131,
  "text" : "@punycode more like accidentally while trying to disassemble a still shining wall-lamp. :D",
  "id" : 633546206774456320,
  "in_reply_to_status_id" : 633546021725990912,
  "created_at" : "2015-08-18 07:49:21 +0000",
  "in_reply_to_screen_name" : "punycode",
  "in_reply_to_user_id_str" : "14328131",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "punycode",
      "screen_name" : "punycode",
      "indices" : [ 0, 9 ],
      "id_str" : "14328131",
      "id" : 14328131
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "633543633321488384",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722714799967, 8.627577462980726 ]
  },
  "id_str" : "633544000633499648",
  "in_reply_to_user_id" : 14328131,
  "text" : "@punycode the last time I tried to electrocute myself was when moving out of my old apartment :P",
  "id" : 633544000633499648,
  "in_reply_to_status_id" : 633543633321488384,
  "created_at" : "2015-08-18 07:40:35 +0000",
  "in_reply_to_screen_name" : "punycode",
  "in_reply_to_user_id_str" : "14328131",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17224268819557, 8.627596798384397 ]
  },
  "id_str" : "633542838551187456",
  "text" : "Just being out of office for 10 days and the first people suspect I was killed in an explosion in China.",
  "id" : 633542838551187456,
  "created_at" : "2015-08-18 07:35:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katha",
      "screen_name" : "kathakatze",
      "indices" : [ 0, 11 ],
      "id_str" : "541170257",
      "id" : 541170257
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "633411519729016832",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11388042566232, 8.753376527712696 ]
  },
  "id_str" : "633419551871475712",
  "in_reply_to_user_id" : 541170257,
  "text" : "@kathakatze entlich keine entlosen M\u00F6glichkeiten mehr!",
  "id" : 633419551871475712,
  "in_reply_to_status_id" : 633411519729016832,
  "created_at" : "2015-08-17 23:26:04 +0000",
  "in_reply_to_screen_name" : "kathakatze",
  "in_reply_to_user_id_str" : "541170257",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katha",
      "screen_name" : "kathakatze",
      "indices" : [ 0, 11 ],
      "id_str" : "541170257",
      "id" : 541170257
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 34 ],
      "url" : "http:\/\/t.co\/Xw0F2RgHAH",
      "expanded_url" : "http:\/\/quackbutton.com\/",
      "display_url" : "quackbutton.com"
    } ]
  },
  "in_reply_to_status_id_str" : "633397880129212417",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11402946616329, 8.753304178816933 ]
  },
  "id_str" : "633401838612647936",
  "in_reply_to_user_id" : 541170257,
  "text" : "@kathakatze http:\/\/t.co\/Xw0F2RgHAH",
  "id" : 633401838612647936,
  "in_reply_to_status_id" : 633397880129212417,
  "created_at" : "2015-08-17 22:15:41 +0000",
  "in_reply_to_screen_name" : "kathakatze",
  "in_reply_to_user_id_str" : "541170257",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 86 ],
      "url" : "https:\/\/t.co\/ntjySiPqCi",
      "expanded_url" : "https:\/\/liorpachter.wordpress.com\/2015\/08\/14\/in-biology-n-does-not-go-to-infinity\/",
      "display_url" : "liorpachter.wordpress.com\/2015\/08\/14\/in-\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11402257021756, 8.753305343014102 ]
  },
  "id_str" : "633378718367514625",
  "text" : "to infinity \u2026 and not beyond \u2026 actually, not even to infinity. https:\/\/t.co\/ntjySiPqCi",
  "id" : 633378718367514625,
  "created_at" : "2015-08-17 20:43:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/psEIa5iXir",
      "expanded_url" : "https:\/\/twitter.com\/glyn_dk\/status\/633356054554873856",
      "display_url" : "twitter.com\/glyn_dk\/status\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.114015000176, 8.75328323450623 ]
  },
  "id_str" : "633372208530915328",
  "text" : "\u00ABA standard question on any early dinner date should be quite simply: \u2018And how are you mad?\u2019\u00BB https:\/\/t.co\/psEIa5iXir",
  "id" : 633372208530915328,
  "created_at" : "2015-08-17 20:17:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 78 ],
      "url" : "https:\/\/t.co\/FUUCoo6v8J",
      "expanded_url" : "https:\/\/youtu.be\/rlBskd3IaNw",
      "display_url" : "youtu.be\/rlBskd3IaNw"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11404096636979, 8.753339752197178 ]
  },
  "id_str" : "633371097757556736",
  "text" : "\u00ABhow to write an Alt-J song\u00BB Will have to try this out https:\/\/t.co\/FUUCoo6v8J",
  "id" : 633371097757556736,
  "created_at" : "2015-08-17 20:13:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cccamp15",
      "indices" : [ 29, 38 ]
    } ],
    "urls" : [ {
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/s8dy3aRxjb",
      "expanded_url" : "http:\/\/www.lagatayelbuho.com\/web\/OJOGATO\/jinetes01.jpg",
      "display_url" : "lagatayelbuho.com\/web\/OJOGATO\/ji\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11115021933126, 8.757946923041464 ]
  },
  "id_str" : "633355364428288000",
  "text" : "Slowly secret footage of the #cccamp15 thunderstorm emerges. http:\/\/t.co\/s8dy3aRxjb",
  "id" : 633355364428288000,
  "created_at" : "2015-08-17 19:11:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cccamp15",
      "indices" : [ 9, 18 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11121125420196, 8.757850247719555 ]
  },
  "id_str" : "633354325260136448",
  "text" : "Home \uD83D\uDE97\u26FA\uFE0F #cccamp15",
  "id" : 633354325260136448,
  "created_at" : "2015-08-17 19:06:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Theresa",
      "screen_name" : "NerdResa",
      "indices" : [ 29, 38 ],
      "id_str" : "279159266",
      "id" : 279159266
    }, {
      "name" : "Lena Schimmel",
      "screen_name" : "LenaSchimmel",
      "indices" : [ 40, 53 ],
      "id_str" : "547537624",
      "id" : 547537624
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cccamp15",
      "indices" : [ 8, 17 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.03247387999619, 13.31186306949667 ]
  },
  "id_str" : "633246551427551233",
  "text" : "Goodbye #cccamp15. Thanks to @NerdResa, @LenaSchimmel et al. for organizing the QueerFeministGeeks Village!",
  "id" : 633246551427551233,
  "created_at" : "2015-08-17 11:58:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "C3 CERT",
      "screen_name" : "c3cert",
      "indices" : [ 0, 7 ],
      "id_str" : "2965827591",
      "id" : 2965827591
    }, {
      "name" : "Fabian",
      "screen_name" : "Sico93",
      "indices" : [ 8, 15 ],
      "id_str" : "45335295",
      "id" : 45335295
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "633242327415431168",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.03277276461295, 13.3101106993978 ]
  },
  "id_str" : "633242879700410368",
  "in_reply_to_user_id" : 2965827591,
  "text" : "@c3cert @Sico93 danke f\u00FCr eure tolle Arbeit. Keep up the good job. :)",
  "id" : 633242879700410368,
  "in_reply_to_status_id" : 633242327415431168,
  "created_at" : "2015-08-17 11:44:02 +0000",
  "in_reply_to_screen_name" : "c3cert",
  "in_reply_to_user_id_str" : "2965827591",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "C3 CERT",
      "screen_name" : "c3cert",
      "indices" : [ 0, 7 ],
      "id_str" : "2965827591",
      "id" : 2965827591
    }, {
      "name" : "Fabian",
      "screen_name" : "Sico93",
      "indices" : [ 8, 15 ],
      "id_str" : "45335295",
      "id" : 45335295
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 65 ],
      "url" : "https:\/\/t.co\/z59xVPeJlD",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/633019294272630784",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "633242327415431168",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.03285012957922, 13.31014414319145 ]
  },
  "id_str" : "633242804500742144",
  "in_reply_to_user_id" : 2965827591,
  "text" : "@c3cert @Sico93 alles gut. Der Mensch aus https:\/\/t.co\/z59xVPeJlD machte nur ein Wortspiel \u00FCber seine nicht-Evakuierung. :)",
  "id" : 633242804500742144,
  "in_reply_to_status_id" : 633242327415431168,
  "created_at" : "2015-08-17 11:43:44 +0000",
  "in_reply_to_screen_name" : "c3cert",
  "in_reply_to_user_id_str" : "2965827591",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cccamp15",
      "indices" : [ 60, 69 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.03167994855021, 13.30859187475295 ]
  },
  "id_str" : "633212561824026624",
  "text" : "\u00ABDas CERT hat mich gar nicht certlich aus dem Zelt geCERT!\u00BB #cccamp15",
  "id" : 633212561824026624,
  "created_at" : "2015-08-17 09:43:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "hukl",
      "screen_name" : "hukl",
      "indices" : [ 0, 5 ],
      "id_str" : "14842853",
      "id" : 14842853
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 6, 29 ],
      "url" : "https:\/\/t.co\/zVA7eTQGB0",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/632979078501507073",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    }, {
      "indices" : [ 34, 57 ],
      "url" : "https:\/\/t.co\/DMV3O8gyrT",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/632217725788659712",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "632915633051709441",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.03047809484259, 13.30391413492511 ]
  },
  "id_str" : "633049006621507584",
  "in_reply_to_user_id" : 14842853,
  "text" : "@hukl https:\/\/t.co\/zVA7eTQGB0 and https:\/\/t.co\/DMV3O8gyrT",
  "id" : 633049006621507584,
  "in_reply_to_status_id" : 632915633051709441,
  "created_at" : "2015-08-16 22:53:39 +0000",
  "in_reply_to_screen_name" : "hukl",
  "in_reply_to_user_id_str" : "14842853",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cccamp15",
      "indices" : [ 12, 21 ]
    } ],
    "urls" : [ {
      "indices" : [ 22, 45 ],
      "url" : "https:\/\/t.co\/TbguAi9MyY",
      "expanded_url" : "https:\/\/instagram.com\/p\/6dhDlWBwmu\/",
      "display_url" : "instagram.com\/p\/6dhDlWBwmu\/"
    } ]
  },
  "geo" : { },
  "id_str" : "633044241351057408",
  "text" : "Overhead at #cccamp15 https:\/\/t.co\/TbguAi9MyY",
  "id" : 633044241351057408,
  "created_at" : "2015-08-16 22:34:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Brechler",
      "screen_name" : "plaetzchen",
      "indices" : [ 0, 11 ],
      "id_str" : "14305613",
      "id" : 14305613
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "633034091613569024",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.03176613995156, 13.30695876852917 ]
  },
  "id_str" : "633035498970288128",
  "in_reply_to_user_id" : 14305613,
  "text" : "@plaetzchen Kuschelparty im gr\u00FCnen QFGV-Zelt? :3",
  "id" : 633035498970288128,
  "in_reply_to_status_id" : 633034091613569024,
  "created_at" : "2015-08-16 21:59:58 +0000",
  "in_reply_to_screen_name" : "plaetzchen",
  "in_reply_to_user_id_str" : "14305613",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "not best practice",
      "screen_name" : "moeffju",
      "indices" : [ 0, 8 ],
      "id_str" : "5618832",
      "id" : 5618832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "633021819042316288",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.03086712565147, 13.30728211721583 ]
  },
  "id_str" : "633022550038179840",
  "in_reply_to_user_id" : 5618832,
  "text" : "@moeffju all of a sudden 5000+ people turned into thunderstorm evac experts\u2026",
  "id" : 633022550038179840,
  "in_reply_to_status_id" : 633021819042316288,
  "created_at" : "2015-08-16 21:08:31 +0000",
  "in_reply_to_screen_name" : "moeffju",
  "in_reply_to_user_id_str" : "5618832",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cccamp15",
      "indices" : [ 128, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.03162197121701, 13.30688735471415 ]
  },
  "id_str" : "633019294272630784",
  "text" : "last man camping: \u00ABI wasn\u2019t evacuated. I was in my tent, programming &amp; flying my drone, so I didn\u2019t hear the announcement.\u00BB #cccamp15",
  "id" : 633019294272630784,
  "created_at" : "2015-08-16 20:55:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cccamp15",
      "indices" : [ 135, 144 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.03148993480918, 13.30734562829336 ]
  },
  "id_str" : "632979078501507073",
  "text" : "Dear diary: today I tried jumping onto a moving train (&amp; failed). To show support bystanders started playing Wild West-style music #cccamp15",
  "id" : 632979078501507073,
  "created_at" : "2015-08-16 18:15:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Brechler",
      "screen_name" : "plaetzchen",
      "indices" : [ 42, 53 ],
      "id_str" : "14305613",
      "id" : 14305613
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cccamp15",
      "indices" : [ 78, 87 ]
    } ],
    "urls" : [ {
      "indices" : [ 54, 77 ],
      "url" : "https:\/\/t.co\/1mzc5of2vf",
      "expanded_url" : "https:\/\/instagram.com\/p\/6cdyEMhwmS\/",
      "display_url" : "instagram.com\/p\/6cdyEMhwmS\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.03056172340934, 13.30509858633772 ]
  },
  "id_str" : "632896456375070722",
  "text" : "Getting a private soldering workshop with @plaetzchen https:\/\/t.co\/1mzc5of2vf #cccamp15",
  "id" : 632896456375070722,
  "created_at" : "2015-08-16 12:47:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Clay",
      "screen_name" : "c3o",
      "indices" : [ 3, 7 ],
      "id_str" : "787678",
      "id" : 787678
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cccamp15",
      "indices" : [ 41, 50 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "632894234975162370",
  "text" : "RT @c3o: Calling all excellent people at #cccamp15: Fabulous Fairy Fest at QueerFeminist Geeks from 9 TONIGHT, spread the word http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/c3o\/status\/632890254761033728\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/XY5YWQJabm",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CMh6OUJWoAA8xUf.jpg",
        "id_str" : "632890133990252544",
        "id" : 632890133990252544,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CMh6OUJWoAA8xUf.jpg",
        "sizes" : [ {
          "h" : 562,
          "resize" : "fit",
          "w" : 562
        }, {
          "h" : 562,
          "resize" : "fit",
          "w" : 562
        }, {
          "h" : 562,
          "resize" : "fit",
          "w" : 562
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 562,
          "resize" : "fit",
          "w" : 562
        } ],
        "display_url" : "pic.twitter.com\/XY5YWQJabm"
      } ],
      "hashtags" : [ {
        "text" : "cccamp15",
        "indices" : [ 32, 41 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "632890254761033728",
    "text" : "Calling all excellent people at #cccamp15: Fabulous Fairy Fest at QueerFeminist Geeks from 9 TONIGHT, spread the word http:\/\/t.co\/XY5YWQJabm",
    "id" : 632890254761033728,
    "created_at" : "2015-08-16 12:22:49 +0000",
    "user" : {
      "name" : "Christopher Clay",
      "screen_name" : "c3o",
      "protected" : false,
      "id_str" : "787678",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/477506274616041472\/_OmAAaKi_normal.jpeg",
      "id" : 787678,
      "verified" : false
    }
  },
  "id" : 632894234975162370,
  "created_at" : "2015-08-16 12:38:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/632886962463113216\/photo\/1",
      "indices" : [ 18, 40 ],
      "url" : "http:\/\/t.co\/xVdCI23WeD",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CMh3VlKWcAABuz9.jpg",
      "id_str" : "632886960282038272",
      "id" : 632886960282038272,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CMh3VlKWcAABuz9.jpg",
      "sizes" : [ {
        "h" : 680,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/xVdCI23WeD"
    } ],
    "hashtags" : [ {
      "text" : "cccamp15",
      "indices" : [ 8, 17 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.03057766939761, 13.30500492926672 ]
  },
  "id_str" : "632886962463113216",
  "text" : "Me too! #cccamp15 http:\/\/t.co\/xVdCI23WeD",
  "id" : 632886962463113216,
  "created_at" : "2015-08-16 12:09:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dvzrv",
      "screen_name" : "dvzrv",
      "indices" : [ 0, 6 ],
      "id_str" : "30868098",
      "id" : 30868098
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 53, 59 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "632880763017498624",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.03055841648386, 13.30513042791057 ]
  },
  "id_str" : "632883274990374912",
  "in_reply_to_user_id" : 30868098,
  "text" : "@dvzrv cool, let me know if it takes place. I\u2019m sure @Lobot and I would be happy to drop by. :)",
  "id" : 632883274990374912,
  "in_reply_to_status_id" : 632880763017498624,
  "created_at" : "2015-08-16 11:55:05 +0000",
  "in_reply_to_screen_name" : "dvzrv",
  "in_reply_to_user_id_str" : "30868098",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dvzrv",
      "screen_name" : "dvzrv",
      "indices" : [ 0, 6 ],
      "id_str" : "30868098",
      "id" : 30868098
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "632863745585356800",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.03270118315987, 13.30646876246976 ]
  },
  "id_str" : "632867673525886977",
  "in_reply_to_user_id" : 30868098,
  "text" : "@dvzrv doh, did you play me again? \uD83D\uDE09",
  "id" : 632867673525886977,
  "in_reply_to_status_id" : 632863745585356800,
  "created_at" : "2015-08-16 10:53:06 +0000",
  "in_reply_to_screen_name" : "dvzrv",
  "in_reply_to_user_id_str" : "30868098",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    }, {
      "name" : "punycode",
      "screen_name" : "punycode",
      "indices" : [ 7, 16 ],
      "id_str" : "14328131",
      "id" : 14328131
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "632717676272578560",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.03140416721568, 13.30679067887122 ]
  },
  "id_str" : "632722683243970560",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot @punycode same here :)",
  "id" : 632722683243970560,
  "in_reply_to_status_id" : 632717676272578560,
  "created_at" : "2015-08-16 01:16:57 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/632675223041634304\/photo\/1",
      "indices" : [ 26, 48 ],
      "url" : "http:\/\/t.co\/gAxxsradh4",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CMe2w1yWcAAMsEc.jpg",
      "id_str" : "632675222857084928",
      "id" : 632675222857084928,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CMe2w1yWcAAMsEc.jpg",
      "sizes" : [ {
        "h" : 1040,
        "resize" : "fit",
        "w" : 1386
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1040,
        "resize" : "fit",
        "w" : 1386
      } ],
      "display_url" : "pic.twitter.com\/gAxxsradh4"
    } ],
    "hashtags" : [ {
      "text" : "cccamp15",
      "indices" : [ 16, 25 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.031534, 13.30698 ]
  },
  "id_str" : "632675223041634304",
  "text" : "apt-get install #cccamp15 http:\/\/t.co\/gAxxsradh4",
  "id" : 632675223041634304,
  "created_at" : "2015-08-15 22:08:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Brechler",
      "screen_name" : "plaetzchen",
      "indices" : [ 3, 14 ],
      "id_str" : "14305613",
      "id" : 14305613
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cccamp15",
      "indices" : [ 20, 29 ]
    }, {
      "text" : "CoderDojo",
      "indices" : [ 30, 40 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/QoHzaCRk26",
      "expanded_url" : "http:\/\/moby.to\/71ids5",
      "display_url" : "moby.to\/71ids5"
    } ]
  },
  "geo" : { },
  "id_str" : "632668055328399361",
  "text" : "RT @plaetzchen: The #cccamp15 #CoderDojo did a robot with a Particle Photon that is controlled by a website http:\/\/t.co\/QoHzaCRk26",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "cccamp15",
        "indices" : [ 4, 13 ]
      }, {
        "text" : "CoderDojo",
        "indices" : [ 14, 24 ]
      } ],
      "urls" : [ {
        "indices" : [ 92, 114 ],
        "url" : "http:\/\/t.co\/QoHzaCRk26",
        "expanded_url" : "http:\/\/moby.to\/71ids5",
        "display_url" : "moby.to\/71ids5"
      } ]
    },
    "geo" : { },
    "id_str" : "632560702612447233",
    "text" : "The #cccamp15 #CoderDojo did a robot with a Particle Photon that is controlled by a website http:\/\/t.co\/QoHzaCRk26",
    "id" : 632560702612447233,
    "created_at" : "2015-08-15 14:33:18 +0000",
    "user" : {
      "name" : "Philip Brechler",
      "screen_name" : "plaetzchen",
      "protected" : false,
      "id_str" : "14305613",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/629365136566931457\/eHyJzERC_normal.jpg",
      "id" : 14305613,
      "verified" : false
    }
  },
  "id" : 632668055328399361,
  "created_at" : "2015-08-15 21:39:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/632640585216749568\/photo\/1",
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/K0BWiNIbUK",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CMeXQqNWUAA4y8E.jpg",
      "id_str" : "632640585132822528",
      "id" : 632640585132822528,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CMeXQqNWUAA4y8E.jpg",
      "sizes" : [ {
        "h" : 1083,
        "resize" : "fit",
        "w" : 812
      }, {
        "h" : 1083,
        "resize" : "fit",
        "w" : 812
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1083,
        "resize" : "fit",
        "w" : 812
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      } ],
      "display_url" : "pic.twitter.com\/K0BWiNIbUK"
    } ],
    "hashtags" : [ {
      "text" : "cccamp15",
      "indices" : [ 81, 90 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "632640585216749568",
  "text" : "Join the 'fabulous fairy fest' in the QueerFeministGeek village on day 4 at 9pm. #cccamp15 http:\/\/t.co\/K0BWiNIbUK",
  "id" : 632640585216749568,
  "created_at" : "2015-08-15 19:50:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Brechler",
      "screen_name" : "plaetzchen",
      "indices" : [ 7, 18 ],
      "id_str" : "14305613",
      "id" : 14305613
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/632636431891099649\/photo\/1",
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/YcU675n1PE",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CMeTex0WgAAcFHt.jpg",
      "id_str" : "632636429647118336",
      "id" : 632636429647118336,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CMeTex0WgAAcFHt.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/YcU675n1PE"
    } ],
    "hashtags" : [ {
      "text" : "cccamp15",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.03157088351718, 13.30687419512617 ]
  },
  "id_str" : "632636431891099649",
  "text" : "Sweet, @plaetzchen queerifies the rad1o badges. #cccamp15 http:\/\/t.co\/YcU675n1PE",
  "id" : 632636431891099649,
  "created_at" : "2015-08-15 19:34:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 3, 9 ],
      "id_str" : "1492631",
      "id" : 1492631
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 13, 29 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Lobot\/status\/632619493836103680\/photo\/1",
      "indices" : [ 52, 74 ],
      "url" : "http:\/\/t.co\/820bY251Gl",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CMeEEzvW8AArHsO.jpg",
      "id_str" : "632619490812030976",
      "id" : 632619490812030976,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CMeEEzvW8AArHsO.jpg",
      "sizes" : [ {
        "h" : 680,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/820bY251Gl"
    } ],
    "hashtags" : [ {
      "text" : "cccamp15",
      "indices" : [ 42, 51 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "632630804271734784",
  "text" : "RT @Lobot: . @gedankenstuecke \u201Cfixed\u201D it. #cccamp15 http:\/\/t.co\/820bY251Gl",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 2, 18 ],
        "id_str" : "14286491",
        "id" : 14286491
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Lobot\/status\/632619493836103680\/photo\/1",
        "indices" : [ 41, 63 ],
        "url" : "http:\/\/t.co\/820bY251Gl",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CMeEEzvW8AArHsO.jpg",
        "id_str" : "632619490812030976",
        "id" : 632619490812030976,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CMeEEzvW8AArHsO.jpg",
        "sizes" : [ {
          "h" : 680,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/820bY251Gl"
      } ],
      "hashtags" : [ {
        "text" : "cccamp15",
        "indices" : [ 31, 40 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "632597587216998400",
    "geo" : { },
    "id_str" : "632619493836103680",
    "in_reply_to_user_id" : 14286491,
    "text" : ". @gedankenstuecke \u201Cfixed\u201D it. #cccamp15 http:\/\/t.co\/820bY251Gl",
    "id" : 632619493836103680,
    "in_reply_to_status_id" : 632597587216998400,
    "created_at" : "2015-08-15 18:26:55 +0000",
    "in_reply_to_screen_name" : "gedankenstuecke",
    "in_reply_to_user_id_str" : "14286491",
    "user" : {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "protected" : false,
      "id_str" : "1492631",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/783617256173494272\/7QL2FeUx_normal.jpg",
      "id" : 1492631,
      "verified" : false
    }
  },
  "id" : 632630804271734784,
  "created_at" : "2015-08-15 19:11:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "herr_schrat",
      "screen_name" : "herr_schrat",
      "indices" : [ 0, 12 ],
      "id_str" : "16066591",
      "id" : 16066591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "632609900221333509",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.03193524484805, 13.30707469025003 ]
  },
  "id_str" : "632612500509474817",
  "in_reply_to_user_id" : 16066591,
  "text" : "@herr_schrat ne danke, erstmal was essen.",
  "id" : 632612500509474817,
  "in_reply_to_status_id" : 632609900221333509,
  "created_at" : "2015-08-15 17:59:08 +0000",
  "in_reply_to_screen_name" : "herr_schrat",
  "in_reply_to_user_id_str" : "16066591",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cccamp15",
      "indices" : [ 77, 86 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "632597587216998400",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.03156074141435, 13.30708265305805 ]
  },
  "id_str" : "632597776665329664",
  "in_reply_to_user_id" : 14286491,
  "text" : "Already asked around in the D\u00FCsseldorf village. The driver is unknown there. #cccamp15",
  "id" : 632597776665329664,
  "in_reply_to_status_id" : 632597587216998400,
  "created_at" : "2015-08-15 17:00:37 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cccamp15",
      "indices" : [ 3, 12 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.03154372615091, 13.30688978546607 ]
  },
  "id_str" : "632597587216998400",
  "text" : "On #cccamp15 driving a white Mazda SUV with D\u00FCsseldorf license plates? You might wanna close your car windows before the storm hits.",
  "id" : 632597587216998400,
  "created_at" : "2015-08-15 16:59:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julian Finn",
      "screen_name" : "hdsjulian",
      "indices" : [ 0, 10 ],
      "id_str" : "12192142",
      "id" : 12192142
    }, {
      "name" : "Kat McKitten",
      "screen_name" : "yuiofthesun",
      "indices" : [ 11, 23 ],
      "id_str" : "513049579",
      "id" : 513049579
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 47 ],
      "url" : "https:\/\/t.co\/76oR2fDoY7",
      "expanded_url" : "https:\/\/events.ccc.de\/camp\/2015\/wiki\/Village:Kinky_Geeks",
      "display_url" : "events.ccc.de\/camp\/2015\/wiki\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "632532778173730816",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.03335924327126, 13.30532938528697 ]
  },
  "id_str" : "632541513415794688",
  "in_reply_to_user_id" : 12192142,
  "text" : "@hdsjulian @yuiofthesun https:\/\/t.co\/76oR2fDoY7",
  "id" : 632541513415794688,
  "in_reply_to_status_id" : 632532778173730816,
  "created_at" : "2015-08-15 13:17:03 +0000",
  "in_reply_to_screen_name" : "hdsjulian",
  "in_reply_to_user_id_str" : "12192142",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julian Finn",
      "screen_name" : "hdsjulian",
      "indices" : [ 0, 10 ],
      "id_str" : "12192142",
      "id" : 12192142
    }, {
      "name" : "Kat McKitten",
      "screen_name" : "yuiofthesun",
      "indices" : [ 11, 23 ],
      "id_str" : "513049579",
      "id" : 513049579
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "632532778173730816",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.0336775491508, 13.30550459214794 ]
  },
  "id_str" : "632540859905523712",
  "in_reply_to_user_id" : 12192142,
  "text" : "@hdsjulian @yuiofthesun in the KinkyGeeks village ;)",
  "id" : 632540859905523712,
  "in_reply_to_status_id" : 632532778173730816,
  "created_at" : "2015-08-15 13:14:27 +0000",
  "in_reply_to_screen_name" : "hdsjulian",
  "in_reply_to_user_id_str" : "12192142",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cccamp15",
      "indices" : [ 35, 44 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.03142130845509, 13.30679180101799 ]
  },
  "id_str" : "632531341922443264",
  "text" : "Hooray for the KinkyGeeks dungeon. #cccamp15",
  "id" : 632531341922443264,
  "created_at" : "2015-08-15 12:36:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/632502294853087232\/photo\/1",
      "indices" : [ 49, 71 ],
      "url" : "http:\/\/t.co\/h0UfM38Q3B",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CMcZe_yWEAAicNu.jpg",
      "id_str" : "632502292978208768",
      "id" : 632502292978208768,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CMcZe_yWEAAicNu.jpg",
      "sizes" : [ {
        "h" : 680,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/h0UfM38Q3B"
    } ],
    "hashtags" : [ {
      "text" : "cccamp15",
      "indices" : [ 39, 48 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.99064891997532, 13.3469538984313 ]
  },
  "id_str" : "632502294853087232",
  "text" : "All set for a Brandenburg party night. #cccamp15 http:\/\/t.co\/h0UfM38Q3B",
  "id" : 632502294853087232,
  "created_at" : "2015-08-15 10:41:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/632490786895069184\/photo\/1",
      "indices" : [ 32, 54 ],
      "url" : "http:\/\/t.co\/7TLbC3Unyx",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CMcPBH4WgAAUFFr.jpg",
      "id_str" : "632490784638533632",
      "id" : 632490784638533632,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CMcPBH4WgAAUFFr.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      } ],
      "display_url" : "pic.twitter.com\/7TLbC3Unyx"
    } ],
    "hashtags" : [ {
      "text" : "cccamp15",
      "indices" : [ 22, 31 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.03194487060198, 13.31138884744234 ]
  },
  "id_str" : "632490786895069184",
  "text" : "Rainbow Glider @ NOPE #cccamp15 http:\/\/t.co\/7TLbC3Unyx",
  "id" : 632490786895069184,
  "created_at" : "2015-08-15 09:55:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/vine.co\" rel=\"nofollow\"\u003EVine - Make a Scene\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CCCamp15",
      "indices" : [ 12, 21 ]
    } ],
    "urls" : [ {
      "indices" : [ 22, 45 ],
      "url" : "https:\/\/t.co\/6qXAM4ram8",
      "expanded_url" : "https:\/\/vine.co\/v\/edlUdpD1ptg",
      "display_url" : "vine.co\/v\/edlUdpD1ptg"
    } ]
  },
  "geo" : { },
  "id_str" : "632315210112598017",
  "text" : "Unicorn-Cat #CCCamp15 https:\/\/t.co\/6qXAM4ram8",
  "id" : 632315210112598017,
  "created_at" : "2015-08-14 22:17:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/632301363637174272\/photo\/1",
      "indices" : [ 32, 54 ],
      "url" : "http:\/\/t.co\/VdVWZQKch8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CMZivPcWcAAsXmh.jpg",
      "id_str" : "632301361430949888",
      "id" : 632301361430949888,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CMZivPcWcAAsXmh.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/VdVWZQKch8"
    } ],
    "hashtags" : [ {
      "text" : "cccamp15",
      "indices" : [ 22, 31 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.03149972115926, 13.30791095272946 ]
  },
  "id_str" : "632301363637174272",
  "text" : "~Klot\u00FCrfeminismus 2.0 #cccamp15 http:\/\/t.co\/VdVWZQKch8",
  "id" : 632301363637174272,
  "created_at" : "2015-08-14 21:22:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "632273528470040577",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.03179086656592, 13.30536880531656 ]
  },
  "id_str" : "632278109379817472",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon im village.",
  "id" : 632278109379817472,
  "in_reply_to_status_id" : 632273528470040577,
  "created_at" : "2015-08-14 19:50:23 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "632272965837697024",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.03176056598596, 13.30685659312951 ]
  },
  "id_str" : "632273116878774272",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon ja, wir haben welche :)",
  "id" : 632273116878774272,
  "in_reply_to_status_id" : 632272965837697024,
  "created_at" : "2015-08-14 19:30:32 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OKF Open Science AG",
      "screen_name" : "OKScienceDE",
      "indices" : [ 3, 15 ],
      "id_str" : "2973261231",
      "id" : 2973261231
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OpenScience",
      "indices" : [ 56, 68 ]
    }, {
      "text" : "CCCamp2015",
      "indices" : [ 81, 92 ]
    }, {
      "text" : "Open",
      "indices" : [ 134, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "632228558023323648",
  "text" : "RT @OKScienceDE: Many thanks to all participants of the #OpenScience workshop at #CCCamp2015. You made this a great event! Spread the #Open\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "OpenScience",
        "indices" : [ 39, 51 ]
      }, {
        "text" : "CCCamp2015",
        "indices" : [ 64, 75 ]
      }, {
        "text" : "Open",
        "indices" : [ 117, 122 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "632195753801351168",
    "text" : "Many thanks to all participants of the #OpenScience workshop at #CCCamp2015. You made this a great event! Spread the #Open spirit!",
    "id" : 632195753801351168,
    "created_at" : "2015-08-14 14:23:07 +0000",
    "user" : {
      "name" : "OKF Open Science AG",
      "screen_name" : "OKScienceDE",
      "protected" : false,
      "id_str" : "2973261231",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/620237688424243200\/GOv6FBCz_normal.png",
      "id" : 2973261231,
      "verified" : false
    }
  },
  "id" : 632228558023323648,
  "created_at" : "2015-08-14 16:33:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Brechler",
      "screen_name" : "plaetzchen",
      "indices" : [ 58, 69 ],
      "id_str" : "14305613",
      "id" : 14305613
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 84, 93 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/632217725788659712\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/Q2dk6Tvwu5",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CMYWmImW8AATT_8.jpg",
      "id_str" : "632217642091343872",
      "id" : 632217642091343872,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CMYWmImW8AATT_8.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      } ],
      "display_url" : "pic.twitter.com\/Q2dk6Tvwu5"
    } ],
    "hashtags" : [ {
      "text" : "cccamp15",
      "indices" : [ 104, 113 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.0315257469686, 13.30684402027475 ]
  },
  "id_str" : "632217725788659712",
  "text" : "\u2018Soldering for members of European Parliament\u2019, hosted by @plaetzchen in QFGV. Only @Senficon showed up #cccamp15 http:\/\/t.co\/Q2dk6Tvwu5",
  "id" : 632217725788659712,
  "created_at" : "2015-08-14 15:50:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "herr_schrat",
      "screen_name" : "herr_schrat",
      "indices" : [ 0, 12 ],
      "id_str" : "16066591",
      "id" : 16066591
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 13, 19 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "632182570143346688",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.03166425791851, 13.30691434444236 ]
  },
  "id_str" : "632193079353675780",
  "in_reply_to_user_id" : 16066591,
  "text" : "@herr_schrat @Lobot wir haben keine geplant und auch sonst nix geh\u00F6rt.",
  "id" : 632193079353675780,
  "in_reply_to_status_id" : 632182570143346688,
  "created_at" : "2015-08-14 14:12:30 +0000",
  "in_reply_to_screen_name" : "herr_schrat",
  "in_reply_to_user_id_str" : "16066591",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/632174649388998656\/photo\/1",
      "indices" : [ 7, 29 ],
      "url" : "http:\/\/t.co\/JRFquoLlk0",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CMXvfhGWcAA3gI0.jpg",
      "id_str" : "632174647455412224",
      "id" : 632174647455412224,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CMXvfhGWcAA3gI0.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/JRFquoLlk0"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "632172426403708928",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.03230362949244, 13.30857035705196 ]
  },
  "id_str" : "632174649388998656",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot http:\/\/t.co\/JRFquoLlk0",
  "id" : 632174649388998656,
  "in_reply_to_status_id" : 632172426403708928,
  "created_at" : "2015-08-14 12:59:16 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "632172426403708928",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.03226280962399, 13.3085271064316 ]
  },
  "id_str" : "632174153433542656",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot nope, only mate counts I guess.",
  "id" : 632174153433542656,
  "in_reply_to_status_id" : 632172426403708928,
  "created_at" : "2015-08-14 12:57:18 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "632171616617762816",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.03220191509745, 13.30848008395481 ]
  },
  "id_str" : "632172251866132480",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot don\u2019t forget to write it down on your arm!",
  "id" : 632172251866132480,
  "in_reply_to_status_id" : 632171616617762816,
  "created_at" : "2015-08-14 12:49:44 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cccamp15",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.03237529476456, 13.30847212114679 ]
  },
  "id_str" : "632160235348754432",
  "text" : "Today at 1900 in the QueerFeministGeeks-Village: vegan chickpea dal. #cccamp15",
  "id" : 632160235348754432,
  "created_at" : "2015-08-14 12:01:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "632150093056098304",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.03149875724039, 13.30687738024938 ]
  },
  "id_str" : "632150243627409408",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon cool, bis gleich. :)",
  "id" : 632150243627409408,
  "in_reply_to_status_id" : 632150093056098304,
  "created_at" : "2015-08-14 11:22:17 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "632149785395527680",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.0313869845616, 13.30687721261131 ]
  },
  "id_str" : "632149946305773568",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon ja, so bis 1350 ca. Dann wollte ich zum Open Science Workshop.",
  "id" : 632149946305773568,
  "in_reply_to_status_id" : 632149785395527680,
  "created_at" : "2015-08-14 11:21:06 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Rupert",
      "screen_name" : "Meowdip",
      "indices" : [ 0, 8 ],
      "id_str" : "48883029",
      "id" : 48883029
    }, {
      "name" : "Konrad F\u00F6rstner",
      "screen_name" : "konradfoerstner",
      "indices" : [ 9, 25 ],
      "id_str" : "15150655",
      "id" : 15150655
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 71 ],
      "url" : "https:\/\/t.co\/6mYynbuLRH",
      "expanded_url" : "https:\/\/events.ccc.de\/camp\/2015\/wiki\/Session:Open_Science_Workshop",
      "display_url" : "events.ccc.de\/camp\/2015\/wiki\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "632144981042466816",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.03154096012286, 13.30689280295121 ]
  },
  "id_str" : "632145625853898752",
  "in_reply_to_user_id" : 48883029,
  "text" : "@Meowdip @konradfoerstner 1400 in Hackcenter 3. https:\/\/t.co\/6mYynbuLRH",
  "id" : 632145625853898752,
  "in_reply_to_status_id" : 632144981042466816,
  "created_at" : "2015-08-14 11:03:56 +0000",
  "in_reply_to_screen_name" : "Meowdip",
  "in_reply_to_user_id_str" : "48883029",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Rupert",
      "screen_name" : "Meowdip",
      "indices" : [ 0, 8 ],
      "id_str" : "48883029",
      "id" : 48883029
    }, {
      "name" : "Konrad F\u00F6rstner",
      "screen_name" : "konradfoerstner",
      "indices" : [ 111, 127 ],
      "id_str" : "15150655",
      "id" : 15150655
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "632143213332049920",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.03152046636961, 13.30691970886039 ]
  },
  "id_str" : "632143785523322880",
  "in_reply_to_user_id" : 48883029,
  "text" : "@Meowdip great, I\u2019m in the QueerFeministGeeks-Village. Also: it seems there will be a open science workshop by @konradfoerstner",
  "id" : 632143785523322880,
  "in_reply_to_status_id" : 632143213332049920,
  "created_at" : "2015-08-14 10:56:37 +0000",
  "in_reply_to_screen_name" : "Meowdip",
  "in_reply_to_user_id_str" : "48883029",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Rupert",
      "screen_name" : "Meowdip",
      "indices" : [ 0, 8 ],
      "id_str" : "48883029",
      "id" : 48883029
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.0315093603479, 13.30693001860129 ]
  },
  "id_str" : "632142707926921216",
  "in_reply_to_user_id" : 48883029,
  "text" : "@Meowdip seems we are neighbors. Would love to chat about those post-translational modifications at some time. :)",
  "id" : 632142707926921216,
  "created_at" : "2015-08-14 10:52:20 +0000",
  "in_reply_to_screen_name" : "Meowdip",
  "in_reply_to_user_id_str" : "48883029",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "metro fnord",
      "screen_name" : "linse",
      "indices" : [ 0, 6 ],
      "id_str" : "2206871",
      "id" : 2206871
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.03214206830881, 13.3070331160103 ]
  },
  "id_str" : "632139772883005440",
  "in_reply_to_user_id" : 2206871,
  "text" : "@linse thanks for the great talk!",
  "id" : 632139772883005440,
  "created_at" : "2015-08-14 10:40:41 +0000",
  "in_reply_to_screen_name" : "linse",
  "in_reply_to_user_id_str" : "2206871",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Konrad F\u00F6rstner",
      "screen_name" : "konradfoerstner",
      "indices" : [ 0, 16 ],
      "id_str" : "15150655",
      "id" : 15150655
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "632135475935862784",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.03250513044468, 13.30638066866743 ]
  },
  "id_str" : "632138973327032320",
  "in_reply_to_user_id" : 15150655,
  "text" : "@konradfoerstner great, see you there. Do you meet at some workshop tent or at your village? :)",
  "id" : 632138973327032320,
  "in_reply_to_status_id" : 632135475935862784,
  "created_at" : "2015-08-14 10:37:30 +0000",
  "in_reply_to_screen_name" : "konradfoerstner",
  "in_reply_to_user_id_str" : "15150655",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/NlxtWKqdF1",
      "expanded_url" : "https:\/\/twitter.com\/Senficon\/status\/632131740086222849",
      "display_url" : "twitter.com\/Senficon\/statu\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.03240370566947, 13.30761539898193 ]
  },
  "id_str" : "632133438561193984",
  "text" : "\u00ABHacking [\u2026] is a route to escaping the shackles of the profit-fetish, not a route to profit. Go home, yuppies\u00BB https:\/\/t.co\/NlxtWKqdF1",
  "id" : 632133438561193984,
  "created_at" : "2015-08-14 10:15:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "rad1obadge",
      "screen_name" : "rad1obadge",
      "indices" : [ 0, 11 ],
      "id_str" : "3364727765",
      "id" : 3364727765
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "631973909219438592",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.03249033638559, 13.30762554892647 ]
  },
  "id_str" : "632130336042958848",
  "in_reply_to_user_id" : 3364727765,
  "text" : "@rad1obadge do you have spare displays you sell? Someone (aka I) crushed mine m(",
  "id" : 632130336042958848,
  "in_reply_to_status_id" : 631973909219438592,
  "created_at" : "2015-08-14 10:03:11 +0000",
  "in_reply_to_screen_name" : "rad1obadge",
  "in_reply_to_user_id_str" : "3364727765",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "metro fnord",
      "screen_name" : "linse",
      "indices" : [ 5, 11 ],
      "id_str" : "2206871",
      "id" : 2206871
    }, {
      "name" : "Digitalcourage e.V.",
      "screen_name" : "digitalcourage",
      "indices" : [ 59, 74 ],
      "id_str" : "29031844",
      "id" : 29031844
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cccamp15",
      "indices" : [ 77, 86 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.03253157534919, 13.30767190085101 ]
  },
  "id_str" : "632129724987408385",
  "text" : "Now: @linse on \u2018building a culture of courage\u2019 (that\u2019s not @digitalcourage). #cccamp15",
  "id" : 632129724987408385,
  "created_at" : "2015-08-14 10:00:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Will-o-the-Wisp",
      "screen_name" : "willowbl00",
      "indices" : [ 0, 11 ],
      "id_str" : "13958262",
      "id" : 13958262
    }, {
      "name" : "Ben Rupert",
      "screen_name" : "Meowdip",
      "indices" : [ 12, 20 ],
      "id_str" : "48883029",
      "id" : 48883029
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "632125872254812160",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.03253270690612, 13.30761238933849 ]
  },
  "id_str" : "632127367708811264",
  "in_reply_to_user_id" : 13958262,
  "text" : "@willowbl00 @Meowdip very nice!",
  "id" : 632127367708811264,
  "in_reply_to_status_id" : 632125872254812160,
  "created_at" : "2015-08-14 09:51:23 +0000",
  "in_reply_to_screen_name" : "willowbl00",
  "in_reply_to_user_id_str" : "13958262",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cccamp15",
      "indices" : [ 90, 99 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.0324733461932, 13.30761337849523 ]
  },
  "id_str" : "632123593527324672",
  "text" : "Examples of \u2018good GMOs\u2019: production of Chymosin (used for rennet) and Insulin in E. coli. #cccamp15",
  "id" : 632123593527324672,
  "created_at" : "2015-08-14 09:36:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cccamp15",
      "indices" : [ 96, 105 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.03243824285737, 13.30758288503933 ]
  },
  "id_str" : "632122706142568448",
  "text" : "On the fear of GMOs: \u00ABThe problem is patents and corporate behavior, not genetic modification.\u00BB #cccamp15",
  "id" : 632122706142568448,
  "created_at" : "2015-08-14 09:32:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Konrad F\u00F6rstner",
      "screen_name" : "konradfoerstner",
      "indices" : [ 0, 16 ],
      "id_str" : "15150655",
      "id" : 15150655
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.03243472245804, 13.30759336241829 ]
  },
  "id_str" : "632118059046727680",
  "in_reply_to_user_id" : 15150655,
  "text" : "@konradfoerstner is the workshop today at 1400 still on? :)",
  "id" : 632118059046727680,
  "created_at" : "2015-08-14 09:14:24 +0000",
  "in_reply_to_screen_name" : "konradfoerstner",
  "in_reply_to_user_id_str" : "15150655",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cccamp15",
      "indices" : [ 78, 87 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.03243157924435, 13.30758271740126 ]
  },
  "id_str" : "632117103563272192",
  "text" : "In 5 minutes in Track North: Benjamin Rupert talking about Real Vegan Cheese. #cccamp15",
  "id" : 632117103563272192,
  "created_at" : "2015-08-14 09:10:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cccamp15",
      "indices" : [ 33, 42 ]
    } ],
    "urls" : [ {
      "indices" : [ 43, 66 ],
      "url" : "https:\/\/t.co\/mit27M5P5R",
      "expanded_url" : "https:\/\/instagram.com\/p\/6WpDU7hwte\/",
      "display_url" : "instagram.com\/p\/6WpDU7hwte\/"
    } ]
  },
  "geo" : { },
  "id_str" : "632076662134452224",
  "text" : "Survived Day 1 (me and the yurt) #cccamp15 https:\/\/t.co\/mit27M5P5R",
  "id" : 632076662134452224,
  "created_at" : "2015-08-14 06:29:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "631946940025044992",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.03149821241669, 13.30678911880898 ]
  },
  "id_str" : "631948337445535744",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon oki.",
  "id" : 631948337445535744,
  "in_reply_to_status_id" : 631946940025044992,
  "created_at" : "2015-08-13 21:59:59 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    }, {
      "name" : "tina alt",
      "screen_name" : "tnakng",
      "indices" : [ 10, 17 ],
      "id_str" : "709415983870558208",
      "id" : 709415983870558208
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "631946535480246272",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.03137181331686, 13.30696673133718 ]
  },
  "id_str" : "631946758080360448",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon @TnaKng yep, komm ins village wenn du welchen willst :3",
  "id" : 631946758080360448,
  "in_reply_to_status_id" : 631946535480246272,
  "created_at" : "2015-08-13 21:53:42 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tina alt",
      "screen_name" : "tnakng",
      "indices" : [ 0, 7 ],
      "id_str" : "709415983870558208",
      "id" : 709415983870558208
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "631923235660169217",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.0315267947065, 13.30690462143468 ]
  },
  "id_str" : "631923969596223489",
  "in_reply_to_user_id" : 339564605,
  "text" : "@TnaKng thanks! :)",
  "id" : 631923969596223489,
  "in_reply_to_status_id" : 631923235660169217,
  "created_at" : "2015-08-13 20:23:09 +0000",
  "in_reply_to_screen_name" : "trotzdemda",
  "in_reply_to_user_id_str" : "339564605",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tina alt",
      "screen_name" : "tnakng",
      "indices" : [ 29, 36 ],
      "id_str" : "709415983870558208",
      "id" : 709415983870558208
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cccamp15",
      "indices" : [ 11, 20 ]
    } ],
    "urls" : [ {
      "indices" : [ 38, 61 ],
      "url" : "https:\/\/t.co\/penhcEB5nd",
      "expanded_url" : "https:\/\/instagram.com\/p\/6ViKtaBwtX\/",
      "display_url" : "instagram.com\/p\/6ViKtaBwtX\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.03158831787578, 13.30690671691048 ]
  },
  "id_str" : "631921077510361089",
  "text" : "Nail Art @ #cccamp15. Thanks @TnaKng! https:\/\/t.co\/penhcEB5nd",
  "id" : 631921077510361089,
  "created_at" : "2015-08-13 20:11:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katha",
      "screen_name" : "kathakatze",
      "indices" : [ 0, 11 ],
      "id_str" : "541170257",
      "id" : 541170257
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nomnomnom",
      "indices" : [ 41, 51 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "631865943019360258",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.03153672726176, 13.30660798588144 ]
  },
  "id_str" : "631875847268532224",
  "in_reply_to_user_id" : 541170257,
  "text" : "@kathakatze ging auch ohne total gut. :) #nomnomnom",
  "id" : 631875847268532224,
  "in_reply_to_status_id" : 631865943019360258,
  "created_at" : "2015-08-13 17:11:56 +0000",
  "in_reply_to_screen_name" : "kathakatze",
  "in_reply_to_user_id_str" : "541170257",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/631862574959718400\/photo\/1",
      "indices" : [ 31, 53 ],
      "url" : "http:\/\/t.co\/FOipKW0oGa",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CMTTqYUWEAAwbln.jpg",
      "id_str" : "631862572774461440",
      "id" : 631862572774461440,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CMTTqYUWEAAwbln.jpg",
      "sizes" : [ {
        "h" : 680,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/FOipKW0oGa"
    } ],
    "hashtags" : [ {
      "text" : "cccamp15",
      "indices" : [ 21, 30 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.03151422185174, 13.30685692840564 ]
  },
  "id_str" : "631862574959718400",
  "text" : "\u00ABDas Brot ist voll!\u00BB #cccamp15 http:\/\/t.co\/FOipKW0oGa",
  "id" : 631862574959718400,
  "created_at" : "2015-08-13 16:19:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    }, {
      "name" : "herr_schrat",
      "screen_name" : "herr_schrat",
      "indices" : [ 10, 22 ],
      "id_str" : "16066591",
      "id" : 16066591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "631861263111430144",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.03151422185174, 13.30685692840564 ]
  },
  "id_str" : "631862388791353344",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon @herr_schrat I\u2019d be even less surprised by that ;)",
  "id" : 631862388791353344,
  "in_reply_to_status_id" : 631861263111430144,
  "created_at" : "2015-08-13 16:18:27 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "herr_schrat",
      "screen_name" : "herr_schrat",
      "indices" : [ 41, 53 ],
      "id_str" : "16066591",
      "id" : 16066591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/VD1YBohjbC",
      "expanded_url" : "https:\/\/twitter.com\/c3cert\/status\/631839920181641216",
      "display_url" : "twitter.com\/c3cert\/status\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.03148111333422, 13.30688945018994 ]
  },
  "id_str" : "631854542343286785",
  "text" : "Color me less than surprised that it was @herr_schrat who was probably the first to need the underwater CERT.  https:\/\/t.co\/VD1YBohjbC",
  "id" : 631854542343286785,
  "created_at" : "2015-08-13 15:47:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/631848714450116608\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/q2oB19dBID",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CMTHDl3WgAAgwiy.jpg",
      "id_str" : "631848712256520192",
      "id" : 631848712256520192,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CMTHDl3WgAAgwiy.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      } ],
      "display_url" : "pic.twitter.com\/q2oB19dBID"
    } ],
    "hashtags" : [ {
      "text" : "cccamp15",
      "indices" : [ 105, 114 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.03167507057361, 13.30677403138327 ]
  },
  "id_str" : "631848714450116608",
  "text" : "Preparing Shakshouka for the QueerFeministGeeks-Village. Drop by at 1830 to get some. 1st come 1st serve #cccamp15 http:\/\/t.co\/q2oB19dBID",
  "id" : 631848714450116608,
  "created_at" : "2015-08-13 15:24:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cccamp15",
      "indices" : [ 89, 98 ]
    } ],
    "urls" : [ {
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/S6hDFW59EA",
      "expanded_url" : "http:\/\/www.transstudent.org\/genderunicorn1.jpg",
      "display_url" : "transstudent.org\/genderunicorn1\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.03161166147611, 13.30691652373719 ]
  },
  "id_str" : "631820280743219200",
  "text" : "Hanging out in the QueerFeministGeeks Village: the Gender Unicorn http:\/\/t.co\/S6hDFW59EA #cccamp15",
  "id" : 631820280743219200,
  "created_at" : "2015-08-13 13:31:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dvzrv",
      "screen_name" : "dvzrv",
      "indices" : [ 0, 6 ],
      "id_str" : "30868098",
      "id" : 30868098
    }, {
      "name" : "c-base e.V.",
      "screen_name" : "cbase",
      "indices" : [ 7, 13 ],
      "id_str" : "72242064",
      "id" : 72242064
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "631774820011782144",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.03243903913818, 13.31111066044617 ]
  },
  "id_str" : "631781888122843136",
  "in_reply_to_user_id" : 30868098,
  "text" : "@dvzrv @cbase sweet, I\u2019m for off for breakfast first :)",
  "id" : 631781888122843136,
  "in_reply_to_status_id" : 631774820011782144,
  "created_at" : "2015-08-13 10:58:34 +0000",
  "in_reply_to_screen_name" : "dvzrv",
  "in_reply_to_user_id_str" : "30868098",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 0, 10 ],
      "id_str" : "14700783",
      "id" : 14700783
    }, {
      "name" : "Manuel Corpas",
      "screen_name" : "manuelcorpas",
      "indices" : [ 19, 32 ],
      "id_str" : "111020569",
      "id" : 111020569
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "631774503597645824",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.03238099445871, 13.31101275981712 ]
  },
  "id_str" : "631781790454296576",
  "in_reply_to_user_id" : 14700783,
  "text" : "@Fischblog thanks! @manuelcorpas is great :)",
  "id" : 631781790454296576,
  "in_reply_to_status_id" : 631774503597645824,
  "created_at" : "2015-08-13 10:58:11 +0000",
  "in_reply_to_screen_name" : "Fischblog",
  "in_reply_to_user_id_str" : "14700783",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cccamp15",
      "indices" : [ 10, 19 ]
    } ],
    "urls" : [ {
      "indices" : [ 46, 69 ],
      "url" : "https:\/\/t.co\/MxVA1mTwCL",
      "expanded_url" : "https:\/\/instagram.com\/p\/6Ui2xRBwi3\/",
      "display_url" : "instagram.com\/p\/6Ui2xRBwi3\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.031168779, 13.310851281 ]
  },
  "id_str" : "631781561667559424",
  "text" : "Fixed it! #cccamp15 @ Ziegeleipark Mildenberg https:\/\/t.co\/MxVA1mTwCL",
  "id" : 631781561667559424,
  "created_at" : "2015-08-13 10:57:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/631739921397587968\/photo\/1",
      "indices" : [ 15, 37 ],
      "url" : "http:\/\/t.co\/hb3BzFzLxj",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CMRkHAeWwAAijI9.jpg",
      "id_str" : "631739919287894016",
      "id" : 631739919287894016,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CMRkHAeWwAAijI9.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/hb3BzFzLxj"
    } ],
    "hashtags" : [ {
      "text" : "cccamp15",
      "indices" : [ 5, 14 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.03175549493454, 13.3069141768043 ]
  },
  "id_str" : "631739921397587968",
  "text" : "Doh! #cccamp15 http:\/\/t.co\/hb3BzFzLxj",
  "id" : 631739921397587968,
  "created_at" : "2015-08-13 08:11:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "631705242271383552",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.03167150826476, 13.30695776270079 ]
  },
  "id_str" : "631728054415589376",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich apply water to burn. ;)",
  "id" : 631728054415589376,
  "in_reply_to_status_id" : 631705242271383552,
  "created_at" : "2015-08-13 07:24:39 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cccamp15",
      "indices" : [ 57, 66 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.03043123805246, 13.30756117591011 ]
  },
  "id_str" : "631564227199803392",
  "text" : "Getting this tent up certainly wasn\u2019t an elevator pitch. #cccamp15",
  "id" : 631564227199803392,
  "created_at" : "2015-08-12 20:33:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cccamp15",
      "indices" : [ 27, 36 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.0295666028308, 13.30718985759961 ]
  },
  "id_str" : "631525283057782784",
  "text" : "Didn\u2019t crash the ambulance #cccamp15",
  "id" : 631525283057782784,
  "created_at" : "2015-08-12 17:58:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "631466619915649024",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.13094974310633, 12.75126566033731 ]
  },
  "id_str" : "631501389420740608",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot that explains why the trunk is full of it!",
  "id" : 631501389420740608,
  "in_reply_to_status_id" : 631466619915649024,
  "created_at" : "2015-08-12 16:23:58 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 10, 16 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "631480307858972673",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.10238479920766, 11.95606897586207 ]
  },
  "id_str" : "631499144109125632",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich @Lobot ouch, aber du hast ja recht :(\uD83D\uDCA5\uD83D\uDEBF",
  "id" : 631499144109125632,
  "in_reply_to_status_id" : 631480307858972673,
  "created_at" : "2015-08-12 16:15:03 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cccamp15",
      "indices" : [ 7, 16 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.00787033331674, 10.25365775452019 ]
  },
  "id_str" : "631455725097758724",
  "text" : "Fellow #cccamp15 travelers at truck stop asking whether we also try navigating by OpenStreetMap. Answering \u2018Apple Maps\u2019 breaks their heart.",
  "id" : 631455725097758724,
  "created_at" : "2015-08-12 13:22:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 10, 16 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "631429512731979776",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.00792364222091, 10.25384416804673 ]
  },
  "id_str" : "631452975609839616",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich @Lobot zumindest du erkennst mein reichhaltiges Talent an. \uD83D\uDE02",
  "id" : 631452975609839616,
  "in_reply_to_status_id" : 631429512731979776,
  "created_at" : "2015-08-12 13:11:35 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 13, 19 ],
      "id_str" : "1492631",
      "id" : 1492631
    }, {
      "name" : "Malwine",
      "screen_name" : "malweene",
      "indices" : [ 20, 29 ],
      "id_str" : "2329258855",
      "id" : 2329258855
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "631433729970438144",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.65408143219599, 9.01124529541378 ]
  },
  "id_str" : "631452462902329344",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch @Lobot @malweene aww\u2764\uFE0F\uD83D\uDC93\uD83D\uDC96 looking forward to it!",
  "id" : 631452462902329344,
  "in_reply_to_status_id" : 631433729970438144,
  "created_at" : "2015-08-12 13:09:33 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/OEc8nKzMJj",
      "expanded_url" : "https:\/\/twitter.com\/Lobot\/status\/631426641235968000",
      "display_url" : "twitter.com\/Lobot\/status\/6\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.21485717506167, 8.662395514555891 ]
  },
  "id_str" : "631429532776558592",
  "text" : "Clear priorities: she heads back for the can opener, I for the nail polish. https:\/\/t.co\/OEc8nKzMJj",
  "id" : 631429532776558592,
  "created_at" : "2015-08-12 11:38:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "631426641235968000",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.21343392790315, 8.661733428024371 ]
  },
  "id_str" : "631429106719133696",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot Bei dieser Bezeichnung f\u00FChle ich mich objektifiziert!!11",
  "id" : 631429106719133696,
  "in_reply_to_status_id" : 631426641235968000,
  "created_at" : "2015-08-12 11:36:45 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cccamp15",
      "indices" : [ 70, 79 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.113998638614, 8.753478777541062 ]
  },
  "id_str" : "631424850045833216",
  "text" : "Yes, we did just turn around so I could pack fluorescent nail polish. #cccamp15",
  "id" : 631424850045833216,
  "created_at" : "2015-08-12 11:19:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/631421088954757120\/photo\/1",
      "indices" : [ 21, 43 ],
      "url" : "http:\/\/t.co\/EcBY2nWnYy",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CMNCIiNWsAAg8-0.jpg",
      "id_str" : "631421087151206400",
      "id" : 631421087151206400,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CMNCIiNWsAAg8-0.jpg",
      "sizes" : [ {
        "h" : 680,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/EcBY2nWnYy"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "631407772270206976",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.10640575823246, 8.766349394845736 ]
  },
  "id_str" : "631421088954757120",
  "in_reply_to_user_id" : 14286491,
  "text" : "And there\u2019s level 2. http:\/\/t.co\/EcBY2nWnYy",
  "id" : 631421088954757120,
  "in_reply_to_status_id" : 631407772270206976,
  "created_at" : "2015-08-12 11:04:53 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "acid\u0FC8 \u1515\u1548\u1587\u1571\u15EF\u1602 \u1515\u1573\u157C\u15DD\u1602\u1571\u1587",
      "screen_name" : "acid23",
      "indices" : [ 0, 7 ],
      "id_str" : "35535998",
      "id" : 35535998
    }, {
      "name" : "himbeerkomplott",
      "screen_name" : "raspberryperson",
      "indices" : [ 8, 24 ],
      "id_str" : "2841131495",
      "id" : 2841131495
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "631415118434336768",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.10635157467713, 8.766505265714349 ]
  },
  "id_str" : "631420972441169920",
  "in_reply_to_user_id" : 35535998,
  "text" : "@acid23 @raspberryperson das Hoffe ich doch ;)",
  "id" : 631420972441169920,
  "in_reply_to_status_id" : 631415118434336768,
  "created_at" : "2015-08-12 11:04:25 +0000",
  "in_reply_to_screen_name" : "acid23",
  "in_reply_to_user_id_str" : "35535998",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "himbeerkomplott",
      "screen_name" : "raspberryperson",
      "indices" : [ 0, 16 ],
      "id_str" : "2841131495",
      "id" : 2841131495
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "631413333841813504",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.10630758949565, 8.765641534709154 ]
  },
  "id_str" : "631413519188160512",
  "in_reply_to_user_id" : 2841131495,
  "text" : "@raspberryperson das glaube ich sofort. Aber ich freu mich, dass sie ihren Urlaub bekommt :)",
  "id" : 631413519188160512,
  "in_reply_to_status_id" : 631413333841813504,
  "created_at" : "2015-08-12 10:34:48 +0000",
  "in_reply_to_screen_name" : "raspberryperson",
  "in_reply_to_user_id_str" : "2841131495",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "himbeerkomplott",
      "screen_name" : "raspberryperson",
      "indices" : [ 0, 16 ],
      "id_str" : "2841131495",
      "id" : 2841131495
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "631410609968517120",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.10629962561491, 8.76659468763015 ]
  },
  "id_str" : "631412162297266177",
  "in_reply_to_user_id" : 2841131495,
  "text" : "@raspberryperson yay, mit \uD83D\uDC36? \uD83D\uDE09",
  "id" : 631412162297266177,
  "in_reply_to_status_id" : 631410609968517120,
  "created_at" : "2015-08-12 10:29:25 +0000",
  "in_reply_to_screen_name" : "raspberryperson",
  "in_reply_to_user_id_str" : "2841131495",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrick Rauscher",
      "screen_name" : "prauscher",
      "indices" : [ 0, 10 ],
      "id_str" : "74155696",
      "id" : 74155696
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "631408619326537728",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11408129745954, 8.753382974309105 ]
  },
  "id_str" : "631409803953348608",
  "in_reply_to_user_id" : 74155696,
  "text" : "@prauscher we\u2019ll try \uD83D\uDE97\uD83D\uDC5D\uD83D\uDC5D\uD83D\uDC5D\uD83D\uDC5C\uD83D\uDC5B\uD83D\uDC5C\uD83D\uDC5B",
  "id" : 631409803953348608,
  "in_reply_to_status_id" : 631408619326537728,
  "created_at" : "2015-08-12 10:20:02 +0000",
  "in_reply_to_screen_name" : "prauscher",
  "in_reply_to_user_id_str" : "74155696",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "himbeerkomplott",
      "screen_name" : "raspberryperson",
      "indices" : [ 0, 16 ],
      "id_str" : "2841131495",
      "id" : 2841131495
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "631408433883955201",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11408129745954, 8.753382974309105 ]
  },
  "id_str" : "631409498188566528",
  "in_reply_to_user_id" : 2841131495,
  "text" : "@raspberryperson w\u00E4re aber nett wenn man sich mal \u00FCber den Weg l\u00E4uft :)",
  "id" : 631409498188566528,
  "in_reply_to_status_id" : 631408433883955201,
  "created_at" : "2015-08-12 10:18:50 +0000",
  "in_reply_to_screen_name" : "raspberryperson",
  "in_reply_to_user_id_str" : "2841131495",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "himbeerkomplott",
      "screen_name" : "raspberryperson",
      "indices" : [ 0, 16 ],
      "id_str" : "2841131495",
      "id" : 2841131495
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "631408433883955201",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11408129745954, 8.753382974309105 ]
  },
  "id_str" : "631409447554953216",
  "in_reply_to_user_id" : 2841131495,
  "text" : "@raspberryperson ob wir in dem village Zelten werden ist auch noch nicht ganz klar, aber zumindest tags\u00FCber vor Ort sein.",
  "id" : 631409447554953216,
  "in_reply_to_status_id" : 631408433883955201,
  "created_at" : "2015-08-12 10:18:37 +0000",
  "in_reply_to_screen_name" : "raspberryperson",
  "in_reply_to_user_id_str" : "2841131495",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrick Rauscher",
      "screen_name" : "prauscher",
      "indices" : [ 0, 10 ],
      "id_str" : "74155696",
      "id" : 74155696
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "631407967024324608",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11408141001441, 8.753377863851329 ]
  },
  "id_str" : "631408341957353472",
  "in_reply_to_user_id" : 74155696,
  "text" : "@prauscher getting all the groceries to cook for a large-ish group for 2 meals and then we\u2019re done :)",
  "id" : 631408341957353472,
  "in_reply_to_status_id" : 631407967024324608,
  "created_at" : "2015-08-12 10:14:14 +0000",
  "in_reply_to_screen_name" : "prauscher",
  "in_reply_to_user_id_str" : "74155696",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "himbeerkomplott",
      "screen_name" : "raspberryperson",
      "indices" : [ 0, 16 ],
      "id_str" : "2841131495",
      "id" : 2841131495
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "631407939706863616",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11405899859865, 8.753300540213074 ]
  },
  "id_str" : "631408208003919876",
  "in_reply_to_user_id" : 2841131495,
  "text" : "@raspberryperson damit wird das QueerFeminist-Village morgen und \u00FCbermorgen bekocht. Wirst du auch da sein? :)",
  "id" : 631408208003919876,
  "in_reply_to_status_id" : 631407939706863616,
  "created_at" : "2015-08-12 10:13:42 +0000",
  "in_reply_to_screen_name" : "raspberryperson",
  "in_reply_to_user_id_str" : "2841131495",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/631407772270206976\/photo\/1",
      "indices" : [ 42, 64 ],
      "url" : "http:\/\/t.co\/zWkWGT4S1R",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CMM2BXZWoAAoQD1.jpg",
      "id_str" : "631407769850126336",
      "id" : 631407769850126336,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CMM2BXZWoAAoQD1.jpg",
      "sizes" : [ {
        "h" : 680,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2448,
        "resize" : "fit",
        "w" : 2448
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/zWkWGT4S1R"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11408188134977, 8.75337869649181 ]
  },
  "id_str" : "631407772270206976",
  "text" : "Solved the first level of luggage Tetris. http:\/\/t.co\/zWkWGT4S1R",
  "id" : 631407772270206976,
  "created_at" : "2015-08-12 10:11:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Droid Boy",
      "screen_name" : "boydroid",
      "indices" : [ 0, 9 ],
      "id_str" : "89437290",
      "id" : 89437290
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "631401425810100224",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11387204756039, 8.753248304136799 ]
  },
  "id_str" : "631407431529164800",
  "in_reply_to_user_id" : 89437290,
  "text" : "@boydroid 2 persons, a bit of cooking and a bit of playing guitar.",
  "id" : 631407431529164800,
  "in_reply_to_status_id" : 631401425810100224,
  "created_at" : "2015-08-12 10:10:37 +0000",
  "in_reply_to_screen_name" : "boydroid",
  "in_reply_to_user_id_str" : "89437290",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cccamp15",
      "indices" : [ 122, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1139973004105, 8.75347881652753 ]
  },
  "id_str" : "631401271065493504",
  "text" : "It\u2019s amazing a) how much stuff you can pack for a 6 day trip and b) that all of this (hopefully) fits into this tiny car. #cccamp15",
  "id" : 631401271065493504,
  "created_at" : "2015-08-12 09:46:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fiona Nielsen",
      "screen_name" : "glyn_dk",
      "indices" : [ 0, 8 ],
      "id_str" : "32340834",
      "id" : 32340834
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "631360700758261760",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11408113383709, 8.753380910075114 ]
  },
  "id_str" : "631370632245182464",
  "in_reply_to_user_id" : 32340834,
  "text" : "@glyn_dk thanks! :)",
  "id" : 631370632245182464,
  "in_reply_to_status_id" : 631360700758261760,
  "created_at" : "2015-08-12 07:44:23 +0000",
  "in_reply_to_screen_name" : "glyn_dk",
  "in_reply_to_user_id_str" : "32340834",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fiona Nielsen",
      "screen_name" : "glyn_dk",
      "indices" : [ 3, 11 ],
      "id_str" : "32340834",
      "id" : 32340834
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 109, 125 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "631370541518225408",
  "text" : "RT @glyn_dk: \"members of public might visit sites like OpenSNP specifically built to openly host human data\" @gedankenstuecke \nhttp:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 96, 112 ],
        "id_str" : "14286491",
        "id" : 14286491
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/6z02CgqorB",
        "expanded_url" : "http:\/\/blog.oup.com\/2015\/08\/genomically-speaking",
        "display_url" : "blog.oup.com\/2015\/08\/genomi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "631360700758261760",
    "text" : "\"members of public might visit sites like OpenSNP specifically built to openly host human data\" @gedankenstuecke \nhttp:\/\/t.co\/6z02CgqorB",
    "id" : 631360700758261760,
    "created_at" : "2015-08-12 07:04:55 +0000",
    "user" : {
      "name" : "Fiona Nielsen",
      "screen_name" : "glyn_dk",
      "protected" : false,
      "id_str" : "32340834",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3409523398\/35ae8a97e778ebb56089e9a9b58ab9b1_normal.png",
      "id" : 32340834,
      "verified" : false
    }
  },
  "id" : 631370541518225408,
  "created_at" : "2015-08-12 07:44:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Richard Ashcroft",
      "screen_name" : "qmulbioethics",
      "indices" : [ 3, 17 ],
      "id_str" : "406131568",
      "id" : 406131568
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Pinker",
      "indices" : [ 50, 57 ]
    }, {
      "text" : "bioethics",
      "indices" : [ 61, 71 ]
    } ],
    "urls" : [ {
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/4gHUou484C",
      "expanded_url" : "http:\/\/velimblog.org\/2015\/08\/11\/on-not-getting-out-of-the-way-a-reflection-on-steven-pinkers-critique-of-bioethics\/",
      "display_url" : "velimblog.org\/2015\/08\/11\/on-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "631232466007793665",
  "text" : "RT @qmulbioethics: Final notice of my response to #Pinker on #bioethics http:\/\/t.co\/4gHUou484C",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Pinker",
        "indices" : [ 31, 38 ]
      }, {
        "text" : "bioethics",
        "indices" : [ 42, 52 ]
      } ],
      "urls" : [ {
        "indices" : [ 53, 75 ],
        "url" : "http:\/\/t.co\/4gHUou484C",
        "expanded_url" : "http:\/\/velimblog.org\/2015\/08\/11\/on-not-getting-out-of-the-way-a-reflection-on-steven-pinkers-critique-of-bioethics\/",
        "display_url" : "velimblog.org\/2015\/08\/11\/on-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "631228173355745280",
    "text" : "Final notice of my response to #Pinker on #bioethics http:\/\/t.co\/4gHUou484C",
    "id" : 631228173355745280,
    "created_at" : "2015-08-11 22:18:18 +0000",
    "user" : {
      "name" : "Richard Ashcroft",
      "screen_name" : "qmulbioethics",
      "protected" : false,
      "id_str" : "406131568",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/918479992350298112\/jvsmwKAD_normal.jpg",
      "id" : 406131568,
      "verified" : false
    }
  },
  "id" : 631232466007793665,
  "created_at" : "2015-08-11 22:35:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/3f7MrzTH77",
      "expanded_url" : "https:\/\/twitter.com\/john_overholt\/status\/631229471325061120",
      "display_url" : "twitter.com\/john_overholt\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11402899869728, 8.753558853649304 ]
  },
  "id_str" : "631230590247956480",
  "text" : "Well, I guess you could easily mistake the Book of Kells for a Burger King napkin\u2026 https:\/\/t.co\/3f7MrzTH77",
  "id" : 631230590247956480,
  "created_at" : "2015-08-11 22:27:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JExpMed",
      "screen_name" : "JExpMed",
      "indices" : [ 3, 11 ],
      "id_str" : "75302402",
      "id" : 75302402
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/CNrixe0pyr",
      "expanded_url" : "http:\/\/www.thespectroscope.com\/read\/want-to-be-ethical-in-science-speak-up-by-lenny-teytelman-321",
      "display_url" : "thespectroscope.com\/read\/want-to-b\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "631227878106112000",
  "text" : "RT @JExpMed: \"By keeping silent, I am honoring a single author and disrespecting a world of researchers\"\nhttp:\/\/t.co\/CNrixe0pyr http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/JExpMed\/status\/631208478338613249\/photo\/1",
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/LDkDyaKaaH",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CMKAxCpUEAAkrsB.jpg",
        "id_str" : "631208477797388288",
        "id" : 631208477797388288,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CMKAxCpUEAAkrsB.jpg",
        "sizes" : [ {
          "h" : 231,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 231,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 231,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 231,
          "resize" : "fit",
          "w" : 500
        } ],
        "display_url" : "pic.twitter.com\/LDkDyaKaaH"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 92, 114 ],
        "url" : "http:\/\/t.co\/CNrixe0pyr",
        "expanded_url" : "http:\/\/www.thespectroscope.com\/read\/want-to-be-ethical-in-science-speak-up-by-lenny-teytelman-321",
        "display_url" : "thespectroscope.com\/read\/want-to-b\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "631208478338613249",
    "text" : "\"By keeping silent, I am honoring a single author and disrespecting a world of researchers\"\nhttp:\/\/t.co\/CNrixe0pyr http:\/\/t.co\/LDkDyaKaaH",
    "id" : 631208478338613249,
    "created_at" : "2015-08-11 21:00:03 +0000",
    "user" : {
      "name" : "JExpMed",
      "screen_name" : "JExpMed",
      "protected" : false,
      "id_str" : "75302402",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/733734404112031744\/jN3RxlJS_normal.jpg",
      "id" : 75302402,
      "verified" : false
    }
  },
  "id" : 631227878106112000,
  "created_at" : "2015-08-11 22:17:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "canoeporn",
      "indices" : [ 57, 67 ]
    } ],
    "urls" : [ {
      "indices" : [ 68, 91 ],
      "url" : "https:\/\/t.co\/VD0fbHVp0k",
      "expanded_url" : "https:\/\/instagram.com\/p\/6QNzvDhwqc\/",
      "display_url" : "instagram.com\/p\/6QNzvDhwqc\/"
    } ]
  },
  "geo" : { },
  "id_str" : "631172330572632064",
  "text" : "Wow, this hashtag already is a thing with over 70 posts! #canoeporn https:\/\/t.co\/VD0fbHVp0k",
  "id" : 631172330572632064,
  "created_at" : "2015-08-11 18:36:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/l22G8V4pwB",
      "expanded_url" : "https:\/\/twitter.com\/kaythaney\/status\/631142033055436800",
      "display_url" : "twitter.com\/kaythaney\/stat\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11400299790224, 8.753405446400874 ]
  },
  "id_str" : "631165245122289665",
  "text" : "If you are based in the UK, US or Canada, this is looks like a great opportunity! https:\/\/t.co\/l22G8V4pwB",
  "id" : 631165245122289665,
  "created_at" : "2015-08-11 18:08:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Brechler",
      "screen_name" : "plaetzchen",
      "indices" : [ 0, 11 ],
      "id_str" : "14305613",
      "id" : 14305613
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "631136634956812289",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11408162152664, 8.75338015603225 ]
  },
  "id_str" : "631137655242260480",
  "in_reply_to_user_id" : 14305613,
  "text" : "@plaetzchen \uD83D\uDE97\uD83D\uDCA8",
  "id" : 631137655242260480,
  "in_reply_to_status_id" : 631136634956812289,
  "created_at" : "2015-08-11 16:18:37 +0000",
  "in_reply_to_screen_name" : "plaetzchen",
  "in_reply_to_user_id_str" : "14305613",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "latergram",
      "indices" : [ 61, 71 ]
    } ],
    "urls" : [ {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/w3KbMGEDII",
      "expanded_url" : "https:\/\/instagram.com\/p\/6P14JLhwqh\/",
      "display_url" : "instagram.com\/p\/6P14JLhwqh\/"
    } ]
  },
  "geo" : { },
  "id_str" : "631119702878748673",
  "text" : "Where the grass is green and the phone reception is abysmal. #latergram https:\/\/t.co\/w3KbMGEDII",
  "id" : 631119702878748673,
  "created_at" : "2015-08-11 15:07:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1046654489358, 8.765332493939217 ]
  },
  "id_str" : "631089453503782912",
  "text" : "My first visit to the tax office. Really growing old it seems.",
  "id" : 631089453503782912,
  "created_at" : "2015-08-11 13:07:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/tNlxHorBp5",
      "expanded_url" : "https:\/\/thescienceweb.wordpress.com\/2015\/08\/10\/loud-incompetent-scientists-still-dominating-conference-calls\/",
      "display_url" : "thescienceweb.wordpress.com\/2015\/08\/10\/lou\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11403594963615, 8.753334849322334 ]
  },
  "id_str" : "631048942151692288",
  "text" : "\u00ABscience selects for arrogant, loud, brash, annoying men who are capable of ruthlessly marketing their own brand\u00BB https:\/\/t.co\/tNlxHorBp5",
  "id" : 631048942151692288,
  "created_at" : "2015-08-11 10:26:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1140323735257, 8.753334164065018 ]
  },
  "id_str" : "631046887374757888",
  "text" : "\u00ABFor the company mission: Add \u2018biological\u2019 in front of \u2018data analysis\u2019. And maybe also add \u2018done with organically farmed bits\u2019 at the end?\u00BB",
  "id" : 631046887374757888,
  "created_at" : "2015-08-11 10:17:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Take-Home Message",
      "screen_name" : "TakeHomeMessage",
      "indices" : [ 3, 19 ],
      "id_str" : "3226741196",
      "id" : 3226741196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "631019311923101696",
  "text" : "RT @TakeHomeMessage: \"Longer reads, longer reads! My kingdom for some longer reads!\" is sort of the theme of our latest comic http:\/\/t.co\/U\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 105, 127 ],
        "url" : "http:\/\/t.co\/UPhqFsGVE9",
        "expanded_url" : "http:\/\/buff.ly\/1TiIXYd",
        "display_url" : "buff.ly\/1TiIXYd"
      } ]
    },
    "geo" : { },
    "id_str" : "630965275077279745",
    "text" : "\"Longer reads, longer reads! My kingdom for some longer reads!\" is sort of the theme of our latest comic http:\/\/t.co\/UPhqFsGVE9",
    "id" : 630965275077279745,
    "created_at" : "2015-08-11 04:53:39 +0000",
    "user" : {
      "name" : "Take-Home Message",
      "screen_name" : "TakeHomeMessage",
      "protected" : false,
      "id_str" : "3226741196",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/606945141081841664\/nTKi3T13_normal.png",
      "id" : 3226741196,
      "verified" : false
    }
  },
  "id" : 631019311923101696,
  "created_at" : "2015-08-11 08:28:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "samantha based clark",
      "screen_name" : "eltonjohn",
      "indices" : [ 0, 10 ],
      "id_str" : "15661851",
      "id" : 15661851
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "630940063300485120",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11397923905331, 8.75341152996065 ]
  },
  "id_str" : "631002858809331712",
  "in_reply_to_user_id" : 15661851,
  "text" : "@eltonjohn that\u2019s my natural color. :)",
  "id" : 631002858809331712,
  "in_reply_to_status_id" : 630940063300485120,
  "created_at" : "2015-08-11 07:22:59 +0000",
  "in_reply_to_screen_name" : "eltonjohn",
  "in_reply_to_user_id_str" : "15661851",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "630891133330137088",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11403393725588, 8.753331803646741 ]
  },
  "id_str" : "630893710864220160",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot the crowd I have to play\u2026 \uD83D\uDE39",
  "id" : 630893710864220160,
  "in_reply_to_status_id" : 630891133330137088,
  "created_at" : "2015-08-11 00:09:16 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "samantha based clark",
      "screen_name" : "eltonjohn",
      "indices" : [ 0, 10 ],
      "id_str" : "15661851",
      "id" : 15661851
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "630815886589468679",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11403343920144, 8.753332004982203 ]
  },
  "id_str" : "630890305563271168",
  "in_reply_to_user_id" : 15661851,
  "text" : "@eltonjohn and now for a really new one. nearly totally blonde and with the correct pair of glasses. ;-)",
  "id" : 630890305563271168,
  "in_reply_to_status_id" : 630815886589468679,
  "created_at" : "2015-08-10 23:55:44 +0000",
  "in_reply_to_screen_name" : "eltonjohn",
  "in_reply_to_user_id_str" : "15661851",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Austin Richardson",
      "screen_name" : "heyaudy",
      "indices" : [ 0, 8 ],
      "id_str" : "14534523",
      "id" : 14534523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "630865334770237440",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11403373796949, 8.75333341036517 ]
  },
  "id_str" : "630865461899591680",
  "in_reply_to_user_id" : 14534523,
  "text" : "@heyaudy nope, didn\u2019t give it a try in the end. So there\u2019s still tons of it growing. ;)",
  "id" : 630865461899591680,
  "in_reply_to_status_id" : 630865334770237440,
  "created_at" : "2015-08-10 22:17:01 +0000",
  "in_reply_to_screen_name" : "heyaudy",
  "in_reply_to_user_id_str" : "14534523",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "samantha based clark",
      "screen_name" : "eltonjohn",
      "indices" : [ 0, 10 ],
      "id_str" : "15661851",
      "id" : 15661851
    }, {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 87, 96 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "quantifiedself",
      "indices" : [ 63, 78 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "630815886589468679",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.18817534621331, 8.698210400583944 ]
  },
  "id_str" : "630816270682820612",
  "in_reply_to_user_id" : 15661851,
  "text" : "@eltonjohn took up running and quit smoking. I blame the whole #quantifiedself shebang @eramirez for that change ;)",
  "id" : 630816270682820612,
  "in_reply_to_status_id" : 630815886589468679,
  "created_at" : "2015-08-10 19:01:33 +0000",
  "in_reply_to_screen_name" : "eltonjohn",
  "in_reply_to_user_id_str" : "15661851",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "samantha based clark",
      "screen_name" : "eltonjohn",
      "indices" : [ 0, 10 ],
      "id_str" : "15661851",
      "id" : 15661851
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "630814695876919296",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1882413893936, 8.69818594882075 ]
  },
  "id_str" : "630814922688077824",
  "in_reply_to_user_id" : 15661851,
  "text" : "@eltonjohn thanks, lost ~20 kg since the last time we met (and the old avatar picture was done).",
  "id" : 630814922688077824,
  "in_reply_to_status_id" : 630814695876919296,
  "created_at" : "2015-08-10 18:56:12 +0000",
  "in_reply_to_screen_name" : "eltonjohn",
  "in_reply_to_user_id_str" : "15661851",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "samantha based clark",
      "screen_name" : "eltonjohn",
      "indices" : [ 0, 10 ],
      "id_str" : "15661851",
      "id" : 15661851
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 38 ],
      "url" : "https:\/\/t.co\/ucOzNFJHPc",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/629721313582653441",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "630813408594673664",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1882413893936, 8.69818594882075 ]
  },
  "id_str" : "630814569112412160",
  "in_reply_to_user_id" : 15661851,
  "text" : "@eltonjohn see https:\/\/t.co\/ucOzNFJHPc ;)",
  "id" : 630814569112412160,
  "in_reply_to_status_id" : 630813408594673664,
  "created_at" : "2015-08-10 18:54:47 +0000",
  "in_reply_to_screen_name" : "eltonjohn",
  "in_reply_to_user_id_str" : "15661851",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sebastian Greiner",
      "screen_name" : "Seb666",
      "indices" : [ 0, 7 ],
      "id_str" : "2365333778",
      "id" : 2365333778
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "630797590926376960",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11403307476066, 8.753335966802155 ]
  },
  "id_str" : "630797973329420288",
  "in_reply_to_user_id" : 2365333778,
  "text" : "@Seb666 \uD83D\uDC96\uD83C\uDF4E\uD83C\uDF70",
  "id" : 630797973329420288,
  "in_reply_to_status_id" : 630797590926376960,
  "created_at" : "2015-08-10 17:48:51 +0000",
  "in_reply_to_screen_name" : "Seb666",
  "in_reply_to_user_id_str" : "2365333778",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sebastian Greiner",
      "screen_name" : "Seb666",
      "indices" : [ 0, 7 ],
      "id_str" : "2365333778",
      "id" : 2365333778
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "630797129129295872",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11426990419563, 8.752608357197419 ]
  },
  "id_str" : "630797524182388737",
  "in_reply_to_user_id" : 2365333778,
  "text" : "@Seb666 ich hoffe wir bekommen was davon \uD83D\uDE00",
  "id" : 630797524182388737,
  "in_reply_to_status_id" : 630797129129295872,
  "created_at" : "2015-08-10 17:47:04 +0000",
  "in_reply_to_screen_name" : "Seb666",
  "in_reply_to_user_id_str" : "2365333778",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sebastian Greiner",
      "screen_name" : "Seb666",
      "indices" : [ 0, 7 ],
      "id_str" : "2365333778",
      "id" : 2365333778
    }, {
      "name" : "Lara",
      "screen_name" : "alibi_ranch",
      "indices" : [ 8, 20 ],
      "id_str" : "265371167",
      "id" : 265371167
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 29, 35 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "630796557588299776",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1123621175706, 8.752216575210824 ]
  },
  "id_str" : "630796787612319745",
  "in_reply_to_user_id" : 2365333778,
  "text" : "@Seb666 @alibi_ranch Kuchen? @lobot und ich steigen gerade ins Auto!",
  "id" : 630796787612319745,
  "in_reply_to_status_id" : 630796557588299776,
  "created_at" : "2015-08-10 17:44:08 +0000",
  "in_reply_to_screen_name" : "Seb666",
  "in_reply_to_user_id_str" : "2365333778",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "630782563221700613",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11403192780796, 8.753333866867905 ]
  },
  "id_str" : "630782733514604544",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon nein, ob er essbar ist ;)",
  "id" : 630782733514604544,
  "in_reply_to_status_id" : 630782563221700613,
  "created_at" : "2015-08-10 16:48:17 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 34 ],
      "url" : "https:\/\/t.co\/60JjY6oYmH",
      "expanded_url" : "https:\/\/instagram.com\/p\/6NWULMhwpg\/",
      "display_url" : "instagram.com\/p\/6NWULMhwpg\/"
    } ]
  },
  "geo" : { },
  "id_str" : "630768823172530177",
  "text" : "ID please? https:\/\/t.co\/60JjY6oYmH",
  "id" : 630768823172530177,
  "created_at" : "2015-08-10 15:53:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11403305814932, 8.753356020578416 ]
  },
  "id_str" : "630765533957332992",
  "text" : "STD counselor: \u00ABI only recommend getting tested for syphilis if you had sexual intercourse with people having Eastern European accents.\u00BB o_O",
  "id" : 630765533957332992,
  "created_at" : "2015-08-10 15:39:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 70 ],
      "url" : "https:\/\/t.co\/HvZnIsZWLP",
      "expanded_url" : "https:\/\/instagram.com\/p\/6M84m-hwno\/",
      "display_url" : "instagram.com\/p\/6M84m-hwno\/"
    } ]
  },
  "geo" : { },
  "id_str" : "630712899800010752",
  "text" : "on looking fabulously while burning your bread https:\/\/t.co\/HvZnIsZWLP",
  "id" : 630712899800010752,
  "created_at" : "2015-08-10 12:10:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vince Buffalo",
      "screen_name" : "vsbuffalo",
      "indices" : [ 3, 13 ],
      "id_str" : "62183077",
      "id" : 62183077
    }, {
      "name" : "Stan",
      "screen_name" : "mcmc_stan",
      "indices" : [ 128, 138 ],
      "id_str" : "1175299088",
      "id" : 1175299088
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/JZGmZvIVgO",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=pWow8Qe1snQ",
      "display_url" : "youtube.com\/watch?v=pWow8Q\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "630634849120989185",
  "text" : "RT @vsbuffalo: Sure, your MCMC sampling routine may be cool, but does it have a dramatic film trailer?? https:\/\/t.co\/JZGmZvIVgO @mcmc_stan",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Stan",
        "screen_name" : "mcmc_stan",
        "indices" : [ 113, 123 ],
        "id_str" : "1175299088",
        "id" : 1175299088
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 89, 112 ],
        "url" : "https:\/\/t.co\/JZGmZvIVgO",
        "expanded_url" : "https:\/\/www.youtube.com\/watch?v=pWow8Qe1snQ",
        "display_url" : "youtube.com\/watch?v=pWow8Q\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "630603048885161984",
    "text" : "Sure, your MCMC sampling routine may be cool, but does it have a dramatic film trailer?? https:\/\/t.co\/JZGmZvIVgO @mcmc_stan",
    "id" : 630603048885161984,
    "created_at" : "2015-08-10 04:54:17 +0000",
    "user" : {
      "name" : "Vince Buffalo",
      "screen_name" : "vsbuffalo",
      "protected" : false,
      "id_str" : "62183077",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797204252535857152\/I_Bk8pup_normal.jpg",
      "id" : 62183077,
      "verified" : false
    }
  },
  "id" : 630634849120989185,
  "created_at" : "2015-08-10 07:00:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TheConstructor",
      "screen_name" : "TheConstructor",
      "indices" : [ 0, 15 ],
      "id_str" : "14362840",
      "id" : 14362840
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "630485034449915905",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.24565805313294, 7.02391952276884 ]
  },
  "id_str" : "630485130440740864",
  "in_reply_to_user_id" : 14362840,
  "text" : "@TheConstructor ich finde die Kombination aber sehr sch\u00F6n. ;)",
  "id" : 630485130440740864,
  "in_reply_to_status_id" : 630485034449915905,
  "created_at" : "2015-08-09 21:05:43 +0000",
  "in_reply_to_screen_name" : "TheConstructor",
  "in_reply_to_user_id_str" : "14362840",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TheConstructor",
      "screen_name" : "TheConstructor",
      "indices" : [ 0, 15 ],
      "id_str" : "14362840",
      "id" : 14362840
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "630484021575815169",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.24565805313294, 7.02391952276884 ]
  },
  "id_str" : "630484393644158976",
  "in_reply_to_user_id" : 14362840,
  "text" : "@TheConstructor Rockstar Rolf Z.? \uD83D\uDE02",
  "id" : 630484393644158976,
  "in_reply_to_status_id" : 630484021575815169,
  "created_at" : "2015-08-09 21:02:47 +0000",
  "in_reply_to_screen_name" : "TheConstructor",
  "in_reply_to_user_id_str" : "14362840",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 13, 26 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "630483571334074368",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.24567682859604, 7.023909296846971 ]
  },
  "id_str" : "630483775210815488",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch @PhilippBayer yes, would love to have a chat\/do it when we all are available. :)",
  "id" : 630483775210815488,
  "in_reply_to_status_id" : 630483571334074368,
  "created_at" : "2015-08-09 21:00:20 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 93, 106 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "630482930725470208",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.24567682859604, 7.023909296846971 ]
  },
  "id_str" : "630483416522334208",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch also hope to have fixed tax thingy, so we can start collecting non-donations ;) @PhilippBayer",
  "id" : 630483416522334208,
  "in_reply_to_status_id" : 630482930725470208,
  "created_at" : "2015-08-09 20:58:54 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "630482930725470208",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.24567682859604, 7.023909296846971 ]
  },
  "id_str" : "630483165354831872",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch yes, would love to. Let\u2019s do it after cccamp\/your vacation. Than I\u2019ll be back at a place that offers reliable internet.",
  "id" : 630483165354831872,
  "in_reply_to_status_id" : 630482930725470208,
  "created_at" : "2015-08-09 20:57:55 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "630482655008718848",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.24567682859604, 7.023909296846971 ]
  },
  "id_str" : "630482746524237825",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch oh, okay. Then have fun with the alternative vacation :)",
  "id" : 630482746524237825,
  "in_reply_to_status_id" : 630482655008718848,
  "created_at" : "2015-08-09 20:56:15 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.24568173200939, 7.023885408422932 ]
  },
  "id_str" : "630482490210275328",
  "text" : "Played my first gig. In front of ~15 people. At a children\u2019s birthday party. \uD83C\uDFB8",
  "id" : 630482490210275328,
  "created_at" : "2015-08-09 20:55:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "630481754034466816",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.24567527794395, 7.023615343502744 ]
  },
  "id_str" : "630481955914711041",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch that\u2019s too bad. Maybe there are still people trying to get rid of theirs? :(",
  "id" : 630481955914711041,
  "in_reply_to_status_id" : 630481754034466816,
  "created_at" : "2015-08-09 20:53:06 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michelle Moravec",
      "screen_name" : "ProfessMoravec",
      "indices" : [ 3, 18 ],
      "id_str" : "369529173",
      "id" : 369529173
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ilooklikeaprofessor",
      "indices" : [ 20, 40 ]
    } ],
    "urls" : [ {
      "indices" : [ 50, 72 ],
      "url" : "http:\/\/t.co\/VsDdR78MoH",
      "expanded_url" : "http:\/\/bit.ly\/1N0skeR",
      "display_url" : "bit.ly\/1N0skeR"
    } ]
  },
  "geo" : { },
  "id_str" : "630444508736569348",
  "text" : "RT @ProfessMoravec: #Ilooklikeaprofessor my story http:\/\/t.co\/VsDdR78MoH what is yours?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Ilooklikeaprofessor",
        "indices" : [ 0, 20 ]
      } ],
      "urls" : [ {
        "indices" : [ 30, 52 ],
        "url" : "http:\/\/t.co\/VsDdR78MoH",
        "expanded_url" : "http:\/\/bit.ly\/1N0skeR",
        "display_url" : "bit.ly\/1N0skeR"
      } ]
    },
    "geo" : { },
    "id_str" : "630334776419975168",
    "text" : "#Ilooklikeaprofessor my story http:\/\/t.co\/VsDdR78MoH what is yours?",
    "id" : 630334776419975168,
    "created_at" : "2015-08-09 11:08:16 +0000",
    "user" : {
      "name" : "Michelle Moravec",
      "screen_name" : "ProfessMoravec",
      "protected" : false,
      "id_str" : "369529173",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/922252888864256000\/1mZHiWLf_normal.jpg",
      "id" : 369529173,
      "verified" : false
    }
  },
  "id" : 630444508736569348,
  "created_at" : "2015-08-09 18:24:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nazeefa",
      "screen_name" : "NazeefaFatima",
      "indices" : [ 0, 14 ],
      "id_str" : "37054704",
      "id" : 37054704
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "630382466835070976",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.24558688880852, 7.023968245880078 ]
  },
  "id_str" : "630419425531965440",
  "in_reply_to_user_id" : 37054704,
  "text" : "@NazeefaFatima probably magic\/epigenetics could solve the problem :3",
  "id" : 630419425531965440,
  "in_reply_to_status_id" : 630382466835070976,
  "created_at" : "2015-08-09 16:44:38 +0000",
  "in_reply_to_screen_name" : "NazeefaFatima",
  "in_reply_to_user_id_str" : "37054704",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 6, 29 ],
      "url" : "https:\/\/t.co\/oPKTaVRUHi",
      "expanded_url" : "https:\/\/instagram.com\/p\/6K211KBwqE\/",
      "display_url" : "instagram.com\/p\/6K211KBwqE\/"
    } ]
  },
  "geo" : { },
  "id_str" : "630418135385014272",
  "text" : "Dusty https:\/\/t.co\/oPKTaVRUHi",
  "id" : 630418135385014272,
  "created_at" : "2015-08-09 16:39:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kit Stubbs, Ph.D.",
      "screen_name" : "vortacist",
      "indices" : [ 3, 13 ],
      "id_str" : "347340056",
      "id" : 347340056
    }, {
      "name" : "Juliet Kahn",
      "screen_name" : "prynnette",
      "indices" : [ 120, 130 ],
      "id_str" : "828340676",
      "id" : 828340676
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "630415604609101825",
  "text" : "RT @vortacist: I teared up reading this. I'm GQ now but used to be a little girl who gamed with her sister, too. Thanks @prynnette! https:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Juliet Kahn",
        "screen_name" : "prynnette",
        "indices" : [ 105, 115 ],
        "id_str" : "828340676",
        "id" : 828340676
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/04pGN2aNCq",
        "expanded_url" : "https:\/\/twitter.com\/elevenafter\/status\/630333220236718080",
        "display_url" : "twitter.com\/elevenafter\/st\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "630356580006019072",
    "text" : "I teared up reading this. I'm GQ now but used to be a little girl who gamed with her sister, too. Thanks @prynnette! https:\/\/t.co\/04pGN2aNCq",
    "id" : 630356580006019072,
    "created_at" : "2015-08-09 12:34:54 +0000",
    "user" : {
      "name" : "Kit Stubbs, Ph.D.",
      "screen_name" : "vortacist",
      "protected" : false,
      "id_str" : "347340056",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/819220259148177408\/UYT71cyh_normal.jpg",
      "id" : 347340056,
      "verified" : false
    }
  },
  "id" : 630415604609101825,
  "created_at" : "2015-08-09 16:29:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katha",
      "screen_name" : "kathakatze",
      "indices" : [ 0, 11 ],
      "id_str" : "541170257",
      "id" : 541170257
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "630405377809645569",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.24673796893525, 7.026304102320526 ]
  },
  "id_str" : "630405572161110016",
  "in_reply_to_user_id" : 541170257,
  "text" : "@kathakatze sobald wir wieder zuhause sind! \uD83D\uDC83\uD83C\uDFFD\uD83C\uDF08",
  "id" : 630405572161110016,
  "in_reply_to_status_id" : 630405377809645569,
  "created_at" : "2015-08-09 15:49:35 +0000",
  "in_reply_to_screen_name" : "kathakatze",
  "in_reply_to_user_id_str" : "541170257",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katha",
      "screen_name" : "kathakatze",
      "indices" : [ 0, 11 ],
      "id_str" : "541170257",
      "id" : 541170257
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 85 ],
      "url" : "https:\/\/t.co\/NdGRx6KPa5",
      "expanded_url" : "https:\/\/instagram.com\/p\/4uMO6QBwnu\/",
      "display_url" : "instagram.com\/p\/4uMO6QBwnu\/"
    } ]
  },
  "in_reply_to_status_id_str" : "630401142988607488",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.24564664995631, 7.024016158595717 ]
  },
  "id_str" : "630404047531581440",
  "in_reply_to_user_id" : 541170257,
  "text" : "@kathakatze hier im Norden ist es zu kalt f\u00FCr den rosa Rock \uD83D\uDE25 https:\/\/t.co\/NdGRx6KPa5",
  "id" : 630404047531581440,
  "in_reply_to_status_id" : 630401142988607488,
  "created_at" : "2015-08-09 15:43:31 +0000",
  "in_reply_to_screen_name" : "kathakatze",
  "in_reply_to_user_id_str" : "541170257",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul-Olivier Dehaye",
      "screen_name" : "podehaye",
      "indices" : [ 0, 9 ],
      "id_str" : "2219841242",
      "id" : 2219841242
    }, {
      "name" : "cariaso",
      "screen_name" : "cariaso",
      "indices" : [ 10, 18 ],
      "id_str" : "14151263",
      "id" : 14151263
    }, {
      "name" : "Joe Pickrell",
      "screen_name" : "joe_pickrell",
      "indices" : [ 19, 32 ],
      "id_str" : "314758565",
      "id" : 314758565
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "630371317695545344",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.24560555236916, 7.023931669349119 ]
  },
  "id_str" : "630403638792425472",
  "in_reply_to_user_id" : 2219841242,
  "text" : "@podehaye @cariaso @joe_pickrell thanks!",
  "id" : 630403638792425472,
  "in_reply_to_status_id" : 630371317695545344,
  "created_at" : "2015-08-09 15:41:54 +0000",
  "in_reply_to_screen_name" : "podehaye",
  "in_reply_to_user_id_str" : "2219841242",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 78 ],
      "url" : "https:\/\/t.co\/BxkBnBbaUT",
      "expanded_url" : "https:\/\/instagram.com\/p\/6Krf9_Bwvo\/",
      "display_url" : "instagram.com\/p\/6Krf9_Bwvo\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.24549367, 7.031546331 ]
  },
  "id_str" : "630393195285848064",
  "text" : "\u00ABLooks like you are at Woodstock\u00BB @ Wuppertal Sch\u00F6ller https:\/\/t.co\/BxkBnBbaUT",
  "id" : 630393195285848064,
  "created_at" : "2015-08-09 15:00:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 56 ],
      "url" : "https:\/\/t.co\/9fV4ur0cNz",
      "expanded_url" : "https:\/\/instagram.com\/p\/6KaqtPhwo-\/",
      "display_url" : "instagram.com\/p\/6KaqtPhwo-\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.24549367, 7.031546331 ]
  },
  "id_str" : "630356180297252864",
  "text" : "Enlightened @ Wuppertal Sch\u00F6ller https:\/\/t.co\/9fV4ur0cNz",
  "id" : 630356180297252864,
  "created_at" : "2015-08-09 12:33:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cccamp15",
      "indices" : [ 33, 42 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.24553928156499, 7.023859759799227 ]
  },
  "id_str" : "630149804006502400",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch btw: will you be at #cccamp15? :)",
  "id" : 630149804006502400,
  "created_at" : "2015-08-08 22:53:15 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 74 ],
      "url" : "https:\/\/t.co\/AJRgM8HHDg",
      "expanded_url" : "https:\/\/twitter.com\/Lobot\/status\/630037634275000320",
      "display_url" : "twitter.com\/Lobot\/status\/6\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.2455486839653, 7.023361638525482 ]
  },
  "id_str" : "630127169948241920",
  "text" : "We can\u2019t stop here, this is smelly cheese country. https:\/\/t.co\/AJRgM8HHDg",
  "id" : 630127169948241920,
  "created_at" : "2015-08-08 21:23:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 68 ],
      "url" : "https:\/\/t.co\/lgir4jNPF5",
      "expanded_url" : "https:\/\/instagram.com\/p\/6HwQm0hwg8\/",
      "display_url" : "instagram.com\/p\/6HwQm0hwg8\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.112976651, 8.753795894 ]
  },
  "id_str" : "629981449228300288",
  "text" : "gently up the stream @ Hafentreppe Offenbach https:\/\/t.co\/lgir4jNPF5",
  "id" : 629981449228300288,
  "created_at" : "2015-08-08 11:44:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "thescientists",
      "indices" : [ 117, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11306935460317, 8.753410410144136 ]
  },
  "id_str" : "629922215912452097",
  "text" : "In the 1660s: \u00ABthe only thing a Cambridge education fitted anyone for was to be a competent priest or a bad doctor.\u00BB #thescientists",
  "id" : 629922215912452097,
  "created_at" : "2015-08-08 07:48:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 41 ],
      "url" : "https:\/\/t.co\/wV5l09HdnF",
      "expanded_url" : "https:\/\/instagram.com\/p\/6HQPQ5Bwmp\/",
      "display_url" : "instagram.com\/p\/6HQPQ5Bwmp\/"
    } ]
  },
  "geo" : { },
  "id_str" : "629911034376155136",
  "text" : "down by the water https:\/\/t.co\/wV5l09HdnF",
  "id" : 629911034376155136,
  "created_at" : "2015-08-08 07:04:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aidan Budd\uD83D\uDC3E\uD83D\uDC31",
      "screen_name" : "AidanBudd",
      "indices" : [ 0, 10 ],
      "id_str" : "1435074373",
      "id" : 1435074373
    }, {
      "name" : "Nazeefa",
      "screen_name" : "NazeefaFatima",
      "indices" : [ 11, 25 ],
      "id_str" : "37054704",
      "id" : 37054704
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "629895159677865985",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11403466207285, 8.753334813849689 ]
  },
  "id_str" : "629897789716209664",
  "in_reply_to_user_id" : 1435074373,
  "text" : "@AidanBudd @NazeefaFatima great! Looking forward to contributing more.",
  "id" : 629897789716209664,
  "in_reply_to_status_id" : 629895159677865985,
  "created_at" : "2015-08-08 06:11:50 +0000",
  "in_reply_to_screen_name" : "AidanBudd",
  "in_reply_to_user_id_str" : "1435074373",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aidan Budd\uD83D\uDC3E\uD83D\uDC31",
      "screen_name" : "AidanBudd",
      "indices" : [ 0, 10 ],
      "id_str" : "1435074373",
      "id" : 1435074373
    }, {
      "name" : "Nazeefa",
      "screen_name" : "NazeefaFatima",
      "indices" : [ 11, 25 ],
      "id_str" : "37054704",
      "id" : 37054704
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "623846567250935808",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11403331466311, 8.753333230253576 ]
  },
  "id_str" : "629800342469873664",
  "in_reply_to_user_id" : 1435074373,
  "text" : "@AidanBudd @NazeefaFatima just did a pull request, hope that\u2019s fine too. :)",
  "id" : 629800342469873664,
  "in_reply_to_status_id" : 623846567250935808,
  "created_at" : "2015-08-07 23:44:37 +0000",
  "in_reply_to_screen_name" : "AidanBudd",
  "in_reply_to_user_id_str" : "1435074373",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nazeefa",
      "screen_name" : "NazeefaFatima",
      "indices" : [ 3, 17 ],
      "id_str" : "37054704",
      "id" : 37054704
    }, {
      "name" : "Aidan Budd\uD83D\uDC3E\uD83D\uDC31",
      "screen_name" : "AidanBudd",
      "indices" : [ 22, 32 ],
      "id_str" : "1435074373",
      "id" : 1435074373
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "opensource",
      "indices" : [ 69, 80 ]
    }, {
      "text" : "bioinformatics",
      "indices" : [ 81, 96 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/u43xlXnIGI",
      "expanded_url" : "https:\/\/github.com\/aidanbudd\/bosc2015",
      "display_url" : "github.com\/aidanbudd\/bosc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "629800095865827329",
  "text" : "RT @NazeefaFatima: RT @AidanBudd Join us crowdsourcing an article on #opensource #bioinformatics communities https:\/\/t.co\/u43xlXnIGI :) REA\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Aidan Budd\uD83D\uDC3E\uD83D\uDC31",
        "screen_name" : "AidanBudd",
        "indices" : [ 3, 13 ],
        "id_str" : "1435074373",
        "id" : 1435074373
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "opensource",
        "indices" : [ 50, 61 ]
      }, {
        "text" : "bioinformatics",
        "indices" : [ 62, 77 ]
      } ],
      "urls" : [ {
        "indices" : [ 90, 113 ],
        "url" : "https:\/\/t.co\/u43xlXnIGI",
        "expanded_url" : "https:\/\/github.com\/aidanbudd\/bosc2015",
        "display_url" : "github.com\/aidanbudd\/bosc\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "629794678574063616",
    "text" : "RT @AidanBudd Join us crowdsourcing an article on #opensource #bioinformatics communities https:\/\/t.co\/u43xlXnIGI :) README has more info!",
    "id" : 629794678574063616,
    "created_at" : "2015-08-07 23:22:07 +0000",
    "user" : {
      "name" : "Nazeefa",
      "screen_name" : "NazeefaFatima",
      "protected" : false,
      "id_str" : "37054704",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/930210077885202432\/DY8D8hGM_normal.jpg",
      "id" : 37054704,
      "verified" : false
    }
  },
  "id" : 629800095865827329,
  "created_at" : "2015-08-07 23:43:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ratty McRatface \uD83D\uDC00",
      "screen_name" : "godhika",
      "indices" : [ 0, 8 ],
      "id_str" : "96797688",
      "id" : 96797688
    }, {
      "name" : "malech maltz",
      "screen_name" : "malech",
      "indices" : [ 9, 16 ],
      "id_str" : "784085846391713793",
      "id" : 784085846391713793
    }, {
      "name" : "Katha",
      "screen_name" : "kathakatze",
      "indices" : [ 17, 28 ],
      "id_str" : "541170257",
      "id" : 541170257
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 51 ],
      "url" : "http:\/\/t.co\/ZMIVOl6lqU",
      "expanded_url" : "http:\/\/i2.wp.com\/media.boingboing.net\/wp-content\/uploads\/2015\/08\/ezgif-4128064031.gif?resize=480%2C270",
      "display_url" : "i2.wp.com\/media.boingboi\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "629763357567000576",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11403281137793, 8.753332350632949 ]
  },
  "id_str" : "629782179028029440",
  "in_reply_to_user_id" : 96797688,
  "text" : "@godhika @malech @kathakatze http:\/\/t.co\/ZMIVOl6lqU",
  "id" : 629782179028029440,
  "in_reply_to_status_id" : 629763357567000576,
  "created_at" : "2015-08-07 22:32:26 +0000",
  "in_reply_to_screen_name" : "godhika",
  "in_reply_to_user_id_str" : "96797688",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mrgunn",
      "screen_name" : "mrgunn",
      "indices" : [ 3, 10 ],
      "id_str" : "15237935",
      "id" : 15237935
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 87 ],
      "url" : "https:\/\/t.co\/SOWh6VzIhz",
      "expanded_url" : "https:\/\/twitter.com\/carlmalamud\/status\/629770032591929346",
      "display_url" : "twitter.com\/carlmalamud\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "629776998039187456",
  "text" : "RT @mrgunn: The most entertaining article about copyright ever. https:\/\/t.co\/SOWh6VzIhz",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 52, 75 ],
        "url" : "https:\/\/t.co\/SOWh6VzIhz",
        "expanded_url" : "https:\/\/twitter.com\/carlmalamud\/status\/629770032591929346",
        "display_url" : "twitter.com\/carlmalamud\/st\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "629771869915185153",
    "text" : "The most entertaining article about copyright ever. https:\/\/t.co\/SOWh6VzIhz",
    "id" : 629771869915185153,
    "created_at" : "2015-08-07 21:51:29 +0000",
    "user" : {
      "name" : "mrgunn",
      "screen_name" : "mrgunn",
      "protected" : false,
      "id_str" : "15237935",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/679914371770798080\/FBcokUq2_normal.jpg",
      "id" : 15237935,
      "verified" : false
    }
  },
  "id" : 629776998039187456,
  "created_at" : "2015-08-07 22:11:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fiona Nielsen",
      "screen_name" : "glyn_dk",
      "indices" : [ 3, 11 ],
      "id_str" : "32340834",
      "id" : 32340834
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "journalFightClub",
      "indices" : [ 59, 76 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/UgWjKxaxqs",
      "expanded_url" : "https:\/\/twitter.com\/edyong209\/status\/629414065102848000",
      "display_url" : "twitter.com\/edyong209\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "629768528263053312",
  "text" : "RT @glyn_dk: Best storify of the week, right up there with #journalFightClub  https:\/\/t.co\/UgWjKxaxqs",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "journalFightClub",
        "indices" : [ 46, 63 ]
      } ],
      "urls" : [ {
        "indices" : [ 65, 88 ],
        "url" : "https:\/\/t.co\/UgWjKxaxqs",
        "expanded_url" : "https:\/\/twitter.com\/edyong209\/status\/629414065102848000",
        "display_url" : "twitter.com\/edyong209\/stat\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "629422840656363520",
    "text" : "Best storify of the week, right up there with #journalFightClub  https:\/\/t.co\/UgWjKxaxqs",
    "id" : 629422840656363520,
    "created_at" : "2015-08-06 22:44:33 +0000",
    "user" : {
      "name" : "Fiona Nielsen",
      "screen_name" : "glyn_dk",
      "protected" : false,
      "id_str" : "32340834",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3409523398\/35ae8a97e778ebb56089e9a9b58ab9b1_normal.png",
      "id" : 32340834,
      "verified" : false
    }
  },
  "id" : 629768528263053312,
  "created_at" : "2015-08-07 21:38:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "malech maltz",
      "screen_name" : "malech",
      "indices" : [ 0, 7 ],
      "id_str" : "784085846391713793",
      "id" : 784085846391713793
    }, {
      "name" : "Katha",
      "screen_name" : "kathakatze",
      "indices" : [ 8, 19 ],
      "id_str" : "541170257",
      "id" : 541170257
    }, {
      "name" : "Ratty McRatface \uD83D\uDC00",
      "screen_name" : "godhika",
      "indices" : [ 20, 28 ],
      "id_str" : "96797688",
      "id" : 96797688
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 59 ],
      "url" : "https:\/\/t.co\/uWG4aQJGlG",
      "expanded_url" : "https:\/\/en.m.wikipedia.org\/wiki\/Mock_duck",
      "display_url" : "en.m.wikipedia.org\/wiki\/Mock_duck"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11203402192342, 8.753731185578511 ]
  },
  "id_str" : "629763026556715008",
  "text" : "@malech @kathakatze @godhika nomnom https:\/\/t.co\/uWG4aQJGlG",
  "id" : 629763026556715008,
  "created_at" : "2015-08-07 21:16:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nazeefa",
      "screen_name" : "NazeefaFatima",
      "indices" : [ 0, 14 ],
      "id_str" : "37054704",
      "id" : 37054704
    }, {
      "name" : "Keith Bradnam",
      "screen_name" : "kbradnam",
      "indices" : [ 15, 24 ],
      "id_str" : "17061155",
      "id" : 17061155
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "629742518339563520",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.10668448177176, 8.75463207253139 ]
  },
  "id_str" : "629755370920128512",
  "in_reply_to_user_id" : 37054704,
  "text" : "@NazeefaFatima @kbradnam recently I was asked about short PacBio reads. The person was referring to 6kb+ reads.",
  "id" : 629755370920128512,
  "in_reply_to_status_id" : 629742518339563520,
  "created_at" : "2015-08-07 20:45:55 +0000",
  "in_reply_to_screen_name" : "NazeefaFatima",
  "in_reply_to_user_id_str" : "37054704",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul-Olivier Dehaye",
      "screen_name" : "podehaye",
      "indices" : [ 0, 9 ],
      "id_str" : "2219841242",
      "id" : 2219841242
    }, {
      "name" : "cariaso",
      "screen_name" : "cariaso",
      "indices" : [ 10, 18 ],
      "id_str" : "14151263",
      "id" : 14151263
    }, {
      "name" : "Joe Pickrell",
      "screen_name" : "joe_pickrell",
      "indices" : [ 19, 32 ],
      "id_str" : "314758565",
      "id" : 314758565
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "629744649440231424",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11405481495905, 8.753518452876017 ]
  },
  "id_str" : "629750581175914496",
  "in_reply_to_user_id" : 2219841242,
  "text" : "@podehaye @cariaso @joe_pickrell do you still know which one? Could look it up later if you don\u2019t have access to it right now :)",
  "id" : 629750581175914496,
  "in_reply_to_status_id" : 629744649440231424,
  "created_at" : "2015-08-07 20:26:53 +0000",
  "in_reply_to_screen_name" : "podehaye",
  "in_reply_to_user_id_str" : "2219841242",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "cariaso",
      "screen_name" : "cariaso",
      "indices" : [ 0, 8 ],
      "id_str" : "14151263",
      "id" : 14151263
    }, {
      "name" : "Joe Pickrell",
      "screen_name" : "joe_pickrell",
      "indices" : [ 9, 22 ],
      "id_str" : "314758565",
      "id" : 314758565
    }, {
      "name" : "Paul-Olivier Dehaye",
      "screen_name" : "podehaye",
      "indices" : [ 31, 40 ],
      "id_str" : "2219841242",
      "id" : 2219841242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "629739546339581952",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11924958326865, 8.87006294914416 ]
  },
  "id_str" : "629744130936193024",
  "in_reply_to_user_id" : 14151263,
  "text" : "@cariaso @joe_pickrell I think @podehaye saw the same?",
  "id" : 629744130936193024,
  "in_reply_to_status_id" : 629739546339581952,
  "created_at" : "2015-08-07 20:01:15 +0000",
  "in_reply_to_screen_name" : "cariaso",
  "in_reply_to_user_id_str" : "14151263",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Madeleine Price Ball",
      "screen_name" : "madprime",
      "indices" : [ 0, 9 ],
      "id_str" : "71557700",
      "id" : 71557700
    }, {
      "name" : "Joe Pickrell",
      "screen_name" : "joe_pickrell",
      "indices" : [ 10, 23 ],
      "id_str" : "314758565",
      "id" : 314758565
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "629727555449421824",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.117416377226, 8.875027466573636 ]
  },
  "id_str" : "629731374832971776",
  "in_reply_to_user_id" : 71557700,
  "text" : "@madprime @joe_pickrell I would love a system that allows that kind of interaction w\/o spam though ;)",
  "id" : 629731374832971776,
  "in_reply_to_status_id" : 629727555449421824,
  "created_at" : "2015-08-07 19:10:34 +0000",
  "in_reply_to_screen_name" : "madprime",
  "in_reply_to_user_id_str" : "71557700",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Misha Angrist",
      "screen_name" : "MishaAngrist",
      "indices" : [ 0, 13 ],
      "id_str" : "116877838",
      "id" : 116877838
    }, {
      "name" : "Madeleine Price Ball",
      "screen_name" : "madprime",
      "indices" : [ 14, 23 ],
      "id_str" : "71557700",
      "id" : 71557700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 56 ],
      "url" : "https:\/\/t.co\/ucOzNFJHPc",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/629721313582653441",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "629726502473629696",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11683710389782, 8.813370270662768 ]
  },
  "id_str" : "629726781348687872",
  "in_reply_to_user_id" : 116877838,
  "text" : "@MishaAngrist @madprime also see https:\/\/t.co\/ucOzNFJHPc",
  "id" : 629726781348687872,
  "in_reply_to_status_id" : 629726502473629696,
  "created_at" : "2015-08-07 18:52:19 +0000",
  "in_reply_to_screen_name" : "MishaAngrist",
  "in_reply_to_user_id_str" : "116877838",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Misha Angrist",
      "screen_name" : "MishaAngrist",
      "indices" : [ 0, 13 ],
      "id_str" : "116877838",
      "id" : 116877838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "629726447368806400",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11683710389782, 8.813370270662768 ]
  },
  "id_str" : "629726687853473792",
  "in_reply_to_user_id" : 116877838,
  "text" : "@MishaAngrist thanks :)",
  "id" : 629726687853473792,
  "in_reply_to_status_id" : 629726447368806400,
  "created_at" : "2015-08-07 18:51:56 +0000",
  "in_reply_to_screen_name" : "MishaAngrist",
  "in_reply_to_user_id_str" : "116877838",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Madeleine Price Ball",
      "screen_name" : "madprime",
      "indices" : [ 0, 9 ],
      "id_str" : "71557700",
      "id" : 71557700
    }, {
      "name" : "Joe Pickrell",
      "screen_name" : "joe_pickrell",
      "indices" : [ 10, 23 ],
      "id_str" : "314758565",
      "id" : 314758565
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "629725356589756416",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11683710389782, 8.813370270662768 ]
  },
  "id_str" : "629726640029978624",
  "in_reply_to_user_id" : 71557700,
  "text" : "@madprime @joe_pickrell it\u2019s only that we\u2019re not offering such a thing to the general public due to spam protection ;)",
  "id" : 629726640029978624,
  "in_reply_to_status_id" : 629725356589756416,
  "created_at" : "2015-08-07 18:51:45 +0000",
  "in_reply_to_screen_name" : "madprime",
  "in_reply_to_user_id_str" : "71557700",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Madeleine Price Ball",
      "screen_name" : "madprime",
      "indices" : [ 0, 9 ],
      "id_str" : "71557700",
      "id" : 71557700
    }, {
      "name" : "Joe Pickrell",
      "screen_name" : "joe_pickrell",
      "indices" : [ 10, 23 ],
      "id_str" : "314758565",
      "id" : 314758565
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "629725356589756416",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11683710389782, 8.813370270662768 ]
  },
  "id_str" : "629726472408858624",
  "in_reply_to_user_id" : 71557700,
  "text" : "@madprime @joe_pickrell thanks, will have a look into it. But sending out mass mailings from our backend also shouldn\u2019t be a problem.",
  "id" : 629726472408858624,
  "in_reply_to_status_id" : 629725356589756416,
  "created_at" : "2015-08-07 18:51:05 +0000",
  "in_reply_to_screen_name" : "madprime",
  "in_reply_to_user_id_str" : "71557700",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Pickrell",
      "screen_name" : "joe_pickrell",
      "indices" : [ 0, 13 ],
      "id_str" : "314758565",
      "id" : 314758565
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "629726046447902720",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11643309616495, 8.812087923296552 ]
  },
  "id_str" : "629726306796740608",
  "in_reply_to_user_id" : 314758565,
  "text" : "@joe_pickrell perfect. I\u2019ll also be on vacation\/travel from tomorrow. DM me your email than I\u2019ll get in touch :-)",
  "id" : 629726306796740608,
  "in_reply_to_status_id" : 629726046447902720,
  "created_at" : "2015-08-07 18:50:25 +0000",
  "in_reply_to_screen_name" : "joe_pickrell",
  "in_reply_to_user_id_str" : "314758565",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Pickrell",
      "screen_name" : "joe_pickrell",
      "indices" : [ 0, 13 ],
      "id_str" : "314758565",
      "id" : 314758565
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "629724484136779776",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.10821899869489, 8.764507547029075 ]
  },
  "id_str" : "629725048136433664",
  "in_reply_to_user_id" : 314758565,
  "text" : "@joe_pickrell \u2026results. We could send them out from our side through the backend if you like. :)",
  "id" : 629725048136433664,
  "in_reply_to_status_id" : 629724484136779776,
  "created_at" : "2015-08-07 18:45:25 +0000",
  "in_reply_to_screen_name" : "joe_pickrell",
  "in_reply_to_user_id_str" : "314758565",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Pickrell",
      "screen_name" : "joe_pickrell",
      "indices" : [ 0, 13 ],
      "id_str" : "314758565",
      "id" : 314758565
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "629724484136779776",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.10718626440512, 8.765487559147891 ]
  },
  "id_str" : "629724930997886976",
  "in_reply_to_user_id" : 314758565,
  "text" : "@joe_pickrell nice! We don\u2019t offer an easy way to send out individualized mass mailings right now. But would be happy to distribute those\u2026",
  "id" : 629724930997886976,
  "in_reply_to_status_id" : 629724484136779776,
  "created_at" : "2015-08-07 18:44:57 +0000",
  "in_reply_to_screen_name" : "joe_pickrell",
  "in_reply_to_user_id_str" : "314758565",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/n1yQLDHGwD",
      "expanded_url" : "https:\/\/dl.dropboxusercontent.com\/u\/170329\/nbt.3309.pdf",
      "display_url" : "dl.dropboxusercontent.com\/u\/170329\/nbt.3\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "629712053876457472",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11403572553463, 8.753334197868108 ]
  },
  "id_str" : "629721313582653441",
  "in_reply_to_user_id" : 14286491,
  "text" : "Whops, I did the most human thing and somehow a PDF copy of \u201CTo share is human\u201D ended up being freely accessible. https:\/\/t.co\/n1yQLDHGwD",
  "id" : 629721313582653441,
  "in_reply_to_status_id" : 629712053876457472,
  "created_at" : "2015-08-07 18:30:35 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Madeleine Price Ball",
      "screen_name" : "madprime",
      "indices" : [ 0, 9 ],
      "id_str" : "71557700",
      "id" : 71557700
    }, {
      "name" : "Misha Angrist",
      "screen_name" : "MishaAngrist",
      "indices" : [ 16, 29 ],
      "id_str" : "116877838",
      "id" : 116877838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "629714550934401025",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11212794114846, 8.753720792018578 ]
  },
  "id_str" : "629716809650962432",
  "in_reply_to_user_id" : 71557700,
  "text" : "@madprime maybe @MishaAngrist can help us out via email?",
  "id" : 629716809650962432,
  "in_reply_to_status_id" : 629714550934401025,
  "created_at" : "2015-08-07 18:12:41 +0000",
  "in_reply_to_screen_name" : "madprime",
  "in_reply_to_user_id_str" : "71557700",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Misha Angrist",
      "screen_name" : "MishaAngrist",
      "indices" : [ 77, 90 ],
      "id_str" : "116877838",
      "id" : 116877838
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/629712053876457472\/photo\/1",
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/qWKxS125bX",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CL0vw-MWsAEtSjS.png",
      "id_str" : "629712041276780545",
      "id" : 629712041276780545,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CL0vw-MWsAEtSjS.png",
      "sizes" : [ {
        "h" : 1334,
        "resize" : "fit",
        "w" : 750
      }, {
        "h" : 1334,
        "resize" : "fit",
        "w" : 750
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 382
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 675
      } ],
      "display_url" : "pic.twitter.com\/qWKxS125bX"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "629711373832994816",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11099379253321, 8.683980006158501 ]
  },
  "id_str" : "629712053876457472",
  "in_reply_to_user_id" : 116877838,
  "text" : "Sharing is human, apparently so is asking horrible prices to read about it . @MishaAngrist http:\/\/t.co\/qWKxS125bX",
  "id" : 629712053876457472,
  "in_reply_to_status_id" : 629711373832994816,
  "created_at" : "2015-08-07 17:53:47 +0000",
  "in_reply_to_screen_name" : "MishaAngrist",
  "in_reply_to_user_id_str" : "116877838",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TheConstructor",
      "screen_name" : "TheConstructor",
      "indices" : [ 0, 15 ],
      "id_str" : "14362840",
      "id" : 14362840
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "629687371185917952",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11354184248495, 8.75460181386094 ]
  },
  "id_str" : "629688967902969856",
  "in_reply_to_user_id" : 14362840,
  "text" : "@TheConstructor der Mann auf dem Profilfoto wusste auch noch nicht wieviel Lebenszeit er verlieren wird wegen der Brille die er dort tr\u00E4gt \uD83D\uDE1B",
  "id" : 629688967902969856,
  "in_reply_to_status_id" : 629687371185917952,
  "created_at" : "2015-08-07 16:22:03 +0000",
  "in_reply_to_screen_name" : "TheConstructor",
  "in_reply_to_user_id_str" : "14362840",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonas",
      "screen_name" : "lsanoj",
      "indices" : [ 0, 7 ],
      "id_str" : "18918915",
      "id" : 18918915
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "629686293451141124",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.10770745114433, 8.757829936229397 ]
  },
  "id_str" : "629686900631183361",
  "in_reply_to_user_id" : 18918915,
  "text" : "@lsanoj und ich nach einem langen Tag leider ins Bett \uD83D\uDE13",
  "id" : 629686900631183361,
  "in_reply_to_status_id" : 629686293451141124,
  "created_at" : "2015-08-07 16:13:50 +0000",
  "in_reply_to_screen_name" : "lsanoj",
  "in_reply_to_user_id_str" : "18918915",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/629686103579226112\/photo\/1",
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/NjXkUTsMsg",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CL0YLMeXAAEEx7h.jpg",
      "id_str" : "629686103507927041",
      "id" : 629686103507927041,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CL0YLMeXAAEEx7h.jpg",
      "sizes" : [ {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      }, {
        "h" : 1049,
        "resize" : "fit",
        "w" : 787
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1049,
        "resize" : "fit",
        "w" : 787
      }, {
        "h" : 1049,
        "resize" : "fit",
        "w" : 787
      } ],
      "display_url" : "pic.twitter.com\/NjXkUTsMsg"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "629686103579226112",
  "text" : "Only took a month, finally I can see again! \uD83D\uDC53\uD83D\uDC53 http:\/\/t.co\/NjXkUTsMsg",
  "id" : 629686103579226112,
  "created_at" : "2015-08-07 16:10:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/qJyQK5neZk",
      "expanded_url" : "http:\/\/www.theheartradio.org\/heatwave\/thepspot",
      "display_url" : "theheartradio.org\/heatwave\/theps\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11399312633472, 8.7532805257305 ]
  },
  "id_str" : "629683212311203840",
  "text" : "fun interviews to conduct: The P-spot. http:\/\/t.co\/qJyQK5neZk",
  "id" : 629683212311203840,
  "created_at" : "2015-08-07 15:59:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/eD5gckgDA1",
      "expanded_url" : "http:\/\/magazine.jhsph.edu\/2015\/summer\/forum\/rethinking-put-the-ph-back-in-phd\/index.html\/",
      "display_url" : "magazine.jhsph.edu\/2015\/summer\/fo\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17224941845327, 8.627601355264549 ]
  },
  "id_str" : "629633811320545280",
  "text" : "On putting the Ph back in PhD \u00ABI refuse to accept that we can\u2019t do better.\u00BB http:\/\/t.co\/eD5gckgDA1",
  "id" : 629633811320545280,
  "created_at" : "2015-08-07 12:42:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GigaScience",
      "screen_name" : "GigaScience",
      "indices" : [ 0, 12 ],
      "id_str" : "208988759",
      "id" : 208988759
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "629621935974936576",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722305994068, 8.627615344123745 ]
  },
  "id_str" : "629622080317849601",
  "in_reply_to_user_id" : 208988759,
  "text" : "@GigaScience alcohol-induced powerpoint-karaoke!",
  "id" : 629622080317849601,
  "in_reply_to_status_id" : 629621935974936576,
  "created_at" : "2015-08-07 11:56:16 +0000",
  "in_reply_to_screen_name" : "GigaScience",
  "in_reply_to_user_id_str" : "208988759",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "629621626418634752",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722305994068, 8.627615344123745 ]
  },
  "id_str" : "629621902504501248",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot drug trading \uD83D\uDC89, but \uD83D\uDE4A. ;)",
  "id" : 629621902504501248,
  "in_reply_to_status_id" : 629621626418634752,
  "created_at" : "2015-08-07 11:55:34 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GigaScience",
      "screen_name" : "GigaScience",
      "indices" : [ 0, 12 ],
      "id_str" : "208988759",
      "id" : 208988759
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "629621268623392768",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722305994068, 8.627615344123745 ]
  },
  "id_str" : "629621674636386304",
  "in_reply_to_user_id" : 208988759,
  "text" : "@GigaScience sounds like I will have such a test before coming for my visit :D",
  "id" : 629621674636386304,
  "in_reply_to_status_id" : 629621268623392768,
  "created_at" : "2015-08-07 11:54:39 +0000",
  "in_reply_to_screen_name" : "GigaScience",
  "in_reply_to_user_id_str" : "208988759",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GigaScience",
      "screen_name" : "GigaScience",
      "indices" : [ 0, 12 ],
      "id_str" : "208988759",
      "id" : 208988759
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "629620222295543808",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17222680326712, 8.627607612305995 ]
  },
  "id_str" : "629620555847737345",
  "in_reply_to_user_id" : 208988759,
  "text" : "@GigaScience sweet, though I guess the results will be unsurprising for the whole GigaScience-Team :D",
  "id" : 629620555847737345,
  "in_reply_to_status_id" : 629620222295543808,
  "created_at" : "2015-08-07 11:50:12 +0000",
  "in_reply_to_screen_name" : "GigaScience",
  "in_reply_to_user_id_str" : "208988759",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GigaScience",
      "screen_name" : "GigaScience",
      "indices" : [ 0, 12 ],
      "id_str" : "208988759",
      "id" : 208988759
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "629617770297032705",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17222823967453, 8.627602596537729 ]
  },
  "id_str" : "629618600383508480",
  "in_reply_to_user_id" : 208988759,
  "text" : "@GigaScience how much do you have to collect in total?",
  "id" : 629618600383508480,
  "in_reply_to_status_id" : 629617770297032705,
  "created_at" : "2015-08-07 11:42:26 +0000",
  "in_reply_to_screen_name" : "GigaScience",
  "in_reply_to_user_id_str" : "208988759",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GigaScience",
      "screen_name" : "GigaScience",
      "indices" : [ 0, 12 ],
      "id_str" : "208988759",
      "id" : 208988759
    }, {
      "name" : "Rob Davidson",
      "screen_name" : "bobbledavidson",
      "indices" : [ 13, 28 ],
      "id_str" : "20198007",
      "id" : 20198007
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "629614993604882432",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17225800319446, 8.62758315707594 ]
  },
  "id_str" : "629617181584699392",
  "in_reply_to_user_id" : 208988759,
  "text" : "@GigaScience @bobbledavidson looks like a pro in doing this!",
  "id" : 629617181584699392,
  "in_reply_to_status_id" : 629614993604882432,
  "created_at" : "2015-08-07 11:36:48 +0000",
  "in_reply_to_screen_name" : "GigaScience",
  "in_reply_to_user_id_str" : "208988759",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17222552096285, 8.627664527534703 ]
  },
  "id_str" : "629609162251616256",
  "text" : "Large DTC company writes to openSNP on whether we want to do advertising with them. That\u2019s interesting. And totally unrealistic given our \uD83D\uDCB8.",
  "id" : 629609162251616256,
  "created_at" : "2015-08-07 11:04:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/Su2QYKBXvS",
      "expanded_url" : "http:\/\/biopython.org\/DIST\/docs\/tutorial\/Tutorial.html#htoc13",
      "display_url" : "biopython.org\/DIST\/docs\/tuto\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17225145737365, 8.627603649655441 ]
  },
  "id_str" : "629561515994185728",
  "text" : "\u00ABI love parsing \u2013 please don\u2019t stop talking about it!\u00BB Probably my work for the day. http:\/\/t.co\/Su2QYKBXvS",
  "id" : 629561515994185728,
  "created_at" : "2015-08-07 07:55:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 14, 20 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "629556639520002048",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17224231549725, 8.627603093766819 ]
  },
  "id_str" : "629556824329613312",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @Lobot yes, but if we agree that it\u2019s improbable to be &gt;, then why is the result interesting, as it has to be universally &lt;?",
  "id" : 629556824329613312,
  "in_reply_to_status_id" : 629556639520002048,
  "created_at" : "2015-08-07 07:36:58 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 14, 20 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "629555064613400576",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17220508218175, 8.62765441820618 ]
  },
  "id_str" : "629556270379495424",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @Lobot the \u201Cstriking\u201D result is that it\u2019s always &lt; chance, not &gt;?",
  "id" : 629556270379495424,
  "in_reply_to_status_id" : 629555064613400576,
  "created_at" : "2015-08-07 07:34:46 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 14, 20 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "629555064613400576",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17218395352642, 8.627683220104668 ]
  },
  "id_str" : "629556102645084160",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @Lobot I wonder if this isn\u2019t expected, as language somewhat by definition must be non-random?",
  "id" : 629556102645084160,
  "in_reply_to_status_id" : 629555064613400576,
  "created_at" : "2015-08-07 07:34:06 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 14, 20 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "629554591521091584",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17232827865482, 8.627539007899195 ]
  },
  "id_str" : "629554819997540352",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @Lobot if I got it correctly their comparison was basically to a baseline of shuffled sentences?",
  "id" : 629554819997540352,
  "in_reply_to_status_id" : 629554591521091584,
  "created_at" : "2015-08-07 07:29:00 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Keith Bradnam",
      "screen_name" : "kbradnam",
      "indices" : [ 3, 12 ],
      "id_str" : "17061155",
      "id" : 17061155
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ACGT",
      "indices" : [ 18, 23 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/B4l6rKipTl",
      "expanded_url" : "http:\/\/buff.ly\/1Ebpyw4",
      "display_url" : "buff.ly\/1Ebpyw4"
    } ]
  },
  "geo" : { },
  "id_str" : "629552805762760708",
  "text" : "RT @kbradnam: New #ACGT link post \u2014\u00A0Get With the Program: DIY tips for adding coding to your analysis arsenal http:\/\/t.co\/B4l6rKipTl",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ACGT",
        "indices" : [ 4, 9 ]
      } ],
      "urls" : [ {
        "indices" : [ 96, 118 ],
        "url" : "http:\/\/t.co\/B4l6rKipTl",
        "expanded_url" : "http:\/\/buff.ly\/1Ebpyw4",
        "display_url" : "buff.ly\/1Ebpyw4"
      } ]
    },
    "geo" : { },
    "id_str" : "629344493607759872",
    "text" : "New #ACGT link post \u2014\u00A0Get With the Program: DIY tips for adding coding to your analysis arsenal http:\/\/t.co\/B4l6rKipTl",
    "id" : 629344493607759872,
    "created_at" : "2015-08-06 17:33:14 +0000",
    "user" : {
      "name" : "Keith Bradnam",
      "screen_name" : "kbradnam",
      "protected" : false,
      "id_str" : "17061155",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/583756306919489538\/D2fFCYq4_normal.jpg",
      "id" : 17061155,
      "verified" : false
    }
  },
  "id" : 629552805762760708,
  "created_at" : "2015-08-07 07:21:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 83, 89 ],
      "id_str" : "1492631",
      "id" : 1492631
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 94, 107 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/KprgDghHAN",
      "expanded_url" : "http:\/\/arstechnica.co.uk\/science\/2015\/08\/mit-claims-to-have-found-a-language-universal-that-ties-all-languages-together\/",
      "display_url" : "arstechnica.co.uk\/science\/2015\/0\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "629454262183968769",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17222060257541, 8.627609413889422 ]
  },
  "id_str" : "629551821426700288",
  "in_reply_to_user_id" : 121777206,
  "text" : "To me this sounds like \u2018languages aren\u2019t random bits\u2019, which is news at 11ish? \/cc @Lobot \/ht @PhilippBayer http:\/\/t.co\/KprgDghHAN",
  "id" : 629551821426700288,
  "in_reply_to_status_id" : 629454262183968769,
  "created_at" : "2015-08-07 07:17:05 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.16948390971996, 8.621374600391347 ]
  },
  "id_str" : "629342432426115073",
  "text" : "\u00ABOh well, I guess doing a PhD is as good a reason to develop PTSD as any\u2026\u00BB on academic work load.",
  "id" : 629342432426115073,
  "created_at" : "2015-08-06 17:25:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "k e i t h \uD83D\uDC24\uD83E\uDD54",
      "screen_name" : "KeetPotato",
      "indices" : [ 3, 14 ],
      "id_str" : "624661805",
      "id" : 624661805
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/KeetPotato\/status\/629217748934098944\/photo\/1",
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/LCQdGx8GDb",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CLtuNUgWEAAHydO.png",
      "id_str" : "629217748070043648",
      "id" : 629217748070043648,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLtuNUgWEAAHydO.png",
      "sizes" : [ {
        "h" : 410,
        "resize" : "fit",
        "w" : 349
      }, {
        "h" : 410,
        "resize" : "fit",
        "w" : 349
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 410,
        "resize" : "fit",
        "w" : 349
      }, {
        "h" : 410,
        "resize" : "fit",
        "w" : 349
      } ],
      "display_url" : "pic.twitter.com\/LCQdGx8GDb"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "629219413661716481",
  "text" : "RT @KeetPotato: cat lover: \"dogs are idiots\"\nme: \"no they aren't\" [opens newspaper] http:\/\/t.co\/LCQdGx8GDb",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/KeetPotato\/status\/629217748934098944\/photo\/1",
        "indices" : [ 68, 90 ],
        "url" : "http:\/\/t.co\/LCQdGx8GDb",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CLtuNUgWEAAHydO.png",
        "id_str" : "629217748070043648",
        "id" : 629217748070043648,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLtuNUgWEAAHydO.png",
        "sizes" : [ {
          "h" : 410,
          "resize" : "fit",
          "w" : 349
        }, {
          "h" : 410,
          "resize" : "fit",
          "w" : 349
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 410,
          "resize" : "fit",
          "w" : 349
        }, {
          "h" : 410,
          "resize" : "fit",
          "w" : 349
        } ],
        "display_url" : "pic.twitter.com\/LCQdGx8GDb"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "629217748934098944",
    "text" : "cat lover: \"dogs are idiots\"\nme: \"no they aren't\" [opens newspaper] http:\/\/t.co\/LCQdGx8GDb",
    "id" : 629217748934098944,
    "created_at" : "2015-08-06 09:09:36 +0000",
    "user" : {
      "name" : "k e i t h \uD83D\uDC24\uD83E\uDD54",
      "screen_name" : "KeetPotato",
      "protected" : false,
      "id_str" : "624661805",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/875382541364187136\/YSIQaTSz_normal.jpg",
      "id" : 624661805,
      "verified" : false
    }
  },
  "id" : 629219413661716481,
  "created_at" : "2015-08-06 09:16:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 39 ],
      "url" : "https:\/\/t.co\/t6au5ZBhlk",
      "expanded_url" : "https:\/\/www.flickr.com\/photos\/britishlibrary\/11292405163\/in\/album-72157640537276514\/",
      "display_url" : "flickr.com\/photos\/british\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "629214443428294656",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17220956647201, 8.627630356494608 ]
  },
  "id_str" : "629215403970043904",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich soon: https:\/\/t.co\/t6au5ZBhlk",
  "id" : 629215403970043904,
  "in_reply_to_status_id" : 629214443428294656,
  "created_at" : "2015-08-06 09:00:17 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/7fOuhatgfH",
      "expanded_url" : "https:\/\/www.flickr.com\/photos\/britishlibrary\/11231653973\/in\/album-72157640537276514\/",
      "display_url" : "flickr.com\/photos\/british\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "629212919239168000",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17224777601606, 8.627595461447926 ]
  },
  "id_str" : "629213697555177472",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich deshalb radikalisieren sich die Radfahrer so? \u201CLet out my fist with all the power I could put behind it\u201D https:\/\/t.co\/7fOuhatgfH",
  "id" : 629213697555177472,
  "in_reply_to_status_id" : 629212919239168000,
  "created_at" : "2015-08-06 08:53:30 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/7veoM1duQe",
      "expanded_url" : "https:\/\/www.flickr.com\/photos\/britishlibrary\/11186813893\/in\/album-72157640537276514\/",
      "display_url" : "flickr.com\/photos\/british\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "629210575411806208",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17222945228329, 8.627644212061503 ]
  },
  "id_str" : "629211706611400704",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich 6 Jahre fr\u00FCher gab es statt spaceships noch offroad-cycling: https:\/\/t.co\/7veoM1duQe",
  "id" : 629211706611400704,
  "in_reply_to_status_id" : 629210575411806208,
  "created_at" : "2015-08-06 08:45:35 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 55 ],
      "url" : "https:\/\/t.co\/84aiTAhRK9",
      "expanded_url" : "https:\/\/www.flickr.com\/photos\/britishlibrary\/11222525186\/in\/album-72157638850077096\/",
      "display_url" : "flickr.com\/photos\/british\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "629206767889739776",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17224858416374, 8.62759433858712 ]
  },
  "id_str" : "629210231738867716",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich spaceships in 1893 \u26F5\uFE0F https:\/\/t.co\/84aiTAhRK9",
  "id" : 629210231738867716,
  "in_reply_to_status_id" : 629206767889739776,
  "created_at" : "2015-08-06 08:39:44 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 70 ],
      "url" : "http:\/\/t.co\/snrKJ6oT9l",
      "expanded_url" : "http:\/\/www.smbc-comics.com\/index.php?id=3820",
      "display_url" : "smbc-comics.com\/index.php?id=3\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17227931328365, 8.627573705773328 ]
  },
  "id_str" : "629208232809119744",
  "text" : "\u00AB\u2026heaven is pretty much entirely r strategists\u00BB http:\/\/t.co\/snrKJ6oT9l",
  "id" : 629208232809119744,
  "created_at" : "2015-08-06 08:31:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/qjbnDkMpGL",
      "expanded_url" : "http:\/\/boingboing.net\/2015\/08\/05\/british-library-releases-over.html",
      "display_url" : "boingboing.net\/2015\/08\/05\/bri\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17225938728038, 8.627592280041673 ]
  },
  "id_str" : "629205096384081920",
  "text" : "Lovely examples: British Library releases over a million public domain images http:\/\/t.co\/qjbnDkMpGL",
  "id" : 629205096384081920,
  "created_at" : "2015-08-06 08:19:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "629202672390963200",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17227847949948, 8.627574086210158 ]
  },
  "id_str" : "629203396348801024",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich \u2600\uFE0F",
  "id" : 629203396348801024,
  "in_reply_to_status_id" : 629202672390963200,
  "created_at" : "2015-08-06 08:12:34 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "629201893923889156",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172271580744, 8.627577581554592 ]
  },
  "id_str" : "629202028623872000",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich ein altes Bild, aber trotzdem 3 Jahre aktueller als das von davor. ;)",
  "id" : 629202028623872000,
  "in_reply_to_status_id" : 629201893923889156,
  "created_at" : "2015-08-06 08:07:08 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ali",
      "screen_name" : "zoonpolitikon",
      "indices" : [ 0, 14 ],
      "id_str" : "13040652",
      "id" : 13040652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "629200862762692608",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17223805142899, 8.627606806358912 ]
  },
  "id_str" : "629201368402788352",
  "in_reply_to_user_id" : 13040652,
  "text" : "@zoonpolitikon by now I think you could get rid of 95%+ of the admin staff and nothing would change.",
  "id" : 629201368402788352,
  "in_reply_to_status_id" : 629200862762692608,
  "created_at" : "2015-08-06 08:04:30 +0000",
  "in_reply_to_screen_name" : "zoonpolitikon",
  "in_reply_to_user_id_str" : "13040652",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17222552176973, 8.627615434889162 ]
  },
  "id_str" : "629198475238985728",
  "text" : "University administration must be the #1 reason why we\u2019re still stuck on this planet\u2026 \uD83C\uDF0D",
  "id" : 629198475238985728,
  "created_at" : "2015-08-06 07:53:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GigaScience",
      "screen_name" : "GigaScience",
      "indices" : [ 3, 15 ],
      "id_str" : "208988759",
      "id" : 208988759
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "journalrapbattle",
      "indices" : [ 114, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "629192295431192576",
  "text" : "RT @GigaScience: C'mon be a hero\nJust make your data CC0\nDon't be an open data hate-ter\nGigaScience gonna make-ya #journalrapbattle",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "journalrapbattle",
        "indices" : [ 97, 114 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "629108710728597504",
    "text" : "C'mon be a hero\nJust make your data CC0\nDon't be an open data hate-ter\nGigaScience gonna make-ya #journalrapbattle",
    "id" : 629108710728597504,
    "created_at" : "2015-08-06 01:56:19 +0000",
    "user" : {
      "name" : "GigaScience",
      "screen_name" : "GigaScience",
      "protected" : false,
      "id_str" : "208988759",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1404305552\/profile-photo-GigaScience-96x96_normal.jpg",
      "id" : 208988759,
      "verified" : false
    }
  },
  "id" : 629192295431192576,
  "created_at" : "2015-08-06 07:28:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fitbit",
      "screen_name" : "fitbit",
      "indices" : [ 54, 61 ],
      "id_str" : "17424053",
      "id" : 17424053
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17235600413465, 8.627604660576473 ]
  },
  "id_str" : "629191405643112448",
  "text" : "After about 7 months I found the refund check for the @fitbit Force in my mailbox. As good a down payment for an Apple Watch as any I guess\u2026",
  "id" : 629191405643112448,
  "created_at" : "2015-08-06 07:24:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Nicholls",
      "screen_name" : "samstudio8",
      "indices" : [ 3, 14 ],
      "id_str" : "40444555",
      "id" : 40444555
    }, {
      "name" : "Sanger Institute",
      "screen_name" : "sangerinstitute",
      "indices" : [ 73, 89 ],
      "id_str" : "34222024",
      "id" : 34222024
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/anKBHwQbA9",
      "expanded_url" : "http:\/\/samstudio8.github.io\/2015\/07\/31\/bridgebuilding-p3\/",
      "display_url" : "samstudio8.github.io\/2015\/07\/31\/bri\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "629065839032074241",
  "text" : "RT @samstudio8: Why is bioinformatics so hard? Part 3 of my never-ending @sangerinstitute story: http:\/\/t.co\/anKBHwQbA9",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Sanger Institute",
        "screen_name" : "sangerinstitute",
        "indices" : [ 57, 73 ],
        "id_str" : "34222024",
        "id" : 34222024
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 81, 103 ],
        "url" : "http:\/\/t.co\/anKBHwQbA9",
        "expanded_url" : "http:\/\/samstudio8.github.io\/2015\/07\/31\/bridgebuilding-p3\/",
        "display_url" : "samstudio8.github.io\/2015\/07\/31\/bri\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "628972423937925120",
    "text" : "Why is bioinformatics so hard? Part 3 of my never-ending @sangerinstitute story: http:\/\/t.co\/anKBHwQbA9",
    "id" : 628972423937925120,
    "created_at" : "2015-08-05 16:54:46 +0000",
    "user" : {
      "name" : "Sam Nicholls",
      "screen_name" : "samstudio8",
      "protected" : false,
      "id_str" : "40444555",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/750350885335826432\/2R3feTKx_normal.jpg",
      "id" : 40444555,
      "verified" : false
    }
  },
  "id" : 629065839032074241,
  "created_at" : "2015-08-05 23:05:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Yoder \uD83D\uDD96\uD83C\uDFFB",
      "screen_name" : "JBYoder",
      "indices" : [ 3, 11 ],
      "id_str" : "19984919",
      "id" : 19984919
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/JBYoder\/status\/628964930864046080\/photo\/1",
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/s1UVIWAGZF",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CLqIRWpUEAA6qrE.png",
      "id_str" : "628964929689620480",
      "id" : 628964929689620480,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLqIRWpUEAA6qrE.png",
      "sizes" : [ {
        "h" : 823,
        "resize" : "fit",
        "w" : 867
      }, {
        "h" : 823,
        "resize" : "fit",
        "w" : 867
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 823,
        "resize" : "fit",
        "w" : 867
      }, {
        "h" : 645,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/s1UVIWAGZF"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/Jei6uOf0dQ",
      "expanded_url" : "http:\/\/denimandtweed.jbyoder.org\/2015\/08\/queer-in-stem-survey-of-lgbtq-science-professionals-now-published\/",
      "display_url" : "denimandtweed.jbyoder.org\/2015\/08\/queer-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "629020542574665728",
  "text" : "RT @JBYoder: Queer in STEM survey of LGBTQ science professionals now\u00A0published http:\/\/t.co\/Jei6uOf0dQ http:\/\/t.co\/s1UVIWAGZF",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/JBYoder\/status\/628964930864046080\/photo\/1",
        "indices" : [ 89, 111 ],
        "url" : "http:\/\/t.co\/s1UVIWAGZF",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CLqIRWpUEAA6qrE.png",
        "id_str" : "628964929689620480",
        "id" : 628964929689620480,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLqIRWpUEAA6qrE.png",
        "sizes" : [ {
          "h" : 823,
          "resize" : "fit",
          "w" : 867
        }, {
          "h" : 823,
          "resize" : "fit",
          "w" : 867
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 823,
          "resize" : "fit",
          "w" : 867
        }, {
          "h" : 645,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/s1UVIWAGZF"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 66, 88 ],
        "url" : "http:\/\/t.co\/Jei6uOf0dQ",
        "expanded_url" : "http:\/\/denimandtweed.jbyoder.org\/2015\/08\/queer-in-stem-survey-of-lgbtq-science-professionals-now-published\/",
        "display_url" : "denimandtweed.jbyoder.org\/2015\/08\/queer-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "628964930864046080",
    "text" : "Queer in STEM survey of LGBTQ science professionals now\u00A0published http:\/\/t.co\/Jei6uOf0dQ http:\/\/t.co\/s1UVIWAGZF",
    "id" : 628964930864046080,
    "created_at" : "2015-08-05 16:24:59 +0000",
    "user" : {
      "name" : "Jeremy Yoder \uD83D\uDD96\uD83C\uDFFB",
      "screen_name" : "JBYoder",
      "protected" : false,
      "id_str" : "19984919",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/870850169759072256\/r0kxCgGs_normal.jpg",
      "id" : 19984919,
      "verified" : true
    }
  },
  "id" : 629020542574665728,
  "created_at" : "2015-08-05 20:05:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 71 ],
      "url" : "https:\/\/t.co\/IqyudGOeFL",
      "expanded_url" : "https:\/\/cesess.wordpress.com\/2015\/08\/03\/on-the-appropriate-use-of-statistics-in-ecology-an-interview-with-ben-bolker\/",
      "display_url" : "cesess.wordpress.com\/2015\/08\/03\/on-\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17225815021295, 8.627604675248541 ]
  },
  "id_str" : "628945305770307584",
  "text" : "On the Appropriate Use of Statistics in Ecology https:\/\/t.co\/IqyudGOeFL",
  "id" : 628945305770307584,
  "created_at" : "2015-08-05 15:07:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Torsten Seemann",
      "screen_name" : "torstenseemann",
      "indices" : [ 0, 15 ],
      "id_str" : "42558652",
      "id" : 42558652
    }, {
      "name" : "Nick Loman",
      "screen_name" : "pathogenomenick",
      "indices" : [ 16, 32 ],
      "id_str" : "85906238",
      "id" : 85906238
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "628931419184611328",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17226075995406, 8.627592657916539 ]
  },
  "id_str" : "628931736118947841",
  "in_reply_to_user_id" : 42558652,
  "text" : "@torstenseemann @pathogenomenick in that case it might also suffer from the plague. Sell that to Science as secondary finding.",
  "id" : 628931736118947841,
  "in_reply_to_status_id" : 628931419184611328,
  "created_at" : "2015-08-05 14:13:05 +0000",
  "in_reply_to_screen_name" : "torstenseemann",
  "in_reply_to_user_id_str" : "42558652",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Loman",
      "screen_name" : "pathogenomenick",
      "indices" : [ 0, 16 ],
      "id_str" : "85906238",
      "id" : 85906238
    }, {
      "name" : "Torsten Seemann",
      "screen_name" : "torstenseemann",
      "indices" : [ 17, 32 ],
      "id_str" : "42558652",
      "id" : 42558652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "628930905009094656",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17226075995406, 8.627592657916539 ]
  },
  "id_str" : "628931272216289280",
  "in_reply_to_user_id" : 85906238,
  "text" : "@pathogenomenick @torstenseemann full steam head, a Nature publication just came into sight!",
  "id" : 628931272216289280,
  "in_reply_to_status_id" : 628930905009094656,
  "created_at" : "2015-08-05 14:11:14 +0000",
  "in_reply_to_screen_name" : "pathogenomenick",
  "in_reply_to_user_id_str" : "85906238",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Appropriate Tributes",
      "screen_name" : "godtributes",
      "indices" : [ 3, 15 ],
      "id_str" : "2566358196",
      "id" : 2566358196
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 17, 33 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "628930902882713600",
  "text" : "RT @godtributes: @gedankenstuecke \uD83D\uDC95 \uD83D\uDC95 \uD83D\uDC95 \uD83D\uDC95 \uD83D\uDC95 \uD83D\uDC95  FOR THE \uD83D\uDC95  GOD! \uD83C\uDF44 \uD83C\uDF44 \uD83C\uDF44 \uD83C\uDF44  FOR THE \uD83C\uDF44  MONSTER",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/jimkang.com\" rel=\"nofollow\"\u003Ebotsforthebotgod\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 0, 16 ],
        "id_str" : "14286491",
        "id" : 14286491
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "628930807722307585",
    "geo" : { },
    "id_str" : "628930852370677760",
    "in_reply_to_user_id" : 14286491,
    "text" : "@gedankenstuecke \uD83D\uDC95 \uD83D\uDC95 \uD83D\uDC95 \uD83D\uDC95 \uD83D\uDC95 \uD83D\uDC95  FOR THE \uD83D\uDC95  GOD! \uD83C\uDF44 \uD83C\uDF44 \uD83C\uDF44 \uD83C\uDF44  FOR THE \uD83C\uDF44  MONSTER",
    "id" : 628930852370677760,
    "in_reply_to_status_id" : 628930807722307585,
    "created_at" : "2015-08-05 14:09:34 +0000",
    "in_reply_to_screen_name" : "gedankenstuecke",
    "in_reply_to_user_id_str" : "14286491",
    "user" : {
      "name" : "Appropriate Tributes",
      "screen_name" : "godtributes",
      "protected" : false,
      "id_str" : "2566358196",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/816397890897649664\/ENsyhp0G_normal.jpg",
      "id" : 2566358196,
      "verified" : false
    }
  },
  "id" : 628930902882713600,
  "created_at" : "2015-08-05 14:09:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 4, 26 ],
      "url" : "http:\/\/t.co\/avuwCzNMfY",
      "expanded_url" : "http:\/\/unearthedcomics.com\/comics\/lichen-love\/",
      "display_url" : "unearthedcomics.com\/comics\/lichen-\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17226075995406, 8.627592657916539 ]
  },
  "id_str" : "628930807722307585",
  "text" : "\uD83C\uDF44\uD83D\uDC95\uD83C\uDF43 http:\/\/t.co\/avuwCzNMfY",
  "id" : 628930807722307585,
  "created_at" : "2015-08-05 14:09:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 7, 29 ],
      "url" : "http:\/\/t.co\/ulCalnEwcv",
      "expanded_url" : "http:\/\/media.giphy.com\/media\/Qo99TlytAvuww\/giphy.gif",
      "display_url" : "media.giphy.com\/media\/Qo99Tlyt\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "628915921780899840",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17221997537937, 8.627601682797762 ]
  },
  "id_str" : "628916267634794496",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot http:\/\/t.co\/ulCalnEwcv",
  "id" : 628916267634794496,
  "in_reply_to_status_id" : 628915921780899840,
  "created_at" : "2015-08-05 13:11:37 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "628915384842850304",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172231456524, 8.62761248477964 ]
  },
  "id_str" : "628915718302605312",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot Deutschsprechende m\u00F6gen ungewaschen sein, aber immerhin wissen sie das \u201Cheiss\u201D == \u201Cnicht anfassen\u201D? \u2668\uFE0F\u2615\uFE0F",
  "id" : 628915718302605312,
  "in_reply_to_status_id" : 628915384842850304,
  "created_at" : "2015-08-05 13:09:26 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/628911599332524032\/photo\/1",
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/qgiDDPKHB7",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CLpXxAAWIAAVQW7.jpg",
      "id_str" : "628911597298262016",
      "id" : 628911597298262016,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLpXxAAWIAAVQW7.jpg",
      "sizes" : [ {
        "h" : 2448,
        "resize" : "fit",
        "w" : 2448
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/qgiDDPKHB7"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722259159462, 8.627610408225848 ]
  },
  "id_str" : "628911599332524032",
  "text" : "How verbose you have to be in your warnings, depending on the language. http:\/\/t.co\/qgiDDPKHB7",
  "id" : 628911599332524032,
  "created_at" : "2015-08-05 12:53:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nazeefa",
      "screen_name" : "NazeefaFatima",
      "indices" : [ 0, 14 ],
      "id_str" : "37054704",
      "id" : 37054704
    }, {
      "name" : "Dr Beth \uD83D\uDC3A",
      "screen_name" : "PhdGeek",
      "indices" : [ 15, 23 ],
      "id_str" : "27841081",
      "id" : 27841081
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "628886241069658112",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17224523410955, 8.627596788638723 ]
  },
  "id_str" : "628889962411368448",
  "in_reply_to_user_id" : 37054704,
  "text" : "@NazeefaFatima @PhdGeek same here, probably because there\u2019s little understanding of how academia works.",
  "id" : 628889962411368448,
  "in_reply_to_status_id" : 628886241069658112,
  "created_at" : "2015-08-05 11:27:05 +0000",
  "in_reply_to_screen_name" : "NazeefaFatima",
  "in_reply_to_user_id_str" : "37054704",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 123, 145 ],
      "url" : "http:\/\/t.co\/CH0IsUnzGZ",
      "expanded_url" : "http:\/\/www.darwinproject.ac.uk\/letter\/entry-3272",
      "display_url" : "darwinproject.ac.uk\/letter\/entry-3\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17225145504544, 8.627598336664354 ]
  },
  "id_str" : "628864001368281088",
  "text" : "\u00ABBut I am very poorly today &amp; very stupid &amp; hate everybody &amp; everything.\u00BB how little academic work has changed http:\/\/t.co\/CH0IsUnzGZ",
  "id" : 628864001368281088,
  "created_at" : "2015-08-05 09:43:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dierk Haasis",
      "screen_name" : "Evo2Me",
      "indices" : [ 68, 75 ],
      "id_str" : "22910316",
      "id" : 22910316
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 67 ],
      "url" : "http:\/\/t.co\/H4hWJFMv3L",
      "expanded_url" : "http:\/\/25.media.tumblr.com\/tumblr_lx0e0zbrdc1qj3x9oo1_500.gif",
      "display_url" : "25.media.tumblr.com\/tumblr_lx0e0zb\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17226552179974, 8.627592514193969 ]
  },
  "id_str" : "628843552437608448",
  "text" : "\u2018please provide a portrait picture\u2019 okay.gif http:\/\/t.co\/H4hWJFMv3L @Evo2Me",
  "id" : 628843552437608448,
  "created_at" : "2015-08-05 08:22:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Keith Bradnam",
      "screen_name" : "kbradnam",
      "indices" : [ 3, 12 ],
      "id_str" : "17061155",
      "id" : 17061155
    }, {
      "name" : "Vince Buffalo",
      "screen_name" : "vsbuffalo",
      "indices" : [ 97, 107 ],
      "id_str" : "62183077",
      "id" : 62183077
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ACGT",
      "indices" : [ 109, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/x5s5k3UZyq",
      "expanded_url" : "http:\/\/buff.ly\/1ILtKrQ",
      "display_url" : "buff.ly\/1ILtKrQ"
    } ]
  },
  "geo" : { },
  "id_str" : "628843164376399872",
  "text" : "RT @kbradnam: For the afternoon crowd: 101 questions with a bioinformatician #30: Vince Buffalo (@vsbuffalo) #ACGT http:\/\/t.co\/x5s5k3UZyq",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Vince Buffalo",
        "screen_name" : "vsbuffalo",
        "indices" : [ 83, 93 ],
        "id_str" : "62183077",
        "id" : 62183077
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ACGT",
        "indices" : [ 95, 100 ]
      } ],
      "urls" : [ {
        "indices" : [ 101, 123 ],
        "url" : "http:\/\/t.co\/x5s5k3UZyq",
        "expanded_url" : "http:\/\/buff.ly\/1ILtKrQ",
        "display_url" : "buff.ly\/1ILtKrQ"
      } ]
    },
    "geo" : { },
    "id_str" : "628842631272001536",
    "text" : "For the afternoon crowd: 101 questions with a bioinformatician #30: Vince Buffalo (@vsbuffalo) #ACGT http:\/\/t.co\/x5s5k3UZyq",
    "id" : 628842631272001536,
    "created_at" : "2015-08-05 08:19:01 +0000",
    "user" : {
      "name" : "Keith Bradnam",
      "screen_name" : "kbradnam",
      "protected" : false,
      "id_str" : "17061155",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/583756306919489538\/D2fFCYq4_normal.jpg",
      "id" : 17061155,
      "verified" : false
    }
  },
  "id" : 628843164376399872,
  "created_at" : "2015-08-05 08:21:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17226412241021, 8.627594235638352 ]
  },
  "id_str" : "628839624341856256",
  "text" : "technological progress: instead of emailing pictures from one device to another I\u2019m now using iMessage.",
  "id" : 628839624341856256,
  "created_at" : "2015-08-05 08:07:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Maggie Delano",
      "screen_name" : "maggied",
      "indices" : [ 3, 11 ],
      "id_str" : "7374462",
      "id" : 7374462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/WIcLHghKF3",
      "expanded_url" : "http:\/\/mic.com\/articles\/123311\/silicon-valley-white-male-privilege-class-war",
      "display_url" : "mic.com\/articles\/12331\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "628823131046707200",
  "text" : "RT @maggied: One Tweet Shows What Silicon Valley Really Thinks of the People It\u2019s Crushing http:\/\/t.co\/WIcLHghKF3",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 78, 100 ],
        "url" : "http:\/\/t.co\/WIcLHghKF3",
        "expanded_url" : "http:\/\/mic.com\/articles\/123311\/silicon-valley-white-male-privilege-class-war",
        "display_url" : "mic.com\/articles\/12331\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "628754911656833024",
    "text" : "One Tweet Shows What Silicon Valley Really Thinks of the People It\u2019s Crushing http:\/\/t.co\/WIcLHghKF3",
    "id" : 628754911656833024,
    "created_at" : "2015-08-05 02:30:27 +0000",
    "user" : {
      "name" : "Maggie Delano",
      "screen_name" : "maggied",
      "protected" : false,
      "id_str" : "7374462",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539503421674356737\/PVTRSCVO_normal.jpeg",
      "id" : 7374462,
      "verified" : false
    }
  },
  "id" : 628823131046707200,
  "created_at" : "2015-08-05 07:01:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 126, 148 ],
      "url" : "http:\/\/t.co\/6Cu6Lyb2HN",
      "expanded_url" : "http:\/\/gizmodo.com\/rob-rhineharts-latest-attempt-to-make-you-buy-soylent-i-1721852606",
      "display_url" : "gizmodo.com\/rob-rhineharts\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17223544212347, 8.627602676317794 ]
  },
  "id_str" : "628820652498243584",
  "text" : "\u00ABYou can\u2019t fix political conflict and economic imbalances &amp; runaway climate change by taking Uber &amp; drinking Soylent\u00BB http:\/\/t.co\/6Cu6Lyb2HN",
  "id" : 628820652498243584,
  "created_at" : "2015-08-05 06:51:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laura Hudson",
      "screen_name" : "laura_hudson",
      "indices" : [ 3, 16 ],
      "id_str" : "15642209",
      "id" : 15642209
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/pf66ykSn3b",
      "expanded_url" : "https:\/\/medium.com\/@schmutzie\/99-invisible-podcast-s-brilliant-response-to-criticism-of-women-s-voices-2d39f49a0569",
      "display_url" : "medium.com\/@schmutzie\/99-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "628818334650384384",
  "text" : "RT @laura_hudson: I &lt;3 this amazing podcast auto-reply to listeners who complain about women's voices: https:\/\/t.co\/pf66ykSn3b http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/laura_hudson\/status\/628708232563855361\/photo\/1",
        "indices" : [ 112, 134 ],
        "url" : "http:\/\/t.co\/5Kv4oTsYoi",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CLmeBRxWEAA_utq.jpg",
        "id_str" : "628707367782322176",
        "id" : 628707367782322176,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLmeBRxWEAA_utq.jpg",
        "sizes" : [ {
          "h" : 680,
          "resize" : "fit",
          "w" : 406
        }, {
          "h" : 904,
          "resize" : "fit",
          "w" : 540
        }, {
          "h" : 904,
          "resize" : "fit",
          "w" : 540
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 904,
          "resize" : "fit",
          "w" : 540
        } ],
        "display_url" : "pic.twitter.com\/5Kv4oTsYoi"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 88, 111 ],
        "url" : "https:\/\/t.co\/pf66ykSn3b",
        "expanded_url" : "https:\/\/medium.com\/@schmutzie\/99-invisible-podcast-s-brilliant-response-to-criticism-of-women-s-voices-2d39f49a0569",
        "display_url" : "medium.com\/@schmutzie\/99-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "628708232563855361",
    "text" : "I &lt;3 this amazing podcast auto-reply to listeners who complain about women's voices: https:\/\/t.co\/pf66ykSn3b http:\/\/t.co\/5Kv4oTsYoi",
    "id" : 628708232563855361,
    "created_at" : "2015-08-04 23:24:58 +0000",
    "user" : {
      "name" : "Laura Hudson",
      "screen_name" : "laura_hudson",
      "protected" : false,
      "id_str" : "15642209",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/755473832631148544\/Nh3KRN7T_normal.jpg",
      "id" : 15642209,
      "verified" : true
    }
  },
  "id" : 628818334650384384,
  "created_at" : "2015-08-05 06:42:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 28, 40 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "628717560599457792",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11402859881439, 8.753339430619924 ]
  },
  "id_str" : "628717749158715392",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer \u201Cmy colleague @helgerausch tried to scare me into writing tests, to no avail\u2026\u201D",
  "id" : 628717749158715392,
  "in_reply_to_status_id" : 628717560599457792,
  "created_at" : "2015-08-05 00:02:47 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "628716158040981504",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1140290526449, 8.753337677078942 ]
  },
  "id_str" : "628716367278141440",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer yes! once we\u2019re at that age we can write \u201Cdo not compile\u201D :D",
  "id" : 628716367278141440,
  "in_reply_to_status_id" : 628716158040981504,
  "created_at" : "2015-08-04 23:57:17 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 18, 31 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "628711272847159296",
  "geo" : { },
  "id_str" : "628711507589767169",
  "in_reply_to_user_id" : 14286491,
  "text" : "That said: Thanks @PhilippBayer for recommending 'Do No Harm': \u00ABI remember all my patients who die after operations. I wish I didn't.\u00BB",
  "id" : 628711507589767169,
  "in_reply_to_status_id" : 628711272847159296,
  "created_at" : "2015-08-04 23:37:58 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 59, 72 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "628711272847159296",
  "text" : "Fun: my Twitter client crashes every time I try to mention @PhilippBayer\u2026",
  "id" : 628711272847159296,
  "created_at" : "2015-08-04 23:37:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Schawinski",
      "screen_name" : "kevinschawinski",
      "indices" : [ 0, 16 ],
      "id_str" : "242844365",
      "id" : 242844365
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 46 ],
      "url" : "https:\/\/t.co\/kzjVCZVvUY",
      "expanded_url" : "https:\/\/m.youtube.com\/watch?v=Arf2TxeYPDs",
      "display_url" : "m.youtube.com\/watch?v=Arf2Tx\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "628678925208530944",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11400636546998, 8.753409456771516 ]
  },
  "id_str" : "628679644712185856",
  "in_reply_to_user_id" : 242844365,
  "text" : "@kevinschawinski soon: https:\/\/t.co\/kzjVCZVvUY",
  "id" : 628679644712185856,
  "in_reply_to_status_id" : 628678925208530944,
  "created_at" : "2015-08-04 21:31:22 +0000",
  "in_reply_to_screen_name" : "kevinschawinski",
  "in_reply_to_user_id_str" : "242844365",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u262E MenschZwoNull \u262E",
      "screen_name" : "MenschZwoNull",
      "indices" : [ 0, 14 ],
      "id_str" : "36943219",
      "id" : 36943219
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "628679092884361216",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11400579875421, 8.753260843010255 ]
  },
  "id_str" : "628679307091701760",
  "in_reply_to_user_id" : 36943219,
  "text" : "@MenschZwoNull mir sagt es ich sollte allen content in avatarwechsel verpacken ;)",
  "id" : 628679307091701760,
  "in_reply_to_status_id" : 628679092884361216,
  "created_at" : "2015-08-04 21:30:01 +0000",
  "in_reply_to_screen_name" : "MenschZwoNull",
  "in_reply_to_user_id_str" : "36943219",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u262E MenschZwoNull \u262E",
      "screen_name" : "MenschZwoNull",
      "indices" : [ 0, 14 ],
      "id_str" : "36943219",
      "id" : 36943219
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "628672759170768896",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11400775567341, 8.753265035417133 ]
  },
  "id_str" : "628677569274118146",
  "in_reply_to_user_id" : 36943219,
  "text" : "@MenschZwoNull ich erschreck mich aber immer selbst wenn ich mich nun in der timeline sehe :D",
  "id" : 628677569274118146,
  "in_reply_to_status_id" : 628672759170768896,
  "created_at" : "2015-08-04 21:23:07 +0000",
  "in_reply_to_screen_name" : "MenschZwoNull",
  "in_reply_to_user_id_str" : "36943219",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nazeefa",
      "screen_name" : "NazeefaFatima",
      "indices" : [ 0, 14 ],
      "id_str" : "37054704",
      "id" : 37054704
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "628674387441545216",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11402496223405, 8.753328318869288 ]
  },
  "id_str" : "628674872210792448",
  "in_reply_to_user_id" : 37054704,
  "text" : "@NazeefaFatima \uD83D\uDC3C\uD83D\uDC93",
  "id" : 628674872210792448,
  "in_reply_to_status_id" : 628674387441545216,
  "created_at" : "2015-08-04 21:12:24 +0000",
  "in_reply_to_screen_name" : "NazeefaFatima",
  "in_reply_to_user_id_str" : "37054704",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1140309727742, 8.753331889190031 ]
  },
  "id_str" : "628672342567350272",
  "text" : "sorry to confuse everyone, but after 3.5 years or so it was time for an avatar-update.",
  "id" : 628672342567350272,
  "created_at" : "2015-08-04 21:02:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 91 ],
      "url" : "https:\/\/t.co\/IeKnZNaPps",
      "expanded_url" : "https:\/\/instagram.com\/p\/5-MD7DBwj_\/",
      "display_url" : "instagram.com\/p\/5-MD7DBwj_\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.106689705, 8.770659658 ]
  },
  "id_str" : "628635210972839936",
  "text" : "Drama Weather \u2014 perfect time to be in a canoe @ Offenbach Main Ufer https:\/\/t.co\/IeKnZNaPps",
  "id" : 628635210972839936,
  "created_at" : "2015-08-04 18:34:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 58 ],
      "url" : "https:\/\/t.co\/jxeduFrtPY",
      "expanded_url" : "https:\/\/instagram.com\/p\/5-K_rXBwiI\/",
      "display_url" : "instagram.com\/p\/5-K_rXBwiI\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.108111776, 8.766002731 ]
  },
  "id_str" : "628632870739951616",
  "text" : "Playground @ Waggon Am Kulturgleis https:\/\/t.co\/jxeduFrtPY",
  "id" : 628632870739951616,
  "created_at" : "2015-08-04 18:25:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 55 ],
      "url" : "https:\/\/t.co\/KKJwURRfZO",
      "expanded_url" : "https:\/\/instagram.com\/p\/5-KC5Mhwgo\/",
      "display_url" : "instagram.com\/p\/5-KC5Mhwgo\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11273012, 8.747702321 ]
  },
  "id_str" : "628630778067423233",
  "text" : "Rainy @ Hafen Offenbach am Main https:\/\/t.co\/KKJwURRfZO",
  "id" : 628630778067423233,
  "created_at" : "2015-08-04 18:17:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/628593620665413632\/photo\/1",
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/HVwxWczDvS",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CLk2kURWUAUrdvp.jpg",
      "id_str" : "628593620539559941",
      "id" : 628593620539559941,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLk2kURWUAUrdvp.jpg",
      "sizes" : [ {
        "h" : 679,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1333,
        "resize" : "fit",
        "w" : 1334
      }, {
        "h" : 1333,
        "resize" : "fit",
        "w" : 1334
      }, {
        "h" : 1199,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/HVwxWczDvS"
    } ],
    "hashtags" : [ {
      "text" : "wikidata",
      "indices" : [ 12, 21 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.114079, 8.753352 ]
  },
  "id_str" : "628593620665413632",
  "text" : "The data of #wikidata is so small: they have to warn of the choking hazard to children. http:\/\/t.co\/HVwxWczDvS",
  "id" : 628593620665413632,
  "created_at" : "2015-08-04 15:49:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "628464485867630592",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17224424676594, 8.627605109451746 ]
  },
  "id_str" : "628582029811187712",
  "in_reply_to_user_id" : 14286491,
  "text" : "Could also be a good tag-line for my self-description: \u2018has science gone to far?!\u2019",
  "id" : 628582029811187712,
  "in_reply_to_status_id" : 628464485867630592,
  "created_at" : "2015-08-04 15:03:29 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "628575112934002688",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.14710399365812, 8.614925428907139 ]
  },
  "id_str" : "628576593271758848",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer did they retrofit it by now? \uD83D\uDE09",
  "id" : 628576593271758848,
  "in_reply_to_status_id" : 628575112934002688,
  "created_at" : "2015-08-04 14:41:52 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BiK-F",
      "screen_name" : "bik_f_",
      "indices" : [ 3, 10 ],
      "id_str" : "2849770550",
      "id" : 2849770550
    }, {
      "name" : "SENCKENBERG",
      "screen_name" : "Senckenberg",
      "indices" : [ 122, 134 ],
      "id_str" : "85120200",
      "id" : 85120200
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/hRuYld2I0h",
      "expanded_url" : "http:\/\/www.senckenberg.de\/files\/content\/stellenausschreibungen\/stellenausschreibung,_ref7-11.pdf",
      "display_url" : "senckenberg.de\/files\/content\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "628519605380743168",
  "text" : "RT @bik_f_: New job at BiK-F: Project coordinator for\n\u201CInternational biodiversity data networking\u201D http:\/\/t.co\/hRuYld2I0h @Senckenberg Pls \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "SENCKENBERG",
        "screen_name" : "Senckenberg",
        "indices" : [ 110, 122 ],
        "id_str" : "85120200",
        "id" : 85120200
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 87, 109 ],
        "url" : "http:\/\/t.co\/hRuYld2I0h",
        "expanded_url" : "http:\/\/www.senckenberg.de\/files\/content\/stellenausschreibungen\/stellenausschreibung,_ref7-11.pdf",
        "display_url" : "senckenberg.de\/files\/content\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "628511893213331456",
    "text" : "New job at BiK-F: Project coordinator for\n\u201CInternational biodiversity data networking\u201D http:\/\/t.co\/hRuYld2I0h @Senckenberg Pls pass it on",
    "id" : 628511893213331456,
    "created_at" : "2015-08-04 10:24:47 +0000",
    "user" : {
      "name" : "BiK-F",
      "screen_name" : "bik_f_",
      "protected" : false,
      "id_str" : "2849770550",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/520456619709452289\/DG1Gz8_e_normal.jpeg",
      "id" : 2849770550,
      "verified" : false
    }
  },
  "id" : 628519605380743168,
  "created_at" : "2015-08-04 10:55:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "malech maltz",
      "screen_name" : "malech",
      "indices" : [ 0, 7 ],
      "id_str" : "784085846391713793",
      "id" : 784085846391713793
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17220434738778, 8.627655429007723 ]
  },
  "id_str" : "628468827257466880",
  "text" : "@malech Mitte September bin ich in Wien :3",
  "id" : 628468827257466880,
  "created_at" : "2015-08-04 07:33:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/aWQMoXhWUs",
      "expanded_url" : "http:\/\/existentialcomics.com\/comic\/92",
      "display_url" : "existentialcomics.com\/comic\/92"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17223074153615, 8.627624622844447 ]
  },
  "id_str" : "628467973049708544",
  "text" : "\u00ABYou don\u2019t need to take off your shirt for this part, Hume.\u00BB \uD83D\uDE02 http:\/\/t.co\/aWQMoXhWUs",
  "id" : 628467973049708544,
  "created_at" : "2015-08-04 07:30:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 72 ],
      "url" : "http:\/\/t.co\/MF9eFW2ujM",
      "expanded_url" : "http:\/\/arstechnica.com\/science\/2015\/08\/fix-sexism-in-air-conditioning-save-the-planet\/",
      "display_url" : "arstechnica.com\/science\/2015\/0\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722263440724, 8.627610846131462 ]
  },
  "id_str" : "628467093701324800",
  "text" : "\u00ABFix sexism in air conditioning, save the planet\u00BB http:\/\/t.co\/MF9eFW2ujM",
  "id" : 628467093701324800,
  "created_at" : "2015-08-04 07:26:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17221111019762, 8.6276229065217 ]
  },
  "id_str" : "628464485867630592",
  "text" : "Not sure whether writing self-descriptions sucks because of humble-bragging or self-reflection. Maybe should go with \u2018likes \uD83D\uDD2C &amp; \uD83D\uDC36\u2019?",
  "id" : 628464485867630592,
  "created_at" : "2015-08-04 07:16:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "628241346483089408",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11403273547646, 8.753330285559304 ]
  },
  "id_str" : "628246298924306432",
  "in_reply_to_user_id" : 191463787,
  "text" : "@biosharing thanks!",
  "id" : 628246298924306432,
  "in_reply_to_status_id" : 628241346483089408,
  "created_at" : "2015-08-03 16:49:24 +0000",
  "in_reply_to_screen_name" : "SusannaASansone",
  "in_reply_to_user_id_str" : "191463787",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 2, 24 ],
      "url" : "http:\/\/t.co\/NtJVFEVuWT",
      "expanded_url" : "http:\/\/33.media.tumblr.com\/a59c99cda990a322c93b4ea13b1861da\/tumblr_inline_mqhj1iqVts1qz4rgp.gif",
      "display_url" : "33.media.tumblr.com\/a59c99cda990a3\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17223487508073, 8.627599040001721 ]
  },
  "id_str" : "628216771246465024",
  "text" : "\uD83D\uDC3B http:\/\/t.co\/NtJVFEVuWT",
  "id" : 628216771246465024,
  "created_at" : "2015-08-03 14:52:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "himbeerkomplott",
      "screen_name" : "raspberryperson",
      "indices" : [ 0, 16 ],
      "id_str" : "2841131495",
      "id" : 2841131495
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "628165002088849408",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17224998158779, 8.627593027309414 ]
  },
  "id_str" : "628183128776048640",
  "in_reply_to_user_id" : 2841131495,
  "text" : "@raspberryperson Gl\u00FCckwunsch :)",
  "id" : 628183128776048640,
  "in_reply_to_status_id" : 628165002088849408,
  "created_at" : "2015-08-03 12:38:23 +0000",
  "in_reply_to_screen_name" : "raspberryperson",
  "in_reply_to_user_id_str" : "2841131495",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    }, {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 7, 16 ],
      "id_str" : "371189071",
      "id" : 371189071
    }, {
      "name" : "Roman Mars",
      "screen_name" : "romanmars",
      "indices" : [ 108, 118 ],
      "id_str" : "8198012",
      "id" : 8198012
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "628127424769822720",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722344061404, 8.627613284474595 ]
  },
  "id_str" : "628127912634490880",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot @JP_Stich probably nothing new in there for you, but who doesn\u2019t like to hear things being retold by @romanmars et al. \uD83D\uDE02",
  "id" : 628127912634490880,
  "in_reply_to_status_id" : 628127424769822720,
  "created_at" : "2015-08-03 08:58:59 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 44, 50 ],
      "id_str" : "1492631",
      "id" : 1492631
    }, {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 51, 60 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/OJZFvxQ2uS",
      "expanded_url" : "http:\/\/99percentinvisible.org\/episode\/from-the-sea-freedom\/",
      "display_url" : "99percentinvisible.org\/episode\/from-t\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17223484985878, 8.62761632145241 ]
  },
  "id_str" : "628124838054510592",
  "text" : "The latest 99PI episode is on micronations! @Lobot @JP_Stich http:\/\/t.co\/OJZFvxQ2uS",
  "id" : 628124838054510592,
  "created_at" : "2015-08-03 08:46:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/uIL1RcVTP7",
      "expanded_url" : "https:\/\/theconversation.com\/bioethics-is-a-moral-imperative-a-reply-to-steven-pinker-45594",
      "display_url" : "theconversation.com\/bioethics-is-a\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17224858630819, 8.627602677942312 ]
  },
  "id_str" : "628104846546202624",
  "text" : "Why Jurassic Park has a better idea of bioethics than Steven Pinker does https:\/\/t.co\/uIL1RcVTP7",
  "id" : 628104846546202624,
  "created_at" : "2015-08-03 07:27:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Austin Richardson",
      "screen_name" : "heyaudy",
      "indices" : [ 3, 11 ],
      "id_str" : "14534523",
      "id" : 14534523
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 82, 94 ],
      "id_str" : "52747896",
      "id" : 52747896
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 95, 111 ],
      "id_str" : "14286491",
      "id" : 14286491
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 112, 125 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 35 ],
      "url" : "http:\/\/t.co\/aM2jmqBKp8",
      "expanded_url" : "http:\/\/opensnp.org",
      "display_url" : "opensnp.org"
    }, {
      "indices" : [ 58, 81 ],
      "url" : "https:\/\/t.co\/h0JrIW00A1",
      "expanded_url" : "https:\/\/github.com\/caesar0301\/awesome-public-datasets\/pull\/94",
      "display_url" : "github.com\/caesar0301\/awe\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "628086557606551552",
  "text" : "RT @heyaudy: http:\/\/t.co\/aM2jmqBKp8 into awesome-datasets https:\/\/t.co\/h0JrIW00A1 @helgerausch @gedankenstuecke @PhilippBayer",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Helge Rausch \uD83E\uDD59",
        "screen_name" : "helgerausch",
        "indices" : [ 69, 81 ],
        "id_str" : "52747896",
        "id" : 52747896
      }, {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 82, 98 ],
        "id_str" : "14286491",
        "id" : 14286491
      }, {
        "name" : "Philipp Bayer\uD83C\uDF08",
        "screen_name" : "PhilippBayer",
        "indices" : [ 99, 112 ],
        "id_str" : "121777206",
        "id" : 121777206
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 0, 22 ],
        "url" : "http:\/\/t.co\/aM2jmqBKp8",
        "expanded_url" : "http:\/\/opensnp.org",
        "display_url" : "opensnp.org"
      }, {
        "indices" : [ 45, 68 ],
        "url" : "https:\/\/t.co\/h0JrIW00A1",
        "expanded_url" : "https:\/\/github.com\/caesar0301\/awesome-public-datasets\/pull\/94",
        "display_url" : "github.com\/caesar0301\/awe\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "628055197697351680",
    "text" : "http:\/\/t.co\/aM2jmqBKp8 into awesome-datasets https:\/\/t.co\/h0JrIW00A1 @helgerausch @gedankenstuecke @PhilippBayer",
    "id" : 628055197697351680,
    "created_at" : "2015-08-03 04:10:02 +0000",
    "user" : {
      "name" : "Austin Richardson",
      "screen_name" : "heyaudy",
      "protected" : false,
      "id_str" : "14534523",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/923034147777474561\/zZvXWmSQ_normal.jpg",
      "id" : 14534523,
      "verified" : false
    }
  },
  "id" : 628086557606551552,
  "created_at" : "2015-08-03 06:14:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Austin Richardson",
      "screen_name" : "heyaudy",
      "indices" : [ 0, 8 ],
      "id_str" : "14534523",
      "id" : 14534523
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 9, 21 ],
      "id_str" : "52747896",
      "id" : 52747896
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 22, 35 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "628055197697351680",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722309599589, 8.627618442981456 ]
  },
  "id_str" : "628086541194272768",
  "in_reply_to_user_id" : 14534523,
  "text" : "@heyaudy @helgerausch @PhilippBayer yay, thanks a lot!",
  "id" : 628086541194272768,
  "in_reply_to_status_id" : 628055197697351680,
  "created_at" : "2015-08-03 06:14:35 +0000",
  "in_reply_to_screen_name" : "heyaudy",
  "in_reply_to_user_id_str" : "14534523",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 75 ],
      "url" : "http:\/\/t.co\/iJfAjPj5Ir",
      "expanded_url" : "http:\/\/boingboing.net\/2015\/08\/02\/vegan-black-metal-chef-makes-l.html",
      "display_url" : "boingboing.net\/2015\/08\/02\/veg\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11402564454821, 8.753331725876354 ]
  },
  "id_str" : "627962054830354432",
  "text" : "\u00ABscoop some tahini into your blender of oblivion\u00BB \uD83C\uDF5D\uD83C\uDFB8 http:\/\/t.co\/iJfAjPj5Ir",
  "id" : 627962054830354432,
  "created_at" : "2015-08-02 21:59:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/n3lzn5c4Bt",
      "expanded_url" : "http:\/\/journals.plos.org\/plosone\/article?id=10.1371\/journal.pone.0134148",
      "display_url" : "journals.plos.org\/plosone\/articl\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11402542176229, 8.753332181220372 ]
  },
  "id_str" : "627945471152136192",
  "text" : "Some titles read like overly specific google queries \u00ABHow to Sync to the Beat [\u2026] without Falling Off the Treadmill?\u00BB http:\/\/t.co\/n3lzn5c4Bt",
  "id" : 627945471152136192,
  "created_at" : "2015-08-02 20:54:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11402545505469, 8.753331830431302 ]
  },
  "id_str" : "627926357654274048",
  "text" : "She had to endure me talking obscure biology for 24+ years &amp; counting, so I will survive her talking about finally learning English. Hi Mom!",
  "id" : 627926357654274048,
  "created_at" : "2015-08-02 19:38:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Yoder \uD83D\uDD96\uD83C\uDFFB",
      "screen_name" : "JBYoder",
      "indices" : [ 0, 8 ],
      "id_str" : "19984919",
      "id" : 19984919
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "627911612779896832",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1140257407306, 8.753332058615953 ]
  },
  "id_str" : "627913255973953536",
  "in_reply_to_user_id" : 19984919,
  "text" : "@JBYoder was it any good?",
  "id" : 627913255973953536,
  "in_reply_to_status_id" : 627911612779896832,
  "created_at" : "2015-08-02 18:46:00 +0000",
  "in_reply_to_screen_name" : "JBYoder",
  "in_reply_to_user_id_str" : "19984919",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonas",
      "screen_name" : "lsanoj",
      "indices" : [ 0, 7 ],
      "id_str" : "18918915",
      "id" : 18918915
    }, {
      "name" : "Sebastian Greiner",
      "screen_name" : "Seb666",
      "indices" : [ 16, 23 ],
      "id_str" : "2365333778",
      "id" : 2365333778
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "627900070831239168",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11402616397011, 8.7533322112025 ]
  },
  "id_str" : "627901635319197696",
  "in_reply_to_user_id" : 18918915,
  "text" : "@lsanoj Ist der @Seb666 bei dir? \uD83D\uDE02",
  "id" : 627901635319197696,
  "in_reply_to_status_id" : 627900070831239168,
  "created_at" : "2015-08-02 17:59:50 +0000",
  "in_reply_to_screen_name" : "lsanoj",
  "in_reply_to_user_id_str" : "18918915",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "627896882573012994",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11402702399446, 8.753333153276067 ]
  },
  "id_str" : "627898078960480256",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot apparently being weird enough automatically turns you into a weirdo-magnet.",
  "id" : 627898078960480256,
  "in_reply_to_status_id" : 627896882573012994,
  "created_at" : "2015-08-02 17:45:42 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11701411491364, 8.78102159414536 ]
  },
  "id_str" : "627861556731248640",
  "text" : "A naked Jesus freak complimented me on my skirt. \u263A\uFE0F",
  "id" : 627861556731248640,
  "created_at" : "2015-08-02 15:20:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Radhouane Aniba",
      "screen_name" : "radaniba",
      "indices" : [ 3, 12 ],
      "id_str" : "57309864",
      "id" : 57309864
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 75 ],
      "url" : "https:\/\/t.co\/M5naSulSCy",
      "expanded_url" : "https:\/\/stronglang.wordpress.com\/2015\/07\/28\/mapping-the-united-swears-of-america\/",
      "display_url" : "stronglang.wordpress.com\/2015\/07\/28\/map\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "627844197542928385",
  "text" : "RT @radaniba: Mapping the United Swears of America\n https:\/\/t.co\/M5naSulSCy",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 38, 61 ],
        "url" : "https:\/\/t.co\/M5naSulSCy",
        "expanded_url" : "https:\/\/stronglang.wordpress.com\/2015\/07\/28\/mapping-the-united-swears-of-america\/",
        "display_url" : "stronglang.wordpress.com\/2015\/07\/28\/map\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "627837424018702336",
    "text" : "Mapping the United Swears of America\n https:\/\/t.co\/M5naSulSCy",
    "id" : 627837424018702336,
    "created_at" : "2015-08-02 13:44:41 +0000",
    "user" : {
      "name" : "Radhouane Aniba",
      "screen_name" : "radaniba",
      "protected" : false,
      "id_str" : "57309864",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/705949371955720192\/nfZ75rVE_normal.jpg",
      "id" : 57309864,
      "verified" : false
    }
  },
  "id" : 627844197542928385,
  "created_at" : "2015-08-02 14:11:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 76 ],
      "url" : "https:\/\/t.co\/tipOZRHDYv",
      "expanded_url" : "https:\/\/en.wikipedia.org\/wiki\/List_of_map_projections",
      "display_url" : "en.wikipedia.org\/wiki\/List_of_m\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "627802196818702336",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11403291436287, 8.753333707133045 ]
  },
  "id_str" : "627804927834914817",
  "in_reply_to_user_id" : 14286491,
  "text" : "And with that I did fall down the rabbit hole again\u2026 https:\/\/t.co\/tipOZRHDYv",
  "id" : 627804927834914817,
  "in_reply_to_status_id" : 627802196818702336,
  "created_at" : "2015-08-02 11:35:33 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 48 ],
      "url" : "http:\/\/t.co\/usw292g7EF",
      "expanded_url" : "http:\/\/tvtropes.org\/pmwiki\/pmwiki.php\/Main\/ContemplatingYourHands",
      "display_url" : "tvtropes.org\/pmwiki\/pmwiki.\u2026"
    }, {
      "indices" : [ 68, 91 ],
      "url" : "https:\/\/t.co\/grDiuHgaoz",
      "expanded_url" : "https:\/\/twitter.com\/ewanbirney\/status\/627798569752338432",
      "display_url" : "twitter.com\/ewanbirney\/sta\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11403019487531, 8.753332911014496 ]
  },
  "id_str" : "627802196818702336",
  "text" : "I can\u2019t help but think of http:\/\/t.co\/usw292g7EF when reading it. \uD83D\uDC50 https:\/\/t.co\/grDiuHgaoz",
  "id" : 627802196818702336,
  "created_at" : "2015-08-02 11:24:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/g5X24nyAcM",
      "expanded_url" : "http:\/\/www.theatlantic.com\/technology\/archive\/2015\/07\/futurism-sexism-men\/400097\/",
      "display_url" : "theatlantic.com\/technology\/arc\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1140290391679, 8.753332795035778 ]
  },
  "id_str" : "627798315124543488",
  "text" : "Why Aren't There More Women Futurists? http:\/\/t.co\/g5X24nyAcM",
  "id" : 627798315124543488,
  "created_at" : "2015-08-02 11:09:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fiona Nielsen",
      "screen_name" : "glyn_dk",
      "indices" : [ 85, 93 ],
      "id_str" : "32340834",
      "id" : 32340834
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/rOsfjanFV2",
      "expanded_url" : "http:\/\/www.vice.com\/en_uk\/read\/heres-every-one-of-the-150-friends-you-have-303?utm_content=bufferd140f&utm_medium=social&utm_source=twitter.com&utm_campaign=buffer",
      "display_url" : "vice.com\/en_uk\/read\/her\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11403004370044, 8.753333917461894 ]
  },
  "id_str" : "627792385842524160",
  "text" : "How each social network should organise their friend list http:\/\/t.co\/rOsfjanFV2 \/HT @glyn_dk",
  "id" : 627792385842524160,
  "created_at" : "2015-08-02 10:45:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11394155657569, 8.753133322348498 ]
  },
  "id_str" : "627758353733808128",
  "text" : "\u00ABI don\u2019t think this relationship will work out. You are reading your Twitter timeline in the wrong direction.\u00BB",
  "id" : 627758353733808128,
  "created_at" : "2015-08-02 08:30:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fieldworkfail",
      "indices" : [ 15, 29 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/BHqE7Zpy6l",
      "expanded_url" : "https:\/\/instagram.com\/p\/rEe4HqBwnR\/",
      "display_url" : "instagram.com\/p\/rEe4HqBwnR\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11397373233578, 8.753114332869266 ]
  },
  "id_str" : "627755372279930880",
  "text" : "Bioinformatics #fieldworkfail: went camping at a spot where mobile phone reception was bad, SSH unusable. https:\/\/t.co\/BHqE7Zpy6l",
  "id" : 627755372279930880,
  "created_at" : "2015-08-02 08:18:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 59 ],
      "url" : "https:\/\/t.co\/QFpsY6soxk",
      "expanded_url" : "https:\/\/instagram.com\/p\/511OMShwi2\/",
      "display_url" : "instagram.com\/p\/511OMShwi2\/"
    } ]
  },
  "geo" : { },
  "id_str" : "627459086678917120",
  "text" : "Wait, which side is starboard now?! https:\/\/t.co\/QFpsY6soxk",
  "id" : 627459086678917120,
  "created_at" : "2015-08-01 12:41:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sebastian Greiner",
      "screen_name" : "Seb666",
      "indices" : [ 0, 7 ],
      "id_str" : "2365333778",
      "id" : 2365333778
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "627415622318694401",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11402812210314, 8.753336528215268 ]
  },
  "id_str" : "627423285702205440",
  "in_reply_to_user_id" : 2365333778,
  "text" : "@Seb666 welche software ist schon nicht unfinished? ;)",
  "id" : 627423285702205440,
  "in_reply_to_status_id" : 627415622318694401,
  "created_at" : "2015-08-01 10:19:02 +0000",
  "in_reply_to_screen_name" : "Seb666",
  "in_reply_to_user_id_str" : "2365333778",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sebastian Greiner",
      "screen_name" : "Seb666",
      "indices" : [ 0, 7 ],
      "id_str" : "2365333778",
      "id" : 2365333778
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "627410069391544320",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11402864282508, 8.75333919650861 ]
  },
  "id_str" : "627410766270984192",
  "in_reply_to_user_id" : 2365333778,
  "text" : "@Seb666 wobei die Notebooks ja gern ein Kriechstrom-Problem haben ;)",
  "id" : 627410766270984192,
  "in_reply_to_status_id" : 627410069391544320,
  "created_at" : "2015-08-01 09:29:18 +0000",
  "in_reply_to_screen_name" : "Seb666",
  "in_reply_to_user_id_str" : "2365333778",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sebastian Greiner",
      "screen_name" : "Seb666",
      "indices" : [ 0, 7 ],
      "id_str" : "2365333778",
      "id" : 2365333778
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "627407650607771648",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11402864282508, 8.75333919650861 ]
  },
  "id_str" : "627409529404305408",
  "in_reply_to_user_id" : 2365333778,
  "text" : "@Seb666 hat sich bestimmt auch nur auf US Keyboard resettet.",
  "id" : 627409529404305408,
  "in_reply_to_status_id" : 627407650607771648,
  "created_at" : "2015-08-01 09:24:23 +0000",
  "in_reply_to_screen_name" : "Seb666",
  "in_reply_to_user_id_str" : "2365333778",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 3, 9 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/m6AugaZZwo",
      "expanded_url" : "http:\/\/lunalunamag.com\/2015\/07\/29\/sailed\/?src=longreads",
      "display_url" : "lunalunamag.com\/2015\/07\/29\/sai\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "627404730944344064",
  "text" : "RT @Lobot: Sailing across the Atlantic Ocean in the 1980s with two little kids \u2764\uFE0F\u26F5\uFE0F\uD83C\uDF0A http:\/\/t.co\/m6AugaZZwo",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 74, 96 ],
        "url" : "http:\/\/t.co\/m6AugaZZwo",
        "expanded_url" : "http:\/\/lunalunamag.com\/2015\/07\/29\/sailed\/?src=longreads",
        "display_url" : "lunalunamag.com\/2015\/07\/29\/sai\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "627404017761656832",
    "text" : "Sailing across the Atlantic Ocean in the 1980s with two little kids \u2764\uFE0F\u26F5\uFE0F\uD83C\uDF0A http:\/\/t.co\/m6AugaZZwo",
    "id" : 627404017761656832,
    "created_at" : "2015-08-01 09:02:29 +0000",
    "user" : {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "protected" : false,
      "id_str" : "1492631",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/783617256173494272\/7QL2FeUx_normal.jpg",
      "id" : 1492631,
      "verified" : false
    }
  },
  "id" : 627404730944344064,
  "created_at" : "2015-08-01 09:05:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helena",
      "screen_name" : "Helena_LB",
      "indices" : [ 3, 13 ],
      "id_str" : "234309722",
      "id" : 234309722
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Helena_LB\/status\/627344832336404480\/photo\/1",
      "indices" : [ 49, 71 ],
      "url" : "http:\/\/t.co\/XtSaW0X0nX",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CLTGzKdWUAAFmQL.jpg",
      "id_str" : "627344830394421248",
      "id" : 627344830394421248,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLTGzKdWUAAFmQL.jpg",
      "sizes" : [ {
        "h" : 233,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 233,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 233,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 233,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/XtSaW0X0nX"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "627400258742583296",
  "text" : "RT @Helena_LB: Iceland: the land of good sleeps. http:\/\/t.co\/XtSaW0X0nX",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Helena_LB\/status\/627344832336404480\/photo\/1",
        "indices" : [ 34, 56 ],
        "url" : "http:\/\/t.co\/XtSaW0X0nX",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CLTGzKdWUAAFmQL.jpg",
        "id_str" : "627344830394421248",
        "id" : 627344830394421248,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLTGzKdWUAAFmQL.jpg",
        "sizes" : [ {
          "h" : 233,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 233,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 233,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 233,
          "resize" : "fit",
          "w" : 640
        } ],
        "display_url" : "pic.twitter.com\/XtSaW0X0nX"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "627344832336404480",
    "text" : "Iceland: the land of good sleeps. http:\/\/t.co\/XtSaW0X0nX",
    "id" : 627344832336404480,
    "created_at" : "2015-08-01 05:07:18 +0000",
    "user" : {
      "name" : "Helena",
      "screen_name" : "Helena_LB",
      "protected" : false,
      "id_str" : "234309722",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/875644318970634241\/AWFWlhkv_normal.jpg",
      "id" : 234309722,
      "verified" : false
    }
  },
  "id" : 627400258742583296,
  "created_at" : "2015-08-01 08:47:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "627396479905206272",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11400385683887, 8.753408983982608 ]
  },
  "id_str" : "627397257361518592",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer thanks!",
  "id" : 627397257361518592,
  "in_reply_to_status_id" : 627396479905206272,
  "created_at" : "2015-08-01 08:35:37 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "627277436372152320",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11397968021497, 8.753120270158483 ]
  },
  "id_str" : "627396038022823937",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer Dropbox pls \uD83D\uDE0A",
  "id" : 627396038022823937,
  "in_reply_to_status_id" : 627277436372152320,
  "created_at" : "2015-08-01 08:30:46 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sebastian Greiner",
      "screen_name" : "Seb666",
      "indices" : [ 0, 7 ],
      "id_str" : "2365333778",
      "id" : 2365333778
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "627390527860830208",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11401047081919, 8.753264939702067 ]
  },
  "id_str" : "627390719498547200",
  "in_reply_to_user_id" : 2365333778,
  "text" : "@Seb666 aber bei Win10 erwarte ich es zumindest nicht anders.",
  "id" : 627390719498547200,
  "in_reply_to_status_id" : 627390527860830208,
  "created_at" : "2015-08-01 08:09:38 +0000",
  "in_reply_to_screen_name" : "Seb666",
  "in_reply_to_user_id_str" : "2365333778",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sebastian Greiner",
      "screen_name" : "Seb666",
      "indices" : [ 0, 7 ],
      "id_str" : "2365333778",
      "id" : 2365333778
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "627387985248546816",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11403115333702, 8.753326364043252 ]
  },
  "id_str" : "627388857277894656",
  "in_reply_to_user_id" : 2365333778,
  "text" : "@Seb666 ich bin so kurz \uD83D\uDC4C davor zu Windows 10 zu wechseln!",
  "id" : 627388857277894656,
  "in_reply_to_status_id" : 627387985248546816,
  "created_at" : "2015-08-01 08:02:14 +0000",
  "in_reply_to_screen_name" : "Seb666",
  "in_reply_to_user_id_str" : "2365333778",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "627220718682570752",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11400351236368, 8.75337631242963 ]
  },
  "id_str" : "627360458270461953",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC read that as yolo foodworld.",
  "id" : 627360458270461953,
  "in_reply_to_status_id" : 627220718682570752,
  "created_at" : "2015-08-01 06:09:23 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Public Emily",
      "screen_name" : "birdlord",
      "indices" : [ 0, 9 ],
      "id_str" : "26518795",
      "id" : 26518795
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "627218879085981696",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11402964911564, 8.753332004736158 ]
  },
  "id_str" : "627241339881713665",
  "in_reply_to_user_id" : 26518795,
  "text" : "@birdlord Stan Rogers \u2764\uFE0F",
  "id" : 627241339881713665,
  "in_reply_to_status_id" : 627218879085981696,
  "created_at" : "2015-07-31 22:16:03 +0000",
  "in_reply_to_screen_name" : "birdlord",
  "in_reply_to_user_id_str" : "26518795",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
} ]