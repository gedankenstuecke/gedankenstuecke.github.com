Grailbird.data.tweets_2012_01 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 32, 41 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Mainz",
      "indices" : [ 90, 96 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 136 ],
      "url" : "http:\/\/t.co\/iEe1kGcL",
      "expanded_url" : "http:\/\/www.flickr.com\/photos\/gedankenstuecke\/6005015226\/in\/photostream",
      "display_url" : "flickr.com\/photos\/gedanke\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "164467436656148484",
  "text" : "Seit Donnerstag Abend vermissen @Senficon und ich unseren Kater Miller. Hat ihn jemand in #Mainz Kastel gesehen? :( http:\/\/t.co\/iEe1kGcL",
  "id" : 164467436656148484,
  "created_at" : "2012-01-31 21:57:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "malech maltz",
      "screen_name" : "malech",
      "indices" : [ 0, 7 ],
      "id_str" : "784085846391713793",
      "id" : 784085846391713793
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "164394524121108481",
  "text" : "@malech Muss man da gratulieren oder den Kopf vor den armen Irren sch\u00FCtteln? :P",
  "id" : 164394524121108481,
  "created_at" : "2012-01-31 17:08:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "164392918348603392",
  "text" : "Schon wieder einen halben Wald per Post versendet f\u00FCr die Verwaltung. Wie ertragen eigentlich andere Menschen diese B\u00FCrokratie?",
  "id" : 164392918348603392,
  "created_at" : "2012-01-31 17:01:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 3, 13 ],
      "id_str" : "14700783",
      "id" : 14700783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "164345501414719488",
  "text" : "RT @Fischblog: Kommt jemand an das Journal Perception, doi:10.1068\/p6829, ran?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "164345298620121089",
    "text" : "Kommt jemand an das Journal Perception, doi:10.1068\/p6829, ran?",
    "id" : 164345298620121089,
    "created_at" : "2012-01-31 13:52:27 +0000",
    "user" : {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "protected" : false,
      "id_str" : "14700783",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/929627167125921792\/t5PPk1W-_normal.jpg",
      "id" : 14700783,
      "verified" : false
    }
  },
  "id" : 164345501414719488,
  "created_at" : "2012-01-31 13:53:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "blackspear",
      "screen_name" : "blackspear",
      "indices" : [ 0, 11 ],
      "id_str" : "18635562",
      "id" : 18635562
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "164342307032805376",
  "geo" : { },
  "id_str" : "164342563812278272",
  "in_reply_to_user_id" : 18635562,
  "text" : "@blackspear Okay, dann viel Gl\u00FCck :)",
  "id" : 164342563812278272,
  "in_reply_to_status_id" : 164342307032805376,
  "created_at" : "2012-01-31 13:41:35 +0000",
  "in_reply_to_screen_name" : "blackspear",
  "in_reply_to_user_id_str" : "18635562",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "blackspear",
      "screen_name" : "blackspear",
      "indices" : [ 0, 11 ],
      "id_str" : "18635562",
      "id" : 18635562
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "164340804960260096",
  "geo" : { },
  "id_str" : "164342105332916224",
  "in_reply_to_user_id" : 18635562,
  "text" : "@blackspear Vielleicht kann er sich direkt beim Mendeley-Support melden? Die sind sehr freundlich und meist genauso kompetent.",
  "id" : 164342105332916224,
  "in_reply_to_status_id" : 164340804960260096,
  "created_at" : "2012-01-31 13:39:45 +0000",
  "in_reply_to_screen_name" : "blackspear",
  "in_reply_to_user_id_str" : "18635562",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "blackspear",
      "screen_name" : "blackspear",
      "indices" : [ 0, 11 ],
      "id_str" : "18635562",
      "id" : 18635562
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "164340804960260096",
  "geo" : { },
  "id_str" : "164341998327836672",
  "in_reply_to_user_id" : 18635562,
  "text" : "@blackspear Kein Ding. :)",
  "id" : 164341998327836672,
  "in_reply_to_status_id" : 164340804960260096,
  "created_at" : "2012-01-31 13:39:20 +0000",
  "in_reply_to_screen_name" : "blackspear",
  "in_reply_to_user_id_str" : "18635562",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "blackspear",
      "screen_name" : "blackspear",
      "indices" : [ 0, 11 ],
      "id_str" : "18635562",
      "id" : 18635562
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "164340458384916480",
  "geo" : { },
  "id_str" : "164340540605861889",
  "in_reply_to_user_id" : 18635562,
  "text" : "@blackspear Ok, dann bin ich sowieso raus. Ist Jahre her das ich das letzte mal mit Word gearbeitet hab.",
  "id" : 164340540605861889,
  "in_reply_to_status_id" : 164340458384916480,
  "created_at" : "2012-01-31 13:33:32 +0000",
  "in_reply_to_screen_name" : "blackspear",
  "in_reply_to_user_id_str" : "18635562",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "blackspear",
      "screen_name" : "blackspear",
      "indices" : [ 0, 11 ],
      "id_str" : "18635562",
      "id" : 18635562
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "164340022407991296",
  "geo" : { },
  "id_str" : "164340162489356288",
  "in_reply_to_user_id" : 18635562,
  "text" : "@blackspear In BibTex sp\u00E4ter, oder wie? (Aber eigentlich hab ich sowieso keine Ahnung, schreib immer auf Englisch)",
  "id" : 164340162489356288,
  "in_reply_to_status_id" : 164340022407991296,
  "created_at" : "2012-01-31 13:32:02 +0000",
  "in_reply_to_screen_name" : "blackspear",
  "in_reply_to_user_id_str" : "18635562",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jan Ortmann",
      "screen_name" : "jojonks",
      "indices" : [ 0, 8 ],
      "id_str" : "3564398897",
      "id" : 3564398897
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "164331945180925952",
  "text" : "@jojonks Jo, ersetzt ein regul\u00E4res Modul. :)",
  "id" : 164331945180925952,
  "created_at" : "2012-01-31 12:59:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jan Ortmann",
      "screen_name" : "jojonks",
      "indices" : [ 0, 8 ],
      "id_str" : "3564398897",
      "id" : 3564398897
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "164331723109302273",
  "text" : "@jojonks \"Betriebspraktikum\" an nem MPI auf Codebase von openSNP. :)",
  "id" : 164331723109302273,
  "created_at" : "2012-01-31 12:58:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 102 ],
      "url" : "http:\/\/t.co\/YPiwr5Cx",
      "expanded_url" : "http:\/\/j.mp\/AaJyvL",
      "display_url" : "j.mp\/AaJyvL"
    } ]
  },
  "geo" : { },
  "id_str" : "164327176194363392",
  "text" : "Kein Platz f\u00FCr junge Wissenschaftler - Das Problem der fehlenden Juniorpositionen http:\/\/t.co\/YPiwr5Cx",
  "id" : 164327176194363392,
  "created_at" : "2012-01-31 12:40:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Edzard Ernst",
      "screen_name" : "EdzardErnst",
      "indices" : [ 3, 15 ],
      "id_str" : "26992475",
      "id" : 26992475
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 37 ],
      "url" : "http:\/\/t.co\/6YaCdYqD",
      "expanded_url" : "http:\/\/occupycorporatism.com\/?p=5173&utm_medium=twitter&utm_source=twitterfeed",
      "display_url" : "occupycorporatism.com\/?p=5173&utm_me\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "164326185864658944",
  "text" : "RT @EdzardErnst: http:\/\/t.co\/6YaCdYqD when independent researchers object to quackery,it's lobbying;when dangerous quacks rip us off,it' ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 0, 20 ],
        "url" : "http:\/\/t.co\/6YaCdYqD",
        "expanded_url" : "http:\/\/occupycorporatism.com\/?p=5173&utm_medium=twitter&utm_source=twitterfeed",
        "display_url" : "occupycorporatism.com\/?p=5173&utm_me\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "164325780820733954",
    "text" : "http:\/\/t.co\/6YaCdYqD when independent researchers object to quackery,it's lobbying;when dangerous quacks rip us off,it's holistic healthcare",
    "id" : 164325780820733954,
    "created_at" : "2012-01-31 12:34:53 +0000",
    "user" : {
      "name" : "Edzard Ernst",
      "screen_name" : "EdzardErnst",
      "protected" : false,
      "id_str" : "26992475",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/111789867\/New_Press_Photo_normal.JPG",
      "id" : 26992475,
      "verified" : false
    }
  },
  "id" : 164326185864658944,
  "created_at" : "2012-01-31 12:36:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "164320905315631104",
  "text" : "Yeah, Praktikum ist genehmigt! \\o\/",
  "id" : 164320905315631104,
  "created_at" : "2012-01-31 12:15:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 59 ],
      "url" : "http:\/\/t.co\/aXjPutt7",
      "expanded_url" : "http:\/\/j.mp\/wW3mAy",
      "display_url" : "j.mp\/wW3mAy"
    } ]
  },
  "geo" : { },
  "id_str" : "164258773958000640",
  "text" : "Project Unbreakable about sexual abuse http:\/\/t.co\/aXjPutt7",
  "id" : 164258773958000640,
  "created_at" : "2012-01-31 08:08:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 138 ],
      "url" : "http:\/\/t.co\/EfFaJwI4",
      "expanded_url" : "http:\/\/j.mp\/zFcsyD",
      "display_url" : "j.mp\/zFcsyD"
    } ]
  },
  "geo" : { },
  "id_str" : "164256184910614528",
  "text" : "An Ensemble Classifier for Eukaryotic Protein Subcellular Location Prediction Using GO Categories & AA Hydrophobicity http:\/\/t.co\/EfFaJwI4",
  "id" : 164256184910614528,
  "created_at" : "2012-01-31 07:58:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 121 ],
      "url" : "http:\/\/t.co\/C3rHXjTM",
      "expanded_url" : "http:\/\/j.mp\/zrZAl9",
      "display_url" : "j.mp\/zrZAl9"
    } ]
  },
  "geo" : { },
  "id_str" : "164255386172534784",
  "text" : "Population Size Estimation of Men Who Have Sex with Men through the Network Scale-Up Method in Japan http:\/\/t.co\/C3rHXjTM",
  "id" : 164255386172534784,
  "created_at" : "2012-01-31 07:55:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Birgitt",
      "screen_name" : "hekate15",
      "indices" : [ 0, 9 ],
      "id_str" : "88686990",
      "id" : 88686990
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "164133114338226177",
  "geo" : { },
  "id_str" : "164133335747137536",
  "in_reply_to_user_id" : 88686990,
  "text" : "@hekate15 ach das hab ich aufgegeben. Dann lieber mehr gescheiterte Experimente im Labor. ;)",
  "id" : 164133335747137536,
  "in_reply_to_status_id" : 164133114338226177,
  "created_at" : "2012-01-30 23:50:11 +0000",
  "in_reply_to_screen_name" : "hekate15",
  "in_reply_to_user_id_str" : "88686990",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "164131954155978754",
  "text" : "\u00ABBei mir lernt ihr was f\u00FCr Wissenschaftler die wichtigste Eigenschaft ist: Eine hohe Frustrationstoleranz\u00BB",
  "id" : 164131954155978754,
  "created_at" : "2012-01-30 23:44:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 91 ],
      "url" : "http:\/\/t.co\/0OgP5pea",
      "expanded_url" : "http:\/\/www.kickstarter.com\/projects\/citizenscience\/help-us-print-csq-issues-03-04",
      "display_url" : "kickstarter.com\/projects\/citiz\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "164105449745022976",
  "text" : "Gave my share to fund the next two issues of Citizen Science Quarterly http:\/\/t.co\/0OgP5pea",
  "id" : 164105449745022976,
  "created_at" : "2012-01-30 21:59:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scytale",
      "screen_name" : "Scytale",
      "indices" : [ 0, 8 ],
      "id_str" : "621716753",
      "id" : 621716753
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "164101113845522433",
  "geo" : { },
  "id_str" : "164103513985650688",
  "in_reply_to_user_id" : 8308632,
  "text" : "@Scytale Verwirrend, denn dbSNP gibt mir auch noch andere Allele raus o_O",
  "id" : 164103513985650688,
  "in_reply_to_status_id" : 164101113845522433,
  "created_at" : "2012-01-30 21:51:41 +0000",
  "in_reply_to_screen_name" : "scy",
  "in_reply_to_user_id_str" : "8308632",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scytale",
      "screen_name" : "Scytale",
      "indices" : [ 0, 8 ],
      "id_str" : "621716753",
      "id" : 621716753
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "164101113845522433",
  "geo" : { },
  "id_str" : "164102188522676225",
  "in_reply_to_user_id" : 8308632,
  "text" : "@Scytale Bin endg\u00FCltig verwirrt. Der rs955988 den 23andMe mir als Marker anzeigt kommt in dem Paper das sie citen gar nicht vor...",
  "id" : 164102188522676225,
  "in_reply_to_status_id" : 164101113845522433,
  "created_at" : "2012-01-30 21:46:25 +0000",
  "in_reply_to_screen_name" : "scy",
  "in_reply_to_user_id_str" : "8308632",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scytale",
      "screen_name" : "Scytale",
      "indices" : [ 0, 8 ],
      "id_str" : "621716753",
      "id" : 621716753
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "164101113845522433",
  "geo" : { },
  "id_str" : "164101251116699648",
  "in_reply_to_user_id" : 8308632,
  "text" : "@Scytale Moment mal, ich bin au\u00DFerdem TT und da steht \"typical odds\" w\u00E4hrend CC \"moderately higher odds of low sperm count\" sind? o_O",
  "id" : 164101251116699648,
  "in_reply_to_status_id" : 164101113845522433,
  "created_at" : "2012-01-30 21:42:41 +0000",
  "in_reply_to_screen_name" : "scy",
  "in_reply_to_user_id_str" : "8308632",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scytale",
      "screen_name" : "Scytale",
      "indices" : [ 0, 8 ],
      "id_str" : "621716753",
      "id" : 621716753
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "164100718448492544",
  "geo" : { },
  "id_str" : "164100982102437888",
  "in_reply_to_user_id" : 8308632,
  "text" : "@Scytale 1.25 h\u00F6heres Risiko und dann nur in asiatischer Pop. getestet ist halt nicht so aussagekr\u00E4ftig.",
  "id" : 164100982102437888,
  "in_reply_to_status_id" : 164100718448492544,
  "created_at" : "2012-01-30 21:41:37 +0000",
  "in_reply_to_screen_name" : "scy",
  "in_reply_to_user_id_str" : "8308632",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scytale",
      "screen_name" : "Scytale",
      "indices" : [ 0, 8 ],
      "id_str" : "621716753",
      "id" : 621716753
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "164100406752968704",
  "geo" : { },
  "id_str" : "164100595630870528",
  "in_reply_to_user_id" : 8308632,
  "text" : "@Scytale Dito. Ich w\u00FCrde aber mit einem Doc-Besuch warten bis es akut wird.",
  "id" : 164100595630870528,
  "in_reply_to_status_id" : 164100406752968704,
  "created_at" : "2012-01-30 21:40:05 +0000",
  "in_reply_to_screen_name" : "scy",
  "in_reply_to_user_id_str" : "8308632",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rya",
      "screen_name" : "_Rya_",
      "indices" : [ 0, 6 ],
      "id_str" : "89234537",
      "id" : 89234537
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 44, 53 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "164096509195993088",
  "geo" : { },
  "id_str" : "164096560777535488",
  "in_reply_to_user_id" : 89234537,
  "text" : "@_Rya_ Nein, der ist immer noch weg. :( \/cc @Senficon",
  "id" : 164096560777535488,
  "in_reply_to_status_id" : 164096509195993088,
  "created_at" : "2012-01-30 21:24:03 +0000",
  "in_reply_to_screen_name" : "_Rya_",
  "in_reply_to_user_id_str" : "89234537",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Loris",
      "screen_name" : "PygmyLoris",
      "indices" : [ 0, 11 ],
      "id_str" : "191004758",
      "id" : 191004758
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "164095285264527362",
  "geo" : { },
  "id_str" : "164095827323793408",
  "in_reply_to_user_id" : 191004758,
  "text" : "@PygmyLoris great! I'm still looking for a good place to get the actual tree inked :)",
  "id" : 164095827323793408,
  "in_reply_to_status_id" : 164095285264527362,
  "created_at" : "2012-01-30 21:21:08 +0000",
  "in_reply_to_screen_name" : "PygmyLoris",
  "in_reply_to_user_id_str" : "191004758",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Loris",
      "screen_name" : "PygmyLoris",
      "indices" : [ 3, 14 ],
      "id_str" : "191004758",
      "id" : 191004758
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/PygmyLoris\/status\/164092494114590721\/photo\/1",
      "indices" : [ 44, 64 ],
      "url" : "http:\/\/t.co\/BhDXPD7y",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Akb5QQZCEAIAwWx.jpg",
      "id_str" : "164092494118785026",
      "id" : 164092494118785026,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Akb5QQZCEAIAwWx.jpg",
      "sizes" : [ {
        "h" : 400,
        "resize" : "fit",
        "w" : 400
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 400
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 400
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 400
      } ],
      "display_url" : "pic.twitter.com\/BhDXPD7y"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "164095546599022592",
  "text" : "RT @PygmyLoris: Going to get this tattoo... http:\/\/t.co\/BhDXPD7y",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/PygmyLoris\/status\/164092494114590721\/photo\/1",
        "indices" : [ 28, 48 ],
        "url" : "http:\/\/t.co\/BhDXPD7y",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Akb5QQZCEAIAwWx.jpg",
        "id_str" : "164092494118785026",
        "id" : 164092494118785026,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Akb5QQZCEAIAwWx.jpg",
        "sizes" : [ {
          "h" : 400,
          "resize" : "fit",
          "w" : 400
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 400
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 400
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 400
        } ],
        "display_url" : "pic.twitter.com\/BhDXPD7y"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "164092494114590721",
    "text" : "Going to get this tattoo... http:\/\/t.co\/BhDXPD7y",
    "id" : 164092494114590721,
    "created_at" : "2012-01-30 21:07:54 +0000",
    "user" : {
      "name" : "Loris",
      "screen_name" : "PygmyLoris",
      "protected" : false,
      "id_str" : "191004758",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/920667159386316801\/BVsCzUy9_normal.jpg",
      "id" : 191004758,
      "verified" : false
    }
  },
  "id" : 164095546599022592,
  "created_at" : "2012-01-30 21:20:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Loris",
      "screen_name" : "PygmyLoris",
      "indices" : [ 0, 11 ],
      "id_str" : "191004758",
      "id" : 191004758
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "164094657809231872",
  "geo" : { },
  "id_str" : "164094866572320768",
  "in_reply_to_user_id" : 191004758,
  "text" : "@PygmyLoris Prepare for some nice conversations (but most people are afraid to ask)",
  "id" : 164094866572320768,
  "in_reply_to_status_id" : 164094657809231872,
  "created_at" : "2012-01-30 21:17:19 +0000",
  "in_reply_to_screen_name" : "PygmyLoris",
  "in_reply_to_user_id_str" : "191004758",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Loris",
      "screen_name" : "PygmyLoris",
      "indices" : [ 0, 11 ],
      "id_str" : "191004758",
      "id" : 191004758
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "164094124222464000",
  "geo" : { },
  "id_str" : "164094537168457729",
  "in_reply_to_user_id" : 191004758,
  "text" : "@PygmyLoris yeah and it's almost the same spot. :)",
  "id" : 164094537168457729,
  "in_reply_to_status_id" : 164094124222464000,
  "created_at" : "2012-01-30 21:16:01 +0000",
  "in_reply_to_screen_name" : "PygmyLoris",
  "in_reply_to_user_id_str" : "191004758",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Loris",
      "screen_name" : "PygmyLoris",
      "indices" : [ 0, 11 ],
      "id_str" : "191004758",
      "id" : 191004758
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "164093985869135873",
  "geo" : { },
  "id_str" : "164094164160618496",
  "in_reply_to_user_id" : 191004758,
  "text" : "@PygmyLoris yeah, although so far only one person IRL recognized its origin. :)",
  "id" : 164094164160618496,
  "in_reply_to_status_id" : 164093985869135873,
  "created_at" : "2012-01-30 21:14:32 +0000",
  "in_reply_to_screen_name" : "PygmyLoris",
  "in_reply_to_user_id_str" : "191004758",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Loris",
      "screen_name" : "PygmyLoris",
      "indices" : [ 0, 11 ],
      "id_str" : "191004758",
      "id" : 191004758
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 126 ],
      "url" : "http:\/\/t.co\/x4F6kNkL",
      "expanded_url" : "http:\/\/distillery.s3.amazonaws.com\/media\/2011\/08\/02\/60d13c5e9cd842dab16aa043e1f46b8b_7.jpg",
      "display_url" : "distillery.s3.amazonaws.com\/media\/2011\/08\/\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "164092494114590721",
  "geo" : { },
  "id_str" : "164093689130524672",
  "in_reply_to_user_id" : 191004758,
  "text" : "@PygmyLoris Excellent choice (and I'm not saying this because this is what's on the back of my left hand: http:\/\/t.co\/x4F6kNkL ;))",
  "id" : 164093689130524672,
  "in_reply_to_status_id" : 164092494114590721,
  "created_at" : "2012-01-30 21:12:38 +0000",
  "in_reply_to_screen_name" : "PygmyLoris",
  "in_reply_to_user_id_str" : "191004758",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 0, 10 ],
      "id_str" : "14700783",
      "id" : 14700783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "164083592325120001",
  "geo" : { },
  "id_str" : "164083960522080257",
  "in_reply_to_user_id" : 14700783,
  "text" : "@Fischblog Also Trauer mal sch\u00F6n brav um den gro\u00DFen Diktator ;)",
  "id" : 164083960522080257,
  "in_reply_to_status_id" : 164083592325120001,
  "created_at" : "2012-01-30 20:33:59 +0000",
  "in_reply_to_screen_name" : "Fischblog",
  "in_reply_to_user_id_str" : "14700783",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 0, 10 ],
      "id_str" : "14700783",
      "id" : 14700783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 67 ],
      "url" : "http:\/\/t.co\/akGCfKEi",
      "expanded_url" : "http:\/\/www.telegraph.co.uk\/news\/worldnews\/asia\/northkorea\/9040152\/North-Korea-threatens-to-punish-mobile-phone-users-as-war-criminals.html",
      "display_url" : "telegraph.co.uk\/news\/worldnews\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "164079889417375744",
  "geo" : { },
  "id_str" : "164080820666109952",
  "in_reply_to_user_id" : 14700783,
  "text" : "@Fischblog So einfach stimmt das ja nun nicht: http:\/\/t.co\/akGCfKEi :P",
  "id" : 164080820666109952,
  "in_reply_to_status_id" : 164079889417375744,
  "created_at" : "2012-01-30 20:21:30 +0000",
  "in_reply_to_screen_name" : "Fischblog",
  "in_reply_to_user_id_str" : "14700783",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 41 ],
      "url" : "http:\/\/t.co\/f5OFD44e",
      "expanded_url" : "http:\/\/j.mp\/ygQg7H",
      "display_url" : "j.mp\/ygQg7H"
    } ]
  },
  "geo" : { },
  "id_str" : "164071698407243778",
  "text" : "For all snake lovers http:\/\/t.co\/f5OFD44e",
  "id" : 164071698407243778,
  "created_at" : "2012-01-30 19:45:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 3, 12 ],
      "id_str" : "14245811",
      "id" : 14245811
    }, {
      "name" : "David Dobbs",
      "screen_name" : "David_Dobbs",
      "indices" : [ 20, 32 ],
      "id_str" : "14043142",
      "id" : 14043142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 112 ],
      "url" : "http:\/\/t.co\/pSMoznmH",
      "expanded_url" : "http:\/\/bit.ly\/xO88fz",
      "display_url" : "bit.ly\/xO88fz"
    } ]
  },
  "geo" : { },
  "id_str" : "164066757185765377",
  "text" : "RT @wilbanks: Check @David_Dobbs on the Open Science Movement catching fire. 'Bout time :-) http:\/\/t.co\/pSMoznmH",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "David Dobbs",
        "screen_name" : "David_Dobbs",
        "indices" : [ 6, 18 ],
        "id_str" : "14043142",
        "id" : 14043142
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 78, 98 ],
        "url" : "http:\/\/t.co\/pSMoznmH",
        "expanded_url" : "http:\/\/bit.ly\/xO88fz",
        "display_url" : "bit.ly\/xO88fz"
      } ]
    },
    "geo" : { },
    "id_str" : "164066303496302593",
    "text" : "Check @David_Dobbs on the Open Science Movement catching fire. 'Bout time :-) http:\/\/t.co\/pSMoznmH",
    "id" : 164066303496302593,
    "created_at" : "2012-01-30 19:23:49 +0000",
    "user" : {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "protected" : false,
      "id_str" : "14245811",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/925696899566440448\/BUTdp410_normal.jpg",
      "id" : 14245811,
      "verified" : false
    }
  },
  "id" : 164066757185765377,
  "created_at" : "2012-01-30 19:25:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "164066129675956225",
  "text" : "I accidentally the Flughafendemo.",
  "id" : 164066129675956225,
  "created_at" : "2012-01-30 19:23:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "164032367445553152",
  "geo" : { },
  "id_str" : "164032860397907968",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon haha, Gott bewahre :D",
  "id" : 164032860397907968,
  "in_reply_to_status_id" : 164032367445553152,
  "created_at" : "2012-01-30 17:10:56 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Goethe-Universit\u00E4t",
      "screen_name" : "goetheuni",
      "indices" : [ 48, 58 ],
      "id_str" : "38180826",
      "id" : 38180826
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "164031756389974016",
  "text" : "Mal schauen ob das Pr\u00FCfungsamt der Biologen der @goetheuni einen Antrag auf ein Betriebspraktikum per eMail akzeptiert.",
  "id" : 164031756389974016,
  "created_at" : "2012-01-30 17:06:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 72 ],
      "url" : "http:\/\/t.co\/lPpXejTV",
      "expanded_url" : "http:\/\/j.mp\/AaiHLf",
      "display_url" : "j.mp\/AaiHLf"
    } ]
  },
  "geo" : { },
  "id_str" : "164026217153036288",
  "text" : "Angebot und erzeugte Nachfrage: Konservierte Freude http:\/\/t.co\/lPpXejTV",
  "id" : 164026217153036288,
  "created_at" : "2012-01-30 16:44:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sebastian Greiner",
      "screen_name" : "Seb666",
      "indices" : [ 0, 7 ],
      "id_str" : "2365333778",
      "id" : 2365333778
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "164001746279071745",
  "geo" : { },
  "id_str" : "164001851845517313",
  "in_reply_to_user_id" : 18362640,
  "text" : "@Seb666 ups, ist schon so sp\u00E4t? :D also ja :)",
  "id" : 164001851845517313,
  "in_reply_to_status_id" : 164001746279071745,
  "created_at" : "2012-01-30 15:07:43 +0000",
  "in_reply_to_screen_name" : "NieMehrPiraten",
  "in_reply_to_user_id_str" : "18362640",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sebastian Greiner",
      "screen_name" : "Seb666",
      "indices" : [ 0, 7 ],
      "id_str" : "2365333778",
      "id" : 2365333778
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "163995728635629568",
  "geo" : { },
  "id_str" : "164001549645910017",
  "in_reply_to_user_id" : 18362640,
  "text" : "@Seb666 jo, anfang februar beim stammtisch h\u00F6chst?",
  "id" : 164001549645910017,
  "in_reply_to_status_id" : 163995728635629568,
  "created_at" : "2012-01-30 15:06:31 +0000",
  "in_reply_to_screen_name" : "NieMehrPiraten",
  "in_reply_to_user_id_str" : "18362640",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sebastian Greiner",
      "screen_name" : "Seb666",
      "indices" : [ 0, 7 ],
      "id_str" : "2365333778",
      "id" : 2365333778
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "163995419704180736",
  "geo" : { },
  "id_str" : "163995461269721088",
  "in_reply_to_user_id" : 18362640,
  "text" : "@Seb666 Oehm, ne.",
  "id" : 163995461269721088,
  "in_reply_to_status_id" : 163995419704180736,
  "created_at" : "2012-01-30 14:42:19 +0000",
  "in_reply_to_screen_name" : "NieMehrPiraten",
  "in_reply_to_user_id_str" : "18362640",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 136 ],
      "url" : "http:\/\/t.co\/73KRhsBm",
      "expanded_url" : "http:\/\/j.mp\/zgiWCi",
      "display_url" : "j.mp\/zgiWCi"
    } ]
  },
  "geo" : { },
  "id_str" : "163995207375925249",
  "text" : "Ultrasound halts sperm: \u00ABIn the meantime, I understand that blasting Nickelback is also an effective contraceptive\u00BB http:\/\/t.co\/73KRhsBm",
  "id" : 163995207375925249,
  "created_at" : "2012-01-30 14:41:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 44 ],
      "url" : "http:\/\/t.co\/s346PPm4",
      "expanded_url" : "http:\/\/j.mp\/wqMPwp",
      "display_url" : "j.mp\/wqMPwp"
    } ]
  },
  "geo" : { },
  "id_str" : "163962157267025920",
  "text" : "Eine Software f\u00FCr Moral http:\/\/t.co\/s346PPm4",
  "id" : 163962157267025920,
  "created_at" : "2012-01-30 12:29:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 68 ],
      "url" : "http:\/\/t.co\/NFJBI9Pk",
      "expanded_url" : "http:\/\/www.aerzteblatt.de\/nachrichten\/48928\/Studierende-entwickeln-Internetportal-zu-Genuntersuchungen",
      "display_url" : "aerzteblatt.de\/nachrichten\/48\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "163946294648389632",
  "text" : "Das \u00C4rzteblatt hat auch \u00FCber openSNP berichtet: http:\/\/t.co\/NFJBI9Pk",
  "id" : 163946294648389632,
  "created_at" : "2012-01-30 11:26:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NetDoktor.de",
      "screen_name" : "NetDoktorDE",
      "indices" : [ 0, 12 ],
      "id_str" : "19764861",
      "id" : 19764861
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "163916071932407808",
  "geo" : { },
  "id_str" : "163916171651977216",
  "in_reply_to_user_id" : 19764861,
  "text" : "@NetDoktorDE Danke! :)",
  "id" : 163916171651977216,
  "in_reply_to_status_id" : 163916071932407808,
  "created_at" : "2012-01-30 09:27:15 +0000",
  "in_reply_to_screen_name" : "NetDoktorDE",
  "in_reply_to_user_id_str" : "19764861",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NetDoktor.de",
      "screen_name" : "NetDoktorDE",
      "indices" : [ 10, 22 ],
      "id_str" : "19764861",
      "id" : 19764861
    }, {
      "name" : "openSNP team",
      "screen_name" : "openSNPorg",
      "indices" : [ 41, 52 ],
      "id_str" : "380205172",
      "id" : 380205172
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 86 ],
      "url" : "http:\/\/t.co\/pVXVfhxm",
      "expanded_url" : "http:\/\/www.netdoktor.de\/Magazin\/Striptease-fuers-Erbgut-12179.html",
      "display_url" : "netdoktor.de\/Magazin\/Stript\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "163915262515617792",
  "text" : "Cool, der @NetDoktorDE hat nun auch \u00FCber @openSNPorg geschrieben: http:\/\/t.co\/pVXVfhxm",
  "id" : 163915262515617792,
  "created_at" : "2012-01-30 09:23:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathan Eisen, Guardian of Microbial Diversity \uD83D\uDCA5\uD83D\uDD06",
      "screen_name" : "phylogenomics",
      "indices" : [ 3, 17 ],
      "id_str" : "15154811",
      "id" : 15154811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 121 ],
      "url" : "http:\/\/t.co\/fQCbAoRF",
      "expanded_url" : "http:\/\/goo.gl\/fb\/205U0",
      "display_url" : "goo.gl\/fb\/205U0"
    } ]
  },
  "geo" : { },
  "id_str" : "163906722229002240",
  "text" : "RT @phylogenomics: The Tree of Life: Boycotting Elsevier is not enough - time to make them invisible http:\/\/t.co\/fQCbAoRF",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 82, 102 ],
        "url" : "http:\/\/t.co\/fQCbAoRF",
        "expanded_url" : "http:\/\/goo.gl\/fb\/205U0",
        "display_url" : "goo.gl\/fb\/205U0"
      } ]
    },
    "geo" : { },
    "id_str" : "163902399164055552",
    "text" : "The Tree of Life: Boycotting Elsevier is not enough - time to make them invisible http:\/\/t.co\/fQCbAoRF",
    "id" : 163902399164055552,
    "created_at" : "2012-01-30 08:32:31 +0000",
    "user" : {
      "name" : "Jonathan Eisen, Guardian of Microbial Diversity \uD83D\uDCA5\uD83D\uDD06",
      "screen_name" : "phylogenomics",
      "protected" : false,
      "id_str" : "15154811",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/751288576403382273\/AKfTiFxx_normal.jpg",
      "id" : 15154811,
      "verified" : true
    }
  },
  "id" : 163906722229002240,
  "created_at" : "2012-01-30 08:49:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 104 ],
      "url" : "http:\/\/t.co\/UJQS1IpR",
      "expanded_url" : "http:\/\/j.mp\/AbfaPg",
      "display_url" : "j.mp\/AbfaPg"
    } ]
  },
  "geo" : { },
  "id_str" : "163903736283017216",
  "text" : "H\u00FCbsches Portrait in der Zeit: Edzard Ernst gegen Prinz Charles und die Hom\u00F6opathen http:\/\/t.co\/UJQS1IpR",
  "id" : 163903736283017216,
  "created_at" : "2012-01-30 08:37:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 83 ],
      "url" : "http:\/\/t.co\/8NiYtI2p",
      "expanded_url" : "http:\/\/j.mp\/AEWmHZ",
      "display_url" : "j.mp\/AEWmHZ"
    } ]
  },
  "geo" : { },
  "id_str" : "163900904158928896",
  "text" : "\u00ABElsevier's Publishing Model Might be About to Go Up in Smoke\u00BB http:\/\/t.co\/8NiYtI2p",
  "id" : 163900904158928896,
  "created_at" : "2012-01-30 08:26:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 108 ],
      "url" : "http:\/\/t.co\/l5qqZiay",
      "expanded_url" : "http:\/\/www.kickstarter.com\/projects\/citizenscience\/help-us-print-csq-issues-03-04?ref=card",
      "display_url" : "kickstarter.com\/projects\/citiz\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "163898726031687680",
  "text" : "Support the Citizen Science Quarterly do they can print issues 3 & 4 of their magazine. http:\/\/t.co\/l5qqZiay",
  "id" : 163898726031687680,
  "created_at" : "2012-01-30 08:17:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bioinformatik Bingen",
      "screen_name" : "bioinformatik",
      "indices" : [ 3, 17 ],
      "id_str" : "234886028",
      "id" : 234886028
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Nature",
      "indices" : [ 100, 107 ]
    }, {
      "text" : "Bioinformatik",
      "indices" : [ 108, 122 ]
    } ],
    "urls" : [ {
      "indices" : [ 79, 99 ],
      "url" : "http:\/\/t.co\/XCYGyBH1",
      "expanded_url" : "http:\/\/www.nature.com\/ng\/journal\/v44\/n2\/full\/ng.1099.html",
      "display_url" : "nature.com\/ng\/journal\/v44\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "163898522305970176",
  "text" : "RT @bioinformatik: \"Reformatting data is a full-time job for many researchers\" http:\/\/t.co\/XCYGyBH1 #Nature #Bioinformatik",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Nature",
        "indices" : [ 81, 88 ]
      }, {
        "text" : "Bioinformatik",
        "indices" : [ 89, 103 ]
      } ],
      "urls" : [ {
        "indices" : [ 60, 80 ],
        "url" : "http:\/\/t.co\/XCYGyBH1",
        "expanded_url" : "http:\/\/www.nature.com\/ng\/journal\/v44\/n2\/full\/ng.1099.html",
        "display_url" : "nature.com\/ng\/journal\/v44\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "163898042276265984",
    "text" : "\"Reformatting data is a full-time job for many researchers\" http:\/\/t.co\/XCYGyBH1 #Nature #Bioinformatik",
    "id" : 163898042276265984,
    "created_at" : "2012-01-30 08:15:13 +0000",
    "user" : {
      "name" : "Bioinformatik Bingen",
      "screen_name" : "bioinformatik",
      "protected" : false,
      "id_str" : "234886028",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/738332744502108160\/XEd5Vt7L_normal.jpg",
      "id" : 234886028,
      "verified" : false
    }
  },
  "id" : 163898522305970176,
  "created_at" : "2012-01-30 08:17:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "naturalismus",
      "screen_name" : "naturalismus",
      "indices" : [ 0, 13 ],
      "id_str" : "4562569648",
      "id" : 4562569648
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "163768414941351937",
  "geo" : { },
  "id_str" : "163768916747894784",
  "in_reply_to_user_id" : 77216385,
  "text" : "@Naturalismus mein Ziel f\u00FCr 2012 sind aktuell 45 B\u00FCcher, \u00FCberlege aber aufzustocken. :)",
  "id" : 163768916747894784,
  "in_reply_to_status_id" : 163768414941351937,
  "created_at" : "2012-01-29 23:42:07 +0000",
  "in_reply_to_screen_name" : "fireantprincess",
  "in_reply_to_user_id_str" : "77216385",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "naturalismus",
      "screen_name" : "naturalismus",
      "indices" : [ 0, 13 ],
      "id_str" : "4562569648",
      "id" : 4562569648
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "163768414941351937",
  "geo" : { },
  "id_str" : "163768671955722240",
  "in_reply_to_user_id" : 77216385,
  "text" : "@Naturalismus kriegst du so gesehen ja. Nur die Punktzahl normiert man selbst. ;)",
  "id" : 163768671955722240,
  "in_reply_to_status_id" : 163768414941351937,
  "created_at" : "2012-01-29 23:41:08 +0000",
  "in_reply_to_screen_name" : "fireantprincess",
  "in_reply_to_user_id_str" : "77216385",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "naturalismus",
      "screen_name" : "naturalismus",
      "indices" : [ 0, 13 ],
      "id_str" : "4562569648",
      "id" : 4562569648
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "163766190760660993",
  "geo" : { },
  "id_str" : "163767463283138560",
  "in_reply_to_user_id" : 77216385,
  "text" : "@Naturalismus nicht wirklich. Wobei du dir ein Ziel setzen kannst f\u00FCrs Jahr, wieviele B\u00FCcher du lesen willst & es zeigt wie im Plan man ist.",
  "id" : 163767463283138560,
  "in_reply_to_status_id" : 163766190760660993,
  "created_at" : "2012-01-29 23:36:20 +0000",
  "in_reply_to_screen_name" : "fireantprincess",
  "in_reply_to_user_id_str" : "77216385",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "naturalismus",
      "screen_name" : "naturalismus",
      "indices" : [ 0, 13 ],
      "id_str" : "4562569648",
      "id" : 4562569648
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "163765071607111680",
  "geo" : { },
  "id_str" : "163765389979959296",
  "in_reply_to_user_id" : 77216385,
  "text" : "@Naturalismus daf\u00FCr gibt es eine iPhone-App, wenn das hilft. ;)",
  "id" : 163765389979959296,
  "in_reply_to_status_id" : 163765071607111680,
  "created_at" : "2012-01-29 23:28:06 +0000",
  "in_reply_to_screen_name" : "fireantprincess",
  "in_reply_to_user_id_str" : "77216385",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "naturalismus",
      "screen_name" : "naturalismus",
      "indices" : [ 0, 13 ],
      "id_str" : "4562569648",
      "id" : 4562569648
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "163763975148929025",
  "geo" : { },
  "id_str" : "163764397901217792",
  "in_reply_to_user_id" : 77216385,
  "text" : "@Naturalismus absolut. Sonst h\u00E4tte ich es nicht an einem halben Tag verschlungen. Du solltest auch mal Goodreads nutzen. ;)",
  "id" : 163764397901217792,
  "in_reply_to_status_id" : 163763975148929025,
  "created_at" : "2012-01-29 23:24:09 +0000",
  "in_reply_to_screen_name" : "fireantprincess",
  "in_reply_to_user_id_str" : "77216385",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "naturalismus",
      "screen_name" : "naturalismus",
      "indices" : [ 0, 13 ],
      "id_str" : "4562569648",
      "id" : 4562569648
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "163689464529559552",
  "geo" : { },
  "id_str" : "163763616078774273",
  "in_reply_to_user_id" : 77216385,
  "text" : "@Naturalismus durch. Sehr sehr toll :)",
  "id" : 163763616078774273,
  "in_reply_to_status_id" : 163689464529559552,
  "created_at" : "2012-01-29 23:21:03 +0000",
  "in_reply_to_screen_name" : "fireantprincess",
  "in_reply_to_user_id_str" : "77216385",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "naturalismus",
      "screen_name" : "naturalismus",
      "indices" : [ 0, 13 ],
      "id_str" : "4562569648",
      "id" : 4562569648
    }, {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 14, 24 ],
      "id_str" : "14700783",
      "id" : 14700783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "163752075119968257",
  "geo" : { },
  "id_str" : "163763533736198144",
  "in_reply_to_user_id" : 77216385,
  "text" : "@Naturalismus @Fischblog bitte nicht ;)",
  "id" : 163763533736198144,
  "in_reply_to_status_id" : 163752075119968257,
  "created_at" : "2012-01-29 23:20:43 +0000",
  "in_reply_to_screen_name" : "fireantprincess",
  "in_reply_to_user_id_str" : "77216385",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 0, 10 ],
      "id_str" : "14700783",
      "id" : 14700783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "163748547559301120",
  "geo" : { },
  "id_str" : "163749688179294208",
  "in_reply_to_user_id" : 14700783,
  "text" : "@Fischblog So was bin\u00E4res ist aber nicht sehr postgender.",
  "id" : 163749688179294208,
  "in_reply_to_status_id" : 163748547559301120,
  "created_at" : "2012-01-29 22:25:42 +0000",
  "in_reply_to_screen_name" : "Fischblog",
  "in_reply_to_user_id_str" : "14700783",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "naturalismus",
      "screen_name" : "naturalismus",
      "indices" : [ 0, 13 ],
      "id_str" : "4562569648",
      "id" : 4562569648
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "163689464529559552",
  "geo" : { },
  "id_str" : "163690857139159041",
  "in_reply_to_user_id" : 77216385,
  "text" : "@Naturalismus mich auch, aber alleine im eigenen Bett statt in der Bahn\/Bus. ;)",
  "id" : 163690857139159041,
  "in_reply_to_status_id" : 163689464529559552,
  "created_at" : "2012-01-29 18:31:56 +0000",
  "in_reply_to_screen_name" : "fireantprincess",
  "in_reply_to_user_id_str" : "77216385",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "naturalismus",
      "screen_name" : "naturalismus",
      "indices" : [ 0, 13 ],
      "id_str" : "4562569648",
      "id" : 4562569648
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "163688534761406464",
  "geo" : { },
  "id_str" : "163688854161858560",
  "in_reply_to_user_id" : 77216385,
  "text" : "@Naturalismus Aber Spa\u00DF beiseite: Das Buch ist gut ausgew\u00E4hlt :)",
  "id" : 163688854161858560,
  "in_reply_to_status_id" : 163688534761406464,
  "created_at" : "2012-01-29 18:23:58 +0000",
  "in_reply_to_screen_name" : "fireantprincess",
  "in_reply_to_user_id_str" : "77216385",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "naturalismus",
      "screen_name" : "naturalismus",
      "indices" : [ 0, 13 ],
      "id_str" : "4562569648",
      "id" : 4562569648
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "163687981788561408",
  "geo" : { },
  "id_str" : "163688077750046720",
  "in_reply_to_user_id" : 77216385,
  "text" : "@Naturalismus Ja, ist etwas m\u00FChsam, aber mit genug Kaffee zum sp\u00FClen geht es ;)",
  "id" : 163688077750046720,
  "in_reply_to_status_id" : 163687981788561408,
  "created_at" : "2012-01-29 18:20:53 +0000",
  "in_reply_to_screen_name" : "fireantprincess",
  "in_reply_to_user_id_str" : "77216385",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "naturalismus",
      "screen_name" : "naturalismus",
      "indices" : [ 0, 13 ],
      "id_str" : "4562569648",
      "id" : 4562569648
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "163687574832025600",
  "in_reply_to_user_id" : 77216385,
  "text" : "@Naturalismus Danke f\u00FCr das Weihnachtsgeschenk noch mal. Bin gerade halb durch und bin begeistert. :)",
  "id" : 163687574832025600,
  "created_at" : "2012-01-29 18:18:53 +0000",
  "in_reply_to_screen_name" : "fireantprincess",
  "in_reply_to_user_id_str" : "77216385",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathan Eisen, Guardian of Microbial Diversity \uD83D\uDCA5\uD83D\uDD06",
      "screen_name" : "phylogenomics",
      "indices" : [ 3, 17 ],
      "id_str" : "15154811",
      "id" : 15154811
    }, {
      "name" : "Kevin Zelnio",
      "screen_name" : "kzelnio",
      "indices" : [ 19, 27 ],
      "id_str" : "19202541",
      "id" : 19202541
    }, {
      "name" : "Michael Eisen",
      "screen_name" : "mbeisen",
      "indices" : [ 28, 36 ],
      "id_str" : "19843630",
      "id" : 19843630
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AAAS",
      "indices" : [ 131, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "163660801511665664",
  "text" : "RT @phylogenomics: @kzelnio @mbeisen I think they mean \"American association for the advancement of (our beloved journal) Science\" #AAAS",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Kevin Zelnio",
        "screen_name" : "kzelnio",
        "indices" : [ 0, 8 ],
        "id_str" : "19202541",
        "id" : 19202541
      }, {
        "name" : "Michael Eisen",
        "screen_name" : "mbeisen",
        "indices" : [ 9, 17 ],
        "id_str" : "19843630",
        "id" : 19843630
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "AAAS",
        "indices" : [ 112, 117 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "163660265844518912",
    "geo" : { },
    "id_str" : "163660579859476481",
    "in_reply_to_user_id" : 19202541,
    "text" : "@kzelnio @mbeisen I think they mean \"American association for the advancement of (our beloved journal) Science\" #AAAS",
    "id" : 163660579859476481,
    "in_reply_to_status_id" : 163660265844518912,
    "created_at" : "2012-01-29 16:31:37 +0000",
    "in_reply_to_screen_name" : "kzelnio",
    "in_reply_to_user_id_str" : "19202541",
    "user" : {
      "name" : "Jonathan Eisen, Guardian of Microbial Diversity \uD83D\uDCA5\uD83D\uDD06",
      "screen_name" : "phylogenomics",
      "protected" : false,
      "id_str" : "15154811",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/751288576403382273\/AKfTiFxx_normal.jpg",
      "id" : 15154811,
      "verified" : true
    }
  },
  "id" : 163660801511665664,
  "created_at" : "2012-01-29 16:32:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "163563510238937088",
  "geo" : { },
  "id_str" : "163620567994470401",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon Im Keller ist er auch nicht :\/",
  "id" : 163620567994470401,
  "in_reply_to_status_id" : 163563510238937088,
  "created_at" : "2012-01-29 13:52:37 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 84 ],
      "url" : "http:\/\/t.co\/5kpxiQ8M",
      "expanded_url" : "http:\/\/io9.com\/5875405\/why-cyborgs-and-mutants-are-more-likely-to-kill-us-than-robots",
      "display_url" : "io9.com\/5875405\/why-cy\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "163603347344076801",
  "text" : "Why cyborgs and mutants are more likely to kill us than robots  http:\/\/t.co\/5kpxiQ8M",
  "id" : 163603347344076801,
  "created_at" : "2012-01-29 12:44:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Freakonometrics",
      "screen_name" : "freakonometrics",
      "indices" : [ 3, 19 ],
      "id_str" : "105530526",
      "id" : 105530526
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 129 ],
      "url" : "http:\/\/t.co\/0fSrpxIN",
      "expanded_url" : "http:\/\/arxiv.org\/abs\/1201.2590",
      "display_url" : "arxiv.org\/abs\/1201.2590"
    } ]
  },
  "geo" : { },
  "id_str" : "163596612202012672",
  "text" : "RT @freakonometrics: \"We should cease teaching frequentist statistics to undergraduates and switch to Bayes\" http:\/\/t.co\/0fSrpxIN via @z ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Luis A. Apiolaza",
        "screen_name" : "zentree",
        "indices" : [ 113, 121 ],
        "id_str" : "12306",
        "id" : 12306
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 88, 108 ],
        "url" : "http:\/\/t.co\/0fSrpxIN",
        "expanded_url" : "http:\/\/arxiv.org\/abs\/1201.2590",
        "display_url" : "arxiv.org\/abs\/1201.2590"
      } ]
    },
    "geo" : { },
    "id_str" : "163596148970500096",
    "text" : "\"We should cease teaching frequentist statistics to undergraduates and switch to Bayes\" http:\/\/t.co\/0fSrpxIN via @zentree",
    "id" : 163596148970500096,
    "created_at" : "2012-01-29 12:15:36 +0000",
    "user" : {
      "name" : "Freakonometrics",
      "screen_name" : "freakonometrics",
      "protected" : false,
      "id_str" : "105530526",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/753994578131357696\/6_ps0aEW_normal.jpg",
      "id" : 105530526,
      "verified" : true
    }
  },
  "id" : 163596612202012672,
  "created_at" : "2012-01-29 12:17:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "163587995658747905",
  "geo" : { },
  "id_str" : "163588176273874944",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer Yeah, sounds good :)",
  "id" : 163588176273874944,
  "in_reply_to_status_id" : 163587995658747905,
  "created_at" : "2012-01-29 11:43:55 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "163587249961840640",
  "geo" : { },
  "id_str" : "163587600307851264",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer Damn, when is your plane leaving? :)",
  "id" : 163587600307851264,
  "in_reply_to_status_id" : 163587249961840640,
  "created_at" : "2012-01-29 11:41:37 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 111 ],
      "url" : "http:\/\/t.co\/oZaQJvXu",
      "expanded_url" : "http:\/\/www.crackajack.de\/2012\/01\/28\/hr2-der-tag-auf-der-galgenwiese-vom-handwerk-des-hinrichtens\/",
      "display_url" : "crackajack.de\/2012\/01\/28\/hr2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "163587508003807232",
  "text" : "HR2 Der Tag macht also auch Torture Porn: Spannende Sendung \u00FCber Historie der Hinrichtung. http:\/\/t.co\/oZaQJvXu",
  "id" : 163587508003807232,
  "created_at" : "2012-01-29 11:41:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "163584481461149697",
  "geo" : { },
  "id_str" : "163584609949450240",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer btw. are you still in Germany or already back to AUS?",
  "id" : 163584609949450240,
  "in_reply_to_status_id" : 163584481461149697,
  "created_at" : "2012-01-29 11:29:44 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "163584481461149697",
  "geo" : { },
  "id_str" : "163584563120058368",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer Crazy shit :D",
  "id" : 163584563120058368,
  "in_reply_to_status_id" : 163584481461149697,
  "created_at" : "2012-01-29 11:29:33 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 67 ],
      "url" : "http:\/\/t.co\/y0c3gxQy",
      "expanded_url" : "http:\/\/j.mp\/yp03c4",
      "display_url" : "j.mp\/yp03c4"
    } ]
  },
  "geo" : { },
  "id_str" : "163577342734761984",
  "text" : "Great Idea: A Open Archive of My F1000 Reviews http:\/\/t.co\/y0c3gxQy",
  "id" : 163577342734761984,
  "created_at" : "2012-01-29 11:00:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ralf Petring",
      "screen_name" : "petringlegal",
      "indices" : [ 3, 16 ],
      "id_str" : "96568072",
      "id" : 96568072
    }, {
      "name" : "Jens Ferner",
      "screen_name" : "jensferner",
      "indices" : [ 57, 68 ],
      "id_str" : "18864811",
      "id" : 18864811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "163576164676419584",
  "text" : "RT @petringlegal: Heftige, berechtigte Kritik v. Kollege @jensferner an Wikipedia-Inhalten zur Filesharing-Abmahnung http:\/\/t.co\/StuMmMu ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jens Ferner",
        "screen_name" : "jensferner",
        "indices" : [ 39, 50 ],
        "id_str" : "18864811",
        "id" : 18864811
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Urheberrecht",
        "indices" : [ 120, 133 ]
      } ],
      "urls" : [ {
        "indices" : [ 99, 119 ],
        "url" : "http:\/\/t.co\/StuMmMuY",
        "expanded_url" : "http:\/\/ferner-alsdorf.de\/2012\/01\/desastros-filesharing-abmahnung-auf-wikipedia\/wettbewerbsrecht\/strafrecht\/rechtsanwalt\/verkehrsrecht\/?isalt=0",
        "display_url" : "ferner-alsdorf.de\/2012\/01\/desast\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "163573850838278144",
    "text" : "Heftige, berechtigte Kritik v. Kollege @jensferner an Wikipedia-Inhalten zur Filesharing-Abmahnung http:\/\/t.co\/StuMmMuY #Urheberrecht",
    "id" : 163573850838278144,
    "created_at" : "2012-01-29 10:46:59 +0000",
    "user" : {
      "name" : "Ralf Petring",
      "screen_name" : "petringlegal",
      "protected" : false,
      "id_str" : "96568072",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1595000999\/Dr_Ralf_Petring_Rechtsanwalt_normal.jpg",
      "id" : 96568072,
      "verified" : false
    }
  },
  "id" : 163576164676419584,
  "created_at" : "2012-01-29 10:56:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "163567815541002240",
  "geo" : { },
  "id_str" : "163568696873332736",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer looks just like Disneyland!",
  "id" : 163568696873332736,
  "in_reply_to_status_id" : 163567815541002240,
  "created_at" : "2012-01-29 10:26:30 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "163562948118323200",
  "geo" : { },
  "id_str" : "163563169862787072",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon so steht aber seit Freitag Nachmittag die Gartent\u00FCr auf.",
  "id" : 163563169862787072,
  "in_reply_to_status_id" : 163562948118323200,
  "created_at" : "2012-01-29 10:04:33 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "163560673253670912",
  "geo" : { },
  "id_str" : "163562810343817216",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon nein, eine Katzenklappe...",
  "id" : 163562810343817216,
  "in_reply_to_status_id" : 163560673253670912,
  "created_at" : "2012-01-29 10:03:07 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "163559796258242561",
  "geo" : { },
  "id_str" : "163560177172353024",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon ja, wobei wenn er in den Garagen w\u00E4re w\u00FCrd man ihn maunzen h\u00F6ren.",
  "id" : 163560177172353024,
  "in_reply_to_status_id" : 163559796258242561,
  "created_at" : "2012-01-29 09:52:39 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "163558230616842240",
  "geo" : { },
  "id_str" : "163559521707507713",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon im Keller war ich noch nicht.",
  "id" : 163559521707507713,
  "in_reply_to_status_id" : 163558230616842240,
  "created_at" : "2012-01-29 09:50:03 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "163547594990174208",
  "geo" : { },
  "id_str" : "163557889179525121",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon kein Kater, trotz Suchaktion :(",
  "id" : 163557889179525121,
  "in_reply_to_status_id" : 163547594990174208,
  "created_at" : "2012-01-29 09:43:34 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Misha Angrist",
      "screen_name" : "MishaAngrist",
      "indices" : [ 3, 16 ],
      "id_str" : "116877838",
      "id" : 116877838
    }, {
      "name" : "Seth Mnookin",
      "screen_name" : "sethmnookin",
      "indices" : [ 21, 33 ],
      "id_str" : "22931893",
      "id" : 22931893
    }, {
      "name" : "Baroness Dr Rachael",
      "screen_name" : "DrRachie",
      "indices" : [ 38, 47 ],
      "id_str" : "15196135",
      "id" : 15196135
    }, {
      "name" : "Zite",
      "screen_name" : "Zite",
      "indices" : [ 133, 138 ],
      "id_str" : "110558385",
      "id" : 110558385
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 128 ],
      "url" : "http:\/\/t.co\/kiuK1xie",
      "expanded_url" : "http:\/\/zite.to\/yAdWmo",
      "display_url" : "zite.to\/yAdWmo"
    } ]
  },
  "geo" : { },
  "id_str" : "163423567168544769",
  "text" : "RT @MishaAngrist: RT @sethmnookin: RT @DrRachie: Why I chose to decline an invitation to review by Elsevier http:\/\/t.co\/kiuK1xie via @zite",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Seth Mnookin",
        "screen_name" : "sethmnookin",
        "indices" : [ 3, 15 ],
        "id_str" : "22931893",
        "id" : 22931893
      }, {
        "name" : "Baroness Dr Rachael",
        "screen_name" : "DrRachie",
        "indices" : [ 20, 29 ],
        "id_str" : "15196135",
        "id" : 15196135
      }, {
        "name" : "Zite",
        "screen_name" : "Zite",
        "indices" : [ 115, 120 ],
        "id_str" : "110558385",
        "id" : 110558385
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 90, 110 ],
        "url" : "http:\/\/t.co\/kiuK1xie",
        "expanded_url" : "http:\/\/zite.to\/yAdWmo",
        "display_url" : "zite.to\/yAdWmo"
      } ]
    },
    "geo" : { },
    "id_str" : "163421786023792641",
    "text" : "RT @sethmnookin: RT @DrRachie: Why I chose to decline an invitation to review by Elsevier http:\/\/t.co\/kiuK1xie via @zite",
    "id" : 163421786023792641,
    "created_at" : "2012-01-29 00:42:44 +0000",
    "user" : {
      "name" : "Misha Angrist",
      "screen_name" : "MishaAngrist",
      "protected" : false,
      "id_str" : "116877838",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747461459974717441\/GIrZkLT-_normal.jpg",
      "id" : 116877838,
      "verified" : false
    }
  },
  "id" : 163423567168544769,
  "created_at" : "2012-01-29 00:49:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "163389039507013635",
  "geo" : { },
  "id_str" : "163389751892779009",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon na klar, der hat dich doch gern. Und wem sollte er sonst im Gesicht rumtreten?",
  "id" : 163389751892779009,
  "in_reply_to_status_id" : 163389039507013635,
  "created_at" : "2012-01-28 22:35:27 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "163374492150808576",
  "geo" : { },
  "id_str" : "163374984511754240",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon na klar. Sp\u00E4testens morgen, wenn die Frau zum nerven wieder da ist, kommt er zur\u00FCck. ;)",
  "id" : 163374984511754240,
  "in_reply_to_status_id" : 163374492150808576,
  "created_at" : "2012-01-28 21:36:46 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "163373593487605760",
  "geo" : { },
  "id_str" : "163374244284211201",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon ihm ist bestimmt nichts passiert Hase. Ich geh auch gleich noch mal eine Runde um den Block zum Suchen.",
  "id" : 163374244284211201,
  "in_reply_to_status_id" : 163373593487605760,
  "created_at" : "2012-01-28 21:33:49 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "163373593487605760",
  "geo" : { },
  "id_str" : "163373808638636032",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon dann ist es doch kein Wunder das er sich erstmal wo anders vollstopfen l\u00E4sst ;)",
  "id" : 163373808638636032,
  "in_reply_to_status_id" : 163373593487605760,
  "created_at" : "2012-01-28 21:32:05 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "163373074568314880",
  "geo" : { },
  "id_str" : "163373322317471744",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon der taucht schon wieder auf. Das macht er doch manchmal. Ist bestimmt bei seiner Zweitfamilie.",
  "id" : 163373322317471744,
  "in_reply_to_status_id" : 163373074568314880,
  "created_at" : "2012-01-28 21:30:10 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "163372787896033280",
  "geo" : { },
  "id_str" : "163372963893227520",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon ich weiss es nicht. Er ist noch nicht wieder aufgetaucht und die Suche war erfolglos :(",
  "id" : 163372963893227520,
  "in_reply_to_status_id" : 163372787896033280,
  "created_at" : "2012-01-28 21:28:44 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "S\u00F6ren Schewe",
      "screen_name" : "Roterhai",
      "indices" : [ 0, 9 ],
      "id_str" : "25101713",
      "id" : 25101713
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "163337229928902656",
  "geo" : { },
  "id_str" : "163337290687578112",
  "in_reply_to_user_id" : 25101713,
  "text" : "@Roterhai okay ;)",
  "id" : 163337290687578112,
  "in_reply_to_status_id" : 163337229928902656,
  "created_at" : "2012-01-28 19:06:59 +0000",
  "in_reply_to_screen_name" : "Roterhai",
  "in_reply_to_user_id_str" : "25101713",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "S\u00F6ren Schewe",
      "screen_name" : "Roterhai",
      "indices" : [ 0, 9 ],
      "id_str" : "25101713",
      "id" : 25101713
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 105 ],
      "url" : "http:\/\/t.co\/1siX43Gw",
      "expanded_url" : "http:\/\/www.goodreads.com\/user\/show\/5925863-bastian-greshake",
      "display_url" : "goodreads.com\/user\/show\/5925\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "163336823735721985",
  "geo" : { },
  "id_str" : "163337147485659136",
  "in_reply_to_user_id" : 25101713,
  "text" : "@Roterhai man kann mir auch bei Goodreads folgen um meine Buchtipps mitzubekommen :) http:\/\/t.co\/1siX43Gw",
  "id" : 163337147485659136,
  "in_reply_to_status_id" : 163336823735721985,
  "created_at" : "2012-01-28 19:06:25 +0000",
  "in_reply_to_screen_name" : "Roterhai",
  "in_reply_to_user_id_str" : "25101713",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "S\u00F6ren Schewe",
      "screen_name" : "Roterhai",
      "indices" : [ 0, 9 ],
      "id_str" : "25101713",
      "id" : 25101713
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 15, 24 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 84 ],
      "url" : "http:\/\/t.co\/zBM1ZGP9",
      "expanded_url" : "http:\/\/www.amazon.de\/Charlatan-Americas-Dangerous-Huckster-ebook\/dp\/B0013SSPVE\/ref=sr_1_1?s=books-intl-de&ie=UTF8&qid=1327777269&sr=1-1",
      "display_url" : "amazon.de\/Charlatan-Amer\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "163335689247801345",
  "geo" : { },
  "id_str" : "163336385573560320",
  "in_reply_to_user_id" : 25101713,
  "text" : "@Roterhai also @Senficon besteht darauf das ich erst dies lese: http:\/\/t.co\/zBM1ZGP9",
  "id" : 163336385573560320,
  "in_reply_to_status_id" : 163335689247801345,
  "created_at" : "2012-01-28 19:03:23 +0000",
  "in_reply_to_screen_name" : "Roterhai",
  "in_reply_to_user_id_str" : "25101713",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "S\u00F6ren Schewe",
      "screen_name" : "Roterhai",
      "indices" : [ 0, 9 ],
      "id_str" : "25101713",
      "id" : 25101713
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "163335343133835264",
  "geo" : { },
  "id_str" : "163335448175976448",
  "in_reply_to_user_id" : 25101713,
  "text" : "@Roterhai in der Theorie, aber selbst nicht gelesen.",
  "id" : 163335448175976448,
  "in_reply_to_status_id" : 163335343133835264,
  "created_at" : "2012-01-28 18:59:40 +0000",
  "in_reply_to_screen_name" : "Roterhai",
  "in_reply_to_user_id_str" : "25101713",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 70 ],
      "url" : "http:\/\/t.co\/AkpW5uWp",
      "expanded_url" : "http:\/\/j.mp\/xtsPOe",
      "display_url" : "j.mp\/xtsPOe"
    } ]
  },
  "geo" : { },
  "id_str" : "163335140607655937",
  "text" : "\u00ABWe\u2019ll be a nation full of immortal poor people.\u00BB http:\/\/t.co\/AkpW5uWp",
  "id" : 163335140607655937,
  "created_at" : "2012-01-28 18:58:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "naturalismus",
      "screen_name" : "naturalismus",
      "indices" : [ 0, 13 ],
      "id_str" : "4562569648",
      "id" : 4562569648
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "163321647699464192",
  "geo" : { },
  "id_str" : "163322026973601792",
  "in_reply_to_user_id" : 77216385,
  "text" : "@Naturalismus so viel Freiheit hatten wir bei uns halt nicht. Praktika nicht besucht-&gt;Durchs Modul gefallen-&gt;Nur 2 Wiederholungsversuche.",
  "id" : 163322026973601792,
  "in_reply_to_status_id" : 163321647699464192,
  "created_at" : "2012-01-28 18:06:20 +0000",
  "in_reply_to_screen_name" : "fireantprincess",
  "in_reply_to_user_id_str" : "77216385",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "naturalismus",
      "screen_name" : "naturalismus",
      "indices" : [ 0, 13 ],
      "id_str" : "4562569648",
      "id" : 4562569648
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IAmScience",
      "indices" : [ 38, 49 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "163320741603971075",
  "geo" : { },
  "id_str" : "163321332099059714",
  "in_reply_to_user_id" : 77216385,
  "text" : "@Naturalismus und sonst schau dir mal #IAmScience an :)",
  "id" : 163321332099059714,
  "in_reply_to_status_id" : 163320741603971075,
  "created_at" : "2012-01-28 18:03:34 +0000",
  "in_reply_to_screen_name" : "fireantprincess",
  "in_reply_to_user_id_str" : "77216385",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "naturalismus",
      "screen_name" : "naturalismus",
      "indices" : [ 0, 13 ],
      "id_str" : "4562569648",
      "id" : 4562569648
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "163320741603971075",
  "geo" : { },
  "id_str" : "163321144387186688",
  "in_reply_to_user_id" : 77216385,
  "text" : "@Naturalismus die ersten 1 1\/2 Jahre hat man mich ausserhalb von Pflichtveranstaltungen gar nicht gesehen.",
  "id" : 163321144387186688,
  "in_reply_to_status_id" : 163320741603971075,
  "created_at" : "2012-01-28 18:02:49 +0000",
  "in_reply_to_screen_name" : "fireantprincess",
  "in_reply_to_user_id_str" : "77216385",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "naturalismus",
      "screen_name" : "naturalismus",
      "indices" : [ 0, 13 ],
      "id_str" : "4562569648",
      "id" : 4562569648
    }, {
      "name" : "Rya",
      "screen_name" : "_Rya_",
      "indices" : [ 14, 20 ],
      "id_str" : "89234537",
      "id" : 89234537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "163320335482109952",
  "geo" : { },
  "id_str" : "163320565741010944",
  "in_reply_to_user_id" : 77216385,
  "text" : "@Naturalismus @_Rya_ wenn ich mal in der Uni gewesen w\u00E4re, dann h\u00E4tten meine mich wohl auch dazu gew\u00E4hlt ;)",
  "id" : 163320565741010944,
  "in_reply_to_status_id" : 163320335482109952,
  "created_at" : "2012-01-28 18:00:31 +0000",
  "in_reply_to_screen_name" : "fireantprincess",
  "in_reply_to_user_id_str" : "77216385",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Stool Pigeon",
      "screen_name" : "TheStoolPigeon",
      "indices" : [ 3, 18 ],
      "id_str" : "171041642",
      "id" : 171041642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 138 ],
      "url" : "http:\/\/t.co\/KgFFgKeX",
      "expanded_url" : "http:\/\/bit.ly\/y005jW",
      "display_url" : "bit.ly\/y005jW"
    } ]
  },
  "geo" : { },
  "id_str" : "163304451216646144",
  "text" : "RT @TheStoolPigeon: Incredible! A blogger has worked out the exact day that Ice Cube's 'It Was A Good Day' refers to: http:\/\/t.co\/KgFFgKeX",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 98, 118 ],
        "url" : "http:\/\/t.co\/KgFFgKeX",
        "expanded_url" : "http:\/\/bit.ly\/y005jW",
        "display_url" : "bit.ly\/y005jW"
      } ]
    },
    "geo" : { },
    "id_str" : "163288322100305920",
    "text" : "Incredible! A blogger has worked out the exact day that Ice Cube's 'It Was A Good Day' refers to: http:\/\/t.co\/KgFFgKeX",
    "id" : 163288322100305920,
    "created_at" : "2012-01-28 15:52:24 +0000",
    "user" : {
      "name" : "The Stool Pigeon",
      "screen_name" : "TheStoolPigeon",
      "protected" : false,
      "id_str" : "171041642",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3240203071\/9a953a4930ff5d69bded121bd7f9a750_normal.jpeg",
      "id" : 171041642,
      "verified" : false
    }
  },
  "id" : 163304451216646144,
  "created_at" : "2012-01-28 16:56:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "163302775185354753",
  "geo" : { },
  "id_str" : "163302987840757761",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon na klar. Aber das macht er ja nicht das erste Mal. Ich Denk er kommt heut oder morgen fr\u00FCh wieder.",
  "id" : 163302987840757761,
  "in_reply_to_status_id" : 163302775185354753,
  "created_at" : "2012-01-28 16:50:40 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "163302427590799361",
  "geo" : { },
  "id_str" : "163302518439411712",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon mach ich.",
  "id" : 163302518439411712,
  "in_reply_to_status_id" : 163302427590799361,
  "created_at" : "2012-01-28 16:48:49 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "163300869545271296",
  "geo" : { },
  "id_str" : "163302363665408000",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon bei aww f\u00E4llt mir auf: der Kater ist immer noch nicht aufgetaucht. :(",
  "id" : 163302363665408000,
  "in_reply_to_status_id" : 163300869545271296,
  "created_at" : "2012-01-28 16:48:12 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "viirus",
      "screen_name" : "viirus42",
      "indices" : [ 0, 9 ],
      "id_str" : "81582697",
      "id" : 81582697
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "163300698136657920",
  "geo" : { },
  "id_str" : "163302199248691201",
  "in_reply_to_user_id" : 81582697,
  "text" : "@viirus42 jo, kurz vor dem Abi.",
  "id" : 163302199248691201,
  "in_reply_to_status_id" : 163300698136657920,
  "created_at" : "2012-01-28 16:47:32 +0000",
  "in_reply_to_screen_name" : "viirus42",
  "in_reply_to_user_id_str" : "81582697",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "oipd12",
      "indices" : [ 19, 26 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 110 ],
      "url" : "http:\/\/t.co\/BOJhYuTK",
      "expanded_url" : "http:\/\/lockerz.com\/s\/178573863",
      "display_url" : "lockerz.com\/s\/178573863"
    } ]
  },
  "geo" : { },
  "id_str" : "163299665494806528",
  "text" : "Meinen Beitrag zum #oipd12 hatte ich schon mal gepostet. Ist aber immer noch Black Metal. http:\/\/t.co\/BOJhYuTK",
  "id" : 163299665494806528,
  "created_at" : "2012-01-28 16:37:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sven Rudloff",
      "screen_name" : "svenrudloff",
      "indices" : [ 3, 15 ],
      "id_str" : "15765206",
      "id" : 15765206
    }, {
      "name" : "Florian Freistetter",
      "screen_name" : "astrodicticum",
      "indices" : [ 20, 34 ],
      "id_str" : "15318271",
      "id" : 15318271
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 136 ],
      "url" : "http:\/\/t.co\/Rh0VWl42",
      "expanded_url" : "http:\/\/is.gd\/YV34hU",
      "display_url" : "is.gd\/YV34hU"
    } ]
  },
  "geo" : { },
  "id_str" : "163267638900953089",
  "text" : "RT @svenrudloff: RT @astrodicticum: \"Wissenschaftler emigrieren, Scharlatane bekommen Orden vom Bundespr\u00E4sidenten\": http:\/\/t.co\/Rh0VWl42",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Florian Freistetter",
        "screen_name" : "astrodicticum",
        "indices" : [ 3, 17 ],
        "id_str" : "15318271",
        "id" : 15318271
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 99, 119 ],
        "url" : "http:\/\/t.co\/Rh0VWl42",
        "expanded_url" : "http:\/\/is.gd\/YV34hU",
        "display_url" : "is.gd\/YV34hU"
      } ]
    },
    "geo" : { },
    "id_str" : "163263280549347329",
    "text" : "RT @astrodicticum: \"Wissenschaftler emigrieren, Scharlatane bekommen Orden vom Bundespr\u00E4sidenten\": http:\/\/t.co\/Rh0VWl42",
    "id" : 163263280549347329,
    "created_at" : "2012-01-28 14:12:54 +0000",
    "user" : {
      "name" : "Sven Rudloff",
      "screen_name" : "svenrudloff",
      "protected" : false,
      "id_str" : "15765206",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/818518861393825792\/jtMplh59_normal.jpg",
      "id" : 15765206,
      "verified" : false
    }
  },
  "id" : 163267638900953089,
  "created_at" : "2012-01-28 14:30:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 5, 14 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 99 ],
      "url" : "http:\/\/t.co\/2IahscfK",
      "expanded_url" : "http:\/\/j.mp\/zj4iMc",
      "display_url" : "j.mp\/zj4iMc"
    } ]
  },
  "geo" : { },
  "id_str" : "163062766377238529",
  "text" : "Wenn @Senficon das sieht dann weiss ich was wir bald im Garten stehen haben... http:\/\/t.co\/2IahscfK",
  "id" : 163062766377238529,
  "created_at" : "2012-01-28 00:56:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "I Secular Ex",
      "screen_name" : "alexcruise",
      "indices" : [ 3, 14 ],
      "id_str" : "20013285",
      "id" : 20013285
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "163055862561255424",
  "text" : "RT @alexcruise: Another stupendous Quora answer. \"Why are software development task estimations regularly off by a factor of 2-3?\" http: ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 135 ],
        "url" : "http:\/\/t.co\/ldfiFaOx",
        "expanded_url" : "http:\/\/www.quora.com\/Why-are-software-development-task-estimations-regularly-off-by-a-factor-of-2-3\/answer\/Michael-Wolfe?srid=kw",
        "display_url" : "quora.com\/Why-are-softwa\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "163012086522318848",
    "text" : "Another stupendous Quora answer. \"Why are software development task estimations regularly off by a factor of 2-3?\" http:\/\/t.co\/ldfiFaOx",
    "id" : 163012086522318848,
    "created_at" : "2012-01-27 21:34:44 +0000",
    "user" : {
      "name" : "I Secular Ex",
      "screen_name" : "alexcruise",
      "protected" : false,
      "id_str" : "20013285",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793147927950610432\/cwWRg661_normal.jpg",
      "id" : 20013285,
      "verified" : false
    }
  },
  "id" : 163055862561255424,
  "created_at" : "2012-01-28 00:28:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jerry Coyne",
      "screen_name" : "Evolutionistrue",
      "indices" : [ 3, 19 ],
      "id_str" : "127305588",
      "id" : 127305588
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 83 ],
      "url" : "http:\/\/t.co\/kk8gaTMA",
      "expanded_url" : "http:\/\/wp.me\/ppUXF-e9c",
      "display_url" : "wp.me\/ppUXF-e9c"
    } ]
  },
  "geo" : { },
  "id_str" : "163021799829934080",
  "text" : "RT @Evolutionistrue: A cartoon history of evolutionary biology http:\/\/t.co\/kk8gaTMA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 42, 62 ],
        "url" : "http:\/\/t.co\/kk8gaTMA",
        "expanded_url" : "http:\/\/wp.me\/ppUXF-e9c",
        "display_url" : "wp.me\/ppUXF-e9c"
      } ]
    },
    "geo" : { },
    "id_str" : "163020162235236352",
    "text" : "A cartoon history of evolutionary biology http:\/\/t.co\/kk8gaTMA",
    "id" : 163020162235236352,
    "created_at" : "2012-01-27 22:06:50 +0000",
    "user" : {
      "name" : "Jerry Coyne",
      "screen_name" : "Evolutionistrue",
      "protected" : false,
      "id_str" : "127305588",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/768814617837596673\/BIuC-_yL_normal.jpg",
      "id" : 127305588,
      "verified" : false
    }
  },
  "id" : 163021799829934080,
  "created_at" : "2012-01-27 22:13:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "openaccess",
      "indices" : [ 102, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 134 ],
      "url" : "http:\/\/t.co\/aQ6ibWwQ",
      "expanded_url" : "http:\/\/scientopia.org\/blogs\/drugmonkey\/2012\/01\/27\/publisher-statements-that-may-get-me-on-the-boycott-peer-review-bandwagon\/",
      "display_url" : "scientopia.org\/blogs\/drugmonk\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "163000193225211904",
  "text" : "THIS: \u00ABSo what do the publisher's add to the \"peer review\" of journal articles? I really don't know.\u00BB #openaccess http:\/\/t.co\/aQ6ibWwQ",
  "id" : 163000193225211904,
  "created_at" : "2012-01-27 20:47:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Wilkins",
      "screen_name" : "jonfwilkins",
      "indices" : [ 3, 15 ],
      "id_str" : "214099847",
      "id" : 214099847
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 116 ],
      "url" : "http:\/\/t.co\/EPuSYpj6",
      "expanded_url" : "http:\/\/www.darwineatscake.com\/?id=85",
      "display_url" : "darwineatscake.com\/?id=85"
    } ]
  },
  "geo" : { },
  "id_str" : "162984568436178944",
  "text" : "RT @jonfwilkins: RT: How do scientists feel about the journals Science and Nature? A flowchart. http:\/\/t.co\/EPuSYpj6",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 79, 99 ],
        "url" : "http:\/\/t.co\/EPuSYpj6",
        "expanded_url" : "http:\/\/www.darwineatscake.com\/?id=85",
        "display_url" : "darwineatscake.com\/?id=85"
      } ]
    },
    "geo" : { },
    "id_str" : "162984503629979648",
    "text" : "RT: How do scientists feel about the journals Science and Nature? A flowchart. http:\/\/t.co\/EPuSYpj6",
    "id" : 162984503629979648,
    "created_at" : "2012-01-27 19:45:08 +0000",
    "user" : {
      "name" : "Jon Wilkins",
      "screen_name" : "jonfwilkins",
      "protected" : false,
      "id_str" : "214099847",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1279449740\/Dev2DEC_normal.jpg",
      "id" : 214099847,
      "verified" : false
    }
  },
  "id" : 162984568436178944,
  "created_at" : "2012-01-27 19:45:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Zelnio",
      "screen_name" : "kzelnio",
      "indices" : [ 83, 91 ],
      "id_str" : "19202541",
      "id" : 19202541
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "iamscience",
      "indices" : [ 124, 135 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 112 ],
      "url" : "http:\/\/t.co\/wohxHyXz",
      "expanded_url" : "http:\/\/deepseanews.com\/2012\/01\/iamscience-embracing-personal-experience-on-our-rise-through-science\/",
      "display_url" : "deepseanews.com\/2012\/01\/iamsci\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "162981665059258368",
  "text" : "Embracing Personal Experience on Our Rise Through Science. Read this great post by @kzelnio http:\/\/t.co\/wohxHyXz and follow #iamscience",
  "id" : 162981665059258368,
  "created_at" : "2012-01-27 19:33:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zen Faulkes",
      "screen_name" : "DoctorZen",
      "indices" : [ 3, 13 ],
      "id_str" : "16486812",
      "id" : 16486812
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/JH1NomwW",
      "expanded_url" : "http:\/\/bit.ly\/xCgtlw",
      "display_url" : "bit.ly\/xCgtlw"
    } ]
  },
  "geo" : { },
  "id_str" : "162942559944060929",
  "text" : "RT @DoctorZen: Making public education in US free would cost what US spent on air conditioning in Afghanistan and Iraq: http:\/\/t.co\/JH1NomwW",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 105, 125 ],
        "url" : "http:\/\/t.co\/JH1NomwW",
        "expanded_url" : "http:\/\/bit.ly\/xCgtlw",
        "display_url" : "bit.ly\/xCgtlw"
      } ]
    },
    "geo" : { },
    "id_str" : "162942027569446912",
    "text" : "Making public education in US free would cost what US spent on air conditioning in Afghanistan and Iraq: http:\/\/t.co\/JH1NomwW",
    "id" : 162942027569446912,
    "created_at" : "2012-01-27 16:56:21 +0000",
    "user" : {
      "name" : "Zen Faulkes",
      "screen_name" : "DoctorZen",
      "protected" : false,
      "id_str" : "16486812",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/821882802064867329\/7dtVmJ-0_normal.jpg",
      "id" : 16486812,
      "verified" : false
    }
  },
  "id" : 162942559944060929,
  "created_at" : "2012-01-27 16:58:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Barton",
      "screen_name" : "MichaelBarton",
      "indices" : [ 3, 17 ],
      "id_str" : "862144844",
      "id" : 862144844
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "162940632795594752",
  "text" : "RT @michaelbarton: To say something is strongly homologous is akin to saying one is \"fiercely pregnant.\" You either share a common ances ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/github.com\/jugyo\/earthquake\" rel=\"nofollow\"\u003Eearthquake.gem\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "162940040513724416",
    "text" : "To say something is strongly homologous is akin to saying one is \"fiercely pregnant.\" You either share a common ancestor or you don't.",
    "id" : 162940040513724416,
    "created_at" : "2012-01-27 16:48:27 +0000",
    "user" : {
      "name" : "Michael Barton",
      "screen_name" : "bioinformatics",
      "protected" : false,
      "id_str" : "14126701",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/910600171704033280\/3V8Zte9P_normal.jpg",
      "id" : 14126701,
      "verified" : false
    }
  },
  "id" : 162940632795594752,
  "created_at" : "2012-01-27 16:50:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 124 ],
      "url" : "http:\/\/t.co\/P5gykEcp",
      "expanded_url" : "http:\/\/thecostofknowledge.com\/",
      "display_url" : "thecostofknowledge.com"
    } ]
  },
  "geo" : { },
  "id_str" : "162938099410804736",
  "text" : "The Cost of Knowledge: \u00ABResearchers taking a stand against Elsevier\u00BB already has over 800 participants. http:\/\/t.co\/P5gykEcp",
  "id" : 162938099410804736,
  "created_at" : "2012-01-27 16:40:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 0, 10 ],
      "id_str" : "14700783",
      "id" : 14700783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "162927187522097152",
  "geo" : { },
  "id_str" : "162927408511586304",
  "in_reply_to_user_id" : 14700783,
  "text" : "@Fischblog Beides parallel. ;)",
  "id" : 162927408511586304,
  "in_reply_to_status_id" : 162927187522097152,
  "created_at" : "2012-01-27 15:58:15 +0000",
  "in_reply_to_screen_name" : "Fischblog",
  "in_reply_to_user_id_str" : "14700783",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 0, 10 ],
      "id_str" : "14700783",
      "id" : 14700783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "162926603213602817",
  "geo" : { },
  "id_str" : "162926696054530048",
  "in_reply_to_user_id" : 14700783,
  "text" : "@Fischblog Dann fang ich besser schon mal an zu trainieren.",
  "id" : 162926696054530048,
  "in_reply_to_status_id" : 162926603213602817,
  "created_at" : "2012-01-27 15:55:26 +0000",
  "in_reply_to_screen_name" : "Fischblog",
  "in_reply_to_user_id_str" : "14700783",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "162912744130093056",
  "text" : "Gibt es eigentlich empfehlenswerte Aufkleber-Anbieter f\u00FCr Kleinmengen die transparente Folie machen?",
  "id" : 162912744130093056,
  "created_at" : "2012-01-27 14:59:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 51 ],
      "url" : "http:\/\/t.co\/8S77tmjO",
      "expanded_url" : "http:\/\/www.cabinetmagazine.org\/issues\/42\/wiles.php",
      "display_url" : "cabinetmagazine.org\/issues\/42\/wile\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "162885576872308738",
  "text" : "On Utopia: The Behavioral Sink http:\/\/t.co\/8S77tmjO",
  "id" : 162885576872308738,
  "created_at" : "2012-01-27 13:12:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 81 ],
      "url" : "http:\/\/t.co\/ehjw9DUB",
      "expanded_url" : "http:\/\/www.wired.com\/magazine\/2012\/01\/ff_autonomouscars\/all\/1",
      "display_url" : "wired.com\/magazine\/2012\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "162883187272458240",
  "text" : "\u00ABThe fact that you\u2019re still driving is a bug, not a feature\u00BB http:\/\/t.co\/ehjw9DUB",
  "id" : 162883187272458240,
  "created_at" : "2012-01-27 13:02:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ds187",
      "screen_name" : "ds187",
      "indices" : [ 0, 6 ],
      "id_str" : "15895350",
      "id" : 15895350
    }, {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 46, 56 ],
      "id_str" : "14700783",
      "id" : 14700783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "162850876137021440",
  "geo" : { },
  "id_str" : "162877889929420800",
  "in_reply_to_user_id" : 15895350,
  "text" : "@ds187 genau. Und beim Thema Facepalm ist der @Fischblog der Experte ;)",
  "id" : 162877889929420800,
  "in_reply_to_status_id" : 162850876137021440,
  "created_at" : "2012-01-27 12:41:29 +0000",
  "in_reply_to_screen_name" : "ds187",
  "in_reply_to_user_id_str" : "15895350",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 122, 132 ],
      "id_str" : "14700783",
      "id" : 14700783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 117 ],
      "url" : "http:\/\/t.co\/5f2Jzgcm",
      "expanded_url" : "http:\/\/j.mp\/zQIEs4",
      "display_url" : "j.mp\/zQIEs4"
    } ]
  },
  "geo" : { },
  "id_str" : "162849818732019713",
  "text" : "P. falciparum produce lower infection intensities in local versus foreign A. gambiae populations http:\/\/t.co\/5f2Jzgcm \/cc @Fischblog",
  "id" : 162849818732019713,
  "created_at" : "2012-01-27 10:49:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 119 ],
      "url" : "http:\/\/t.co\/merzboPM",
      "expanded_url" : "http:\/\/j.mp\/zQfpVF",
      "display_url" : "j.mp\/zQfpVF"
    } ]
  },
  "geo" : { },
  "id_str" : "162849414694703105",
  "text" : "Microarray Analysis of HIV Resistant Female Sex Workers Reveal a Gene Expression Signature Pattern http:\/\/t.co\/merzboPM",
  "id" : 162849414694703105,
  "created_at" : "2012-01-27 10:48:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Figueroa",
      "screen_name" : "unimatrixZxero",
      "indices" : [ 3, 18 ],
      "id_str" : "645353",
      "id" : 645353
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 111 ],
      "url" : "http:\/\/t.co\/Guignog4",
      "expanded_url" : "http:\/\/jakepoz.com\/soviet_debugging.html",
      "display_url" : "jakepoz.com\/soviet_debuggi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "162833579255152640",
  "text" : "RT @unimatrixZxero: Hahahah, this gives a whole new meaning to the term 'interrupting cow' http:\/\/t.co\/Guignog4",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sites.google.com\/site\/yorufukurou\/\" rel=\"nofollow\"\u003EYoruFukurou\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 71, 91 ],
        "url" : "http:\/\/t.co\/Guignog4",
        "expanded_url" : "http:\/\/jakepoz.com\/soviet_debugging.html",
        "display_url" : "jakepoz.com\/soviet_debuggi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "162832844601831424",
    "text" : "Hahahah, this gives a whole new meaning to the term 'interrupting cow' http:\/\/t.co\/Guignog4",
    "id" : 162832844601831424,
    "created_at" : "2012-01-27 09:42:30 +0000",
    "user" : {
      "name" : "Sam Figueroa",
      "screen_name" : "unimatrixZxero",
      "protected" : false,
      "id_str" : "645353",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2041971609\/rage_face_me_100px_normal.gif",
      "id" : 645353,
      "verified" : false
    }
  },
  "id" : 162833579255152640,
  "created_at" : "2012-01-27 09:45:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 64 ],
      "url" : "http:\/\/t.co\/pzCWXcGc",
      "expanded_url" : "http:\/\/j.mp\/AEUPLX",
      "display_url" : "j.mp\/AEUPLX"
    } ]
  },
  "geo" : { },
  "id_str" : "162817649343070208",
  "text" : "Covariance: the neuroinformatics of Neopets http:\/\/t.co\/pzCWXcGc",
  "id" : 162817649343070208,
  "created_at" : "2012-01-27 08:42:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Empirical Zeal",
      "screen_name" : "EmpiricalZeal",
      "indices" : [ 0, 14 ],
      "id_str" : "77510178",
      "id" : 77510178
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "162623881042083840",
  "geo" : { },
  "id_str" : "162642333580533760",
  "in_reply_to_user_id" : 300735398,
  "text" : "@EmpiricalZeal I just finished watching the third season and it was awesome. Can't remember the last time i had to laugh that much. :)",
  "id" : 162642333580533760,
  "in_reply_to_status_id" : 162623881042083840,
  "created_at" : "2012-01-26 21:05:28 +0000",
  "in_reply_to_screen_name" : "aatishb",
  "in_reply_to_user_id_str" : "300735398",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "162615618217062401",
  "text" : "A seal with a taste for mammal blood!",
  "id" : 162615618217062401,
  "created_at" : "2012-01-26 19:19:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 42 ],
      "url" : "http:\/\/t.co\/1IyJafcP",
      "expanded_url" : "http:\/\/instagr.am\/p\/k12uW\/",
      "display_url" : "instagr.am\/p\/k12uW\/"
    } ]
  },
  "geo" : { },
  "id_str" : "162599535246458880",
  "text" : "Falafelvorbereitungen http:\/\/t.co\/1IyJafcP",
  "id" : 162599535246458880,
  "created_at" : "2012-01-26 18:15:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ds187",
      "screen_name" : "ds187",
      "indices" : [ 3, 9 ],
      "id_str" : "15895350",
      "id" : 15895350
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "atidriver",
      "indices" : [ 55, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 34, 54 ],
      "url" : "http:\/\/t.co\/7j3sAdFn",
      "expanded_url" : "http:\/\/img.pr0gramm.com\/2012\/01\/1327575434877.jpg",
      "display_url" : "img.pr0gramm.com\/2012\/01\/132757\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "162504575650242560",
  "text" : "RT @ds187: been there, done that: http:\/\/t.co\/7j3sAdFn #atidriver",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twirssi.com\" rel=\"nofollow\"\u003ETwirssi\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "atidriver",
        "indices" : [ 44, 54 ]
      } ],
      "urls" : [ {
        "indices" : [ 23, 43 ],
        "url" : "http:\/\/t.co\/7j3sAdFn",
        "expanded_url" : "http:\/\/img.pr0gramm.com\/2012\/01\/1327575434877.jpg",
        "display_url" : "img.pr0gramm.com\/2012\/01\/132757\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "162497114272825344",
    "text" : "been there, done that: http:\/\/t.co\/7j3sAdFn #atidriver",
    "id" : 162497114272825344,
    "created_at" : "2012-01-26 11:28:25 +0000",
    "user" : {
      "name" : "ds187",
      "screen_name" : "ds187",
      "protected" : false,
      "id_str" : "15895350",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1264498553\/sandos_normal.jpg",
      "id" : 15895350,
      "verified" : false
    }
  },
  "id" : 162504575650242560,
  "created_at" : "2012-01-26 11:58:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 41 ],
      "url" : "http:\/\/t.co\/JDQrNtno",
      "expanded_url" : "http:\/\/j.mp\/A1Ddjd",
      "display_url" : "j.mp\/A1Ddjd"
    } ]
  },
  "geo" : { },
  "id_str" : "162438440451964928",
  "text" : "Evolving our success http:\/\/t.co\/JDQrNtno",
  "id" : 162438440451964928,
  "created_at" : "2012-01-26 07:35:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 100 ],
      "url" : "http:\/\/t.co\/5iAkee2Q",
      "expanded_url" : "http:\/\/j.mp\/wu5YgV",
      "display_url" : "j.mp\/wu5YgV"
    } ]
  },
  "geo" : { },
  "id_str" : "162434931371425792",
  "text" : "Shifting from Population-wide to Personalized Cancer Prognosis with Microarrays http:\/\/t.co\/5iAkee2Q",
  "id" : 162434931371425792,
  "created_at" : "2012-01-26 07:21:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 117 ],
      "url" : "http:\/\/t.co\/nXdGupt4",
      "expanded_url" : "http:\/\/j.mp\/Ax30Z4",
      "display_url" : "j.mp\/Ax30Z4"
    } ]
  },
  "geo" : { },
  "id_str" : "162434305405095937",
  "text" : "Genome-Wide Association Study of CNVs Suggests LTBP1 and FGD4 Are Important for Alcohol Drinking http:\/\/t.co\/nXdGupt4",
  "id" : 162434305405095937,
  "created_at" : "2012-01-26 07:18:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 133 ],
      "url" : "http:\/\/t.co\/CXRwzdBu",
      "expanded_url" : "http:\/\/j.mp\/xQYwza",
      "display_url" : "j.mp\/xQYwza"
    } ]
  },
  "geo" : { },
  "id_str" : "162433853682761729",
  "text" : "Profiling Using Genome-Wide Significant Disease Risk Variants Does Not Improve the Prediction of Atherosclerosis http:\/\/t.co\/CXRwzdBu",
  "id" : 162433853682761729,
  "created_at" : "2012-01-26 07:17:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "162307456687554560",
  "text" : "Stimmzettel sortieren. Welch Freude wenn Leute ihre Aufgaben nicht erledigen...",
  "id" : 162307456687554560,
  "created_at" : "2012-01-25 22:54:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carl Boettiger",
      "screen_name" : "cboettig",
      "indices" : [ 3, 12 ],
      "id_str" : "105529826",
      "id" : 105529826
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OKFN",
      "indices" : [ 46, 51 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "162281067510894592",
  "text" : "RT @cboettig: Nice! Open Knowledge foundation #OKFN offers Panton fellowships to scientists who actively promote open data http:\/\/t.co\/S ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "OKFN",
        "indices" : [ 32, 37 ]
      } ],
      "urls" : [ {
        "indices" : [ 109, 129 ],
        "url" : "http:\/\/t.co\/Sml1Cbbc",
        "expanded_url" : "http:\/\/blog.okfn.org\/2012\/01\/25\/panton-fellowships-apply-now\/",
        "display_url" : "blog.okfn.org\/2012\/01\/25\/pan\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "162240975727624192",
    "text" : "Nice! Open Knowledge foundation #OKFN offers Panton fellowships to scientists who actively promote open data http:\/\/t.co\/Sml1Cbbc",
    "id" : 162240975727624192,
    "created_at" : "2012-01-25 18:30:37 +0000",
    "user" : {
      "name" : "Carl Boettiger",
      "screen_name" : "cboettig",
      "protected" : false,
      "id_str" : "105529826",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/621454897704103937\/XWh0Oxwo_normal.jpg",
      "id" : 105529826,
      "verified" : false
    }
  },
  "id" : 162281067510894592,
  "created_at" : "2012-01-25 21:09:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "naturalismus",
      "screen_name" : "naturalismus",
      "indices" : [ 0, 13 ],
      "id_str" : "4562569648",
      "id" : 4562569648
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 14, 23 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "162251500414971904",
  "geo" : { },
  "id_str" : "162267019780173826",
  "in_reply_to_user_id" : 77216385,
  "text" : "@Naturalismus @Senficon Jetzt habt ihr es mir aber hart gegeben ;)",
  "id" : 162267019780173826,
  "in_reply_to_status_id" : 162251500414971904,
  "created_at" : "2012-01-25 20:14:06 +0000",
  "in_reply_to_screen_name" : "fireantprincess",
  "in_reply_to_user_id_str" : "77216385",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "michael_nielsen",
      "screen_name" : "michael_nielsen",
      "indices" : [ 3, 19 ],
      "id_str" : "15626406",
      "id" : 15626406
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 54 ],
      "url" : "http:\/\/t.co\/a3vR3YvB",
      "expanded_url" : "http:\/\/michaelnielsen.org\/blog\/on-elsevier\/",
      "display_url" : "michaelnielsen.org\/blog\/on-elsevi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "162242260765900801",
  "text" : "RT @michael_nielsen: On Elsevier: http:\/\/t.co\/a3vR3YvB",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 13, 33 ],
        "url" : "http:\/\/t.co\/a3vR3YvB",
        "expanded_url" : "http:\/\/michaelnielsen.org\/blog\/on-elsevier\/",
        "display_url" : "michaelnielsen.org\/blog\/on-elsevi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "162239355161812992",
    "text" : "On Elsevier: http:\/\/t.co\/a3vR3YvB",
    "id" : 162239355161812992,
    "created_at" : "2012-01-25 18:24:11 +0000",
    "user" : {
      "name" : "michael_nielsen",
      "screen_name" : "michael_nielsen",
      "protected" : false,
      "id_str" : "15626406",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2756243281\/6d3d0ade1bd4364b75d7d0151dce38e5_normal.png",
      "id" : 15626406,
      "verified" : false
    }
  },
  "id" : 162242260765900801,
  "created_at" : "2012-01-25 18:35:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "fasel",
      "screen_name" : "fasel",
      "indices" : [ 0, 6 ],
      "id_str" : "21739255",
      "id" : 21739255
    }, {
      "name" : "(((Andi Zottmann)))",
      "screen_name" : "andizottmann",
      "indices" : [ 7, 20 ],
      "id_str" : "49799881",
      "id" : 49799881
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "162237684998344704",
  "geo" : { },
  "id_str" : "162237783321214977",
  "in_reply_to_user_id" : 21739255,
  "text" : "@fasel @andizottmann Der kleine Bruder vom Darth. ;)",
  "id" : 162237783321214977,
  "in_reply_to_status_id" : 162237684998344704,
  "created_at" : "2012-01-25 18:17:56 +0000",
  "in_reply_to_screen_name" : "fasel",
  "in_reply_to_user_id_str" : "21739255",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "(((Andi Zottmann)))",
      "screen_name" : "andizottmann",
      "indices" : [ 0, 13 ],
      "id_str" : "49799881",
      "id" : 49799881
    }, {
      "name" : "fasel",
      "screen_name" : "fasel",
      "indices" : [ 14, 20 ],
      "id_str" : "21739255",
      "id" : 21739255
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "162235823943716865",
  "geo" : { },
  "id_str" : "162237056435761152",
  "in_reply_to_user_id" : 49799881,
  "text" : "@andizottmann @fasel Es ist \u00FCbrigens Wader. ;)",
  "id" : 162237056435761152,
  "in_reply_to_status_id" : 162235823943716865,
  "created_at" : "2012-01-25 18:15:03 +0000",
  "in_reply_to_screen_name" : "andizottmann",
  "in_reply_to_user_id_str" : "49799881",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "naturalismus",
      "screen_name" : "naturalismus",
      "indices" : [ 0, 13 ],
      "id_str" : "4562569648",
      "id" : 4562569648
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "162217383187054593",
  "geo" : { },
  "id_str" : "162217641564581888",
  "in_reply_to_user_id" : 77216385,
  "text" : "@Naturalismus Freude, will mein letztes Modul durch ein Betriebspraktikum ersetzen weil keine Lust mehr auf Kurse&Klausuren. :P",
  "id" : 162217641564581888,
  "in_reply_to_status_id" : 162217383187054593,
  "created_at" : "2012-01-25 16:57:54 +0000",
  "in_reply_to_screen_name" : "fireantprincess",
  "in_reply_to_user_id_str" : "77216385",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "naturalismus",
      "screen_name" : "naturalismus",
      "indices" : [ 0, 13 ],
      "id_str" : "4562569648",
      "id" : 4562569648
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "162215405694369792",
  "geo" : { },
  "id_str" : "162215915319070722",
  "in_reply_to_user_id" : 77216385,
  "text" : "@Naturalismus Nur noch ein Protokoll und eine Klausur, dann hab ich es hinter mir. Vermutlich f\u00FCr immer\u2122 :D",
  "id" : 162215915319070722,
  "in_reply_to_status_id" : 162215405694369792,
  "created_at" : "2012-01-25 16:51:02 +0000",
  "in_reply_to_screen_name" : "fireantprincess",
  "in_reply_to_user_id_str" : "77216385",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "162208625304145920",
  "text" : "Angehende Patentanw\u00E4lte die sich dar\u00FCber beschweren das ihre Warez wegen DRM nicht laufen... Ikonisch f\u00FCr den Status Quo des IP...",
  "id" : 162208625304145920,
  "created_at" : "2012-01-25 16:22:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Universit\u00E4t M\u00FCnster",
      "screen_name" : "WWU_Muenster",
      "indices" : [ 4, 17 ],
      "id_str" : "24677217",
      "id" : 24677217
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 50, 63 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 65, 77 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 124 ],
      "url" : "http:\/\/t.co\/gG1GbbyX",
      "expanded_url" : "http:\/\/www.uni-muenster.de\/unizeitung\/2012\/1-10.html",
      "display_url" : "uni-muenster.de\/unizeitung\/201\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "162202312343953410",
  "text" : "Die @WWU_Muenster hat jetzt auch \u00FCber openSNP von @PhilippBayer, @helgerausch, Fabian und mir berichtet http:\/\/t.co\/gG1GbbyX",
  "id" : 162202312343953410,
  "created_at" : "2012-01-25 15:56:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 61 ],
      "url" : "http:\/\/t.co\/ZvYpPEgE",
      "expanded_url" : "http:\/\/j.mp\/yps3HA",
      "display_url" : "j.mp\/yps3HA"
    } ]
  },
  "geo" : { },
  "id_str" : "162199517729525760",
  "text" : "The New French Hacker-Artist Underground http:\/\/t.co\/ZvYpPEgE",
  "id" : 162199517729525760,
  "created_at" : "2012-01-25 15:45:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 137 ],
      "url" : "http:\/\/t.co\/IWkynOhf",
      "expanded_url" : "http:\/\/j.mp\/Atk4wA",
      "display_url" : "j.mp\/Atk4wA"
    } ]
  },
  "geo" : { },
  "id_str" : "162192994945081348",
  "text" : "\u2018back to the land\u2019 will generally not be good for the environment, however psych. fulfilling these objectives may be http:\/\/t.co\/IWkynOhf",
  "id" : 162192994945081348,
  "created_at" : "2012-01-25 15:19:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 38 ],
      "url" : "http:\/\/t.co\/6HcRflty",
      "expanded_url" : "http:\/\/j.mp\/z4z5hu",
      "display_url" : "j.mp\/z4z5hu"
    } ]
  },
  "geo" : { },
  "id_str" : "162192253404717056",
  "text" : "Peeling Oniontown http:\/\/t.co\/6HcRflty",
  "id" : 162192253404717056,
  "created_at" : "2012-01-25 15:17:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 78 ],
      "url" : "http:\/\/t.co\/VWhiE3bX",
      "expanded_url" : "http:\/\/j.mp\/A9sG3n",
      "display_url" : "j.mp\/A9sG3n"
    } ]
  },
  "geo" : { },
  "id_str" : "162075572212727810",
  "text" : "The Power of Introverts: A Manifesto for Quiet Brilliance http:\/\/t.co\/VWhiE3bX",
  "id" : 162075572212727810,
  "created_at" : "2012-01-25 07:33:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Wilkins",
      "screen_name" : "jonfwilkins",
      "indices" : [ 3, 15 ],
      "id_str" : "214099847",
      "id" : 214099847
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 110 ],
      "url" : "http:\/\/t.co\/CKDAlRt8",
      "expanded_url" : "http:\/\/jonfwilkins.blogspot.com\/2012\/01\/find-your-sole-mate-at-seaharmony.html",
      "display_url" : "jonfwilkins.blogspot.com\/2012\/01\/find-y\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "162070638851399680",
  "text" : "RT @jonfwilkins: seaHarmony, because those other dating sits are just so species specific http:\/\/t.co\/CKDAlRt8",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 73, 93 ],
        "url" : "http:\/\/t.co\/CKDAlRt8",
        "expanded_url" : "http:\/\/jonfwilkins.blogspot.com\/2012\/01\/find-your-sole-mate-at-seaharmony.html",
        "display_url" : "jonfwilkins.blogspot.com\/2012\/01\/find-y\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "162013756396814336",
    "text" : "seaHarmony, because those other dating sits are just so species specific http:\/\/t.co\/CKDAlRt8",
    "id" : 162013756396814336,
    "created_at" : "2012-01-25 03:27:44 +0000",
    "user" : {
      "name" : "Jon Wilkins",
      "screen_name" : "jonfwilkins",
      "protected" : false,
      "id_str" : "214099847",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1279449740\/Dev2DEC_normal.jpg",
      "id" : 214099847,
      "verified" : false
    }
  },
  "id" : 162070638851399680,
  "created_at" : "2012-01-25 07:13:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Switek @MFF",
      "screen_name" : "Laelaps",
      "indices" : [ 20, 28 ],
      "id_str" : "29342640",
      "id" : 29342640
    }, {
      "name" : "io9",
      "screen_name" : "io9",
      "indices" : [ 124, 128 ],
      "id_str" : "13215132",
      "id" : 13215132
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 119 ],
      "url" : "http:\/\/t.co\/3UfLB2Z4",
      "expanded_url" : "http:\/\/io9.com\/5878918\/",
      "display_url" : "io9.com\/5878918\/"
    } ]
  },
  "geo" : { },
  "id_str" : "161935994239729664",
  "text" : "Awwsome pictures RT @Laelaps: Last chance to see? Heartbreaking glamor shots of endangered species http:\/\/t.co\/3UfLB2Z4 via @io9",
  "id" : 161935994239729664,
  "created_at" : "2012-01-24 22:18:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "J\u00FCrgen Geuter",
      "screen_name" : "tante",
      "indices" : [ 3, 9 ],
      "id_str" : "14179278",
      "id" : 14179278
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Privacy",
      "indices" : [ 24, 32 ]
    } ],
    "urls" : [ {
      "indices" : [ 81, 101 ],
      "url" : "http:\/\/t.co\/symqutkW",
      "expanded_url" : "http:\/\/is.gd\/fiqc8s",
      "display_url" : "is.gd\/fiqc8s"
    } ]
  },
  "geo" : { },
  "id_str" : "161925298949070848",
  "text" : "RT @tante: Gro\u00DFes Kino: #Privacy policy der Screenshot pimp Screengrab Extension http:\/\/t.co\/symqutkW",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/hotot.org\" rel=\"nofollow\"\u003EHotot\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Privacy",
        "indices" : [ 13, 21 ]
      } ],
      "urls" : [ {
        "indices" : [ 70, 90 ],
        "url" : "http:\/\/t.co\/symqutkW",
        "expanded_url" : "http:\/\/is.gd\/fiqc8s",
        "display_url" : "is.gd\/fiqc8s"
      } ]
    },
    "geo" : { },
    "id_str" : "161915392372121600",
    "text" : "Gro\u00DFes Kino: #Privacy policy der Screenshot pimp Screengrab Extension http:\/\/t.co\/symqutkW",
    "id" : 161915392372121600,
    "created_at" : "2012-01-24 20:56:52 +0000",
    "user" : {
      "name" : "J\u00FCrgen Geuter",
      "screen_name" : "tante",
      "protected" : false,
      "id_str" : "14179278",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/802837466512236544\/UiursIr__normal.jpg",
      "id" : 14179278,
      "verified" : true
    }
  },
  "id" : 161925298949070848,
  "created_at" : "2012-01-24 21:36:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 45 ],
      "url" : "http:\/\/t.co\/YwAkbEL5",
      "expanded_url" : "http:\/\/j.mp\/ACCjjz",
      "display_url" : "j.mp\/ACCjjz"
    } ]
  },
  "geo" : { },
  "id_str" : "161911992175689729",
  "text" : "The Open Science Paradox http:\/\/t.co\/YwAkbEL5",
  "id" : 161911992175689729,
  "created_at" : "2012-01-24 20:43:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 93 ],
      "url" : "http:\/\/t.co\/Gb1NwmOO",
      "expanded_url" : "http:\/\/j.mp\/wqnOiD",
      "display_url" : "j.mp\/wqnOiD"
    } ]
  },
  "geo" : { },
  "id_str" : "161888016699359232",
  "text" : "Homebrew, 3D printed Fisher-Price record-player disc plays \"Still Alive\" http:\/\/t.co\/Gb1NwmOO",
  "id" : 161888016699359232,
  "created_at" : "2012-01-24 19:08:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gunnar Lott",
      "screen_name" : "HerrKaliban",
      "indices" : [ 3, 15 ],
      "id_str" : "16945253",
      "id" : 16945253
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 88 ],
      "url" : "http:\/\/t.co\/4itKGHSy",
      "expanded_url" : "http:\/\/wp.me\/pntNF-3zk",
      "display_url" : "wp.me\/pntNF-3zk"
    } ]
  },
  "geo" : { },
  "id_str" : "161841373077712898",
  "text" : "RT @HerrKaliban: Ein offener Brief an die Herrscher der DRM-H\u00F6lle.\n\nhttp:\/\/t.co\/4itKGHSy",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/sopresto.mailchimp.com\" rel=\"nofollow\"\u003ESocial Proxy by Mailchimp\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 51, 71 ],
        "url" : "http:\/\/t.co\/4itKGHSy",
        "expanded_url" : "http:\/\/wp.me\/pntNF-3zk",
        "display_url" : "wp.me\/pntNF-3zk"
      } ]
    },
    "geo" : { },
    "id_str" : "161840195786903552",
    "text" : "Ein offener Brief an die Herrscher der DRM-H\u00F6lle.\n\nhttp:\/\/t.co\/4itKGHSy",
    "id" : 161840195786903552,
    "created_at" : "2012-01-24 15:58:04 +0000",
    "user" : {
      "name" : "Gunnar Lott",
      "screen_name" : "HerrKaliban",
      "protected" : false,
      "id_str" : "16945253",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/888401398064459777\/FaKgniYG_normal.jpg",
      "id" : 16945253,
      "verified" : true
    }
  },
  "id" : 161841373077712898,
  "created_at" : "2012-01-24 16:02:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "spackeria",
      "indices" : [ 52, 62 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "161836206869577728",
  "text" : "Drecksserver... \u00DCber 24h kein Liveprotokoll von der #spackeria...",
  "id" : 161836206869577728,
  "created_at" : "2012-01-24 15:42:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 0, 10 ],
      "id_str" : "14700783",
      "id" : 14700783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "161821447755538432",
  "geo" : { },
  "id_str" : "161825038742470657",
  "in_reply_to_user_id" : 14700783,
  "text" : "@Fischblog was setzt ihr \u00FCberhaupt bei euch ein?",
  "id" : 161825038742470657,
  "in_reply_to_status_id" : 161821447755538432,
  "created_at" : "2012-01-24 14:57:50 +0000",
  "in_reply_to_screen_name" : "Fischblog",
  "in_reply_to_user_id_str" : "14700783",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 0, 10 ],
      "id_str" : "14700783",
      "id" : 14700783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "161811750776356864",
  "geo" : { },
  "id_str" : "161820303050293249",
  "in_reply_to_user_id" : 14700783,
  "text" : "@Fischblog kann man auch Revers suchen so wie bei Google? ;)",
  "id" : 161820303050293249,
  "in_reply_to_status_id" : 161811750776356864,
  "created_at" : "2012-01-24 14:39:01 +0000",
  "in_reply_to_screen_name" : "Fischblog",
  "in_reply_to_user_id_str" : "14700783",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "161809287381913600",
  "text" : "Zumindest von meiner Uni her sind also schon mal alle Voraussetzungen f\u00FCr ein externes Praktikum erf\u00FCllt. \\o\/",
  "id" : 161809287381913600,
  "created_at" : "2012-01-24 13:55:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 0, 10 ],
      "id_str" : "14700783",
      "id" : 14700783
    }, {
      "name" : "schusselhexe",
      "screen_name" : "christorolo",
      "indices" : [ 11, 23 ],
      "id_str" : "292924620",
      "id" : 292924620
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "161806322558439424",
  "geo" : { },
  "id_str" : "161808326391382018",
  "in_reply_to_user_id" : 14700783,
  "text" : "@Fischblog @christorolo kommt von der \u00C4hnlichkeit zu Vin. ;)",
  "id" : 161808326391382018,
  "in_reply_to_status_id" : 161806322558439424,
  "created_at" : "2012-01-24 13:51:25 +0000",
  "in_reply_to_screen_name" : "Fischblog",
  "in_reply_to_user_id_str" : "14700783",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 13, 26 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "161745762903015425",
  "geo" : { },
  "id_str" : "161808187350192128",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch @PhilippBayer ja, ich glaub davon hab ich schon mal geh\u00F6rt. :)",
  "id" : 161808187350192128,
  "in_reply_to_status_id" : 161745762903015425,
  "created_at" : "2012-01-24 13:50:52 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scytale",
      "screen_name" : "Scytale",
      "indices" : [ 0, 8 ],
      "id_str" : "621716753",
      "id" : 621716753
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "161785672653475840",
  "geo" : { },
  "id_str" : "161807166808920064",
  "in_reply_to_user_id" : 8308632,
  "text" : "@Scytale kannst du ja mal bei openSNP als Ph\u00E4notyp Abfragen. W\u00E4re sicher spannend. :)",
  "id" : 161807166808920064,
  "in_reply_to_status_id" : 161785672653475840,
  "created_at" : "2012-01-24 13:46:49 +0000",
  "in_reply_to_screen_name" : "scy",
  "in_reply_to_user_id_str" : "8308632",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 82 ],
      "url" : "http:\/\/t.co\/PyZpSX39",
      "expanded_url" : "http:\/\/manuelcorpas.com\/2012\/01\/23\/my-personal-exome-now-publicly-released\/",
      "display_url" : "manuelcorpas.com\/2012\/01\/23\/my-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "161712651616006144",
  "text" : "Wow, Manuel released his exome sequencing results as CC BY-SA http:\/\/t.co\/PyZpSX39",
  "id" : 161712651616006144,
  "created_at" : "2012-01-24 07:31:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 60 ],
      "url" : "http:\/\/t.co\/WwGwa2YI",
      "expanded_url" : "http:\/\/j.mp\/AaqaGq",
      "display_url" : "j.mp\/AaqaGq"
    } ]
  },
  "geo" : { },
  "id_str" : "161712094755033088",
  "text" : "The problem with defining our ancestors http:\/\/t.co\/WwGwa2YI",
  "id" : 161712094755033088,
  "created_at" : "2012-01-24 07:29:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 47 ],
      "url" : "http:\/\/t.co\/SH8029XB",
      "expanded_url" : "http:\/\/j.mp\/xo5Ghn",
      "display_url" : "j.mp\/xo5Ghn"
    } ]
  },
  "geo" : { },
  "id_str" : "161710978340368385",
  "text" : "The Current State of dbSNP http:\/\/t.co\/SH8029XB",
  "id" : 161710978340368385,
  "created_at" : "2012-01-24 07:24:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 67 ],
      "url" : "http:\/\/t.co\/Z8yGaCpY",
      "expanded_url" : "http:\/\/j.mp\/yrcNtM",
      "display_url" : "j.mp\/yrcNtM"
    } ]
  },
  "geo" : { },
  "id_str" : "161709439181791232",
  "text" : "Pirate Bays Filesharing for 3D-Printed Objects http:\/\/t.co\/Z8yGaCpY",
  "id" : 161709439181791232,
  "created_at" : "2012-01-24 07:18:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sebastian Boegel",
      "screen_name" : "sebboeg",
      "indices" : [ 0, 8 ],
      "id_str" : "296476788",
      "id" : 296476788
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "161708761155764224",
  "geo" : { },
  "id_str" : "161708978844336128",
  "in_reply_to_user_id" : 296476788,
  "text" : "@sebboeg jo, das \"Dorf\" in dem ich aufgewachsen bin hat 35k. In den Ferien d\u00FCrfte T\u00FCbingen dann \u00E4hnlich stark bev\u00F6lkert sein ;)",
  "id" : 161708978844336128,
  "in_reply_to_status_id" : 161708761155764224,
  "created_at" : "2012-01-24 07:16:39 +0000",
  "in_reply_to_screen_name" : "sebboeg",
  "in_reply_to_user_id_str" : "296476788",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sebastian Boegel",
      "screen_name" : "sebboeg",
      "indices" : [ 0, 8 ],
      "id_str" : "296476788",
      "id" : 296476788
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "161707999356928000",
  "geo" : { },
  "id_str" : "161708297404162048",
  "in_reply_to_user_id" : 296476788,
  "text" : "@sebboeg klar, es war toll. Ich war nur ehrlich \u00FCberrascht das es laut Taxifahrer nur ~90k Einwohner sind.",
  "id" : 161708297404162048,
  "in_reply_to_status_id" : 161707999356928000,
  "created_at" : "2012-01-24 07:13:57 +0000",
  "in_reply_to_screen_name" : "sebboeg",
  "in_reply_to_user_id_str" : "296476788",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "161592877124825088",
  "text" : "\u00ABCollapse: How Societies Choose to Fail or Succeed\u00BB is a great (but lengthy) read for everyone interested in environmentalism.",
  "id" : 161592877124825088,
  "created_at" : "2012-01-23 23:35:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sebastian Boegel",
      "screen_name" : "sebboeg",
      "indices" : [ 0, 8 ],
      "id_str" : "296476788",
      "id" : 296476788
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "161566310139039744",
  "geo" : { },
  "id_str" : "161590567782973440",
  "in_reply_to_user_id" : 296476788,
  "text" : "@sebboeg hatte im Taxi den Eindruck das T\u00FCbingen nur aus einem H\u00FCgel besteht und wir den wegen der Einbahnstrassen rauf & runter fahren ;)",
  "id" : 161590567782973440,
  "in_reply_to_status_id" : 161566310139039744,
  "created_at" : "2012-01-23 23:26:08 +0000",
  "in_reply_to_screen_name" : "sebboeg",
  "in_reply_to_user_id_str" : "296476788",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/kindle.amazon.com\" rel=\"nofollow\"\u003EKindle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Kindle",
      "indices" : [ 79, 86 ]
    }, {
      "text" : "iPad",
      "indices" : [ 87, 92 ]
    } ],
    "urls" : [ {
      "indices" : [ 58, 78 ],
      "url" : "http:\/\/t.co\/s2O1U0Dv",
      "expanded_url" : "http:\/\/amzn.com\/k\/104QKJZII7FQF",
      "display_url" : "amzn.com\/k\/104QKJZII7FQF"
    } ]
  },
  "geo" : { },
  "id_str" : "161541638072705024",
  "text" : "There is already enough food for everyone on this planet? http:\/\/t.co\/s2O1U0Dv #Kindle #iPad",
  "id" : 161541638072705024,
  "created_at" : "2012-01-23 20:11:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emanuel Wyler",
      "screen_name" : "ewyler",
      "indices" : [ 0, 7 ],
      "id_str" : "122329006",
      "id" : 122329006
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "161540798033309696",
  "geo" : { },
  "id_str" : "161540939104530432",
  "in_reply_to_user_id" : 122329006,
  "text" : "@ewyler f\u00FCr EHEC hat man ja genau das gemacht.",
  "id" : 161540939104530432,
  "in_reply_to_status_id" : 161540798033309696,
  "created_at" : "2012-01-23 20:08:55 +0000",
  "in_reply_to_screen_name" : "ewyler",
  "in_reply_to_user_id_str" : "122329006",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emanuel Wyler",
      "screen_name" : "ewyler",
      "indices" : [ 0, 7 ],
      "id_str" : "122329006",
      "id" : 122329006
    }, {
      "name" : "Sebastian",
      "screen_name" : "MrEnkapsis",
      "indices" : [ 8, 19 ],
      "id_str" : "115717883",
      "id" : 115717883
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "161539535749120000",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.07529, 8.648663 ]
  },
  "id_str" : "161540361863446529",
  "in_reply_to_user_id" : 122329006,
  "text" : "@ewyler @MrEnkapsis ganz abgesehen von meiner Arbeitszeit, denn welches kleine Labor hat schon die Bioinformatiker zur Auswertung? ;)",
  "id" : 161540361863446529,
  "in_reply_to_status_id" : 161539535749120000,
  "created_at" : "2012-01-23 20:06:38 +0000",
  "in_reply_to_screen_name" : "ewyler",
  "in_reply_to_user_id_str" : "122329006",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Schnapper \uD83D\uDE0A\uD83D\uDCF1",
      "screen_name" : "alexschnapper",
      "indices" : [ 0, 14 ],
      "id_str" : "13320692",
      "id" : 13320692
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "161512153776525312",
  "geo" : { },
  "id_str" : "161512328880336896",
  "in_reply_to_user_id" : 13320692,
  "text" : "@alexschnapper schon im Gegensatz zu M\u00FCnster was als verschlafene Studentenstadt gilt :P",
  "id" : 161512328880336896,
  "in_reply_to_status_id" : 161512153776525312,
  "created_at" : "2012-01-23 18:15:14 +0000",
  "in_reply_to_screen_name" : "alexschnapper",
  "in_reply_to_user_id_str" : "13320692",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dierk Haasis",
      "screen_name" : "Evo2Me",
      "indices" : [ 0, 7 ],
      "id_str" : "22910316",
      "id" : 22910316
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "161511320766787586",
  "geo" : { },
  "id_str" : "161511650392940544",
  "in_reply_to_user_id" : 22910316,
  "text" : "@Evo2Me ich f\u00E4nd eine ICE-Anbindung noch ganz praktisch ;)",
  "id" : 161511650392940544,
  "in_reply_to_status_id" : 161511320766787586,
  "created_at" : "2012-01-23 18:12:32 +0000",
  "in_reply_to_screen_name" : "Evo2Me",
  "in_reply_to_user_id_str" : "22910316",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "161511154609422337",
  "text" : "Mir war vorher gar nicht bewusst wie winzig T\u00FCbingen eigentlich ist.",
  "id" : 161511154609422337,
  "created_at" : "2012-01-23 18:10:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rya",
      "screen_name" : "_Rya_",
      "indices" : [ 0, 6 ],
      "id_str" : "89234537",
      "id" : 89234537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "161500505657450496",
  "geo" : { },
  "id_str" : "161503865982812161",
  "in_reply_to_user_id" : 89234537,
  "text" : "@_Rya_ gute Besserung, Hase!",
  "id" : 161503865982812161,
  "in_reply_to_status_id" : 161500505657450496,
  "created_at" : "2012-01-23 17:41:36 +0000",
  "in_reply_to_screen_name" : "_Rya_",
  "in_reply_to_user_id_str" : "89234537",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "161383455828099072",
  "text" : "Gleich der erste Zug hat 15 Minuten Versp\u00E4tung... Deshalb wird der Anschluss in Mannheim schon weg sein. Macht dann eine Stunde Versp\u00E4tung..",
  "id" : 161383455828099072,
  "created_at" : "2012-01-23 09:43:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "161377665243287552",
  "text" : "On my way to T\u00FCbingen to talk about openSNP.",
  "id" : 161377665243287552,
  "created_at" : "2012-01-23 09:20:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "J\u00FCrgen Geuter",
      "screen_name" : "tante",
      "indices" : [ 0, 6 ],
      "id_str" : "14179278",
      "id" : 14179278
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "161359674506096640",
  "geo" : { },
  "id_str" : "161377479976681472",
  "in_reply_to_user_id" : 14179278,
  "text" : "@tante dann muss ich ja fast ;)",
  "id" : 161377479976681472,
  "in_reply_to_status_id" : 161359674506096640,
  "created_at" : "2012-01-23 09:19:24 +0000",
  "in_reply_to_screen_name" : "tante",
  "in_reply_to_user_id_str" : "14179278",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Khomenko",
      "screen_name" : "akhomenko",
      "indices" : [ 3, 13 ],
      "id_str" : "46498656",
      "id" : 46498656
    }, {
      "name" : "Deyan Vitanov",
      "screen_name" : "dvitanov",
      "indices" : [ 36, 45 ],
      "id_str" : "14554483",
      "id" : 14554483
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "161197169586614272",
  "text" : "RT @akhomenko: An excellent read RT @dvitanov MUST read article: Trials and Errors: Why Science Is Failing Us | Wired Magazine http:\/\/t. ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Deyan Vitanov",
        "screen_name" : "dvitanov",
        "indices" : [ 21, 30 ],
        "id_str" : "14554483",
        "id" : 14554483
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 112, 132 ],
        "url" : "http:\/\/t.co\/V14KFpFI",
        "expanded_url" : "http:\/\/www.wired.com\/magazine\/2011\/12\/ff_causation\/all\/1",
        "display_url" : "wired.com\/magazine\/2011\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "161192411266154497",
    "text" : "An excellent read RT @dvitanov MUST read article: Trials and Errors: Why Science Is Failing Us | Wired Magazine http:\/\/t.co\/V14KFpFI",
    "id" : 161192411266154497,
    "created_at" : "2012-01-22 21:04:00 +0000",
    "user" : {
      "name" : "Alex Khomenko",
      "screen_name" : "akhomenko",
      "protected" : false,
      "id_str" : "46498656",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/616369769\/spontaneous_square_normal.png",
      "id" : 46498656,
      "verified" : false
    }
  },
  "id" : 161197169586614272,
  "created_at" : "2012-01-22 21:22:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Henklein",
      "screen_name" : "snooze82",
      "indices" : [ 0, 9 ],
      "id_str" : "14094265",
      "id" : 14094265
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 10, 19 ],
      "id_str" : "14861745",
      "id" : 14861745
    }, {
      "name" : "Rya",
      "screen_name" : "_Rya_",
      "indices" : [ 20, 26 ],
      "id_str" : "89234537",
      "id" : 89234537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "161176600963072000",
  "geo" : { },
  "id_str" : "161178811084439553",
  "in_reply_to_user_id" : 14094265,
  "text" : "@snooze82 @senficon @_rya_ danke.",
  "id" : 161178811084439553,
  "in_reply_to_status_id" : 161176600963072000,
  "created_at" : "2012-01-22 20:09:57 +0000",
  "in_reply_to_screen_name" : "snooze82",
  "in_reply_to_user_id_str" : "14094265",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Henklein",
      "screen_name" : "snooze82",
      "indices" : [ 0, 9 ],
      "id_str" : "14094265",
      "id" : 14094265
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 10, 19 ],
      "id_str" : "14861745",
      "id" : 14861745
    }, {
      "name" : "Rya",
      "screen_name" : "_Rya_",
      "indices" : [ 20, 26 ],
      "id_str" : "89234537",
      "id" : 89234537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "161042710554353664",
  "geo" : { },
  "id_str" : "161175046524633089",
  "in_reply_to_user_id" : 14094265,
  "text" : "@snooze82 @Senficon @_Rya_ k\u00F6nnen wir das noch mal verschieben? Lieg immer noch flach :(",
  "id" : 161175046524633089,
  "in_reply_to_status_id" : 161042710554353664,
  "created_at" : "2012-01-22 19:55:00 +0000",
  "in_reply_to_screen_name" : "snooze82",
  "in_reply_to_user_id_str" : "14094265",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Curry",
      "screen_name" : "Stephen_Curry",
      "indices" : [ 3, 17 ],
      "id_str" : "41358714",
      "id" : 41358714
    }, {
      "name" : "Susan Jordan",
      "screen_name" : "Moonbootica",
      "indices" : [ 68, 80 ],
      "id_str" : "16984207",
      "id" : 16984207
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 136 ],
      "url" : "http:\/\/t.co\/VHXUEnJP",
      "expanded_url" : "http:\/\/gu.com\/p\/34qfh\/tw",
      "display_url" : "gu.com\/p\/34qfh\/tw"
    } ]
  },
  "geo" : { },
  "id_str" : "161062359924867074",
  "text" : "RT @Stephen_Curry: Good fences make good neighbours? Not always. MT @Moonbootica: Belfast peace walls - in pictures http:\/\/t.co\/VHXUEnJP ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Susan Jordan",
        "screen_name" : "Moonbootica",
        "indices" : [ 49, 61 ],
        "id_str" : "16984207",
        "id" : 16984207
      }, {
        "name" : "The Guardian",
        "screen_name" : "guardian",
        "indices" : [ 122, 131 ],
        "id_str" : "87818409",
        "id" : 87818409
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 97, 117 ],
        "url" : "http:\/\/t.co\/VHXUEnJP",
        "expanded_url" : "http:\/\/gu.com\/p\/34qfh\/tw",
        "display_url" : "gu.com\/p\/34qfh\/tw"
      } ]
    },
    "geo" : { },
    "id_str" : "161061662756044800",
    "text" : "Good fences make good neighbours? Not always. MT @Moonbootica: Belfast peace walls - in pictures http:\/\/t.co\/VHXUEnJP via @guardian",
    "id" : 161061662756044800,
    "created_at" : "2012-01-22 12:24:27 +0000",
    "user" : {
      "name" : "Stephen Curry",
      "screen_name" : "Stephen_Curry",
      "protected" : false,
      "id_str" : "41358714",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/814162182632075265\/1tXrvuPC_normal.jpg",
      "id" : 41358714,
      "verified" : true
    }
  },
  "id" : 161062359924867074,
  "created_at" : "2012-01-22 12:27:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "L3viathan",
      "screen_name" : "L3viathan2142",
      "indices" : [ 3, 17 ],
      "id_str" : "23305817",
      "id" : 23305817
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 93 ],
      "url" : "http:\/\/t.co\/BWyOj7vP",
      "expanded_url" : "http:\/\/i.imgur.com\/w9Ksn.png",
      "display_url" : "i.imgur.com\/w9Ksn.png"
    } ]
  },
  "geo" : { },
  "id_str" : "160834468595240960",
  "text" : "RT @L3viathan2142: Has anyone seen the cruise ship that sank near italy? http:\/\/t.co\/BWyOj7vP",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.metrotwit.com\/\" rel=\"nofollow\"\u003EMetroTwit\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 54, 74 ],
        "url" : "http:\/\/t.co\/BWyOj7vP",
        "expanded_url" : "http:\/\/i.imgur.com\/w9Ksn.png",
        "display_url" : "i.imgur.com\/w9Ksn.png"
      } ]
    },
    "geo" : { },
    "id_str" : "160834026238783488",
    "text" : "Has anyone seen the cruise ship that sank near italy? http:\/\/t.co\/BWyOj7vP",
    "id" : 160834026238783488,
    "created_at" : "2012-01-21 21:19:54 +0000",
    "user" : {
      "name" : "L3viathan",
      "screen_name" : "L3viathan2142",
      "protected" : false,
      "id_str" : "23305817",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1416278793\/Night_Cat_Reloaded_by_l3viathan2142_normal.png",
      "id" : 23305817,
      "verified" : false
    }
  },
  "id" : 160834468595240960,
  "created_at" : "2012-01-21 21:21:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 82 ],
      "url" : "http:\/\/t.co\/2e9w7HK1",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=CHPxcYgifd8&feature=youtu.be",
      "display_url" : "youtube.com\/watch?v=CHPxcY\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "160833589561401346",
  "text" : "Fabian hat beim Science Slam in M\u00FCnster \u00FCber openSNP erz\u00E4hlt. http:\/\/t.co\/2e9w7HK1",
  "id" : 160833589561401346,
  "created_at" : "2012-01-21 21:18:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "160810327238385665",
  "text" : "Immer wieder erstaunt wieviel Dreck der Roomba bei einer Fahrt so ansammelt.",
  "id" : 160810327238385665,
  "created_at" : "2012-01-21 19:45:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 5, 15 ],
      "id_str" : "14700783",
      "id" : 14700783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 78 ],
      "url" : "http:\/\/t.co\/M3xcHkeh",
      "expanded_url" : "http:\/\/www.dailymotion.com\/video\/x9x1ou_banana-boat-song-day-o-harry-belafo_music",
      "display_url" : "dailymotion.com\/video\/x9x1ou_b\u2026"
    }, {
      "indices" : [ 79, 99 ],
      "url" : "http:\/\/t.co\/sXLNd7hm",
      "expanded_url" : "http:\/\/bit.ly\/yJZ9y2",
      "display_url" : "bit.ly\/yJZ9y2"
    } ]
  },
  "geo" : { },
  "id_str" : "160801900059570176",
  "text" : "Laut @Fischblog war es das bald mit dem Banana Boat Song! http:\/\/t.co\/M3xcHkeh http:\/\/t.co\/sXLNd7hm",
  "id" : 160801900059570176,
  "created_at" : "2012-01-21 19:12:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "wirhabenessatt",
      "indices" : [ 63, 78 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "160717465792421888",
  "text" : "Rechnen von Hand statt k\u00FCnstlicher neuronaler Terrornetzwerke! #wirhabenessatt",
  "id" : 160717465792421888,
  "created_at" : "2012-01-21 13:36:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 3, 13 ],
      "id_str" : "14700783",
      "id" : 14700783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 132 ],
      "url" : "http:\/\/t.co\/wt9l5654",
      "expanded_url" : "http:\/\/www.nichtlustig.de\/comics\/full\/040816.jpg",
      "display_url" : "nichtlustig.de\/comics\/full\/04\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "160701807415410689",
  "text" : "RT @Fischblog: Hm, vielleicht sind Gentechnikgegner tats\u00E4chlich nicht antimodern. K\u00F6nnte nat\u00FCrlich auch sein... http:\/\/t.co\/wt9l5654",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 97, 117 ],
        "url" : "http:\/\/t.co\/wt9l5654",
        "expanded_url" : "http:\/\/www.nichtlustig.de\/comics\/full\/040816.jpg",
        "display_url" : "nichtlustig.de\/comics\/full\/04\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "160697554013650946",
    "text" : "Hm, vielleicht sind Gentechnikgegner tats\u00E4chlich nicht antimodern. K\u00F6nnte nat\u00FCrlich auch sein... http:\/\/t.co\/wt9l5654",
    "id" : 160697554013650946,
    "created_at" : "2012-01-21 12:17:37 +0000",
    "user" : {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "protected" : false,
      "id_str" : "14700783",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/929627167125921792\/t5PPk1W-_normal.jpg",
      "id" : 14700783,
      "verified" : false
    }
  },
  "id" : 160701807415410689,
  "created_at" : "2012-01-21 12:34:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anatol Stefanowitsch",
      "screen_name" : "astefanowitsch",
      "indices" : [ 0, 15 ],
      "id_str" : "73134122",
      "id" : 73134122
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "wirhabenessatt",
      "indices" : [ 42, 57 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "160688537946165248",
  "geo" : { },
  "id_str" : "160688676911845376",
  "in_reply_to_user_id" : 73134122,
  "text" : "@astefanowitsch LifeType statt Wordpress! #wirhabenessatt",
  "id" : 160688676911845376,
  "in_reply_to_status_id" : 160688537946165248,
  "created_at" : "2012-01-21 11:42:20 +0000",
  "in_reply_to_screen_name" : "astefanowitsch",
  "in_reply_to_user_id_str" : "73134122",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dummy",
      "screen_name" : "esowatchcom",
      "indices" : [ 0, 12 ],
      "id_str" : "629709981",
      "id" : 629709981
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "160676575568867328",
  "geo" : { },
  "id_str" : "160676890879868929",
  "in_reply_to_user_id" : 146485378,
  "text" : "@Esowatchcom Bitte auch alle nicht heimischen Nahrungsmittel verbannen. Goodbye Kartoffel, Mais und Tomate. ;)",
  "id" : 160676890879868929,
  "in_reply_to_status_id" : 160676575568867328,
  "created_at" : "2012-01-21 10:55:30 +0000",
  "in_reply_to_screen_name" : "Psiramcom",
  "in_reply_to_user_id_str" : "146485378",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dummy",
      "screen_name" : "esowatchcom",
      "indices" : [ 0, 12 ],
      "id_str" : "629709981",
      "id" : 629709981
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "160674716103868416",
  "geo" : { },
  "id_str" : "160676294986711040",
  "in_reply_to_user_id" : 146485378,
  "text" : "@Esowatchcom \u00ABHeimisches Futter statt Gentechnik-Soja f\u00F6rdern\u00BB finde ich auch prima.",
  "id" : 160676294986711040,
  "in_reply_to_status_id" : 160674716103868416,
  "created_at" : "2012-01-21 10:53:08 +0000",
  "in_reply_to_screen_name" : "Psiramcom",
  "in_reply_to_user_id_str" : "146485378",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joerg Blumtritt",
      "screen_name" : "jbenno",
      "indices" : [ 10, 17 ],
      "id_str" : "10177792",
      "id" : 10177792
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 64 ],
      "url" : "http:\/\/t.co\/vbYzAjOj",
      "expanded_url" : "http:\/\/www.scilogs.de\/wblogs\/blog\/detritus\/bio\/2011-01-22\/demonstration-der-wohlstandsmaden",
      "display_url" : "scilogs.de\/wblogs\/blog\/de\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "160669073296998400",
  "geo" : { },
  "id_str" : "160669501711585280",
  "in_reply_to_user_id" : 413389519,
  "text" : "@Snougata @jbenno gutes von vor einem Jahr: http:\/\/t.co\/vbYzAjOj",
  "id" : 160669501711585280,
  "in_reply_to_status_id" : 160669073296998400,
  "created_at" : "2012-01-21 10:26:08 +0000",
  "in_reply_to_screen_name" : "Schneckbeth",
  "in_reply_to_user_id_str" : "413389519",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 73 ],
      "url" : "http:\/\/t.co\/Y0VCYngO",
      "expanded_url" : "http:\/\/www.wir-haben-es-satt.de\/",
      "display_url" : "wir-haben-es-satt.de"
    } ]
  },
  "geo" : { },
  "id_str" : "160668652193054720",
  "text" : "Oh, die hohlen Wohlstandsmaden marschieren wieder... http:\/\/t.co\/Y0VCYngO",
  "id" : 160668652193054720,
  "created_at" : "2012-01-21 10:22:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 0, 10 ],
      "id_str" : "14700783",
      "id" : 14700783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 56 ],
      "url" : "http:\/\/t.co\/JJH9zkOh",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=UuHILqDIvis&feature=youtube_gdata_player",
      "display_url" : "youtube.com\/watch?v=UuHILq\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "160665659041251329",
  "geo" : { },
  "id_str" : "160666329563660288",
  "in_reply_to_user_id" : 14700783,
  "text" : "@Fischblog there is always money... http:\/\/t.co\/JJH9zkOh",
  "id" : 160666329563660288,
  "in_reply_to_status_id" : 160665659041251329,
  "created_at" : "2012-01-21 10:13:32 +0000",
  "in_reply_to_screen_name" : "Fischblog",
  "in_reply_to_user_id_str" : "14700783",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathan Eisen, Guardian of Microbial Diversity \uD83D\uDCA5\uD83D\uDD06",
      "screen_name" : "phylogenomics",
      "indices" : [ 3, 17 ],
      "id_str" : "15154811",
      "id" : 15154811
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "scio12",
      "indices" : [ 101, 108 ]
    }, {
      "text" : "openscience",
      "indices" : [ 109, 121 ]
    }, {
      "text" : "rosieredfield",
      "indices" : [ 122, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 100 ],
      "url" : "http:\/\/t.co\/nZpOXuYZ",
      "expanded_url" : "http:\/\/shar.es\/WLhmE",
      "display_url" : "shar.es\/WLhmE"
    } ]
  },
  "geo" : { },
  "id_str" : "160652335494873088",
  "text" : "RT @phylogenomics: Nature News Study challenges existence of arsenic-based life http:\/\/t.co\/nZpOXuYZ #scio12 #openscience #rosieredfield",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sharethis.com\" rel=\"nofollow\"\u003EShareThis.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "scio12",
        "indices" : [ 82, 89 ]
      }, {
        "text" : "openscience",
        "indices" : [ 90, 102 ]
      }, {
        "text" : "rosieredfield",
        "indices" : [ 103, 117 ]
      } ],
      "urls" : [ {
        "indices" : [ 61, 81 ],
        "url" : "http:\/\/t.co\/nZpOXuYZ",
        "expanded_url" : "http:\/\/shar.es\/WLhmE",
        "display_url" : "shar.es\/WLhmE"
      } ]
    },
    "geo" : { },
    "id_str" : "160637002461618176",
    "text" : "Nature News Study challenges existence of arsenic-based life http:\/\/t.co\/nZpOXuYZ #scio12 #openscience #rosieredfield",
    "id" : 160637002461618176,
    "created_at" : "2012-01-21 08:17:00 +0000",
    "user" : {
      "name" : "Jonathan Eisen, Guardian of Microbial Diversity \uD83D\uDCA5\uD83D\uDD06",
      "screen_name" : "phylogenomics",
      "protected" : false,
      "id_str" : "15154811",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/751288576403382273\/AKfTiFxx_normal.jpg",
      "id" : 15154811,
      "verified" : true
    }
  },
  "id" : 160652335494873088,
  "created_at" : "2012-01-21 09:17:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 56 ],
      "url" : "http:\/\/t.co\/J27tcZi2",
      "expanded_url" : "http:\/\/j.mp\/x62iiD",
      "display_url" : "j.mp\/x62iiD"
    } ]
  },
  "geo" : { },
  "id_str" : "160507380172455936",
  "text" : "Pfandring f\u00FCr \u00F6ffentliche M\u00FClleimer http:\/\/t.co\/J27tcZi2",
  "id" : 160507380172455936,
  "created_at" : "2012-01-20 23:41:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Corneveaux",
      "screen_name" : "caddymob",
      "indices" : [ 3, 12 ],
      "id_str" : "19578190",
      "id" : 19578190
    }, {
      "name" : "Lifehacker",
      "screen_name" : "lifehacker",
      "indices" : [ 20, 31 ],
      "id_str" : "7144422",
      "id" : 7144422
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "160500641628823552",
  "text" : "RT @caddymob: FUCK \u201C@lifehacker: DreamHost has been hacked: if you are a customer, you need to change your password now: http:\/\/t.co\/bAJ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Lifehacker",
        "screen_name" : "lifehacker",
        "indices" : [ 6, 17 ],
        "id_str" : "7144422",
        "id" : 7144422
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 107, 127 ],
        "url" : "http:\/\/t.co\/bAJqtbqW",
        "expanded_url" : "http:\/\/lifehac.kr\/xEq64E",
        "display_url" : "lifehac.kr\/xEq64E"
      } ]
    },
    "geo" : { },
    "id_str" : "160498007769485313",
    "text" : "FUCK \u201C@lifehacker: DreamHost has been hacked: if you are a customer, you need to change your password now: http:\/\/t.co\/bAJqtbqW\u201D",
    "id" : 160498007769485313,
    "created_at" : "2012-01-20 23:04:41 +0000",
    "user" : {
      "name" : "Jason Corneveaux",
      "screen_name" : "caddymob",
      "protected" : false,
      "id_str" : "19578190",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1201171713\/Profile_normal.png",
      "id" : 19578190,
      "verified" : false
    }
  },
  "id" : 160500641628823552,
  "created_at" : "2012-01-20 23:15:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 68 ],
      "url" : "http:\/\/t.co\/hHRFtSoC",
      "expanded_url" : "http:\/\/j.mp\/zRod0L",
      "display_url" : "j.mp\/zRod0L"
    } ]
  },
  "geo" : { },
  "id_str" : "160412765138325504",
  "text" : "Soon, You May Download New Skills to Your Brain http:\/\/t.co\/hHRFtSoC",
  "id" : 160412765138325504,
  "created_at" : "2012-01-20 17:25:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leonid Kruglyak",
      "screen_name" : "leonidkruglyak",
      "indices" : [ 3, 18 ],
      "id_str" : "19416598",
      "id" : 19416598
    }, {
      "name" : "Nature News&Comment",
      "screen_name" : "NatureNews",
      "indices" : [ 48, 59 ],
      "id_str" : "15862891",
      "id" : 15862891
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "arseniclife",
      "indices" : [ 81, 93 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "160410780628553728",
  "text" : "RT @leonidkruglyak: The beginning of the end RT @NatureNews: Is this the end for #arseniclife ? Attempts to replicate have failed http:\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nature News&Comment",
        "screen_name" : "NatureNews",
        "indices" : [ 28, 39 ],
        "id_str" : "15862891",
        "id" : 15862891
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "arseniclife",
        "indices" : [ 61, 73 ]
      } ],
      "urls" : [ {
        "indices" : [ 110, 130 ],
        "url" : "http:\/\/t.co\/3rjWe4TH",
        "expanded_url" : "http:\/\/ow.ly\/8AFb7",
        "display_url" : "ow.ly\/8AFb7"
      } ]
    },
    "geo" : { },
    "id_str" : "160410660528865280",
    "text" : "The beginning of the end RT @NatureNews: Is this the end for #arseniclife ? Attempts to replicate have failed http:\/\/t.co\/3rjWe4TH",
    "id" : 160410660528865280,
    "created_at" : "2012-01-20 17:17:36 +0000",
    "user" : {
      "name" : "Leonid Kruglyak",
      "screen_name" : "leonidkruglyak",
      "protected" : false,
      "id_str" : "19416598",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1095542276\/MyRecentPhoto_normal.jpg",
      "id" : 19416598,
      "verified" : false
    }
  },
  "id" : 160410780628553728,
  "created_at" : "2012-01-20 17:18:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "160403427447418880",
  "text" : "I really couldn't prepare the talk. I had to kill zombies in L4D2",
  "id" : 160403427447418880,
  "created_at" : "2012-01-20 16:48:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "160362942842408960",
  "text" : "Ich war die letzten Stunden nicht auf Twitter, deshalb: Muss man Megaupload gerade gut oder b\u00F6se finden?",
  "id" : 160362942842408960,
  "created_at" : "2012-01-20 14:07:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Frau Fragmente",
      "screen_name" : "fragmente",
      "indices" : [ 3, 13 ],
      "id_str" : "7207642",
      "id" : 7207642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 89 ],
      "url" : "http:\/\/t.co\/ZSxkxRQq",
      "expanded_url" : "http:\/\/www.journelle.de\/703\/verdorben-bis-ins-schokoladentortchen\/",
      "display_url" : "journelle.de\/703\/verdorben-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "160321528985157632",
  "text" : "RT @fragmente: \"Wirkliche Schuld empfinden wir nur noch beim Essen.\" http:\/\/t.co\/ZSxkxRQq",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 54, 74 ],
        "url" : "http:\/\/t.co\/ZSxkxRQq",
        "expanded_url" : "http:\/\/www.journelle.de\/703\/verdorben-bis-ins-schokoladentortchen\/",
        "display_url" : "journelle.de\/703\/verdorben-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "160320859427450882",
    "text" : "\"Wirkliche Schuld empfinden wir nur noch beim Essen.\" http:\/\/t.co\/ZSxkxRQq",
    "id" : 160320859427450882,
    "created_at" : "2012-01-20 11:20:46 +0000",
    "user" : {
      "name" : "Frau Fragmente",
      "screen_name" : "fragmente",
      "protected" : false,
      "id_str" : "7207642",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/696457425277317120\/emEVfsV-_normal.jpg",
      "id" : 7207642,
      "verified" : false
    }
  },
  "id" : 160321528985157632,
  "created_at" : "2012-01-20 11:23:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "hwy395",
      "screen_name" : "hwy395",
      "indices" : [ 3, 10 ],
      "id_str" : "16841062",
      "id" : 16841062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 97 ],
      "url" : "http:\/\/t.co\/xLBHbbAY",
      "expanded_url" : "http:\/\/bit.ly\/ztdhVx",
      "display_url" : "bit.ly\/ztdhVx"
    }, {
      "indices" : [ 108, 128 ],
      "url" : "http:\/\/t.co\/H1qPBqTr",
      "expanded_url" : "http:\/\/kottke.org",
      "display_url" : "kottke.org"
    } ]
  },
  "geo" : { },
  "id_str" : "160122826249089024",
  "text" : "RT @hwy395: 13-year-old girl sees a vinyl lp for the first time in her life. http:\/\/t.co\/xLBHbbAY (found on http:\/\/t.co\/H1qPBqTr)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 65, 85 ],
        "url" : "http:\/\/t.co\/xLBHbbAY",
        "expanded_url" : "http:\/\/bit.ly\/ztdhVx",
        "display_url" : "bit.ly\/ztdhVx"
      }, {
        "indices" : [ 96, 116 ],
        "url" : "http:\/\/t.co\/H1qPBqTr",
        "expanded_url" : "http:\/\/kottke.org",
        "display_url" : "kottke.org"
      } ]
    },
    "geo" : { },
    "id_str" : "160121890558578688",
    "text" : "13-year-old girl sees a vinyl lp for the first time in her life. http:\/\/t.co\/xLBHbbAY (found on http:\/\/t.co\/H1qPBqTr)",
    "id" : 160121890558578688,
    "created_at" : "2012-01-19 22:10:08 +0000",
    "user" : {
      "name" : "Fabian Mohr",
      "screen_name" : "fabianmohr",
      "protected" : false,
      "id_str" : "13183522",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/932352046967246849\/UXOqOF2N_normal.jpg",
      "id" : 13183522,
      "verified" : true
    }
  },
  "id" : 160122826249089024,
  "created_at" : "2012-01-19 22:13:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "160061020419801089",
  "text" : "So langsam sollte ich mich mal an den Talk \u00FCber openSNP f\u00FCrs MPI setzen...",
  "id" : 160061020419801089,
  "created_at" : "2012-01-19 18:08:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 0, 10 ],
      "id_str" : "14700783",
      "id" : 14700783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "160026689005568002",
  "geo" : { },
  "id_str" : "160043738188611584",
  "in_reply_to_user_id" : 14700783,
  "text" : "@Fischblog Sieht super aus :)",
  "id" : 160043738188611584,
  "in_reply_to_status_id" : 160026689005568002,
  "created_at" : "2012-01-19 16:59:35 +0000",
  "in_reply_to_screen_name" : "Fischblog",
  "in_reply_to_user_id_str" : "14700783",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "160043489588027392",
  "text" : "Die einzige n\u00FCtzliche Verwendung die ich bislang f\u00FCr meinen Stryer gefunden habe: Um den externen Monitor h\u00F6her zu stellen.",
  "id" : 160043489588027392,
  "created_at" : "2012-01-19 16:58:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arikia\uD83D\uDCAB",
      "screen_name" : "arikia",
      "indices" : [ 3, 10 ],
      "id_str" : "71654283",
      "id" : 71654283
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "scio12",
      "indices" : [ 119, 126 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "160023881233604608",
  "text" : "RT @arikia: \"Sharks aren't so bad. If a stranger entered my house wearing only a Speedo, I'd probably attack him too.\" #scio12",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "scio12",
        "indices" : [ 107, 114 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "160023119103393792",
    "text" : "\"Sharks aren't so bad. If a stranger entered my house wearing only a Speedo, I'd probably attack him too.\" #scio12",
    "id" : 160023119103393792,
    "created_at" : "2012-01-19 15:37:39 +0000",
    "user" : {
      "name" : "Arikia\uD83D\uDCAB",
      "screen_name" : "arikia",
      "protected" : false,
      "id_str" : "71654283",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/897255084073025537\/5uB8YwJG_normal.jpg",
      "id" : 71654283,
      "verified" : false
    }
  },
  "id" : 160023881233604608,
  "created_at" : "2012-01-19 15:40:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 72 ],
      "url" : "http:\/\/t.co\/y9sObGmY",
      "expanded_url" : "http:\/\/j.mp\/xTpC2e",
      "display_url" : "j.mp\/xTpC2e"
    } ]
  },
  "geo" : { },
  "id_str" : "160021039106113536",
  "text" : "What Scientists Under Pressure Can Learn From Spock http:\/\/t.co\/y9sObGmY",
  "id" : 160021039106113536,
  "created_at" : "2012-01-19 15:29:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 73 ],
      "url" : "http:\/\/t.co\/iY1S28oP",
      "expanded_url" : "http:\/\/j.mp\/zFIa8k",
      "display_url" : "j.mp\/zFIa8k"
    } ]
  },
  "geo" : { },
  "id_str" : "160019787907477504",
  "text" : "When Does a Medical Student Overstep Her Boundaries? http:\/\/t.co\/iY1S28oP",
  "id" : 160019787907477504,
  "created_at" : "2012-01-19 15:24:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 80 ],
      "url" : "http:\/\/t.co\/C83TcXoY",
      "expanded_url" : "http:\/\/j.mp\/yRl7a8",
      "display_url" : "j.mp\/yRl7a8"
    } ]
  },
  "geo" : { },
  "id_str" : "160011349525667841",
  "text" : "The Architect, The \"It\u201D Girl And The Toy Pistol That Wasn't http:\/\/t.co\/C83TcXoY",
  "id" : 160011349525667841,
  "created_at" : "2012-01-19 14:50:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sebastian Kroos",
      "screen_name" : "de_Wastl",
      "indices" : [ 11, 20 ],
      "id_str" : "17620538",
      "id" : 17620538
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 56 ],
      "url" : "http:\/\/t.co\/oK1bBGxa",
      "expanded_url" : "http:\/\/mobil.zeit.de\/2011\/42\/C-Schule-Kreationisten",
      "display_url" : "mobil.zeit.de\/2011\/42\/C-Schu\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "159990005064941568",
  "geo" : { },
  "id_str" : "160005329281753088",
  "in_reply_to_user_id" : 50121415,
  "text" : "@robikraus @de_Wastl und aktueller: http:\/\/t.co\/oK1bBGxa",
  "id" : 160005329281753088,
  "in_reply_to_status_id" : 159990005064941568,
  "created_at" : "2012-01-19 14:26:57 +0000",
  "in_reply_to_screen_name" : "_papow_",
  "in_reply_to_user_id_str" : "50121415",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sebastian Kroos",
      "screen_name" : "de_Wastl",
      "indices" : [ 11, 20 ],
      "id_str" : "17620538",
      "id" : 17620538
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 60 ],
      "url" : "http:\/\/t.co\/rkm5SJo8",
      "expanded_url" : "http:\/\/m.spiegel.de\/schulspiegel\/wissen\/a-437733.html#spRedirectedFrom=www",
      "display_url" : "m.spiegel.de\/schulspiegel\/w\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "159990005064941568",
  "geo" : { },
  "id_str" : "160004241958768640",
  "in_reply_to_user_id" : 50121415,
  "text" : "@robikraus @de_Wastl schon etwas \u00E4lter: http:\/\/t.co\/rkm5SJo8",
  "id" : 160004241958768640,
  "in_reply_to_status_id" : 159990005064941568,
  "created_at" : "2012-01-19 14:22:38 +0000",
  "in_reply_to_screen_name" : "_papow_",
  "in_reply_to_user_id_str" : "50121415",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jensbest",
      "screen_name" : "jensbest",
      "indices" : [ 27, 36 ],
      "id_str" : "14599545",
      "id" : 14599545
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 103, 112 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 98 ],
      "url" : "http:\/\/t.co\/ctucIoK0",
      "expanded_url" : "http:\/\/ow.ly\/8yFLz",
      "display_url" : "ow.ly\/8yFLz"
    } ]
  },
  "geo" : { },
  "id_str" : "159904380953440256",
  "text" : "Von Ethik & Klimawandel MT @jensbest: FLEISCH ist keine Privatsache mehr[...] http:\/\/t.co\/ctucIoK0 \/cc @Senficon",
  "id" : 159904380953440256,
  "created_at" : "2012-01-19 07:45:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 104 ],
      "url" : "http:\/\/t.co\/ax4jF6BM",
      "expanded_url" : "http:\/\/j.mp\/zFoTLS",
      "display_url" : "j.mp\/zFoTLS"
    } ]
  },
  "geo" : { },
  "id_str" : "159901854979981312",
  "text" : "Interrogating Claims about Natural Sexual Behavior: More on Deep Thinking Hebephile http:\/\/t.co\/ax4jF6BM",
  "id" : 159901854979981312,
  "created_at" : "2012-01-19 07:35:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 39 ],
      "url" : "http:\/\/t.co\/gq5atjIx",
      "expanded_url" : "http:\/\/j.mp\/z8KWui",
      "display_url" : "j.mp\/z8KWui"
    } ]
  },
  "geo" : { },
  "id_str" : "159898092722847744",
  "text" : "Regulatory Capture http:\/\/t.co\/gq5atjIx",
  "id" : 159898092722847744,
  "created_at" : "2012-01-19 07:20:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 58 ],
      "url" : "http:\/\/t.co\/fOyhv9fK",
      "expanded_url" : "http:\/\/j.mp\/y0KFwp",
      "display_url" : "j.mp\/y0KFwp"
    } ]
  },
  "geo" : { },
  "id_str" : "159768960240320514",
  "text" : "Informatics Technology Mimics Ecology http:\/\/t.co\/fOyhv9fK",
  "id" : 159768960240320514,
  "created_at" : "2012-01-18 22:47:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "openSNP team",
      "screen_name" : "openSNPorg",
      "indices" : [ 3, 14 ],
      "id_str" : "380205172",
      "id" : 380205172
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 90 ],
      "url" : "http:\/\/t.co\/6nfVAxKe",
      "expanded_url" : "http:\/\/j.mp\/zD2IwV",
      "display_url" : "j.mp\/zD2IwV"
    } ]
  },
  "geo" : { },
  "id_str" : "159767094970429441",
  "text" : "RT @openSNPorg: Genetic Signatures of Exceptional Longevity in Humans http:\/\/t.co\/6nfVAxKe",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 54, 74 ],
        "url" : "http:\/\/t.co\/6nfVAxKe",
        "expanded_url" : "http:\/\/j.mp\/zD2IwV",
        "display_url" : "j.mp\/zD2IwV"
      } ]
    },
    "geo" : { },
    "id_str" : "159766886198939649",
    "text" : "Genetic Signatures of Exceptional Longevity in Humans http:\/\/t.co\/6nfVAxKe",
    "id" : 159766886198939649,
    "created_at" : "2012-01-18 22:39:28 +0000",
    "user" : {
      "name" : "openSNP team",
      "screen_name" : "openSNPorg",
      "protected" : false,
      "id_str" : "380205172",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/735374825187909632\/wJEJW1zW_normal.jpg",
      "id" : 380205172,
      "verified" : false
    }
  },
  "id" : 159767094970429441,
  "created_at" : "2012-01-18 22:40:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 80 ],
      "url" : "http:\/\/t.co\/6Jh4Q1ZB",
      "expanded_url" : "http:\/\/www.biodas.org\/wiki\/DASWorkshop2012",
      "display_url" : "biodas.org\/wiki\/DASWorksh\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "159758798842630144",
  "text" : "Just booked flight tickets to visit the DAS Workshop at EBI http:\/\/t.co\/6Jh4Q1ZB",
  "id" : 159758798842630144,
  "created_at" : "2012-01-18 22:07:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave-Kay",
      "screen_name" : "Dave_Kay",
      "indices" : [ 0, 9 ],
      "id_str" : "10487642",
      "id" : 10487642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "159724667815469057",
  "geo" : { },
  "id_str" : "159724732743294976",
  "in_reply_to_user_id" : 10487642,
  "text" : "@Dave_Kay Ne, leider nicht. :)",
  "id" : 159724732743294976,
  "in_reply_to_status_id" : 159724667815469057,
  "created_at" : "2012-01-18 19:51:58 +0000",
  "in_reply_to_screen_name" : "Dave_Kay",
  "in_reply_to_user_id_str" : "10487642",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Manuel Corpas",
      "screen_name" : "manuelcorpas",
      "indices" : [ 0, 13 ],
      "id_str" : "111020569",
      "id" : 111020569
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "159722589512675328",
  "geo" : { },
  "id_str" : "159724127123546112",
  "in_reply_to_user_id" : 111020569,
  "text" : "@manuelcorpas Thanks a lot! :)",
  "id" : 159724127123546112,
  "in_reply_to_status_id" : 159722589512675328,
  "created_at" : "2012-01-18 19:49:34 +0000",
  "in_reply_to_screen_name" : "manuelcorpas",
  "in_reply_to_user_id_str" : "111020569",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steffa",
      "screen_name" : "rei_in_der_tube",
      "indices" : [ 0, 16 ],
      "id_str" : "19707954",
      "id" : 19707954
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "159717805044932608",
  "geo" : { },
  "id_str" : "159717965124730880",
  "in_reply_to_user_id" : 19707954,
  "text" : "@rei_in_der_tube Naja, hier war ausnahmsweise einfach wirklich niemand zuhause ;)",
  "id" : 159717965124730880,
  "in_reply_to_status_id" : 159717805044932608,
  "created_at" : "2012-01-18 19:25:04 +0000",
  "in_reply_to_screen_name" : "rei_in_der_tube",
  "in_reply_to_user_id_str" : "19707954",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steffa",
      "screen_name" : "rei_in_der_tube",
      "indices" : [ 0, 16 ],
      "id_str" : "19707954",
      "id" : 19707954
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "159710778008678401",
  "geo" : { },
  "id_str" : "159712734324330498",
  "in_reply_to_user_id" : 19707954,
  "text" : "@rei_in_der_tube Ich darf morgen einen 24\" Monitor von der Filiale zu Fuss abholen. Mein R\u00FCcken freut sich schon ;)",
  "id" : 159712734324330498,
  "in_reply_to_status_id" : 159710778008678401,
  "created_at" : "2012-01-18 19:04:17 +0000",
  "in_reply_to_screen_name" : "rei_in_der_tube",
  "in_reply_to_user_id_str" : "19707954",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 96 ],
      "url" : "http:\/\/t.co\/50aTh8tM",
      "expanded_url" : "http:\/\/opensnp.wordpress.com\/2012\/01\/18\/some-progress-on-the-api-json-endpoints\/",
      "display_url" : "opensnp.wordpress.com\/2012\/01\/18\/som\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "159704581562052608",
  "text" : "As was often requested: openSNP now features some JSON-methods to grab data http:\/\/t.co\/50aTh8tM",
  "id" : 159704581562052608,
  "created_at" : "2012-01-18 18:31:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GrrlScientist",
      "screen_name" : "GrrlScientist",
      "indices" : [ 3, 17 ],
      "id_str" : "27834920",
      "id" : 27834920
    }, {
      "name" : "GrrlScientist",
      "screen_name" : "GrrlScientist",
      "indices" : [ 122, 136 ],
      "id_str" : "27834920",
      "id" : 27834920
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "159683340574789632",
  "text" : "RT @GrrlScientist: the script for this satirical video commentary on SOPA\/PIPA is really well done: Hitler reacts to SOPA @GrrlScientist ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "GrrlScientist",
        "screen_name" : "GrrlScientist",
        "indices" : [ 103, 117 ],
        "id_str" : "27834920",
        "id" : 27834920
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 138 ],
        "url" : "http:\/\/t.co\/mDogNZtE",
        "expanded_url" : "http:\/\/gu.com\/p\/34ndb\/tw",
        "display_url" : "gu.com\/p\/34ndb\/tw"
      } ]
    },
    "geo" : { },
    "id_str" : "159682698644963328",
    "text" : "the script for this satirical video commentary on SOPA\/PIPA is really well done: Hitler reacts to SOPA @GrrlScientist http:\/\/t.co\/mDogNZtE",
    "id" : 159682698644963328,
    "created_at" : "2012-01-18 17:04:56 +0000",
    "user" : {
      "name" : "GrrlScientist",
      "screen_name" : "GrrlScientist",
      "protected" : false,
      "id_str" : "27834920",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/874915412735086593\/5QEzH-DY_normal.jpg",
      "id" : 27834920,
      "verified" : true
    }
  },
  "id" : 159683340574789632,
  "created_at" : "2012-01-18 17:07:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sebastian Kroos",
      "screen_name" : "de_Wastl",
      "indices" : [ 0, 9 ],
      "id_str" : "17620538",
      "id" : 17620538
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "159678187645845504",
  "geo" : { },
  "id_str" : "159678288665657344",
  "in_reply_to_user_id" : 17620538,
  "text" : "@de_Wastl Dann w\u00FCrde ich mal bei den Busunternehmen in MS und Umgebung anfragen. :)",
  "id" : 159678288665657344,
  "in_reply_to_status_id" : 159678187645845504,
  "created_at" : "2012-01-18 16:47:25 +0000",
  "in_reply_to_screen_name" : "de_Wastl",
  "in_reply_to_user_id_str" : "17620538",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sebastian Kroos",
      "screen_name" : "de_Wastl",
      "indices" : [ 0, 9 ],
      "id_str" : "17620538",
      "id" : 17620538
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "159677383421595648",
  "geo" : { },
  "id_str" : "159678054355058688",
  "in_reply_to_user_id" : 17620538,
  "text" : "@de_Wastl Was zahlste denn an Miete? ;)",
  "id" : 159678054355058688,
  "in_reply_to_status_id" : 159677383421595648,
  "created_at" : "2012-01-18 16:46:29 +0000",
  "in_reply_to_screen_name" : "de_Wastl",
  "in_reply_to_user_id_str" : "17620538",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 0, 10 ],
      "id_str" : "14700783",
      "id" : 14700783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "159669855224741888",
  "geo" : { },
  "id_str" : "159669925466746880",
  "in_reply_to_user_id" : 14700783,
  "text" : "@Fischblog Das f\u00E4nde ich n\u00E4mlich ziemlich sexy muss ich sagen. :)",
  "id" : 159669925466746880,
  "in_reply_to_status_id" : 159669855224741888,
  "created_at" : "2012-01-18 16:14:11 +0000",
  "in_reply_to_screen_name" : "Fischblog",
  "in_reply_to_user_id_str" : "14700783",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 0, 10 ],
      "id_str" : "14700783",
      "id" : 14700783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "159668378309636096",
  "geo" : { },
  "id_str" : "159668675308298242",
  "in_reply_to_user_id" : 14700783,
  "text" : "@Fischblog Praktischer gedacht: Kann man eigentlich so ein CI auf andere Frequenzb\u00E4nder umprogrammieren?",
  "id" : 159668675308298242,
  "in_reply_to_status_id" : 159668378309636096,
  "created_at" : "2012-01-18 16:09:13 +0000",
  "in_reply_to_screen_name" : "Fischblog",
  "in_reply_to_user_id_str" : "14700783",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 58 ],
      "url" : "http:\/\/t.co\/7cAzMOkD",
      "expanded_url" : "http:\/\/j.mp\/y8tYFw",
      "display_url" : "j.mp\/y8tYFw"
    } ]
  },
  "geo" : { },
  "id_str" : "159657825889562624",
  "text" : "Euphemisms: Making Murder Respectable http:\/\/t.co\/7cAzMOkD",
  "id" : 159657825889562624,
  "created_at" : "2012-01-18 15:26:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.instapaper.com\/\" rel=\"nofollow\"\u003EInstapaper\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 84 ],
      "url" : "http:\/\/t.co\/zfsIC7xo",
      "expanded_url" : "http:\/\/j.mp\/xRZSDd",
      "display_url" : "j.mp\/xRZSDd"
    } ]
  },
  "geo" : { },
  "id_str" : "159653811433127936",
  "text" : "Genetically modified foods: Ari Laux's alarmism in the Atlantic http:\/\/t.co\/zfsIC7xo",
  "id" : 159653811433127936,
  "created_at" : "2012-01-18 15:10:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "trashdot",
      "screen_name" : "trashdot",
      "indices" : [ 3, 12 ],
      "id_str" : "15168759",
      "id" : 15168759
    }, {
      "name" : "Sue Reindke",
      "screen_name" : "HappySchnitzel",
      "indices" : [ 17, 32 ],
      "id_str" : "16379529",
      "id" : 16379529
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 127 ],
      "url" : "http:\/\/t.co\/15rD61Qa",
      "expanded_url" : "http:\/\/bit.ly\/xAT5gl",
      "display_url" : "bit.ly\/xAT5gl"
    } ]
  },
  "geo" : { },
  "id_str" : "159650447374811136",
  "text" : "RT @trashdot: RT @HappySchnitzel: Die Hymne des Tages: The day the LOLcats died. (Achtung, Ohrwurmgefahr!) http:\/\/t.co\/15rD61Qa",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Sue Reindke",
        "screen_name" : "HappySchnitzel",
        "indices" : [ 3, 18 ],
        "id_str" : "16379529",
        "id" : 16379529
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 93, 113 ],
        "url" : "http:\/\/t.co\/15rD61Qa",
        "expanded_url" : "http:\/\/bit.ly\/xAT5gl",
        "display_url" : "bit.ly\/xAT5gl"
      } ]
    },
    "geo" : { },
    "id_str" : "159649313054670849",
    "text" : "RT @HappySchnitzel: Die Hymne des Tages: The day the LOLcats died. (Achtung, Ohrwurmgefahr!) http:\/\/t.co\/15rD61Qa",
    "id" : 159649313054670849,
    "created_at" : "2012-01-18 14:52:17 +0000",
    "user" : {
      "name" : "trashdot",
      "screen_name" : "trashdot",
      "protected" : false,
      "id_str" : "15168759",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1679469638\/avatar_5__normal.png",
      "id" : 15168759,
      "verified" : false
    }
  },
  "id" : 159650447374811136,
  "created_at" : "2012-01-18 14:56:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 27, 37 ],
      "id_str" : "14700783",
      "id" : 14700783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 87 ],
      "url" : "http:\/\/t.co\/WsmPEH1F",
      "expanded_url" : "http:\/\/www.scilogs.de\/wblogs\/blog\/fischblog\/allgemein\/2012-01-18\/wissenschaftler-und-journalisten",
      "display_url" : "scilogs.de\/wblogs\/blog\/fi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "159605810446614529",
  "text" : "Und deshalb findet man den @Fischblog und mich immer in der Kneipe http:\/\/t.co\/WsmPEH1F",
  "id" : 159605810446614529,
  "created_at" : "2012-01-18 11:59:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "159558605358628864",
  "geo" : { },
  "id_str" : "159559284001214464",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon Immerhin war das dann wohl billig genug damit wir nicht selbst zum Zoll m\u00FCssen ;)",
  "id" : 159559284001214464,
  "in_reply_to_status_id" : 159558605358628864,
  "created_at" : "2012-01-18 08:54:32 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "159558257625661440",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon Danke f\u00FCrs Paket abholen. D\u00FCrften RadioLab-Buttons sein ;)",
  "id" : 159558257625661440,
  "created_at" : "2012-01-18 08:50:27 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "J\u00FCrgen Geuter",
      "screen_name" : "tante",
      "indices" : [ 0, 6 ],
      "id_str" : "14179278",
      "id" : 14179278
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 16, 25 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "159539249652310016",
  "geo" : { },
  "id_str" : "159541265237676032",
  "in_reply_to_user_id" : 14179278,
  "text" : "@tante frag mal @Senficon, die ist daf\u00FCr seit kurzem Expertin.",
  "id" : 159541265237676032,
  "in_reply_to_status_id" : 159539249652310016,
  "created_at" : "2012-01-18 07:42:56 +0000",
  "in_reply_to_screen_name" : "tante",
  "in_reply_to_user_id_str" : "14179278",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 98 ],
      "url" : "http:\/\/t.co\/KhYxjINw",
      "expanded_url" : "http:\/\/j.mp\/xH6X0d",
      "display_url" : "j.mp\/xH6X0d"
    } ]
  },
  "geo" : { },
  "id_str" : "159405898224254976",
  "text" : "A personal view of genetic diagnosis using modern DNA sequencing technologies http:\/\/t.co\/KhYxjINw",
  "id" : 159405898224254976,
  "created_at" : "2012-01-17 22:45:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 117 ],
      "url" : "http:\/\/t.co\/9cZNJYEt",
      "expanded_url" : "http:\/\/j.mp\/yTvZjS",
      "display_url" : "j.mp\/yTvZjS"
    } ]
  },
  "geo" : { },
  "id_str" : "159405462293463040",
  "text" : "Males become more competitive when potential mates are short in supply, so they spend more money http:\/\/t.co\/9cZNJYEt",
  "id" : 159405462293463040,
  "created_at" : "2012-01-17 22:43:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 111 ],
      "url" : "http:\/\/t.co\/kA856Fm3",
      "expanded_url" : "http:\/\/j.mp\/yWKroC",
      "display_url" : "j.mp\/yWKroC"
    } ]
  },
  "geo" : { },
  "id_str" : "159404896997748737",
  "text" : "Genetic Mapping and Exome Sequencing Identify Variants Associated with Five Novel Diseases http:\/\/t.co\/kA856Fm3",
  "id" : 159404896997748737,
  "created_at" : "2012-01-17 22:41:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "openSNP team",
      "screen_name" : "openSNPorg",
      "indices" : [ 19, 30 ],
      "id_str" : "380205172",
      "id" : 380205172
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "159370105497726976",
  "text" : "Did some stuff for @opensnporg JSON of SNP-genotype for a given user and list of all phenotypes of a given user now works.",
  "id" : 159370105497726976,
  "created_at" : "2012-01-17 20:22:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 40 ],
      "url" : "http:\/\/t.co\/0t4h1yF4",
      "expanded_url" : "http:\/\/j.mp\/yxfKTC",
      "display_url" : "j.mp\/yxfKTC"
    } ]
  },
  "geo" : { },
  "id_str" : "159356522223251456",
  "text" : "Shit Scientists Say http:\/\/t.co\/0t4h1yF4",
  "id" : 159356522223251456,
  "created_at" : "2012-01-17 19:28:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Silberman",
      "screen_name" : "stevesilberman",
      "indices" : [ 3, 18 ],
      "id_str" : "18655567",
      "id" : 18655567
    }, {
      "name" : "Alexis C. Madrigal",
      "screen_name" : "alexismadrigal",
      "indices" : [ 37, 52 ],
      "id_str" : "11107172",
      "id" : 11107172
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 99 ],
      "url" : "http:\/\/t.co\/H5ARbMc6",
      "expanded_url" : "http:\/\/bit.ly\/z17kmv",
      "display_url" : "bit.ly\/z17kmv"
    } ]
  },
  "geo" : { },
  "id_str" : "159332808685387777",
  "text" : "RT @stevesilberman: Pithy, brilliant @alexismadrigal on \"the Radiolab effect.\" http:\/\/t.co\/H5ARbMc6",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Alexis C. Madrigal",
        "screen_name" : "alexismadrigal",
        "indices" : [ 17, 32 ],
        "id_str" : "11107172",
        "id" : 11107172
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 59, 79 ],
        "url" : "http:\/\/t.co\/H5ARbMc6",
        "expanded_url" : "http:\/\/bit.ly\/z17kmv",
        "display_url" : "bit.ly\/z17kmv"
      } ]
    },
    "geo" : { },
    "id_str" : "159332074921279488",
    "text" : "Pithy, brilliant @alexismadrigal on \"the Radiolab effect.\" http:\/\/t.co\/H5ARbMc6",
    "id" : 159332074921279488,
    "created_at" : "2012-01-17 17:51:41 +0000",
    "user" : {
      "name" : "Steve Silberman",
      "screen_name" : "stevesilberman",
      "protected" : false,
      "id_str" : "18655567",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/801317729978449920\/1ZDKwlMv_normal.jpg",
      "id" : 18655567,
      "verified" : true
    }
  },
  "id" : 159332808685387777,
  "created_at" : "2012-01-17 17:54:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "159324656132833282",
  "text" : "Are there any chrome extension developers around here?",
  "id" : 159324656132833282,
  "created_at" : "2012-01-17 17:22:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrick Rauscher",
      "screen_name" : "prauscher",
      "indices" : [ 0, 10 ],
      "id_str" : "74155696",
      "id" : 74155696
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "159314056665247744",
  "geo" : { },
  "id_str" : "159320718297927681",
  "in_reply_to_user_id" : 74155696,
  "text" : "@prauscher m(",
  "id" : 159320718297927681,
  "in_reply_to_status_id" : 159314056665247744,
  "created_at" : "2012-01-17 17:06:33 +0000",
  "in_reply_to_screen_name" : "prauscher",
  "in_reply_to_user_id_str" : "74155696",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "159300154158100480",
  "text" : "Working on some JSON-output so users can easily query genotypes for user\/SNP-combinations.",
  "id" : 159300154158100480,
  "created_at" : "2012-01-17 15:44:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "openSNP team",
      "screen_name" : "openSNPorg",
      "indices" : [ 3, 14 ],
      "id_str" : "380205172",
      "id" : 380205172
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 77, 90 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "159278312135475200",
  "text" : "RT @openSNPorg: Looking for a way to parse all files you can obtain from us? @PhilippBayer wrote a small example parser in Python https: ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Philipp Bayer\uD83C\uDF08",
        "screen_name" : "PhilippBayer",
        "indices" : [ 61, 74 ],
        "id_str" : "121777206",
        "id" : 121777206
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 135 ],
        "url" : "https:\/\/t.co\/6pdmwHfj",
        "expanded_url" : "https:\/\/gist.github.com\/1626642",
        "display_url" : "gist.github.com\/1626642"
      } ]
    },
    "geo" : { },
    "id_str" : "159278285375799296",
    "text" : "Looking for a way to parse all files you can obtain from us? @PhilippBayer wrote a small example parser in Python https:\/\/t.co\/6pdmwHfj",
    "id" : 159278285375799296,
    "created_at" : "2012-01-17 14:17:57 +0000",
    "user" : {
      "name" : "openSNP team",
      "screen_name" : "openSNPorg",
      "protected" : false,
      "id_str" : "380205172",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/735374825187909632\/wJEJW1zW_normal.jpg",
      "id" : 380205172,
      "verified" : false
    }
  },
  "id" : 159278312135475200,
  "created_at" : "2012-01-17 14:18:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 3, 9 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 135 ],
      "url" : "http:\/\/t.co\/g33XLvOh",
      "expanded_url" : "http:\/\/matadornetwork.com\/abroad\/how-to-piss-off-a-german\/",
      "display_url" : "matadornetwork.com\/abroad\/how-to-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "159241809384579072",
  "text" : "RT @Lobot: Auch sch\u00F6n: \"Even the most house-trained German men don\u2019t wee sitting down in clubs or public toilets.\" http:\/\/t.co\/g33XLvOh",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 104, 124 ],
        "url" : "http:\/\/t.co\/g33XLvOh",
        "expanded_url" : "http:\/\/matadornetwork.com\/abroad\/how-to-piss-off-a-german\/",
        "display_url" : "matadornetwork.com\/abroad\/how-to-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "159231600427667456",
    "text" : "Auch sch\u00F6n: \"Even the most house-trained German men don\u2019t wee sitting down in clubs or public toilets.\" http:\/\/t.co\/g33XLvOh",
    "id" : 159231600427667456,
    "created_at" : "2012-01-17 11:12:26 +0000",
    "user" : {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "protected" : false,
      "id_str" : "1492631",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/783617256173494272\/7QL2FeUx_normal.jpg",
      "id" : 1492631,
      "verified" : false
    }
  },
  "id" : 159241809384579072,
  "created_at" : "2012-01-17 11:53:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 42 ],
      "url" : "http:\/\/t.co\/lFfGXvQv",
      "expanded_url" : "http:\/\/j.mp\/xJYLk7",
      "display_url" : "j.mp\/xJYLk7"
    } ]
  },
  "geo" : { },
  "id_str" : "159178438178115584",
  "text" : "Steve Ballmer Reboots http:\/\/t.co\/lFfGXvQv",
  "id" : 159178438178115584,
  "created_at" : "2012-01-17 07:41:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joshua Shapiro",
      "screen_name" : "jashapiro",
      "indices" : [ 71, 81 ],
      "id_str" : "12286942",
      "id" : 12286942
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 60 ],
      "url" : "http:\/\/t.co\/i7L4aDQT",
      "expanded_url" : "http:\/\/www.evilmadscientist.com\/article.php\/bristlebot",
      "display_url" : "evilmadscientist.com\/article.php\/br\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "159174860893978625",
  "text" : "This looks like a fun robotics project! http:\/\/t.co\/i7L4aDQT \/Link via @jashapiro",
  "id" : 159174860893978625,
  "created_at" : "2012-01-17 07:26:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 80 ],
      "url" : "http:\/\/t.co\/7rNdn3l5",
      "expanded_url" : "http:\/\/j.mp\/AdtGS7",
      "display_url" : "j.mp\/AdtGS7"
    } ]
  },
  "geo" : { },
  "id_str" : "159173247378800640",
  "text" : "A Glow-in-the-Dark Material that Lasts All Night and Longer http:\/\/t.co\/7rNdn3l5",
  "id" : 159173247378800640,
  "created_at" : "2012-01-17 07:20:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 36 ],
      "url" : "http:\/\/t.co\/hdXLL9K3",
      "expanded_url" : "http:\/\/j.mp\/zqt4HL",
      "display_url" : "j.mp\/zqt4HL"
    } ]
  },
  "geo" : { },
  "id_str" : "159172521189580800",
  "text" : "Those academics http:\/\/t.co\/hdXLL9K3",
  "id" : 159172521189580800,
  "created_at" : "2012-01-17 07:17:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "aprica",
      "screen_name" : "aprica",
      "indices" : [ 0, 7 ],
      "id_str" : "13196692",
      "id" : 13196692
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "159053290787700737",
  "geo" : { },
  "id_str" : "159054235722448896",
  "in_reply_to_user_id" : 13196692,
  "text" : "@aprica danke :)",
  "id" : 159054235722448896,
  "in_reply_to_status_id" : 159053290787700737,
  "created_at" : "2012-01-16 23:27:39 +0000",
  "in_reply_to_screen_name" : "aprica",
  "in_reply_to_user_id_str" : "13196692",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "aprica",
      "screen_name" : "aprica",
      "indices" : [ 0, 7 ],
      "id_str" : "13196692",
      "id" : 13196692
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "159049069292044288",
  "geo" : { },
  "id_str" : "159052408310337536",
  "in_reply_to_user_id" : 13196692,
  "text" : "@aprica hier :)",
  "id" : 159052408310337536,
  "in_reply_to_status_id" : 159049069292044288,
  "created_at" : "2012-01-16 23:20:23 +0000",
  "in_reply_to_screen_name" : "aprica",
  "in_reply_to_user_id_str" : "13196692",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Hawks",
      "screen_name" : "johnhawks",
      "indices" : [ 3, 13 ],
      "id_str" : "52584039",
      "id" : 52584039
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "159052314148208641",
  "text" : "RT @johnhawks: \"For $5000 I could pay someone to sit in a coffee shop and hand-type my article into personalized e-mails\" http:\/\/t.co\/CQ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 107, 127 ],
        "url" : "http:\/\/t.co\/CQ3sTUSE",
        "expanded_url" : "http:\/\/bit.ly\/wnsWxU",
        "display_url" : "bit.ly\/wnsWxU"
      } ]
    },
    "geo" : { },
    "id_str" : "159046161196523520",
    "text" : "\"For $5000 I could pay someone to sit in a coffee shop and hand-type my article into personalized e-mails\" http:\/\/t.co\/CQ3sTUSE",
    "id" : 159046161196523520,
    "created_at" : "2012-01-16 22:55:34 +0000",
    "user" : {
      "name" : "John Hawks",
      "screen_name" : "johnhawks",
      "protected" : false,
      "id_str" : "52584039",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2162500613\/scio12-0442-jhawks-twitter-focus_normal.jpg",
      "id" : 52584039,
      "verified" : false
    }
  },
  "id" : 159052314148208641,
  "created_at" : "2012-01-16 23:20:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 58 ],
      "url" : "http:\/\/t.co\/XBnUKCTY",
      "expanded_url" : "http:\/\/j.mp\/zIdkUu",
      "display_url" : "j.mp\/zIdkUu"
    } ]
  },
  "geo" : { },
  "id_str" : "159051490487574528",
  "text" : "Als sie kamen, um die Kekse zu holen\u2026 http:\/\/t.co\/XBnUKCTY",
  "id" : 159051490487574528,
  "created_at" : "2012-01-16 23:16:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anonymous",
      "screen_name" : "AnonyOps",
      "indices" : [ 3, 12 ],
      "id_str" : "225235528",
      "id" : 225235528
    }, {
      "name" : "MPAA",
      "screen_name" : "MPAA",
      "indices" : [ 45, 50 ],
      "id_str" : "289072583",
      "id" : 289072583
    }, {
      "name" : "RIAA",
      "screen_name" : "RIAA",
      "indices" : [ 53, 58 ],
      "id_str" : "487620060",
      "id" : 487620060
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOPA",
      "indices" : [ 124, 129 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 123 ],
      "url" : "http:\/\/t.co\/XZDmlIEW",
      "expanded_url" : "http:\/\/thepiratebay.org\/promo",
      "display_url" : "thepiratebay.org\/promo"
    } ]
  },
  "geo" : { },
  "id_str" : "159044241325162496",
  "text" : "RT @AnonyOps: In a giant \"Who needs you?\" to @MPAA & @RIAA, The Pirate Bay will start promoting bands: http:\/\/t.co\/XZDmlIEW #SOPA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/birdherd.com\" rel=\"nofollow\"\u003EBird Herd\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "MPAA",
        "screen_name" : "MPAA",
        "indices" : [ 31, 36 ],
        "id_str" : "289072583",
        "id" : 289072583
      }, {
        "name" : "RIAA",
        "screen_name" : "RIAA",
        "indices" : [ 39, 44 ],
        "id_str" : "487620060",
        "id" : 487620060
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SOPA",
        "indices" : [ 110, 115 ]
      } ],
      "urls" : [ {
        "indices" : [ 89, 109 ],
        "url" : "http:\/\/t.co\/XZDmlIEW",
        "expanded_url" : "http:\/\/thepiratebay.org\/promo",
        "display_url" : "thepiratebay.org\/promo"
      } ]
    },
    "geo" : { },
    "id_str" : "158666095191003136",
    "text" : "In a giant \"Who needs you?\" to @MPAA & @RIAA, The Pirate Bay will start promoting bands: http:\/\/t.co\/XZDmlIEW #SOPA",
    "id" : 158666095191003136,
    "created_at" : "2012-01-15 21:45:19 +0000",
    "user" : {
      "name" : "Anonymous",
      "screen_name" : "AnonyOps",
      "protected" : false,
      "id_str" : "225235528",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/544502451265486848\/1kc793mC_normal.jpeg",
      "id" : 225235528,
      "verified" : false
    }
  },
  "id" : 159044241325162496,
  "created_at" : "2012-01-16 22:47:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 108 ],
      "url" : "http:\/\/t.co\/3uc7kMvm",
      "expanded_url" : "http:\/\/seqify.com\/alpha",
      "display_url" : "seqify.com\/alpha"
    } ]
  },
  "geo" : { },
  "id_str" : "159040682286252033",
  "text" : "Interested in DNA barcoding of edible fish? Give it a try (if you're located in the US) http:\/\/t.co\/3uc7kMvm",
  "id" : 159040682286252033,
  "created_at" : "2012-01-16 22:33:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 86 ],
      "url" : "http:\/\/t.co\/6k7gyROJ",
      "expanded_url" : "http:\/\/blogs.plos.org\/obesitypanacea\/2012\/01\/16\/can-you-limit-your-sitting-and-sleeping-to-just-23-5-hrs-per-day\/",
      "display_url" : "blogs.plos.org\/obesitypanacea\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "159025128330637312",
  "text" : "Can you limit your sitting and sleeping to just 23.5 hrs per day? http:\/\/t.co\/6k7gyROJ",
  "id" : 159025128330637312,
  "created_at" : "2012-01-16 21:31:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DetritusBlog",
      "screen_name" : "gedankenabfall",
      "indices" : [ 0, 15 ],
      "id_str" : "2175883684",
      "id" : 2175883684
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "159004832726908928",
  "geo" : { },
  "id_str" : "159007125165715456",
  "in_reply_to_user_id" : 29082973,
  "text" : "@gedankenabfall \u00ABLife(Type) is killing me!\u00BB",
  "id" : 159007125165715456,
  "in_reply_to_status_id" : 159004832726908928,
  "created_at" : "2012-01-16 20:20:27 +0000",
  "in_reply_to_screen_name" : "ballaschk",
  "in_reply_to_user_id_str" : "29082973",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DetritusBlog",
      "screen_name" : "gedankenabfall",
      "indices" : [ 0, 15 ],
      "id_str" : "2175883684",
      "id" : 2175883684
    }, {
      "name" : "Anatol Stefanowitsch",
      "screen_name" : "astefanowitsch",
      "indices" : [ 42, 57 ],
      "id_str" : "73134122",
      "id" : 73134122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "159004832726908928",
  "geo" : { },
  "id_str" : "159005685231792128",
  "in_reply_to_user_id" : 29082973,
  "text" : "@gedankenabfall Jetzt m\u00FCssen wir nur noch @astefanowitsch um schmissige Slogans bitten ;)",
  "id" : 159005685231792128,
  "in_reply_to_status_id" : 159004832726908928,
  "created_at" : "2012-01-16 20:14:44 +0000",
  "in_reply_to_screen_name" : "ballaschk",
  "in_reply_to_user_id_str" : "29082973",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DetritusBlog",
      "screen_name" : "gedankenabfall",
      "indices" : [ 0, 15 ],
      "id_str" : "2175883684",
      "id" : 2175883684
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 77 ],
      "url" : "http:\/\/t.co\/oUSFZvHw",
      "expanded_url" : "http:\/\/www.artsjournal.com\/outthere\/1934_picket_line_6x11_300_dpi.jpg",
      "display_url" : "artsjournal.com\/outthere\/1934_\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "159004461438738432",
  "geo" : { },
  "id_str" : "159004627642224641",
  "in_reply_to_user_id" : 29082973,
  "text" : "@gedankenabfall Ich sag ja: Picket Line in Deidesheim ;) http:\/\/t.co\/oUSFZvHw",
  "id" : 159004627642224641,
  "in_reply_to_status_id" : 159004461438738432,
  "created_at" : "2012-01-16 20:10:32 +0000",
  "in_reply_to_screen_name" : "ballaschk",
  "in_reply_to_user_id_str" : "29082973",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DetritusBlog",
      "screen_name" : "gedankenabfall",
      "indices" : [ 0, 15 ],
      "id_str" : "2175883684",
      "id" : 2175883684
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "159004214352297984",
  "geo" : { },
  "id_str" : "159004247885758464",
  "in_reply_to_user_id" : 29082973,
  "text" : "@gedankenabfall Ah, stimmt",
  "id" : 159004247885758464,
  "in_reply_to_status_id" : 159004214352297984,
  "created_at" : "2012-01-16 20:09:01 +0000",
  "in_reply_to_screen_name" : "ballaschk",
  "in_reply_to_user_id_str" : "29082973",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DetritusBlog",
      "screen_name" : "gedankenabfall",
      "indices" : [ 0, 15 ],
      "id_str" : "2175883684",
      "id" : 2175883684
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "159003990179323904",
  "geo" : { },
  "id_str" : "159004177610178560",
  "in_reply_to_user_id" : 29082973,
  "text" : "@gedankenabfall Wobei ich mir ehrlich gesagt nicht sicher bin ob manche Bugs nicht einfach an der XMLRPC-Schnittstelle von LT liegen. :(",
  "id" : 159004177610178560,
  "in_reply_to_status_id" : 159003990179323904,
  "created_at" : "2012-01-16 20:08:44 +0000",
  "in_reply_to_screen_name" : "ballaschk",
  "in_reply_to_user_id_str" : "29082973",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DetritusBlog",
      "screen_name" : "gedankenabfall",
      "indices" : [ 0, 15 ],
      "id_str" : "2175883684",
      "id" : 2175883684
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "159003990179323904",
  "geo" : { },
  "id_str" : "159004057829261312",
  "in_reply_to_user_id" : 29082973,
  "text" : "@gedankenabfall Was f\u00FCr Probleme hat der? :D",
  "id" : 159004057829261312,
  "in_reply_to_status_id" : 159003990179323904,
  "created_at" : "2012-01-16 20:08:16 +0000",
  "in_reply_to_screen_name" : "ballaschk",
  "in_reply_to_user_id_str" : "29082973",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Brechler",
      "screen_name" : "plaetzchen",
      "indices" : [ 0, 11 ],
      "id_str" : "14305613",
      "id" : 14305613
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "159002071901810690",
  "geo" : { },
  "id_str" : "159002695187963904",
  "in_reply_to_user_id" : 14305613,
  "text" : "@plaetzchen Rate my Foo :P",
  "id" : 159002695187963904,
  "in_reply_to_status_id" : 159002071901810690,
  "created_at" : "2012-01-16 20:02:51 +0000",
  "in_reply_to_screen_name" : "plaetzchen",
  "in_reply_to_user_id_str" : "14305613",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 108 ],
      "url" : "http:\/\/t.co\/INngqGFO",
      "expanded_url" : "http:\/\/www.scilogs.de\/wblogs\/blog\/bierologie\/biologie\/2012-01-16\/genom-bergreifende-kooperationen",
      "display_url" : "scilogs.de\/wblogs\/blog\/bi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "159002327662075904",
  "text" : "Ich hab mal kurz \u00FCber die Koevolution von Genomen & die Endosymbiontentheorie gebloggt: http:\/\/t.co\/INngqGFO",
  "id" : 159002327662075904,
  "created_at" : "2012-01-16 20:01:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "158965926774063105",
  "text" : "Jetzt f\u00E4ngt sogar mein XMLRPC-Client an Blogposts zu fressen...",
  "id" : 158965926774063105,
  "created_at" : "2012-01-16 17:36:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sebastian Boegel",
      "screen_name" : "sebboeg",
      "indices" : [ 0, 8 ],
      "id_str" : "296476788",
      "id" : 296476788
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "158942672147582976",
  "geo" : { },
  "id_str" : "158943006228086784",
  "in_reply_to_user_id" : 296476788,
  "text" : "@sebboeg ja, ich suche noch :)",
  "id" : 158943006228086784,
  "in_reply_to_status_id" : 158942672147582976,
  "created_at" : "2012-01-16 16:05:40 +0000",
  "in_reply_to_screen_name" : "sebboeg",
  "in_reply_to_user_id_str" : "296476788",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "openaccess",
      "indices" : [ 104, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 136 ],
      "url" : "http:\/\/t.co\/NnywRzn4",
      "expanded_url" : "http:\/\/www.guardian.co.uk\/science\/2012\/jan\/16\/academic-publishers-enemies-science",
      "display_url" : "guardian.co.uk\/science\/2012\/j\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "158942730515517441",
  "text" : "\u00ABPublishers have turned to the approach that uncompetitive corporations have always used in America...\u00BB #openaccess http:\/\/t.co\/NnywRzn4",
  "id" : 158942730515517441,
  "created_at" : "2012-01-16 16:04:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "cr",
      "screen_name" : "p4ula",
      "indices" : [ 3, 9 ],
      "id_str" : "18506162",
      "id" : 18506162
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 87 ],
      "url" : "http:\/\/t.co\/fRqhF8FW",
      "expanded_url" : "http:\/\/acko.net\/blog\/making-love-to-webkit\/",
      "display_url" : "acko.net\/blog\/making-lo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "158940124078555137",
  "text" : "RT @p4ula: If there's such a thing as a cssorgasm, I just had one: http:\/\/t.co\/fRqhF8FW (Chrome\/Safari only)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 56, 76 ],
        "url" : "http:\/\/t.co\/fRqhF8FW",
        "expanded_url" : "http:\/\/acko.net\/blog\/making-love-to-webkit\/",
        "display_url" : "acko.net\/blog\/making-lo\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "158939030627696641",
    "text" : "If there's such a thing as a cssorgasm, I just had one: http:\/\/t.co\/fRqhF8FW (Chrome\/Safari only)",
    "id" : 158939030627696641,
    "created_at" : "2012-01-16 15:49:52 +0000",
    "user" : {
      "name" : "cr",
      "screen_name" : "p4ula",
      "protected" : false,
      "id_str" : "18506162",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1763694644\/f-pentomino-titanium_normal.png",
      "id" : 18506162,
      "verified" : false
    }
  },
  "id" : 158940124078555137,
  "created_at" : "2012-01-16 15:54:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "fasel",
      "screen_name" : "fasel",
      "indices" : [ 0, 6 ],
      "id_str" : "21739255",
      "id" : 21739255
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "158937034893950976",
  "geo" : { },
  "id_str" : "158939546275422208",
  "in_reply_to_user_id" : 21739255,
  "text" : "@fasel Druglord BA.",
  "id" : 158939546275422208,
  "in_reply_to_status_id" : 158937034893950976,
  "created_at" : "2012-01-16 15:51:55 +0000",
  "in_reply_to_screen_name" : "fasel",
  "in_reply_to_user_id_str" : "21739255",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 89 ],
      "url" : "http:\/\/t.co\/IRyMqGfe",
      "expanded_url" : "http:\/\/j.mp\/xM4VzM",
      "display_url" : "j.mp\/xM4VzM"
    } ]
  },
  "geo" : { },
  "id_str" : "158939376762617856",
  "text" : "On the inheritance of traits like skin color: Mendelism is not magic http:\/\/t.co\/IRyMqGfe",
  "id" : 158939376762617856,
  "created_at" : "2012-01-16 15:51:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 132 ],
      "url" : "http:\/\/t.co\/1eBEEe8y",
      "expanded_url" : "http:\/\/j.mp\/xym4dB",
      "display_url" : "j.mp\/xym4dB"
    } ]
  },
  "geo" : { },
  "id_str" : "158938739119374337",
  "text" : "Cool: The presence of a prominent female role model in an Indian village reduces the gender gap in that village http:\/\/t.co\/1eBEEe8y",
  "id" : 158938739119374337,
  "created_at" : "2012-01-16 15:48:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 76 ],
      "url" : "http:\/\/t.co\/HvsdhpGf",
      "expanded_url" : "http:\/\/j.mp\/AjaY6Y",
      "display_url" : "j.mp\/AjaY6Y"
    } ]
  },
  "geo" : { },
  "id_str" : "158937040711458817",
  "text" : "Richard Dawkins celebrates a victory over creationists  http:\/\/t.co\/HvsdhpGf",
  "id" : 158937040711458817,
  "created_at" : "2012-01-16 15:41:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 52 ],
      "url" : "http:\/\/t.co\/lCgNNfp0",
      "expanded_url" : "http:\/\/j.mp\/zukXMP",
      "display_url" : "j.mp\/zukXMP"
    } ]
  },
  "geo" : { },
  "id_str" : "158936165469257728",
  "text" : "Mexico has a great DIY-movement http:\/\/t.co\/lCgNNfp0",
  "id" : 158936165469257728,
  "created_at" : "2012-01-16 15:38:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scytale",
      "screen_name" : "Scytale",
      "indices" : [ 0, 8 ],
      "id_str" : "621716753",
      "id" : 621716753
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "158933556222103553",
  "geo" : { },
  "id_str" : "158935334070136833",
  "in_reply_to_user_id" : 8308632,
  "text" : "@Scytale Man nennt es auch Anwenderfail. :(",
  "id" : 158935334070136833,
  "in_reply_to_status_id" : 158933556222103553,
  "created_at" : "2012-01-16 15:35:11 +0000",
  "in_reply_to_screen_name" : "scy",
  "in_reply_to_user_id_str" : "8308632",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 92 ],
      "url" : "http:\/\/t.co\/Iz1rQMH5",
      "expanded_url" : "http:\/\/4sq.com\/wy9Z7g",
      "display_url" : "4sq.com\/wy9Z7g"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1183767509, 8.6620438099 ]
  },
  "id_str" : "158933247663947777",
  "text" : "I'm at U-Bahnstation Westend (Bockenheimer Landstr., Frankfurt am Main) http:\/\/t.co\/Iz1rQMH5",
  "id" : 158933247663947777,
  "created_at" : "2012-01-16 15:26:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "icanhaspdf",
      "indices" : [ 105, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 104 ],
      "url" : "http:\/\/t.co\/VmpFzW6Y",
      "expanded_url" : "http:\/\/dx.doi.org\/10.1016\/0076-6879(87)43016-4",
      "display_url" : "dx.doi.org\/10.1016\/0076-6\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "158895008978698240",
  "text" : "Has anybody access to this paper? A mail to bgreshake@googlemail.com would be nice! http:\/\/t.co\/VmpFzW6Y #icanhaspdf",
  "id" : 158895008978698240,
  "created_at" : "2012-01-16 12:54:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 95 ],
      "url" : "http:\/\/t.co\/ZMF7ER53",
      "expanded_url" : "http:\/\/j.mp\/A9JhNg",
      "display_url" : "j.mp\/A9JhNg"
    } ]
  },
  "geo" : { },
  "id_str" : "158886518134538240",
  "text" : "Da hat sich der Herr Wicht mal wieder ausgetobt: Akademische Darmt\u00E4tigkeit http:\/\/t.co\/ZMF7ER53",
  "id" : 158886518134538240,
  "created_at" : "2012-01-16 12:21:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 81 ],
      "url" : "http:\/\/t.co\/byrAb77b",
      "expanded_url" : "http:\/\/j.mp\/yRYFkS",
      "display_url" : "j.mp\/yRYFkS"
    } ]
  },
  "geo" : { },
  "id_str" : "158836205914566656",
  "text" : "Insults from the Copyright Lobby Over The Research Works Act http:\/\/t.co\/byrAb77b",
  "id" : 158836205914566656,
  "created_at" : "2012-01-16 09:01:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laurie Penny",
      "screen_name" : "PennyRed",
      "indices" : [ 3, 12 ],
      "id_str" : "19530289",
      "id" : 19530289
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "republican",
      "indices" : [ 102, 113 ]
    }, {
      "text" : "lol",
      "indices" : [ 114, 118 ]
    }, {
      "text" : "godsavethequeen",
      "indices" : [ 119, 135 ]
    } ],
    "urls" : [ {
      "indices" : [ 81, 101 ],
      "url" : "http:\/\/t.co\/GETtXm5I",
      "expanded_url" : "http:\/\/twitpic.com\/87r4fh",
      "display_url" : "twitpic.com\/87r4fh"
    } ]
  },
  "geo" : { },
  "id_str" : "158691366946353152",
  "text" : "RT @PennyRed: Somebody give that Guardian picture editor a great big hug for me. http:\/\/t.co\/GETtXm5I #republican #lol #godsavethequeen",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "republican",
        "indices" : [ 88, 99 ]
      }, {
        "text" : "lol",
        "indices" : [ 100, 104 ]
      }, {
        "text" : "godsavethequeen",
        "indices" : [ 105, 121 ]
      } ],
      "urls" : [ {
        "indices" : [ 67, 87 ],
        "url" : "http:\/\/t.co\/GETtXm5I",
        "expanded_url" : "http:\/\/twitpic.com\/87r4fh",
        "display_url" : "twitpic.com\/87r4fh"
      } ]
    },
    "geo" : { },
    "id_str" : "158688713365397505",
    "text" : "Somebody give that Guardian picture editor a great big hug for me. http:\/\/t.co\/GETtXm5I #republican #lol #godsavethequeen",
    "id" : 158688713365397505,
    "created_at" : "2012-01-15 23:15:12 +0000",
    "user" : {
      "name" : "Laurie Penny",
      "screen_name" : "PennyRed",
      "protected" : false,
      "id_str" : "19530289",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/887966692877504512\/hrvuIg4n_normal.jpg",
      "id" : 19530289,
      "verified" : true
    }
  },
  "id" : 158691366946353152,
  "created_at" : "2012-01-15 23:25:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Henklein",
      "screen_name" : "snooze82",
      "indices" : [ 0, 9 ],
      "id_str" : "14094265",
      "id" : 14094265
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "158681424604577792",
  "geo" : { },
  "id_str" : "158681527998353408",
  "in_reply_to_user_id" : 14094265,
  "text" : "@snooze82 Ich weiss, am kommenden Wochenende sieht es besser aus mit der Zeit. :)",
  "id" : 158681527998353408,
  "in_reply_to_status_id" : 158681424604577792,
  "created_at" : "2012-01-15 22:46:39 +0000",
  "in_reply_to_screen_name" : "snooze82",
  "in_reply_to_user_id_str" : "14094265",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 54 ],
      "url" : "http:\/\/t.co\/HuXHG2jw",
      "expanded_url" : "http:\/\/j.mp\/wxyavd",
      "display_url" : "j.mp\/wxyavd"
    } ]
  },
  "geo" : { },
  "id_str" : "158680559462260736",
  "text" : "The cake is(n't) a lie after all: http:\/\/t.co\/HuXHG2jw",
  "id" : 158680559462260736,
  "created_at" : "2012-01-15 22:42:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jad Abumrad",
      "screen_name" : "JadAbumrad",
      "indices" : [ 3, 14 ],
      "id_str" : "135316691",
      "id" : 135316691
    }, {
      "name" : "Dan Ariely",
      "screen_name" : "danariely",
      "indices" : [ 119, 129 ],
      "id_str" : "17997789",
      "id" : 17997789
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 113 ],
      "url" : "http:\/\/t.co\/M4rkSvXr",
      "expanded_url" : "http:\/\/nyti.ms\/w4CV4y",
      "display_url" : "nyti.ms\/w4CV4y"
    } ]
  },
  "geo" : { },
  "id_str" : "158656614365274113",
  "text" : "RT @JadAbumrad: The psychology behind Starbucks raising the price of a large coffee to $2.01 http:\/\/t.co\/M4rkSvXr (via @danariely)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twuffer.com\" rel=\"nofollow\"\u003ETwuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Dan Ariely",
        "screen_name" : "danariely",
        "indices" : [ 103, 113 ],
        "id_str" : "17997789",
        "id" : 17997789
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 77, 97 ],
        "url" : "http:\/\/t.co\/M4rkSvXr",
        "expanded_url" : "http:\/\/nyti.ms\/w4CV4y",
        "display_url" : "nyti.ms\/w4CV4y"
      } ]
    },
    "geo" : { },
    "id_str" : "158655378031255554",
    "text" : "The psychology behind Starbucks raising the price of a large coffee to $2.01 http:\/\/t.co\/M4rkSvXr (via @danariely)",
    "id" : 158655378031255554,
    "created_at" : "2012-01-15 21:02:44 +0000",
    "user" : {
      "name" : "Jad Abumrad",
      "screen_name" : "JadAbumrad",
      "protected" : false,
      "id_str" : "135316691",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1529014082\/Jad-Pic2_normal.jpg",
      "id" : 135316691,
      "verified" : true
    }
  },
  "id" : 158656614365274113,
  "created_at" : "2012-01-15 21:07:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "158614240859668480",
  "text" : "Jetzt erstmal Burrito-Reste-Essen und Arrested Development dabei schauen.",
  "id" : 158614240859668480,
  "created_at" : "2012-01-15 18:19:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/8daLKfHR",
      "expanded_url" : "http:\/\/j.mp\/yY8rrk",
      "display_url" : "j.mp\/yY8rrk"
    } ]
  },
  "geo" : { },
  "id_str" : "158594360986959872",
  "text" : "When Satire Becomes Reality http:\/\/t.co\/8daLKfHR",
  "id" : 158594360986959872,
  "created_at" : "2012-01-15 17:00:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rya",
      "screen_name" : "_Rya_",
      "indices" : [ 0, 6 ],
      "id_str" : "89234537",
      "id" : 89234537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "158591515340451840",
  "geo" : { },
  "id_str" : "158592247326183424",
  "in_reply_to_user_id" : 89234537,
  "text" : "@_Rya_ Komm mal in Jabber, dann sag ich dir die Antwort ;)",
  "id" : 158592247326183424,
  "in_reply_to_status_id" : 158591515340451840,
  "created_at" : "2012-01-15 16:51:52 +0000",
  "in_reply_to_screen_name" : "_Rya_",
  "in_reply_to_user_id_str" : "89234537",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "158566758842769408",
  "text" : "I finally got a chance to play Portal 2.",
  "id" : 158566758842769408,
  "created_at" : "2012-01-15 15:10:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DetritusBlog",
      "screen_name" : "gedankenabfall",
      "indices" : [ 0, 15 ],
      "id_str" : "2175883684",
      "id" : 2175883684
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "158509704627232768",
  "in_reply_to_user_id" : 29082973,
  "text" : "@gedankenabfall Der neue Roomba funktioniert. Der alte war wirklich ein Montagsger\u00E4t. :)",
  "id" : 158509704627232768,
  "created_at" : "2012-01-15 11:23:53 +0000",
  "in_reply_to_screen_name" : "ballaschk",
  "in_reply_to_user_id_str" : "29082973",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 72 ],
      "url" : "http:\/\/t.co\/46vXdafE",
      "expanded_url" : "http:\/\/instagr.am\/p\/hD5PR\/",
      "display_url" : "instagr.am\/p\/hD5PR\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0094076368, 8.2804512978 ]
  },
  "id_str" : "158212005835182080",
  "text" : "Sprayer  @ Br\u00FCckenkopf Kastel Graffiti Hall Of Fame http:\/\/t.co\/46vXdafE",
  "id" : 158212005835182080,
  "created_at" : "2012-01-14 15:40:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ralf ter Veer",
      "screen_name" : "terveer",
      "indices" : [ 0, 8 ],
      "id_str" : "51412887",
      "id" : 51412887
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "157920627829899265",
  "geo" : { },
  "id_str" : "157940160938524673",
  "in_reply_to_user_id" : 51412887,
  "text" : "@terveer Wenn bei mir der Wecker klingelt dann hab ich 15-20 Minuten um das Haus zu verlassen. ;)",
  "id" : 157940160938524673,
  "in_reply_to_status_id" : 157920627829899265,
  "created_at" : "2012-01-13 21:40:43 +0000",
  "in_reply_to_screen_name" : "terveer",
  "in_reply_to_user_id_str" : "51412887",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Martin ",
      "screen_name" : "jamarton",
      "indices" : [ 3, 12 ],
      "id_str" : "2925697173",
      "id" : 2925697173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "157908627972304896",
  "text" : "RT @JAMarton: found 5-yo hiding as she attempted to use a butter knife to unscrew a toy to see what made it talk. Handed her the appropr ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "157907147747893248",
    "text" : "found 5-yo hiding as she attempted to use a butter knife to unscrew a toy to see what made it talk. Handed her the appropriate Phillips head",
    "id" : 157907147747893248,
    "created_at" : "2012-01-13 19:29:32 +0000",
    "user" : {
      "name" : "Julie Mars",
      "screen_name" : "thereforeijam",
      "protected" : false,
      "id_str" : "35610962",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/897447205249978368\/t0OMh2L3_normal.jpg",
      "id" : 35610962,
      "verified" : false
    }
  },
  "id" : 157908627972304896,
  "created_at" : "2012-01-13 19:35:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ralf ter Veer",
      "screen_name" : "terveer",
      "indices" : [ 0, 8 ],
      "id_str" : "51412887",
      "id" : 51412887
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "157907860695695360",
  "geo" : { },
  "id_str" : "157908212945915906",
  "in_reply_to_user_id" : 51412887,
  "text" : "@terveer Das kann man sich aber auch nur erlauben, wenn man den Akku tags\u00FCber laden kann :(",
  "id" : 157908212945915906,
  "in_reply_to_status_id" : 157907860695695360,
  "created_at" : "2012-01-13 19:33:46 +0000",
  "in_reply_to_screen_name" : "terveer",
  "in_reply_to_user_id_str" : "51412887",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 95 ],
      "url" : "http:\/\/t.co\/3dmezh8k",
      "expanded_url" : "http:\/\/www.radiolab.org\/2012\/jan\/09\/",
      "display_url" : "radiolab.org\/2012\/jan\/09\/"
    } ]
  },
  "geo" : { },
  "id_str" : "157885244685553664",
  "text" : "The latest RadioLab-episode is awesome. Including the story of Fritz Haber http:\/\/t.co\/3dmezh8k",
  "id" : 157885244685553664,
  "created_at" : "2012-01-13 18:02:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rya",
      "screen_name" : "_Rya_",
      "indices" : [ 0, 6 ],
      "id_str" : "89234537",
      "id" : 89234537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "157876228559347712",
  "geo" : { },
  "id_str" : "157876434583556097",
  "in_reply_to_user_id" : 89234537,
  "text" : "@_Rya_ \u00AB[...] sondern an meinem Trampolin\u00BB gelesen und neidisch gewesen.",
  "id" : 157876434583556097,
  "in_reply_to_status_id" : 157876228559347712,
  "created_at" : "2012-01-13 17:27:29 +0000",
  "in_reply_to_screen_name" : "_Rya_",
  "in_reply_to_user_id_str" : "89234537",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexander Endl",
      "screen_name" : "zielpublikum",
      "indices" : [ 0, 13 ],
      "id_str" : "14711791",
      "id" : 14711791
    }, {
      "name" : "Peter Wenz",
      "screen_name" : "sparta644",
      "indices" : [ 14, 24 ],
      "id_str" : "17988190",
      "id" : 17988190
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "157861725721468928",
  "geo" : { },
  "id_str" : "157871361954562048",
  "in_reply_to_user_id" : 14711791,
  "text" : "@zielpublikum @sparta644 Cool, ich freu mich. :)",
  "id" : 157871361954562048,
  "in_reply_to_status_id" : 157861725721468928,
  "created_at" : "2012-01-13 17:07:20 +0000",
  "in_reply_to_screen_name" : "zielpublikum",
  "in_reply_to_user_id_str" : "14711791",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Priem",
      "screen_name" : "jasonpriem",
      "indices" : [ 3, 14 ],
      "id_str" : "15137538",
      "id" : 15137538
    }, {
      "name" : "brad plumer",
      "screen_name" : "bradplumer",
      "indices" : [ 19, 30 ],
      "id_str" : "15507433",
      "id" : 15507433
    }, {
      "name" : "Velterop \u24D0 \uD83C\uDDEA\uD83C\uDDFA\uD83D\uDD36",
      "screen_name" : "Villavelius",
      "indices" : [ 31, 43 ],
      "id_str" : "72249574",
      "id" : 72249574
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "157870128632041472",
  "text" : "RT @jasonpriem: RT @bradplumer @Villavelius : Each year, JSTOR turns away 150 million attempts to read its journal articles: http:\/\/t.co ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "brad plumer",
        "screen_name" : "bradplumer",
        "indices" : [ 3, 14 ],
        "id_str" : "15507433",
        "id" : 15507433
      }, {
        "name" : "Velterop \u24D0 \uD83C\uDDEA\uD83C\uDDFA\uD83D\uDD36",
        "screen_name" : "Villavelius",
        "indices" : [ 15, 27 ],
        "id_str" : "72249574",
        "id" : 72249574
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 109, 129 ],
        "url" : "http:\/\/t.co\/lLrylue4",
        "expanded_url" : "http:\/\/bit.ly\/zvWIPT",
        "display_url" : "bit.ly\/zvWIPT"
      } ]
    },
    "geo" : { },
    "id_str" : "157869644529676288",
    "text" : "RT @bradplumer @Villavelius : Each year, JSTOR turns away 150 million attempts to read its journal articles: http:\/\/t.co\/lLrylue4",
    "id" : 157869644529676288,
    "created_at" : "2012-01-13 17:00:30 +0000",
    "user" : {
      "name" : "Jason Priem",
      "screen_name" : "jasonpriem",
      "protected" : false,
      "id_str" : "15137538",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/820790537456226304\/Tis8dyhv_normal.jpg",
      "id" : 15137538,
      "verified" : false
    }
  },
  "id" : 157870128632041472,
  "created_at" : "2012-01-13 17:02:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexander Endl",
      "screen_name" : "zielpublikum",
      "indices" : [ 0, 13 ],
      "id_str" : "14711791",
      "id" : 14711791
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "157828455646494722",
  "geo" : { },
  "id_str" : "157845782702198784",
  "in_reply_to_user_id" : 14711791,
  "text" : "@zielpublikum ich mache mittlerweile meinen Master in Frankfurt und wohn in Mainz-Kastel. :)",
  "id" : 157845782702198784,
  "in_reply_to_status_id" : 157828455646494722,
  "created_at" : "2012-01-13 15:25:41 +0000",
  "in_reply_to_screen_name" : "zielpublikum",
  "in_reply_to_user_id_str" : "14711791",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexander Endl",
      "screen_name" : "zielpublikum",
      "indices" : [ 0, 13 ],
      "id_str" : "14711791",
      "id" : 14711791
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "157827833224368129",
  "geo" : { },
  "id_str" : "157828091643830272",
  "in_reply_to_user_id" : 14711791,
  "text" : "@zielpublikum dann sieht man sich ja mal wieder. Nachdem die letzte re:publica nicht geklappt hat. :)",
  "id" : 157828091643830272,
  "in_reply_to_status_id" : 157827833224368129,
  "created_at" : "2012-01-13 14:15:24 +0000",
  "in_reply_to_screen_name" : "zielpublikum",
  "in_reply_to_user_id_str" : "14711791",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexander Endl",
      "screen_name" : "zielpublikum",
      "indices" : [ 0, 13 ],
      "id_str" : "14711791",
      "id" : 14711791
    }, {
      "name" : "Peter Wenz",
      "screen_name" : "sparta644",
      "indices" : [ 87, 97 ],
      "id_str" : "17988190",
      "id" : 17988190
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "157827089763024898",
  "geo" : { },
  "id_str" : "157827684427235330",
  "in_reply_to_user_id" : 14711791,
  "text" : "@zielpublikum du kannst ja mal auf einem Stammtisch in H\u00F6chst vorbeikommen. Da ist der @sparta644 noch \u00E4lter ;)",
  "id" : 157827684427235330,
  "in_reply_to_status_id" : 157827089763024898,
  "created_at" : "2012-01-13 14:13:46 +0000",
  "in_reply_to_screen_name" : "zielpublikum",
  "in_reply_to_user_id_str" : "14711791",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/7xEgTDcH",
      "expanded_url" : "http:\/\/j.mp\/A0EPxr",
      "display_url" : "j.mp\/A0EPxr"
    } ]
  },
  "geo" : { },
  "id_str" : "157823270715011072",
  "text" : "WTF: Google's Kenyan ripoff http:\/\/t.co\/7xEgTDcH",
  "id" : 157823270715011072,
  "created_at" : "2012-01-13 13:56:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 43 ],
      "url" : "http:\/\/t.co\/mtrbvRdw",
      "expanded_url" : "http:\/\/j.mp\/yZwUKf",
      "display_url" : "j.mp\/yZwUKf"
    } ]
  },
  "geo" : { },
  "id_str" : "157822780753199104",
  "text" : "Jewelry made from AK47 http:\/\/t.co\/mtrbvRdw",
  "id" : 157822780753199104,
  "created_at" : "2012-01-13 13:54:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bob O'Hara",
      "screen_name" : "BobOHara",
      "indices" : [ 0, 9 ],
      "id_str" : "19146944",
      "id" : 19146944
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "157808018619240448",
  "geo" : { },
  "id_str" : "157820767881539584",
  "in_reply_to_user_id" : 19146944,
  "text" : "@BobOHara that would be cool. :)",
  "id" : 157820767881539584,
  "in_reply_to_status_id" : 157808018619240448,
  "created_at" : "2012-01-13 13:46:17 +0000",
  "in_reply_to_screen_name" : "BobOHara",
  "in_reply_to_user_id_str" : "19146944",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bob O'Hara",
      "screen_name" : "BobOHara",
      "indices" : [ 0, 9 ],
      "id_str" : "19146944",
      "id" : 19146944
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "157804850090999808",
  "geo" : { },
  "id_str" : "157806301873840128",
  "in_reply_to_user_id" : 19146944,
  "text" : "@BobOHara oh and nice talk today. Will you do a blogpost about this? :)",
  "id" : 157806301873840128,
  "in_reply_to_status_id" : 157804850090999808,
  "created_at" : "2012-01-13 12:48:48 +0000",
  "in_reply_to_screen_name" : "BobOHara",
  "in_reply_to_user_id_str" : "19146944",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bob O'Hara",
      "screen_name" : "BobOHara",
      "indices" : [ 0, 9 ],
      "id_str" : "19146944",
      "id" : 19146944
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "157804850090999808",
  "geo" : { },
  "id_str" : "157806150606262273",
  "in_reply_to_user_id" : 19146944,
  "text" : "@BobOHara its across different individuals. So it might not be that practical? And: it's a course for students. ;)",
  "id" : 157806150606262273,
  "in_reply_to_status_id" : 157804850090999808,
  "created_at" : "2012-01-13 12:48:12 +0000",
  "in_reply_to_screen_name" : "BobOHara",
  "in_reply_to_user_id_str" : "19146944",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "157802464312164352",
  "text" : "One week and 450 PCRs later... Weekend",
  "id" : 157802464312164352,
  "created_at" : "2012-01-13 12:33:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.flipboard.com\" rel=\"nofollow\"\u003EFlipboard\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "New Scientist",
      "screen_name" : "newscientist",
      "indices" : [ 3, 16 ],
      "id_str" : "19658826",
      "id" : 19658826
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 90 ],
      "url" : "http:\/\/t.co\/IbCzQkjj",
      "expanded_url" : "http:\/\/bit.ly\/yTLxXq",
      "display_url" : "bit.ly\/yTLxXq"
    } ]
  },
  "geo" : { },
  "id_str" : "157595503926841344",
  "text" : "RT @newscientist: World's smallest vertebrate is **7.7 mm long** frog http:\/\/t.co\/IbCzQkjj",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 52, 72 ],
        "url" : "http:\/\/t.co\/IbCzQkjj",
        "expanded_url" : "http:\/\/bit.ly\/yTLxXq",
        "display_url" : "bit.ly\/yTLxXq"
      } ]
    },
    "geo" : { },
    "id_str" : "157224590941241344",
    "text" : "World's smallest vertebrate is **7.7 mm long** frog http:\/\/t.co\/IbCzQkjj",
    "id" : 157224590941241344,
    "created_at" : "2012-01-11 22:17:18 +0000",
    "user" : {
      "name" : "New Scientist",
      "screen_name" : "newscientist",
      "protected" : false,
      "id_str" : "19658826",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/843789564074496001\/m34mTHmg_normal.jpg",
      "id" : 19658826,
      "verified" : true
    }
  },
  "id" : 157595503926841344,
  "created_at" : "2012-01-12 22:51:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 84 ],
      "url" : "http:\/\/t.co\/RQYbyH9A",
      "expanded_url" : "http:\/\/j.mp\/zpwSdk",
      "display_url" : "j.mp\/zpwSdk"
    } ]
  },
  "geo" : { },
  "id_str" : "157590773003599873",
  "text" : "A Half-Century of Inspiration: An Interview with Hamilton Smith http:\/\/t.co\/RQYbyH9A",
  "id" : 157590773003599873,
  "created_at" : "2012-01-12 22:32:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rya",
      "screen_name" : "_Rya_",
      "indices" : [ 0, 6 ],
      "id_str" : "89234537",
      "id" : 89234537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "157590196597170178",
  "geo" : { },
  "id_str" : "157590415015555072",
  "in_reply_to_user_id" : 89234537,
  "text" : "@_Rya_ der Name des Vertriebs ist oberpeinlich. Daf\u00FCr schmeckt das Ding besser als das Original das es kopiert.",
  "id" : 157590415015555072,
  "in_reply_to_status_id" : 157590196597170178,
  "created_at" : "2012-01-12 22:30:57 +0000",
  "in_reply_to_screen_name" : "_Rya_",
  "in_reply_to_user_id_str" : "89234537",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "157589996507893761",
  "text" : "\u00AB[..] Produkt wird in einem Betrieb erzeugt in dem auch Milch, Eier, Weizen & N\u00FCsse verarbeitet\u00BB Wie passt das zum \u00ABAbsolute Vegan Empire\u00BB?",
  "id" : 157589996507893761,
  "created_at" : "2012-01-12 22:29:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rachel Sklar \u2744\uFE0F",
      "screen_name" : "rachelsklar",
      "indices" : [ 3, 15 ],
      "id_str" : "12193342",
      "id" : 12193342
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "157588874938417152",
  "text" : "RT @rachelsklar: Can someone do a \"Shit Girls Annoyed By The Shit Girls Say Meme Say\" video? It's about that time.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "157587624415072258",
    "text" : "Can someone do a \"Shit Girls Annoyed By The Shit Girls Say Meme Say\" video? It's about that time.",
    "id" : 157587624415072258,
    "created_at" : "2012-01-12 22:19:52 +0000",
    "user" : {
      "name" : "Rachel Sklar \u2744\uFE0F",
      "screen_name" : "rachelsklar",
      "protected" : false,
      "id_str" : "12193342",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/465994828417753088\/yr3lkEoU_normal.png",
      "id" : 12193342,
      "verified" : true
    }
  },
  "id" : 157588874938417152,
  "created_at" : "2012-01-12 22:24:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "157588748123635712",
  "text" : "Der vegane Snickers-Verschnitt ist echt verdammt gut. Nur das \"nothing artifical\" auf der Verpackung... Nat\u00FCrlich vom Nussriegelbaum...",
  "id" : 157588748123635712,
  "created_at" : "2012-01-12 22:24:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mem_somerville",
      "screen_name" : "mem_somerville",
      "indices" : [ 3, 18 ],
      "id_str" : "15201021",
      "id" : 15201021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "157584284050407424",
  "text" : "RT @mem_somerville: Have found way to get more public interest in plant genomics: Medicinal Genomics launches medical marijuana app http ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 112, 132 ],
        "url" : "http:\/\/t.co\/g6oXsDI7",
        "expanded_url" : "http:\/\/bit.ly\/wWVBy0",
        "display_url" : "bit.ly\/wWVBy0"
      } ]
    },
    "geo" : { },
    "id_str" : "157583074731896832",
    "text" : "Have found way to get more public interest in plant genomics: Medicinal Genomics launches medical marijuana app http:\/\/t.co\/g6oXsDI7",
    "id" : 157583074731896832,
    "created_at" : "2012-01-12 22:01:47 +0000",
    "user" : {
      "name" : "mem_somerville",
      "screen_name" : "mem_somerville",
      "protected" : false,
      "id_str" : "15201021",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/929049262591115264\/ZIPrsQlr_normal.jpg",
      "id" : 15201021,
      "verified" : false
    }
  },
  "id" : 157584284050407424,
  "created_at" : "2012-01-12 22:06:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 87 ],
      "url" : "http:\/\/t.co\/kgPzKWKA",
      "expanded_url" : "http:\/\/j.mp\/x5DFAM",
      "display_url" : "j.mp\/x5DFAM"
    } ]
  },
  "geo" : { },
  "id_str" : "157545963882422272",
  "text" : "Anti-GM groups attempt to sully transgenic control of dengue fever http:\/\/t.co\/kgPzKWKA",
  "id" : 157545963882422272,
  "created_at" : "2012-01-12 19:34:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "157537743134666753",
  "text" : "\u00DCberall gehen die Sicherungen wieder rein. Ausser da wo der Router steht...",
  "id" : 157537743134666753,
  "created_at" : "2012-01-12 19:01:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    }, {
      "name" : "fidhy",
      "screen_name" : "dhyfe",
      "indices" : [ 10, 16 ],
      "id_str" : "20421364",
      "id" : 20421364
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "157487782816788483",
  "geo" : { },
  "id_str" : "157488064367824896",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon @Dhyfe dann k\u00F6nnen wir ja akut froh sein kein B\u00E4llebad zu haben :(",
  "id" : 157488064367824896,
  "in_reply_to_status_id" : 157487782816788483,
  "created_at" : "2012-01-12 15:44:15 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    }, {
      "name" : "fidhy",
      "screen_name" : "dhyfe",
      "indices" : [ 10, 16 ],
      "id_str" : "20421364",
      "id" : 20421364
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "157487511214632961",
  "geo" : { },
  "id_str" : "157487650079645696",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon @Dhyfe jetzt darf ich ein Schnabeltier halten?!",
  "id" : 157487650079645696,
  "in_reply_to_status_id" : 157487511214632961,
  "created_at" : "2012-01-12 15:42:36 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Horak",
      "screen_name" : "fatmike182",
      "indices" : [ 0, 11 ],
      "id_str" : "15271509",
      "id" : 15271509
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "157412262917844992",
  "geo" : { },
  "id_str" : "157412877630836738",
  "in_reply_to_user_id" : 15271509,
  "text" : "@fatmike182 aber ich Mail die mal an. Ich hab auch schon mit klinischen Humangenetikern Kontakt aufgenommen die interessiert sind.",
  "id" : 157412877630836738,
  "in_reply_to_status_id" : 157412262917844992,
  "created_at" : "2012-01-12 10:45:29 +0000",
  "in_reply_to_screen_name" : "fatmike182",
  "in_reply_to_user_id_str" : "15271509",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Horak",
      "screen_name" : "fatmike182",
      "indices" : [ 0, 11 ],
      "id_str" : "15271509",
      "id" : 15271509
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "157412262917844992",
  "geo" : { },
  "id_str" : "157412726317125632",
  "in_reply_to_user_id" : 15271509,
  "text" : "@fatmike182 hatte gerade nur zeit um den ersten Post von ihnen zu lesen. Scheint in der Tat noch sehr offen was genau sie machen wollen.",
  "id" : 157412726317125632,
  "in_reply_to_status_id" : 157412262917844992,
  "created_at" : "2012-01-12 10:44:53 +0000",
  "in_reply_to_screen_name" : "fatmike182",
  "in_reply_to_user_id_str" : "15271509",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Horak",
      "screen_name" : "fatmike182",
      "indices" : [ 0, 11 ],
      "id_str" : "15271509",
      "id" : 15271509
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "157409961058631682",
  "geo" : { },
  "id_str" : "157412020151529472",
  "in_reply_to_user_id" : 15271509,
  "text" : "@fatmike182 danke, das kannte ich in der Tat noch nicht. Schau ich mir heut Abend mal in Ruhe an. :)",
  "id" : 157412020151529472,
  "in_reply_to_status_id" : 157409961058631682,
  "created_at" : "2012-01-12 10:42:04 +0000",
  "in_reply_to_screen_name" : "fatmike182",
  "in_reply_to_user_id_str" : "15271509",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scytale",
      "screen_name" : "Scytale",
      "indices" : [ 0, 8 ],
      "id_str" : "621716753",
      "id" : 621716753
    }, {
      "name" : "J\u00FCrgen Geuter",
      "screen_name" : "tante",
      "indices" : [ 9, 15 ],
      "id_str" : "14179278",
      "id" : 14179278
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "157360941888045057",
  "geo" : { },
  "id_str" : "157362909092122626",
  "in_reply_to_user_id" : 8308632,
  "text" : "@Scytale @tante fr\u00FChaufsteherkritische Verschlaferia.",
  "id" : 157362909092122626,
  "in_reply_to_status_id" : 157360941888045057,
  "created_at" : "2012-01-12 07:26:55 +0000",
  "in_reply_to_screen_name" : "scy",
  "in_reply_to_user_id_str" : "8308632",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "J\u00FCrgen Geuter",
      "screen_name" : "tante",
      "indices" : [ 0, 6 ],
      "id_str" : "14179278",
      "id" : 14179278
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "157358271999651840",
  "geo" : { },
  "id_str" : "157360688547905537",
  "in_reply_to_user_id" : 14179278,
  "text" : "@tante dito!",
  "id" : 157360688547905537,
  "in_reply_to_status_id" : 157358271999651840,
  "created_at" : "2012-01-12 07:18:06 +0000",
  "in_reply_to_screen_name" : "tante",
  "in_reply_to_user_id_str" : "14179278",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ian Mulvany",
      "screen_name" : "IanMulvany",
      "indices" : [ 3, 14 ],
      "id_str" : "4339911",
      "id" : 4339911
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 63 ],
      "url" : "http:\/\/t.co\/w00XnvPh",
      "expanded_url" : "http:\/\/stackoverflow.com\/questions\/101268\/hidden-features-of-python#102202",
      "display_url" : "stackoverflow.com\/questions\/1012\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "157244721314529280",
  "text" : "RT @IanMulvany: hidden features of python: http:\/\/t.co\/w00XnvPh, I'm charmed by named formatting.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 27, 47 ],
        "url" : "http:\/\/t.co\/w00XnvPh",
        "expanded_url" : "http:\/\/stackoverflow.com\/questions\/101268\/hidden-features-of-python#102202",
        "display_url" : "stackoverflow.com\/questions\/1012\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "157238755051311104",
    "text" : "hidden features of python: http:\/\/t.co\/w00XnvPh, I'm charmed by named formatting.",
    "id" : 157238755051311104,
    "created_at" : "2012-01-11 23:13:35 +0000",
    "user" : {
      "name" : "Ian Mulvany",
      "screen_name" : "IanMulvany",
      "protected" : false,
      "id_str" : "4339911",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/605109727404638208\/p6BLA4Ub_normal.jpg",
      "id" : 4339911,
      "verified" : false
    }
  },
  "id" : 157244721314529280,
  "created_at" : "2012-01-11 23:37:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 86 ],
      "url" : "http:\/\/t.co\/OG6KeTA8",
      "expanded_url" : "http:\/\/feeds.nature.com\/~r\/news\/rss\/the_great_beyond\/~3\/qASuQZqEv7A\/has-prostate-cancer-found-its-brca.html",
      "display_url" : "feeds.nature.com\/~r\/news\/rss\/th\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "157234004284813312",
  "text" : "Genetic testing for diseases: Has prostate cancer found its BRCA? http:\/\/t.co\/OG6KeTA8",
  "id" : 157234004284813312,
  "created_at" : "2012-01-11 22:54:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 106 ],
      "url" : "http:\/\/t.co\/eGrb2y3D",
      "expanded_url" : "http:\/\/j.mp\/ynRgB7",
      "display_url" : "j.mp\/ynRgB7"
    } ]
  },
  "geo" : { },
  "id_str" : "157233750495866881",
  "text" : "Torturer\u2019s Apprentice: \u00ABThe Inquisition is not a closed chapter. It is an open book.\u00BB http:\/\/t.co\/eGrb2y3D",
  "id" : 157233750495866881,
  "created_at" : "2012-01-11 22:53:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "li5a",
      "screen_name" : "li5a",
      "indices" : [ 0, 5 ],
      "id_str" : "11712822",
      "id" : 11712822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "157231661313044480",
  "geo" : { },
  "id_str" : "157231955153395712",
  "in_reply_to_user_id" : 11712822,
  "text" : "@li5a Do you have an ebook-copy of this?",
  "id" : 157231955153395712,
  "in_reply_to_status_id" : 157231661313044480,
  "created_at" : "2012-01-11 22:46:33 +0000",
  "in_reply_to_screen_name" : "li5a",
  "in_reply_to_user_id_str" : "11712822",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 91 ],
      "url" : "http:\/\/t.co\/9CQg8q24",
      "expanded_url" : "http:\/\/instagr.am\/p\/gUSBr\/",
      "display_url" : "instagr.am\/p\/gUSBr\/"
    } ]
  },
  "geo" : { },
  "id_str" : "157231814434504705",
  "text" : "Vergessen: Der Adventskalender an dem nur ein T\u00FCrchen ge\u00F6ffnet wurde.  http:\/\/t.co\/9CQg8q24",
  "id" : 157231814434504705,
  "created_at" : "2012-01-11 22:46:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 56 ],
      "url" : "http:\/\/t.co\/eN12eUeK",
      "expanded_url" : "http:\/\/j.mp\/wqcLY9",
      "display_url" : "j.mp\/wqcLY9"
    } ]
  },
  "geo" : { },
  "id_str" : "157220271282077697",
  "text" : "TARDIS purse. Bigger on the inside! http:\/\/t.co\/eN12eUeK",
  "id" : 157220271282077697,
  "created_at" : "2012-01-11 22:00:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Brechler",
      "screen_name" : "plaetzchen",
      "indices" : [ 0, 11 ],
      "id_str" : "14305613",
      "id" : 14305613
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 73 ],
      "url" : "https:\/\/t.co\/8DQWdkXN",
      "expanded_url" : "https:\/\/bugs.launchpad.net\/ubuntu\/+source\/cups\/+bug\/465916",
      "display_url" : "bugs.launchpad.net\/ubuntu\/+source\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "157188011308752897",
  "geo" : { },
  "id_str" : "157218340283219969",
  "in_reply_to_user_id" : 14305613,
  "text" : "@plaetzchen Fehler gefunden, liegt nicht bei mir... https:\/\/t.co\/8DQWdkXN",
  "id" : 157218340283219969,
  "in_reply_to_status_id" : 157188011308752897,
  "created_at" : "2012-01-11 21:52:27 +0000",
  "in_reply_to_screen_name" : "plaetzchen",
  "in_reply_to_user_id_str" : "14305613",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Brechler",
      "screen_name" : "plaetzchen",
      "indices" : [ 0, 11 ],
      "id_str" : "14305613",
      "id" : 14305613
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "157187030755971073",
  "geo" : { },
  "id_str" : "157187864290004992",
  "in_reply_to_user_id" : 14305613,
  "text" : "@plaetzchen Was muss ich denn bei avahi einstellen? :D",
  "id" : 157187864290004992,
  "in_reply_to_status_id" : 157187030755971073,
  "created_at" : "2012-01-11 19:51:21 +0000",
  "in_reply_to_screen_name" : "plaetzchen",
  "in_reply_to_user_id_str" : "14305613",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Brechler",
      "screen_name" : "plaetzchen",
      "indices" : [ 0, 11 ],
      "id_str" : "14305613",
      "id" : 14305613
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "157186805265997824",
  "geo" : { },
  "id_str" : "157186947973001216",
  "in_reply_to_user_id" : 14305613,
  "text" : "@plaetzchen Ist installiert, aber eventuell falsch konfiguriert :D",
  "id" : 157186947973001216,
  "in_reply_to_status_id" : 157186805265997824,
  "created_at" : "2012-01-11 19:47:43 +0000",
  "in_reply_to_screen_name" : "plaetzchen",
  "in_reply_to_user_id_str" : "14305613",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chai Guy",
      "screen_name" : "yaccin",
      "indices" : [ 0, 7 ],
      "id_str" : "23505101",
      "id" : 23505101
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "157186480777863168",
  "geo" : { },
  "id_str" : "157186899721719808",
  "in_reply_to_user_id" : 23505101,
  "text" : "@yaccin Kombination von Gr\u00FCnden: a) Maschine l\u00E4uft weil Homeserver b) Will ich die Scan-Einheit des Druckers \u00FCber ssh\/gscan2pdf nutzen",
  "id" : 157186899721719808,
  "in_reply_to_status_id" : 157186480777863168,
  "created_at" : "2012-01-11 19:47:31 +0000",
  "in_reply_to_screen_name" : "yaccin",
  "in_reply_to_user_id_str" : "23505101",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Brechler",
      "screen_name" : "plaetzchen",
      "indices" : [ 0, 11 ],
      "id_str" : "14305613",
      "id" : 14305613
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "157186480417153024",
  "geo" : { },
  "id_str" : "157186626316017665",
  "in_reply_to_user_id" : 14305613,
  "text" : "@plaetzchen Versucht, er weigert sich dann den Drucker zu verwenden -&gt; Printer not found\/stopped",
  "id" : 157186626316017665,
  "in_reply_to_status_id" : 157186480417153024,
  "created_at" : "2012-01-11 19:46:26 +0000",
  "in_reply_to_screen_name" : "plaetzchen",
  "in_reply_to_user_id_str" : "14305613",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Brechler",
      "screen_name" : "plaetzchen",
      "indices" : [ 0, 11 ],
      "id_str" : "14305613",
      "id" : 14305613
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "157185996688076800",
  "geo" : { },
  "id_str" : "157186331796193282",
  "in_reply_to_user_id" : 14305613,
  "text" : "@plaetzchen Mac OS weigert sich ohne den Fix den Drucker zu finden der an einer Ubuntu-Box via cups freigegeben ist.",
  "id" : 157186331796193282,
  "in_reply_to_status_id" : 157185996688076800,
  "created_at" : "2012-01-11 19:45:16 +0000",
  "in_reply_to_screen_name" : "plaetzchen",
  "in_reply_to_user_id_str" : "14305613",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 88 ],
      "url" : "http:\/\/t.co\/2bsLZsJO",
      "expanded_url" : "http:\/\/www.trollop.org\/2007\/10\/31\/linux-printer-sharing-with-mac-os-x-105-leopard\/",
      "display_url" : "trollop.org\/2007\/10\/31\/lin\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "157179566933278721",
  "text" : "Still need to perform this workaround to find my network-printer... http:\/\/t.co\/2bsLZsJO",
  "id" : 157179566933278721,
  "created_at" : "2012-01-11 19:18:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 3, 12 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "followerpower",
      "indices" : [ 80, 94 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "157157505024262144",
  "text" : "RT @Senficon: Was f\u00FCr ein Linux w\u00FCrdet Ihr denn auf einem MacBook installieren? #followerpower",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "followerpower",
        "indices" : [ 66, 80 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "157155826967134209",
    "text" : "Was f\u00FCr ein Linux w\u00FCrdet Ihr denn auf einem MacBook installieren? #followerpower",
    "id" : 157155826967134209,
    "created_at" : "2012-01-11 17:44:03 +0000",
    "user" : {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "protected" : false,
      "id_str" : "14861745",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/637016870638350336\/QrtPmoul_normal.jpg",
      "id" : 14861745,
      "verified" : true
    }
  },
  "id" : 157157505024262144,
  "created_at" : "2012-01-11 17:50:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rya",
      "screen_name" : "_Rya_",
      "indices" : [ 0, 6 ],
      "id_str" : "89234537",
      "id" : 89234537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "157153929170395137",
  "geo" : { },
  "id_str" : "157154200055324672",
  "in_reply_to_user_id" : 89234537,
  "text" : "@_Rya_ hatte ich, aber das wurde wohl von Twitter abgeschnitten beim Crosspost von Instagram weil zu lang.",
  "id" : 157154200055324672,
  "in_reply_to_status_id" : 157153929170395137,
  "created_at" : "2012-01-11 17:37:35 +0000",
  "in_reply_to_screen_name" : "_Rya_",
  "in_reply_to_user_id_str" : "89234537",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Brechler",
      "screen_name" : "plaetzchen",
      "indices" : [ 0, 11 ],
      "id_str" : "14305613",
      "id" : 14305613
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "157146613763149824",
  "geo" : { },
  "id_str" : "157146865064886273",
  "in_reply_to_user_id" : 14305613,
  "text" : "@plaetzchen ne, gar nicht. Musste heute einen Seminarvortrag geben.",
  "id" : 157146865064886273,
  "in_reply_to_status_id" : 157146613763149824,
  "created_at" : "2012-01-11 17:08:26 +0000",
  "in_reply_to_screen_name" : "plaetzchen",
  "in_reply_to_user_id_str" : "14305613",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Brechler",
      "screen_name" : "plaetzchen",
      "indices" : [ 0, 11 ],
      "id_str" : "14305613",
      "id" : 14305613
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "157145416754929664",
  "geo" : { },
  "id_str" : "157146533911994370",
  "in_reply_to_user_id" : 14305613,
  "text" : "@plaetzchen danke. H\u00E4ttest mich gestern aber sowieso nicht wirklich telefonisch erreichen k\u00F6nnen weil im Lab.",
  "id" : 157146533911994370,
  "in_reply_to_status_id" : 157145416754929664,
  "created_at" : "2012-01-11 17:07:07 +0000",
  "in_reply_to_screen_name" : "plaetzchen",
  "in_reply_to_user_id_str" : "14305613",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "marni",
      "screen_name" : "_rya",
      "indices" : [ 80, 85 ],
      "id_str" : "97821574",
      "id" : 97821574
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 134 ],
      "url" : "http:\/\/t.co\/fZSLFyUe",
      "expanded_url" : "http:\/\/instagr.am\/p\/gP_pd\/",
      "display_url" : "instagr.am\/p\/gP_pd\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0059405631, 8.2865283783 ]
  },
  "id_str" : "157143243857993728",
  "text" : "Eine der tollsten Frauen wo gibt hat mir ein Geburtstagsgeschenk gemacht. Danke @_Rya  @ Andere Nennen Es Zuhause http:\/\/t.co\/fZSLFyUe",
  "id" : 157143243857993728,
  "created_at" : "2012-01-11 16:54:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/kindle.amazon.com\" rel=\"nofollow\"\u003EKindle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Kindle",
      "indices" : [ 62, 69 ]
    }, {
      "text" : "iPad",
      "indices" : [ 70, 75 ]
    } ],
    "urls" : [ {
      "indices" : [ 41, 61 ],
      "url" : "http:\/\/t.co\/xUtUHBD6",
      "expanded_url" : "http:\/\/amzn.com\/k\/3JQIBXM246E6N",
      "display_url" : "amzn.com\/k\/3JQIBXM246E6N"
    } ]
  },
  "geo" : { },
  "id_str" : "157137921252655104",
  "text" : "Love thy neighbor. That's how it's done! http:\/\/t.co\/xUtUHBD6 #Kindle #iPad",
  "id" : 157137921252655104,
  "created_at" : "2012-01-11 16:32:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 71 ],
      "url" : "http:\/\/t.co\/8ZLG3vJD",
      "expanded_url" : "http:\/\/j.mp\/AkpWPk",
      "display_url" : "j.mp\/AkpWPk"
    } ]
  },
  "geo" : { },
  "id_str" : "157127845641064449",
  "text" : "Vintage Punk Flyers redesigned in Swiss Typography http:\/\/t.co\/8ZLG3vJD",
  "id" : 157127845641064449,
  "created_at" : "2012-01-11 15:52:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 57 ],
      "url" : "http:\/\/t.co\/UVFEirtJ",
      "expanded_url" : "http:\/\/j.mp\/xsQuge",
      "display_url" : "j.mp\/xsQuge"
    } ]
  },
  "geo" : { },
  "id_str" : "156999606394294272",
  "text" : "The $1,000 genome: are we there yet? http:\/\/t.co\/UVFEirtJ",
  "id" : 156999606394294272,
  "created_at" : "2012-01-11 07:23:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 51 ],
      "url" : "http:\/\/t.co\/aGja6Paq",
      "expanded_url" : "http:\/\/j.mp\/xBZFjs",
      "display_url" : "j.mp\/xBZFjs"
    } ]
  },
  "geo" : { },
  "id_str" : "156998871279599616",
  "text" : "Any deadly viruses to declare? http:\/\/t.co\/aGja6Paq",
  "id" : 156998871279599616,
  "created_at" : "2012-01-11 07:20:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Ziegener",
      "screen_name" : "sofakissen",
      "indices" : [ 0, 11 ],
      "id_str" : "16084074",
      "id" : 16084074
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "156853234399580161",
  "geo" : { },
  "id_str" : "156854865098842113",
  "in_reply_to_user_id" : 16084074,
  "text" : "@sofakissen richtig. :P",
  "id" : 156854865098842113,
  "in_reply_to_status_id" : 156853234399580161,
  "created_at" : "2012-01-10 21:48:08 +0000",
  "in_reply_to_screen_name" : "sofakissen",
  "in_reply_to_user_id_str" : "16084074",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Ziegener",
      "screen_name" : "sofakissen",
      "indices" : [ 0, 11 ],
      "id_str" : "16084074",
      "id" : 16084074
    }, {
      "name" : "openSNP team",
      "screen_name" : "openSNPorg",
      "indices" : [ 42, 53 ],
      "id_str" : "380205172",
      "id" : 380205172
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "156852554200907776",
  "geo" : { },
  "id_str" : "156852855997861889",
  "in_reply_to_user_id" : 16084074,
  "text" : "@sofakissen Allerdings w\u00FCrden wir uns f\u00FCr @openSNPorg nat\u00FCrlich \u00FCber Rohdaten freuen :P",
  "id" : 156852855997861889,
  "in_reply_to_status_id" : 156852554200907776,
  "created_at" : "2012-01-10 21:40:09 +0000",
  "in_reply_to_screen_name" : "sofakissen",
  "in_reply_to_user_id_str" : "16084074",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Ziegener",
      "screen_name" : "sofakissen",
      "indices" : [ 0, 11 ],
      "id_str" : "16084074",
      "id" : 16084074
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "156852554200907776",
  "geo" : { },
  "id_str" : "156852781892907009",
  "in_reply_to_user_id" : 16084074,
  "text" : "@sofakissen Naja, ob du die Ancestry-Analyse mit Dritten teilen willst kannst du selbst aussuchen. Ist kein muss. ;)",
  "id" : 156852781892907009,
  "in_reply_to_status_id" : 156852554200907776,
  "created_at" : "2012-01-10 21:39:52 +0000",
  "in_reply_to_screen_name" : "sofakissen",
  "in_reply_to_user_id_str" : "16084074",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Ziegener",
      "screen_name" : "sofakissen",
      "indices" : [ 0, 11 ],
      "id_str" : "16084074",
      "id" : 16084074
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "156848196935630848",
  "geo" : { },
  "id_str" : "156850972138807298",
  "in_reply_to_user_id" : 16084074,
  "text" : "@sofakissen d) hab ich mir aber ehrlich gesagt noch nie wirklich angeschaut weil ich es langweilig finde :&gt;",
  "id" : 156850972138807298,
  "in_reply_to_status_id" : 156848196935630848,
  "created_at" : "2012-01-10 21:32:40 +0000",
  "in_reply_to_screen_name" : "sofakissen",
  "in_reply_to_user_id_str" : "16084074",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Ziegener",
      "screen_name" : "sofakissen",
      "indices" : [ 0, 11 ],
      "id_str" : "16084074",
      "id" : 16084074
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "156848196935630848",
  "geo" : { },
  "id_str" : "156850883588665344",
  "in_reply_to_user_id" : 16084074,
  "text" : "@sofakissen Oh, und d) Ancestry-Analyse: Woher kommen meine Vorfahren? Gibt es potentiell Nahverwandte Kunden in deren User-DB?",
  "id" : 156850883588665344,
  "in_reply_to_status_id" : 156848196935630848,
  "created_at" : "2012-01-10 21:32:19 +0000",
  "in_reply_to_screen_name" : "sofakissen",
  "in_reply_to_user_id_str" : "16084074",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "The_Smoking_GNU",
      "indices" : [ 0, 16 ],
      "id_str" : "14535787",
      "id" : 14535787
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "156846532912619520",
  "geo" : { },
  "id_str" : "156850604122177536",
  "in_reply_to_user_id" : 14535787,
  "text" : "@The_Smoking_GNU Ah, my bad. It looks like it works now (copying the Library removed this iTunes\/Mac from authorized). Thanks for help. :)",
  "id" : 156850604122177536,
  "in_reply_to_status_id" : 156846532912619520,
  "created_at" : "2012-01-10 21:31:12 +0000",
  "in_reply_to_screen_name" : "The_Smoking_GNU",
  "in_reply_to_user_id_str" : "14535787",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Ziegener",
      "screen_name" : "sofakissen",
      "indices" : [ 0, 11 ],
      "id_str" : "16084074",
      "id" : 16084074
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "156848196935630848",
  "geo" : { },
  "id_str" : "156848929684725761",
  "in_reply_to_user_id" : 16084074,
  "text" : "@sofakissen c) Pharmakogenomik: Wie wirken Medikamente\/Substanzen auf meinen Stoffwechsel. Vertrage ich Medikament X?",
  "id" : 156848929684725761,
  "in_reply_to_status_id" : 156848196935630848,
  "created_at" : "2012-01-10 21:24:33 +0000",
  "in_reply_to_screen_name" : "sofakissen",
  "in_reply_to_user_id_str" : "16084074",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Ziegener",
      "screen_name" : "sofakissen",
      "indices" : [ 0, 11 ],
      "id_str" : "16084074",
      "id" : 16084074
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "156848196935630848",
  "geo" : { },
  "id_str" : "156848776538099712",
  "in_reply_to_user_id" : 16084074,
  "text" : "@sofakissen Zum Teil aber auch f\u00FCr stark erh\u00F6hte Risiken (Brustkrebs, Alzheimer u.A.)",
  "id" : 156848776538099712,
  "in_reply_to_status_id" : 156848196935630848,
  "created_at" : "2012-01-10 21:23:57 +0000",
  "in_reply_to_screen_name" : "sofakissen",
  "in_reply_to_user_id_str" : "16084074",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Ziegener",
      "screen_name" : "sofakissen",
      "indices" : [ 0, 11 ],
      "id_str" : "16084074",
      "id" : 16084074
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "156848196935630848",
  "geo" : { },
  "id_str" : "156848662205575169",
  "in_reply_to_user_id" : 16084074,
  "text" : "@sofakissen b) Risiko-Absch\u00E4tzung f\u00FCr verschiedene Krankheiten. idr sind das kleine Risiko-Anstiege (1-2x gg\u00FC. Durchschnitt)",
  "id" : 156848662205575169,
  "in_reply_to_status_id" : 156848196935630848,
  "created_at" : "2012-01-10 21:23:29 +0000",
  "in_reply_to_screen_name" : "sofakissen",
  "in_reply_to_user_id_str" : "16084074",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Ziegener",
      "screen_name" : "sofakissen",
      "indices" : [ 0, 11 ],
      "id_str" : "16084074",
      "id" : 16084074
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "156848196935630848",
  "geo" : { },
  "id_str" : "156848446328942592",
  "in_reply_to_user_id" : 16084074,
  "text" : "@sofakissen a) Auswertung ob du (\u00DCber)Tr\u00E4ger von Erbkrankheiten bist (interessant falls irgendwann Nachwuchs ansteht)",
  "id" : 156848446328942592,
  "in_reply_to_status_id" : 156848196935630848,
  "created_at" : "2012-01-10 21:22:38 +0000",
  "in_reply_to_screen_name" : "sofakissen",
  "in_reply_to_user_id_str" : "16084074",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rya",
      "screen_name" : "_Rya_",
      "indices" : [ 0, 6 ],
      "id_str" : "89234537",
      "id" : 89234537
    }, {
      "name" : "Daniel Ziegener",
      "screen_name" : "sofakissen",
      "indices" : [ 7, 18 ],
      "id_str" : "16084074",
      "id" : 16084074
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "156847274268434432",
  "geo" : { },
  "id_str" : "156847872208416768",
  "in_reply_to_user_id" : 89234537,
  "text" : "@_Rya_ @sofakissen Um was genau geht es denn?",
  "id" : 156847872208416768,
  "in_reply_to_status_id" : 156847274268434432,
  "created_at" : "2012-01-10 21:20:21 +0000",
  "in_reply_to_screen_name" : "_Rya_",
  "in_reply_to_user_id_str" : "89234537",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "naturalismus",
      "screen_name" : "naturalismus",
      "indices" : [ 0, 13 ],
      "id_str" : "4562569648",
      "id" : 4562569648
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "156847051328589824",
  "geo" : { },
  "id_str" : "156847163958231041",
  "in_reply_to_user_id" : 77216385,
  "text" : "@Naturalismus damn, nat\u00FCrlich nicht :D",
  "id" : 156847163958231041,
  "in_reply_to_status_id" : 156847051328589824,
  "created_at" : "2012-01-10 21:17:32 +0000",
  "in_reply_to_screen_name" : "fireantprincess",
  "in_reply_to_user_id_str" : "77216385",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "naturalismus",
      "screen_name" : "naturalismus",
      "indices" : [ 0, 13 ],
      "id_str" : "4562569648",
      "id" : 4562569648
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "156842437157986304",
  "geo" : { },
  "id_str" : "156846911419203585",
  "in_reply_to_user_id" : 77216385,
  "text" : "@Naturalismus Mach ein animated GIF raus :D",
  "id" : 156846911419203585,
  "in_reply_to_status_id" : 156842437157986304,
  "created_at" : "2012-01-10 21:16:32 +0000",
  "in_reply_to_screen_name" : "fireantprincess",
  "in_reply_to_user_id_str" : "77216385",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "The_Smoking_GNU",
      "indices" : [ 0, 16 ],
      "id_str" : "14535787",
      "id" : 14535787
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "156846532912619520",
  "geo" : { },
  "id_str" : "156846701641089024",
  "in_reply_to_user_id" : 14535787,
  "text" : "@The_Smoking_GNU yes, and it recognized my backup :(",
  "id" : 156846701641089024,
  "in_reply_to_status_id" : 156846532912619520,
  "created_at" : "2012-01-10 21:15:42 +0000",
  "in_reply_to_screen_name" : "The_Smoking_GNU",
  "in_reply_to_user_id_str" : "14535787",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "naturalismus",
      "screen_name" : "naturalismus",
      "indices" : [ 51, 64 ],
      "id_str" : "4562569648",
      "id" : 4562569648
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 46 ],
      "url" : "http:\/\/t.co\/uB4Bmf1x",
      "expanded_url" : "http:\/\/j.mp\/yr9CBY",
      "display_url" : "j.mp\/yr9CBY"
    } ]
  },
  "geo" : { },
  "id_str" : "156845482541449217",
  "text" : "\"300\" with flying insects http:\/\/t.co\/uB4Bmf1x \/cc @Naturalismus",
  "id" : 156845482541449217,
  "created_at" : "2012-01-10 21:10:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "The_Smoking_GNU",
      "indices" : [ 0, 16 ],
      "id_str" : "14535787",
      "id" : 14535787
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "156816505684766722",
  "geo" : { },
  "id_str" : "156834098965512194",
  "in_reply_to_user_id" : 14535787,
  "text" : "@The_Smoking_GNU Nope, doesn't work. Still says that this Mac wouldn't be allowed to sync. Maybe I'll just don't sync apps at all.",
  "id" : 156834098965512194,
  "in_reply_to_status_id" : 156816505684766722,
  "created_at" : "2012-01-10 20:25:37 +0000",
  "in_reply_to_screen_name" : "The_Smoking_GNU",
  "in_reply_to_user_id_str" : "14535787",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "The_Smoking_GNU",
      "indices" : [ 0, 16 ],
      "id_str" : "14535787",
      "id" : 14535787
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "156816505684766722",
  "geo" : { },
  "id_str" : "156819306569674752",
  "in_reply_to_user_id" : 14535787,
  "text" : "@The_Smoking_GNU Thanks, I'll try this.",
  "id" : 156819306569674752,
  "in_reply_to_status_id" : 156816505684766722,
  "created_at" : "2012-01-10 19:26:50 +0000",
  "in_reply_to_screen_name" : "The_Smoking_GNU",
  "in_reply_to_user_id_str" : "14535787",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "156804742004219904",
  "text" : "But what is the best way to move the syncing of my iOS-devices from old iTunes to iTunes on the new machine?",
  "id" : 156804742004219904,
  "created_at" : "2012-01-10 18:28:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "156804563339460608",
  "text" : "Yeah, finished installing postgres, so my openSNP-development-environment is back up.",
  "id" : 156804563339460608,
  "created_at" : "2012-01-10 18:28:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kampfdenker (Marc)",
      "screen_name" : "Kampfdenker",
      "indices" : [ 0, 12 ],
      "id_str" : "67280656",
      "id" : 67280656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "156783881138339840",
  "geo" : { },
  "id_str" : "156784938979561472",
  "in_reply_to_user_id" : 67280656,
  "text" : "@Kampfdenker gibt ein paar Versuche in die Richtung. Aber ist bei der Softwarelandschaft ein Kampf gegen Windm\u00FChlen.",
  "id" : 156784938979561472,
  "in_reply_to_status_id" : 156783881138339840,
  "created_at" : "2012-01-10 17:10:17 +0000",
  "in_reply_to_screen_name" : "Kampfdenker",
  "in_reply_to_user_id_str" : "67280656",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kampfdenker (Marc)",
      "screen_name" : "Kampfdenker",
      "indices" : [ 0, 12 ],
      "id_str" : "67280656",
      "id" : 67280656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "156782301609594880",
  "geo" : { },
  "id_str" : "156782782822088704",
  "in_reply_to_user_id" : 67280656,
  "text" : "@Kampfdenker und die vielen, meist recht simplen Datenformate umparsen kann ;)",
  "id" : 156782782822088704,
  "in_reply_to_status_id" : 156782301609594880,
  "created_at" : "2012-01-10 17:01:42 +0000",
  "in_reply_to_screen_name" : "Kampfdenker",
  "in_reply_to_user_id_str" : "67280656",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kampfdenker (Marc)",
      "screen_name" : "Kampfdenker",
      "indices" : [ 0, 12 ],
      "id_str" : "67280656",
      "id" : 67280656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "156782301609594880",
  "geo" : { },
  "id_str" : "156782644980482049",
  "in_reply_to_user_id" : 67280656,
  "text" : "@Kampfdenker dank Next-Gen-Sequencing und den Datenmengen brauchen zumindest viele jemanden der Kommandozeilen-Tools bedienen kann.",
  "id" : 156782644980482049,
  "in_reply_to_status_id" : 156782301609594880,
  "created_at" : "2012-01-10 17:01:10 +0000",
  "in_reply_to_screen_name" : "Kampfdenker",
  "in_reply_to_user_id_str" : "67280656",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kampfdenker (Marc)",
      "screen_name" : "Kampfdenker",
      "indices" : [ 0, 12 ],
      "id_str" : "67280656",
      "id" : 67280656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "156781003157942272",
  "geo" : { },
  "id_str" : "156781525294268416",
  "in_reply_to_user_id" : 67280656,
  "text" : "@Kampfdenker such dir eine beliebige Arbeitsgruppe die molekularbiologisch arbeitet ;)",
  "id" : 156781525294268416,
  "in_reply_to_status_id" : 156781003157942272,
  "created_at" : "2012-01-10 16:56:43 +0000",
  "in_reply_to_screen_name" : "Kampfdenker",
  "in_reply_to_user_id_str" : "67280656",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Edward Teach",
      "screen_name" : "schwarzbart",
      "indices" : [ 0, 12 ],
      "id_str" : "17088945",
      "id" : 17088945
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "156780990717636608",
  "geo" : { },
  "id_str" : "156781272230932481",
  "in_reply_to_user_id" : 17088945,
  "text" : "@schwarzbart it wont get you rich for sure, but it offers plenty of opportunity ;)",
  "id" : 156781272230932481,
  "in_reply_to_status_id" : 156780990717636608,
  "created_at" : "2012-01-10 16:55:42 +0000",
  "in_reply_to_screen_name" : "schwarzbart",
  "in_reply_to_user_id_str" : "17088945",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "156780099256074240",
  "text" : "Have basic knowledge of sed & awk? Make a living as bioinformatician!",
  "id" : 156780099256074240,
  "created_at" : "2012-01-10 16:51:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Samantha Clark",
      "screen_name" : "iameltonjohn",
      "indices" : [ 0, 13 ],
      "id_str" : "1514567630",
      "id" : 1514567630
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "156757962386456576",
  "geo" : { },
  "id_str" : "156775476449394688",
  "in_reply_to_user_id" : 15661851,
  "text" : "@iameltonjohn It would be great if you could make it. Any vacation-plans yet? ;)",
  "id" : 156775476449394688,
  "in_reply_to_status_id" : 156757962386456576,
  "created_at" : "2012-01-10 16:32:40 +0000",
  "in_reply_to_screen_name" : "eltonjohn",
  "in_reply_to_user_id_str" : "15661851",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "156754659246215168",
  "text" : "Biologen die auf Gele starren.",
  "id" : 156754659246215168,
  "created_at" : "2012-01-10 15:09:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u00D0aniel Schwerd",
      "screen_name" : "netnrd",
      "indices" : [ 0, 7 ],
      "id_str" : "88916809",
      "id" : 88916809
    }, {
      "name" : "Johannes Rehborn",
      "screen_name" : "JRehborn",
      "indices" : [ 8, 17 ],
      "id_str" : "25483958",
      "id" : 25483958
    }, {
      "name" : "Kia",
      "screen_name" : "nad_no_ennas",
      "indices" : [ 18, 31 ],
      "id_str" : "1702539380",
      "id" : 1702539380
    }, {
      "name" : "Alexander Knoll",
      "screen_name" : "Argent23",
      "indices" : [ 32, 41 ],
      "id_str" : "22828618",
      "id" : 22828618
    }, {
      "name" : "Textheld",
      "screen_name" : "Textheld",
      "indices" : [ 42, 51 ],
      "id_str" : "58492545",
      "id" : 58492545
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "156682253169201152",
  "geo" : { },
  "id_str" : "156731669053837312",
  "in_reply_to_user_id" : 88916809,
  "text" : "@netnrd @JRehborn @nad_no_ennas @Argent23 @Textheld Danke :)",
  "id" : 156731669053837312,
  "in_reply_to_status_id" : 156682253169201152,
  "created_at" : "2012-01-10 13:38:36 +0000",
  "in_reply_to_screen_name" : "netnrd",
  "in_reply_to_user_id_str" : "88916809",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scytale",
      "screen_name" : "Scytale",
      "indices" : [ 0, 8 ],
      "id_str" : "621716753",
      "id" : 621716753
    }, {
      "name" : "Jonas",
      "screen_name" : "lsanoj",
      "indices" : [ 9, 16 ],
      "id_str" : "18918915",
      "id" : 18918915
    }, {
      "name" : "\u2716\uFE0F\u3030\u2716\uFE0F",
      "screen_name" : "MamsellChaos",
      "indices" : [ 17, 30 ],
      "id_str" : "140774041",
      "id" : 140774041
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "156667337502769152",
  "geo" : { },
  "id_str" : "156668737565622273",
  "in_reply_to_user_id" : 8308632,
  "text" : "@Scytale @lsanoj @MamsellChaos mit den Mittwittegeburtstagskindern kann ich mich irgendwie besser anfreunden ;)",
  "id" : 156668737565622273,
  "in_reply_to_status_id" : 156667337502769152,
  "created_at" : "2012-01-10 09:28:32 +0000",
  "in_reply_to_screen_name" : "scy",
  "in_reply_to_user_id_str" : "8308632",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "J\u00FCrgen Geuter",
      "screen_name" : "tante",
      "indices" : [ 0, 6 ],
      "id_str" : "14179278",
      "id" : 14179278
    }, {
      "name" : "Marc Henklein",
      "screen_name" : "snooze82",
      "indices" : [ 7, 16 ],
      "id_str" : "14094265",
      "id" : 14094265
    }, {
      "name" : "Cae Vye",
      "screen_name" : "CaeVye",
      "indices" : [ 17, 24 ],
      "id_str" : "31104704",
      "id" : 31104704
    }, {
      "name" : "Scytale",
      "screen_name" : "Scytale",
      "indices" : [ 25, 33 ],
      "id_str" : "621716753",
      "id" : 621716753
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "156668467431473152",
  "in_reply_to_user_id" : 14179278,
  "text" : "@tante @snooze82 @CaeVye @Scytale Danke :)",
  "id" : 156668467431473152,
  "created_at" : "2012-01-10 09:27:28 +0000",
  "in_reply_to_screen_name" : "tante",
  "in_reply_to_user_id_str" : "14179278",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "naturalismus",
      "screen_name" : "naturalismus",
      "indices" : [ 0, 13 ],
      "id_str" : "4562569648",
      "id" : 4562569648
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "156641060817354752",
  "geo" : { },
  "id_str" : "156642135041523712",
  "in_reply_to_user_id" : 77216385,
  "text" : "@Naturalismus die statischen Objekte in meinen Laufwegen kenne ich ja ;)",
  "id" : 156642135041523712,
  "in_reply_to_status_id" : 156641060817354752,
  "created_at" : "2012-01-10 07:42:49 +0000",
  "in_reply_to_screen_name" : "fireantprincess",
  "in_reply_to_user_id_str" : "77216385",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "156640586483515392",
  "text" : "Ich will NFC in meinem Mobilger\u00E4t damit es mich warnt bevor ich in andere Leute renne die auch nur auf ihr Display starren.",
  "id" : 156640586483515392,
  "created_at" : "2012-01-10 07:36:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "naturalismus",
      "screen_name" : "naturalismus",
      "indices" : [ 0, 13 ],
      "id_str" : "4562569648",
      "id" : 4562569648
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "156637607009325056",
  "geo" : { },
  "id_str" : "156638555467300864",
  "in_reply_to_user_id" : 77216385,
  "text" : "@Naturalismus was sich halt tolles in ~24 h im Reader sammelt ;)",
  "id" : 156638555467300864,
  "in_reply_to_status_id" : 156637607009325056,
  "created_at" : "2012-01-10 07:28:36 +0000",
  "in_reply_to_screen_name" : "fireantprincess",
  "in_reply_to_user_id_str" : "77216385",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "purrrlegon",
      "screen_name" : "pulegon",
      "indices" : [ 9, 17 ],
      "id_str" : "107502279",
      "id" : 107502279
    }, {
      "name" : "Torge Schmidt",
      "screen_name" : "Torgator",
      "indices" : [ 18, 27 ],
      "id_str" : "50943115",
      "id" : 50943115
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "156638169096392704",
  "text" : "@levudev @pulegon @Torgator Danke :)",
  "id" : 156638169096392704,
  "created_at" : "2012-01-10 07:27:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 55 ],
      "url" : "http:\/\/t.co\/oQDYBa65",
      "expanded_url" : "http:\/\/j.mp\/yNnkbX",
      "display_url" : "j.mp\/yNnkbX"
    } ]
  },
  "geo" : { },
  "id_str" : "156636863065632770",
  "text" : "How to make silica aerogel at home http:\/\/t.co\/oQDYBa65",
  "id" : 156636863065632770,
  "created_at" : "2012-01-10 07:21:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 115 ],
      "url" : "http:\/\/t.co\/ijULKfpf",
      "expanded_url" : "http:\/\/j.mp\/ADkoLx",
      "display_url" : "j.mp\/ADkoLx"
    } ]
  },
  "geo" : { },
  "id_str" : "156636024343248896",
  "text" : "Maybe I should reinstall Rocket Arena? Psychology says couples who play together stay together http:\/\/t.co\/ijULKfpf",
  "id" : 156636024343248896,
  "created_at" : "2012-01-10 07:18:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 88 ],
      "url" : "http:\/\/t.co\/0IJ1ZHXQ",
      "expanded_url" : "http:\/\/j.mp\/z5Uuvy",
      "display_url" : "j.mp\/z5Uuvy"
    } ]
  },
  "geo" : { },
  "id_str" : "156635135318573056",
  "text" : "Is Evolution of Blind Mole Rats Determined by Climate Oscillations? http:\/\/t.co\/0IJ1ZHXQ",
  "id" : 156635135318573056,
  "created_at" : "2012-01-10 07:15:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 139 ],
      "url" : "http:\/\/t.co\/abXCXPu1",
      "expanded_url" : "http:\/\/j.mp\/z7DUQy",
      "display_url" : "j.mp\/z7DUQy"
    } ]
  },
  "geo" : { },
  "id_str" : "156634451361792000",
  "text" : "\u201EAls g\u00E4be es keine Probleme mit [A]lgorithmen. Es sind nur nicht die, an denen sich Geisteswissenschaftler abarbeiten\u201C http:\/\/t.co\/abXCXPu1",
  "id" : 156634451361792000,
  "created_at" : "2012-01-10 07:12:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 63, 72 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 58 ],
      "url" : "http:\/\/t.co\/8q6KKfkE",
      "expanded_url" : "http:\/\/j.mp\/AfbvZy",
      "display_url" : "j.mp\/AfbvZy"
    } ]
  },
  "geo" : { },
  "id_str" : "156632441707171840",
  "text" : "Overnight holidays at a nuclear plant http:\/\/t.co\/8q6KKfkE \/cc @Senficon",
  "id" : 156632441707171840,
  "created_at" : "2012-01-10 07:04:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ennomane",
      "screen_name" : "ennomane",
      "indices" : [ 4, 13 ],
      "id_str" : "850704103814705152",
      "id" : 850704103814705152
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 80 ],
      "url" : "http:\/\/t.co\/a5exzXsC",
      "expanded_url" : "http:\/\/www.ennomane.de\/2012\/01\/09\/prothetik-und-inklusion-sind-kein-gegensatz\/",
      "display_url" : "ennomane.de\/2012\/01\/09\/pro\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "156631982187618304",
  "text" : "Der @ennomane \u00FCber Cyborgs und retiring from the human race http:\/\/t.co\/a5exzXsC",
  "id" : 156631982187618304,
  "created_at" : "2012-01-10 07:02:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Wenz",
      "screen_name" : "sparta644",
      "indices" : [ 0, 10 ],
      "id_str" : "17988190",
      "id" : 17988190
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "156629522039570432",
  "geo" : { },
  "id_str" : "156631716788842496",
  "in_reply_to_user_id" : 17988190,
  "text" : "@sparta644 danke!",
  "id" : 156631716788842496,
  "in_reply_to_status_id" : 156629522039570432,
  "created_at" : "2012-01-10 07:01:26 +0000",
  "in_reply_to_screen_name" : "sparta644",
  "in_reply_to_user_id_str" : "17988190",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/ugGegaIe",
      "expanded_url" : "http:\/\/j.mp\/zK7oN1",
      "display_url" : "j.mp\/zK7oN1"
    } ]
  },
  "geo" : { },
  "id_str" : "156631223115067392",
  "text" : "The best account on Twitter http:\/\/t.co\/ugGegaIe",
  "id" : 156631223115067392,
  "created_at" : "2012-01-10 06:59:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "naturalismus",
      "screen_name" : "naturalismus",
      "indices" : [ 0, 13 ],
      "id_str" : "4562569648",
      "id" : 4562569648
    }, {
      "name" : "\u2716\uFE0F\u3030\u2716\uFE0F",
      "screen_name" : "MamsellChaos",
      "indices" : [ 45, 58 ],
      "id_str" : "140774041",
      "id" : 140774041
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "156626287916613632",
  "geo" : { },
  "id_str" : "156627832183857152",
  "in_reply_to_user_id" : 77216385,
  "text" : "@Naturalismus danke und auch Gl\u00FCckw\u00FCnsche an @MamsellChaos :)",
  "id" : 156627832183857152,
  "in_reply_to_status_id" : 156626287916613632,
  "created_at" : "2012-01-10 06:45:59 +0000",
  "in_reply_to_screen_name" : "fireantprincess",
  "in_reply_to_user_id_str" : "77216385",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "156517380414115842",
  "text" : "Finished installing xcode, biopython, rvm & latest rails-versions. Now all I need is postgres and I'm up again.",
  "id" : 156517380414115842,
  "created_at" : "2012-01-09 23:27:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "156517052209831936",
  "geo" : { },
  "id_str" : "156517151409324034",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer k\u00F6nnen wir ja morgen oder so mal schauen. :)",
  "id" : 156517151409324034,
  "in_reply_to_status_id" : 156517052209831936,
  "created_at" : "2012-01-09 23:26:11 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "156516119925104641",
  "geo" : { },
  "id_str" : "156516812983513090",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer Oh, hast recht. Man wird umgeleitet beim login. my bad",
  "id" : 156516812983513090,
  "in_reply_to_status_id" : 156516119925104641,
  "created_at" : "2012-01-09 23:24:50 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mrgunn",
      "screen_name" : "mrgunn",
      "indices" : [ 0, 7 ],
      "id_str" : "15237935",
      "id" : 15237935
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "156511648453103616",
  "geo" : { },
  "id_str" : "156513383271772162",
  "in_reply_to_user_id" : 15237935,
  "text" : "@mrgunn oh, and it is kind of platform-independent as the rendering is the same on all devices incl. optimisation for print.",
  "id" : 156513383271772162,
  "in_reply_to_status_id" : 156511648453103616,
  "created_at" : "2012-01-09 23:11:13 +0000",
  "in_reply_to_screen_name" : "mrgunn",
  "in_reply_to_user_id_str" : "15237935",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mrgunn",
      "screen_name" : "mrgunn",
      "indices" : [ 0, 7 ],
      "id_str" : "15237935",
      "id" : 15237935
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "156511648453103616",
  "geo" : { },
  "id_str" : "156513156108271616",
  "in_reply_to_user_id" : 15237935,
  "text" : "@mrgunn plus: sharing a single file is\/feels easier, compared to complex HTML-docs with images etc.",
  "id" : 156513156108271616,
  "in_reply_to_status_id" : 156511648453103616,
  "created_at" : "2012-01-09 23:10:18 +0000",
  "in_reply_to_screen_name" : "mrgunn",
  "in_reply_to_user_id_str" : "15237935",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "156480999088340993",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer SSL geht irgendwie bei mir nicht mehr, bei dir?",
  "id" : 156480999088340993,
  "created_at" : "2012-01-09 21:02:32 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DetritusBlog",
      "screen_name" : "gedankenabfall",
      "indices" : [ 0, 15 ],
      "id_str" : "2175883684",
      "id" : 2175883684
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "156466966280937473",
  "geo" : { },
  "id_str" : "156467210909523968",
  "in_reply_to_user_id" : 29082973,
  "text" : "@gedankenabfall naja, montagsger\u00E4te gibts sicher \u00FCberall. :)",
  "id" : 156467210909523968,
  "in_reply_to_status_id" : 156466966280937473,
  "created_at" : "2012-01-09 20:07:44 +0000",
  "in_reply_to_screen_name" : "ballaschk",
  "in_reply_to_user_id_str" : "29082973",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DetritusBlog",
      "screen_name" : "gedankenabfall",
      "indices" : [ 0, 15 ],
      "id_str" : "2175883684",
      "id" : 2175883684
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "156466130238709760",
  "geo" : { },
  "id_str" : "156466754237894656",
  "in_reply_to_user_id" : 29082973,
  "text" : "@gedankenabfall Der Akku war defekt. Warte aufs Ersatzger\u00E4t.",
  "id" : 156466754237894656,
  "in_reply_to_status_id" : 156466130238709760,
  "created_at" : "2012-01-09 20:05:55 +0000",
  "in_reply_to_screen_name" : "ballaschk",
  "in_reply_to_user_id_str" : "29082973",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scytale",
      "screen_name" : "Scytale",
      "indices" : [ 0, 8 ],
      "id_str" : "621716753",
      "id" : 621716753
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "156463837162381312",
  "geo" : { },
  "id_str" : "156464403137568768",
  "in_reply_to_user_id" : 8308632,
  "text" : "@Scytale Bin schockiert. Du nutzt kein Caffeine?",
  "id" : 156464403137568768,
  "in_reply_to_status_id" : 156463837162381312,
  "created_at" : "2012-01-09 19:56:35 +0000",
  "in_reply_to_screen_name" : "scy",
  "in_reply_to_user_id_str" : "8308632",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "156438973647028225",
  "text" : "After switching to Lion: God, what have you done to iCal & the Address Book?!",
  "id" : 156438973647028225,
  "created_at" : "2012-01-09 18:15:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rin Raeuber",
      "screen_name" : "rinpaku",
      "indices" : [ 0, 8 ],
      "id_str" : "195489657",
      "id" : 195489657
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "156435051112972290",
  "geo" : { },
  "id_str" : "156436990479450112",
  "in_reply_to_user_id" : 8018382,
  "text" : "@rinpaku Oh wie \u00FCberniedlich!",
  "id" : 156436990479450112,
  "in_reply_to_status_id" : 156435051112972290,
  "created_at" : "2012-01-09 18:07:39 +0000",
  "in_reply_to_screen_name" : "rinrae",
  "in_reply_to_user_id_str" : "8018382",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twirssi.com\" rel=\"nofollow\"\u003ETwirssi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "156433146018144256",
  "text" : "Bash-Config-Zeugs erfolgreich migriert. Fehlen Adressbuch & Mails.",
  "id" : 156433146018144256,
  "created_at" : "2012-01-09 17:52:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scytale",
      "screen_name" : "Scytale",
      "indices" : [ 0, 8 ],
      "id_str" : "621716753",
      "id" : 621716753
    }, {
      "name" : "DetritusBlog",
      "screen_name" : "gedankenabfall",
      "indices" : [ 45, 60 ],
      "id_str" : "2175883684",
      "id" : 2175883684
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "156428357167349760",
  "geo" : { },
  "id_str" : "156430586582548480",
  "in_reply_to_user_id" : 8308632,
  "text" : "@Scytale Es gibt noch mehr @gedankenfoos Der @gedankenabfall hatte die mal aufgez\u00E4hlt glaube ich ;)",
  "id" : 156430586582548480,
  "in_reply_to_status_id" : 156428357167349760,
  "created_at" : "2012-01-09 17:42:12 +0000",
  "in_reply_to_screen_name" : "scy",
  "in_reply_to_user_id_str" : "8308632",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DetritusBlog",
      "screen_name" : "gedankenabfall",
      "indices" : [ 0, 15 ],
      "id_str" : "2175883684",
      "id" : 2175883684
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "156428047841624065",
  "geo" : { },
  "id_str" : "156428221397745664",
  "in_reply_to_user_id" : 29082973,
  "text" : "@gedankenabfall Ja, aber haupts\u00E4chlich wollte ich die gr\u00F6\u00DFere Aufl\u00F6sung haben. :)",
  "id" : 156428221397745664,
  "in_reply_to_status_id" : 156428047841624065,
  "created_at" : "2012-01-09 17:32:48 +0000",
  "in_reply_to_screen_name" : "ballaschk",
  "in_reply_to_user_id_str" : "29082973",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TheConstructor",
      "screen_name" : "TheConstructor",
      "indices" : [ 0, 15 ],
      "id_str" : "14362840",
      "id" : 14362840
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "156424638551965698",
  "geo" : { },
  "id_str" : "156425291756077056",
  "in_reply_to_user_id" : 14362840,
  "text" : "@TheConstructor Wobei ich hab schon vieles in der Cloud, das macht es einfacher.",
  "id" : 156425291756077056,
  "in_reply_to_status_id" : 156424638551965698,
  "created_at" : "2012-01-09 17:21:10 +0000",
  "in_reply_to_screen_name" : "TheConstructor",
  "in_reply_to_user_id_str" : "14362840",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TheConstructor",
      "screen_name" : "TheConstructor",
      "indices" : [ 0, 15 ],
      "id_str" : "14362840",
      "id" : 14362840
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "156423185657626624",
  "geo" : { },
  "id_str" : "156424483215904768",
  "in_reply_to_user_id" : 14362840,
  "text" : "@TheConstructor auf der einen Seite Super, weil man Altlasten los wird. Auf der anderen Seite: Mega viel Arbeit.",
  "id" : 156424483215904768,
  "in_reply_to_status_id" : 156423185657626624,
  "created_at" : "2012-01-09 17:17:57 +0000",
  "in_reply_to_screen_name" : "TheConstructor",
  "in_reply_to_user_id_str" : "14362840",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "156415884683001857",
  "text" : "Jetzt: Alles neu installieren anstatt den Migrationsassistenten zu verwenden.",
  "id" : 156415884683001857,
  "created_at" : "2012-01-09 16:43:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephan Urbach",
      "screen_name" : "herrurbach",
      "indices" : [ 0, 11 ],
      "id_str" : "28090494",
      "id" : 28090494
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "156396885043707906",
  "geo" : { },
  "id_str" : "156397013137752064",
  "in_reply_to_user_id" : 28090494,
  "text" : "@herrurbach yep, neues 15\" rechts-unten.",
  "id" : 156397013137752064,
  "in_reply_to_status_id" : 156396885043707906,
  "created_at" : "2012-01-09 15:28:48 +0000",
  "in_reply_to_screen_name" : "herrurbach",
  "in_reply_to_user_id_str" : "28090494",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 121 ],
      "url" : "http:\/\/t.co\/PyDK6Vm2",
      "expanded_url" : "http:\/\/instagr.am\/p\/fv5_5\/",
      "display_url" : "instagr.am\/p\/fv5_5\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0059405631, 8.2865283783 ]
  },
  "id_str" : "156396773835931648",
  "text" : "UPS hat die besten Boten. Auf Tipp des Nachbarn noch mal vorbeigekommen.  @ Andere Nennen Es Zuhause http:\/\/t.co\/PyDK6Vm2",
  "id" : 156396773835931648,
  "created_at" : "2012-01-09 15:27:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dorian Winter",
      "screen_name" : "dorianwinter",
      "indices" : [ 0, 13 ],
      "id_str" : "19884962",
      "id" : 19884962
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "156343267636690944",
  "geo" : { },
  "id_str" : "156343445240299520",
  "in_reply_to_user_id" : 19884962,
  "text" : "@dorianwinter Das stimmt. Aber A+ ist ja verbreitet (~30% in Europa, wenn ich mich recht erinnere). Seltsam das sogar das knapp scheint.",
  "id" : 156343445240299520,
  "in_reply_to_status_id" : 156343267636690944,
  "created_at" : "2012-01-09 11:55:56 +0000",
  "in_reply_to_screen_name" : "dorianwinter",
  "in_reply_to_user_id_str" : "19884962",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dorian Winter",
      "screen_name" : "dorianwinter",
      "indices" : [ 0, 13 ],
      "id_str" : "19884962",
      "id" : 19884962
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "156341193943433219",
  "geo" : { },
  "id_str" : "156341270128758785",
  "in_reply_to_user_id" : 19884962,
  "text" : "@dorianwinter Das ist ja Spender-kompatibel :)",
  "id" : 156341270128758785,
  "in_reply_to_status_id" : 156341193943433219,
  "created_at" : "2012-01-09 11:47:18 +0000",
  "in_reply_to_screen_name" : "dorianwinter",
  "in_reply_to_user_id_str" : "19884962",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Heldmaschine",
      "screen_name" : "Donnerbeutel",
      "indices" : [ 0, 13 ],
      "id_str" : "116280930",
      "id" : 116280930
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "156332908880199681",
  "geo" : { },
  "id_str" : "156333423370305536",
  "in_reply_to_user_id" : 116280930,
  "text" : "@Donnerbeutel oder einfach die Frageb\u00F6gen nicht korrekt beantworten. ;)",
  "id" : 156333423370305536,
  "in_reply_to_status_id" : 156332908880199681,
  "created_at" : "2012-01-09 11:16:07 +0000",
  "in_reply_to_screen_name" : "Donnerbeutel",
  "in_reply_to_user_id_str" : "116280930",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Terrorzicke",
      "screen_name" : "terrorzicke",
      "indices" : [ 0, 12 ],
      "id_str" : "14728378",
      "id" : 14728378
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "156332939590897664",
  "geo" : { },
  "id_str" : "156333116049457152",
  "in_reply_to_user_id" : 14728378,
  "text" : "@terrorzicke offensichtlich, zumindest werde ich von denen regelm\u00E4\u00DFig angerufen, dass sie mein Blut wollen.",
  "id" : 156333116049457152,
  "in_reply_to_status_id" : 156332939590897664,
  "created_at" : "2012-01-09 11:14:54 +0000",
  "in_reply_to_screen_name" : "terrorzicke",
  "in_reply_to_user_id_str" : "14728378",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "156332510782033921",
  "text" : "Wenn eure Blutgruppe A+ (oder Spender-kompatibel) ist, dann geht doch mal zur Spende am UK Mainz. Die suchen gerade dringend.",
  "id" : 156332510782033921,
  "created_at" : "2012-01-09 11:12:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Henklein",
      "screen_name" : "snooze82",
      "indices" : [ 0, 9 ],
      "id_str" : "14094265",
      "id" : 14094265
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "156318413818576896",
  "geo" : { },
  "id_str" : "156332289339564032",
  "in_reply_to_user_id" : 14094265,
  "text" : "@snooze82 mal sehen ob ich da bin. Meine Eltern besuchen mich an dem Wochenende so weit ich weiss.",
  "id" : 156332289339564032,
  "in_reply_to_status_id" : 156318413818576896,
  "created_at" : "2012-01-09 11:11:36 +0000",
  "in_reply_to_screen_name" : "snooze82",
  "in_reply_to_user_id_str" : "14094265",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twirssi.com\" rel=\"nofollow\"\u003ETwirssi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "156316396815532032",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer Do you have a second for jabber?",
  "id" : 156316396815532032,
  "created_at" : "2012-01-09 10:08:27 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "156301601135534080",
  "text" : "\u2026",
  "id" : 156301601135534080,
  "created_at" : "2012-01-09 09:09:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scytale",
      "screen_name" : "Scytale",
      "indices" : [ 3, 11 ],
      "id_str" : "621716753",
      "id" : 621716753
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 135 ],
      "url" : "http:\/\/t.co\/s5jIJos9",
      "expanded_url" : "http:\/\/is.gd\/gRi1He",
      "display_url" : "is.gd\/gRi1He"
    } ]
  },
  "geo" : { },
  "id_str" : "156301119658790912",
  "text" : "RT @Scytale: Nicht-monogame Beziehungen funktionieren nicht? Quark. Ihr kriegt die funktionierenden nur nicht mit. http:\/\/t.co\/s5jIJos9  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Lore Frost",
        "screen_name" : "Lobot",
        "indices" : [ 128, 134 ],
        "id_str" : "1492631",
        "id" : 1492631
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 102, 122 ],
        "url" : "http:\/\/t.co\/s5jIJos9",
        "expanded_url" : "http:\/\/is.gd\/gRi1He",
        "display_url" : "is.gd\/gRi1He"
      } ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 49.4955473928, 8.4576165676 ]
    },
    "id_str" : "156298653617762305",
    "text" : "Nicht-monogame Beziehungen funktionieren nicht? Quark. Ihr kriegt die funktionierenden nur nicht mit. http:\/\/t.co\/s5jIJos9 (via @Lobot)",
    "id" : 156298653617762305,
    "created_at" : "2012-01-09 08:57:57 +0000",
    "user" : {
      "name" : "Tim Weber",
      "screen_name" : "scy",
      "protected" : false,
      "id_str" : "8308632",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/640094846196150272\/6X7gF8lF_normal.png",
      "id" : 8308632,
      "verified" : false
    }
  },
  "id" : 156301119658790912,
  "created_at" : "2012-01-09 09:07:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 89 ],
      "url" : "http:\/\/t.co\/Dpf7uXr1",
      "expanded_url" : "http:\/\/j.mp\/x7wNNu",
      "display_url" : "j.mp\/x7wNNu"
    } ]
  },
  "geo" : { },
  "id_str" : "156268624460513280",
  "text" : "A nice piece on geneticist James Crow who passed away some days ago. http:\/\/t.co\/Dpf7uXr1",
  "id" : 156268624460513280,
  "created_at" : "2012-01-09 06:58:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 20, 33 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 97 ],
      "url" : "http:\/\/t.co\/Qroi3bYt",
      "expanded_url" : "http:\/\/norvig.com\/21-days.html",
      "display_url" : "norvig.com\/21-days.html"
    } ]
  },
  "geo" : { },
  "id_str" : "156267605915738112",
  "text" : "Mastering stuff: RT @PhilippBayer: Teach yourself programming! In ten years. http:\/\/t.co\/Qroi3bYt",
  "id" : 156267605915738112,
  "created_at" : "2012-01-09 06:54:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "156196768839774208",
  "geo" : { },
  "id_str" : "156266633080471552",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer gratz :)",
  "id" : 156266633080471552,
  "in_reply_to_status_id" : 156196768839774208,
  "created_at" : "2012-01-09 06:50:43 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 94 ],
      "url" : "http:\/\/t.co\/Gnt2WEof",
      "expanded_url" : "http:\/\/4sq.com\/wkYaQj",
      "display_url" : "4sq.com\/wkYaQj"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0075459472, 8.2818889618 ]
  },
  "id_str" : "156265880962072576",
  "text" : "Da ist die Vorlesungsfreie Zeit wieder vorbei... (@ Bahnhof Mainz-Kastel) http:\/\/t.co\/Gnt2WEof",
  "id" : 156265880962072576,
  "created_at" : "2012-01-09 06:47:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steffan Antonas",
      "screen_name" : "SteffanAntonas",
      "indices" : [ 3, 18 ],
      "id_str" : "6686402",
      "id" : 6686402
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 94 ],
      "url" : "http:\/\/t.co\/nRyFUSg4",
      "expanded_url" : "http:\/\/read.bi\/uKkB1d",
      "display_url" : "read.bi\/uKkB1d"
    } ]
  },
  "geo" : { },
  "id_str" : "156158466489204738",
  "text" : "RT @SteffanAntonas: Teach Your Kids How To Code, Not How To Speak Chinese http:\/\/t.co\/nRyFUSg4 &lt;-- I couldn't say this any better. Gr ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 54, 74 ],
        "url" : "http:\/\/t.co\/nRyFUSg4",
        "expanded_url" : "http:\/\/read.bi\/uKkB1d",
        "display_url" : "read.bi\/uKkB1d"
      } ]
    },
    "geo" : { },
    "id_str" : "156119541456445440",
    "text" : "Teach Your Kids How To Code, Not How To Speak Chinese http:\/\/t.co\/nRyFUSg4 &lt;-- I couldn't say this any better. Great article.",
    "id" : 156119541456445440,
    "created_at" : "2012-01-08 21:06:13 +0000",
    "user" : {
      "name" : "Steffan Antonas",
      "screen_name" : "SteffanAntonas",
      "protected" : false,
      "id_str" : "6686402",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/460418635886915586\/7VFzq9R1_normal.jpeg",
      "id" : 6686402,
      "verified" : false
    }
  },
  "id" : 156158466489204738,
  "created_at" : "2012-01-08 23:40:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "stress2punkt0",
      "indices" : [ 81, 95 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "156123597809795072",
  "text" : "\u00ABOh Gott, jetzt muss ich auch noch pinkeln. Wer soll denn das alles erledigen?!\u00BB #stress2punkt0",
  "id" : 156123597809795072,
  "created_at" : "2012-01-08 21:22:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Open Science",
      "screen_name" : "openscience",
      "indices" : [ 3, 15 ],
      "id_str" : "53560219",
      "id" : 53560219
    }, {
      "name" : "Carolyn B. Maloney",
      "screen_name" : "CarolynBMaloney",
      "indices" : [ 39, 55 ],
      "id_str" : "119250381",
      "id" : 119250381
    }, {
      "name" : "Darrell Issa",
      "screen_name" : "DarrellIssa",
      "indices" : [ 60, 72 ],
      "id_str" : "22509548",
      "id" : 22509548
    }, {
      "name" : "C\u24D0meronNeylon",
      "screen_name" : "CameronNeylon",
      "indices" : [ 117, 131 ],
      "id_str" : "12984852",
      "id" : 12984852
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RWA",
      "indices" : [ 132, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 98 ],
      "url" : "http:\/\/t.co\/risc5rSW",
      "expanded_url" : "http:\/\/bit.ly\/AfbtH7",
      "display_url" : "bit.ly\/AfbtH7"
    } ]
  },
  "geo" : { },
  "id_str" : "156117997398925312",
  "text" : "RT @openscience: \"Dear Representatives @CarolynBMaloney and @DarrellIssa ...\" http:\/\/t.co\/risc5rSW an open letter by @CameronNeylon #RWA ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Carolyn B. Maloney",
        "screen_name" : "CarolynBMaloney",
        "indices" : [ 22, 38 ],
        "id_str" : "119250381",
        "id" : 119250381
      }, {
        "name" : "Darrell Issa",
        "screen_name" : "DarrellIssa",
        "indices" : [ 43, 55 ],
        "id_str" : "22509548",
        "id" : 22509548
      }, {
        "name" : "C\u24D0meronNeylon",
        "screen_name" : "CameronNeylon",
        "indices" : [ 100, 114 ],
        "id_str" : "12984852",
        "id" : 12984852
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "RWA",
        "indices" : [ 115, 119 ]
      }, {
        "text" : "HR3699",
        "indices" : [ 120, 127 ]
      }, {
        "text" : "OpenAccess",
        "indices" : [ 128, 139 ]
      } ],
      "urls" : [ {
        "indices" : [ 61, 81 ],
        "url" : "http:\/\/t.co\/risc5rSW",
        "expanded_url" : "http:\/\/bit.ly\/AfbtH7",
        "display_url" : "bit.ly\/AfbtH7"
      } ]
    },
    "geo" : { },
    "id_str" : "156111096850292736",
    "text" : "\"Dear Representatives @CarolynBMaloney and @DarrellIssa ...\" http:\/\/t.co\/risc5rSW an open letter by @CameronNeylon #RWA #HR3699 #OpenAccess",
    "id" : 156111096850292736,
    "created_at" : "2012-01-08 20:32:40 +0000",
    "user" : {
      "name" : "Open Science",
      "screen_name" : "openscience",
      "protected" : false,
      "id_str" : "53560219",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/459933268746317825\/wrEyqxhT_normal.png",
      "id" : 53560219,
      "verified" : false
    }
  },
  "id" : 156117997398925312,
  "created_at" : "2012-01-08 21:00:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 50 ],
      "url" : "http:\/\/t.co\/kBLiVVI3",
      "expanded_url" : "http:\/\/bit.ly\/ya59MG",
      "display_url" : "bit.ly\/ya59MG"
    } ]
  },
  "geo" : { },
  "id_str" : "156107285536583680",
  "text" : "Ooops, I've broken the build! http:\/\/t.co\/kBLiVVI3",
  "id" : 156107285536583680,
  "created_at" : "2012-01-08 20:17:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "156097600083337216",
  "geo" : { },
  "id_str" : "156099425083719680",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer Set up your own jabber-server :D",
  "id" : 156099425083719680,
  "in_reply_to_status_id" : 156097600083337216,
  "created_at" : "2012-01-08 19:46:17 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 43, 53 ],
      "id_str" : "14700783",
      "id" : 14700783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 80 ],
      "url" : "http:\/\/t.co\/j9DmYI7U",
      "expanded_url" : "http:\/\/freethoughtblogs.com\/xblog\/files\/2012\/01\/4e834c0304cea.png",
      "display_url" : "freethoughtblogs.com\/xblog\/files\/20\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "156091752120459264",
  "text" : "Taking fun out of biochemistry since... RT @Fischblog: WIN! http:\/\/t.co\/j9DmYI7U",
  "id" : 156091752120459264,
  "created_at" : "2012-01-08 19:15:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Skellett",
      "screen_name" : "Gurdur",
      "indices" : [ 0, 7 ],
      "id_str" : "125928028",
      "id" : 125928028
    }, {
      "name" : "Marisa Alonso Nu\u00F1ez",
      "screen_name" : "lualnu10",
      "indices" : [ 8, 17 ],
      "id_str" : "135431733",
      "id" : 135431733
    }, {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 18, 28 ],
      "id_str" : "14700783",
      "id" : 14700783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "156083697106436096",
  "geo" : { },
  "id_str" : "156088218926850048",
  "in_reply_to_user_id" : 125928028,
  "text" : "@Gurdur @lualnu10 @fischblog I will also miss all of you. But it's just to far away if nobody covers your travel expenses ;)",
  "id" : 156088218926850048,
  "in_reply_to_status_id" : 156083697106436096,
  "created_at" : "2012-01-08 19:01:46 +0000",
  "in_reply_to_screen_name" : "Gurdur",
  "in_reply_to_user_id_str" : "125928028",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "156043256537415681",
  "text" : "Finished slides for a seminar talk. Next: Slides for a talk about openSNP at the end of January in T\u00FCbingen.",
  "id" : 156043256537415681,
  "created_at" : "2012-01-08 16:03:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 71 ],
      "url" : "http:\/\/t.co\/ALzbuoXL",
      "expanded_url" : "http:\/\/j.mp\/yLV7bj",
      "display_url" : "j.mp\/yLV7bj"
    } ]
  },
  "geo" : { },
  "id_str" : "156041667760238593",
  "text" : "Nom nom nom: 3D printed TARDIS gingerbread cookies http:\/\/t.co\/ALzbuoXL",
  "id" : 156041667760238593,
  "created_at" : "2012-01-08 15:56:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "herr_schrat",
      "screen_name" : "herr_schrat",
      "indices" : [ 0, 12 ],
      "id_str" : "16066591",
      "id" : 16066591
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 73, 82 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "156036361399451648",
  "geo" : { },
  "id_str" : "156036577817145344",
  "in_reply_to_user_id" : 16066591,
  "text" : "@herr_schrat Deshalb weiss ich jetzt schon immer 30 Sekunden fr\u00FCher wann @Senficon nach hause kommt.Auf einmal laufen die Backstreet Boys ;)",
  "id" : 156036577817145344,
  "in_reply_to_status_id" : 156036361399451648,
  "created_at" : "2012-01-08 15:36:33 +0000",
  "in_reply_to_screen_name" : "herr_schrat",
  "in_reply_to_user_id_str" : "16066591",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Frau Fragmente",
      "screen_name" : "fragmente",
      "indices" : [ 3, 13 ],
      "id_str" : "7207642",
      "id" : 7207642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 75 ],
      "url" : "http:\/\/t.co\/zqeD7Jm6",
      "expanded_url" : "http:\/\/www.postsecret.com\/",
      "display_url" : "postsecret.com"
    } ]
  },
  "geo" : { },
  "id_str" : "155988497956749313",
  "text" : "RT @fragmente: Postsecret ist diesen Sonntag ganz gut. http:\/\/t.co\/zqeD7Jm6",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 40, 60 ],
        "url" : "http:\/\/t.co\/zqeD7Jm6",
        "expanded_url" : "http:\/\/www.postsecret.com\/",
        "display_url" : "postsecret.com"
      } ]
    },
    "geo" : { },
    "id_str" : "155983323313872896",
    "text" : "Postsecret ist diesen Sonntag ganz gut. http:\/\/t.co\/zqeD7Jm6",
    "id" : 155983323313872896,
    "created_at" : "2012-01-08 12:04:56 +0000",
    "user" : {
      "name" : "Frau Fragmente",
      "screen_name" : "fragmente",
      "protected" : false,
      "id_str" : "7207642",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/696457425277317120\/emEVfsV-_normal.jpg",
      "id" : 7207642,
      "verified" : false
    }
  },
  "id" : 155988497956749313,
  "created_at" : "2012-01-08 12:25:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 42 ],
      "url" : "http:\/\/t.co\/AcaF19wA",
      "expanded_url" : "http:\/\/j.mp\/A9LsdD",
      "display_url" : "j.mp\/A9LsdD"
    } ]
  },
  "geo" : { },
  "id_str" : "155975689651224576",
  "text" : "Elend Einfamilienhaus http:\/\/t.co\/AcaF19wA",
  "id" : 155975689651224576,
  "created_at" : "2012-01-08 11:34:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rya",
      "screen_name" : "_Rya_",
      "indices" : [ 0, 6 ],
      "id_str" : "89234537",
      "id" : 89234537
    }, {
      "name" : "Scytale",
      "screen_name" : "Scytale",
      "indices" : [ 27, 35 ],
      "id_str" : "621716753",
      "id" : 621716753
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "155774898046902272",
  "geo" : { },
  "id_str" : "155776093540978690",
  "in_reply_to_user_id" : 89234537,
  "text" : "@_Rya_ Ich auch, damit der @Scytale mir nicht immer bei JS aushelfen muss :P",
  "id" : 155776093540978690,
  "in_reply_to_status_id" : 155774898046902272,
  "created_at" : "2012-01-07 22:21:29 +0000",
  "in_reply_to_screen_name" : "_Rya_",
  "in_reply_to_user_id_str" : "89234537",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "naturalismus",
      "screen_name" : "naturalismus",
      "indices" : [ 0, 13 ],
      "id_str" : "4562569648",
      "id" : 4562569648
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "155771799278333952",
  "geo" : { },
  "id_str" : "155771936054579200",
  "in_reply_to_user_id" : 77216385,
  "text" : "@Naturalismus richtig. Bei BME gibt es noch jede Menge der Art. ;)",
  "id" : 155771936054579200,
  "in_reply_to_status_id" : 155771799278333952,
  "created_at" : "2012-01-07 22:04:58 +0000",
  "in_reply_to_screen_name" : "fireantprincess",
  "in_reply_to_user_id_str" : "77216385",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "naturalismus",
      "screen_name" : "naturalismus",
      "indices" : [ 0, 13 ],
      "id_str" : "4562569648",
      "id" : 4562569648
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "155770303170084865",
  "geo" : { },
  "id_str" : "155770536922841088",
  "in_reply_to_user_id" : 77216385,
  "text" : "@Naturalismus hehe, ok.",
  "id" : 155770536922841088,
  "in_reply_to_status_id" : 155770303170084865,
  "created_at" : "2012-01-07 21:59:24 +0000",
  "in_reply_to_screen_name" : "fireantprincess",
  "in_reply_to_user_id_str" : "77216385",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "naturalismus",
      "screen_name" : "naturalismus",
      "indices" : [ 0, 13 ],
      "id_str" : "4562569648",
      "id" : 4562569648
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "155763042129424384",
  "geo" : { },
  "id_str" : "155769768962572288",
  "in_reply_to_user_id" : 77216385,
  "text" : "@Naturalismus du warst ja wohl gewarnt ;)",
  "id" : 155769768962572288,
  "in_reply_to_status_id" : 155763042129424384,
  "created_at" : "2012-01-07 21:56:21 +0000",
  "in_reply_to_screen_name" : "fireantprincess",
  "in_reply_to_user_id_str" : "77216385",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 0, 10 ],
      "id_str" : "14700783",
      "id" : 14700783
    }, {
      "name" : "Cae Vye",
      "screen_name" : "CaeVye",
      "indices" : [ 11, 18 ],
      "id_str" : "31104704",
      "id" : 31104704
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 75 ],
      "url" : "http:\/\/t.co\/OWyoR6Yf",
      "expanded_url" : "http:\/\/bit.ly\/xIfeus",
      "display_url" : "bit.ly\/xIfeus"
    } ]
  },
  "in_reply_to_status_id_str" : "155759752159297539",
  "geo" : { },
  "id_str" : "155761147524554752",
  "in_reply_to_user_id" : 14700783,
  "text" : "@Fischblog @CaeVye Hier das Interview inkl. mehr Fotos http:\/\/t.co\/OWyoR6Yf (das nsfw kann ich mir sparen, oder? ;))",
  "id" : 155761147524554752,
  "in_reply_to_status_id" : 155759752159297539,
  "created_at" : "2012-01-07 21:22:06 +0000",
  "in_reply_to_screen_name" : "Fischblog",
  "in_reply_to_user_id_str" : "14700783",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 0, 10 ],
      "id_str" : "14700783",
      "id" : 14700783
    }, {
      "name" : "Cae Vye",
      "screen_name" : "CaeVye",
      "indices" : [ 11, 18 ],
      "id_str" : "31104704",
      "id" : 31104704
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "155759752159297539",
  "geo" : { },
  "id_str" : "155760750227505153",
  "in_reply_to_user_id" : 14700783,
  "text" : "@Fischblog @CaeVye Finde es aber auch aus medizinischer Sicht nicht so spannend: \u00ABKann man machen, muss man aber nicht\u00BB ;)",
  "id" : 155760750227505153,
  "in_reply_to_status_id" : 155759752159297539,
  "created_at" : "2012-01-07 21:20:31 +0000",
  "in_reply_to_screen_name" : "Fischblog",
  "in_reply_to_user_id_str" : "14700783",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cae Vye",
      "screen_name" : "CaeVye",
      "indices" : [ 0, 7 ],
      "id_str" : "31104704",
      "id" : 31104704
    }, {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 8, 18 ],
      "id_str" : "14700783",
      "id" : 14700783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "155759258430996480",
  "geo" : { },
  "id_str" : "155760673245249537",
  "in_reply_to_user_id" : 31104704,
  "text" : "@CaeVye @Fischblog Hier ist ein Bild dabei, das Interview such ich gerade noch.",
  "id" : 155760673245249537,
  "in_reply_to_status_id" : 155759258430996480,
  "created_at" : "2012-01-07 21:20:13 +0000",
  "in_reply_to_screen_name" : "CaeVye",
  "in_reply_to_user_id_str" : "31104704",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 0, 10 ],
      "id_str" : "14700783",
      "id" : 14700783
    }, {
      "name" : "Cae Vye",
      "screen_name" : "CaeVye",
      "indices" : [ 11, 18 ],
      "id_str" : "31104704",
      "id" : 31104704
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "155758896311570432",
  "geo" : { },
  "id_str" : "155759146912854016",
  "in_reply_to_user_id" : 14700783,
  "text" : "@Fischblog @CaeVye Das BME hatte mal ein Interview mit einem der Split Penis-Typen, wenn ich mich recht erinnere.",
  "id" : 155759146912854016,
  "in_reply_to_status_id" : 155758896311570432,
  "created_at" : "2012-01-07 21:14:09 +0000",
  "in_reply_to_screen_name" : "Fischblog",
  "in_reply_to_user_id_str" : "14700783",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 16, 26 ],
      "id_str" : "14700783",
      "id" : 14700783
    }, {
      "name" : "Mugwump",
      "screen_name" : "ozaed",
      "indices" : [ 30, 36 ],
      "id_str" : "15806521",
      "id" : 15806521
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 118 ],
      "url" : "http:\/\/t.co\/3FJ1Qh7y",
      "expanded_url" : "http:\/\/on.msnbc.com\/A7sg8U",
      "display_url" : "on.msnbc.com\/A7sg8U"
    } ]
  },
  "geo" : { },
  "id_str" : "155757279822626817",
  "text" : "Das ist was f\u00FCr @Fischblog RT @ozaed: \u201Cbased on our unique case, we discourage penile tattooing.\u201D http:\/\/t.co\/3FJ1Qh7y",
  "id" : 155757279822626817,
  "created_at" : "2012-01-07 21:06:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jensbest",
      "screen_name" : "jensbest",
      "indices" : [ 3, 12 ],
      "id_str" : "14599545",
      "id" : 14599545
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 62 ],
      "url" : "http:\/\/t.co\/VI0s0GrF",
      "expanded_url" : "http:\/\/fernsehkritik.tv\/blog\/2012\/01\/kenn-dein-limit\/",
      "display_url" : "fernsehkritik.tv\/blog\/2012\/01\/k\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "155733544747012096",
  "text" : "RT @jensbest: Gelungen: Kenn' Dein Limit! http:\/\/t.co\/VI0s0GrF",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 28, 48 ],
        "url" : "http:\/\/t.co\/VI0s0GrF",
        "expanded_url" : "http:\/\/fernsehkritik.tv\/blog\/2012\/01\/kenn-dein-limit\/",
        "display_url" : "fernsehkritik.tv\/blog\/2012\/01\/k\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "155722080686575617",
    "text" : "Gelungen: Kenn' Dein Limit! http:\/\/t.co\/VI0s0GrF",
    "id" : 155722080686575617,
    "created_at" : "2012-01-07 18:46:51 +0000",
    "user" : {
      "name" : "jensbest",
      "screen_name" : "jensbest",
      "protected" : false,
      "id_str" : "14599545",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/879823333239517184\/1ULQsf5I_normal.jpg",
      "id" : 14599545,
      "verified" : false
    }
  },
  "id" : 155733544747012096,
  "created_at" : "2012-01-07 19:32:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 64 ],
      "url" : "http:\/\/t.co\/iv5W9I4Z",
      "expanded_url" : "http:\/\/j.mp\/Agoitg",
      "display_url" : "j.mp\/Agoitg"
    } ]
  },
  "geo" : { },
  "id_str" : "155702121071771649",
  "text" : "Spannend: Opfer-DNA im Lauf von Feuerwaffen http:\/\/t.co\/iv5W9I4Z",
  "id" : 155702121071771649,
  "created_at" : "2012-01-07 17:27:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "155685915027718147",
  "geo" : { },
  "id_str" : "155686665061531649",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch Haha, good luck! :)",
  "id" : 155686665061531649,
  "in_reply_to_status_id" : 155685915027718147,
  "created_at" : "2012-01-07 16:26:08 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 0, 10 ],
      "id_str" : "14700783",
      "id" : 14700783
    }, {
      "name" : "Rya",
      "screen_name" : "_Rya_",
      "indices" : [ 11, 17 ],
      "id_str" : "89234537",
      "id" : 89234537
    }, {
      "name" : "naturalismus",
      "screen_name" : "naturalismus",
      "indices" : [ 18, 31 ],
      "id_str" : "4562569648",
      "id" : 4562569648
    }, {
      "name" : "Anatol Stefanowitsch",
      "screen_name" : "astefanowitsch",
      "indices" : [ 32, 47 ],
      "id_str" : "73134122",
      "id" : 73134122
    }, {
      "name" : "Michael Horak",
      "screen_name" : "fatmike182",
      "indices" : [ 48, 59 ],
      "id_str" : "15271509",
      "id" : 15271509
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "155683580880760832",
  "geo" : { },
  "id_str" : "155683788851134464",
  "in_reply_to_user_id" : 14700783,
  "text" : "@Fischblog @_Rya_ @Naturalismus @astefanowitsch @fatmike182 Krypto-Zoologie! ;)",
  "id" : 155683788851134464,
  "in_reply_to_status_id" : 155683580880760832,
  "created_at" : "2012-01-07 16:14:42 +0000",
  "in_reply_to_screen_name" : "Fischblog",
  "in_reply_to_user_id_str" : "14700783",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Horak",
      "screen_name" : "fatmike182",
      "indices" : [ 0, 11 ],
      "id_str" : "15271509",
      "id" : 15271509
    }, {
      "name" : "naturalismus",
      "screen_name" : "naturalismus",
      "indices" : [ 12, 25 ],
      "id_str" : "4562569648",
      "id" : 4562569648
    }, {
      "name" : "Anatol Stefanowitsch",
      "screen_name" : "astefanowitsch",
      "indices" : [ 26, 41 ],
      "id_str" : "73134122",
      "id" : 73134122
    }, {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 42, 52 ],
      "id_str" : "14700783",
      "id" : 14700783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "155680891551744002",
  "geo" : { },
  "id_str" : "155681063052644352",
  "in_reply_to_user_id" : 15271509,
  "text" : "@fatmike182 @Naturalismus @astefanowitsch @fischblog Daf\u00FCr mit Glow-In-The-Dark. Das ist ja auch ziemlich cool.",
  "id" : 155681063052644352,
  "in_reply_to_status_id" : 155680891551744002,
  "created_at" : "2012-01-07 16:03:52 +0000",
  "in_reply_to_screen_name" : "fatmike182",
  "in_reply_to_user_id_str" : "15271509",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 0, 10 ],
      "id_str" : "14700783",
      "id" : 14700783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "155677912425701376",
  "geo" : { },
  "id_str" : "155678216399491073",
  "in_reply_to_user_id" : 14700783,
  "text" : "@Fischblog I\u00E4! I\u00E4! Cthulhu Fhtagn!",
  "id" : 155678216399491073,
  "in_reply_to_status_id" : 155677912425701376,
  "created_at" : "2012-01-07 15:52:33 +0000",
  "in_reply_to_screen_name" : "Fischblog",
  "in_reply_to_user_id_str" : "14700783",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anatol Stefanowitsch",
      "screen_name" : "astefanowitsch",
      "indices" : [ 0, 15 ],
      "id_str" : "73134122",
      "id" : 73134122
    }, {
      "name" : "Quokkas machen \u00FCbrigens gar nicht 'quok'. \uD83D\uDE22",
      "screen_name" : "Fischblog",
      "indices" : [ 16, 26 ],
      "id_str" : "14700783",
      "id" : 14700783
    }, {
      "name" : "Michael Horak",
      "screen_name" : "fatmike182",
      "indices" : [ 27, 38 ],
      "id_str" : "15271509",
      "id" : 15271509
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 72 ],
      "url" : "http:\/\/t.co\/syUSTnUj",
      "expanded_url" : "http:\/\/bit.ly\/AcM08P",
      "display_url" : "bit.ly\/AcM08P"
    } ]
  },
  "in_reply_to_status_id_str" : "155674808842059776",
  "geo" : { },
  "id_str" : "155675110928416768",
  "in_reply_to_user_id" : 73134122,
  "text" : "@astefanowitsch @Fischblog @fatmike182 Oder daraus: http:\/\/t.co\/syUSTnUj",
  "id" : 155675110928416768,
  "in_reply_to_status_id" : 155674808842059776,
  "created_at" : "2012-01-07 15:40:13 +0000",
  "in_reply_to_screen_name" : "astefanowitsch",
  "in_reply_to_user_id_str" : "73134122",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sebastian",
      "screen_name" : "MrEnkapsis",
      "indices" : [ 0, 11 ],
      "id_str" : "115717883",
      "id" : 115717883
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "155614374583730176",
  "geo" : { },
  "id_str" : "155614755715956736",
  "in_reply_to_user_id" : 115717883,
  "text" : "@MrEnkapsis Naja, ich hab keine Ahnung wie die Situation in MZ ist. Aber normalerweise hat man doch immer mal gesunde Kontrolltiere \"\u00FCber\"",
  "id" : 155614755715956736,
  "in_reply_to_status_id" : 155614374583730176,
  "created_at" : "2012-01-07 11:40:23 +0000",
  "in_reply_to_screen_name" : "MrEnkapsis",
  "in_reply_to_user_id_str" : "115717883",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 0, 10 ],
      "id_str" : "14700783",
      "id" : 14700783
    }, {
      "name" : "Sebastian",
      "screen_name" : "MrEnkapsis",
      "indices" : [ 11, 22 ],
      "id_str" : "115717883",
      "id" : 115717883
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "155611798924566531",
  "geo" : { },
  "id_str" : "155612828303228928",
  "in_reply_to_user_id" : 14700783,
  "text" : "@Fischblog @MrEnkapsis mit Tierschutz hat das imho nichts zu tun. Bestimmt fallen auch in Mainz t\u00E4glich M\u00E4use aus Versuchen ab..",
  "id" : 155612828303228928,
  "in_reply_to_status_id" : 155611798924566531,
  "created_at" : "2012-01-07 11:32:44 +0000",
  "in_reply_to_screen_name" : "Fischblog",
  "in_reply_to_user_id_str" : "14700783",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mugwump",
      "screen_name" : "ozaed",
      "indices" : [ 12, 18 ],
      "id_str" : "15806521",
      "id" : 15806521
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 78 ],
      "url" : "http:\/\/t.co\/R4HPQZaS",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=d9NF2edxy-M",
      "display_url" : "youtube.com\/watch?v=d9NF2e\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "155612116588564481",
  "text" : "Awesome! RT @ozaed: Eine akustische Gitarre reicht v\u00F6llig http:\/\/t.co\/R4HPQZaS",
  "id" : 155612116588564481,
  "created_at" : "2012-01-07 11:29:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 56 ],
      "url" : "http:\/\/t.co\/LeyEo7s2",
      "expanded_url" : "http:\/\/j.mp\/zxUerZ",
      "display_url" : "j.mp\/zxUerZ"
    } ]
  },
  "geo" : { },
  "id_str" : "155610197497356288",
  "text" : "Gendered Language among the Pueblos http:\/\/t.co\/LeyEo7s2",
  "id" : 155610197497356288,
  "created_at" : "2012-01-07 11:22:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 116 ],
      "url" : "http:\/\/t.co\/HHAfvUk9",
      "expanded_url" : "http:\/\/j.mp\/zDtR26",
      "display_url" : "j.mp\/zDtR26"
    } ]
  },
  "geo" : { },
  "id_str" : "155608672557465601",
  "text" : "Modeling the Spread of Methicillin-Resistant Staphylococcus aureus in Nursing Homes for Elderly http:\/\/t.co\/HHAfvUk9",
  "id" : 155608672557465601,
  "created_at" : "2012-01-07 11:16:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 46 ],
      "url" : "http:\/\/t.co\/Gr1GrYCD",
      "expanded_url" : "http:\/\/j.mp\/y9FuZp",
      "display_url" : "j.mp\/y9FuZp"
    } ]
  },
  "geo" : { },
  "id_str" : "155607692868726785",
  "text" : "Solving the Fermi Paradox http:\/\/t.co\/Gr1GrYCD",
  "id" : 155607692868726785,
  "created_at" : "2012-01-07 11:12:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OpenAccessHulk",
      "screen_name" : "OpenAccessHulk",
      "indices" : [ 3, 18 ],
      "id_str" : "369732344",
      "id" : 369732344
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "155436240697696258",
  "text" : "RT @OpenAccessHulk: OA HULK TOUCHED BY IMMEDIATE CRITICAL RESPONSE TO RESEARCH WORKS ACT! WE WILL ALL SMASH TOGETHER!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "155422786901393408",
    "text" : "OA HULK TOUCHED BY IMMEDIATE CRITICAL RESPONSE TO RESEARCH WORKS ACT! WE WILL ALL SMASH TOGETHER!",
    "id" : 155422786901393408,
    "created_at" : "2012-01-06 22:57:34 +0000",
    "user" : {
      "name" : "OpenAccessHulk",
      "screen_name" : "OpenAccessHulk",
      "protected" : false,
      "id_str" : "369732344",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1549535589\/OAhulk_normal",
      "id" : 369732344,
      "verified" : false
    }
  },
  "id" : 155436240697696258,
  "created_at" : "2012-01-06 23:51:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 49 ],
      "url" : "http:\/\/t.co\/LKj6xM7x",
      "expanded_url" : "http:\/\/bit.ly\/zhpCvx",
      "display_url" : "bit.ly\/zhpCvx"
    } ]
  },
  "geo" : { },
  "id_str" : "155422682408689664",
  "text" : "\u2026omics? What about Fuckomics http:\/\/t.co\/LKj6xM7x",
  "id" : 155422682408689664,
  "created_at" : "2012-01-06 22:57:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 3, 12 ],
      "id_str" : "14245811",
      "id" : 14245811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 122 ],
      "url" : "http:\/\/t.co\/ir9YiRRN",
      "expanded_url" : "http:\/\/amzn.to\/tSJZGX",
      "display_url" : "amzn.to\/tSJZGX"
    } ]
  },
  "geo" : { },
  "id_str" : "155414377158287360",
  "text" : "RT @wilbanks: Some outstanding Amazon reviews here, especially the one about Fibonacci and hand size. http:\/\/t.co\/ir9YiRRN",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 88, 108 ],
        "url" : "http:\/\/t.co\/ir9YiRRN",
        "expanded_url" : "http:\/\/amzn.to\/tSJZGX",
        "display_url" : "amzn.to\/tSJZGX"
      } ]
    },
    "geo" : { },
    "id_str" : "155413611047682048",
    "text" : "Some outstanding Amazon reviews here, especially the one about Fibonacci and hand size. http:\/\/t.co\/ir9YiRRN",
    "id" : 155413611047682048,
    "created_at" : "2012-01-06 22:21:06 +0000",
    "user" : {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "protected" : false,
      "id_str" : "14245811",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/925696899566440448\/BUTdp410_normal.jpg",
      "id" : 14245811,
      "verified" : false
    }
  },
  "id" : 155414377158287360,
  "created_at" : "2012-01-06 22:24:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "155411552974012416",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon Testmention",
  "id" : 155411552974012416,
  "created_at" : "2012-01-06 22:12:56 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 85, 94 ],
      "id_str" : "14861745",
      "id" : 14861745
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 120, 133 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 115 ],
      "url" : "http:\/\/t.co\/GIIpdI24",
      "expanded_url" : "http:\/\/bit.ly\/zfxW9h",
      "display_url" : "bit.ly\/zfxW9h"
    } ]
  },
  "geo" : { },
  "id_str" : "155400125437579265",
  "text" : "Worked through the open answers on our survey on sharing phenotypic information with @Senficon http:\/\/t.co\/GIIpdI24 \/cc @PhilippBayer",
  "id" : 155400125437579265,
  "created_at" : "2012-01-06 21:27:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leonid Kruglyak",
      "screen_name" : "leonidkruglyak",
      "indices" : [ 3, 18 ],
      "id_str" : "19416598",
      "id" : 19416598
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "155371781945954306",
  "text" : "RT @leonidkruglyak: \"p-values may be the worst form of statistical significance calculation except all other forms that have been tried\" ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 137 ],
        "url" : "http:\/\/t.co\/KXLKKil4",
        "expanded_url" : "http:\/\/bit.ly\/xDSfW9",
        "display_url" : "bit.ly\/xDSfW9"
      } ]
    },
    "geo" : { },
    "id_str" : "155359248023437313",
    "text" : "\"p-values may be the worst form of statistical significance calculation except all other forms that have been tried\" http:\/\/t.co\/KXLKKil4",
    "id" : 155359248023437313,
    "created_at" : "2012-01-06 18:45:05 +0000",
    "user" : {
      "name" : "Leonid Kruglyak",
      "screen_name" : "leonidkruglyak",
      "protected" : false,
      "id_str" : "19416598",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1095542276\/MyRecentPhoto_normal.jpg",
      "id" : 19416598,
      "verified" : false
    }
  },
  "id" : 155371781945954306,
  "created_at" : "2012-01-06 19:34:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 117 ],
      "url" : "http:\/\/t.co\/uHpu21RW",
      "expanded_url" : "http:\/\/j.mp\/A6jyvR",
      "display_url" : "j.mp\/A6jyvR"
    } ]
  },
  "geo" : { },
  "id_str" : "155346414967324672",
  "text" : "How-To use super computers in a sensible way: Mathematician claims breakthrough in Sudoku puzzle http:\/\/t.co\/uHpu21RW",
  "id" : 155346414967324672,
  "created_at" : "2012-01-06 17:54:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 52 ],
      "url" : "http:\/\/t.co\/49BqtuhJ",
      "expanded_url" : "http:\/\/j.mp\/zkHeG6",
      "display_url" : "j.mp\/zkHeG6"
    } ]
  },
  "geo" : { },
  "id_str" : "155345863005319168",
  "text" : "Fungi, a Tool for Weed Control? http:\/\/t.co\/49BqtuhJ",
  "id" : 155345863005319168,
  "created_at" : "2012-01-06 17:51:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 47 ],
      "url" : "http:\/\/t.co\/WlOucHJ1",
      "expanded_url" : "http:\/\/j.mp\/x4PDYI",
      "display_url" : "j.mp\/x4PDYI"
    } ]
  },
  "geo" : { },
  "id_str" : "155344275461255169",
  "text" : "Hamster-powered submarines http:\/\/t.co\/WlOucHJ1",
  "id" : 155344275461255169,
  "created_at" : "2012-01-06 17:45:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kia",
      "screen_name" : "nad_no_ennas",
      "indices" : [ 0, 13 ],
      "id_str" : "1702539380",
      "id" : 1702539380
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "155315669712379904",
  "geo" : { },
  "id_str" : "155315903414804481",
  "in_reply_to_user_id" : 102096393,
  "text" : "@nad_no_ennas Ich glaub gerade da findet man keine biologischen Fakten. :D",
  "id" : 155315903414804481,
  "in_reply_to_status_id" : 155315669712379904,
  "created_at" : "2012-01-06 15:52:51 +0000",
  "in_reply_to_screen_name" : "kianelazin",
  "in_reply_to_user_id_str" : "102096393",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kia",
      "screen_name" : "nad_no_ennas",
      "indices" : [ 0, 13 ],
      "id_str" : "1702539380",
      "id" : 1702539380
    }, {
      "name" : "Kai M\u00F6ller \/ cheGGo",
      "screen_name" : "kaifuzius",
      "indices" : [ 14, 24 ],
      "id_str" : "18588098",
      "id" : 18588098
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "155277980892020737",
  "geo" : { },
  "id_str" : "155313221149003776",
  "in_reply_to_user_id" : 102096393,
  "text" : "@nad_no_ennas @kaifuzius Ungef\u00E4hr gar nicht. :P",
  "id" : 155313221149003776,
  "in_reply_to_status_id" : 155277980892020737,
  "created_at" : "2012-01-06 15:42:12 +0000",
  "in_reply_to_screen_name" : "kianelazin",
  "in_reply_to_user_id_str" : "102096393",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 94 ],
      "url" : "http:\/\/t.co\/H6MgYhFh",
      "expanded_url" : "http:\/\/j.mp\/yNET27",
      "display_url" : "j.mp\/yNET27"
    } ]
  },
  "geo" : { },
  "id_str" : "155311839012593667",
  "text" : "On the history of tattoos and the pros & cons of getting a QR code-tattoo http:\/\/t.co\/H6MgYhFh",
  "id" : 155311839012593667,
  "created_at" : "2012-01-06 15:36:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 83 ],
      "url" : "http:\/\/t.co\/Kolm1KiI",
      "expanded_url" : "http:\/\/j.mp\/AvduH3",
      "display_url" : "j.mp\/AvduH3"
    } ]
  },
  "geo" : { },
  "id_str" : "155309004623581184",
  "text" : "Bei der ZEIT gibt es ein paar Fotos von  Vivian Maier zu sehen http:\/\/t.co\/Kolm1KiI",
  "id" : 155309004623581184,
  "created_at" : "2012-01-06 15:25:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/uSx8YxXp",
      "expanded_url" : "http:\/\/j.mp\/yYxnqr",
      "display_url" : "j.mp\/yYxnqr"
    } ]
  },
  "geo" : { },
  "id_str" : "155307143220830208",
  "text" : "Album Covers - Dead Artists http:\/\/t.co\/uSx8YxXp",
  "id" : 155307143220830208,
  "created_at" : "2012-01-06 15:18:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 52 ],
      "url" : "http:\/\/t.co\/yIMihz16",
      "expanded_url" : "http:\/\/j.mp\/xhpma7",
      "display_url" : "j.mp\/xhpma7"
    } ]
  },
  "geo" : { },
  "id_str" : "155306524338696196",
  "text" : "Fish mimics mimic octopus &lt;3 http:\/\/t.co\/yIMihz16",
  "id" : 155306524338696196,
  "created_at" : "2012-01-06 15:15:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "155300621652729857",
  "text" : "Mist, mit dem vorl\u00E4ufigen Lieferdatum war nur gemeint, wann mein neuer Rechner in die EU kommt...",
  "id" : 155300621652729857,
  "created_at" : "2012-01-06 14:52:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Web of Stories",
      "screen_name" : "webofstories",
      "indices" : [ 3, 16 ],
      "id_str" : "143106740",
      "id" : 143106740
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "155272030676197376",
  "text" : "RT @webofstories: 06 January 1920: Birth of late biologist John Maynard Smith. Watch him talk about his wish to spend a day with Darwin. ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 119, 139 ],
        "url" : "http:\/\/t.co\/RxANGlJl",
        "expanded_url" : "http:\/\/www.webofstories.com\/play\/7348",
        "display_url" : "webofstories.com\/play\/7348"
      } ]
    },
    "geo" : { },
    "id_str" : "155269402806329345",
    "text" : "06 January 1920: Birth of late biologist John Maynard Smith. Watch him talk about his wish to spend a day with Darwin. http:\/\/t.co\/RxANGlJl",
    "id" : 155269402806329345,
    "created_at" : "2012-01-06 12:48:05 +0000",
    "user" : {
      "name" : "Web of Stories",
      "screen_name" : "webofstories",
      "protected" : false,
      "id_str" : "143106740",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1247177870\/logo_2010_normal.png",
      "id" : 143106740,
      "verified" : false
    }
  },
  "id" : 155272030676197376,
  "created_at" : "2012-01-06 12:58:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dieter McDevitt",
      "screen_name" : "Mrcalvinhobbes",
      "indices" : [ 0, 15 ],
      "id_str" : "21339038",
      "id" : 21339038
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "155197993077850112",
  "geo" : { },
  "id_str" : "155252725402177536",
  "in_reply_to_user_id" : 21339038,
  "text" : "@Mrcalvinhobbes Scheint ein Montagsger\u00E4t zu sein. Lasse mir Ersatz kommen.",
  "id" : 155252725402177536,
  "in_reply_to_status_id" : 155197993077850112,
  "created_at" : "2012-01-06 11:41:48 +0000",
  "in_reply_to_screen_name" : "Mrcalvinhobbes",
  "in_reply_to_user_id_str" : "21339038",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dieter McDevitt",
      "screen_name" : "Mrcalvinhobbes",
      "indices" : [ 0, 15 ],
      "id_str" : "21339038",
      "id" : 21339038
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "155197993077850112",
  "geo" : { },
  "id_str" : "155204590931935232",
  "in_reply_to_user_id" : 21339038,
  "text" : "@Mrcalvinhobbes noch steht er an seiner Base und l\u00E4dt. Ich lass ihn sp\u00E4ter mal fahren.",
  "id" : 155204590931935232,
  "in_reply_to_status_id" : 155197993077850112,
  "created_at" : "2012-01-06 08:30:32 +0000",
  "in_reply_to_screen_name" : "Mrcalvinhobbes",
  "in_reply_to_user_id_str" : "21339038",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Turner",
      "screen_name" : "genetics_blog",
      "indices" : [ 0, 14 ],
      "id_str" : "923639552874557440",
      "id" : 923639552874557440
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "155066207177932800",
  "geo" : { },
  "id_str" : "155066518403678208",
  "in_reply_to_user_id" : 20444825,
  "text" : "@genetics_blog This would be great for us at openSNP, but I think SNPedia already does a great job on that, especially with Promethease.",
  "id" : 155066518403678208,
  "in_reply_to_status_id" : 155066207177932800,
  "created_at" : "2012-01-05 23:21:53 +0000",
  "in_reply_to_screen_name" : "strnr",
  "in_reply_to_user_id_str" : "20444825",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 100 ],
      "url" : "http:\/\/t.co\/zogWzBgN",
      "expanded_url" : "http:\/\/j.mp\/yOGClB",
      "display_url" : "j.mp\/yOGClB"
    } ]
  },
  "geo" : { },
  "id_str" : "155044797290262528",
  "text" : "Instant Messaging: No substitute for voice communication. At least hormon-wise. http:\/\/t.co\/zogWzBgN",
  "id" : 155044797290262528,
  "created_at" : "2012-01-05 21:55:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 40 ],
      "url" : "http:\/\/t.co\/0uoKTBQR",
      "expanded_url" : "http:\/\/j.mp\/wXDemY",
      "display_url" : "j.mp\/wXDemY"
    } ]
  },
  "geo" : { },
  "id_str" : "155043320815550464",
  "text" : "Our evil overlords! http:\/\/t.co\/0uoKTBQR",
  "id" : 155043320815550464,
  "created_at" : "2012-01-05 21:49:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "li5a",
      "screen_name" : "li5a",
      "indices" : [ 0, 5 ],
      "id_str" : "11712822",
      "id" : 11712822
    }, {
      "name" : "Brad Voytek",
      "screen_name" : "bradleyvoytek",
      "indices" : [ 6, 20 ],
      "id_str" : "162535413",
      "id" : 162535413
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "155036764493455360",
  "geo" : { },
  "id_str" : "155037069218021376",
  "in_reply_to_user_id" : 11712822,
  "text" : "@li5a @bradleyvoytek well, up to now I'm of quite lucky. No 60+h weeks yet ;)",
  "id" : 155037069218021376,
  "in_reply_to_status_id" : 155036764493455360,
  "created_at" : "2012-01-05 21:24:52 +0000",
  "in_reply_to_screen_name" : "li5a",
  "in_reply_to_user_id_str" : "11712822",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 82 ],
      "url" : "https:\/\/t.co\/x6Gwe1QM",
      "expanded_url" : "https:\/\/opensnp.org",
      "display_url" : "opensnp.org"
    } ]
  },
  "geo" : { },
  "id_str" : "155008588010618880",
  "text" : "Whoops, for some unknown reason our Mendeley\/PLoS-crawler at https:\/\/t.co\/x6Gwe1QM stopped. Should be back up again.",
  "id" : 155008588010618880,
  "created_at" : "2012-01-05 19:31:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brad Voytek",
      "screen_name" : "bradleyvoytek",
      "indices" : [ 0, 14 ],
      "id_str" : "162535413",
      "id" : 162535413
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "154996393084325888",
  "geo" : { },
  "id_str" : "154996600228429824",
  "in_reply_to_user_id" : 162535413,
  "text" : "@bradleyvoytek Thanks for collecting all the reasons ;-)",
  "id" : 154996600228429824,
  "in_reply_to_status_id" : 154996393084325888,
  "created_at" : "2012-01-05 18:44:03 +0000",
  "in_reply_to_screen_name" : "bradleyvoytek",
  "in_reply_to_user_id_str" : "162535413",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leonid Kruglyak",
      "screen_name" : "leonidkruglyak",
      "indices" : [ 123, 138 ],
      "id_str" : "19416598",
      "id" : 19416598
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 112 ],
      "url" : "http:\/\/t.co\/bSKNwsL3",
      "expanded_url" : "http:\/\/bit.ly\/x3bNSd",
      "display_url" : "bit.ly\/x3bNSd"
    } ]
  },
  "geo" : { },
  "id_str" : "154993772814548992",
  "text" : "Working in Academia.. Isn't it beautiful? [God, I should kill myself after reading this...] http:\/\/t.co\/bSKNwsL3 \/Link via @leonidkruglyak",
  "id" : 154993772814548992,
  "created_at" : "2012-01-05 18:32:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Henklein",
      "screen_name" : "snooze82",
      "indices" : [ 0, 9 ],
      "id_str" : "14094265",
      "id" : 14094265
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "154971860570877953",
  "geo" : { },
  "id_str" : "154972338545373184",
  "in_reply_to_user_id" : 14094265,
  "text" : "@snooze82 jetzt bin ich neidisch. ;)",
  "id" : 154972338545373184,
  "in_reply_to_status_id" : 154971860570877953,
  "created_at" : "2012-01-05 17:07:39 +0000",
  "in_reply_to_screen_name" : "snooze82",
  "in_reply_to_user_id_str" : "14094265",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ewen Callaway",
      "screen_name" : "ewencallaway",
      "indices" : [ 3, 16 ],
      "id_str" : "17251787",
      "id" : 17251787
    }, {
      "name" : "John Hawks",
      "screen_name" : "johnhawks",
      "indices" : [ 90, 100 ],
      "id_str" : "52584039",
      "id" : 52584039
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 121 ],
      "url" : "http:\/\/t.co\/7mNtEidu",
      "expanded_url" : "http:\/\/bit.ly\/yk5I9k",
      "display_url" : "bit.ly\/yk5I9k"
    } ]
  },
  "geo" : { },
  "id_str" : "154955269871386624",
  "text" : "RT @ewencallaway: Nature Genetics says submit (most of) your GWAS elsewhere. Nice post by @johnhawks http:\/\/t.co\/7mNtEidu",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/chrome.google.com\/extensions\/detail\/encaiiljifbdbjlphpgpiimidegddhic\" rel=\"nofollow\"\u003ESilver Bird\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "John Hawks",
        "screen_name" : "johnhawks",
        "indices" : [ 72, 82 ],
        "id_str" : "52584039",
        "id" : 52584039
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 83, 103 ],
        "url" : "http:\/\/t.co\/7mNtEidu",
        "expanded_url" : "http:\/\/bit.ly\/yk5I9k",
        "display_url" : "bit.ly\/yk5I9k"
      } ]
    },
    "geo" : { },
    "id_str" : "154863448193372160",
    "text" : "Nature Genetics says submit (most of) your GWAS elsewhere. Nice post by @johnhawks http:\/\/t.co\/7mNtEidu",
    "id" : 154863448193372160,
    "created_at" : "2012-01-05 09:54:57 +0000",
    "user" : {
      "name" : "Ewen Callaway",
      "screen_name" : "ewencallaway",
      "protected" : false,
      "id_str" : "17251787",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/905426585880289282\/-Fg5BkEr_normal.jpg",
      "id" : 17251787,
      "verified" : true
    }
  },
  "id" : 154955269871386624,
  "created_at" : "2012-01-05 15:59:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "sickipediabot",
      "screen_name" : "sickipediabot",
      "indices" : [ 3, 17 ],
      "id_str" : "157627966",
      "id" : 157627966
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "154946017656180736",
  "text" : "RT @sickipediabot: Scientist - My findings are pointless when taken out of context.\n\nMedia - Scientist claims \"findings are pointless\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/sickipediabot\" rel=\"nofollow\"\u003Esickipediabot\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "154837195180617728",
    "text" : "Scientist - My findings are pointless when taken out of context.\n\nMedia - Scientist claims \"findings are pointless\"",
    "id" : 154837195180617728,
    "created_at" : "2012-01-05 08:10:38 +0000",
    "user" : {
      "name" : "sickipediabot",
      "screen_name" : "sickipediabot",
      "protected" : false,
      "id_str" : "157627966",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2024564220\/tumblr_ljbd1lUfT21qb1nat_normal.png",
      "id" : 157627966,
      "verified" : false
    }
  },
  "id" : 154946017656180736,
  "created_at" : "2012-01-05 15:23:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DetritusBlog",
      "screen_name" : "gedankenabfall",
      "indices" : [ 0, 15 ],
      "id_str" : "2175883684",
      "id" : 2175883684
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "154943977718693888",
  "geo" : { },
  "id_str" : "154944227766312960",
  "in_reply_to_user_id" : 29082973,
  "text" : "@gedankenabfall wird im Handbuch beschrieben. Ich geb ihm mal 24h zum Laden. Mal schauen was dann passiert.",
  "id" : 154944227766312960,
  "in_reply_to_status_id" : 154943977718693888,
  "created_at" : "2012-01-05 15:15:57 +0000",
  "in_reply_to_screen_name" : "ballaschk",
  "in_reply_to_user_id_str" : "29082973",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DetritusBlog",
      "screen_name" : "gedankenabfall",
      "indices" : [ 0, 15 ],
      "id_str" : "2175883684",
      "id" : 2175883684
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "154943717244026880",
  "geo" : { },
  "id_str" : "154943944898252800",
  "in_reply_to_user_id" : 29082973,
  "text" : "@gedankenabfall schnelles orangenes leuchten anstatt langsames. ;)",
  "id" : 154943944898252800,
  "in_reply_to_status_id" : 154943717244026880,
  "created_at" : "2012-01-05 15:14:49 +0000",
  "in_reply_to_screen_name" : "ballaschk",
  "in_reply_to_user_id_str" : "29082973",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DetritusBlog",
      "screen_name" : "gedankenabfall",
      "indices" : [ 0, 15 ],
      "id_str" : "2175883684",
      "id" : 2175883684
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "154943606233378817",
  "geo" : { },
  "id_str" : "154943822365868032",
  "in_reply_to_user_id" : 29082973,
  "text" : "@gedankenabfall ok \u00DCN hatte ich auch probiert. Ist dann aber heute Mittag vor\/zur\u00FCck fahrend auf der Stelle verendet. ;)",
  "id" : 154943822365868032,
  "in_reply_to_status_id" : 154943606233378817,
  "created_at" : "2012-01-05 15:14:20 +0000",
  "in_reply_to_screen_name" : "ballaschk",
  "in_reply_to_user_id_str" : "29082973",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DetritusBlog",
      "screen_name" : "gedankenabfall",
      "indices" : [ 0, 15 ],
      "id_str" : "2175883684",
      "id" : 2175883684
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "154942817918140416",
  "geo" : { },
  "id_str" : "154943406991360001",
  "in_reply_to_user_id" : 29082973,
  "text" : "@gedankenabfall eine andere Frage: Wie lang muss man den Roomba Initial so Laden? Er will immer in den langen Lademodus.",
  "id" : 154943406991360001,
  "in_reply_to_status_id" : 154942817918140416,
  "created_at" : "2012-01-05 15:12:41 +0000",
  "in_reply_to_screen_name" : "ballaschk",
  "in_reply_to_user_id_str" : "29082973",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DNAbarcode",
      "indices" : [ 107, 118 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 106 ],
      "url" : "http:\/\/t.co\/65hue5LD",
      "expanded_url" : "http:\/\/itunes.apple.com\/us\/app\/dna-barcoding-assistant\/id477080376?mt=8",
      "display_url" : "itunes.apple.com\/us\/app\/dna-bar\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "154939368392495104",
  "text" : "RT @Megan_BOLD: DNA Barcoding Assistant App for iPhone is now free in the app store!  http:\/\/t.co\/65hue5LD #DNAbarcode",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "DNAbarcode",
        "indices" : [ 91, 102 ]
      } ],
      "urls" : [ {
        "indices" : [ 70, 90 ],
        "url" : "http:\/\/t.co\/65hue5LD",
        "expanded_url" : "http:\/\/itunes.apple.com\/us\/app\/dna-barcoding-assistant\/id477080376?mt=8",
        "display_url" : "itunes.apple.com\/us\/app\/dna-bar\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "154926441421733888",
    "text" : "DNA Barcoding Assistant App for iPhone is now free in the app store!  http:\/\/t.co\/65hue5LD #DNAbarcode",
    "id" : 154926441421733888,
    "created_at" : "2012-01-05 14:05:16 +0000",
    "user" : {
      "name" : "Megan Milton",
      "screen_name" : "Megan_Meantime",
      "protected" : false,
      "id_str" : "60932439",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/895782338516406272\/0b7dfEcw_normal.jpg",
      "id" : 60932439,
      "verified" : false
    }
  },
  "id" : 154939368392495104,
  "created_at" : "2012-01-05 14:56:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Henklein",
      "screen_name" : "snooze82",
      "indices" : [ 0, 9 ],
      "id_str" : "14094265",
      "id" : 14094265
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "154922391326310400",
  "geo" : { },
  "id_str" : "154922868361281537",
  "in_reply_to_user_id" : 14094265,
  "text" : "@snooze82 danke!",
  "id" : 154922868361281537,
  "in_reply_to_status_id" : 154922391326310400,
  "created_at" : "2012-01-05 13:51:04 +0000",
  "in_reply_to_screen_name" : "snooze82",
  "in_reply_to_user_id_str" : "14094265",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Henklein",
      "screen_name" : "snooze82",
      "indices" : [ 0, 9 ],
      "id_str" : "14094265",
      "id" : 14094265
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "154921488514953217",
  "geo" : { },
  "id_str" : "154922182013747200",
  "in_reply_to_user_id" : 14094265,
  "text" : "@snooze82 ich denk das f\u00E4llt komplett flach. Bin auch noch krank.",
  "id" : 154922182013747200,
  "in_reply_to_status_id" : 154921488514953217,
  "created_at" : "2012-01-05 13:48:21 +0000",
  "in_reply_to_screen_name" : "snooze82",
  "in_reply_to_user_id_str" : "14094265",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.flipboard.com\" rel=\"nofollow\"\u003EFlipboard\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "New Scientist",
      "screen_name" : "newscientist",
      "indices" : [ 3, 16 ],
      "id_str" : "19658826",
      "id" : 19658826
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 113 ],
      "url" : "http:\/\/t.co\/f4hA9SwJ",
      "expanded_url" : "http:\/\/bit.ly\/rQVjQc",
      "display_url" : "bit.ly\/rQVjQc"
    } ]
  },
  "geo" : { },
  "id_str" : "154916694861684736",
  "text" : "RT @newscientist: What does a Norwegian beach carpetted in 20 tonnes of dead fish look like? http:\/\/t.co\/f4hA9SwJ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 75, 95 ],
        "url" : "http:\/\/t.co\/f4hA9SwJ",
        "expanded_url" : "http:\/\/bit.ly\/rQVjQc",
        "display_url" : "bit.ly\/rQVjQc"
      } ]
    },
    "geo" : { },
    "id_str" : "154212553420062720",
    "text" : "What does a Norwegian beach carpetted in 20 tonnes of dead fish look like? http:\/\/t.co\/f4hA9SwJ",
    "id" : 154212553420062720,
    "created_at" : "2012-01-03 14:48:32 +0000",
    "user" : {
      "name" : "New Scientist",
      "screen_name" : "newscientist",
      "protected" : false,
      "id_str" : "19658826",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/843789564074496001\/m34mTHmg_normal.jpg",
      "id" : 19658826,
      "verified" : true
    }
  },
  "id" : 154916694861684736,
  "created_at" : "2012-01-05 13:26:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dieter McDevitt",
      "screen_name" : "Mrcalvinhobbes",
      "indices" : [ 0, 15 ],
      "id_str" : "21339038",
      "id" : 21339038
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "154897956988923904",
  "geo" : { },
  "id_str" : "154902785626877952",
  "in_reply_to_user_id" : 21339038,
  "text" : "@Mrcalvinhobbes momentan h\u00F6rt er einfach auf zu fahren und f\u00E4hrt auf der Stelle etwas vor und zur\u00FCck und verendet da.",
  "id" : 154902785626877952,
  "in_reply_to_status_id" : 154897956988923904,
  "created_at" : "2012-01-05 12:31:16 +0000",
  "in_reply_to_screen_name" : "Mrcalvinhobbes",
  "in_reply_to_user_id_str" : "21339038",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dieter McDevitt",
      "screen_name" : "Mrcalvinhobbes",
      "indices" : [ 0, 15 ],
      "id_str" : "21339038",
      "id" : 21339038
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "154892446860460032",
  "geo" : { },
  "id_str" : "154892633850916864",
  "in_reply_to_user_id" : 21339038,
  "text" : "@Mrcalvinhobbes ich bin noch gespannt ob er es am Ende wieder auf die Ladeplattform schafft ;)",
  "id" : 154892633850916864,
  "in_reply_to_status_id" : 154892446860460032,
  "created_at" : "2012-01-05 11:50:56 +0000",
  "in_reply_to_screen_name" : "Mrcalvinhobbes",
  "in_reply_to_user_id_str" : "21339038",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "154892279310589952",
  "text" : "Akut kostet der Roomba mehr Zeit als er spart. Sitze gebannt vor den Ding und schau ihm beim putzen zu.",
  "id" : 154892279310589952,
  "created_at" : "2012-01-05 11:49:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonas",
      "screen_name" : "lsanoj",
      "indices" : [ 0, 7 ],
      "id_str" : "18918915",
      "id" : 18918915
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 8, 17 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "154891691017502720",
  "geo" : { },
  "id_str" : "154891928012455936",
  "in_reply_to_user_id" : 18918915,
  "text" : "@lsanoj @Senficon macht das immer umgekehrt ;)",
  "id" : 154891928012455936,
  "in_reply_to_status_id" : 154891691017502720,
  "created_at" : "2012-01-05 11:48:08 +0000",
  "in_reply_to_screen_name" : "lsanoj",
  "in_reply_to_user_id_str" : "18918915",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Wicks",
      "screen_name" : "PaulLikeMe",
      "indices" : [ 0, 11 ],
      "id_str" : "375875836",
      "id" : 375875836
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "154877792759201793",
  "geo" : { },
  "id_str" : "154878445707460608",
  "in_reply_to_user_id" : 375875836,
  "text" : "@PaulLikeMe I know. It was supposed to be a joke ;)",
  "id" : 154878445707460608,
  "in_reply_to_status_id" : 154877792759201793,
  "created_at" : "2012-01-05 10:54:33 +0000",
  "in_reply_to_screen_name" : "PaulLikeMe",
  "in_reply_to_user_id_str" : "375875836",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ian Holmes",
      "screen_name" : "ianholmes",
      "indices" : [ 115, 125 ],
      "id_str" : "7079752",
      "id" : 7079752
    }, {
      "name" : "Jonathan Eisen, Guardian of Microbial Diversity \uD83D\uDCA5\uD83D\uDD06",
      "screen_name" : "phylogenomics",
      "indices" : [ 126, 140 ],
      "id_str" : "15154811",
      "id" : 15154811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 80 ],
      "url" : "http:\/\/t.co\/RBoqvzCq",
      "expanded_url" : "http:\/\/biowiki.org\/FileFormatDesign",
      "display_url" : "biowiki.org\/FileFormatDesi\u2026"
    }, {
      "indices" : [ 83, 103 ],
      "url" : "http:\/\/t.co\/sApq4Z0f",
      "expanded_url" : "http:\/\/fb.me\/1fzHqA0HN",
      "display_url" : "fb.me\/1fzHqA0HN"
    } ]
  },
  "geo" : { },
  "id_str" : "154872082595971072",
  "text" : "What's wrong with bioinformatics software and file formats: http:\/\/t.co\/RBoqvzCq & http:\/\/t.co\/sApq4Z0f \/links via @ianholmes @phylogenomics",
  "id" : 154872082595971072,
  "created_at" : "2012-01-05 10:29:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 132 ],
      "url" : "http:\/\/t.co\/DEz9OGNv",
      "expanded_url" : "http:\/\/j.mp\/zZm6x5",
      "display_url" : "j.mp\/zZm6x5"
    } ]
  },
  "geo" : { },
  "id_str" : "154867613531516929",
  "text" : "A Walkthrough To Find Credible Souces and Answers to the Controversies of Vaccines, Evolution, Holocaust et al. http:\/\/t.co\/DEz9OGNv",
  "id" : 154867613531516929,
  "created_at" : "2012-01-05 10:11:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 80 ],
      "url" : "http:\/\/t.co\/m5ZIgLz1",
      "expanded_url" : "http:\/\/j.mp\/xHllF3",
      "display_url" : "j.mp\/xHllF3"
    } ]
  },
  "geo" : { },
  "id_str" : "154866528871923712",
  "text" : "When your wife becomes your daughter: Datamining gone wrong http:\/\/t.co\/m5ZIgLz1",
  "id" : 154866528871923712,
  "created_at" : "2012-01-05 10:07:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "openSNP team",
      "screen_name" : "openSNPorg",
      "indices" : [ 3, 14 ],
      "id_str" : "380205172",
      "id" : 380205172
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 115 ],
      "url" : "https:\/\/t.co\/eEw4JyH0",
      "expanded_url" : "https:\/\/opensnp.org\/",
      "display_url" : "opensnp.org"
    } ]
  },
  "geo" : { },
  "id_str" : "154860532254523392",
  "text" : "RT @openSNPorg: Finally: You can use SSL to connect to openSNP using an encrypted connection! https:\/\/t.co\/eEw4JyH0",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 78, 99 ],
        "url" : "https:\/\/t.co\/eEw4JyH0",
        "expanded_url" : "https:\/\/opensnp.org\/",
        "display_url" : "opensnp.org"
      } ]
    },
    "geo" : { },
    "id_str" : "154860372753530880",
    "text" : "Finally: You can use SSL to connect to openSNP using an encrypted connection! https:\/\/t.co\/eEw4JyH0",
    "id" : 154860372753530880,
    "created_at" : "2012-01-05 09:42:44 +0000",
    "user" : {
      "name" : "openSNP team",
      "screen_name" : "openSNPorg",
      "protected" : false,
      "id_str" : "380205172",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/735374825187909632\/wJEJW1zW_normal.jpg",
      "id" : 380205172,
      "verified" : false
    }
  },
  "id" : 154860532254523392,
  "created_at" : "2012-01-05 09:43:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jan Ortmann",
      "screen_name" : "jojonks",
      "indices" : [ 0, 8 ],
      "id_str" : "3564398897",
      "id" : 3564398897
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "154856251166175232",
  "text" : "@jojonks Gl\u00FCckwunsch, wo geht es hin?",
  "id" : 154856251166175232,
  "created_at" : "2012-01-05 09:26:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PatientsLikeMe",
      "screen_name" : "patientslikeme",
      "indices" : [ 0, 15 ],
      "id_str" : "16933716",
      "id" : 16933716
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 52 ],
      "url" : "http:\/\/t.co\/bL9ESPUS",
      "expanded_url" : "http:\/\/j.mp\/zacjvM",
      "display_url" : "j.mp\/zacjvM"
    } ]
  },
  "in_reply_to_status_id_str" : "154713490911801345",
  "geo" : { },
  "id_str" : "154855639200440320",
  "in_reply_to_user_id" : 16933716,
  "text" : "@patientslikeme it's about this http:\/\/t.co\/bL9ESPUS study and that one could crowdsource a larger follow-up ;)",
  "id" : 154855639200440320,
  "in_reply_to_status_id" : 154713490911801345,
  "created_at" : "2012-01-05 09:23:56 +0000",
  "in_reply_to_screen_name" : "patientslikeme",
  "in_reply_to_user_id_str" : "16933716",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 0, 10 ],
      "id_str" : "14700783",
      "id" : 14700783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "154848334824226816",
  "geo" : { },
  "id_str" : "154855440545611776",
  "in_reply_to_user_id" : 14700783,
  "text" : "@Fischblog hab irgendwo auch mal geh\u00F6rt das es Alzheimer verlangsamen soll(?)",
  "id" : 154855440545611776,
  "in_reply_to_status_id" : 154848334824226816,
  "created_at" : "2012-01-05 09:23:08 +0000",
  "in_reply_to_screen_name" : "Fischblog",
  "in_reply_to_user_id_str" : "14700783",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Hawks",
      "screen_name" : "johnhawks",
      "indices" : [ 3, 13 ],
      "id_str" : "52584039",
      "id" : 52584039
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "154854954207686656",
  "text" : "RT @johnhawks: Just received word that James F. Crow died last night. Maybe the most important living population geneticist, he was 95.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "154663119396937728",
    "text" : "Just received word that James F. Crow died last night. Maybe the most important living population geneticist, he was 95.",
    "id" : 154663119396937728,
    "created_at" : "2012-01-04 20:38:55 +0000",
    "user" : {
      "name" : "John Hawks",
      "screen_name" : "johnhawks",
      "protected" : false,
      "id_str" : "52584039",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2162500613\/scio12-0442-jhawks-twitter-focus_normal.jpg",
      "id" : 52584039,
      "verified" : false
    }
  },
  "id" : 154854954207686656,
  "created_at" : "2012-01-05 09:21:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "154696006141870080",
  "geo" : { },
  "id_str" : "154696241140342784",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer same here, lets go for it :)",
  "id" : 154696241140342784,
  "in_reply_to_status_id" : 154696006141870080,
  "created_at" : "2012-01-04 22:50:32 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "154694606787854337",
  "geo" : { },
  "id_str" : "154695805024997376",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer looks like twitters url-shortener removes http and www. So what do you prefer: with www or without?",
  "id" : 154695805024997376,
  "in_reply_to_status_id" : 154694606787854337,
  "created_at" : "2012-01-04 22:48:48 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kerri Hicks",
      "screen_name" : "kerri9494",
      "indices" : [ 20, 30 ],
      "id_str" : "1516611",
      "id" : 1516611
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 124 ],
      "url" : "http:\/\/t.co\/0D3OCAZD",
      "expanded_url" : "http:\/\/yfrog.com\/klwigwdj",
      "display_url" : "yfrog.com\/klwigwdj"
    } ]
  },
  "geo" : { },
  "id_str" : "154694269855215618",
  "text" : "For pony lovers: RT @kerri9494: This is, quite possibly, the best New York Times correction in history. http:\/\/t.co\/0D3OCAZD",
  "id" : 154694269855215618,
  "created_at" : "2012-01-04 22:42:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "154693003028602881",
  "geo" : { },
  "id_str" : "154694064304951296",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer joah, bzw. halt nicht auskuriert sondern ja gestern gleich wieder unterwegs",
  "id" : 154694064304951296,
  "in_reply_to_status_id" : 154693003028602881,
  "created_at" : "2012-01-04 22:41:53 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "154690826478424064",
  "geo" : { },
  "id_str" : "154691527099158528",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer that's what I thought. I have some stuff for university which needs to be done (if I can leave my bed again..)",
  "id" : 154691527099158528,
  "in_reply_to_status_id" : 154690826478424064,
  "created_at" : "2012-01-04 22:31:48 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "154687783687045121",
  "geo" : { },
  "id_str" : "154688151099682817",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer but: if you made it through configuration-hell you could start working on ssl ;)",
  "id" : 154688151099682817,
  "in_reply_to_status_id" : 154687783687045121,
  "created_at" : "2012-01-04 22:18:23 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "154687783687045121",
  "geo" : { },
  "id_str" : "154687978457931776",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer yeah, basically the whole dependencies-stuff outside of bundler sucks",
  "id" : 154687978457931776,
  "in_reply_to_status_id" : 154687783687045121,
  "created_at" : "2012-01-04 22:17:42 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "154687366169247744",
  "geo" : { },
  "id_str" : "154687609732464643",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer can't wait to perform this after the macosx 10.6 -&gt; 10.7 update :(",
  "id" : 154687609732464643,
  "in_reply_to_status_id" : 154687366169247744,
  "created_at" : "2012-01-04 22:16:14 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cae Vye",
      "screen_name" : "CaeVye",
      "indices" : [ 0, 7 ],
      "id_str" : "31104704",
      "id" : 31104704
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "154675420636250112",
  "geo" : { },
  "id_str" : "154676424215756800",
  "in_reply_to_user_id" : 31104704,
  "text" : "@CaeVye das kann man ja auch ganz ohne Mittel als Patient-Driven Research umsetzen. Vielleicht auf PatientsLikeMe. ;)",
  "id" : 154676424215756800,
  "in_reply_to_status_id" : 154675420636250112,
  "created_at" : "2012-01-04 21:31:47 +0000",
  "in_reply_to_screen_name" : "CaeVye",
  "in_reply_to_user_id_str" : "31104704",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 51 ],
      "url" : "http:\/\/t.co\/bL9ESPUS",
      "expanded_url" : "http:\/\/j.mp\/zacjvM",
      "display_url" : "j.mp\/zacjvM"
    } ]
  },
  "geo" : { },
  "id_str" : "154671935366770689",
  "text" : "Hot Sex Prevents Breast Cancer http:\/\/t.co\/bL9ESPUS",
  "id" : 154671935366770689,
  "created_at" : "2012-01-04 21:13:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jacquelyn Gill",
      "screen_name" : "JacquelynGill",
      "indices" : [ 3, 17 ],
      "id_str" : "112475924",
      "id" : 112475924
    }, {
      "name" : "Founder - Alan M",
      "screen_name" : "BenchFly",
      "indices" : [ 22, 31 ],
      "id_str" : "20707999",
      "id" : 20707999
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 121 ],
      "url" : "http:\/\/t.co\/9OF3o3G7",
      "expanded_url" : "http:\/\/bit.ly\/xb6lTY",
      "display_url" : "bit.ly\/xb6lTY"
    } ]
  },
  "geo" : { },
  "id_str" : "154666236058419200",
  "text" : "RT @JacquelynGill: RT @BenchFly: Finally, resolutions we can actually keep! New Year's Lab-olutions: http:\/\/t.co\/9OF3o3G7",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Founder - Alan M",
        "screen_name" : "BenchFly",
        "indices" : [ 3, 12 ],
        "id_str" : "20707999",
        "id" : 20707999
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 82, 102 ],
        "url" : "http:\/\/t.co\/9OF3o3G7",
        "expanded_url" : "http:\/\/bit.ly\/xb6lTY",
        "display_url" : "bit.ly\/xb6lTY"
      } ]
    },
    "geo" : { },
    "id_str" : "154663780750589952",
    "text" : "RT @BenchFly: Finally, resolutions we can actually keep! New Year's Lab-olutions: http:\/\/t.co\/9OF3o3G7",
    "id" : 154663780750589952,
    "created_at" : "2012-01-04 20:41:33 +0000",
    "user" : {
      "name" : "Jacquelyn Gill",
      "screen_name" : "JacquelynGill",
      "protected" : false,
      "id_str" : "112475924",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/816027573343965184\/qUfIq3xY_normal.jpg",
      "id" : 112475924,
      "verified" : true
    }
  },
  "id" : 154666236058419200,
  "created_at" : "2012-01-04 20:51:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kollektiv Raufaser",
      "screen_name" : "insideX",
      "indices" : [ 0, 8 ],
      "id_str" : "14857351",
      "id" : 14857351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "154650373393625090",
  "geo" : { },
  "id_str" : "154654055115919360",
  "in_reply_to_user_id" : 14857351,
  "text" : "@insideX ich vermute den muss man einfach regelm\u00E4ssig  fahren lassen.",
  "id" : 154654055115919360,
  "in_reply_to_status_id" : 154650373393625090,
  "created_at" : "2012-01-04 20:02:54 +0000",
  "in_reply_to_screen_name" : "insideX",
  "in_reply_to_user_id_str" : "14857351",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Henklein",
      "screen_name" : "snooze82",
      "indices" : [ 0, 9 ],
      "id_str" : "14094265",
      "id" : 14094265
    }, {
      "name" : "Kollektiv Raufaser",
      "screen_name" : "insideX",
      "indices" : [ 10, 18 ],
      "id_str" : "14857351",
      "id" : 14857351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "154652739358556160",
  "geo" : { },
  "id_str" : "154653853902585857",
  "in_reply_to_user_id" : 14094265,
  "text" : "@snooze82 @insideX scheint noch nicht so weit zu sein ;)",
  "id" : 154653853902585857,
  "in_reply_to_status_id" : 154652739358556160,
  "created_at" : "2012-01-04 20:02:06 +0000",
  "in_reply_to_screen_name" : "snooze82",
  "in_reply_to_user_id_str" : "14094265",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave-Kay",
      "screen_name" : "Dave_Kay",
      "indices" : [ 0, 9 ],
      "id_str" : "10487642",
      "id" : 10487642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "154650335468720128",
  "geo" : { },
  "id_str" : "154650582869745664",
  "in_reply_to_user_id" : 10487642,
  "text" : "@Dave_Kay Puh, 581 glaube ich.",
  "id" : 154650582869745664,
  "in_reply_to_status_id" : 154650335468720128,
  "created_at" : "2012-01-04 19:49:06 +0000",
  "in_reply_to_screen_name" : "Dave_Kay",
  "in_reply_to_user_id_str" : "10487642",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "steffi",
      "screen_name" : "guerillagirl_",
      "indices" : [ 0, 14 ],
      "id_str" : "17117819",
      "id" : 17117819
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "154650038319067136",
  "geo" : { },
  "id_str" : "154650483112411136",
  "in_reply_to_user_id" : 17117819,
  "text" : "@guerillagirl_ das ist ja auch endniedlich :)",
  "id" : 154650483112411136,
  "in_reply_to_status_id" : 154650038319067136,
  "created_at" : "2012-01-04 19:48:43 +0000",
  "in_reply_to_screen_name" : "guerillagirl_",
  "in_reply_to_user_id_str" : "17117819",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rya",
      "screen_name" : "_Rya_",
      "indices" : [ 0, 6 ],
      "id_str" : "89234537",
      "id" : 89234537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "154649900120940544",
  "geo" : { },
  "id_str" : "154650328061583360",
  "in_reply_to_user_id" : 89234537,
  "text" : "@_Rya_ Bislang sind sie mehr so indifferent. ;)",
  "id" : 154650328061583360,
  "in_reply_to_status_id" : 154649900120940544,
  "created_at" : "2012-01-04 19:48:06 +0000",
  "in_reply_to_screen_name" : "_Rya_",
  "in_reply_to_user_id_str" : "89234537",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kollektiv Raufaser",
      "screen_name" : "insideX",
      "indices" : [ 0, 8 ],
      "id_str" : "14857351",
      "id" : 14857351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "154648977986420736",
  "geo" : { },
  "id_str" : "154649801491873792",
  "in_reply_to_user_id" : 14857351,
  "text" : "@insideX wir liegen uns weinend in den Armen \u00ABNie wieder Staubsaugen!\u00BB",
  "id" : 154649801491873792,
  "in_reply_to_status_id" : 154648977986420736,
  "created_at" : "2012-01-04 19:46:00 +0000",
  "in_reply_to_screen_name" : "insideX",
  "in_reply_to_user_id_str" : "14857351",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "steffi",
      "screen_name" : "guerillagirl_",
      "indices" : [ 0, 14 ],
      "id_str" : "17117819",
      "id" : 17117819
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 46 ],
      "url" : "http:\/\/t.co\/t42LVz2f",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=_sFJugJPZZc&feature=youtube_gdata_player",
      "display_url" : "youtube.com\/watch?v=_sFJug\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "154648963608346624",
  "geo" : { },
  "id_str" : "154649573393039361",
  "in_reply_to_user_id" : 17117819,
  "text" : "@guerillagirl_ oder auch: http:\/\/t.co\/t42LVz2f :)",
  "id" : 154649573393039361,
  "in_reply_to_status_id" : 154648963608346624,
  "created_at" : "2012-01-04 19:45:06 +0000",
  "in_reply_to_screen_name" : "guerillagirl_",
  "in_reply_to_user_id_str" : "17117819",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "154648651396956160",
  "text" : "Already in love with the Roomba.",
  "id" : 154648651396956160,
  "created_at" : "2012-01-04 19:41:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rike MW",
      "screen_name" : "rike_mw",
      "indices" : [ 36, 44 ],
      "id_str" : "79192038",
      "id" : 79192038
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "booklovers",
      "indices" : [ 113, 124 ]
    } ],
    "urls" : [ {
      "indices" : [ 46, 66 ],
      "url" : "http:\/\/t.co\/Ytp8uf6d",
      "expanded_url" : "http:\/\/bookshelfporn.com\/",
      "display_url" : "bookshelfporn.com"
    } ]
  },
  "geo" : { },
  "id_str" : "154635839136206848",
  "text" : "In some years this will be gone: RT @rike_mw: http:\/\/t.co\/Ytp8uf6d ...I might sent in a photograph of my wall :) #booklovers",
  "id" : 154635839136206848,
  "created_at" : "2012-01-04 18:50:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 3, 16 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 121 ],
      "url" : "http:\/\/t.co\/nkR1rqrY",
      "expanded_url" : "http:\/\/www.theregister.co.uk\/2003\/09\/11\/bill_joys_greatest_gift\/print.html",
      "display_url" : "theregister.co.uk\/2003\/09\/11\/bil\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "154635443516874752",
  "text" : "RT @PhilippBayer: How vi was written for a world that doesn't exist anymore (but it's still awesome) http:\/\/t.co\/nkR1rqrY",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 83, 103 ],
        "url" : "http:\/\/t.co\/nkR1rqrY",
        "expanded_url" : "http:\/\/www.theregister.co.uk\/2003\/09\/11\/bill_joys_greatest_gift\/print.html",
        "display_url" : "theregister.co.uk\/2003\/09\/11\/bil\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "154632139252563969",
    "text" : "How vi was written for a world that doesn't exist anymore (but it's still awesome) http:\/\/t.co\/nkR1rqrY",
    "id" : 154632139252563969,
    "created_at" : "2012-01-04 18:35:49 +0000",
    "user" : {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "protected" : false,
      "id_str" : "121777206",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2013711027\/IMG_1088_normal.png",
      "id" : 121777206,
      "verified" : false
    }
  },
  "id" : 154635443516874752,
  "created_at" : "2012-01-04 18:48:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "li5a",
      "screen_name" : "li5a",
      "indices" : [ 0, 5 ],
      "id_str" : "11712822",
      "id" : 11712822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 118 ],
      "url" : "http:\/\/t.co\/V2hItZyX",
      "expanded_url" : "http:\/\/seqanswers.com\/wiki\/Software\/list",
      "display_url" : "seqanswers.com\/wiki\/Software\/\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "154600094094725122",
  "geo" : { },
  "id_str" : "154601655013355520",
  "in_reply_to_user_id" : 11712822,
  "text" : "@li5a hab bislang nur so homebrew-Zeug gearbeitet. Sonst gibt es hier noch eine praktische Liste: http:\/\/t.co\/V2hItZyX",
  "id" : 154601655013355520,
  "in_reply_to_status_id" : 154600094094725122,
  "created_at" : "2012-01-04 16:34:41 +0000",
  "in_reply_to_screen_name" : "li5a",
  "in_reply_to_user_id_str" : "11712822",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "li5a",
      "screen_name" : "li5a",
      "indices" : [ 0, 5 ],
      "id_str" : "11712822",
      "id" : 11712822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 6, 27 ],
      "url" : "https:\/\/t.co\/FyLvVlMX",
      "expanded_url" : "https:\/\/github.com\/gedankenstuecke\/bioinf-junk\/blob\/master\/snp_finder.py",
      "display_url" : "github.com\/gedankenstueck\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "154600094094725122",
  "geo" : { },
  "id_str" : "154601263563149312",
  "in_reply_to_user_id" : 11712822,
  "text" : "@li5a https:\/\/t.co\/FyLvVlMX nicht h\u00FCbsch, macht aber genau das mit frequency & depth aus BAM-Mappingalignments.",
  "id" : 154601263563149312,
  "in_reply_to_status_id" : 154600094094725122,
  "created_at" : "2012-01-04 16:33:08 +0000",
  "in_reply_to_screen_name" : "li5a",
  "in_reply_to_user_id_str" : "11712822",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "li5a",
      "screen_name" : "li5a",
      "indices" : [ 0, 5 ],
      "id_str" : "11712822",
      "id" : 11712822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "154600094094725122",
  "geo" : { },
  "id_str" : "154601144897900544",
  "in_reply_to_user_id" : 11712822,
  "text" : "@li5a sonst kann man mit PySAM auch selbst einfach etwas zusammenbasteln (\u00FCber min. depth of coverage & min. minor allele frequency)",
  "id" : 154601144897900544,
  "in_reply_to_status_id" : 154600094094725122,
  "created_at" : "2012-01-04 16:32:39 +0000",
  "in_reply_to_screen_name" : "li5a",
  "in_reply_to_user_id_str" : "11712822",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "li5a",
      "screen_name" : "li5a",
      "indices" : [ 0, 5 ],
      "id_str" : "11712822",
      "id" : 11712822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 94 ],
      "url" : "https:\/\/t.co\/3H61WQNN",
      "expanded_url" : "https:\/\/github.com\/tolotos\/fzsheffield",
      "display_url" : "github.com\/tolotos\/fzshef\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "154600094094725122",
  "geo" : { },
  "id_str" : "154600740533448704",
  "in_reply_to_user_id" : 11712822,
  "text" : "@li5a Fabian hat selbst einen ML-Approach umgesetzt, m\u00FCsste dieser sein: https:\/\/t.co\/3H61WQNN",
  "id" : 154600740533448704,
  "in_reply_to_status_id" : 154600094094725122,
  "created_at" : "2012-01-04 16:31:03 +0000",
  "in_reply_to_screen_name" : "li5a",
  "in_reply_to_user_id_str" : "11712822",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Zelnio",
      "screen_name" : "kzelnio",
      "indices" : [ 3, 11 ],
      "id_str" : "19202541",
      "id" : 19202541
    }, {
      "name" : "Smithsonian Magazine",
      "screen_name" : "SmithsonianMag",
      "indices" : [ 99, 114 ],
      "id_str" : "17998609",
      "id" : 17998609
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 94 ],
      "url" : "http:\/\/t.co\/Xg5AsZmI",
      "expanded_url" : "http:\/\/www.smithsonianmag.com\/history-archaeology\/Photos-The-Best-Facial-Hair-in-the-Civil-War.html",
      "display_url" : "smithsonianmag.com\/history-archae\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "154585441511813120",
  "text" : "RT @kzelnio: Who had the best civil war facial hair? Vote for your fave!  http:\/\/t.co\/Xg5AsZmI via @SmithsonianMag",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Smithsonian Magazine",
        "screen_name" : "SmithsonianMag",
        "indices" : [ 86, 101 ],
        "id_str" : "17998609",
        "id" : 17998609
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 61, 81 ],
        "url" : "http:\/\/t.co\/Xg5AsZmI",
        "expanded_url" : "http:\/\/www.smithsonianmag.com\/history-archaeology\/Photos-The-Best-Facial-Hair-in-the-Civil-War.html",
        "display_url" : "smithsonianmag.com\/history-archae\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "154584989978214401",
    "text" : "Who had the best civil war facial hair? Vote for your fave!  http:\/\/t.co\/Xg5AsZmI via @SmithsonianMag",
    "id" : 154584989978214401,
    "created_at" : "2012-01-04 15:28:28 +0000",
    "user" : {
      "name" : "Kevin Zelnio",
      "screen_name" : "kzelnio",
      "protected" : false,
      "id_str" : "19202541",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/847483816457285632\/b1frtSEL_normal.jpg",
      "id" : 19202541,
      "verified" : false
    }
  },
  "id" : 154585441511813120,
  "created_at" : "2012-01-04 15:30:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lukas Martini",
      "screen_name" : "lutoma",
      "indices" : [ 0, 7 ],
      "id_str" : "41419667",
      "id" : 41419667
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "154570119346003970",
  "geo" : { },
  "id_str" : "154570360350720001",
  "in_reply_to_user_id" : 41419667,
  "text" : "@lutoma Weil Twitter \"echte\" Mentions (@ als erstes Zeichen) nicht anzeigt wenn du der angeschriebenen Person nicht folgst.",
  "id" : 154570360350720001,
  "in_reply_to_status_id" : 154570119346003970,
  "created_at" : "2012-01-04 14:30:20 +0000",
  "in_reply_to_screen_name" : "lutoma",
  "in_reply_to_user_id_str" : "41419667",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "li5a",
      "screen_name" : "li5a",
      "indices" : [ 0, 5 ],
      "id_str" : "11712822",
      "id" : 11712822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "154564160007577601",
  "geo" : { },
  "id_str" : "154564517144174592",
  "in_reply_to_user_id" : 11712822,
  "text" : "@li5a aus was genau willst du denn callen? Assembly? Mapping?",
  "id" : 154564517144174592,
  "in_reply_to_status_id" : 154564160007577601,
  "created_at" : "2012-01-04 14:07:07 +0000",
  "in_reply_to_screen_name" : "li5a",
  "in_reply_to_user_id_str" : "11712822",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 115 ],
      "url" : "http:\/\/t.co\/VuscqTHo",
      "expanded_url" : "http:\/\/j.mp\/Atp93b",
      "display_url" : "j.mp\/Atp93b"
    } ]
  },
  "geo" : { },
  "id_str" : "154557349229641728",
  "text" : "Bayesian Variable Selection in Searching for Additive and Dominant Effects in Genome-Wide Data http:\/\/t.co\/VuscqTHo",
  "id" : 154557349229641728,
  "created_at" : "2012-01-04 13:38:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 56 ],
      "url" : "http:\/\/t.co\/457IBC7Z",
      "expanded_url" : "http:\/\/j.mp\/y5g2EZ",
      "display_url" : "j.mp\/y5g2EZ"
    } ]
  },
  "geo" : { },
  "id_str" : "154557175577067520",
  "text" : "Turning Text into Research Networks http:\/\/t.co\/457IBC7Z",
  "id" : 154557175577067520,
  "created_at" : "2012-01-04 13:37:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 28, 38 ],
      "id_str" : "14700783",
      "id" : 14700783
    }, {
      "name" : "Michael Horak",
      "screen_name" : "fatmike182",
      "indices" : [ 46, 57 ],
      "id_str" : "15271509",
      "id" : 15271509
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LOL",
      "indices" : [ 130, 134 ]
    }, {
      "text" : "ncbi",
      "indices" : [ 135, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 129 ],
      "url" : "http:\/\/t.co\/8fw6RKMB",
      "expanded_url" : "http:\/\/182.fm\/xcY8Gp",
      "display_url" : "182.fm\/xcY8Gp"
    } ]
  },
  "geo" : { },
  "id_str" : "154533821990187009",
  "text" : "Studienfall f\u00FCr openSNP? RT @Fischblog: ^^ RT @fatmike182: \"Sneezing induced by sexual ideation or orgasm: \" http:\/\/t.co\/8fw6RKMB #LOL #ncbi",
  "id" : 154533821990187009,
  "created_at" : "2012-01-04 12:05:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "154503748352344064",
  "text" : "Loop in a loop in a loop in a loop\u2026 What happens if I start coding before 10am...",
  "id" : 154503748352344064,
  "created_at" : "2012-01-04 10:05:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "154353033097117696",
  "text" : "\u00ABWeisst du wer dich noch lieb hat?\u00BB \u2014 \u00ABDIE NAZIS?!\u00BB \u2014 \u00ABDie K\u00E4tzchen...\u00BB",
  "id" : 154353033097117696,
  "created_at" : "2012-01-04 00:06:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Maximilian\u00E9 Elbmurf \u2013 bekannt aus dem Internet\u2122",
      "screen_name" : "frumble",
      "indices" : [ 0, 8 ],
      "id_str" : "16377175",
      "id" : 16377175
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "154352285605048322",
  "geo" : { },
  "id_str" : "154352758210834432",
  "in_reply_to_user_id" : 16377175,
  "text" : "@frumble ja, aber muss ich mich an deutsche gepflogenheiten halten, wenn ich ausl\u00E4ndische verwende?",
  "id" : 154352758210834432,
  "in_reply_to_status_id" : 154352285605048322,
  "created_at" : "2012-01-04 00:05:39 +0000",
  "in_reply_to_screen_name" : "frumble",
  "in_reply_to_user_id_str" : "16377175",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "154351695881707521",
  "geo" : { },
  "id_str" : "154351826098073600",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon verklag mich doch. Oder ruf die BILD an!",
  "id" : 154351826098073600,
  "in_reply_to_status_id" : 154351695881707521,
  "created_at" : "2012-01-04 00:01:57 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "siwoti",
      "indices" : [ 44, 51 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "154351411411423232",
  "text" : "Ich geh dann \u00FCbrigens mal alleine ins Bett. #siwoti",
  "id" : 154351411411423232,
  "created_at" : "2012-01-04 00:00:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Maximilian\u00E9 Elbmurf \u2013 bekannt aus dem Internet\u2122",
      "screen_name" : "frumble",
      "indices" : [ 0, 8 ],
      "id_str" : "16377175",
      "id" : 16377175
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "154350204462698496",
  "geo" : { },
  "id_str" : "154350846149275649",
  "in_reply_to_user_id" : 16377175,
  "text" : "@frumble laut Wiki ist meine Variante genauso m\u00F6glich: http:\/\/de.m.wikipedia.org\/wiki\/Anf\u00FChrungszeichen",
  "id" : 154350846149275649,
  "in_reply_to_status_id" : 154350204462698496,
  "created_at" : "2012-01-03 23:58:04 +0000",
  "in_reply_to_screen_name" : "frumble",
  "in_reply_to_user_id_str" : "16377175",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "154349688613634048",
  "text" : "\u00ABSchatz, kommst du ins Bett wenn du damit fertig bist den Piraten zu sagen wo sie dumm sind?\u00BB",
  "id" : 154349688613634048,
  "created_at" : "2012-01-03 23:53:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "fasel",
      "screen_name" : "fasel",
      "indices" : [ 0, 6 ],
      "id_str" : "21739255",
      "id" : 21739255
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "spack1",
      "indices" : [ 20, 27 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "154323394526064640",
  "geo" : { },
  "id_str" : "154323790795509760",
  "in_reply_to_user_id" : 21739255,
  "text" : "@fasel gibt auf der #spack1 dann ein Orga-Fail-Panel dazu. ;)",
  "id" : 154323790795509760,
  "in_reply_to_status_id" : 154323394526064640,
  "created_at" : "2012-01-03 22:10:33 +0000",
  "in_reply_to_screen_name" : "fasel",
  "in_reply_to_user_id_str" : "21739255",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Samantha Clark",
      "screen_name" : "iameltonjohn",
      "indices" : [ 0, 13 ],
      "id_str" : "1514567630",
      "id" : 1514567630
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "154302189593051137",
  "geo" : { },
  "id_str" : "154302297894162432",
  "in_reply_to_user_id" : 15661851,
  "text" : "@iameltonjohn irssi ftw!",
  "id" : 154302297894162432,
  "in_reply_to_status_id" : 154302189593051137,
  "created_at" : "2012-01-03 20:45:09 +0000",
  "in_reply_to_screen_name" : "eltonjohn",
  "in_reply_to_user_id_str" : "15661851",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emily [redacted] Willingham\uD83C\uDFC1",
      "screen_name" : "ejwillingham",
      "indices" : [ 3, 16 ],
      "id_str" : "77907514",
      "id" : 77907514
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "154296474803519489",
  "text" : "RT @ejwillingham: Pretty sure that most of these apply generally, not only to writers: 25 Things Writers Should Stop Doing http:\/\/t.co\/5 ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 105, 125 ],
        "url" : "http:\/\/t.co\/5CjmNGQX",
        "expanded_url" : "http:\/\/j.mp\/vFiTLP",
        "display_url" : "j.mp\/vFiTLP"
      } ]
    },
    "geo" : { },
    "id_str" : "154295224892522496",
    "text" : "Pretty sure that most of these apply generally, not only to writers: 25 Things Writers Should Stop Doing http:\/\/t.co\/5CjmNGQX",
    "id" : 154295224892522496,
    "created_at" : "2012-01-03 20:17:02 +0000",
    "user" : {
      "name" : "Emily [redacted] Willingham\uD83C\uDFC1",
      "screen_name" : "ejwillingham",
      "protected" : false,
      "id_str" : "77907514",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/758517441618071553\/6FGWqxc3_normal.jpg",
      "id" : 77907514,
      "verified" : true
    }
  },
  "id" : 154296474803519489,
  "created_at" : "2012-01-03 20:22:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andreas Baum",
      "screen_name" : "rka",
      "indices" : [ 0, 4 ],
      "id_str" : "8487782",
      "id" : 8487782
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "154274476236877824",
  "geo" : { },
  "id_str" : "154274734262059008",
  "in_reply_to_user_id" : 8487782,
  "text" : "@rka Mist, dann kann ich mich ja auf was freuen, wenn ich n\u00E4chste Woche das Upgrade mache. Mein gmail d\u00FCrfte ~70k Mails haben :(",
  "id" : 154274734262059008,
  "in_reply_to_status_id" : 154274476236877824,
  "created_at" : "2012-01-03 18:55:37 +0000",
  "in_reply_to_screen_name" : "rka",
  "in_reply_to_user_id_str" : "8487782",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andreas Baum",
      "screen_name" : "rka",
      "indices" : [ 0, 4 ],
      "id_str" : "8487782",
      "id" : 8487782
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "154273940917846017",
  "geo" : { },
  "id_str" : "154274144106721281",
  "in_reply_to_user_id" : 8487782,
  "text" : "@rka Uh, kann Mail das unter 10.7 nicht mehr?",
  "id" : 154274144106721281,
  "in_reply_to_status_id" : 154273940917846017,
  "created_at" : "2012-01-03 18:53:16 +0000",
  "in_reply_to_screen_name" : "rka",
  "in_reply_to_user_id_str" : "8487782",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trey Lathe",
      "screen_name" : "GenomesAreUs",
      "indices" : [ 3, 16 ],
      "id_str" : "270565078",
      "id" : 270565078
    }, {
      "name" : "23andMe",
      "screen_name" : "23andMe",
      "indices" : [ 30, 38 ],
      "id_str" : "14738561",
      "id" : 14738561
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 85 ],
      "url" : "http:\/\/t.co\/yxp2YIe0",
      "expanded_url" : "http:\/\/www.yourgeneticgenealogist.com\/2011\/12\/23andme-changes-tos-for-expired-pgs.html",
      "display_url" : "yourgeneticgenealogist.com\/2011\/12\/23andm\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "154268946248380416",
  "text" : "RT @GenomesAreUs: dustup over @23andme terms of service changes: http:\/\/t.co\/yxp2YIe0",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "23andMe",
        "screen_name" : "23andMe",
        "indices" : [ 12, 20 ],
        "id_str" : "14738561",
        "id" : 14738561
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 47, 67 ],
        "url" : "http:\/\/t.co\/yxp2YIe0",
        "expanded_url" : "http:\/\/www.yourgeneticgenealogist.com\/2011\/12\/23andme-changes-tos-for-expired-pgs.html",
        "display_url" : "yourgeneticgenealogist.com\/2011\/12\/23andm\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "154268679041859584",
    "text" : "dustup over @23andme terms of service changes: http:\/\/t.co\/yxp2YIe0",
    "id" : 154268679041859584,
    "created_at" : "2012-01-03 18:31:33 +0000",
    "user" : {
      "name" : "Trey Lathe",
      "screen_name" : "GenomesAreUs",
      "protected" : false,
      "id_str" : "270565078",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1284028027\/39-thumb_normal.jpg",
      "id" : 270565078,
      "verified" : false
    }
  },
  "id" : 154268946248380416,
  "created_at" : "2012-01-03 18:32:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 101 ],
      "url" : "http:\/\/t.co\/LKTKBNOw",
      "expanded_url" : "http:\/\/j.mp\/yrcEeP",
      "display_url" : "j.mp\/yrcEeP"
    } ]
  },
  "geo" : { },
  "id_str" : "154253191851163648",
  "text" : "Social structure and language evolution: resolving the synthetic\/analytic debate http:\/\/t.co\/LKTKBNOw",
  "id" : 154253191851163648,
  "created_at" : "2012-01-03 17:30:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marcus Chown",
      "screen_name" : "marcuschown",
      "indices" : [ 3, 15 ],
      "id_str" : "38205414",
      "id" : 38205414
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "154248061823098880",
  "text" : "RT @marcuschown: Most distant image of Earth, taken by Voyager 1. How about, in 2012, we remember we're all on this dot together? http:\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.punicasoft.com\/imagetwit\" rel=\"nofollow\"\u003EImageTwit for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 113, 133 ],
        "url" : "http:\/\/t.co\/zU0bHT1D",
        "expanded_url" : "http:\/\/twitpic.com\/82o9fx",
        "display_url" : "twitpic.com\/82o9fx"
      } ]
    },
    "geo" : { },
    "id_str" : "154223594384277504",
    "text" : "Most distant image of Earth, taken by Voyager 1. How about, in 2012, we remember we're all on this dot together? http:\/\/t.co\/zU0bHT1D",
    "id" : 154223594384277504,
    "created_at" : "2012-01-03 15:32:24 +0000",
    "user" : {
      "name" : "Marcus Chown",
      "screen_name" : "marcuschown",
      "protected" : false,
      "id_str" : "38205414",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/681518625090580480\/BJUBjRiS_normal.jpg",
      "id" : 38205414,
      "verified" : false
    }
  },
  "id" : 154248061823098880,
  "created_at" : "2012-01-03 17:09:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christoph Steltner",
      "screen_name" : "nplhse",
      "indices" : [ 0, 7 ],
      "id_str" : "111716214",
      "id" : 111716214
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "154242837821657088",
  "geo" : { },
  "id_str" : "154246550346936321",
  "in_reply_to_user_id" : 111716214,
  "text" : "@nplhse 10.000 spoons if all you need is a 5 megawatt laser?",
  "id" : 154246550346936321,
  "in_reply_to_status_id" : 154242837821657088,
  "created_at" : "2012-01-03 17:03:38 +0000",
  "in_reply_to_screen_name" : "nplhse",
  "in_reply_to_user_id_str" : "111716214",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Rogers",
      "screen_name" : "jetjocko",
      "indices" : [ 3, 12 ],
      "id_str" : "18955413",
      "id" : 18955413
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/ixo9jY5r",
      "expanded_url" : "http:\/\/spectrum.ieee.org\/automaton\/robotics\/industrial-robots\/behold-your-doom-robospidernaut",
      "display_url" : "spectrum.ieee.org\/automaton\/robo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "154245403750043648",
  "text" : "RT @jetjocko: The main problem with science as a practice is that it keeps forgetting to not build giant robot spiders. http:\/\/t.co\/ixo9jY5r",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 106, 126 ],
        "url" : "http:\/\/t.co\/ixo9jY5r",
        "expanded_url" : "http:\/\/spectrum.ieee.org\/automaton\/robotics\/industrial-robots\/behold-your-doom-robospidernaut",
        "display_url" : "spectrum.ieee.org\/automaton\/robo\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "154244006526713857",
    "text" : "The main problem with science as a practice is that it keeps forgetting to not build giant robot spiders. http:\/\/t.co\/ixo9jY5r",
    "id" : 154244006526713857,
    "created_at" : "2012-01-03 16:53:31 +0000",
    "user" : {
      "name" : "Adam Rogers",
      "screen_name" : "jetjocko",
      "protected" : false,
      "id_str" : "18955413",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/931791411766222849\/DIJ1RO7F_normal.jpg",
      "id" : 18955413,
      "verified" : false
    }
  },
  "id" : 154245403750043648,
  "created_at" : "2012-01-03 16:59:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "154244292519538688",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon Der Roomba ist auf dem Weg!",
  "id" : 154244292519538688,
  "created_at" : "2012-01-03 16:54:39 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jens Ohlig",
      "screen_name" : "johl",
      "indices" : [ 0, 5 ],
      "id_str" : "1147751",
      "id" : 1147751
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "154242050391416834",
  "geo" : { },
  "id_str" : "154242450985189376",
  "in_reply_to_user_id" : 1147751,
  "text" : "@johl iSSH works for me.",
  "id" : 154242450985189376,
  "in_reply_to_status_id" : 154242050391416834,
  "created_at" : "2012-01-03 16:47:20 +0000",
  "in_reply_to_screen_name" : "johl",
  "in_reply_to_user_id_str" : "1147751",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "naturalismus",
      "screen_name" : "naturalismus",
      "indices" : [ 0, 13 ],
      "id_str" : "4562569648",
      "id" : 4562569648
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 14, 23 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "154241279180550146",
  "geo" : { },
  "id_str" : "154241812008153088",
  "in_reply_to_user_id" : 77216385,
  "text" : "@Naturalismus @senficon das glaube ich erst wenn ich die Knopp-Doku dazu geschaut habe!",
  "id" : 154241812008153088,
  "in_reply_to_status_id" : 154241279180550146,
  "created_at" : "2012-01-03 16:44:48 +0000",
  "in_reply_to_screen_name" : "fireantprincess",
  "in_reply_to_user_id_str" : "77216385",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 39 ],
      "url" : "http:\/\/t.co\/RuPgUaEP",
      "expanded_url" : "http:\/\/j.mp\/tU1CKE",
      "display_url" : "j.mp\/tU1CKE"
    } ]
  },
  "geo" : { },
  "id_str" : "154241156945944576",
  "text" : "King of the Cosmos http:\/\/t.co\/RuPgUaEP",
  "id" : 154241156945944576,
  "created_at" : "2012-01-03 16:42:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 24, 33 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "154240358304317440",
  "text" : "Jetzt versteh ich erst. @Senficon will nur heiraten weil Pro-Kernkraft und Pro-Gentechnik zum trollen nicht mehr reichen.",
  "id" : 154240358304317440,
  "created_at" : "2012-01-03 16:39:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "154237747253608448",
  "text" : "Weibchen? Das sind doch die mit den dicken Gameten?!",
  "id" : 154237747253608448,
  "created_at" : "2012-01-03 16:28:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Oliver Tacke",
      "screen_name" : "otacke",
      "indices" : [ 0, 7 ],
      "id_str" : "34880281",
      "id" : 34880281
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "154230628173348864",
  "geo" : { },
  "id_str" : "154232633054859264",
  "in_reply_to_user_id" : 34880281,
  "text" : "@otacke aber verlier ihn nicht ;)",
  "id" : 154232633054859264,
  "in_reply_to_status_id" : 154230628173348864,
  "created_at" : "2012-01-03 16:08:19 +0000",
  "in_reply_to_screen_name" : "otacke",
  "in_reply_to_user_id_str" : "34880281",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 129 ],
      "url" : "http:\/\/t.co\/xietIAge",
      "expanded_url" : "http:\/\/j.mp\/tglji7",
      "display_url" : "j.mp\/tglji7"
    } ]
  },
  "geo" : { },
  "id_str" : "154232450816552960",
  "text" : "\u00ABWhen men and women think about parking, their mental capacity reverts to the reptilian cortex of the brain\u00BB http:\/\/t.co\/xietIAge",
  "id" : 154232450816552960,
  "created_at" : "2012-01-03 16:07:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Oliver Tacke",
      "screen_name" : "otacke",
      "indices" : [ 0, 7 ],
      "id_str" : "34880281",
      "id" : 34880281
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 8, 17 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "154228226481324034",
  "geo" : { },
  "id_str" : "154229575554048003",
  "in_reply_to_user_id" : 34880281,
  "text" : "@otacke @Senficon und wenn wir doch mal einen Kopf nehmen m\u00FCssen reicht bestimmt auch das K\u00FCchenmesser.",
  "id" : 154229575554048003,
  "in_reply_to_status_id" : 154228226481324034,
  "created_at" : "2012-01-03 15:56:10 +0000",
  "in_reply_to_screen_name" : "otacke",
  "in_reply_to_user_id_str" : "34880281",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "malech maltz",
      "screen_name" : "malech",
      "indices" : [ 0, 7 ],
      "id_str" : "784085846391713793",
      "id" : 784085846391713793
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 8, 17 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "154226682516086785",
  "text" : "@malech @Senficon ist ja auch noch etwas Zeit bis es akut wird.",
  "id" : 154226682516086785,
  "created_at" : "2012-01-03 15:44:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    }, {
      "name" : "Oliver Tacke",
      "screen_name" : "otacke",
      "indices" : [ 10, 17 ],
      "id_str" : "34880281",
      "id" : 34880281
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "154226103509192704",
  "geo" : { },
  "id_str" : "154226247860371457",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon @otacke ich mach dir doch gern die Tessa.",
  "id" : 154226247860371457,
  "in_reply_to_status_id" : 154226103509192704,
  "created_at" : "2012-01-03 15:42:57 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "154225933904130048",
  "geo" : { },
  "id_str" : "154226199269355521",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon ich und Sprachen lernen? Da kann ich ja vorher den genetischen Code auswendig.",
  "id" : 154226199269355521,
  "in_reply_to_status_id" : 154225933904130048,
  "created_at" : "2012-01-03 15:42:45 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Oliver Tacke",
      "screen_name" : "otacke",
      "indices" : [ 0, 7 ],
      "id_str" : "34880281",
      "id" : 34880281
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 36, 45 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "154225041448517633",
  "geo" : { },
  "id_str" : "154225885875159040",
  "in_reply_to_user_id" : 34880281,
  "text" : "@otacke die sind schon zusammen mit @senficon eingezogen. ;)",
  "id" : 154225885875159040,
  "in_reply_to_status_id" : 154225041448517633,
  "created_at" : "2012-01-03 15:41:31 +0000",
  "in_reply_to_screen_name" : "otacke",
  "in_reply_to_user_id_str" : "34880281",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "154224994317119489",
  "geo" : { },
  "id_str" : "154225643125604352",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon wenn man davon absieht, dass die da alle eine komische Sprache sprechen.",
  "id" : 154225643125604352,
  "in_reply_to_status_id" : 154224994317119489,
  "created_at" : "2012-01-03 15:40:33 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "malech maltz",
      "screen_name" : "malech",
      "indices" : [ 0, 7 ],
      "id_str" : "784085846391713793",
      "id" : 784085846391713793
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 8, 17 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "154225391182159872",
  "text" : "@malech @Senficon aus Amsterdam hab ich aber noch kein Stellenangebot bekommen ;)",
  "id" : 154225391182159872,
  "created_at" : "2012-01-03 15:39:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "154224530011860993",
  "geo" : { },
  "id_str" : "154224761696829440",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon damit kann ich leider nicht dienen. Aber vielleicht kann man ja in Strasbourg auch auf einem Hausboot leben ;)",
  "id" : 154224761696829440,
  "in_reply_to_status_id" : 154224530011860993,
  "created_at" : "2012-01-03 15:37:03 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "154222626288566272",
  "geo" : { },
  "id_str" : "154222941373083648",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon wenn du Lust auf Frankreich hast, dann hab ich da auch eine PhD-Position ;)",
  "id" : 154222941373083648,
  "in_reply_to_status_id" : 154222626288566272,
  "created_at" : "2012-01-03 15:29:49 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PLOS Blogs",
      "screen_name" : "PLOSBlogs",
      "indices" : [ 3, 13 ],
      "id_str" : "184931891",
      "id" : 184931891
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 122 ],
      "url" : "http:\/\/t.co\/QAC4tGZy",
      "expanded_url" : "http:\/\/bit.ly\/w4Mi6l",
      "display_url" : "bit.ly\/w4Mi6l"
    } ]
  },
  "geo" : { },
  "id_str" : "154219828817829888",
  "text" : "RT @plosblogs: False positive HIV tests: the problem no one wants to talk about (and how to solve it) http:\/\/t.co\/QAC4tGZy",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 87, 107 ],
        "url" : "http:\/\/t.co\/QAC4tGZy",
        "expanded_url" : "http:\/\/bit.ly\/w4Mi6l",
        "display_url" : "bit.ly\/w4Mi6l"
      } ]
    },
    "geo" : { },
    "id_str" : "154202169459998720",
    "text" : "False positive HIV tests: the problem no one wants to talk about (and how to solve it) http:\/\/t.co\/QAC4tGZy",
    "id" : 154202169459998720,
    "created_at" : "2012-01-03 14:07:16 +0000",
    "user" : {
      "name" : "PLOS Blogs",
      "screen_name" : "PLOSBlogs",
      "protected" : false,
      "id_str" : "184931891",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2436219018\/x047acnubvb1fvmp3h9p_normal.jpeg",
      "id" : 184931891,
      "verified" : false
    }
  },
  "id" : 154219828817829888,
  "created_at" : "2012-01-03 15:17:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 41 ],
      "url" : "http:\/\/t.co\/unwN2dt2",
      "expanded_url" : "http:\/\/j.mp\/t6aWQ2",
      "display_url" : "j.mp\/t6aWQ2"
    } ]
  },
  "geo" : { },
  "id_str" : "154217510198185984",
  "text" : "A history of purpose http:\/\/t.co\/unwN2dt2",
  "id" : 154217510198185984,
  "created_at" : "2012-01-03 15:08:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "154217130504622080",
  "text" : "Offenburg \u201EHauptbahnhof\u201C \u2014 Auch nichts wo man 30 Minuten Aufenthalt haben will.",
  "id" : 154217130504622080,
  "created_at" : "2012-01-03 15:06:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "154216119257927681",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon ETA 18:45",
  "id" : 154216119257927681,
  "created_at" : "2012-01-03 15:02:42 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "154094711265697793",
  "text" : "Talking about human genetics if your only qualification is having a genome yourself...",
  "id" : 154094711265697793,
  "created_at" : "2012-01-03 07:00:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 31 ],
      "url" : "http:\/\/t.co\/FmgVo30R",
      "expanded_url" : "http:\/\/j.mp\/s1HN7O",
      "display_url" : "j.mp\/s1HN7O"
    } ]
  },
  "geo" : { },
  "id_str" : "154091022027206656",
  "text" : "Provisions http:\/\/t.co\/FmgVo30R",
  "id" : 154091022027206656,
  "created_at" : "2012-01-03 06:45:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 80 ],
      "url" : "http:\/\/t.co\/crglpGGN",
      "expanded_url" : "http:\/\/j.mp\/u21vnO",
      "display_url" : "j.mp\/u21vnO"
    } ]
  },
  "geo" : { },
  "id_str" : "154071236618620929",
  "text" : "LOLcats and the Arab Spring - human rights and the Internet http:\/\/t.co\/crglpGGN",
  "id" : 154071236618620929,
  "created_at" : "2012-01-03 05:26:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 57 ],
      "url" : "http:\/\/t.co\/wFkRCukN",
      "expanded_url" : "http:\/\/j.mp\/uRraSl",
      "display_url" : "j.mp\/uRraSl"
    } ]
  },
  "geo" : { },
  "id_str" : "154068984143151105",
  "text" : "New Year's Resolution: Learn To Code http:\/\/t.co\/wFkRCukN",
  "id" : 154068984143151105,
  "created_at" : "2012-01-03 05:18:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "154054060507545601",
  "text" : "Morgen...",
  "id" : 154054060507545601,
  "created_at" : "2012-01-03 04:18:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "153974148450893824",
  "text" : "Jetzt wo der Roomba bestellt ist: Gibt es Custom-Firmware\/Plugins um die Sprachausgabe auf Dalek zu stellen?",
  "id" : 153974148450893824,
  "created_at" : "2012-01-02 23:01:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jad Abumrad",
      "screen_name" : "JadAbumrad",
      "indices" : [ 3, 14 ],
      "id_str" : "135316691",
      "id" : 135316691
    }, {
      "name" : "Brian Stelter",
      "screen_name" : "brianstelter",
      "indices" : [ 55, 68 ],
      "id_str" : "14515799",
      "id" : 14515799
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 133 ],
      "url" : "http:\/\/t.co\/e3t9HoTt",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=XKfuS6gfxPY&feature=share",
      "display_url" : "youtube.com\/watch?v=XKfuS6\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "153947339327942658",
  "text" : "RT @JadAbumrad: Woah. Interesting inversion of POV. RT @brianstelter Have you ever seen a campaign ad like this? http:\/\/t.co\/e3t9HoTt",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Brian Stelter",
        "screen_name" : "brianstelter",
        "indices" : [ 39, 52 ],
        "id_str" : "14515799",
        "id" : 14515799
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 97, 117 ],
        "url" : "http:\/\/t.co\/e3t9HoTt",
        "expanded_url" : "http:\/\/www.youtube.com\/watch?v=XKfuS6gfxPY&feature=share",
        "display_url" : "youtube.com\/watch?v=XKfuS6\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "153946316584652800",
    "text" : "Woah. Interesting inversion of POV. RT @brianstelter Have you ever seen a campaign ad like this? http:\/\/t.co\/e3t9HoTt",
    "id" : 153946316584652800,
    "created_at" : "2012-01-02 21:10:36 +0000",
    "user" : {
      "name" : "Jad Abumrad",
      "screen_name" : "JadAbumrad",
      "protected" : false,
      "id_str" : "135316691",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1529014082\/Jad-Pic2_normal.jpg",
      "id" : 135316691,
      "verified" : true
    }
  },
  "id" : 153947339327942658,
  "created_at" : "2012-01-02 21:14:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LOLGOP",
      "screen_name" : "LOLGOP",
      "indices" : [ 3, 10 ],
      "id_str" : "11866582",
      "id" : 11866582
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "153944663055810560",
  "text" : "RT @LOLGOP: Give a Republican a fish and he'll think he learned how to fish. Teach him to fish and he'll call you socialist.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/timely.is\" rel=\"nofollow\"\u003ETimely by Demandforce\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "153943927907549184",
    "text" : "Give a Republican a fish and he'll think he learned how to fish. Teach him to fish and he'll call you socialist.",
    "id" : 153943927907549184,
    "created_at" : "2012-01-02 21:01:07 +0000",
    "user" : {
      "name" : "LOLGOP",
      "screen_name" : "LOLGOP",
      "protected" : false,
      "id_str" : "11866582",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/875789656369102848\/YtrDL9IU_normal.jpg",
      "id" : 11866582,
      "verified" : false
    }
  },
  "id" : 153944663055810560,
  "created_at" : "2012-01-02 21:04:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 35 ],
      "url" : "http:\/\/t.co\/MBhsgXtc",
      "expanded_url" : "http:\/\/j.mp\/rZM8Qz",
      "display_url" : "j.mp\/rZM8Qz"
    } ]
  },
  "geo" : { },
  "id_str" : "153939328404434945",
  "text" : "Best cake ever http:\/\/t.co\/MBhsgXtc",
  "id" : 153939328404434945,
  "created_at" : "2012-01-02 20:42:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 55 ],
      "url" : "http:\/\/t.co\/3hLm8URy",
      "expanded_url" : "http:\/\/j.mp\/vwLFTJ",
      "display_url" : "j.mp\/vwLFTJ"
    } ]
  },
  "geo" : { },
  "id_str" : "153938120218382336",
  "text" : "Typoporn: Domo Arigato, Mr. Roboto http:\/\/t.co\/3hLm8URy",
  "id" : 153938120218382336,
  "created_at" : "2012-01-02 20:38:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 42 ],
      "url" : "http:\/\/t.co\/tishEd8h",
      "expanded_url" : "http:\/\/twitpic.com\/82avdh",
      "display_url" : "twitpic.com\/82avdh"
    } ]
  },
  "geo" : { },
  "id_str" : "153933117856559104",
  "text" : "Highlander, Season 4  http:\/\/t.co\/tishEd8h",
  "id" : 153933117856559104,
  "created_at" : "2012-01-02 20:18:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "openSNP team",
      "screen_name" : "openSNPorg",
      "indices" : [ 3, 14 ],
      "id_str" : "380205172",
      "id" : 380205172
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 51, 64 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 69, 85 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 130 ],
      "url" : "http:\/\/t.co\/BalqR5ET",
      "expanded_url" : "http:\/\/bit.ly\/slFhi0",
      "display_url" : "bit.ly\/slFhi0"
    } ]
  },
  "geo" : { },
  "id_str" : "153915214394437632",
  "text" : "RT @openSNPorg: The videos and slides of the talks @PhilippBayer and @gedankenstuecke gave are now available: http:\/\/t.co\/BalqR5ET",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Philipp Bayer\uD83C\uDF08",
        "screen_name" : "PhilippBayer",
        "indices" : [ 35, 48 ],
        "id_str" : "121777206",
        "id" : 121777206
      }, {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 53, 69 ],
        "id_str" : "14286491",
        "id" : 14286491
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 94, 114 ],
        "url" : "http:\/\/t.co\/BalqR5ET",
        "expanded_url" : "http:\/\/bit.ly\/slFhi0",
        "display_url" : "bit.ly\/slFhi0"
      } ]
    },
    "geo" : { },
    "id_str" : "153915169435697152",
    "text" : "The videos and slides of the talks @PhilippBayer and @gedankenstuecke gave are now available: http:\/\/t.co\/BalqR5ET",
    "id" : 153915169435697152,
    "created_at" : "2012-01-02 19:06:50 +0000",
    "user" : {
      "name" : "openSNP team",
      "screen_name" : "openSNPorg",
      "protected" : false,
      "id_str" : "380205172",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/735374825187909632\/wJEJW1zW_normal.jpg",
      "id" : 380205172,
      "verified" : false
    }
  },
  "id" : 153915214394437632,
  "created_at" : "2012-01-02 19:07:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cae Vye",
      "screen_name" : "CaeVye",
      "indices" : [ 0, 7 ],
      "id_str" : "31104704",
      "id" : 31104704
    }, {
      "name" : "laprintemps",
      "screen_name" : "laprintemps",
      "indices" : [ 8, 20 ],
      "id_str" : "1483038588",
      "id" : 1483038588
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "153900433650364416",
  "geo" : { },
  "id_str" : "153901579278364672",
  "in_reply_to_user_id" : 31104704,
  "text" : "@CaeVye @laprintemps spannend w\u00E4re ja ob man Epimemetik nachweisen kann ;)",
  "id" : 153901579278364672,
  "in_reply_to_status_id" : 153900433650364416,
  "created_at" : "2012-01-02 18:12:50 +0000",
  "in_reply_to_screen_name" : "CaeVye",
  "in_reply_to_user_id_str" : "31104704",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "acid\u0FC8 \u1515\u1548\u1587\u1571\u15EF\u1602 \u1515\u1573\u157C\u15DD\u1602\u1571\u1587",
      "screen_name" : "acid23",
      "indices" : [ 0, 7 ],
      "id_str" : "35535998",
      "id" : 35535998
    }, {
      "name" : "Cae Vye",
      "screen_name" : "CaeVye",
      "indices" : [ 8, 15 ],
      "id_str" : "31104704",
      "id" : 31104704
    }, {
      "name" : "laprintemps",
      "screen_name" : "laprintemps",
      "indices" : [ 16, 28 ],
      "id_str" : "1483038588",
      "id" : 1483038588
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "153900576223137792",
  "geo" : { },
  "id_str" : "153901440115544064",
  "in_reply_to_user_id" : 35535998,
  "text" : "@acid23 @CaeVye @laprintemps man muss halt aus dem recht breiten Fitness-Bereich rauskommen.",
  "id" : 153901440115544064,
  "in_reply_to_status_id" : 153900576223137792,
  "created_at" : "2012-01-02 18:12:17 +0000",
  "in_reply_to_screen_name" : "acid23",
  "in_reply_to_user_id_str" : "35535998",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave-Kay",
      "screen_name" : "Dave_Kay",
      "indices" : [ 0, 9 ],
      "id_str" : "10487642",
      "id" : 10487642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "153898674869649408",
  "geo" : { },
  "id_str" : "153899541320577025",
  "in_reply_to_user_id" : 10487642,
  "text" : "@Dave_Kay Montag, Dienstag, Mittwoch, Donnerstag...",
  "id" : 153899541320577025,
  "in_reply_to_status_id" : 153898674869649408,
  "created_at" : "2012-01-02 18:04:44 +0000",
  "in_reply_to_screen_name" : "Dave_Kay",
  "in_reply_to_user_id_str" : "10487642",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cae Vye",
      "screen_name" : "CaeVye",
      "indices" : [ 0, 7 ],
      "id_str" : "31104704",
      "id" : 31104704
    }, {
      "name" : "laprintemps",
      "screen_name" : "laprintemps",
      "indices" : [ 8, 20 ],
      "id_str" : "1483038588",
      "id" : 1483038588
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "153898739231240192",
  "geo" : { },
  "id_str" : "153899320561766401",
  "in_reply_to_user_id" : 31104704,
  "text" : "@CaeVye @laprintemps aber die sind ja auch nicht universell Fit, sondern in einem bestimmten \u00D6kosystem.",
  "id" : 153899320561766401,
  "in_reply_to_status_id" : 153898739231240192,
  "created_at" : "2012-01-02 18:03:51 +0000",
  "in_reply_to_screen_name" : "CaeVye",
  "in_reply_to_user_id_str" : "31104704",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cae Vye",
      "screen_name" : "CaeVye",
      "indices" : [ 0, 7 ],
      "id_str" : "31104704",
      "id" : 31104704
    }, {
      "name" : "laprintemps",
      "screen_name" : "laprintemps",
      "indices" : [ 8, 20 ],
      "id_str" : "1483038588",
      "id" : 1483038588
    }, {
      "name" : "acid\u0FC8 \u1515\u1548\u1587\u1571\u15EF\u1602 \u1515\u1573\u157C\u15DD\u1602\u1571\u1587",
      "screen_name" : "acid23",
      "indices" : [ 100, 107 ],
      "id_str" : "35535998",
      "id" : 35535998
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "spack0",
      "indices" : [ 83, 90 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "153898739231240192",
  "geo" : { },
  "id_str" : "153898934736125954",
  "in_reply_to_user_id" : 31104704,
  "text" : "@CaeVye @laprintemps das meinte ich mit den fitten Diskriminierungs-Memen nach dem #spack0 Talk von @acid23",
  "id" : 153898934736125954,
  "in_reply_to_status_id" : 153898739231240192,
  "created_at" : "2012-01-02 18:02:20 +0000",
  "in_reply_to_screen_name" : "CaeVye",
  "in_reply_to_user_id_str" : "31104704",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cae Vye",
      "screen_name" : "CaeVye",
      "indices" : [ 0, 7 ],
      "id_str" : "31104704",
      "id" : 31104704
    }, {
      "name" : "laprintemps",
      "screen_name" : "laprintemps",
      "indices" : [ 8, 20 ],
      "id_str" : "1483038588",
      "id" : 1483038588
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "153897970931204097",
  "geo" : { },
  "id_str" : "153898659593994240",
  "in_reply_to_user_id" : 31104704,
  "text" : "@CaeVye @laprintemps ich wollte den Schritten an sich auch keine Wertung geben. Man kann auch in kleinen Schritten \u00FCber die Klippe.",
  "id" : 153898659593994240,
  "in_reply_to_status_id" : 153897970931204097,
  "created_at" : "2012-01-02 18:01:14 +0000",
  "in_reply_to_screen_name" : "CaeVye",
  "in_reply_to_user_id_str" : "31104704",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cae Vye",
      "screen_name" : "CaeVye",
      "indices" : [ 0, 7 ],
      "id_str" : "31104704",
      "id" : 31104704
    }, {
      "name" : "laprintemps",
      "screen_name" : "laprintemps",
      "indices" : [ 8, 20 ],
      "id_str" : "1483038588",
      "id" : 1483038588
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "153896058349559808",
  "geo" : { },
  "id_str" : "153897316321996801",
  "in_reply_to_user_id" : 31104704,
  "text" : "@CaeVye @laprintemps ich w\u00FCrde sagen Menschen \u00E4ndern sich in kleinen Schritten. So das am Ende aber einen gro\u00DFen Unterschied stehen _kann_",
  "id" : 153897316321996801,
  "in_reply_to_status_id" : 153896058349559808,
  "created_at" : "2012-01-02 17:55:54 +0000",
  "in_reply_to_screen_name" : "CaeVye",
  "in_reply_to_user_id_str" : "31104704",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cae Vye",
      "screen_name" : "CaeVye",
      "indices" : [ 0, 7 ],
      "id_str" : "31104704",
      "id" : 31104704
    }, {
      "name" : "laprintemps",
      "screen_name" : "laprintemps",
      "indices" : [ 8, 20 ],
      "id_str" : "1483038588",
      "id" : 1483038588
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "153895501622812672",
  "geo" : { },
  "id_str" : "153895683580108800",
  "in_reply_to_user_id" : 31104704,
  "text" : "@CaeVye @laprintemps solange nicht direkt nach der Bet\u00E4ubung ;)",
  "id" : 153895683580108800,
  "in_reply_to_status_id" : 153895501622812672,
  "created_at" : "2012-01-02 17:49:24 +0000",
  "in_reply_to_screen_name" : "CaeVye",
  "in_reply_to_user_id_str" : "31104704",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cae Vye",
      "screen_name" : "CaeVye",
      "indices" : [ 0, 7 ],
      "id_str" : "31104704",
      "id" : 31104704
    }, {
      "name" : "laprintemps",
      "screen_name" : "laprintemps",
      "indices" : [ 8, 20 ],
      "id_str" : "1483038588",
      "id" : 1483038588
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "153895287650398208",
  "geo" : { },
  "id_str" : "153895583986356224",
  "in_reply_to_user_id" : 31104704,
  "text" : "@CaeVye @laprintemps das seh ich anders. Vor allem finde ich \"Menschen sind halt so\" ist ein vergleichsweise schwaches Argument.",
  "id" : 153895583986356224,
  "in_reply_to_status_id" : 153895287650398208,
  "created_at" : "2012-01-02 17:49:01 +0000",
  "in_reply_to_screen_name" : "CaeVye",
  "in_reply_to_user_id_str" : "31104704",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cae Vye",
      "screen_name" : "CaeVye",
      "indices" : [ 0, 7 ],
      "id_str" : "31104704",
      "id" : 31104704
    }, {
      "name" : "laprintemps",
      "screen_name" : "laprintemps",
      "indices" : [ 8, 20 ],
      "id_str" : "1483038588",
      "id" : 1483038588
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "153894968728100864",
  "geo" : { },
  "id_str" : "153895144930820096",
  "in_reply_to_user_id" : 31104704,
  "text" : "@CaeVye @laprintemps kurzes Break of Discussion. Die Meme \u00ABerlauben\u00BB mir gerade einen Zahnarzttermin.  ;)",
  "id" : 153895144930820096,
  "in_reply_to_status_id" : 153894968728100864,
  "created_at" : "2012-01-02 17:47:16 +0000",
  "in_reply_to_screen_name" : "CaeVye",
  "in_reply_to_user_id_str" : "31104704",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cae Vye",
      "screen_name" : "CaeVye",
      "indices" : [ 0, 7 ],
      "id_str" : "31104704",
      "id" : 31104704
    }, {
      "name" : "laprintemps",
      "screen_name" : "laprintemps",
      "indices" : [ 8, 20 ],
      "id_str" : "1483038588",
      "id" : 1483038588
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "153894287862542337",
  "geo" : { },
  "id_str" : "153894434449264641",
  "in_reply_to_user_id" : 31104704,
  "text" : "@CaeVye @laprintemps deshalb Frequenzen. Ausgestorben sicher nicht so schnell.",
  "id" : 153894434449264641,
  "in_reply_to_status_id" : 153894287862542337,
  "created_at" : "2012-01-02 17:44:27 +0000",
  "in_reply_to_screen_name" : "CaeVye",
  "in_reply_to_user_id_str" : "31104704",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cae Vye",
      "screen_name" : "CaeVye",
      "indices" : [ 0, 7 ],
      "id_str" : "31104704",
      "id" : 31104704
    }, {
      "name" : "laprintemps",
      "screen_name" : "laprintemps",
      "indices" : [ 8, 20 ],
      "id_str" : "1483038588",
      "id" : 1483038588
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "153893027151228928",
  "geo" : { },
  "id_str" : "153893773577949185",
  "in_reply_to_user_id" : 31104704,
  "text" : "@CaeVye @laprintemps meinst du nicht, dass sich die Mem-Frequenzen dazu in den letzten 100-200 Jahren allein drastisch verschoben haben?",
  "id" : 153893773577949185,
  "in_reply_to_status_id" : 153893027151228928,
  "created_at" : "2012-01-02 17:41:49 +0000",
  "in_reply_to_screen_name" : "CaeVye",
  "in_reply_to_user_id_str" : "31104704",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "laprintemps",
      "screen_name" : "laprintemps",
      "indices" : [ 0, 12 ],
      "id_str" : "1483038588",
      "id" : 1483038588
    }, {
      "name" : "Cae Vye",
      "screen_name" : "CaeVye",
      "indices" : [ 13, 20 ],
      "id_str" : "31104704",
      "id" : 31104704
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "153892724322476032",
  "geo" : { },
  "id_str" : "153892988827873280",
  "in_reply_to_user_id" : 47728577,
  "text" : "@laprintemps @CaeVye kommt auf den Level an auf dem man ihn diskutieren will ;)",
  "id" : 153892988827873280,
  "in_reply_to_status_id" : 153892724322476032,
  "created_at" : "2012-01-02 17:38:42 +0000",
  "in_reply_to_screen_name" : "_juliaschramm",
  "in_reply_to_user_id_str" : "47728577",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "laprintemps",
      "screen_name" : "laprintemps",
      "indices" : [ 0, 12 ],
      "id_str" : "1483038588",
      "id" : 1483038588
    }, {
      "name" : "Cae Vye",
      "screen_name" : "CaeVye",
      "indices" : [ 13, 20 ],
      "id_str" : "31104704",
      "id" : 31104704
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "153891969289043968",
  "geo" : { },
  "id_str" : "153892459183747072",
  "in_reply_to_user_id" : 47728577,
  "text" : "@laprintemps @CaeVye viele davon umgehen wir doch heute z.T. schon. Event. Inklusion Behinderter als Bsp?",
  "id" : 153892459183747072,
  "in_reply_to_status_id" : 153891969289043968,
  "created_at" : "2012-01-02 17:36:36 +0000",
  "in_reply_to_screen_name" : "_juliaschramm",
  "in_reply_to_user_id_str" : "47728577",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "153891700887134208",
  "geo" : { },
  "id_str" : "153891855363354624",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon ~20 Minuten?",
  "id" : 153891855363354624,
  "in_reply_to_status_id" : 153891700887134208,
  "created_at" : "2012-01-02 17:34:12 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "acid\u0FC8 \u1515\u1548\u1587\u1571\u15EF\u1602 \u1515\u1573\u157C\u15DD\u1602\u1571\u1587",
      "screen_name" : "acid23",
      "indices" : [ 0, 7 ],
      "id_str" : "35535998",
      "id" : 35535998
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "153889557052538880",
  "geo" : { },
  "id_str" : "153889992756822016",
  "in_reply_to_user_id" : 35535998,
  "text" : "@acid23 naja, ist ja nun wieder gefixt ;)",
  "id" : 153889992756822016,
  "in_reply_to_status_id" : 153889557052538880,
  "created_at" : "2012-01-02 17:26:48 +0000",
  "in_reply_to_screen_name" : "acid23",
  "in_reply_to_user_id_str" : "35535998",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "laprintemps",
      "screen_name" : "laprintemps",
      "indices" : [ 0, 12 ],
      "id_str" : "1483038588",
      "id" : 1483038588
    }, {
      "name" : "Cae Vye",
      "screen_name" : "CaeVye",
      "indices" : [ 13, 20 ],
      "id_str" : "31104704",
      "id" : 31104704
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "153889523825262592",
  "geo" : { },
  "id_str" : "153889848023977984",
  "in_reply_to_user_id" : 47728577,
  "text" : "@laprintemps @CaeVye und wenn wir den Einfluss von Genen mittlerweile minimieren, wieso dann nicht auch von spezifischen Memen?",
  "id" : 153889848023977984,
  "in_reply_to_status_id" : 153889523825262592,
  "created_at" : "2012-01-02 17:26:13 +0000",
  "in_reply_to_screen_name" : "_juliaschramm",
  "in_reply_to_user_id_str" : "47728577",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "laprintemps",
      "screen_name" : "laprintemps",
      "indices" : [ 0, 12 ],
      "id_str" : "1483038588",
      "id" : 1483038588
    }, {
      "name" : "Cae Vye",
      "screen_name" : "CaeVye",
      "indices" : [ 13, 20 ],
      "id_str" : "31104704",
      "id" : 31104704
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "153888103029948416",
  "geo" : { },
  "id_str" : "153889311648002048",
  "in_reply_to_user_id" : 47728577,
  "text" : "@laprintemps @CaeVye und auch sonst ist das mehr Memetik als Genetik w\u00FCrde ich sagen.",
  "id" : 153889311648002048,
  "in_reply_to_status_id" : 153888103029948416,
  "created_at" : "2012-01-02 17:24:05 +0000",
  "in_reply_to_screen_name" : "_juliaschramm",
  "in_reply_to_user_id_str" : "47728577",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "acid\u0FC8 \u1515\u1548\u1587\u1571\u15EF\u1602 \u1515\u1573\u157C\u15DD\u1602\u1571\u1587",
      "screen_name" : "acid23",
      "indices" : [ 0, 7 ],
      "id_str" : "35535998",
      "id" : 35535998
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "153888503187513346",
  "geo" : { },
  "id_str" : "153889103866368000",
  "in_reply_to_user_id" : 35535998,
  "text" : "@acid23 ich habs nicht bewusst ge\u00E4ndert. Vielleicht mal wieder ein Twitter-Schluckauf?",
  "id" : 153889103866368000,
  "in_reply_to_status_id" : 153888503187513346,
  "created_at" : "2012-01-02 17:23:16 +0000",
  "in_reply_to_screen_name" : "acid23",
  "in_reply_to_user_id_str" : "35535998",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "laprintemps",
      "screen_name" : "laprintemps",
      "indices" : [ 0, 12 ],
      "id_str" : "1483038588",
      "id" : 1483038588
    }, {
      "name" : "Cae Vye",
      "screen_name" : "CaeVye",
      "indices" : [ 13, 20 ],
      "id_str" : "31104704",
      "id" : 31104704
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "153888103029948416",
  "geo" : { },
  "id_str" : "153888867693498368",
  "in_reply_to_user_id" : 47728577,
  "text" : "@laprintemps @CaeVye \u00FCber anthroposophische Grundkonstanten diskutiere ich nicht. \u00DCber anthropologische k\u00F6nnen wir reden. ;)",
  "id" : 153888867693498368,
  "in_reply_to_status_id" : 153888103029948416,
  "created_at" : "2012-01-02 17:22:19 +0000",
  "in_reply_to_screen_name" : "_juliaschramm",
  "in_reply_to_user_id_str" : "47728577",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "acid\u0FC8 \u1515\u1548\u1587\u1571\u15EF\u1602 \u1515\u1573\u157C\u15DD\u1602\u1571\u1587",
      "screen_name" : "acid23",
      "indices" : [ 0, 7 ],
      "id_str" : "35535998",
      "id" : 35535998
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "om11",
      "indices" : [ 43, 48 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "153887851342340096",
  "geo" : { },
  "id_str" : "153887987657216000",
  "in_reply_to_user_id" : 35535998,
  "text" : "@acid23 ich dachte ich h\u00E4tte das schon zur #om11 ge\u00E4ndert.",
  "id" : 153887987657216000,
  "in_reply_to_status_id" : 153887851342340096,
  "created_at" : "2012-01-02 17:18:50 +0000",
  "in_reply_to_screen_name" : "acid23",
  "in_reply_to_user_id_str" : "35535998",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cae Vye",
      "screen_name" : "CaeVye",
      "indices" : [ 0, 7 ],
      "id_str" : "31104704",
      "id" : 31104704
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "153884376416002048",
  "geo" : { },
  "id_str" : "153887678729953282",
  "in_reply_to_user_id" : 31104704,
  "text" : "@CaeVye da bin ich mir nicht so sicher.",
  "id" : 153887678729953282,
  "in_reply_to_status_id" : 153884376416002048,
  "created_at" : "2012-01-02 17:17:36 +0000",
  "in_reply_to_screen_name" : "CaeVye",
  "in_reply_to_user_id_str" : "31104704",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "acid\u0FC8 \u1515\u1548\u1587\u1571\u15EF\u1602 \u1515\u1573\u157C\u15DD\u1602\u1571\u1587",
      "screen_name" : "acid23",
      "indices" : [ 0, 7 ],
      "id_str" : "35535998",
      "id" : 35535998
    }, {
      "name" : "naturalismus",
      "screen_name" : "naturalismus",
      "indices" : [ 8, 21 ],
      "id_str" : "4562569648",
      "id" : 4562569648
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "153884843460141056",
  "geo" : { },
  "id_str" : "153885474270879746",
  "in_reply_to_user_id" : 35535998,
  "text" : "@acid23 @Naturalismus und sogar wieder zur\u00FCck ;)",
  "id" : 153885474270879746,
  "in_reply_to_status_id" : 153884843460141056,
  "created_at" : "2012-01-02 17:08:50 +0000",
  "in_reply_to_screen_name" : "acid23",
  "in_reply_to_user_id_str" : "35535998",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "acid\u0FC8 \u1515\u1548\u1587\u1571\u15EF\u1602 \u1515\u1573\u157C\u15DD\u1602\u1571\u1587",
      "screen_name" : "acid23",
      "indices" : [ 29, 36 ],
      "id_str" : "35535998",
      "id" : 35535998
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 94 ],
      "url" : "http:\/\/t.co\/HF3LPdAF",
      "expanded_url" : "http:\/\/flic.kr\/p\/b633ue",
      "display_url" : "flic.kr\/p\/b633ue"
    } ]
  },
  "geo" : { },
  "id_str" : "153884427657822208",
  "text" : "Und den Weg nicht finden! RT @acid23: M\u00E4nner, die auf Smartphones starren http:\/\/t.co\/HF3LPdAF",
  "id" : 153884427657822208,
  "created_at" : "2012-01-02 17:04:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cae Vye",
      "screen_name" : "CaeVye",
      "indices" : [ 0, 7 ],
      "id_str" : "31104704",
      "id" : 31104704
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "153883589791072256",
  "geo" : { },
  "id_str" : "153884045774815232",
  "in_reply_to_user_id" : 31104704,
  "text" : "@CaeVye was auch das Fernziel sein sollte.",
  "id" : 153884045774815232,
  "in_reply_to_status_id" : 153883589791072256,
  "created_at" : "2012-01-02 17:03:10 +0000",
  "in_reply_to_screen_name" : "CaeVye",
  "in_reply_to_user_id_str" : "31104704",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cae Vye",
      "screen_name" : "CaeVye",
      "indices" : [ 0, 7 ],
      "id_str" : "31104704",
      "id" : 31104704
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "153882455944855552",
  "geo" : { },
  "id_str" : "153883034817536000",
  "in_reply_to_user_id" : 31104704,
  "text" : "@CaeVye ja, kommen sie. Und deshalb sollen Privilegierte ihre Daten nicht ver\u00F6ffentlichen (und damit u.U. das Problem lindern?)",
  "id" : 153883034817536000,
  "in_reply_to_status_id" : 153882455944855552,
  "created_at" : "2012-01-02 16:59:09 +0000",
  "in_reply_to_screen_name" : "CaeVye",
  "in_reply_to_user_id_str" : "31104704",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cae Vye",
      "screen_name" : "CaeVye",
      "indices" : [ 0, 7 ],
      "id_str" : "31104704",
      "id" : 31104704
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "153881843962363904",
  "geo" : { },
  "id_str" : "153882107977023488",
  "in_reply_to_user_id" : 31104704,
  "text" : "@CaeVye wenn man die Probleme sowieso angehen muss, dann kann man aber den Fix gleich f\u00FCr was positives nutzen finde ich.",
  "id" : 153882107977023488,
  "in_reply_to_status_id" : 153881843962363904,
  "created_at" : "2012-01-02 16:55:28 +0000",
  "in_reply_to_screen_name" : "CaeVye",
  "in_reply_to_user_id_str" : "31104704",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cae Vye",
      "screen_name" : "CaeVye",
      "indices" : [ 0, 7 ],
      "id_str" : "31104704",
      "id" : 31104704
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "153881380336566274",
  "geo" : { },
  "id_str" : "153881619088932864",
  "in_reply_to_user_id" : 31104704,
  "text" : "@CaeVye damit bleiben aber die Probleme von Diskriminierung et al. die gel\u00F6st werden m\u00FCssen.",
  "id" : 153881619088932864,
  "in_reply_to_status_id" : 153881380336566274,
  "created_at" : "2012-01-02 16:53:31 +0000",
  "in_reply_to_screen_name" : "CaeVye",
  "in_reply_to_user_id_str" : "31104704",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cae Vye",
      "screen_name" : "CaeVye",
      "indices" : [ 0, 7 ],
      "id_str" : "31104704",
      "id" : 31104704
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "153880941092290560",
  "geo" : { },
  "id_str" : "153881173393813504",
  "in_reply_to_user_id" : 31104704,
  "text" : "@CaeVye ich glaube einfach nur nicht, dass man PM-Daten (oder Daten ansich) sicher lagern kann.",
  "id" : 153881173393813504,
  "in_reply_to_status_id" : 153880941092290560,
  "created_at" : "2012-01-02 16:51:45 +0000",
  "in_reply_to_screen_name" : "CaeVye",
  "in_reply_to_user_id_str" : "31104704",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rya",
      "screen_name" : "_Rya_",
      "indices" : [ 0, 6 ],
      "id_str" : "89234537",
      "id" : 89234537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "153880037945389057",
  "geo" : { },
  "id_str" : "153880547351990273",
  "in_reply_to_user_id" : 89234537,
  "text" : "@_Rya_ \u00FCber openSNP und Patient-Driven Research reden.",
  "id" : 153880547351990273,
  "in_reply_to_status_id" : 153880037945389057,
  "created_at" : "2012-01-02 16:49:16 +0000",
  "in_reply_to_screen_name" : "_Rya_",
  "in_reply_to_user_id_str" : "89234537",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cae Vye",
      "screen_name" : "CaeVye",
      "indices" : [ 0, 7 ],
      "id_str" : "31104704",
      "id" : 31104704
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "153879558414794753",
  "geo" : { },
  "id_str" : "153880453663825920",
  "in_reply_to_user_id" : 31104704,
  "text" : "@CaeVye und es gibt nie Sicherheitsl\u00F6cher\/gezielte Leaks?",
  "id" : 153880453663825920,
  "in_reply_to_status_id" : 153879558414794753,
  "created_at" : "2012-01-02 16:48:53 +0000",
  "in_reply_to_screen_name" : "CaeVye",
  "in_reply_to_user_id_str" : "31104704",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cae Vye",
      "screen_name" : "CaeVye",
      "indices" : [ 0, 7 ],
      "id_str" : "31104704",
      "id" : 31104704
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "153878945266270208",
  "geo" : { },
  "id_str" : "153879200615501824",
  "in_reply_to_user_id" : 31104704,
  "text" : "@CaeVye wenn wir in Sachen personalisierter Medizin weiterkommen wollen f\u00FChrt daran aber kein Weg vorbei.",
  "id" : 153879200615501824,
  "in_reply_to_status_id" : 153878945266270208,
  "created_at" : "2012-01-02 16:43:55 +0000",
  "in_reply_to_screen_name" : "CaeVye",
  "in_reply_to_user_id_str" : "31104704",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "153878919878164480",
  "text" : "Got tickets to Strasbourg and already finished my slides.",
  "id" : 153878919878164480,
  "created_at" : "2012-01-02 16:42:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cae Vye",
      "screen_name" : "CaeVye",
      "indices" : [ 0, 7 ],
      "id_str" : "31104704",
      "id" : 31104704
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "153877188213612544",
  "geo" : { },
  "id_str" : "153878623160504320",
  "in_reply_to_user_id" : 31104704,
  "text" : "@CaeVye ja, aber dahin wollen wir doch?",
  "id" : 153878623160504320,
  "in_reply_to_status_id" : 153877188213612544,
  "created_at" : "2012-01-02 16:41:37 +0000",
  "in_reply_to_screen_name" : "CaeVye",
  "in_reply_to_user_id_str" : "31104704",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 98 ],
      "url" : "http:\/\/t.co\/K0A78zlw",
      "expanded_url" : "http:\/\/j.mp\/sbZPTG",
      "display_url" : "j.mp\/sbZPTG"
    } ]
  },
  "geo" : { },
  "id_str" : "153875515122528256",
  "text" : "\u00ABImagine if we could be open about our health. What good could come of that?\u00BB http:\/\/t.co\/K0A78zlw",
  "id" : 153875515122528256,
  "created_at" : "2012-01-02 16:29:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "153836507453587456",
  "text" : "Chief Buzzword Officer",
  "id" : 153836507453587456,
  "created_at" : "2012-01-02 13:54:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "153832160913145856",
  "geo" : { },
  "id_str" : "153835492666908673",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon DHL war es ;)",
  "id" : 153835492666908673,
  "in_reply_to_status_id" : 153832160913145856,
  "created_at" : "2012-01-02 13:50:14 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "153823249044733952",
  "text" : "\u00ABWhy X is the future of Y\u00BB Feels like Social Media Expert...",
  "id" : 153823249044733952,
  "created_at" : "2012-01-02 13:01:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Henklein",
      "screen_name" : "snooze82",
      "indices" : [ 0, 9 ],
      "id_str" : "14094265",
      "id" : 14094265
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "153808378215399424",
  "geo" : { },
  "id_str" : "153808477754621952",
  "in_reply_to_user_id" : 14094265,
  "text" : "@snooze82 ausgezeichnet :D",
  "id" : 153808477754621952,
  "in_reply_to_status_id" : 153808378215399424,
  "created_at" : "2012-01-02 12:02:53 +0000",
  "in_reply_to_screen_name" : "snooze82",
  "in_reply_to_user_id_str" : "14094265",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Henklein",
      "screen_name" : "snooze82",
      "indices" : [ 0, 9 ],
      "id_str" : "14094265",
      "id" : 14094265
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "153807795244900352",
  "geo" : { },
  "id_str" : "153807892573724672",
  "in_reply_to_user_id" : 14094265,
  "text" : "@snooze82 Also morgen bin ich den Tag \u00FCber in Strasbourg, ab Mittwoch aber wieder da.",
  "id" : 153807892573724672,
  "in_reply_to_status_id" : 153807795244900352,
  "created_at" : "2012-01-02 12:00:33 +0000",
  "in_reply_to_screen_name" : "snooze82",
  "in_reply_to_user_id_str" : "14094265",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 47 ],
      "url" : "http:\/\/t.co\/C1KOsC3N",
      "expanded_url" : "http:\/\/j.mp\/uDcCvx",
      "display_url" : "j.mp\/uDcCvx"
    } ]
  },
  "geo" : { },
  "id_str" : "153807226388234240",
  "text" : "Too smart to be a good cop http:\/\/t.co\/C1KOsC3N",
  "id" : 153807226388234240,
  "created_at" : "2012-01-02 11:57:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "153783757722230787",
  "geo" : { },
  "id_str" : "153789699637518336",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer lucky you. I'm still waiting for the shipping-notification ;)",
  "id" : 153789699637518336,
  "in_reply_to_status_id" : 153783757722230787,
  "created_at" : "2012-01-02 10:48:16 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "153616193054445569",
  "geo" : { },
  "id_str" : "153616439394312192",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon du musst dir deine Wegfindung ja auch nicht beim Roomba abschauen!",
  "id" : 153616439394312192,
  "in_reply_to_status_id" : 153616193054445569,
  "created_at" : "2012-01-01 23:19:47 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 3, 12 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "153616272561668096",
  "text" : "RT @Senficon: Der kranke Mann, f\u00FCr den ich durch die Wohnung hetze, um ihm Dinge zu bringen, erkl\u00E4rt mir, dass meine Wegfindung ineffizi ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "153616193054445569",
    "text" : "Der kranke Mann, f\u00FCr den ich durch die Wohnung hetze, um ihm Dinge zu bringen, erkl\u00E4rt mir, dass meine Wegfindung ineffizient ist. O.o",
    "id" : 153616193054445569,
    "created_at" : "2012-01-01 23:18:49 +0000",
    "user" : {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "protected" : false,
      "id_str" : "14861745",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/637016870638350336\/QrtPmoul_normal.jpg",
      "id" : 14861745,
      "verified" : true
    }
  },
  "id" : 153616272561668096,
  "created_at" : "2012-01-01 23:19:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "153614048968179714",
  "text" : "More sleep, hopefully less ill tomorrow...",
  "id" : 153614048968179714,
  "created_at" : "2012-01-01 23:10:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "naturalismus",
      "screen_name" : "naturalismus",
      "indices" : [ 0, 13 ],
      "id_str" : "4562569648",
      "id" : 4562569648
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "153613443080011776",
  "geo" : { },
  "id_str" : "153613828062580736",
  "in_reply_to_user_id" : 77216385,
  "text" : "@Naturalismus und W\u00E4sche waschen...",
  "id" : 153613828062580736,
  "in_reply_to_status_id" : 153613443080011776,
  "created_at" : "2012-01-01 23:09:25 +0000",
  "in_reply_to_screen_name" : "fireantprincess",
  "in_reply_to_user_id_str" : "77216385",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mrgunn",
      "screen_name" : "mrgunn",
      "indices" : [ 0, 7 ],
      "id_str" : "15237935",
      "id" : 15237935
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "153610890221060096",
  "geo" : { },
  "id_str" : "153610995196100608",
  "in_reply_to_user_id" : 15237935,
  "text" : "@mrgunn sure :)",
  "id" : 153610995196100608,
  "in_reply_to_status_id" : 153610890221060096,
  "created_at" : "2012-01-01 22:58:09 +0000",
  "in_reply_to_screen_name" : "mrgunn",
  "in_reply_to_user_id_str" : "15237935",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mrgunn",
      "screen_name" : "mrgunn",
      "indices" : [ 0, 7 ],
      "id_str" : "15237935",
      "id" : 15237935
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "153608806989967362",
  "in_reply_to_user_id" : 15237935,
  "text" : "@mrgunn worked on the screencast\/video for openSNP. will need some time to finish post-production. but I've not forgot about it.",
  "id" : 153608806989967362,
  "created_at" : "2012-01-01 22:49:28 +0000",
  "in_reply_to_screen_name" : "mrgunn",
  "in_reply_to_user_id_str" : "15237935",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John McKay",
      "screen_name" : "archymck",
      "indices" : [ 3, 12 ],
      "id_str" : "106542818",
      "id" : 106542818
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "153599077337137152",
  "text" : "RT @archymck: Newt Gingrich says he knows climate change isn't real because he's \"an amateur paleontologist.\" I smell a meme.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/chrome.google.com\/extensions\/detail\/encaiiljifbdbjlphpgpiimidegddhic\" rel=\"nofollow\"\u003ESilver Bird\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "153584485496135680",
    "text" : "Newt Gingrich says he knows climate change isn't real because he's \"an amateur paleontologist.\" I smell a meme.",
    "id" : 153584485496135680,
    "created_at" : "2012-01-01 21:12:49 +0000",
    "user" : {
      "name" : "John McKay",
      "screen_name" : "archymck",
      "protected" : false,
      "id_str" : "106542818",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/642509418\/Skramm_normal.jpg",
      "id" : 106542818,
      "verified" : false
    }
  },
  "id" : 153599077337137152,
  "created_at" : "2012-01-01 22:10:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "153592792948539393",
  "text" : "Mein Beitrag zu Patient-Driven Research heute: Getestet wie lange man an einem Tag im Bett bleiben kann.",
  "id" : 153592792948539393,
  "created_at" : "2012-01-01 21:45:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sebastian Boegel",
      "screen_name" : "sebboeg",
      "indices" : [ 0, 8 ],
      "id_str" : "296476788",
      "id" : 296476788
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "153549304257191936",
  "geo" : { },
  "id_str" : "153552430683000832",
  "in_reply_to_user_id" : 296476788,
  "text" : "@sebboeg Ja, zu teuer und mangelnde Informationspolitik ist meine Meinung dazu.",
  "id" : 153552430683000832,
  "in_reply_to_status_id" : 153549304257191936,
  "created_at" : "2012-01-01 19:05:26 +0000",
  "in_reply_to_screen_name" : "sebboeg",
  "in_reply_to_user_id_str" : "296476788",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "153459916986789889",
  "geo" : { },
  "id_str" : "153460008485523456",
  "in_reply_to_user_id" : 30868098,
  "text" : "@davezerave Weil ich gestern Abend auch nur gearbeitet hab :(",
  "id" : 153460008485523456,
  "in_reply_to_status_id" : 153459916986789889,
  "created_at" : "2012-01-01 12:58:11 +0000",
  "in_reply_to_screen_name" : "dvzrv",
  "in_reply_to_user_id_str" : "30868098",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hans H\u00FCbner",
      "screen_name" : "HansHuebner",
      "indices" : [ 3, 15 ],
      "id_str" : "14329882",
      "id" : 14329882
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "spack0",
      "indices" : [ 22, 29 ]
    } ],
    "urls" : [ {
      "indices" : [ 74, 94 ],
      "url" : "http:\/\/t.co\/VNX2SaiY",
      "expanded_url" : "http:\/\/www.youtube.com\/user\/lisphans\/videos",
      "display_url" : "youtube.com\/user\/lisphans\/\u2026"
    }, {
      "indices" : [ 99, 119 ],
      "url" : "http:\/\/t.co\/tyd0eN3t",
      "expanded_url" : "http:\/\/bknr.net\/spack0\/",
      "display_url" : "bknr.net\/spack0\/"
    } ]
  },
  "geo" : { },
  "id_str" : "153458151809753089",
  "text" : "RT @HansHuebner: alle #spack0 videos bis auf fickileaks jetzt auf youtube http:\/\/t.co\/VNX2SaiY und http:\/\/t.co\/tyd0eN3t",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "spack0",
        "indices" : [ 5, 12 ]
      } ],
      "urls" : [ {
        "indices" : [ 57, 77 ],
        "url" : "http:\/\/t.co\/VNX2SaiY",
        "expanded_url" : "http:\/\/www.youtube.com\/user\/lisphans\/videos",
        "display_url" : "youtube.com\/user\/lisphans\/\u2026"
      }, {
        "indices" : [ 82, 102 ],
        "url" : "http:\/\/t.co\/tyd0eN3t",
        "expanded_url" : "http:\/\/bknr.net\/spack0\/",
        "display_url" : "bknr.net\/spack0\/"
      } ]
    },
    "geo" : { },
    "id_str" : "153457138407178240",
    "text" : "alle #spack0 videos bis auf fickileaks jetzt auf youtube http:\/\/t.co\/VNX2SaiY und http:\/\/t.co\/tyd0eN3t",
    "id" : 153457138407178240,
    "created_at" : "2012-01-01 12:46:47 +0000",
    "user" : {
      "name" : "Hans H\u00FCbner",
      "screen_name" : "HansHuebner",
      "protected" : false,
      "id_str" : "14329882",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/567661538782093314\/kXtaMUSA_normal.jpeg",
      "id" : 14329882,
      "verified" : false
    }
  },
  "id" : 153458151809753089,
  "created_at" : "2012-01-01 12:50:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "153456286963474433",
  "geo" : { },
  "id_str" : "153456385294729217",
  "in_reply_to_user_id" : 30868098,
  "text" : "@davezerave Ne, sitz gerade noch an ein bisschen Arbeit. Wollt es mir danach reinziehen :)",
  "id" : 153456385294729217,
  "in_reply_to_status_id" : 153456286963474433,
  "created_at" : "2012-01-01 12:43:47 +0000",
  "in_reply_to_screen_name" : "dvzrv",
  "in_reply_to_user_id_str" : "30868098",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "153449299441750016",
  "text" : "Das warten aufs 21. Jahrhundert hat ein Ende: Staubsaugeroboter bestellt.",
  "id" : 153449299441750016,
  "created_at" : "2012-01-01 12:15:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alostrael Venenbaum",
      "screen_name" : "Sinneswandlerin",
      "indices" : [ 0, 16 ],
      "id_str" : "154512173",
      "id" : 154512173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "153253702206107648",
  "geo" : { },
  "id_str" : "153253829167677441",
  "in_reply_to_user_id" : 154512173,
  "text" : "@Sinneswandlerin danke! Dir aber auch. :)",
  "id" : 153253829167677441,
  "in_reply_to_status_id" : 153253702206107648,
  "created_at" : "2011-12-31 23:18:54 +0000",
  "in_reply_to_screen_name" : "Sinneswandlerin",
  "in_reply_to_user_id_str" : "154512173",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "schusselhexe",
      "screen_name" : "christorolo",
      "indices" : [ 0, 12 ],
      "id_str" : "292924620",
      "id" : 292924620
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "153251062097260544",
  "geo" : { },
  "id_str" : "153252140800937984",
  "in_reply_to_user_id" : 292924620,
  "text" : "@christorolo n\u00E4chsten Monat vielleicht mal :(",
  "id" : 153252140800937984,
  "in_reply_to_status_id" : 153251062097260544,
  "created_at" : "2011-12-31 23:12:12 +0000",
  "in_reply_to_screen_name" : "christorolo",
  "in_reply_to_user_id_str" : "292924620",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "153250509657096193",
  "text" : "Immerhin wird mein Stundenzettel sagen das ich bis zur letzten Minute gearbeitet habe...",
  "id" : 153250509657096193,
  "created_at" : "2011-12-31 23:05:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
} ]