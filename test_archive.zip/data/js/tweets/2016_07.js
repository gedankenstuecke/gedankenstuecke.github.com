Grailbird.data.tweets_2016_07 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/759841753058963457\/photo\/1",
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/2etFwuMFiV",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cot_4NTXYAUtk6b.jpg",
      "id_str" : "759841565762347013",
      "id" : 759841565762347013,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cot_4NTXYAUtk6b.jpg",
      "sizes" : [ {
        "h" : 4032,
        "resize" : "fit",
        "w" : 3024
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      } ],
      "display_url" : "pic.twitter.com\/2etFwuMFiV"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35920434362713, 8.587681027922981 ]
  },
  "id_str" : "759841753058963457",
  "text" : "As much as I like the book so far: I always fear that bystanders see this as the worst \u2018no homo\u2019-lit\u2026 :\/ https:\/\/t.co\/2etFwuMFiV",
  "id" : 759841753058963457,
  "created_at" : "2016-07-31 20:02:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dom Greves",
      "screen_name" : "domgreves",
      "indices" : [ 0, 10 ],
      "id_str" : "233991496",
      "id" : 233991496
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "759833537084141568",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35921693230093, 8.58770553476875 ]
  },
  "id_str" : "759838844091064320",
  "in_reply_to_user_id" : 233991496,
  "text" : "@domgreves not really, lots of Chinese people move abroad, so give lots of people in the global community? :)",
  "id" : 759838844091064320,
  "in_reply_to_status_id" : 759833537084141568,
  "created_at" : "2016-07-31 19:51:12 +0000",
  "in_reply_to_screen_name" : "domgreves",
  "in_reply_to_user_id_str" : "233991496",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35923417036685, 8.587703305618511 ]
  },
  "id_str" : "759838665224880128",
  "text" : "\u00ABYou totally sounded like a fake persona at first. One whose creator didn\u2019t bother flipping past letter A in the \u201CBook of Ethnic Names\u201D.\u00BB",
  "id" : 759838665224880128,
  "created_at" : "2016-07-31 19:50:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emilio Ferrara",
      "screen_name" : "jabawack",
      "indices" : [ 0, 9 ],
      "id_str" : "17354555",
      "id" : 17354555
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "759821897529831426",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35924660300399, 8.587700058298758 ]
  },
  "id_str" : "759831105071681536",
  "in_reply_to_user_id" : 17354555,
  "text" : "@jabawack great idea, thanks!",
  "id" : 759831105071681536,
  "in_reply_to_status_id" : 759821897529831426,
  "created_at" : "2016-07-31 19:20:27 +0000",
  "in_reply_to_screen_name" : "jabawack",
  "in_reply_to_user_id_str" : "17354555",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mohamed Sayed",
      "screen_name" : "ma7madsayed",
      "indices" : [ 0, 12 ],
      "id_str" : "16384982",
      "id" : 16384982
    }, {
      "name" : "The Royal Society",
      "screen_name" : "royalsociety",
      "indices" : [ 13, 26 ],
      "id_str" : "28567809",
      "id" : 28567809
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/2B3nwjPmxa",
      "expanded_url" : "http:\/\/ruleofthirds.de\/scienceisglobal\/",
      "display_url" : "ruleofthirds.de\/scienceisgloba\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "759819993366134785",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35924660300399, 8.587700058298758 ]
  },
  "id_str" : "759830888909770752",
  "in_reply_to_user_id" : 16384982,
  "text" : "@ma7madsayed @royalsociety I only used the emoji flags actually. See here :) https:\/\/t.co\/2B3nwjPmxa",
  "id" : 759830888909770752,
  "in_reply_to_status_id" : 759819993366134785,
  "created_at" : "2016-07-31 19:19:35 +0000",
  "in_reply_to_screen_name" : "ma7madsayed",
  "in_reply_to_user_id_str" : "16384982",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Royal Society",
      "screen_name" : "royalsociety",
      "indices" : [ 0, 13 ],
      "id_str" : "28567809",
      "id" : 28567809
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "759817174810701824",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35924660300399, 8.587700058298758 ]
  },
  "id_str" : "759830768923316224",
  "in_reply_to_user_id" : 28567809,
  "text" : "@royalsociety will do! :)",
  "id" : 759830768923316224,
  "in_reply_to_status_id" : 759817174810701824,
  "created_at" : "2016-07-31 19:19:06 +0000",
  "in_reply_to_screen_name" : "royalsociety",
  "in_reply_to_user_id_str" : "28567809",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Royal Society",
      "screen_name" : "royalsociety",
      "indices" : [ 0, 13 ],
      "id_str" : "28567809",
      "id" : 28567809
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/2B3nwjPmxa",
      "expanded_url" : "http:\/\/ruleofthirds.de\/scienceisglobal\/",
      "display_url" : "ruleofthirds.de\/scienceisgloba\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "759814294145871873",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35925528261403, 8.587697741942844 ]
  },
  "id_str" : "759815406420955136",
  "in_reply_to_user_id" : 28567809,
  "text" : "@royalsociety thanks. I prepared a small blog post on it that I wanted to share on Mon. when more ppl are around :) https:\/\/t.co\/2B3nwjPmxa",
  "id" : 759815406420955136,
  "in_reply_to_status_id" : 759814294145871873,
  "created_at" : "2016-07-31 18:18:04 +0000",
  "in_reply_to_screen_name" : "royalsociety",
  "in_reply_to_user_id_str" : "28567809",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alice Sheppard",
      "screen_name" : "PenguinGalaxy",
      "indices" : [ 0, 14 ],
      "id_str" : "20635230",
      "id" : 20635230
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "759807230552133634",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35922977808636, 8.587777426612355 ]
  },
  "id_str" : "759813082285797376",
  "in_reply_to_user_id" : 20635230,
  "text" : "@PenguinGalaxy done!",
  "id" : 759813082285797376,
  "in_reply_to_status_id" : 759807230552133634,
  "created_at" : "2016-07-31 18:08:50 +0000",
  "in_reply_to_screen_name" : "PenguinGalaxy",
  "in_reply_to_user_id_str" : "20635230",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Noah Raford",
      "screen_name" : "nraford",
      "indices" : [ 0, 8 ],
      "id_str" : "89227119",
      "id" : 89227119
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "759758727637458944",
  "geo" : { },
  "id_str" : "759761127152680960",
  "in_reply_to_user_id" : 89227119,
  "text" : "@nraford which in itself is pretty nice somehow :p",
  "id" : 759761127152680960,
  "in_reply_to_status_id" : 759758727637458944,
  "created_at" : "2016-07-31 14:42:23 +0000",
  "in_reply_to_screen_name" : "nraford",
  "in_reply_to_user_id_str" : "89227119",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Noah Raford",
      "screen_name" : "nraford",
      "indices" : [ 0, 8 ],
      "id_str" : "89227119",
      "id" : 89227119
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "759758727637458944",
  "geo" : { },
  "id_str" : "759761087961194496",
  "in_reply_to_user_id" : 89227119,
  "text" : "@nraford the viz won\u2019t get more informative as the degrees are not too different for most nodes I guess. :)",
  "id" : 759761087961194496,
  "in_reply_to_status_id" : 759758727637458944,
  "created_at" : "2016-07-31 14:42:13 +0000",
  "in_reply_to_screen_name" : "nraford",
  "in_reply_to_user_id_str" : "89227119",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "759757002507681792",
  "geo" : { },
  "id_str" : "759757267378012160",
  "in_reply_to_user_id" : 14286491,
  "text" : "Label\/Node size == # of mentions. Edge size == log(# of co-occurrences).",
  "id" : 759757267378012160,
  "in_reply_to_status_id" : 759757002507681792,
  "created_at" : "2016-07-31 14:27:02 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/759757002507681792\/photo\/1",
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/UiqInrbOn6",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cosy9ofXgAA4MR5.jpg",
      "id_str" : "759756996564451328",
      "id" : 759756996564451328,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cosy9ofXgAA4MR5.jpg",
      "sizes" : [ {
        "h" : 680,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/UiqInrbOn6"
    } ],
    "hashtags" : [ {
      "text" : "ScienceIsGlobal",
      "indices" : [ 73, 89 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "759757002507681792",
  "text" : "What you can see when visualizing the co-occurrence of countries in 8444 #ScienceIsGlobal tweets. https:\/\/t.co\/UiqInrbOn6",
  "id" : 759757002507681792,
  "created_at" : "2016-07-31 14:25:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sujai Kumar",
      "screen_name" : "sujaik",
      "indices" : [ 39, 46 ],
      "id_str" : "33651124",
      "id" : 33651124
    }, {
      "name" : "\uD83D\uDC9A Aure Moser \uD83D\uDC9A",
      "screen_name" : "auremoser",
      "indices" : [ 47, 57 ],
      "id_str" : "186529934",
      "id" : 186529934
    }, {
      "name" : "Egle Ramanauskaite \u2623",
      "screen_name" : "Seplute",
      "indices" : [ 58, 66 ],
      "id_str" : "188833865",
      "id" : 188833865
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Mozfest",
      "indices" : [ 27, 35 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "759734071438241792",
  "text" : "Submitted our proposal for #Mozfest! \uD83C\uDF89 @sujaik @auremoser @Seplute",
  "id" : 759734071438241792,
  "created_at" : "2016-07-31 12:54:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.36415247986542, 8.574795901222954 ]
  },
  "id_str" : "759457050015457280",
  "text" : "\u00ABEvery time we meet each other we destroy our perception of time. And our nails.\u00BB",
  "id" : 759457050015457280,
  "created_at" : "2016-07-30 18:34:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "The_Smoking_GNU",
      "indices" : [ 0, 16 ],
      "id_str" : "14535787",
      "id" : 14535787
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "759113442838114304",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35923769026319, 8.587826996795785 ]
  },
  "id_str" : "759370305735393280",
  "in_reply_to_user_id" : 14535787,
  "text" : "@The_Smoking_GNU which is so sad :\/",
  "id" : 759370305735393280,
  "in_reply_to_status_id" : 759113442838114304,
  "created_at" : "2016-07-30 12:49:23 +0000",
  "in_reply_to_screen_name" : "The_Smoking_GNU",
  "in_reply_to_user_id_str" : "14535787",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 84 ],
      "url" : "https:\/\/t.co\/6NZEdB5DOn",
      "expanded_url" : "https:\/\/twitter.com\/russeltarr\/status\/758346233241034753",
      "display_url" : "twitter.com\/russeltarr\/sta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "758966069495148547",
  "text" : "The only string theory I ever at least partially understood. https:\/\/t.co\/6NZEdB5DOn",
  "id" : 758966069495148547,
  "created_at" : "2016-07-29 10:03:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 54 ],
      "url" : "https:\/\/t.co\/NF5erTqjGd",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=Uqm5K0oiMmM",
      "display_url" : "youtube.com\/watch?v=Uqm5K0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "758940592466309120",
  "text" : "It\u2019s been a long tiresome year https:\/\/t.co\/NF5erTqjGd",
  "id" : 758940592466309120,
  "created_at" : "2016-07-29 08:21:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Schawinski",
      "screen_name" : "kevinschawinski",
      "indices" : [ 0, 16 ],
      "id_str" : "242844365",
      "id" : 242844365
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "758759206430400512",
  "geo" : { },
  "id_str" : "758767006866874368",
  "in_reply_to_user_id" : 242844365,
  "text" : "@kevinschawinski and that\u2019s why you travel w\/ carry-on and nothing else.",
  "id" : 758767006866874368,
  "in_reply_to_status_id" : 758759206430400512,
  "created_at" : "2016-07-28 20:52:06 +0000",
  "in_reply_to_screen_name" : "kevinschawinski",
  "in_reply_to_user_id_str" : "242844365",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kate Crawford",
      "screen_name" : "katecrawford",
      "indices" : [ 3, 16 ],
      "id_str" : "19968025",
      "id" : 19968025
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "758765543528726532",
  "text" : "RT @katecrawford: Make yourself a coffee, choose a comfy chair, and read this paper on bias and word embeddings. Lots to discuss. https:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 112, 135 ],
        "url" : "https:\/\/t.co\/MhPNBwut2B",
        "expanded_url" : "http:\/\/arxiv.org\/pdf\/1607.06520.pdf",
        "display_url" : "arxiv.org\/pdf\/1607.06520\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "758682982286712833",
    "text" : "Make yourself a coffee, choose a comfy chair, and read this paper on bias and word embeddings. Lots to discuss. https:\/\/t.co\/MhPNBwut2B",
    "id" : 758682982286712833,
    "created_at" : "2016-07-28 15:18:13 +0000",
    "user" : {
      "name" : "Kate Crawford",
      "screen_name" : "katecrawford",
      "protected" : false,
      "id_str" : "19968025",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/844013024809631744\/tvoeKcfV_normal.jpg",
      "id" : 19968025,
      "verified" : true
    }
  },
  "id" : 758765543528726532,
  "created_at" : "2016-07-28 20:46:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul-Olivier Dehaye",
      "screen_name" : "podehaye",
      "indices" : [ 0, 9 ],
      "id_str" : "2219841242",
      "id" : 2219841242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "758755425462394880",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.05958501581076, 8.817722027885381 ]
  },
  "id_str" : "758757302778331137",
  "in_reply_to_user_id" : 2219841242,
  "text" : "@podehaye great, looking forward to it!",
  "id" : 758757302778331137,
  "in_reply_to_status_id" : 758755425462394880,
  "created_at" : "2016-07-28 20:13:32 +0000",
  "in_reply_to_screen_name" : "podehaye",
  "in_reply_to_user_id_str" : "2219841242",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luc Henry",
      "screen_name" : "heluc",
      "indices" : [ 0, 6 ],
      "id_str" : "850645992",
      "id" : 850645992
    }, {
      "name" : "Marcel Salathe",
      "screen_name" : "marcelsalathe",
      "indices" : [ 38, 52 ],
      "id_str" : "14177696",
      "id" : 14177696
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 7, 30 ],
      "url" : "https:\/\/t.co\/A0UZnMh6K9",
      "expanded_url" : "https:\/\/twitter.com\/marcelsalathe\/status\/757527684599652352",
      "display_url" : "twitter.com\/marcelsalathe\/\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "758659322834460672",
  "geo" : { },
  "id_str" : "758659598299652096",
  "in_reply_to_user_id" : 850645992,
  "text" : "@heluc https:\/\/t.co\/A0UZnMh6K9 (&amp; @marcelsalathe will be happy to hear that I found flights that allow me to make my talk w\/ max. jetlag)",
  "id" : 758659598299652096,
  "in_reply_to_status_id" : 758659322834460672,
  "created_at" : "2016-07-28 13:45:18 +0000",
  "in_reply_to_screen_name" : "heluc",
  "in_reply_to_user_id_str" : "850645992",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TwistedDoodles",
      "screen_name" : "twisteddoodles",
      "indices" : [ 3, 18 ],
      "id_str" : "487584390",
      "id" : 487584390
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/twisteddoodles\/status\/758587168575160320\/photo\/1",
      "indices" : [ 61, 84 ],
      "url" : "https:\/\/t.co\/ZaFoPwEb2d",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CocK_sDW8AQp8Os.jpg",
      "id_str" : "758587151508500484",
      "id" : 758587151508500484,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CocK_sDW8AQp8Os.jpg",
      "sizes" : [ {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1462
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 485
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 857
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1462
      } ],
      "display_url" : "pic.twitter.com\/ZaFoPwEb2d"
    } ],
    "hashtags" : [ {
      "text" : "science",
      "indices" : [ 40, 48 ]
    }, {
      "text" : "sciencecat",
      "indices" : [ 49, 60 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "758656187520933888",
  "text" : "RT @twisteddoodles: Scientific research #science #sciencecat https:\/\/t.co\/ZaFoPwEb2d",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/twisteddoodles\/status\/758587168575160320\/photo\/1",
        "indices" : [ 41, 64 ],
        "url" : "https:\/\/t.co\/ZaFoPwEb2d",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CocK_sDW8AQp8Os.jpg",
        "id_str" : "758587151508500484",
        "id" : 758587151508500484,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CocK_sDW8AQp8Os.jpg",
        "sizes" : [ {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1462
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 485
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 857
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1462
        } ],
        "display_url" : "pic.twitter.com\/ZaFoPwEb2d"
      } ],
      "hashtags" : [ {
        "text" : "science",
        "indices" : [ 20, 28 ]
      }, {
        "text" : "sciencecat",
        "indices" : [ 29, 40 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "758587168575160320",
    "text" : "Scientific research #science #sciencecat https:\/\/t.co\/ZaFoPwEb2d",
    "id" : 758587168575160320,
    "created_at" : "2016-07-28 08:57:29 +0000",
    "user" : {
      "name" : "TwistedDoodles",
      "screen_name" : "twisteddoodles",
      "protected" : false,
      "id_str" : "487584390",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2923852396\/20613163743438c5ee92899367284184_normal.jpeg",
      "id" : 487584390,
      "verified" : true
    }
  },
  "id" : 758656187520933888,
  "created_at" : "2016-07-28 13:31:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "R\u24EAss Mounce",
      "screen_name" : "rmounce",
      "indices" : [ 0, 8 ],
      "id_str" : "222765418",
      "id" : 222765418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "758642284904710144",
  "geo" : { },
  "id_str" : "758645054147887104",
  "in_reply_to_user_id" : 222765418,
  "text" : "@rmounce awesome, congrats!",
  "id" : 758645054147887104,
  "in_reply_to_status_id" : 758642284904710144,
  "created_at" : "2016-07-28 12:47:30 +0000",
  "in_reply_to_screen_name" : "rmounce",
  "in_reply_to_user_id_str" : "222765418",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Denker",
      "screen_name" : "Phaidr0s",
      "indices" : [ 0, 9 ],
      "id_str" : "40466433",
      "id" : 40466433
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "758643645511770112",
  "geo" : { },
  "id_str" : "758644014950285312",
  "in_reply_to_user_id" : 40466433,
  "text" : "@Phaidr0s ~Mitte 2017.",
  "id" : 758644014950285312,
  "in_reply_to_status_id" : 758643645511770112,
  "created_at" : "2016-07-28 12:43:22 +0000",
  "in_reply_to_screen_name" : "Phaidr0s",
  "in_reply_to_user_id_str" : "40466433",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "758643574783311872",
  "text" : "And there\u2019s the next set of flights: ZRH \u2708\uFE0F IAD \u2708\uFE0F SAN \u2708\uFE0F IAD \u2708\uFE0F GVA.",
  "id" : 758643574783311872,
  "created_at" : "2016-07-28 12:41:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Beatrix150",
      "indices" : [ 15, 26 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/e5YN9L5Nz9",
      "expanded_url" : "https:\/\/www.brainpickings.org\/2015\/07\/28\/beatrix-potter-a-life-in-nature-botany-mycology-fungi\/",
      "display_url" : "brainpickings.org\/2015\/07\/28\/bea\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "758636359666065408",
  "text" : "Happy Birthday #Beatrix150 Potter! She\u2019s one of my favorite mycologists\/lichenologists! https:\/\/t.co\/e5YN9L5Nz9",
  "id" : 758636359666065408,
  "created_at" : "2016-07-28 12:12:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "758600232666009600",
  "text" : "Hard to follow US elections w\/o thinking of Arendt\u2019s \u201Ethose who choose the lesser evil forget very quickly that they choose evil\u201C, isn\u2019t it?",
  "id" : 758600232666009600,
  "created_at" : "2016-07-28 09:49:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helen Taylor",
      "screen_name" : "HelenTaylorCG",
      "indices" : [ 3, 17 ],
      "id_str" : "3058881006",
      "id" : 3058881006
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "758576193847300097",
  "text" : "RT @HelenTaylorCG: Conference rules: \"dietary requirements will not be catered for at lunch or morning tea\". Okaaaaay, where's my discount\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "758512452329836544",
    "text" : "Conference rules: \"dietary requirements will not be catered for at lunch or morning tea\". Okaaaaay, where's my discount for non-edible food?",
    "id" : 758512452329836544,
    "created_at" : "2016-07-28 04:00:35 +0000",
    "user" : {
      "name" : "Helen Taylor",
      "screen_name" : "HelenTaylorCG",
      "protected" : false,
      "id_str" : "3058881006",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/572569975928283136\/093KHYFq_normal.jpeg",
      "id" : 3058881006,
      "verified" : false
    }
  },
  "id" : 758576193847300097,
  "created_at" : "2016-07-28 08:13:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alice Sheppard",
      "screen_name" : "PenguinGalaxy",
      "indices" : [ 0, 14 ],
      "id_str" : "20635230",
      "id" : 20635230
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "758313342683480064",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17357381862124, 8.62830320972555 ]
  },
  "id_str" : "758313421385465856",
  "in_reply_to_user_id" : 20635230,
  "text" : "@PenguinGalaxy i might, at latest end of October for the MozFest. :)",
  "id" : 758313421385465856,
  "in_reply_to_status_id" : 758313342683480064,
  "created_at" : "2016-07-27 14:49:43 +0000",
  "in_reply_to_screen_name" : "PenguinGalaxy",
  "in_reply_to_user_id_str" : "20635230",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alice Sheppard",
      "screen_name" : "PenguinGalaxy",
      "indices" : [ 0, 14 ],
      "id_str" : "20635230",
      "id" : 20635230
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "758313051674279936",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17357534892926, 8.628303566768674 ]
  },
  "id_str" : "758313124915064834",
  "in_reply_to_user_id" : 20635230,
  "text" : "@PenguinGalaxy sure, may even happen next month!",
  "id" : 758313124915064834,
  "in_reply_to_status_id" : 758313051674279936,
  "created_at" : "2016-07-27 14:48:32 +0000",
  "in_reply_to_screen_name" : "PenguinGalaxy",
  "in_reply_to_user_id_str" : "20635230",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lara",
      "screen_name" : "alibi_ranch",
      "indices" : [ 0, 12 ],
      "id_str" : "265371167",
      "id" : 265371167
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "758311331502129158",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17357873979063, 8.628311206925508 ]
  },
  "id_str" : "758311403556106241",
  "in_reply_to_user_id" : 265371167,
  "text" : "@alibi_ranch sehr gern!",
  "id" : 758311403556106241,
  "in_reply_to_status_id" : 758311331502129158,
  "created_at" : "2016-07-27 14:41:42 +0000",
  "in_reply_to_screen_name" : "alibi_ranch",
  "in_reply_to_user_id_str" : "265371167",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "openscience",
      "indices" : [ 48, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 68, 91 ],
      "url" : "https:\/\/t.co\/aGAsKSRXBO",
      "expanded_url" : "https:\/\/twitter.com\/abbycabs\/status\/758278653981683712",
      "display_url" : "twitter.com\/abbycabs\/statu\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17352307596973, 8.629617573120608 ]
  },
  "id_str" : "758285092938719232",
  "text" : "Already started working on my submission to the #openscience space! https:\/\/t.co\/aGAsKSRXBO",
  "id" : 758285092938719232,
  "created_at" : "2016-07-27 12:57:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alice Sheppard",
      "screen_name" : "PenguinGalaxy",
      "indices" : [ 15, 29 ],
      "id_str" : "20635230",
      "id" : 20635230
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/CTHM2vnWXa",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/758263733835685889",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "758263733835685889",
  "geo" : { },
  "id_str" : "758265915024744449",
  "in_reply_to_user_id" : 14286491,
  "text" : "And good news, @PenguinGalaxy, Cecilia Payne is featured amongst them! https:\/\/t.co\/CTHM2vnWXa",
  "id" : 758265915024744449,
  "in_reply_to_status_id" : 758263733835685889,
  "created_at" : "2016-07-27 11:40:56 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/758263733835685889\/photo\/1",
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/bt6nhCXNai",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CoXk1-xW8AAi9uN.jpg",
      "id_str" : "758263728316018688",
      "id" : 758263728316018688,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CoXk1-xW8AAi9uN.jpg",
      "sizes" : [ {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 1398,
        "resize" : "fit",
        "w" : 1049
      }, {
        "h" : 1398,
        "resize" : "fit",
        "w" : 1049
      } ],
      "display_url" : "pic.twitter.com\/bt6nhCXNai"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172468, 8.627421 ]
  },
  "id_str" : "758263733835685889",
  "text" : "Being called by the porter of my university because there's an important package waiting for me. \uD83D\uDE0D https:\/\/t.co\/bt6nhCXNai",
  "id" : 758263733835685889,
  "created_at" : "2016-07-27 11:32:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ScienceIsGlobal",
      "indices" : [ 51, 67 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17358443398105, 8.628302756468123 ]
  },
  "id_str" : "758257723158953984",
  "text" : "For the lab I\u2019m doing my dayjob in: \uD83C\uDDEE\uD83C\uDDF3\uD83C\uDDFB\uD83C\uDDF3\uD83C\uDDE9\uD83C\uDDF0\uD83C\uDDEA\uD83C\uDDF8\uD83C\uDDEE\uD83C\uDDF7\uD83C\uDDE9\uD83C\uDDEA\uD83C\uDDF2\uD83C\uDDFD #ScienceIsGlobal",
  "id" : 758257723158953984,
  "created_at" : "2016-07-27 11:08:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ScienceIsGlobal",
      "indices" : [ 59, 75 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17362713126241, 8.628253103754458 ]
  },
  "id_str" : "758254940343140352",
  "text" : "For openSNP (I bet I forgot some country!): \uD83C\uDDE8\uD83C\uDDE6\uD83C\uDDE7\uD83C\uDDF7\uD83C\uDDE6\uD83C\uDDFA\uD83C\uDDE9\uD83C\uDDEA\uD83C\uDDFA\uD83C\uDDF8\uD83C\uDDEE\uD83C\uDDF3\uD83C\uDDEC\uD83C\uDDE7 #ScienceIsGlobal",
  "id" : 758254940343140352,
  "created_at" : "2016-07-27 10:57:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 7, 30 ],
      "url" : "https:\/\/t.co\/xcYle9F0bf",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BIXK1UgjWkG\/",
      "display_url" : "instagram.com\/p\/BIXK1UgjWkG\/"
    } ]
  },
  "geo" : { },
  "id_str" : "758251738600202240",
  "text" : "Brainy https:\/\/t.co\/xcYle9F0bf",
  "id" : 758251738600202240,
  "created_at" : "2016-07-27 10:44:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul-Olivier Dehaye",
      "screen_name" : "podehaye",
      "indices" : [ 0, 9 ],
      "id_str" : "2219841242",
      "id" : 2219841242
    }, {
      "name" : "23andMe",
      "screen_name" : "23andMe",
      "indices" : [ 10, 18 ],
      "id_str" : "14738561",
      "id" : 14738561
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "758003515755270144",
  "geo" : { },
  "id_str" : "758003738929922048",
  "in_reply_to_user_id" : 2219841242,
  "text" : "@podehaye @23andMe sure, please email me about it. :)",
  "id" : 758003738929922048,
  "in_reply_to_status_id" : 758003515755270144,
  "created_at" : "2016-07-26 18:19:09 +0000",
  "in_reply_to_screen_name" : "podehaye",
  "in_reply_to_user_id_str" : "2219841242",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "A. Murat Eren",
      "screen_name" : "merenbey",
      "indices" : [ 0, 9 ],
      "id_str" : "16029156",
      "id" : 16029156
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "757964538784391168",
  "geo" : { },
  "id_str" : "757964676508573696",
  "in_reply_to_user_id" : 16029156,
  "text" : "@merenbey email will be best for me too as I can easily fit that into my already full schedule this week.",
  "id" : 757964676508573696,
  "in_reply_to_status_id" : 757964538784391168,
  "created_at" : "2016-07-26 15:43:55 +0000",
  "in_reply_to_screen_name" : "merenbey",
  "in_reply_to_user_id_str" : "16029156",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "A. Murat Eren",
      "screen_name" : "merenbey",
      "indices" : [ 0, 9 ],
      "id_str" : "16029156",
      "id" : 16029156
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "757959115616452609",
  "geo" : { },
  "id_str" : "757959476188151808",
  "in_reply_to_user_id" : 16029156,
  "text" : "@merenbey \u2026but I\u2019d be interested in talking to you about what I\u2019ve planned to use it for if you\u2019re up for it!",
  "id" : 757959476188151808,
  "in_reply_to_status_id" : 757959115616452609,
  "created_at" : "2016-07-26 15:23:15 +0000",
  "in_reply_to_screen_name" : "merenbey",
  "in_reply_to_user_id_str" : "16029156",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "A. Murat Eren",
      "screen_name" : "merenbey",
      "indices" : [ 0, 9 ],
      "id_str" : "16029156",
      "id" : 16029156
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "757959115616452609",
  "geo" : { },
  "id_str" : "757959259225219072",
  "in_reply_to_user_id" : 16029156,
  "text" : "@merenbey Sorry, wasn\u2019t even meant like this. More like: Haven\u2019t made it to the actual installation step. The OS X installer worked fine.",
  "id" : 757959259225219072,
  "in_reply_to_status_id" : 757959115616452609,
  "created_at" : "2016-07-26 15:22:24 +0000",
  "in_reply_to_screen_name" : "merenbey",
  "in_reply_to_user_id_str" : "16029156",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/PuOwRvp7T7",
      "expanded_url" : "https:\/\/aeon.co\/essays\/there-s-no-emotion-we-ought-to-think-harder-about-than-anger",
      "display_url" : "aeon.co\/essays\/there-s\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172495, 8.62755 ]
  },
  "id_str" : "757942020342177792",
  "text" : "\u00ABThere\u2019s no emotion we ought to think harder about than anger\u00BB by Martha C Nussbaum https:\/\/t.co\/PuOwRvp7T7",
  "id" : 757942020342177792,
  "created_at" : "2016-07-26 14:13:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 63 ],
      "url" : "https:\/\/t.co\/egrjxzKyH6",
      "expanded_url" : "http:\/\/www.nytimes.com\/video\/multimedia\/100000004526979\/fragments-of-a-life-a-curbside-mystery.html",
      "display_url" : "nytimes.com\/video\/multimed\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "757939463179960320",
  "text" : "Fragments of a Life: A Curbside Mystery https:\/\/t.co\/egrjxzKyH6",
  "id" : 757939463179960320,
  "created_at" : "2016-07-26 14:03:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Torsten Seemann",
      "screen_name" : "torstenseemann",
      "indices" : [ 0, 15 ],
      "id_str" : "42558652",
      "id" : 42558652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "757925853988663297",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17343705288097, 8.628382753447779 ]
  },
  "id_str" : "757926832213729280",
  "in_reply_to_user_id" : 42558652,
  "text" : "@torstenseemann to be fair, some organizations are super easy with it. But my Uni is horrible.",
  "id" : 757926832213729280,
  "in_reply_to_status_id" : 757925853988663297,
  "created_at" : "2016-07-26 13:13:33 +0000",
  "in_reply_to_screen_name" : "torstenseemann",
  "in_reply_to_user_id_str" : "42558652",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 6, 29 ],
      "url" : "https:\/\/t.co\/Tb7kBQiYc6",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BIU21TcDkfB\/",
      "display_url" : "instagram.com\/p\/BIU21TcDkfB\/"
    } ]
  },
  "geo" : { },
  "id_str" : "757926282785124352",
  "text" : "Sunny https:\/\/t.co\/Tb7kBQiYc6",
  "id" : 757926282785124352,
  "created_at" : "2016-07-26 13:11:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Torsten Seemann",
      "screen_name" : "torstenseemann",
      "indices" : [ 0, 15 ],
      "id_str" : "42558652",
      "id" : 42558652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "757922082416058370",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1745594874052, 8.627931718045303 ]
  },
  "id_str" : "757925345353924612",
  "in_reply_to_user_id" : 42558652,
  "text" : "@torstenseemann I don\u2019t even try to make daily reclaims because it\u2019s so hard. Just give me the money for the flights and I\u2019ll shut up.",
  "id" : 757925345353924612,
  "in_reply_to_status_id" : 757922082416058370,
  "created_at" : "2016-07-26 13:07:38 +0000",
  "in_reply_to_screen_name" : "torstenseemann",
  "in_reply_to_user_id_str" : "42558652",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "A. Murat Eren",
      "screen_name" : "merenbey",
      "indices" : [ 59, 68 ],
      "id_str" : "16029156",
      "id" : 16029156
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "757901825232232448",
  "text" : "I have yet to suceed in installing anvi\u2019o, but the docs by @merenbey are so full of humor that it\u2019s fun in any case.",
  "id" : 757901825232232448,
  "created_at" : "2016-07-26 11:34:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/p93vR4nDPu",
      "expanded_url" : "https:\/\/www.theguardian.com\/world\/2016\/jul\/26\/code-club-senegal-where-women-lead-the-way",
      "display_url" : "theguardian.com\/world\/2016\/jul\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "757894128973807620",
  "text" : "\u00ABI can imagine a Senegalese woman at the head of Google without a problem\u00BB \uD83D\uDC96 https:\/\/t.co\/p93vR4nDPu",
  "id" : 757894128973807620,
  "created_at" : "2016-07-26 11:03:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "757891692594880512",
  "geo" : { },
  "id_str" : "757892115087187968",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich hatte ich nicht. I\u2019m in tears! \uD83D\uDE02\uD83D\uDE02\uD83D\uDE02",
  "id" : 757892115087187968,
  "in_reply_to_status_id" : 757891692594880512,
  "created_at" : "2016-07-26 10:55:35 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "precarious underemployed early career academic",
      "screen_name" : "TheLitCritGuy",
      "indices" : [ 3, 17 ],
      "id_str" : "464620194",
      "id" : 464620194
    }, {
      "name" : "Donald J. Trump",
      "screen_name" : "realDonaldTrump",
      "indices" : [ 23, 39 ],
      "id_str" : "25073877",
      "id" : 25073877
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/TheLitCritGuy\/status\/757596274195660801\/photo\/1",
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/DkPO7keIFl",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CoOFpVLW8AAjTKk.jpg",
      "id_str" : "757596107434291200",
      "id" : 757596107434291200,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CoOFpVLW8AAjTKk.jpg",
      "sizes" : [ {
        "h" : 953,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 953,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 675,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 953,
        "resize" : "fit",
        "w" : 960
      } ],
      "display_url" : "pic.twitter.com\/DkPO7keIFl"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "757892017213046784",
  "text" : "RT @TheLitCritGuy: So, @realDonaldTrump is doing a reddit ama? Hope someone brings up this SHOCKING quote. https:\/\/t.co\/DkPO7keIFl",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Donald J. Trump",
        "screen_name" : "realDonaldTrump",
        "indices" : [ 4, 20 ],
        "id_str" : "25073877",
        "id" : 25073877
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/TheLitCritGuy\/status\/757596274195660801\/photo\/1",
        "indices" : [ 88, 111 ],
        "url" : "https:\/\/t.co\/DkPO7keIFl",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CoOFpVLW8AAjTKk.jpg",
        "id_str" : "757596107434291200",
        "id" : 757596107434291200,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CoOFpVLW8AAjTKk.jpg",
        "sizes" : [ {
          "h" : 953,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 953,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 675,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 953,
          "resize" : "fit",
          "w" : 960
        } ],
        "display_url" : "pic.twitter.com\/DkPO7keIFl"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "757596274195660801",
    "text" : "So, @realDonaldTrump is doing a reddit ama? Hope someone brings up this SHOCKING quote. https:\/\/t.co\/DkPO7keIFl",
    "id" : 757596274195660801,
    "created_at" : "2016-07-25 15:20:01 +0000",
    "user" : {
      "name" : "precarious underemployed early career academic",
      "screen_name" : "TheLitCritGuy",
      "protected" : false,
      "id_str" : "464620194",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/927547608939270145\/qodp--Ln_normal.jpg",
      "id" : 464620194,
      "verified" : false
    }
  },
  "id" : 757892017213046784,
  "created_at" : "2016-07-26 10:55:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 51 ],
      "url" : "https:\/\/t.co\/86O3B9rjIw",
      "expanded_url" : "http:\/\/existentialcomics.com\/comic\/143",
      "display_url" : "existentialcomics.com\/comic\/143"
    } ]
  },
  "geo" : { },
  "id_str" : "757890315864997888",
  "text" : "Philosophizing and Punching https:\/\/t.co\/86O3B9rjIw",
  "id" : 757890315864997888,
  "created_at" : "2016-07-26 10:48:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Edmunds",
      "screen_name" : "SCEdmunds",
      "indices" : [ 0, 10 ],
      "id_str" : "176024190",
      "id" : 176024190
    }, {
      "name" : "Laurie Goodman",
      "screen_name" : "Grimhawk1",
      "indices" : [ 11, 21 ],
      "id_str" : "67713333",
      "id" : 67713333
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "757878310349058048",
  "geo" : { },
  "id_str" : "757878979588227072",
  "in_reply_to_user_id" : 176024190,
  "text" : "@SCEdmunds @Grimhawk1 that looks like a free spot in my calendar until now :p",
  "id" : 757878979588227072,
  "in_reply_to_status_id" : 757878310349058048,
  "created_at" : "2016-07-26 10:03:24 +0000",
  "in_reply_to_screen_name" : "SCEdmunds",
  "in_reply_to_user_id_str" : "176024190",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Linus Schumacher",
      "screen_name" : "LinusSchumacher",
      "indices" : [ 0, 16 ],
      "id_str" : "2289913051",
      "id" : 2289913051
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "757872770927689728",
  "geo" : { },
  "id_str" : "757878933434011648",
  "in_reply_to_user_id" : 2289913051,
  "text" : "@LinusSchumacher less forms, more trust would be a start? :)",
  "id" : 757878933434011648,
  "in_reply_to_status_id" : 757872770927689728,
  "created_at" : "2016-07-26 10:03:13 +0000",
  "in_reply_to_screen_name" : "LinusSchumacher",
  "in_reply_to_user_id_str" : "2289913051",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 64 ],
      "url" : "https:\/\/t.co\/Z8emWRqh7K",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=7GMs5DUfCf0",
      "display_url" : "youtube.com\/watch?v=7GMs5D\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "757878044279308288",
  "text" : "\u00ABI can never come back if I don\u2019t go.\u00BB \uD83C\uDFDE https:\/\/t.co\/Z8emWRqh7K",
  "id" : 757878044279308288,
  "created_at" : "2016-07-26 09:59:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Edmunds",
      "screen_name" : "SCEdmunds",
      "indices" : [ 0, 10 ],
      "id_str" : "176024190",
      "id" : 176024190
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "757877338201731072",
  "geo" : { },
  "id_str" : "757877481055617024",
  "in_reply_to_user_id" : 176024190,
  "text" : "@SCEdmunds oh, wow! Any chance of getting invited? (And when is ICG11?)",
  "id" : 757877481055617024,
  "in_reply_to_status_id" : 757877338201731072,
  "created_at" : "2016-07-26 09:57:26 +0000",
  "in_reply_to_screen_name" : "SCEdmunds",
  "in_reply_to_user_id_str" : "176024190",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Edmunds",
      "screen_name" : "SCEdmunds",
      "indices" : [ 0, 10 ],
      "id_str" : "176024190",
      "id" : 176024190
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "757876686817857536",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17246424698532, 8.627424850554855 ]
  },
  "id_str" : "757876787183489024",
  "in_reply_to_user_id" : 176024190,
  "text" : "@SCEdmunds would love to go visit now!",
  "id" : 757876787183489024,
  "in_reply_to_status_id" : 757876686817857536,
  "created_at" : "2016-07-26 09:54:41 +0000",
  "in_reply_to_screen_name" : "SCEdmunds",
  "in_reply_to_user_id_str" : "176024190",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Edmunds",
      "screen_name" : "SCEdmunds",
      "indices" : [ 0, 10 ],
      "id_str" : "176024190",
      "id" : 176024190
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "757840138139373568",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17246517836648, 8.627423605358103 ]
  },
  "id_str" : "757875029027721216",
  "in_reply_to_user_id" : 176024190,
  "text" : "@SCEdmunds wow, impressive how quick that went.",
  "id" : 757875029027721216,
  "in_reply_to_status_id" : 757840138139373568,
  "created_at" : "2016-07-26 09:47:42 +0000",
  "in_reply_to_screen_name" : "SCEdmunds",
  "in_reply_to_user_id_str" : "176024190",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 131, 140 ],
      "id_str" : "14245811",
      "id" : 14245811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/gaFLAUoABG",
      "expanded_url" : "http:\/\/arxiv.org\/pdf\/1607.05840.pdf",
      "display_url" : "arxiv.org\/pdf\/1607.05840\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "757866348550782976",
  "text" : "Awesome: \u00ABEvaluating the Strength of Genomic Privacy  Metrics\u00BB, using openSNP as ground truth data set! https:\/\/t.co\/gaFLAUoABG cc @wilbanks",
  "id" : 757866348550782976,
  "created_at" : "2016-07-26 09:13:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "laura clarke",
      "screen_name" : "laurastephen",
      "indices" : [ 0, 13 ],
      "id_str" : "20142273",
      "id" : 20142273
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "757865084223913984",
  "geo" : { },
  "id_str" : "757865263941488641",
  "in_reply_to_user_id" : 20142273,
  "text" : "@laurastephen I know, they can\u2019t differentiate whether it\u2019s writing a paper or filling mindless forms.",
  "id" : 757865263941488641,
  "in_reply_to_status_id" : 757865084223913984,
  "created_at" : "2016-07-26 09:08:54 +0000",
  "in_reply_to_screen_name" : "laurastephen",
  "in_reply_to_user_id_str" : "20142273",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/757861959081558019\/photo\/1",
      "indices" : [ 61, 84 ],
      "url" : "https:\/\/t.co\/G6TYqKGna4",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CoR3b4oXgAAQ-dB.jpg",
      "id_str" : "757861958246957056",
      "id" : 757861958246957056,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CoR3b4oXgAAQ-dB.jpg",
      "sizes" : [ {
        "h" : 335,
        "resize" : "fit",
        "w" : 317
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 335,
        "resize" : "fit",
        "w" : 317
      }, {
        "h" : 335,
        "resize" : "fit",
        "w" : 317
      }, {
        "h" : 335,
        "resize" : "fit",
        "w" : 317
      } ],
      "display_url" : "pic.twitter.com\/G6TYqKGna4"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "757857849804402693",
  "geo" : { },
  "id_str" : "757861959081558019",
  "in_reply_to_user_id" : 14286491,
  "text" : "At the same time RescueTime falsely thinks I was productive\u2026 https:\/\/t.co\/G6TYqKGna4",
  "id" : 757861959081558019,
  "in_reply_to_status_id" : 757857849804402693,
  "created_at" : "2016-07-26 08:55:46 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17247580608125, 8.627420760419497 ]
  },
  "id_str" : "757857849804402693",
  "text" : "Filing expense reports all morning, I can\u2019t think of any larger waste of time for all people involved.",
  "id" : 757857849804402693,
  "created_at" : "2016-07-26 08:39:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "757584187931131904",
  "text" : "Thought I could optimize my September travels by flying from\/to ZRH instead of FRA. But it just adds additional layovers at FRA. m)",
  "id" : 757584187931131904,
  "created_at" : "2016-07-25 14:32:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 51 ],
      "url" : "https:\/\/t.co\/9hbjmKWDKq",
      "expanded_url" : "https:\/\/twitter.com\/PhdGeek\/status\/757546511802793985",
      "display_url" : "twitter.com\/PhdGeek\/status\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "757556099696451584",
  "text" : "Yay, looking forward to it! https:\/\/t.co\/9hbjmKWDKq",
  "id" : 757556099696451584,
  "created_at" : "2016-07-25 12:40:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nyborg",
      "screen_name" : "ny_borg",
      "indices" : [ 0, 8 ],
      "id_str" : "570156398",
      "id" : 570156398
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "757550349817380864",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17268435557371, 8.627578352721205 ]
  },
  "id_str" : "757551339513741312",
  "in_reply_to_user_id" : 570156398,
  "text" : "@ny_borg guess who\u2019s been carrying a dead tooth around the globe!",
  "id" : 757551339513741312,
  "in_reply_to_status_id" : 757550349817380864,
  "created_at" : "2016-07-25 12:21:28 +0000",
  "in_reply_to_screen_name" : "ny_borg",
  "in_reply_to_user_id_str" : "570156398",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 19, 32 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "757549302726139904",
  "geo" : { },
  "id_str" : "757549840817463296",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot I could ask @PhilippBayer to do the press briefings otherwise!",
  "id" : 757549840817463296,
  "in_reply_to_status_id" : 757549302726139904,
  "created_at" : "2016-07-25 12:15:31 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 92 ],
      "url" : "https:\/\/t.co\/rac46G2G6e",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/757480964742320128",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "757480964742320128",
  "geo" : { },
  "id_str" : "757542318463414272",
  "in_reply_to_user_id" : 14286491,
  "text" : "Totally forgot to mention it this morning: Happy Birthday, Rosalind! https:\/\/t.co\/rac46G2G6e",
  "id" : 757542318463414272,
  "in_reply_to_status_id" : 757480964742320128,
  "created_at" : "2016-07-25 11:45:37 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marcel Salathe",
      "screen_name" : "marcelsalathe",
      "indices" : [ 0, 14 ],
      "id_str" : "14177696",
      "id" : 14177696
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "757530853044084736",
  "geo" : { },
  "id_str" : "757539808050814976",
  "in_reply_to_user_id" : 14177696,
  "text" : "@marcelsalathe looking forward to meet all of you again!",
  "id" : 757539808050814976,
  "in_reply_to_status_id" : 757530853044084736,
  "created_at" : "2016-07-25 11:35:39 +0000",
  "in_reply_to_screen_name" : "marcelsalathe",
  "in_reply_to_user_id_str" : "14177696",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Cock",
      "screen_name" : "pjacock",
      "indices" : [ 0, 8 ],
      "id_str" : "58756672",
      "id" : 58756672
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "757527142922063872",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.10185707448935, 8.69982972485391 ]
  },
  "id_str" : "757527338523516928",
  "in_reply_to_user_id" : 58756672,
  "text" : "@pjacock half-half as I was requested to keep me eyes closed after all. ;)",
  "id" : 757527338523516928,
  "in_reply_to_status_id" : 757527142922063872,
  "created_at" : "2016-07-25 10:46:06 +0000",
  "in_reply_to_screen_name" : "pjacock",
  "in_reply_to_user_id_str" : "58756672",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Cock",
      "screen_name" : "pjacock",
      "indices" : [ 0, 8 ],
      "id_str" : "58756672",
      "id" : 58756672
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "757526828395458560",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.10189729061992, 8.699822752809347 ]
  },
  "id_str" : "757527140770410496",
  "in_reply_to_user_id" : 58756672,
  "text" : "@pjacock thanks. The first appointment\u2019s done. Two more to go over the next week.",
  "id" : 757527140770410496,
  "in_reply_to_status_id" : 757526828395458560,
  "created_at" : "2016-07-25 10:45:19 +0000",
  "in_reply_to_screen_name" : "pjacock",
  "in_reply_to_user_id_str" : "58756672",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.10197334890174, 8.748674298416846 ]
  },
  "id_str" : "757524654273822720",
  "text" : "\u00ABPlease close your eyes while I inject the anesthetic.\u00BB \u2014 \u00ABFor medical reasons or for me not freaking out by the hypodermic needle\u2019s size?\u00BB",
  "id" : 757524654273822720,
  "created_at" : "2016-07-25 10:35:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/757509858258223104\/photo\/1",
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/eXZ1aWQSWE",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CoM3MVMWAAItOau.jpg",
      "id_str" : "757509847315251202",
      "id" : 757509847315251202,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CoM3MVMWAAItOau.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      } ],
      "display_url" : "pic.twitter.com\/eXZ1aWQSWE"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1045923371932, 8.764406694071658 ]
  },
  "id_str" : "757509858258223104",
  "text" : "What better way to celebrate coming back than having root canal surgery? https:\/\/t.co\/eXZ1aWQSWE",
  "id" : 757509858258223104,
  "created_at" : "2016-07-25 09:36:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sujai Kumar",
      "screen_name" : "sujaik",
      "indices" : [ 0, 7 ],
      "id_str" : "33651124",
      "id" : 33651124
    }, {
      "name" : "\uD83D\uDC9A Aure Moser \uD83D\uDC9A",
      "screen_name" : "auremoser",
      "indices" : [ 78, 88 ],
      "id_str" : "186529934",
      "id" : 186529934
    }, {
      "name" : "Joey  Lee",
      "screen_name" : "leejoeyk",
      "indices" : [ 89, 98 ],
      "id_str" : "575961466",
      "id" : 575961466
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mozfest",
      "indices" : [ 45, 53 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "757486212647092224",
  "geo" : { },
  "id_str" : "757486711693799424",
  "in_reply_to_user_id" : 33651124,
  "text" : "@sujaik yep, sounds like a fun idea to do at #mozfest, calling the map nerds! @auremoser @leejoeyk",
  "id" : 757486711693799424,
  "in_reply_to_status_id" : 757486212647092224,
  "created_at" : "2016-07-25 08:04:40 +0000",
  "in_reply_to_screen_name" : "sujaik",
  "in_reply_to_user_id_str" : "33651124",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sujai Kumar",
      "screen_name" : "sujaik",
      "indices" : [ 0, 7 ],
      "id_str" : "33651124",
      "id" : 33651124
    }, {
      "name" : "Micropia",
      "screen_name" : "Micropia",
      "indices" : [ 8, 17 ],
      "id_str" : "2482016394",
      "id" : 2482016394
    }, {
      "name" : "Nick Loman",
      "screen_name" : "pathogenomenick",
      "indices" : [ 18, 34 ],
      "id_str" : "85906238",
      "id" : 85906238
    }, {
      "name" : "Ed Yong",
      "screen_name" : "edyong209",
      "indices" : [ 35, 45 ],
      "id_str" : "19767193",
      "id" : 19767193
    }, {
      "name" : "Mozilla Science Lab",
      "screen_name" : "MozillaScience",
      "indices" : [ 86, 101 ],
      "id_str" : "1428575976",
      "id" : 1428575976
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mozfest",
      "indices" : [ 116, 124 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "757485068231344128",
  "geo" : { },
  "id_str" : "757485988423802880",
  "in_reply_to_user_id" : 33651124,
  "text" : "@sujaik @Micropia @pathogenomenick @edyong209 that might be a fun project to run as a @MozillaScience sprint during #mozfest!",
  "id" : 757485988423802880,
  "in_reply_to_status_id" : 757485068231344128,
  "created_at" : "2016-07-25 08:01:47 +0000",
  "in_reply_to_screen_name" : "sujaik",
  "in_reply_to_user_id_str" : "33651124",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sujai Kumar",
      "screen_name" : "sujaik",
      "indices" : [ 0, 7 ],
      "id_str" : "33651124",
      "id" : 33651124
    }, {
      "name" : "Micropia",
      "screen_name" : "Micropia",
      "indices" : [ 8, 17 ],
      "id_str" : "2482016394",
      "id" : 2482016394
    }, {
      "name" : "Nick Loman",
      "screen_name" : "pathogenomenick",
      "indices" : [ 18, 34 ],
      "id_str" : "85906238",
      "id" : 85906238
    }, {
      "name" : "Ed Yong",
      "screen_name" : "edyong209",
      "indices" : [ 35, 45 ],
      "id_str" : "19767193",
      "id" : 19767193
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "757483912134270976",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11385279415622, 8.753435380151139 ]
  },
  "id_str" : "757484603795996672",
  "in_reply_to_user_id" : 33651124,
  "text" : "@sujaik @Micropia @pathogenomenick @edyong209 what about an open repository of nerdy things to see around latitude\/longitude?",
  "id" : 757484603795996672,
  "in_reply_to_status_id" : 757483912134270976,
  "created_at" : "2016-07-25 07:56:17 +0000",
  "in_reply_to_screen_name" : "sujaik",
  "in_reply_to_user_id_str" : "33651124",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sujai Kumar",
      "screen_name" : "sujaik",
      "indices" : [ 0, 7 ],
      "id_str" : "33651124",
      "id" : 33651124
    }, {
      "name" : "Micropia",
      "screen_name" : "Micropia",
      "indices" : [ 8, 17 ],
      "id_str" : "2482016394",
      "id" : 2482016394
    }, {
      "name" : "Nick Loman",
      "screen_name" : "pathogenomenick",
      "indices" : [ 18, 34 ],
      "id_str" : "85906238",
      "id" : 85906238
    }, {
      "name" : "Ed Yong",
      "screen_name" : "edyong209",
      "indices" : [ 35, 45 ],
      "id_str" : "19767193",
      "id" : 19767193
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "757482282034798592",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11380920783461, 8.75345507953101 ]
  },
  "id_str" : "757483031410212864",
  "in_reply_to_user_id" : 33651124,
  "text" : "@sujaik @Micropia @pathogenomenick @edyong209 I don\u2019t think nerds at large are people who buy pre-planned tours.",
  "id" : 757483031410212864,
  "in_reply_to_status_id" : 757482282034798592,
  "created_at" : "2016-07-25 07:50:02 +0000",
  "in_reply_to_screen_name" : "sujaik",
  "in_reply_to_user_id_str" : "33651124",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sujai Kumar",
      "screen_name" : "sujaik",
      "indices" : [ 0, 7 ],
      "id_str" : "33651124",
      "id" : 33651124
    }, {
      "name" : "Nick Loman",
      "screen_name" : "pathogenomenick",
      "indices" : [ 8, 24 ],
      "id_str" : "85906238",
      "id" : 85906238
    }, {
      "name" : "Ed Yong",
      "screen_name" : "edyong209",
      "indices" : [ 25, 35 ],
      "id_str" : "19767193",
      "id" : 19767193
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/757480964742320128\/photo\/1",
      "indices" : [ 67, 90 ],
      "url" : "https:\/\/t.co\/lkW4gz5wFv",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CoMc2TyXgAAbADD.jpg",
      "id_str" : "757480881678417920",
      "id" : 757480881678417920,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CoMc2TyXgAAbADD.jpg",
      "sizes" : [ {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      } ],
      "display_url" : "pic.twitter.com\/lkW4gz5wFv"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "757478889610502144",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11405163914025, 8.753321328522649 ]
  },
  "id_str" : "757480964742320128",
  "in_reply_to_user_id" : 33651124,
  "text" : "@sujaik @pathogenomenick @edyong209 my vacation was visiting here. https:\/\/t.co\/lkW4gz5wFv",
  "id" : 757480964742320128,
  "in_reply_to_status_id" : 757478889610502144,
  "created_at" : "2016-07-25 07:41:49 +0000",
  "in_reply_to_screen_name" : "sujaik",
  "in_reply_to_user_id_str" : "33651124",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sujai Kumar",
      "screen_name" : "sujaik",
      "indices" : [ 0, 7 ],
      "id_str" : "33651124",
      "id" : 33651124
    }, {
      "name" : "Micropia",
      "screen_name" : "Micropia",
      "indices" : [ 8, 17 ],
      "id_str" : "2482016394",
      "id" : 2482016394
    }, {
      "name" : "Nick Loman",
      "screen_name" : "pathogenomenick",
      "indices" : [ 18, 34 ],
      "id_str" : "85906238",
      "id" : 85906238
    }, {
      "name" : "Ed Yong",
      "screen_name" : "edyong209",
      "indices" : [ 35, 45 ],
      "id_str" : "19767193",
      "id" : 19767193
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "757478889610502144",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11405151501478, 8.753322299099361 ]
  },
  "id_str" : "757479318956179456",
  "in_reply_to_user_id" : 33651124,
  "text" : "@sujaik @Micropia @pathogenomenick @edyong209 we should go on vacation together at some time :p",
  "id" : 757479318956179456,
  "in_reply_to_status_id" : 757478889610502144,
  "created_at" : "2016-07-25 07:35:17 +0000",
  "in_reply_to_screen_name" : "sujaik",
  "in_reply_to_user_id_str" : "33651124",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11398266499699, 8.75337009249562 ]
  },
  "id_str" : "757475771460050945",
  "text" : "When you\u2019ve been abroad for so long that you forgot the PIN for your domestic debit card.",
  "id" : 757475771460050945,
  "created_at" : "2016-07-25 07:21:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.4665584592628, -0.4428358096633505 ]
  },
  "id_str" : "757289520496861185",
  "text" : "Goodbye London. See you soon! LHR \u2708\uFE0F FRA.",
  "id" : 757289520496861185,
  "created_at" : "2016-07-24 19:01:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nazeefa",
      "screen_name" : "NazeefaFatima",
      "indices" : [ 0, 14 ],
      "id_str" : "37054704",
      "id" : 37054704
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "757283628552429568",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.47062749606694, -0.4442598111931647 ]
  },
  "id_str" : "757283768449269764",
  "in_reply_to_user_id" : 37054704,
  "text" : "@NazeefaFatima thanks! :-)",
  "id" : 757283768449269764,
  "in_reply_to_status_id" : 757283628552429568,
  "created_at" : "2016-07-24 18:38:14 +0000",
  "in_reply_to_screen_name" : "NazeefaFatima",
  "in_reply_to_user_id_str" : "37054704",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Denker",
      "screen_name" : "Phaidr0s",
      "indices" : [ 0, 9 ],
      "id_str" : "40466433",
      "id" : 40466433
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "757280601229627392",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.47053208484243, -0.4437850086727701 ]
  },
  "id_str" : "757282803918770176",
  "in_reply_to_user_id" : 40466433,
  "text" : "@Phaidr0s wieso denn ausgerechnet Berlin?",
  "id" : 757282803918770176,
  "in_reply_to_status_id" : 757280601229627392,
  "created_at" : "2016-07-24 18:34:24 +0000",
  "in_reply_to_screen_name" : "Phaidr0s",
  "in_reply_to_user_id_str" : "40466433",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nazeefa",
      "screen_name" : "NazeefaFatima",
      "indices" : [ 0, 14 ],
      "id_str" : "37054704",
      "id" : 37054704
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "757282138257514496",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.46832328382033, -0.4495627763916554 ]
  },
  "id_str" : "757282360681500672",
  "in_reply_to_user_id" : 37054704,
  "text" : "@NazeefaFatima personal preferences :)",
  "id" : 757282360681500672,
  "in_reply_to_status_id" : 757282138257514496,
  "created_at" : "2016-07-24 18:32:39 +0000",
  "in_reply_to_screen_name" : "NazeefaFatima",
  "in_reply_to_user_id_str" : "37054704",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.47169494628905, -0.4401702841880871 ]
  },
  "id_str" : "757280520032190464",
  "text" : "\u00ABSo the only places we\u2019ve ruled out for doing our post-docs are Berlin and Paris?\u00BB \u2014 \u00ABDon\u2019t forget Greece and North Korea!\u00BB",
  "id" : 757280520032190464,
  "created_at" : "2016-07-24 18:25:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.5390520446078, -0.0791847454463629 ]
  },
  "id_str" : "756974213420949504",
  "text" : "\u00ABDuring check-in they asked me for my flight reason. There was no \u2018if only I knew\u2019 option offered.\u00BB",
  "id" : 756974213420949504,
  "created_at" : "2016-07-23 22:08:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 32 ],
      "url" : "https:\/\/t.co\/Dqqh6XbNoD",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BINrcKkDYCH\/",
      "display_url" : "instagram.com\/p\/BINrcKkDYCH\/"
    } ]
  },
  "geo" : { },
  "id_str" : "756916066924785664",
  "text" : "Sharding https:\/\/t.co\/Dqqh6XbNoD",
  "id" : 756916066924785664,
  "created_at" : "2016-07-23 18:17:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 68 ],
      "url" : "https:\/\/t.co\/FGBnGxTo39",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BINZxx2DxlT\/",
      "display_url" : "instagram.com\/p\/BINZxx2DxlT\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.510173, -0.098438 ]
  },
  "id_str" : "756877229833986048",
  "text" : "Time for a break @ Millennium Bridge, London https:\/\/t.co\/FGBnGxTo39",
  "id" : 756877229833986048,
  "created_at" : "2016-07-23 15:42:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.53918598390609, -0.07940394829187783 ]
  },
  "id_str" : "756806434340372481",
  "text" : "\u00ABDo you know how many kilograms are in one stone?\u00BB \u2014 \u00ABHard to say, isn\u2019t that tied to how much the Queen can lift on a given day?\u00BB",
  "id" : 756806434340372481,
  "created_at" : "2016-07-23 11:01:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 76 ],
      "url" : "https:\/\/t.co\/wRFjdGhhG9",
      "expanded_url" : "https:\/\/twitter.com\/heyaudy\/status\/756605153864654848",
      "display_url" : "twitter.com\/heyaudy\/status\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.53908209164952, -0.07921030655840117 ]
  },
  "id_str" : "756798028078546944",
  "text" : "I do, especially for the plague infected platypuses. https:\/\/t.co\/wRFjdGhhG9",
  "id" : 756798028078546944,
  "created_at" : "2016-07-23 10:28:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elio Qoshi",
      "screen_name" : "elioqoshi",
      "indices" : [ 0, 10 ],
      "id_str" : "93434375",
      "id" : 93434375
    }, {
      "name" : "ura old",
      "screen_name" : "uraworks",
      "indices" : [ 96, 105 ],
      "id_str" : "756103023278092288",
      "id" : 756103023278092288
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "756515151281553408",
  "geo" : { },
  "id_str" : "756515529846824960",
  "in_reply_to_user_id" : 93434375,
  "text" : "@elioqoshi Already distributed them over 3 continents by now. Each time w\/ a shout-out to you \/ @uraworks. Hope it has some effect!",
  "id" : 756515529846824960,
  "in_reply_to_status_id" : 756515151281553408,
  "created_at" : "2016-07-22 15:45:32 +0000",
  "in_reply_to_screen_name" : "elioqoshi",
  "in_reply_to_user_id_str" : "93434375",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elio Qoshi",
      "screen_name" : "elioqoshi",
      "indices" : [ 87, 97 ],
      "id_str" : "93434375",
      "id" : 93434375
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "756514975938650114",
  "text" : "Just reordered a larger number of openSNP stickers as the first batch is already gone. @elioqoshi your design is getting lots of love!",
  "id" : 756514975938650114,
  "created_at" : "2016-07-22 15:43:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/cM7Xbhm0kg",
      "expanded_url" : "https:\/\/media.giphy.com\/media\/KR9OgQyWAwIIE\/giphy.gif",
      "display_url" : "media.giphy.com\/media\/KR9OgQyW\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "756511685645570049",
  "text" : "When you used your week of workcation to draft good parts of a paper. https:\/\/t.co\/cM7Xbhm0kg",
  "id" : 756511685645570049,
  "created_at" : "2016-07-22 15:30:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul-Olivier Dehaye",
      "screen_name" : "podehaye",
      "indices" : [ 0, 9 ],
      "id_str" : "2219841242",
      "id" : 2219841242
    }, {
      "name" : "Anne Wojcicki",
      "screen_name" : "annewoj23",
      "indices" : [ 10, 20 ],
      "id_str" : "460593762",
      "id" : 460593762
    }, {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 21, 30 ],
      "id_str" : "14245811",
      "id" : 14245811
    }, {
      "name" : "Eric Topol",
      "screen_name" : "EricTopol",
      "indices" : [ 31, 41 ],
      "id_str" : "86626845",
      "id" : 86626845
    }, {
      "name" : "nature",
      "screen_name" : "nature",
      "indices" : [ 42, 49 ],
      "id_str" : "487833518",
      "id" : 487833518
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "756482168097038337",
  "geo" : { },
  "id_str" : "756482647665369089",
  "in_reply_to_user_id" : 2219841242,
  "text" : "@podehaye @annewoj23 @wilbanks @EricTopol @nature awesome, will be in touch!",
  "id" : 756482647665369089,
  "in_reply_to_status_id" : 756482168097038337,
  "created_at" : "2016-07-22 13:34:52 +0000",
  "in_reply_to_screen_name" : "podehaye",
  "in_reply_to_user_id_str" : "2219841242",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul-Olivier Dehaye",
      "screen_name" : "podehaye",
      "indices" : [ 0, 9 ],
      "id_str" : "2219841242",
      "id" : 2219841242
    }, {
      "name" : "Anne Wojcicki",
      "screen_name" : "annewoj23",
      "indices" : [ 10, 20 ],
      "id_str" : "460593762",
      "id" : 460593762
    }, {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 21, 30 ],
      "id_str" : "14245811",
      "id" : 14245811
    }, {
      "name" : "Eric Topol",
      "screen_name" : "EricTopol",
      "indices" : [ 31, 41 ],
      "id_str" : "86626845",
      "id" : 86626845
    }, {
      "name" : "nature",
      "screen_name" : "nature",
      "indices" : [ 42, 49 ],
      "id_str" : "487833518",
      "id" : 487833518
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "756480891271127040",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.49996962784157, -0.07834013294151981 ]
  },
  "id_str" : "756481276056657920",
  "in_reply_to_user_id" : 2219841242,
  "text" : "@podehaye @annewoj23 @wilbanks @EricTopol @nature will do, but that\u2019s not the easy way of getting access for everyone that\u2019s meant here :(",
  "id" : 756481276056657920,
  "in_reply_to_status_id" : 756480891271127040,
  "created_at" : "2016-07-22 13:29:25 +0000",
  "in_reply_to_screen_name" : "podehaye",
  "in_reply_to_user_id_str" : "2219841242",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u00C9l\u00E9onore Mayola",
      "screen_name" : "EleonoreMayola",
      "indices" : [ 0, 15 ],
      "id_str" : "502916683",
      "id" : 502916683
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "756237973172154368",
  "geo" : { },
  "id_str" : "756475191040106496",
  "in_reply_to_user_id" : 502916683,
  "text" : "@EleonoreMayola those are awesome!",
  "id" : 756475191040106496,
  "in_reply_to_status_id" : 756237973172154368,
  "created_at" : "2016-07-22 13:05:14 +0000",
  "in_reply_to_screen_name" : "EleonoreMayola",
  "in_reply_to_user_id_str" : "502916683",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/wDLzKkJ5Fb",
      "expanded_url" : "https:\/\/twitter.com\/wtvox\/status\/756456558779740160",
      "display_url" : "twitter.com\/wtvox\/status\/7\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "756471452514283521",
  "text" : "If only I had known before coming over, then I would have made my nails! https:\/\/t.co\/wDLzKkJ5Fb",
  "id" : 756471452514283521,
  "created_at" : "2016-07-22 12:50:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniela",
      "screen_name" : "DanielaGunz",
      "indices" : [ 0, 12 ],
      "id_str" : "3062395330",
      "id" : 3062395330
    }, {
      "name" : "healthbank",
      "screen_name" : "healthbankcoop",
      "indices" : [ 13, 28 ],
      "id_str" : "1075273202",
      "id" : 1075273202
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "756456788556382208",
  "geo" : { },
  "id_str" : "756465217035460608",
  "in_reply_to_user_id" : 3062395330,
  "text" : "@DanielaGunz @healthbankcoop thanks for the pointer!",
  "id" : 756465217035460608,
  "in_reply_to_status_id" : 756456788556382208,
  "created_at" : "2016-07-22 12:25:36 +0000",
  "in_reply_to_screen_name" : "DanielaGunz",
  "in_reply_to_user_id_str" : "3062395330",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mick Watson",
      "screen_name" : "BioMickWatson",
      "indices" : [ 0, 14 ],
      "id_str" : "228586748",
      "id" : 228586748
    }, {
      "name" : "Kai Blin",
      "screen_name" : "kaiblin",
      "indices" : [ 15, 23 ],
      "id_str" : "124202458",
      "id" : 124202458
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "756410491346575360",
  "geo" : { },
  "id_str" : "756410970449317888",
  "in_reply_to_user_id" : 228586748,
  "text" : "@BioMickWatson @kaiblin isn\u2019t all of colorspace one huge edge case?",
  "id" : 756410970449317888,
  "in_reply_to_status_id" : 756410491346575360,
  "created_at" : "2016-07-22 08:50:03 +0000",
  "in_reply_to_screen_name" : "BioMickWatson",
  "in_reply_to_user_id_str" : "228586748",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/LxcUqpgAuH",
      "expanded_url" : "https:\/\/twitter.com\/annewoj23\/status\/756190838250614784",
      "display_url" : "twitter.com\/annewoj23\/stat\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.49876643999998, -0.08128660999999997 ]
  },
  "id_str" : "756405592634294272",
  "text" : "So when can I export all of my phenotype questionnaire answers from 23andMe? https:\/\/t.co\/LxcUqpgAuH",
  "id" : 756405592634294272,
  "created_at" : "2016-07-22 08:28:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/756403305157386240\/photo\/1",
      "indices" : [ 41, 64 ],
      "url" : "https:\/\/t.co\/DYeBelLsTq",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cn9IyaDXYAE_sJ5.jpg",
      "id_str" : "756403293245628417",
      "id" : 756403293245628417,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cn9IyaDXYAE_sJ5.jpg",
      "sizes" : [ {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/DYeBelLsTq"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.49876643999998, -0.08128660999999995 ]
  },
  "id_str" : "756403305157386240",
  "text" : "There are some good reasons to level up. https:\/\/t.co\/DYeBelLsTq",
  "id" : 756403305157386240,
  "created_at" : "2016-07-22 08:19:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/756400408411725824\/photo\/1",
      "indices" : [ 36, 59 ],
      "url" : "https:\/\/t.co\/2k1axYWf7G",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cn9GKGGWEAAtAfU.jpg",
      "id_str" : "756400401671393280",
      "id" : 756400401671393280,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cn9GKGGWEAAtAfU.jpg",
      "sizes" : [ {
        "h" : 1445,
        "resize" : "fit",
        "w" : 1084
      }, {
        "h" : 1445,
        "resize" : "fit",
        "w" : 1084
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      } ],
      "display_url" : "pic.twitter.com\/2k1axYWf7G"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.498766, -0.081287 ]
  },
  "id_str" : "756400408411725824",
  "text" : "Dog friendly breastfeeding welcome. https:\/\/t.co\/2k1axYWf7G",
  "id" : 756400408411725824,
  "created_at" : "2016-07-22 08:08:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/756398597046988800\/photo\/1",
      "indices" : [ 33, 56 ],
      "url" : "https:\/\/t.co\/616NHt1jVQ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cn9Ef31XYAEkHoo.jpg",
      "id_str" : "756398576775946241",
      "id" : 756398576775946241,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cn9Ef31XYAEkHoo.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      } ],
      "display_url" : "pic.twitter.com\/616NHt1jVQ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.50008774832962, -0.08111192844815655 ]
  },
  "id_str" : "756398597046988800",
  "text" : "Some old fashioned bike sharing. https:\/\/t.co\/616NHt1jVQ",
  "id" : 756398597046988800,
  "created_at" : "2016-07-22 08:00:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 74 ],
      "url" : "https:\/\/t.co\/JRBwOqBn7h",
      "expanded_url" : "http:\/\/www.atlasobscura.com\/articles\/sydney-could-become-the-first-city-in-australia-to-give-women-free-tampons",
      "display_url" : "atlasobscura.com\/articles\/sydne\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.5179, -0.080264 ]
  },
  "id_str" : "756392042767478784",
  "text" : "Tampons Could Soon Be Free For All Women in Sydney https:\/\/t.co\/JRBwOqBn7h",
  "id" : 756392042767478784,
  "created_at" : "2016-07-22 07:34:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.53945398521753, -0.07929674349732631 ]
  },
  "id_str" : "756255088218439681",
  "text" : "\u00ABI told them I\u2019d have to leave the party to meet you, as you\u2019d be sadly roaming London all alone. Then I went back to my data analysis.\u00BB \uD83D\uDE0D",
  "id" : 756255088218439681,
  "created_at" : "2016-07-21 22:30:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alice Sheppard",
      "screen_name" : "PenguinGalaxy",
      "indices" : [ 0, 14 ],
      "id_str" : "20635230",
      "id" : 20635230
    }, {
      "name" : "Kevin Schawinski",
      "screen_name" : "kevinschawinski",
      "indices" : [ 15, 31 ],
      "id_str" : "242844365",
      "id" : 242844365
    }, {
      "name" : "Alice Sheppard",
      "screen_name" : "PenguinGalaxy",
      "indices" : [ 45, 59 ],
      "id_str" : "20635230",
      "id" : 20635230
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "756240977711562756",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.53480529726696, -0.0759429937303817 ]
  },
  "id_str" : "756241327705165825",
  "in_reply_to_user_id" : 20635230,
  "text" : "@PenguinGalaxy @kevinschawinski right, bring @PenguinGalaxy to Zurich again soon!",
  "id" : 756241327705165825,
  "in_reply_to_status_id" : 756240977711562756,
  "created_at" : "2016-07-21 21:35:57 +0000",
  "in_reply_to_screen_name" : "PenguinGalaxy",
  "in_reply_to_user_id_str" : "20635230",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alice Sheppard",
      "screen_name" : "PenguinGalaxy",
      "indices" : [ 0, 14 ],
      "id_str" : "20635230",
      "id" : 20635230
    }, {
      "name" : "Egle Ramanauskaite \u2623",
      "screen_name" : "Seplute",
      "indices" : [ 15, 23 ],
      "id_str" : "188833865",
      "id" : 188833865
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "756238122963329024",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.53480528843203, -0.0759430022892234 ]
  },
  "id_str" : "756241256741830656",
  "in_reply_to_user_id" : 20635230,
  "text" : "@PenguinGalaxy @Seplute no, not at all; no worries!",
  "id" : 756241256741830656,
  "in_reply_to_status_id" : 756238122963329024,
  "created_at" : "2016-07-21 21:35:40 +0000",
  "in_reply_to_screen_name" : "PenguinGalaxy",
  "in_reply_to_user_id_str" : "20635230",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alice Sheppard",
      "screen_name" : "PenguinGalaxy",
      "indices" : [ 16, 30 ],
      "id_str" : "20635230",
      "id" : 20635230
    }, {
      "name" : "Egle Ramanauskaite \u2623",
      "screen_name" : "Seplute",
      "indices" : [ 95, 103 ],
      "id_str" : "188833865",
      "id" : 188833865
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.53480529774222, -0.07594299339081716 ]
  },
  "id_str" : "756227638167867393",
  "text" : "Awesome to meet @PenguinGalaxy after such a long time to talk citizen science. You were missed @Seplute!",
  "id" : 756227638167867393,
  "created_at" : "2016-07-21 20:41:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dennis Schwartz",
      "screen_name" : "dschwartz_pf",
      "indices" : [ 0, 13 ],
      "id_str" : "3824125822",
      "id" : 3824125822
    }, {
      "name" : "Fiona Nielsen",
      "screen_name" : "glyn_dk",
      "indices" : [ 14, 22 ],
      "id_str" : "32340834",
      "id" : 32340834
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "756136010724085764",
  "geo" : { },
  "id_str" : "756136183097397248",
  "in_reply_to_user_id" : 3824125822,
  "text" : "@dschwartz_pf @glyn_dk sure, where\u2019s your event located? could head up earlier to UCL if that helps.",
  "id" : 756136183097397248,
  "in_reply_to_status_id" : 756136010724085764,
  "created_at" : "2016-07-21 14:38:09 +0000",
  "in_reply_to_screen_name" : "dschwartz_pf",
  "in_reply_to_user_id_str" : "3824125822",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Quinnsplainer ' ; DROP TABLE altright_users",
      "screen_name" : "quinnnorton",
      "indices" : [ 3, 15 ],
      "id_str" : "38975663",
      "id" : 38975663
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "756112188167839744",
  "text" : "RT @quinnnorton: Most research is forbidden in most of the world because only a few researchers have access to resources. https:\/\/t.co\/XYK3\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 105, 128 ],
        "url" : "https:\/\/t.co\/XYK30xivPi",
        "expanded_url" : "https:\/\/twitter.com\/datasociety\/status\/756111613283930112",
        "display_url" : "twitter.com\/datasociety\/st\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "756112114721390592",
    "text" : "Most research is forbidden in most of the world because only a few researchers have access to resources. https:\/\/t.co\/XYK30xivPi",
    "id" : 756112114721390592,
    "created_at" : "2016-07-21 13:02:30 +0000",
    "user" : {
      "name" : "Quinnsplainer ' ; DROP TABLE altright_users",
      "screen_name" : "quinnnorton",
      "protected" : false,
      "id_str" : "38975663",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/925809688989523968\/1LolWEWQ_normal.jpg",
      "id" : 38975663,
      "verified" : false
    }
  },
  "id" : 756112188167839744,
  "created_at" : "2016-07-21 13:02:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GigaScience",
      "screen_name" : "GigaScience",
      "indices" : [ 3, 15 ],
      "id_str" : "208988759",
      "id" : 208988759
    }, {
      "name" : "openSNP team",
      "screen_name" : "openSNPorg",
      "indices" : [ 18, 29 ],
      "id_str" : "380205172",
      "id" : 380205172
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "756071510075408384",
  "text" : "RT @GigaScience: .@openSNPorg moved to receive crowdfunding &amp; external funding. Support their great work via Patreon https:\/\/t.co\/kLy7DXywR\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "openSNP team",
        "screen_name" : "openSNPorg",
        "indices" : [ 1, 12 ],
        "id_str" : "380205172",
        "id" : 380205172
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BOSC2016",
        "indices" : [ 128, 137 ]
      } ],
      "urls" : [ {
        "indices" : [ 104, 127 ],
        "url" : "https:\/\/t.co\/kLy7DXywRl",
        "expanded_url" : "https:\/\/www.patreon.com\/openSNP",
        "display_url" : "patreon.com\/openSNP"
      } ]
    },
    "in_reply_to_status_id_str" : "751850262864723968",
    "geo" : { },
    "id_str" : "751850872645320706",
    "in_reply_to_user_id" : 208988759,
    "text" : ".@openSNPorg moved to receive crowdfunding &amp; external funding. Support their great work via Patreon https:\/\/t.co\/kLy7DXywRl #BOSC2016",
    "id" : 751850872645320706,
    "in_reply_to_status_id" : 751850262864723968,
    "created_at" : "2016-07-09 18:49:51 +0000",
    "in_reply_to_screen_name" : "GigaScience",
    "in_reply_to_user_id_str" : "208988759",
    "user" : {
      "name" : "GigaScience",
      "screen_name" : "GigaScience",
      "protected" : false,
      "id_str" : "208988759",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1404305552\/profile-photo-GigaScience-96x96_normal.jpg",
      "id" : 208988759,
      "verified" : false
    }
  },
  "id" : 756071510075408384,
  "created_at" : "2016-07-21 10:21:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    }, {
      "name" : "Kai Denker",
      "screen_name" : "Phaidr0s",
      "indices" : [ 7, 16 ],
      "id_str" : "40466433",
      "id" : 40466433
    }, {
      "name" : "Manuel W\u00FCst",
      "screen_name" : "ManuelWuest",
      "indices" : [ 17, 29 ],
      "id_str" : "88493882",
      "id" : 88493882
    }, {
      "name" : "Sebastian Greiner",
      "screen_name" : "Seb666",
      "indices" : [ 30, 37 ],
      "id_str" : "2365333778",
      "id" : 2365333778
    }, {
      "name" : "Stephan Urbach",
      "screen_name" : "herrurbach",
      "indices" : [ 80, 91 ],
      "id_str" : "28090494",
      "id" : 28090494
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "756060783520382976",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.50227674391898, -0.08238545682798272 ]
  },
  "id_str" : "756062365523775488",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot @Phaidr0s @ManuelWuest @Seb666 das rechte K\u00E4nguru sieht ein bisschen wie @herrurbach aus? \uD83E\uDD14",
  "id" : 756062365523775488,
  "in_reply_to_status_id" : 756060783520382976,
  "created_at" : "2016-07-21 09:44:49 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sebastian Greiner",
      "screen_name" : "Seb666",
      "indices" : [ 0, 7 ],
      "id_str" : "2365333778",
      "id" : 2365333778
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 8, 14 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "756042334870134784",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.53093164325834, -0.1203819829971719 ]
  },
  "id_str" : "756055501260070913",
  "in_reply_to_user_id" : 2365333778,
  "text" : "@Seb666 @Lobot willst du in meinen Beutel?",
  "id" : 756055501260070913,
  "in_reply_to_status_id" : 756042334870134784,
  "created_at" : "2016-07-21 09:17:32 +0000",
  "in_reply_to_screen_name" : "Seb666",
  "in_reply_to_user_id_str" : "2365333778",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.53930152173452, -0.07937221610642395 ]
  },
  "id_str" : "755884400894701568",
  "text" : "\u00ABI thought the jokes you can make about it are the only things that are reproducible about neuroscience?\u00BB",
  "id" : 755884400894701568,
  "created_at" : "2016-07-20 21:57:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 3, 11 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 85 ],
      "url" : "https:\/\/t.co\/HOdn4k00zA",
      "expanded_url" : "http:\/\/www.bbc.co.uk\/news\/science-environment-36835566",
      "display_url" : "bbc.co.uk\/news\/science-e\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "755775836293328896",
  "text" : "RT @o_guest: BBC News - UK scientists speak about Brexit pain https:\/\/t.co\/HOdn4k00zA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 49, 72 ],
        "url" : "https:\/\/t.co\/HOdn4k00zA",
        "expanded_url" : "http:\/\/www.bbc.co.uk\/news\/science-environment-36835566",
        "display_url" : "bbc.co.uk\/news\/science-e\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "755710715168776192",
    "text" : "BBC News - UK scientists speak about Brexit pain https:\/\/t.co\/HOdn4k00zA",
    "id" : 755710715168776192,
    "created_at" : "2016-07-20 10:27:29 +0000",
    "user" : {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "protected" : false,
      "id_str" : "3865005196",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/844972791732584453\/mdSj6vOd_normal.jpg",
      "id" : 3865005196,
      "verified" : false
    }
  },
  "id" : 755775836293328896,
  "created_at" : "2016-07-20 14:46:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dennis Schwartz",
      "screen_name" : "dschwartz_pf",
      "indices" : [ 0, 13 ],
      "id_str" : "3824125822",
      "id" : 3824125822
    }, {
      "name" : "Fiona Nielsen",
      "screen_name" : "glyn_dk",
      "indices" : [ 14, 22 ],
      "id_str" : "32340834",
      "id" : 32340834
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "755748902050168832",
  "geo" : { },
  "id_str" : "755761111258062849",
  "in_reply_to_user_id" : 3824125822,
  "text" : "@dschwartz_pf @glyn_dk having a meeting at UCL at 5pm, probably near Tower Bridge on the south bank before that.",
  "id" : 755761111258062849,
  "in_reply_to_status_id" : 755748902050168832,
  "created_at" : "2016-07-20 13:47:44 +0000",
  "in_reply_to_screen_name" : "dschwartz_pf",
  "in_reply_to_user_id_str" : "3824125822",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.54604957909467, -0.2409508824350694 ]
  },
  "id_str" : "755730290962788352",
  "text" : "Nice to see it\u2019s not only me. Other people visit Rosalind Franklin and leave their pebbles as well.",
  "id" : 755730290962788352,
  "created_at" : "2016-07-20 11:45:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 79 ],
      "url" : "https:\/\/t.co\/DZgfUoDZI8",
      "expanded_url" : "http:\/\/existentialcomics.com\/comic\/142",
      "display_url" : "existentialcomics.com\/comic\/142"
    } ]
  },
  "geo" : { },
  "id_str" : "755700597505089536",
  "text" : "Zeno &amp; Zeno. This could make for an awesome sitcom. https:\/\/t.co\/DZgfUoDZI8",
  "id" : 755700597505089536,
  "created_at" : "2016-07-20 09:47:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/5gkxn6EKWe",
      "expanded_url" : "https:\/\/medium.com\/the-archipelago\/the-queer-case-of-luke-odonovan-4be5bbcbb198#.64j3owd8i",
      "display_url" : "medium.com\/the-archipelag\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "755686164611366912",
  "text" : "\u00ABEntire communities have had to enact their trauma through self-defending violence for people to pay attention.\u00BB https:\/\/t.co\/5gkxn6EKWe",
  "id" : 755686164611366912,
  "created_at" : "2016-07-20 08:49:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.53909492574758, -0.07927662986089172 ]
  },
  "id_str" : "755555195283730433",
  "text" : "\u00ABSo which names do the cats that you haven\u2019t imagined we would own not have?\u00BB",
  "id" : 755555195283730433,
  "created_at" : "2016-07-20 00:09:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fiona Nielsen",
      "screen_name" : "glyn_dk",
      "indices" : [ 0, 8 ],
      "id_str" : "32340834",
      "id" : 32340834
    }, {
      "name" : "Dennis Schwartz",
      "screen_name" : "dschwartz_pf",
      "indices" : [ 9, 22 ],
      "id_str" : "3824125822",
      "id" : 3824125822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "755522787368898560",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.53908048456256, -0.07928502462789222 ]
  },
  "id_str" : "755523365847330816",
  "in_reply_to_user_id" : 32340834,
  "text" : "@glyn_dk @dschwartz_pf great, happy to meet at some point if it fits in.",
  "id" : 755523365847330816,
  "in_reply_to_status_id" : 755522787368898560,
  "created_at" : "2016-07-19 22:03:02 +0000",
  "in_reply_to_screen_name" : "glyn_dk",
  "in_reply_to_user_id_str" : "32340834",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.51879846123188, -0.1292906887830508 ]
  },
  "id_str" : "755417948265783297",
  "text" : "Always carrying chopsticks and a sporf is one of the best travel ideas: Enables noodles and ice cream wherever you go. \uD83C\uDF5C\uD83C\uDF67",
  "id" : 755417948265783297,
  "created_at" : "2016-07-19 15:04:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony Ross-Hellauer",
      "screen_name" : "tonyR_H",
      "indices" : [ 3, 11 ],
      "id_str" : "44890780",
      "id" : 44890780
    }, {
      "name" : "F1000Research",
      "screen_name" : "F1000Research",
      "indices" : [ 14, 28 ],
      "id_str" : "59126394",
      "id" : 59126394
    }, {
      "name" : "OpenAIRE",
      "screen_name" : "OpenAIRE_eu",
      "indices" : [ 99, 111 ],
      "id_str" : "104462518",
      "id" : 104462518
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "openaccess",
      "indices" : [ 117, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "755414145135173632",
  "text" : "RT @tonyR_H: .@F1000Research admits \"objective author criteria\u201D \u201Cdisadvantage young researchers\u201D - @OpenAIRE_eu blog #openaccess https:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "F1000Research",
        "screen_name" : "F1000Research",
        "indices" : [ 1, 15 ],
        "id_str" : "59126394",
        "id" : 59126394
      }, {
        "name" : "OpenAIRE",
        "screen_name" : "OpenAIRE_eu",
        "indices" : [ 86, 98 ],
        "id_str" : "104462518",
        "id" : 104462518
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "openaccess",
        "indices" : [ 104, 115 ]
      } ],
      "urls" : [ {
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/o11pAfieiy",
        "expanded_url" : "https:\/\/blogs.openaire.eu\/?p=1122",
        "display_url" : "blogs.openaire.eu\/?p=1122"
      } ]
    },
    "geo" : { },
    "id_str" : "755346551439056896",
    "text" : ".@F1000Research admits \"objective author criteria\u201D \u201Cdisadvantage young researchers\u201D - @OpenAIRE_eu blog #openaccess https:\/\/t.co\/o11pAfieiy",
    "id" : 755346551439056896,
    "created_at" : "2016-07-19 10:20:26 +0000",
    "user" : {
      "name" : "Tony Ross-Hellauer",
      "screen_name" : "tonyR_H",
      "protected" : false,
      "id_str" : "44890780",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/908588506917883904\/pJgVpC15_normal.jpg",
      "id" : 44890780,
      "verified" : false
    }
  },
  "id" : 755414145135173632,
  "created_at" : "2016-07-19 14:49:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "755367804963065858",
  "text" : "Think you can\u2019t procrastinate if you have no home to clean? Guess who spent 45 minutes on reorganizing his Gmail labels\/folders!",
  "id" : 755367804963065858,
  "created_at" : "2016-07-19 11:44:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "755350656031006720",
  "text" : "Approaching 30 \u00B0C. The best time to listen to \u201ERain in England\u201C through some background noise app in order to drown out the cafe\u2019s music.",
  "id" : 755350656031006720,
  "created_at" : "2016-07-19 10:36:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alice Sheppard",
      "screen_name" : "PenguinGalaxy",
      "indices" : [ 0, 14 ],
      "id_str" : "20635230",
      "id" : 20635230
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "755330759263682561",
  "geo" : { },
  "id_str" : "755333893419626496",
  "in_reply_to_user_id" : 20635230,
  "text" : "@PenguinGalaxy very nice! Let\u2019s say Thur then?",
  "id" : 755333893419626496,
  "in_reply_to_status_id" : 755330759263682561,
  "created_at" : "2016-07-19 09:30:08 +0000",
  "in_reply_to_screen_name" : "PenguinGalaxy",
  "in_reply_to_user_id_str" : "20635230",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BOSC2016",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/kaXd8jHdhB",
      "expanded_url" : "https:\/\/twitter.com\/OBF_BOSC\/status\/755076650619002880",
      "display_url" : "twitter.com\/OBF_BOSC\/statu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "755333091745497088",
  "text" : "My talk about the state of openSNP at #BOSC2016. Only the video contains the high quality GIF selection! https:\/\/t.co\/kaXd8jHdhB",
  "id" : 755333091745497088,
  "created_at" : "2016-07-19 09:26:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alice Sheppard",
      "screen_name" : "PenguinGalaxy",
      "indices" : [ 0, 14 ],
      "id_str" : "20635230",
      "id" : 20635230
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "755327271976726529",
  "geo" : { },
  "id_str" : "755327383457132544",
  "in_reply_to_user_id" : 20635230,
  "text" : "@PenguinGalaxy sure, that would work! Where are you based work-wise now? :)",
  "id" : 755327383457132544,
  "in_reply_to_status_id" : 755327271976726529,
  "created_at" : "2016-07-19 09:04:16 +0000",
  "in_reply_to_screen_name" : "PenguinGalaxy",
  "in_reply_to_user_id_str" : "20635230",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "755312299544571904",
  "text" : "\u00ABI\u2019ll miss you from 9 to 5.\u00BB \u2013 \u00ABThat sounds like a job paid even worse than Academia.\u00BB",
  "id" : 755312299544571904,
  "created_at" : "2016-07-19 08:04:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alice Sheppard",
      "screen_name" : "PenguinGalaxy",
      "indices" : [ 0, 14 ],
      "id_str" : "20635230",
      "id" : 20635230
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "755173003781169153",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.5391766699511, -0.07926371879883042 ]
  },
  "id_str" : "755189489807552516",
  "in_reply_to_user_id" : 20635230,
  "text" : "@PenguinGalaxy btw: i'll be in town all week. Wanna grab some food some time?",
  "id" : 755189489807552516,
  "in_reply_to_status_id" : 755173003781169153,
  "created_at" : "2016-07-18 23:56:19 +0000",
  "in_reply_to_screen_name" : "PenguinGalaxy",
  "in_reply_to_user_id_str" : "20635230",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "755044007009320960",
  "geo" : { },
  "id_str" : "755044552357142528",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer approaches the point where you could just pay an army of PhD students to do Sanger sequencing ;)",
  "id" : 755044552357142528,
  "in_reply_to_status_id" : 755044007009320960,
  "created_at" : "2016-07-18 14:20:23 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 37 ],
      "url" : "https:\/\/t.co\/MQgRyOyJrz",
      "expanded_url" : "https:\/\/media0.giphy.com\/media\/la6Ne7z15BXs4\/200.gif",
      "display_url" : "media0.giphy.com\/media\/la6Ne7z1\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "755033117291712512",
  "geo" : { },
  "id_str" : "755042771812179968",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer https:\/\/t.co\/MQgRyOyJrz",
  "id" : 755042771812179968,
  "in_reply_to_status_id" : 755033117291712512,
  "created_at" : "2016-07-18 14:13:19 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "755041931441438720",
  "text" : "Apparently \u201Elaughing until tears roll down your face\u201C isn\u2019t the expected answer to \u201EHave you considered moving to the UK?\u201C.",
  "id" : 755041931441438720,
  "created_at" : "2016-07-18 14:09:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "latergram",
      "indices" : [ 42, 52 ]
    } ],
    "urls" : [ {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/SC8hElegNy",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BIARiw2jw8y\/",
      "display_url" : "instagram.com\/p\/BIARiw2jw8y\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.5438, -0.080577 ]
  },
  "id_str" : "755029531849846785",
  "text" : "Someone wants her share of the breakfast. #latergram @ De Beauvoir Town https:\/\/t.co\/SC8hElegNy",
  "id" : 755029531849846785,
  "created_at" : "2016-07-18 13:20:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Science Museum",
      "screen_name" : "sciencemuseum",
      "indices" : [ 0, 14 ],
      "id_str" : "15987295",
      "id" : 15987295
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "755007100397326336",
  "geo" : { },
  "id_str" : "755007318442516480",
  "in_reply_to_user_id" : 15987295,
  "text" : "@sciencemuseum I agree that it\u2019s complex to summarize given the space limitation. Happy to chat with the team if they wish.",
  "id" : 755007318442516480,
  "in_reply_to_status_id" : 755007100397326336,
  "created_at" : "2016-07-18 11:52:26 +0000",
  "in_reply_to_screen_name" : "sciencemuseum",
  "in_reply_to_user_id_str" : "15987295",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 47 ],
      "url" : "https:\/\/t.co\/vFVYrMhjXB",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BIAHCeODHLj\/",
      "display_url" : "instagram.com\/p\/BIAHCeODHLj\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.4991366, -0.0809941 ]
  },
  "id_str" : "755006432572047360",
  "text" : "double-dare @ Fuckoffee https:\/\/t.co\/vFVYrMhjXB",
  "id" : 755006432572047360,
  "created_at" : "2016-07-18 11:48:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Science Museum",
      "screen_name" : "sciencemuseum",
      "indices" : [ 0, 14 ],
      "id_str" : "15987295",
      "id" : 15987295
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 87 ],
      "url" : "https:\/\/t.co\/AaYswcniiz",
      "expanded_url" : "https:\/\/www.theguardian.com\/science\/2015\/jun\/23\/sexism-in-science-did-watson-and-crick-really-steal-rosalind-franklins-data",
      "display_url" : "theguardian.com\/science\/2015\/j\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "754984265348026368",
  "geo" : { },
  "id_str" : "755004669995384834",
  "in_reply_to_user_id" : 15987295,
  "text" : "@sciencemuseum \u2026dishonestly at least would do her justice. c.f. https:\/\/t.co\/AaYswcniiz",
  "id" : 755004669995384834,
  "in_reply_to_status_id" : 754984265348026368,
  "created_at" : "2016-07-18 11:41:55 +0000",
  "in_reply_to_screen_name" : "sciencemuseum",
  "in_reply_to_user_id_str" : "15987295",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Science Museum",
      "screen_name" : "sciencemuseum",
      "indices" : [ 0, 14 ],
      "id_str" : "15987295",
      "id" : 15987295
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "754984265348026368",
  "geo" : { },
  "id_str" : "755004611816263680",
  "in_reply_to_user_id" : 15987295,
  "text" : "@sciencemuseum thanks for getting in touch. Some mention of how her contribution was played down and how her data was acquired\u2026",
  "id" : 755004611816263680,
  "in_reply_to_status_id" : 754984265348026368,
  "created_at" : "2016-07-18 11:41:41 +0000",
  "in_reply_to_screen_name" : "sciencemuseum",
  "in_reply_to_user_id_str" : "15987295",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Open Culture",
      "screen_name" : "openculture",
      "indices" : [ 3, 15 ],
      "id_str" : "19826509",
      "id" : 19826509
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/openculture\/status\/754794319010082820\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/ZhWRtq2ZnZ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CnmE_8RUIAAd5mo.jpg",
      "id_str" : "754780646606643200",
      "id" : 754780646606643200,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CnmE_8RUIAAd5mo.jpg",
      "sizes" : [ {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/ZhWRtq2ZnZ"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/NNCD8XZ6IJ",
      "expanded_url" : "http:\/\/goo.gl\/gBrRSS",
      "display_url" : "goo.gl\/gBrRSS"
    } ]
  },
  "geo" : { },
  "id_str" : "754962165275197440",
  "text" : "RT @openculture: The Feminist Theory of Simone de Beauvoir Explained with 8-Bit Video Games https:\/\/t.co\/NNCD8XZ6IJ https:\/\/t.co\/ZhWRtq2ZnZ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/openculture\/status\/754794319010082820\/photo\/1",
        "indices" : [ 99, 122 ],
        "url" : "https:\/\/t.co\/ZhWRtq2ZnZ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CnmE_8RUIAAd5mo.jpg",
        "id_str" : "754780646606643200",
        "id" : 754780646606643200,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CnmE_8RUIAAd5mo.jpg",
        "sizes" : [ {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/ZhWRtq2ZnZ"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 75, 98 ],
        "url" : "https:\/\/t.co\/NNCD8XZ6IJ",
        "expanded_url" : "http:\/\/goo.gl\/gBrRSS",
        "display_url" : "goo.gl\/gBrRSS"
      } ]
    },
    "geo" : { },
    "id_str" : "754794319010082820",
    "text" : "The Feminist Theory of Simone de Beauvoir Explained with 8-Bit Video Games https:\/\/t.co\/NNCD8XZ6IJ https:\/\/t.co\/ZhWRtq2ZnZ",
    "id" : 754794319010082820,
    "created_at" : "2016-07-17 21:46:03 +0000",
    "user" : {
      "name" : "Open Culture",
      "screen_name" : "openculture",
      "protected" : false,
      "id_str" : "19826509",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/851645340830715904\/jrs1gcNM_normal.jpg",
      "id" : 19826509,
      "verified" : false
    }
  },
  "id" : 754962165275197440,
  "created_at" : "2016-07-18 08:53:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/IXkeBfPTXi",
      "expanded_url" : "https:\/\/twitter.com\/auremoser\/status\/754840426448818177",
      "display_url" : "twitter.com\/auremoser\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "754961583839870978",
  "text" : "#49: \u00ABThe most interesting destinations aren\u2019t geotagged, are not easily geo-taggable.\u00BB \uD83D\uDC98 https:\/\/t.co\/IXkeBfPTXi",
  "id" : 754961583839870978,
  "created_at" : "2016-07-18 08:50:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Science Museum",
      "screen_name" : "sciencemuseum",
      "indices" : [ 101, 115 ],
      "id_str" : "15987295",
      "id" : 15987295
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/754946383426256896\/photo\/1",
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/ZreWhfkJmA",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CnobuXaXgAAwKc5.jpg",
      "id_str" : "754946370910519296",
      "id" : 754946370910519296,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CnobuXaXgAAwKc5.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      } ],
      "display_url" : "pic.twitter.com\/ZreWhfkJmA"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.5314794006306, -0.07574021816260716 ]
  },
  "id_str" : "754946383426256896",
  "text" : "Nice, finally have seen this in person. But disappointed of how Rosalind is treated on the plaque by @sciencemuseum. https:\/\/t.co\/ZreWhfkJmA",
  "id" : 754946383426256896,
  "created_at" : "2016-07-18 07:50:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "quantifiedself",
      "indices" : [ 70, 85 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/bG2uUlYRHM",
      "expanded_url" : "http:\/\/www.sciencemuseum.org.uk\/visitmuseum\/plan_your_visit\/exhibitions\/beyond-the-lab",
      "display_url" : "sciencemuseum.org.uk\/visitmuseum\/pl\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "754794817192914944",
  "text" : "The Science Museum not only has a nice exhibit on personal data &amp; #quantifiedself but also on DIY Science. https:\/\/t.co\/bG2uUlYRHM",
  "id" : 754794817192914944,
  "created_at" : "2016-07-17 21:48:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andreas Mueller",
      "screen_name" : "amuellerml",
      "indices" : [ 0, 11 ],
      "id_str" : "471550563",
      "id" : 471550563
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "754756615916560384",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.51864947290301, -0.132581172511105 ]
  },
  "id_str" : "754771837066829824",
  "in_reply_to_user_id" : 471550563,
  "text" : "@amuellerml have fun with it! And let me know if you find anything interesting or need help!",
  "id" : 754771837066829824,
  "in_reply_to_status_id" : 754756615916560384,
  "created_at" : "2016-07-17 20:16:43 +0000",
  "in_reply_to_screen_name" : "amuellerml",
  "in_reply_to_user_id_str" : "471550563",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andreas Mueller",
      "screen_name" : "amuellerml",
      "indices" : [ 0, 11 ],
      "id_str" : "471550563",
      "id" : 471550563
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "754729614560235520",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.50062481877534, -0.1931757945569169 ]
  },
  "id_str" : "754747592714625024",
  "in_reply_to_user_id" : 471550563,
  "text" : "@amuellerml unfortunately  there isn\u2019t right now. Is getting all data impractical for you?",
  "id" : 754747592714625024,
  "in_reply_to_status_id" : 754729614560235520,
  "created_at" : "2016-07-17 18:40:23 +0000",
  "in_reply_to_screen_name" : "amuellerml",
  "in_reply_to_user_id_str" : "471550563",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andreas Mueller",
      "screen_name" : "amuellerml",
      "indices" : [ 0, 11 ],
      "id_str" : "471550563",
      "id" : 471550563
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "754727939107721216",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.50391797263005, -0.179874779075405 ]
  },
  "id_str" : "754728302502416384",
  "in_reply_to_user_id" : 471550563,
  "text" : "@amuellerml no problem, it\u2019s not that obvious. And glad to hear you like it!",
  "id" : 754728302502416384,
  "in_reply_to_status_id" : 754727939107721216,
  "created_at" : "2016-07-17 17:23:44 +0000",
  "in_reply_to_screen_name" : "amuellerml",
  "in_reply_to_user_id_str" : "471550563",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andreas Mueller",
      "screen_name" : "amuellerml",
      "indices" : [ 0, 11 ],
      "id_str" : "471550563",
      "id" : 471550563
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/Qo3cRRP3rk",
      "expanded_url" : "https:\/\/github.com\/openSNP\/snpr",
      "display_url" : "github.com\/openSNP\/snpr"
    } ]
  },
  "in_reply_to_status_id_str" : "754721661115432960",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.50389394168242, -0.1798618276545114 ]
  },
  "id_str" : "754726364209639425",
  "in_reply_to_user_id" : 471550563,
  "text" : "@amuellerml actually we are, the link is in the footer of the page. And here directly to Github: https:\/\/t.co\/Qo3cRRP3rk",
  "id" : 754726364209639425,
  "in_reply_to_status_id" : 754721661115432960,
  "created_at" : "2016-07-17 17:16:02 +0000",
  "in_reply_to_screen_name" : "amuellerml",
  "in_reply_to_user_id_str" : "471550563",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ourlivesindata",
      "indices" : [ 43, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/AtPBedseo0",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BH988d9Dx9F\/",
      "display_url" : "instagram.com\/p\/BH988d9Dx9F\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.4972929928, -0.17472351632 ]
  },
  "id_str" : "754702761434972160",
  "text" : "I did the data sharing personality quiz at #ourlivesindata and that's the result\u2026 @ Science Museum https:\/\/t.co\/AtPBedseo0",
  "id" : 754702761434972160,
  "created_at" : "2016-07-17 15:42:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/zz2b8MXNXb",
      "expanded_url" : "https:\/\/medium.com\/@honeystaysuper\/we-regret-to-inform-you-that-the-remainder-of-2016-has-been-cancelled-ce7944c2e6c2#.e5q8rvn96",
      "display_url" : "medium.com\/@honeystaysupe\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.539164, -0.079387 ]
  },
  "id_str" : "754617860283072512",
  "text" : "\u00ABpower down 2016, disconnect all cords, count to six months, reconnect everything\u2026\u00BB https:\/\/t.co\/zz2b8MXNXb",
  "id" : 754617860283072512,
  "created_at" : "2016-07-17 10:04:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.53907461013079, -0.0792211259940212 ]
  },
  "id_str" : "754580439164186624",
  "text" : "\u00ABApparently it's London Fetish Week!\u00BB \u2014 \u00ABIs this the name of the Star Wars convention you told me about?\u00BB",
  "id" : 754580439164186624,
  "created_at" : "2016-07-17 07:36:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Edmunds",
      "screen_name" : "SCEdmunds",
      "indices" : [ 0, 10 ],
      "id_str" : "176024190",
      "id" : 176024190
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "754396320715112448",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.52003345355929, -0.06068048705957774 ]
  },
  "id_str" : "754401107615580162",
  "in_reply_to_user_id" : 176024190,
  "text" : "@SCEdmunds good call. Tomorrow!",
  "id" : 754401107615580162,
  "in_reply_to_status_id" : 754396320715112448,
  "created_at" : "2016-07-16 19:43:34 +0000",
  "in_reply_to_screen_name" : "SCEdmunds",
  "in_reply_to_user_id_str" : "176024190",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "754258595114516480",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.505844858523, -0.1232871506364302 ]
  },
  "id_str" : "754379650009358336",
  "in_reply_to_user_id" : 14286491,
  "text" : "That was great. Also memorials for JD Hooker, Lyell etc. Though I\u2019m kind of jealous that Newton\u2019s memorial is so much larger.",
  "id" : 754379650009358336,
  "in_reply_to_status_id" : 754258595114516480,
  "created_at" : "2016-07-16 18:18:18 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "754347941486297088",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.51288013756017, -0.1342503774005232 ]
  },
  "id_str" : "754349035444703233",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot wiggle it!",
  "id" : 754349035444703233,
  "in_reply_to_status_id" : 754347941486297088,
  "created_at" : "2016-07-16 16:16:39 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bastien Chevreux",
      "screen_name" : "BaCh_mira",
      "indices" : [ 0, 10 ],
      "id_str" : "360258516",
      "id" : 360258516
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "754273192039084032",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.499660606544, -0.1268159318716515 ]
  },
  "id_str" : "754287052800331776",
  "in_reply_to_user_id" : 360258516,
  "text" : "@BaCh_mira thanks, will have a look.",
  "id" : 754287052800331776,
  "in_reply_to_status_id" : 754273192039084032,
  "created_at" : "2016-07-16 12:10:22 +0000",
  "in_reply_to_screen_name" : "BaCh_mira",
  "in_reply_to_user_id_str" : "360258516",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.53930620105507, -0.07937730464951155 ]
  },
  "id_str" : "754272273285210112",
  "text" : "\u00ABEach time we meet there seems to be some horrible world news. Now I fear our planned road trip coincidences with the US election.\u00BB",
  "id" : 754272273285210112,
  "created_at" : "2016-07-16 11:11:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.53906134850713, -0.07924060200687576 ]
  },
  "id_str" : "754258595114516480",
  "text" : "Going full evolutionary tourist and visiting Darwin\u2019s grave. Any other ones I should look out for? (Price\u2019s unfortunately isn\u2019t marked).",
  "id" : 754258595114516480,
  "created_at" : "2016-07-16 10:17:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Iara VPS",
      "screen_name" : "iaravps",
      "indices" : [ 0, 8 ],
      "id_str" : "173881525",
      "id" : 173881525
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "754079189653983234",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.53905574920694, -0.07923068223451214 ]
  },
  "id_str" : "754087016615317505",
  "in_reply_to_user_id" : 173881525,
  "text" : "@iaravps sweet. I\u2019ll keep my fingers crossed that it works out!",
  "id" : 754087016615317505,
  "in_reply_to_status_id" : 754079189653983234,
  "created_at" : "2016-07-15 22:55:29 +0000",
  "in_reply_to_screen_name" : "iaravps",
  "in_reply_to_user_id_str" : "173881525",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "753981151052718082",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.53957779215075, -0.0793553364408447 ]
  },
  "id_str" : "754066511640297472",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich working on it! \u2708\uFE0F\uD83D\uDE0F",
  "id" : 754066511640297472,
  "in_reply_to_status_id" : 753981151052718082,
  "created_at" : "2016-07-15 21:34:00 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Iara VPS",
      "screen_name" : "iaravps",
      "indices" : [ 0, 8 ],
      "id_str" : "173881525",
      "id" : 173881525
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "754047841383936000",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.53955624530496, -0.07934404704949272 ]
  },
  "id_str" : "754066302239698944",
  "in_reply_to_user_id" : 173881525,
  "text" : "@iaravps great, San Diego? ;)",
  "id" : 754066302239698944,
  "in_reply_to_status_id" : 754047841383936000,
  "created_at" : "2016-07-15 21:33:10 +0000",
  "in_reply_to_screen_name" : "iaravps",
  "in_reply_to_user_id_str" : "173881525",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.46996753813563, -0.4473415797849297 ]
  },
  "id_str" : "753980366415888384",
  "text" : "Not only did the algorithmic facial recognition at the border not work. Even the human border police didn\u2019t believe that it\u2019s my passport\u2026",
  "id" : 753980366415888384,
  "created_at" : "2016-07-15 15:51:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.04699003421705, 8.570870747797722 ]
  },
  "id_str" : "753953876487860224",
  "text" : "And en route FRA \u2708\uFE0F LHR.",
  "id" : 753953876487860224,
  "created_at" : "2016-07-15 14:06:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "kaa",
      "screen_name" : "katrinfaensen",
      "indices" : [ 0, 14 ],
      "id_str" : "306281663",
      "id" : 306281663
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "753944346555285504",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.04666391656659, 8.57143422570692 ]
  },
  "id_str" : "753947243019898880",
  "in_reply_to_user_id" : 306281663,
  "text" : "@katrinfaensen nope, not my cup of tea :)",
  "id" : 753947243019898880,
  "in_reply_to_status_id" : 753944346555285504,
  "created_at" : "2016-07-15 13:40:05 +0000",
  "in_reply_to_screen_name" : "katrinfaensen",
  "in_reply_to_user_id_str" : "306281663",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Blin",
      "screen_name" : "kaiblin",
      "indices" : [ 0, 8 ],
      "id_str" : "124202458",
      "id" : 124202458
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "753938062984511488",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.04661279805728, 8.571338039871149 ]
  },
  "id_str" : "753938315074764800",
  "in_reply_to_user_id" : 124202458,
  "text" : "@kaiblin nice, thanks!",
  "id" : 753938315074764800,
  "in_reply_to_status_id" : 753938062984511488,
  "created_at" : "2016-07-15 13:04:36 +0000",
  "in_reply_to_screen_name" : "kaiblin",
  "in_reply_to_user_id_str" : "124202458",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Blin",
      "screen_name" : "kaiblin",
      "indices" : [ 0, 8 ],
      "id_str" : "124202458",
      "id" : 124202458
    }, {
      "name" : "Nick Loman",
      "screen_name" : "pathogenomenick",
      "indices" : [ 97, 113 ],
      "id_str" : "85906238",
      "id" : 85906238
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "753937194356727810",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.04660639746497, 8.57129064237876 ]
  },
  "id_str" : "753937715880685568",
  "in_reply_to_user_id" : 124202458,
  "text" : "@kaiblin but then: all of our carry-on is already full of electronics in any case. And don\u2019t ask @pathogenomenick about that ;)",
  "id" : 753937715880685568,
  "in_reply_to_status_id" : 753937194356727810,
  "created_at" : "2016-07-15 13:02:13 +0000",
  "in_reply_to_screen_name" : "kaiblin",
  "in_reply_to_user_id_str" : "124202458",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony Ross-Hellauer",
      "screen_name" : "tonyR_H",
      "indices" : [ 0, 8 ],
      "id_str" : "44890780",
      "id" : 44890780
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "753936466980573184",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.04667663684103, 8.571385530194027 ]
  },
  "id_str" : "753936774783721472",
  "in_reply_to_user_id" : 44890780,
  "text" : "@tonyR_H aiming for a 50:50 split between down and productivity. Don\u2019t mess up my schedule ;)",
  "id" : 753936774783721472,
  "in_reply_to_status_id" : 753936466980573184,
  "created_at" : "2016-07-15 12:58:29 +0000",
  "in_reply_to_screen_name" : "tonyR_H",
  "in_reply_to_user_id_str" : "44890780",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Blin",
      "screen_name" : "kaiblin",
      "indices" : [ 65, 73 ],
      "id_str" : "124202458",
      "id" : 124202458
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/e62YHv6n6Z",
      "expanded_url" : "https:\/\/twitter.com\/pfandtasse\/status\/753936271286931457",
      "display_url" : "twitter.com\/pfandtasse\/sta\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.04662533251861, 8.57141651695177 ]
  },
  "id_str" : "753936564766511108",
  "text" : "Especially if you build a small raspberry-based cluster into it. @kaiblin how about that? https:\/\/t.co\/e62YHv6n6Z",
  "id" : 753936564766511108,
  "created_at" : "2016-07-15 12:57:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony Ross-Hellauer",
      "screen_name" : "tonyR_H",
      "indices" : [ 0, 8 ],
      "id_str" : "44890780",
      "id" : 44890780
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "753935511526445056",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.04657198798198, 8.571563772913994 ]
  },
  "id_str" : "753935726430027776",
  "in_reply_to_user_id" : 44890780,
  "text" : "@tonyR_H officially doing vacation in London. Inofficially meeting people and getting a writing-retreat ;)",
  "id" : 753935726430027776,
  "in_reply_to_status_id" : 753935511526445056,
  "created_at" : "2016-07-15 12:54:19 +0000",
  "in_reply_to_screen_name" : "tonyR_H",
  "in_reply_to_user_id_str" : "44890780",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony Ross-Hellauer",
      "screen_name" : "tonyR_H",
      "indices" : [ 0, 8 ],
      "id_str" : "44890780",
      "id" : 44890780
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "753934622266892291",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.04666858014347, 8.571178367511079 ]
  },
  "id_str" : "753935426096881664",
  "in_reply_to_user_id" : 44890780,
  "text" : "@tonyR_H I\u2019m still more into trying to catch flights than Pokemon ;)",
  "id" : 753935426096881664,
  "in_reply_to_status_id" : 753934622266892291,
  "created_at" : "2016-07-15 12:53:07 +0000",
  "in_reply_to_screen_name" : "tonyR_H",
  "in_reply_to_user_id_str" : "44890780",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/753933304076926976\/photo\/1",
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/frxGfHFcT6",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CnaCV9CWEAAlSBH.jpg",
      "id_str" : "753933301304397824",
      "id" : 753933301304397824,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CnaCV9CWEAAlSBH.jpg",
      "sizes" : [ {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1212,
        "resize" : "fit",
        "w" : 909
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      }, {
        "h" : 1212,
        "resize" : "fit",
        "w" : 909
      } ],
      "display_url" : "pic.twitter.com\/frxGfHFcT6"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.046556, 8.571409 ]
  },
  "id_str" : "753933304076926976",
  "text" : "And I thought my carry-on would be pretty good. But that's a whole other level of cool. \uD83D\uDC27\uD83D\uDC27 https:\/\/t.co\/frxGfHFcT6",
  "id" : 753933304076926976,
  "created_at" : "2016-07-15 12:44:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/753924100217794561\/photo\/1",
      "indices" : [ 4, 27 ],
      "url" : "https:\/\/t.co\/DuMGoMfa5H",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CnZ59T2WYAAZBYW.jpg",
      "id_str" : "753924081838350336",
      "id" : 753924081838350336,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CnZ59T2WYAAZBYW.jpg",
      "sizes" : [ {
        "h" : 900,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 598,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/DuMGoMfa5H"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11721156368642, 8.683467376146623 ]
  },
  "id_str" : "753924100217794561",
  "text" : "Hm\u2026 https:\/\/t.co\/DuMGoMfa5H",
  "id" : 753924100217794561,
  "created_at" : "2016-07-15 12:08:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony Ross-Hellauer",
      "screen_name" : "tonyR_H",
      "indices" : [ 0, 8 ],
      "id_str" : "44890780",
      "id" : 44890780
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "753905546118529024",
  "geo" : { },
  "id_str" : "753905697276985344",
  "in_reply_to_user_id" : 44890780,
  "text" : "@tonyR_H also when people are so pushy to commit you to things like joining an organizing committee! \uD83D\uDE09",
  "id" : 753905697276985344,
  "in_reply_to_status_id" : 753905546118529024,
  "created_at" : "2016-07-15 10:54:59 +0000",
  "in_reply_to_screen_name" : "tonyR_H",
  "in_reply_to_user_id_str" : "44890780",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 75 ],
      "url" : "https:\/\/t.co\/v6PoAGb647",
      "expanded_url" : "http:\/\/vomzi.com\/wp-content\/uploads\/2016\/02\/cool-head-explode-gif-127.gif",
      "display_url" : "vomzi.com\/wp-content\/upl\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "753905049051463680",
  "text" : "Academia, where you\u2019re pathologically overcommitted https:\/\/t.co\/v6PoAGb647",
  "id" : 753905049051463680,
  "created_at" : "2016-07-15 10:52:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 86 ],
      "url" : "https:\/\/t.co\/YtrkZHRner",
      "expanded_url" : "http:\/\/blogs.scientificamerican.com\/sa-visual\/visualizing-the-global-network-of-languages\/",
      "display_url" : "blogs.scientificamerican.com\/sa-visual\/visu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "753888596965326848",
  "text" : "There goes my day: Visualizing the Global Network of Languages https:\/\/t.co\/YtrkZHRner",
  "id" : 753888596965326848,
  "created_at" : "2016-07-15 09:47:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angela Bassa",
      "screen_name" : "AngeBassa",
      "indices" : [ 3, 13 ],
      "id_str" : "937467860",
      "id" : 937467860
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "753860743502630912",
  "text" : "RT @AngeBassa: A grown man seriously asked me if I was really a mathematician.\n\nI asked why.\n\nHe replied, \u201Cbecause you wear pink.\u201D https:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/RAgmHDTNch",
        "expanded_url" : "https:\/\/twitter.com\/extremefriday\/status\/753568424622694401",
        "display_url" : "twitter.com\/extremefriday\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "753618428238393344",
    "text" : "A grown man seriously asked me if I was really a mathematician.\n\nI asked why.\n\nHe replied, \u201Cbecause you wear pink.\u201D https:\/\/t.co\/RAgmHDTNch",
    "id" : 753618428238393344,
    "created_at" : "2016-07-14 15:53:29 +0000",
    "user" : {
      "name" : "Angela Bassa",
      "screen_name" : "AngeBassa",
      "protected" : false,
      "id_str" : "937467860",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/925692072060956673\/-ZGUs27H_normal.jpg",
      "id" : 937467860,
      "verified" : false
    }
  },
  "id" : 753860743502630912,
  "created_at" : "2016-07-15 07:56:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 81 ],
      "url" : "https:\/\/t.co\/jVbNI8hq9w",
      "expanded_url" : "http:\/\/www.atlasobscura.com\/articles\/why-smart-clowns-immortalize-their-makeup-designs-on-ceramic-eggs",
      "display_url" : "atlasobscura.com\/articles\/why-s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "753856772927057921",
  "text" : "Who knew that copyright also concerned clownish eggheads? https:\/\/t.co\/jVbNI8hq9w",
  "id" : 753856772927057921,
  "created_at" : "2016-07-15 07:40:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Elio Qoshi",
      "screen_name" : "elioqoshi",
      "indices" : [ 14, 24 ],
      "id_str" : "93434375",
      "id" : 93434375
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "753831509019078657",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06095441982715, 8.818558654597213 ]
  },
  "id_str" : "753838081724129280",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @elioqoshi it\u2019s not like I asked for them specifically :D",
  "id" : 753838081724129280,
  "in_reply_to_status_id" : 753831509019078657,
  "created_at" : "2016-07-15 06:26:18 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elio Qoshi",
      "screen_name" : "elioqoshi",
      "indices" : [ 57, 67 ],
      "id_str" : "93434375",
      "id" : 93434375
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/5d3AfTVQQV",
      "expanded_url" : "https:\/\/twitter.com\/istar_nil\/status\/753761168687177728",
      "display_url" : "twitter.com\/istar_nil\/stat\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0609220534021, 8.818540388612723 ]
  },
  "id_str" : "753830214791069696",
  "text" : "Great to see how they turn up all over the world. Thanks @elioqoshi for designing them! https:\/\/t.co\/5d3AfTVQQV",
  "id" : 753830214791069696,
  "created_at" : "2016-07-15 05:55:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06084266612276, 8.818683761054263 ]
  },
  "id_str" : "753722487142248448",
  "text" : "\u00ABI\u2019d love to spend some time in jail with you!\u00BB \u2014 \u00ABSpoken like a true romantic.\u00BB",
  "id" : 753722487142248448,
  "created_at" : "2016-07-14 22:46:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 32 ],
      "url" : "https:\/\/t.co\/6vInIF4Zt2",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BH2yDUWDLb8\/",
      "display_url" : "instagram.com\/p\/BH2yDUWDLb8\/"
    } ]
  },
  "geo" : { },
  "id_str" : "753693645233094656",
  "text" : "Tofu-ing https:\/\/t.co\/6vInIF4Zt2",
  "id" : 753693645233094656,
  "created_at" : "2016-07-14 20:52:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uD83D\uDC9A Aure Moser \uD83D\uDC9A",
      "screen_name" : "auremoser",
      "indices" : [ 3, 13 ],
      "id_str" : "186529934",
      "id" : 186529934
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/dp2QAlAdqS",
      "expanded_url" : "http:\/\/lochcarron.co.uk\/clanmap\/",
      "display_url" : "lochcarron.co.uk\/clanmap\/"
    } ]
  },
  "geo" : { },
  "id_str" : "753631570368532480",
  "text" : "RT @auremoser: like the map and metadata styling in this clan map of scotland (highlander search shown): https:\/\/t.co\/dp2QAlAdqS https:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/auremoser\/status\/753618614905925632\/photo\/1",
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/fCuPPRVvgA",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CnVkHktWgAAkbwi.jpg",
        "id_str" : "753618593930182656",
        "id" : 753618593930182656,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CnVkHktWgAAkbwi.jpg",
        "sizes" : [ {
          "h" : 634,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 758,
          "resize" : "fit",
          "w" : 1435
        }, {
          "h" : 359,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 758,
          "resize" : "fit",
          "w" : 1435
        } ],
        "display_url" : "pic.twitter.com\/fCuPPRVvgA"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 90, 113 ],
        "url" : "https:\/\/t.co\/dp2QAlAdqS",
        "expanded_url" : "http:\/\/lochcarron.co.uk\/clanmap\/",
        "display_url" : "lochcarron.co.uk\/clanmap\/"
      } ]
    },
    "geo" : { },
    "id_str" : "753618614905925632",
    "text" : "like the map and metadata styling in this clan map of scotland (highlander search shown): https:\/\/t.co\/dp2QAlAdqS https:\/\/t.co\/fCuPPRVvgA",
    "id" : 753618614905925632,
    "created_at" : "2016-07-14 15:54:14 +0000",
    "user" : {
      "name" : "\uD83D\uDC9A Aure Moser \uD83D\uDC9A",
      "screen_name" : "auremoser",
      "protected" : false,
      "id_str" : "186529934",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/723868643688325122\/AHwUDHy3_normal.jpg",
      "id" : 186529934,
      "verified" : false
    }
  },
  "id" : 753631570368532480,
  "created_at" : "2016-07-14 16:45:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bastien Chevreux",
      "screen_name" : "BaCh_mira",
      "indices" : [ 0, 10 ],
      "id_str" : "360258516",
      "id" : 360258516
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "753602037145804800",
  "in_reply_to_user_id" : 360258516,
  "text" : "@BaCh_mira btw. following the BOSC dinner convo: could you email me some more info in the GC bias I should look out for? :)",
  "id" : 753602037145804800,
  "created_at" : "2016-07-14 14:48:21 +0000",
  "in_reply_to_screen_name" : "BaCh_mira",
  "in_reply_to_user_id_str" : "360258516",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan Rice",
      "screen_name" : "alanmrice",
      "indices" : [ 0, 10 ],
      "id_str" : "6872082",
      "id" : 6872082
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "753552576600211456",
  "geo" : { },
  "id_str" : "753552679100612608",
  "in_reply_to_user_id" : 6872082,
  "text" : "@alanmrice just as weird as you\u2019d imagine! On the plus side: I had very little jet lag when coming back to Europe!",
  "id" : 753552679100612608,
  "in_reply_to_status_id" : 753552576600211456,
  "created_at" : "2016-07-14 11:32:13 +0000",
  "in_reply_to_screen_name" : "alanmrice",
  "in_reply_to_user_id_str" : "6872082",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan Rice",
      "screen_name" : "alanmrice",
      "indices" : [ 0, 10 ],
      "id_str" : "6872082",
      "id" : 6872082
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "753467802468712448",
  "geo" : { },
  "id_str" : "753551719234203648",
  "in_reply_to_user_id" : 6872082,
  "text" : "@alanmrice back to your time zone by now? :)",
  "id" : 753551719234203648,
  "in_reply_to_status_id" : 753467802468712448,
  "created_at" : "2016-07-14 11:28:24 +0000",
  "in_reply_to_screen_name" : "alanmrice",
  "in_reply_to_user_id_str" : "6872082",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mrgunn",
      "screen_name" : "mrgunn",
      "indices" : [ 0, 7 ],
      "id_str" : "15237935",
      "id" : 15237935
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "753460927870083072",
  "geo" : { },
  "id_str" : "753551180467494912",
  "in_reply_to_user_id" : 15237935,
  "text" : "@mrgunn congrats!",
  "id" : 753551180467494912,
  "in_reply_to_status_id" : 753460927870083072,
  "created_at" : "2016-07-14 11:26:16 +0000",
  "in_reply_to_screen_name" : "mrgunn",
  "in_reply_to_user_id_str" : "15237935",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/nsgPFWX89M",
      "expanded_url" : "https:\/\/medium.com\/@davepell\/ruth-bader-ginsberg-is-under-the-influence-1668bf701b49#.wovbt8j8e",
      "display_url" : "medium.com\/@davepell\/ruth\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "753550413262155780",
  "text" : "\u00ABBreak with precedent. We\u2019ve got your back. This is the Notorious RBG vs a Loquacious P.O.S.\u00BB https:\/\/t.co\/nsgPFWX89M",
  "id" : 753550413262155780,
  "created_at" : "2016-07-14 11:23:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 85 ],
      "url" : "https:\/\/t.co\/YHTgahpQcS",
      "expanded_url" : "https:\/\/twitter.com\/evasqyap\/status\/753292216064507905",
      "display_url" : "twitter.com\/evasqyap\/statu\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17244863060799, 8.6276047246681 ]
  },
  "id_str" : "753528376170872833",
  "text" : "See me discussing open source software while pool partying. \uD83C\uDF89 https:\/\/t.co\/YHTgahpQcS",
  "id" : 753528376170872833,
  "created_at" : "2016-07-14 09:55:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "F\u00FCxin",
      "screen_name" : "foxeen",
      "indices" : [ 0, 7 ],
      "id_str" : "46904555",
      "id" : 46904555
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "753521699442819072",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1724188615902, 8.627586141055065 ]
  },
  "id_str" : "753522178109403136",
  "in_reply_to_user_id" : 46904555,
  "text" : "@foxeen yep :)",
  "id" : 753522178109403136,
  "in_reply_to_status_id" : 753521699442819072,
  "created_at" : "2016-07-14 09:31:01 +0000",
  "in_reply_to_screen_name" : "foxeen",
  "in_reply_to_user_id_str" : "46904555",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 79 ],
      "url" : "https:\/\/t.co\/cxutgH28kw",
      "expanded_url" : "http:\/\/xkcd.com\/1706\/",
      "display_url" : "xkcd.com\/1706\/"
    } ]
  },
  "geo" : { },
  "id_str" : "753519816833654784",
  "text" : "I always wanted to give that a try to see what happens. https:\/\/t.co\/cxutgH28kw",
  "id" : 753519816833654784,
  "created_at" : "2016-07-14 09:21:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Iara VPS",
      "screen_name" : "iaravps",
      "indices" : [ 0, 8 ],
      "id_str" : "173881525",
      "id" : 173881525
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "753333857957666816",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06089354816825, 8.818433225279142 ]
  },
  "id_str" : "753334590476091392",
  "in_reply_to_user_id" : 173881525,
  "text" : "@iaravps happy to bring my copy the next time we meet thanks to all the flying.",
  "id" : 753334590476091392,
  "in_reply_to_status_id" : 753333857957666816,
  "created_at" : "2016-07-13 21:05:37 +0000",
  "in_reply_to_screen_name" : "iaravps",
  "in_reply_to_user_id_str" : "173881525",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "latergram",
      "indices" : [ 11, 21 ]
    } ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/2ZCAYx1tkH",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BH0GhIjDC34\/",
      "display_url" : "instagram.com\/p\/BH0GhIjDC34\/"
    } ]
  },
  "geo" : { },
  "id_str" : "753316438191013888",
  "text" : "An extreme #latergram (finally figured out how to export Live Photos from iOS) https:\/\/t.co\/2ZCAYx1tkH",
  "id" : 753316438191013888,
  "created_at" : "2016-07-13 19:53:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/753298325114421249\/photo\/1",
      "indices" : [ 67, 90 ],
      "url" : "https:\/\/t.co\/wqsLY4bTE4",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CnRAqLcXYAAE5OX.jpg",
      "id_str" : "753298131048161280",
      "id" : 753298131048161280,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CnRAqLcXYAAE5OX.jpg",
      "sizes" : [ {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 3024,
        "resize" : "fit",
        "w" : 4032
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/wqsLY4bTE4"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/753298325114421249\/photo\/1",
      "indices" : [ 67, 90 ],
      "url" : "https:\/\/t.co\/wqsLY4bTE4",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CnRAqOLWAAA63l7.jpg",
      "id_str" : "753298131782074368",
      "id" : 753298131782074368,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CnRAqOLWAAA63l7.jpg",
      "sizes" : [ {
        "h" : 4032,
        "resize" : "fit",
        "w" : 3024
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      } ],
      "display_url" : "pic.twitter.com\/wqsLY4bTE4"
    } ],
    "hashtags" : [ {
      "text" : "ISMB16",
      "indices" : [ 23, 30 ]
    }, {
      "text" : "bosc2016",
      "indices" : [ 33, 42 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06087339953525, 8.818565709524618 ]
  },
  "id_str" : "753298325114421249",
  "text" : "My experience with the #ISMB16 \/ #bosc2016 location in a nutshell. https:\/\/t.co\/wqsLY4bTE4",
  "id" : 753298325114421249,
  "created_at" : "2016-07-13 18:41:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "latergram",
      "indices" : [ 37, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 48, 71 ],
      "url" : "https:\/\/t.co\/oGydYqlCVI",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BHzisafDZxL\/",
      "display_url" : "instagram.com\/p\/BHzisafDZxL\/"
    } ]
  },
  "geo" : { },
  "id_str" : "753237661100441604",
  "text" : "The only Disney Magic I acknowledge. #latergram https:\/\/t.co\/oGydYqlCVI",
  "id" : 753237661100441604,
  "created_at" : "2016-07-13 14:40:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 80 ],
      "url" : "https:\/\/t.co\/FllE1XNurT",
      "expanded_url" : "http:\/\/scitation.aip.org\/content\/aip\/journal\/chaos\/26\/9\/10.1063\/1.4954275",
      "display_url" : "scitation.aip.org\/content\/aip\/jo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "753225400482947072",
  "text" : "Modelling jet-lag, published in the journal \u00ABChaos\u00BB \u2708\uFE0F \uD83D\uDE02 https:\/\/t.co\/FllE1XNurT",
  "id" : 753225400482947072,
  "created_at" : "2016-07-13 13:51:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/OpW9cSxBgD",
      "expanded_url" : "https:\/\/twitter.com\/marc_rr\/status\/753143119714127872",
      "display_url" : "twitter.com\/marc_rr\/status\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "753149255930482688",
  "text" : "Looks like an awesome data set, but also like an awesome way to find spurious correlations. https:\/\/t.co\/OpW9cSxBgD",
  "id" : 753149255930482688,
  "created_at" : "2016-07-13 08:49:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17297691204601, 8.627840448178935 ]
  },
  "id_str" : "752910174894063616",
  "text" : "Survived a jet lagged day full of meetings without going \uD83D\uDE34.",
  "id" : 752910174894063616,
  "created_at" : "2016-07-12 16:59:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/mTw0GSjIC9",
      "expanded_url" : "https:\/\/twitter.com\/pjacock\/status\/752835825482797056",
      "display_url" : "twitter.com\/pjacock\/status\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "752845748904026112",
  "text" : "Also: the lack of vegan\/vegetarian food meant skipping most meals in general. https:\/\/t.co\/mTw0GSjIC9",
  "id" : 752845748904026112,
  "created_at" : "2016-07-12 12:43:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "latergram",
      "indices" : [ 10, 20 ]
    } ],
    "urls" : [ {
      "indices" : [ 21, 44 ],
      "url" : "https:\/\/t.co\/YNfmh1C5JJ",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BHwWblnDAg_\/",
      "display_url" : "instagram.com\/p\/BHwWblnDAg_\/"
    } ]
  },
  "geo" : { },
  "id_str" : "752788493831663618",
  "text" : "Departure #latergram https:\/\/t.co\/YNfmh1C5JJ",
  "id" : 752788493831663618,
  "created_at" : "2016-07-12 08:55:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.03194885720737, 8.544186054784767 ]
  },
  "id_str" : "752780474557267970",
  "text" : "And back, after: First crossing of the equator, first circumnavigation and first crossing of the international dateline. \uD83D\uDC4D\u2708\uFE0F",
  "id" : 752780474557267970,
  "created_at" : "2016-07-12 08:23:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elizabeth Seiver",
      "screen_name" : "tweetotaler",
      "indices" : [ 0, 12 ],
      "id_str" : "29891068",
      "id" : 29891068
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "752717996125065216",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.03225765428519, 8.545204860710502 ]
  },
  "id_str" : "752780201961123840",
  "in_reply_to_user_id" : 29891068,
  "text" : "@tweetotaler this I read too!",
  "id" : 752780201961123840,
  "in_reply_to_status_id" : 752717996125065216,
  "created_at" : "2016-07-12 08:22:40 +0000",
  "in_reply_to_screen_name" : "tweetotaler",
  "in_reply_to_user_id_str" : "29891068",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christian Brueffer",
      "screen_name" : "cbrueffer",
      "indices" : [ 0, 10 ],
      "id_str" : "2475490934",
      "id" : 2475490934
    }, {
      "name" : "Minaal",
      "screen_name" : "minaal",
      "indices" : [ 11, 18 ],
      "id_str" : "246624621",
      "id" : 246624621
    }, {
      "name" : "Tortuga",
      "screen_name" : "TortugaBackpack",
      "indices" : [ 19, 35 ],
      "id_str" : "72396513",
      "id" : 72396513
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "752663640625602560",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.64512657204472, -73.77739683891278 ]
  },
  "id_str" : "752665093788332033",
  "in_reply_to_user_id" : 2475490934,
  "text" : "@cbrueffer @minaal @TortugaBackpack yay, safe travels!",
  "id" : 752665093788332033,
  "in_reply_to_status_id" : 752663640625602560,
  "created_at" : "2016-07-12 00:45:16 +0000",
  "in_reply_to_screen_name" : "cbrueffer",
  "in_reply_to_user_id_str" : "2475490934",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 37 ],
      "url" : "https:\/\/t.co\/IxansPBxAw",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BHvY-bTDHdE\/",
      "display_url" : "instagram.com\/p\/BHvY-bTDHdE\/"
    } ]
  },
  "geo" : { },
  "id_str" : "752653338534174722",
  "text" : "Working on it https:\/\/t.co\/IxansPBxAw",
  "id" : 752653338534174722,
  "created_at" : "2016-07-11 23:58:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Slate",
      "screen_name" : "Slate",
      "indices" : [ 94, 100 ],
      "id_str" : "15164565",
      "id" : 15164565
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 89 ],
      "url" : "https:\/\/t.co\/s0eKiu2Stv",
      "expanded_url" : "http:\/\/www.slate.com\/articles\/health_and_science\/science\/2016\/07\/jonah_lehrer_s_a_book_about_love_isn_t_full_of_fraud_but_it_still_has_its.html?wpsrc=sh_all_dt_tw_ru",
      "display_url" : "slate.com\/articles\/healt\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "752638468015218689",
  "text" : "\u00ABJonah Lehrer: more honest, more boring, still spreading bunk\u00BB \uD83D\uDD25\uD83D\uDD25\uD83D\uDD25https:\/\/t.co\/s0eKiu2Stv via @slate",
  "id" : 752638468015218689,
  "created_at" : "2016-07-11 22:59:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "752634307756384257",
  "text" : "If you want to know how the vegan food in Disney universe is: This airport Ramen tasted excellent and felt reasonably priced in comparison\u2026",
  "id" : 752634307756384257,
  "created_at" : "2016-07-11 22:42:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "752568430339948547",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.64322535592479, -73.77910107488462 ]
  },
  "id_str" : "752628351848841216",
  "in_reply_to_user_id" : 1044887107,
  "text" : "@vivek_ziel thanks. Enjoy ISMB! Was great to meet you!",
  "id" : 752628351848841216,
  "in_reply_to_status_id" : 752568430339948547,
  "created_at" : "2016-07-11 22:19:16 +0000",
  "in_reply_to_screen_name" : "raivivek_",
  "in_reply_to_user_id_str" : "1044887107",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "752558990844895233",
  "text" : "Now: MCO \u2708\uFE0F JFK. Slowly making my way back.",
  "id" : 752558990844895233,
  "created_at" : "2016-07-11 17:43:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gyroscope \u2728",
      "screen_name" : "gyroscope_app",
      "indices" : [ 0, 14 ],
      "id_str" : "2701949732",
      "id" : 2701949732
    }, {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 15, 24 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "752537597973377024",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 28.43211592686338, -81.30749089673164 ]
  },
  "id_str" : "752537817822162944",
  "in_reply_to_user_id" : 2701949732,
  "text" : "@gyroscope_app @eramirez thx, hope you\u2019ll figure out a way to optimize it even more! Love browsing the stats!",
  "id" : 752537817822162944,
  "in_reply_to_status_id" : 752537597973377024,
  "created_at" : "2016-07-11 16:19:31 +0000",
  "in_reply_to_screen_name" : "gyroscope_app",
  "in_reply_to_user_id_str" : "2701949732",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    }, {
      "name" : "Gyroscope \u2728",
      "screen_name" : "gyroscope_app",
      "indices" : [ 10, 24 ],
      "id_str" : "2701949732",
      "id" : 2701949732
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "752536868776865793",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 28.43211389000318, -81.30752982377325 ]
  },
  "id_str" : "752537450401128448",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez @gyroscope_app the note re:age calculation you mean?",
  "id" : 752537450401128448,
  "in_reply_to_status_id" : 752536868776865793,
  "created_at" : "2016-07-11 16:18:04 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gyroscope \u2728",
      "screen_name" : "gyroscope_app",
      "indices" : [ 0, 14 ],
      "id_str" : "2701949732",
      "id" : 2701949732
    }, {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 15, 24 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "752536046802341888",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 28.43211239415389, -81.30765023045903 ]
  },
  "id_str" : "752536599389433856",
  "in_reply_to_user_id" : 2701949732,
  "text" : "@gyroscope_app @eramirez only thing that bugs me a bit: just looking at the stats in the app seems to drain my battery pretty quickly?",
  "id" : 752536599389433856,
  "in_reply_to_status_id" : 752536046802341888,
  "created_at" : "2016-07-11 16:14:41 +0000",
  "in_reply_to_screen_name" : "gyroscope_app",
  "in_reply_to_user_id_str" : "2701949732",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gyroscope \u2728",
      "screen_name" : "gyroscope_app",
      "indices" : [ 0, 14 ],
      "id_str" : "2701949732",
      "id" : 2701949732
    }, {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 15, 24 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "752536046802341888",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 28.43211642792237, -81.30760166589141 ]
  },
  "id_str" : "752536425967579136",
  "in_reply_to_user_id" : 2701949732,
  "text" : "@gyroscope_app @eramirez ah, snap. But thanks for the update. Luckily I don\u2019t do the round trip regularly. Well done app btw!",
  "id" : 752536425967579136,
  "in_reply_to_status_id" : 752536046802341888,
  "created_at" : "2016-07-11 16:14:00 +0000",
  "in_reply_to_screen_name" : "gyroscope_app",
  "in_reply_to_user_id_str" : "2701949732",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    }, {
      "name" : "Gyroscope \u2728",
      "screen_name" : "gyroscope_app",
      "indices" : [ 10, 24 ],
      "id_str" : "2701949732",
      "id" : 2701949732
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "752524951593201664",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 28.43212495245153, -81.30746424648473 ]
  },
  "id_str" : "752535039255126016",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez @gyroscope_app just wonder whether the pro version would get that there\u2019s a shorter route to it.",
  "id" : 752535039255126016,
  "in_reply_to_status_id" : 752524951593201664,
  "created_at" : "2016-07-11 16:08:29 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gyroscope \u2728",
      "screen_name" : "gyroscope_app",
      "indices" : [ 11, 25 ],
      "id_str" : "2701949732",
      "id" : 2701949732
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/752521394852880384\/photo\/1",
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/RSZDzqho4u",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CnF-N3fW8AE1vEm.jpg",
      "id_str" : "752521389446459393",
      "id" : 752521389446459393,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CnF-N3fW8AE1vEm.jpg",
      "sizes" : [ {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/RSZDzqho4u"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 28.36621717552502, -81.55944529928412 ]
  },
  "id_str" : "752521394852880384",
  "text" : "Looks like @gyroscope_app doesn\u2019t handle global travel to well so far. \uD83D\uDE02 https:\/\/t.co\/RSZDzqho4u",
  "id" : 752521394852880384,
  "created_at" : "2016-07-11 15:14:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bj\u00F6rn Gr\u00FCning",
      "screen_name" : "bjoerngruening",
      "indices" : [ 3, 18 ],
      "id_str" : "117360280",
      "id" : 117360280
    }, {
      "name" : "Johannes K\u00F6ster",
      "screen_name" : "johanneskoester",
      "indices" : [ 37, 53 ],
      "id_str" : "4834898643",
      "id" : 4834898643
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bioconda",
      "indices" : [ 59, 68 ]
    }, {
      "text" : "ISMB16",
      "indices" : [ 75, 82 ]
    }, {
      "text" : "BOSC2016",
      "indices" : [ 95, 104 ]
    }, {
      "text" : "opensource",
      "indices" : [ 121, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "752520250973941764",
  "text" : "RT @bjoerngruening: Wall of shame by @johanneskoester from #bioconda fame. #ISMB16; learn from #BOSC2016 and only accept #opensource sw.\nht\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Johannes K\u00F6ster",
        "screen_name" : "johanneskoester",
        "indices" : [ 17, 33 ],
        "id_str" : "4834898643",
        "id" : 4834898643
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "bioconda",
        "indices" : [ 39, 48 ]
      }, {
        "text" : "ISMB16",
        "indices" : [ 55, 62 ]
      }, {
        "text" : "BOSC2016",
        "indices" : [ 75, 84 ]
      }, {
        "text" : "opensource",
        "indices" : [ 101, 112 ]
      } ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/HfgmmXKdBv",
        "expanded_url" : "https:\/\/github.com\/bioconda\/bioconda-recipes\/pull\/1951",
        "display_url" : "github.com\/bioconda\/bioco\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "752399012280557568",
    "text" : "Wall of shame by @johanneskoester from #bioconda fame. #ISMB16; learn from #BOSC2016 and only accept #opensource sw.\nhttps:\/\/t.co\/HfgmmXKdBv",
    "id" : 752399012280557568,
    "created_at" : "2016-07-11 07:07:58 +0000",
    "user" : {
      "name" : "Bj\u00F6rn Gr\u00FCning",
      "screen_name" : "bjoerngruening",
      "protected" : false,
      "id_str" : "117360280",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531467432129339392\/LZIyviBa_normal.jpeg",
      "id" : 117360280,
      "verified" : false
    }
  },
  "id" : 752520250973941764,
  "created_at" : "2016-07-11 15:09:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "F\u00FCxin",
      "screen_name" : "foxeen",
      "indices" : [ 0, 7 ],
      "id_str" : "46904555",
      "id" : 46904555
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "752517865958506496",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 28.36602820467106, -81.55916274339707 ]
  },
  "id_str" : "752518478234587136",
  "in_reply_to_user_id" : 46904555,
  "text" : "@foxeen yep. PDX is Portland, took the picture of the carpet there in April. :)",
  "id" : 752518478234587136,
  "in_reply_to_status_id" : 752517865958506496,
  "created_at" : "2016-07-11 15:02:40 +0000",
  "in_reply_to_screen_name" : "foxeen",
  "in_reply_to_user_id_str" : "46904555",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "F\u00FCxin",
      "screen_name" : "foxeen",
      "indices" : [ 0, 7 ],
      "id_str" : "46904555",
      "id" : 46904555
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 28.3659874220106, -81.55911039568211 ]
  },
  "id_str" : "752516606182453248",
  "in_reply_to_user_id" : 46904555,
  "text" : "@foxeen yes, even though it\u2019s a hotel room floor. But the same environment when it comes to the beating they have to take.",
  "id" : 752516606182453248,
  "created_at" : "2016-07-11 14:55:14 +0000",
  "in_reply_to_screen_name" : "foxeen",
  "in_reply_to_user_id_str" : "46904555",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "F\u00FCxin",
      "screen_name" : "foxeen",
      "indices" : [ 0, 7 ],
      "id_str" : "46904555",
      "id" : 46904555
    }, {
      "name" : "Minaal",
      "screen_name" : "minaal",
      "indices" : [ 8, 15 ],
      "id_str" : "246624621",
      "id" : 246624621
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 56 ],
      "url" : "https:\/\/t.co\/vzVoWCi2Ga",
      "expanded_url" : "https:\/\/instagram.com\/p\/BESK_iZBwux\/",
      "display_url" : "instagram.com\/p\/BESK_iZBwux\/"
    } ]
  },
  "in_reply_to_status_id_str" : "752514684260126720",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 28.36637177999515, -81.55880950944459 ]
  },
  "id_str" : "752515047323267072",
  "in_reply_to_user_id" : 46904555,
  "text" : "@foxeen @minaal nope, that\u2019s PDX https:\/\/t.co\/vzVoWCi2Ga",
  "id" : 752515047323267072,
  "in_reply_to_status_id" : 752514684260126720,
  "created_at" : "2016-07-11 14:49:02 +0000",
  "in_reply_to_screen_name" : "foxeen",
  "in_reply_to_user_id_str" : "46904555",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Minaal",
      "screen_name" : "minaal",
      "indices" : [ 67, 74 ],
      "id_str" : "246624621",
      "id" : 246624621
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/752514110366093313\/photo\/1",
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/Os81L1mXNu",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CnF3mB3WEAA2K2k.jpg",
      "id_str" : "752514107966885888",
      "id" : 752514107966885888,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CnF3mB3WEAA2K2k.jpg",
      "sizes" : [ {
        "h" : 1129,
        "resize" : "fit",
        "w" : 847
      }, {
        "h" : 1129,
        "resize" : "fit",
        "w" : 847
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1129,
        "resize" : "fit",
        "w" : 847
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      } ],
      "display_url" : "pic.twitter.com\/Os81L1mXNu"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "752514110366093313",
  "text" : "Not sure how, but again I managed to get everything stuffed in the @minaal. For the last time (well, until Friday) https:\/\/t.co\/Os81L1mXNu",
  "id" : 752514110366093313,
  "created_at" : "2016-07-11 14:45:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 28.36588630737502, -81.55994128762455 ]
  },
  "id_str" : "752493565662691329",
  "text" : "Now: Some \uD83C\uDFCA before heading to the next pair of \u2708\uFE0Fs.",
  "id" : 752493565662691329,
  "created_at" : "2016-07-11 13:23:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 77 ],
      "url" : "https:\/\/t.co\/PfT5eG2iFo",
      "expanded_url" : "https:\/\/twitter.com\/monimunozto\/status\/752373109987180545",
      "display_url" : "twitter.com\/monimunozto\/st\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 28.36608938151634, -81.55904136560622 ]
  },
  "id_str" : "752407741600268288",
  "text" : "wtf?! Thanks for standing up against such prejudices! https:\/\/t.co\/PfT5eG2iFo",
  "id" : 752407741600268288,
  "created_at" : "2016-07-11 07:42:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Abby Cabunoc Mayes",
      "screen_name" : "abbycabs",
      "indices" : [ 0, 9 ],
      "id_str" : "395367768",
      "id" : 395367768
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "752269099082850304",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 28.3668361873478, -81.56028543182096 ]
  },
  "id_str" : "752277449795309569",
  "in_reply_to_user_id" : 395367768,
  "text" : "@abbycabs thanks for the fun tour in Downtown Disney!",
  "id" : 752277449795309569,
  "in_reply_to_status_id" : 752269099082850304,
  "created_at" : "2016-07-10 23:04:55 +0000",
  "in_reply_to_screen_name" : "abbycabs",
  "in_reply_to_user_id_str" : "395367768",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bi\u24D0nca Kramer",
      "screen_name" : "MsPhelps",
      "indices" : [ 0, 9 ],
      "id_str" : "22963112",
      "id" : 22963112
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "752255452310798336",
  "geo" : { },
  "id_str" : "752257609919520768",
  "in_reply_to_user_id" : 22963112,
  "text" : "@MsPhelps as i said, it\u2019s the very lazy solution ;)",
  "id" : 752257609919520768,
  "in_reply_to_status_id" : 752255452310798336,
  "created_at" : "2016-07-10 21:46:05 +0000",
  "in_reply_to_screen_name" : "MsPhelps",
  "in_reply_to_user_id_str" : "22963112",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bi\u24D0nca Kramer",
      "screen_name" : "MsPhelps",
      "indices" : [ 0, 9 ],
      "id_str" : "22963112",
      "id" : 22963112
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "752253800325537796",
  "geo" : { },
  "id_str" : "752254606936334336",
  "in_reply_to_user_id" : 22963112,
  "text" : "@MsPhelps for getting the null distribution just the # of answers so you can get a random draw.",
  "id" : 752254606936334336,
  "in_reply_to_status_id" : 752253800325537796,
  "created_at" : "2016-07-10 21:34:09 +0000",
  "in_reply_to_screen_name" : "MsPhelps",
  "in_reply_to_user_id_str" : "22963112",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bi\u24D0nca Kramer",
      "screen_name" : "MsPhelps",
      "indices" : [ 0, 9 ],
      "id_str" : "22963112",
      "id" : 22963112
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "752252350115512320",
  "geo" : { },
  "id_str" : "752252694254026754",
  "in_reply_to_user_id" : 22963112,
  "text" : "@MsPhelps \u2026you can just compare observed co-occ to random draw and see whether in simulated 95% or not.",
  "id" : 752252694254026754,
  "in_reply_to_status_id" : 752252350115512320,
  "created_at" : "2016-07-10 21:26:33 +0000",
  "in_reply_to_screen_name" : "MsPhelps",
  "in_reply_to_user_id_str" : "22963112",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bi\u24D0nca Kramer",
      "screen_name" : "MsPhelps",
      "indices" : [ 0, 9 ],
      "id_str" : "22963112",
      "id" : 22963112
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "752252350115512320",
  "geo" : { },
  "id_str" : "752252593120960512",
  "in_reply_to_user_id" : 22963112,
  "text" : "@MsPhelps that\u2019s why i\u2019d go the easy way: randomly draw according to observed # of answers and then see co-occ distribution. that way\u2026",
  "id" : 752252593120960512,
  "in_reply_to_status_id" : 752252350115512320,
  "created_at" : "2016-07-10 21:26:09 +0000",
  "in_reply_to_screen_name" : "MsPhelps",
  "in_reply_to_user_id_str" : "22963112",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bi\u24D0nca Kramer",
      "screen_name" : "MsPhelps",
      "indices" : [ 0, 9 ],
      "id_str" : "22963112",
      "id" : 22963112
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "752248668703580160",
  "geo" : { },
  "id_str" : "752249496726302724",
  "in_reply_to_user_id" : 22963112,
  "text" : "@MsPhelps maybe get a null distribution of co-occurrences by simulating random draw using the observed # of answers distribution?",
  "id" : 752249496726302724,
  "in_reply_to_status_id" : 752248668703580160,
  "created_at" : "2016-07-10 21:13:50 +0000",
  "in_reply_to_screen_name" : "MsPhelps",
  "in_reply_to_user_id_str" : "22963112",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bi\u24D0nca Kramer",
      "screen_name" : "MsPhelps",
      "indices" : [ 0, 9 ],
      "id_str" : "22963112",
      "id" : 22963112
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "752248423563325440",
  "geo" : { },
  "id_str" : "752248466882064384",
  "in_reply_to_user_id" : 22963112,
  "text" : "@MsPhelps if i remember correctly",
  "id" : 752248466882064384,
  "in_reply_to_status_id" : 752248423563325440,
  "created_at" : "2016-07-10 21:09:45 +0000",
  "in_reply_to_screen_name" : "MsPhelps",
  "in_reply_to_user_id_str" : "22963112",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bi\u24D0nca Kramer",
      "screen_name" : "MsPhelps",
      "indices" : [ 0, 9 ],
      "id_str" : "22963112",
      "id" : 22963112
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "752247455161446401",
  "geo" : { },
  "id_str" : "752248224237383686",
  "in_reply_to_user_id" : 22963112,
  "text" : "@MsPhelps yes, not that easy, because iirc # of answers can vary, right?",
  "id" : 752248224237383686,
  "in_reply_to_status_id" : 752247455161446401,
  "created_at" : "2016-07-10 21:08:47 +0000",
  "in_reply_to_screen_name" : "MsPhelps",
  "in_reply_to_user_id_str" : "22963112",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bi\u24D0nca Kramer",
      "screen_name" : "MsPhelps",
      "indices" : [ 0, 9 ],
      "id_str" : "22963112",
      "id" : 22963112
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "752246395827064833",
  "geo" : { },
  "id_str" : "752246690028060672",
  "in_reply_to_user_id" : 22963112,
  "text" : "@MsPhelps sure, I\u2019ll fly back to old Europe tomorrow, so graphing stuff to do for the flight might be fun ;)",
  "id" : 752246690028060672,
  "in_reply_to_status_id" : 752246395827064833,
  "created_at" : "2016-07-10 21:02:41 +0000",
  "in_reply_to_screen_name" : "MsPhelps",
  "in_reply_to_user_id_str" : "22963112",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bi\u24D0nca Kramer",
      "screen_name" : "MsPhelps",
      "indices" : [ 0, 9 ],
      "id_str" : "22963112",
      "id" : 22963112
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 84 ],
      "url" : "https:\/\/t.co\/VnlLMiCXWu",
      "expanded_url" : "https:\/\/learnr.wordpress.com\/2010\/01\/26\/ggplot2-quick-heatmap-plotting\/",
      "display_url" : "learnr.wordpress.com\/2010\/01\/26\/ggp\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "752245204099399680",
  "geo" : { },
  "id_str" : "752246258115420160",
  "in_reply_to_user_id" : 22963112,
  "text" : "@MsPhelps a very simple tutorial for R + ggplot2 is this one https:\/\/t.co\/VnlLMiCXWu",
  "id" : 752246258115420160,
  "in_reply_to_status_id" : 752245204099399680,
  "created_at" : "2016-07-10 21:00:58 +0000",
  "in_reply_to_screen_name" : "MsPhelps",
  "in_reply_to_user_id_str" : "22963112",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bi\u24D0nca Kramer",
      "screen_name" : "MsPhelps",
      "indices" : [ 0, 9 ],
      "id_str" : "22963112",
      "id" : 22963112
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "752245204099399680",
  "geo" : { },
  "id_str" : "752246144009404422",
  "in_reply_to_user_id" : 22963112,
  "text" : "@MsPhelps yes, have done tons of those with R :)",
  "id" : 752246144009404422,
  "in_reply_to_status_id" : 752245204099399680,
  "created_at" : "2016-07-10 21:00:31 +0000",
  "in_reply_to_screen_name" : "MsPhelps",
  "in_reply_to_user_id_str" : "22963112",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bi\u24D0nca Kramer",
      "screen_name" : "MsPhelps",
      "indices" : [ 0, 9 ],
      "id_str" : "22963112",
      "id" : 22963112
    }, {
      "name" : "Abby Cabunoc Mayes",
      "screen_name" : "abbycabs",
      "indices" : [ 10, 19 ],
      "id_str" : "395367768",
      "id" : 395367768
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "752243129873465351",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 28.36624630352752, -81.55893039940229 ]
  },
  "id_str" : "752243442781155329",
  "in_reply_to_user_id" : 22963112,
  "text" : "@MsPhelps @abbycabs I tried getting one to send with the tweet but the glitter evades being photographed. Looks like dandruff when tying. ;)",
  "id" : 752243442781155329,
  "in_reply_to_status_id" : 752243129873465351,
  "created_at" : "2016-07-10 20:49:47 +0000",
  "in_reply_to_screen_name" : "MsPhelps",
  "in_reply_to_user_id_str" : "22963112",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Abby Cabunoc Mayes",
      "screen_name" : "abbycabs",
      "indices" : [ 30, 39 ],
      "id_str" : "395367768",
      "id" : 395367768
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 28.36611797118231, -81.5590450102354 ]
  },
  "id_str" : "752239070194065409",
  "text" : "I went to Disney Springs with @abbycabs and now I have fairy dust-glitter all over my hair! \uD83C\uDF89\uD83D\uDC51",
  "id" : 752239070194065409,
  "created_at" : "2016-07-10 20:32:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael R. Crusoe",
      "screen_name" : "biocrusoe",
      "indices" : [ 3, 13 ],
      "id_str" : "17645638",
      "id" : 17645638
    }, {
      "name" : "Monica Munoz-Torres",
      "screen_name" : "monimunozto",
      "indices" : [ 85, 97 ],
      "id_str" : "538714687",
      "id" : 538714687
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ISMB16",
      "indices" : [ 25, 32 ]
    }, {
      "text" : "PulseShooting",
      "indices" : [ 55, 69 ]
    }, {
      "text" : "BOSC2016",
      "indices" : [ 109, 118 ]
    }, {
      "text" : "LGBTinSTEM",
      "indices" : [ 120, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "752196023565647872",
  "text" : "RT @biocrusoe: Thank you #ISMB16 for acknowledging the #PulseShooting. Not pictured: @monimunozto tribute at #BOSC2016. #LGBTinSTEM https:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Monica Munoz-Torres",
        "screen_name" : "monimunozto",
        "indices" : [ 70, 82 ],
        "id_str" : "538714687",
        "id" : 538714687
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/biocrusoe\/status\/752135013483810816\/photo\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/HlwSFAU2VL",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CnAeyS5XEAAoDLm.jpg",
        "id_str" : "752134987185590272",
        "id" : 752134987185590272,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CnAeyS5XEAAoDLm.jpg",
        "sizes" : [ {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1537,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 1560,
          "resize" : "fit",
          "w" : 2079
        }, {
          "h" : 900,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/HlwSFAU2VL"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/biocrusoe\/status\/752135013483810816\/photo\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/HlwSFAU2VL",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CnAezExWIAAhfvM.jpg",
        "id_str" : "752135000573747200",
        "id" : 752135000573747200,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CnAezExWIAAhfvM.jpg",
        "sizes" : [ {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1560,
          "resize" : "fit",
          "w" : 2080
        }, {
          "h" : 900,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/HlwSFAU2VL"
      } ],
      "hashtags" : [ {
        "text" : "ISMB16",
        "indices" : [ 10, 17 ]
      }, {
        "text" : "PulseShooting",
        "indices" : [ 40, 54 ]
      }, {
        "text" : "BOSC2016",
        "indices" : [ 94, 103 ]
      }, {
        "text" : "LGBTinSTEM",
        "indices" : [ 105, 116 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "752135013483810816",
    "text" : "Thank you #ISMB16 for acknowledging the #PulseShooting. Not pictured: @monimunozto tribute at #BOSC2016. #LGBTinSTEM https:\/\/t.co\/HlwSFAU2VL",
    "id" : 752135013483810816,
    "created_at" : "2016-07-10 13:38:55 +0000",
    "user" : {
      "name" : "Michael R. Crusoe",
      "screen_name" : "biocrusoe",
      "protected" : false,
      "id_str" : "17645638",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/485998749311721472\/0yX4CFRV_normal.jpeg",
      "id" : 17645638,
      "verified" : false
    }
  },
  "id" : 752196023565647872,
  "created_at" : "2016-07-10 17:41:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Cock",
      "screen_name" : "pjacock",
      "indices" : [ 7, 15 ],
      "id_str" : "58756672",
      "id" : 58756672
    }, {
      "name" : "Nomi Harris",
      "screen_name" : "NomiHarris",
      "indices" : [ 16, 27 ],
      "id_str" : "351049850",
      "id" : 351049850
    }, {
      "name" : "Heather L. Wiencko",
      "screen_name" : "HLWiencko",
      "indices" : [ 28, 38 ],
      "id_str" : "2657942712",
      "id" : 2657942712
    }, {
      "name" : "Hilmar Lapp",
      "screen_name" : "hlapp",
      "indices" : [ 39, 45 ],
      "id_str" : "19042414",
      "id" : 19042414
    }, {
      "name" : "Chris Fields",
      "screen_name" : "cjfields",
      "indices" : [ 46, 55 ],
      "id_str" : "14365634",
      "id" : 14365634
    }, {
      "name" : "Monica Munoz-Torres",
      "screen_name" : "monimunozto",
      "indices" : [ 56, 68 ],
      "id_str" : "538714687",
      "id" : 538714687
    }, {
      "name" : "Brad Chapman",
      "screen_name" : "chapmanb",
      "indices" : [ 69, 78 ],
      "id_str" : "18284047",
      "id" : 18284047
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bosc2016",
      "indices" : [ 90, 99 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 28.36583734169588, -81.5598247918069 ]
  },
  "id_str" : "752144469760368641",
  "text" : "Thanks @pjacock @NomiHarris @HLWiencko @hlapp @cjfields @monimunozto @chapmanb for making #bosc2016, again one of my favorite conferences!",
  "id" : 752144469760368641,
  "created_at" : "2016-07-10 14:16:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 78 ],
      "url" : "https:\/\/t.co\/xlpmek8JYD",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BHrtSM2jYoQ\/",
      "display_url" : "instagram.com\/p\/BHrtSM2jYoQ\/"
    } ]
  },
  "geo" : { },
  "id_str" : "752135048518860804",
  "text" : "Welcome to the Disney arcology, where evil corps rule. https:\/\/t.co\/xlpmek8JYD",
  "id" : 752135048518860804,
  "created_at" : "2016-07-10 13:39:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shaun Jackman",
      "screen_name" : "sjackman",
      "indices" : [ 0, 9 ],
      "id_str" : "8779352",
      "id" : 8779352
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "752026964249182209",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 28.36629404768279, -81.55900633557556 ]
  },
  "id_str" : "752116438203244544",
  "in_reply_to_user_id" : 8779352,
  "text" : "@sjackman finally an avatar that allows to recognize you at conferences :p",
  "id" : 752116438203244544,
  "in_reply_to_status_id" : 752026964249182209,
  "created_at" : "2016-07-10 12:25:07 +0000",
  "in_reply_to_screen_name" : "sjackman",
  "in_reply_to_user_id_str" : "8779352",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Atossa Araxia Abrahamian",
      "screen_name" : "atossaaraxia",
      "indices" : [ 3, 16 ],
      "id_str" : "228437800",
      "id" : 228437800
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/Ysv0coC7pv",
      "expanded_url" : "http:\/\/nyti.ms\/29ussqS",
      "display_url" : "nyti.ms\/29ussqS"
    } ]
  },
  "geo" : { },
  "id_str" : "751978096946020353",
  "text" : "RT @atossaaraxia: A Central Conflict of 21st-Century Politics: Who Belongs? https:\/\/t.co\/Ysv0coC7pv",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 58, 81 ],
        "url" : "https:\/\/t.co\/Ysv0coC7pv",
        "expanded_url" : "http:\/\/nyti.ms\/29ussqS",
        "display_url" : "nyti.ms\/29ussqS"
      } ]
    },
    "geo" : { },
    "id_str" : "751891425558757376",
    "text" : "A Central Conflict of 21st-Century Politics: Who Belongs? https:\/\/t.co\/Ysv0coC7pv",
    "id" : 751891425558757376,
    "created_at" : "2016-07-09 21:30:59 +0000",
    "user" : {
      "name" : "Atossa Araxia Abrahamian",
      "screen_name" : "atossaaraxia",
      "protected" : false,
      "id_str" : "228437800",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/707884522738728960\/VqnZwF27_normal.jpg",
      "id" : 228437800,
      "verified" : true
    }
  },
  "id" : 751978096946020353,
  "created_at" : "2016-07-10 03:15:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bosc2016",
      "indices" : [ 101, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/tWEgSHoApr",
      "expanded_url" : "https:\/\/twitter.com\/vivek_ziel\/status\/751880254923374592",
      "display_url" : "twitter.com\/vivek_ziel\/sta\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 28.36625946718909, -81.55903856332876 ]
  },
  "id_str" : "751975785418919936",
  "text" : "Just in time to be introduced as one of our GSoC students! Fun to meet in person for the first time! #bosc2016 https:\/\/t.co\/tWEgSHoApr",
  "id" : 751975785418919936,
  "created_at" : "2016-07-10 03:06:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Abby Cabunoc Mayes",
      "screen_name" : "abbycabs",
      "indices" : [ 0, 9 ],
      "id_str" : "395367768",
      "id" : 395367768
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "751939848727105536",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 28.43226447018817, -81.47050472294286 ]
  },
  "id_str" : "751941397926805504",
  "in_reply_to_user_id" : 395367768,
  "text" : "@abbycabs how funny. Should meet up tomorrow if he likes.",
  "id" : 751941397926805504,
  "in_reply_to_status_id" : 751939848727105536,
  "created_at" : "2016-07-10 00:49:34 +0000",
  "in_reply_to_screen_name" : "abbycabs",
  "in_reply_to_user_id_str" : "395367768",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bosc2016",
      "indices" : [ 106, 115 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "751875996794626049",
  "geo" : { },
  "id_str" : "751877187050037248",
  "in_reply_to_user_id" : 14286491,
  "text" : "I can only recommend going to Mozfest. A great and fun way to get in touch with the larger OSS community. #bosc2016",
  "id" : 751877187050037248,
  "in_reply_to_status_id" : 751875996794626049,
  "created_at" : "2016-07-09 20:34:25 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bosc2016",
      "indices" : [ 78, 87 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "751854013264564224",
  "geo" : { },
  "id_str" : "751875996794626049",
  "in_reply_to_user_id" : 14286491,
  "text" : "There are still a couple of openSNP stickers left. Catch me if you want some! #bosc2016",
  "id" : 751875996794626049,
  "in_reply_to_status_id" : 751854013264564224,
  "created_at" : "2016-07-09 20:29:41 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Cock",
      "screen_name" : "pjacock",
      "indices" : [ 0, 8 ],
      "id_str" : "58756672",
      "id" : 58756672
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "751874522748448768",
  "geo" : { },
  "id_str" : "751874786985406465",
  "in_reply_to_user_id" : 58756672,
  "text" : "@pjacock great, forwarded to the person in Q. :)",
  "id" : 751874786985406465,
  "in_reply_to_status_id" : 751874522748448768,
  "created_at" : "2016-07-09 20:24:53 +0000",
  "in_reply_to_screen_name" : "pjacock",
  "in_reply_to_user_id_str" : "58756672",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shaun Jackman",
      "screen_name" : "sjackman",
      "indices" : [ 0, 9 ],
      "id_str" : "8779352",
      "id" : 8779352
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "751856401178329088",
  "geo" : { },
  "id_str" : "751871016255774720",
  "in_reply_to_user_id" : 8779352,
  "text" : "@sjackman awesome!",
  "id" : 751871016255774720,
  "in_reply_to_status_id" : 751856401178329088,
  "created_at" : "2016-07-09 20:09:54 +0000",
  "in_reply_to_screen_name" : "sjackman",
  "in_reply_to_user_id_str" : "8779352",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Cock",
      "screen_name" : "pjacock",
      "indices" : [ 0, 8 ],
      "id_str" : "58756672",
      "id" : 58756672
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "751870947053932544",
  "in_reply_to_user_id" : 58756672,
  "text" : "@pjacock do you know whether there\u2019s still place for the dinner tonight?",
  "id" : 751870947053932544,
  "created_at" : "2016-07-09 20:09:37 +0000",
  "in_reply_to_screen_name" : "pjacock",
  "in_reply_to_user_id_str" : "58756672",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GigaScience",
      "screen_name" : "GigaScience",
      "indices" : [ 0, 12 ],
      "id_str" : "208988759",
      "id" : 208988759
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "751854392526110721",
  "geo" : { },
  "id_str" : "751854578279313408",
  "in_reply_to_user_id" : 208988759,
  "text" : "@GigaScience sweet, but then it\u2019s not fully automated but needs regular re-upload, right?",
  "id" : 751854578279313408,
  "in_reply_to_status_id" : 751854392526110721,
  "created_at" : "2016-07-09 19:04:34 +0000",
  "in_reply_to_screen_name" : "GigaScience",
  "in_reply_to_user_id_str" : "208988759",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jan Aerts",
      "screen_name" : "jandot",
      "indices" : [ 0, 7 ],
      "id_str" : "14000542",
      "id" : 14000542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "751853153017028612",
  "geo" : { },
  "id_str" : "751854443990319104",
  "in_reply_to_user_id" : 14000542,
  "text" : "@jandot thanks so much!",
  "id" : 751854443990319104,
  "in_reply_to_status_id" : 751853153017028612,
  "created_at" : "2016-07-09 19:04:02 +0000",
  "in_reply_to_screen_name" : "jandot",
  "in_reply_to_user_id_str" : "14000542",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bosc2016",
      "indices" : [ 80, 89 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "751854013264564224",
  "geo" : { },
  "id_str" : "751854179367485440",
  "in_reply_to_user_id" : 14286491,
  "text" : "Even see great intra-group mentoring amongst our GSoC students, awesome to see. #bosc2016",
  "id" : 751854179367485440,
  "in_reply_to_status_id" : 751854013264564224,
  "created_at" : "2016-07-09 19:02:59 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bosc2016",
      "indices" : [ 78, 87 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/4cxE1sQort",
      "expanded_url" : "https:\/\/twitter.com\/cjfields\/status\/751851316398460928",
      "display_url" : "twitter.com\/cjfields\/statu\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "751853468579684352",
  "geo" : { },
  "id_str" : "751854013264564224",
  "in_reply_to_user_id" : 14286491,
  "text" : "Forgot to mention: GSoC a great way to mentor newcomers and foster community. #bosc2016 https:\/\/t.co\/4cxE1sQort",
  "id" : 751854013264564224,
  "in_reply_to_status_id" : 751853468579684352,
  "created_at" : "2016-07-09 19:02:20 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Biopython Project",
      "screen_name" : "Biopython",
      "indices" : [ 14, 24 ],
      "id_str" : "26723969",
      "id" : 26723969
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bosc2016",
      "indices" : [ 82, 91 ]
    } ],
    "urls" : [ {
      "indices" : [ 58, 81 ],
      "url" : "https:\/\/t.co\/Cj8u2tdwal",
      "expanded_url" : "https:\/\/www.openhub.net\/p\/openSNP",
      "display_url" : "openhub.net\/p\/openSNP"
    } ]
  },
  "in_reply_to_status_id_str" : "751853216980172800",
  "geo" : { },
  "id_str" : "751853468579684352",
  "in_reply_to_user_id" : 14286491,
  "text" : "Following the @Biopython talk I added openSNP to openhub: https:\/\/t.co\/Cj8u2tdwal #bosc2016",
  "id" : 751853468579684352,
  "in_reply_to_status_id" : 751853216980172800,
  "created_at" : "2016-07-09 19:00:10 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bosc2016",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "751840615386714114",
  "geo" : { },
  "id_str" : "751853216980172800",
  "in_reply_to_user_id" : 14286491,
  "text" : "Yes, the real reason I needed my own machine were the animated GIFs. #bosc2016",
  "id" : 751853216980172800,
  "in_reply_to_status_id" : 751840615386714114,
  "created_at" : "2016-07-09 18:59:10 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Heather L. Wiencko",
      "screen_name" : "HLWiencko",
      "indices" : [ 3, 13 ],
      "id_str" : "2657942712",
      "id" : 2657942712
    }, {
      "name" : "openSNP team",
      "screen_name" : "openSNPorg",
      "indices" : [ 16, 27 ],
      "id_str" : "380205172",
      "id" : 380205172
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BOSC2016",
      "indices" : [ 128, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "751853063225405440",
  "text" : "RT @HLWiencko: .@openSNPorg totally tracks text editor preferences. I would *love* to see if preference for vi(m) is heritable. #BOSC2016",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "openSNP team",
        "screen_name" : "openSNPorg",
        "indices" : [ 1, 12 ],
        "id_str" : "380205172",
        "id" : 380205172
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BOSC2016",
        "indices" : [ 113, 122 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "751849139219075072",
    "text" : ".@openSNPorg totally tracks text editor preferences. I would *love* to see if preference for vi(m) is heritable. #BOSC2016",
    "id" : 751849139219075072,
    "created_at" : "2016-07-09 18:42:58 +0000",
    "user" : {
      "name" : "Heather L. Wiencko",
      "screen_name" : "HLWiencko",
      "protected" : false,
      "id_str" : "2657942712",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/490274907117215746\/GBit7UNq_normal.jpeg",
      "id" : 2657942712,
      "verified" : false
    }
  },
  "id" : 751853063225405440,
  "created_at" : "2016-07-09 18:58:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Abby Cabunoc Mayes",
      "screen_name" : "abbycabs",
      "indices" : [ 0, 9 ],
      "id_str" : "395367768",
      "id" : 395367768
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 58, 71 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "751851233854488576",
  "geo" : { },
  "id_str" : "751852942521761792",
  "in_reply_to_user_id" : 395367768,
  "text" : "@abbycabs thanks for all the hours you put into mentoring @PhilippBayer and me!",
  "id" : 751852942521761792,
  "in_reply_to_status_id" : 751851233854488576,
  "created_at" : "2016-07-09 18:58:04 +0000",
  "in_reply_to_screen_name" : "abbycabs",
  "in_reply_to_user_id_str" : "395367768",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GigaScience",
      "screen_name" : "GigaScience",
      "indices" : [ 0, 12 ],
      "id_str" : "208988759",
      "id" : 208988759
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "751851361092898816",
  "geo" : { },
  "id_str" : "751852880580186116",
  "in_reply_to_user_id" : 208988759,
  "text" : "@GigaScience oh, I didn\u2019t know Pebble by now does some QS too. Is there a good way to export it already?",
  "id" : 751852880580186116,
  "in_reply_to_status_id" : 751851361092898816,
  "created_at" : "2016-07-09 18:57:50 +0000",
  "in_reply_to_screen_name" : "GigaScience",
  "in_reply_to_user_id_str" : "208988759",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Abby Cabunoc Mayes",
      "screen_name" : "abbycabs",
      "indices" : [ 3, 12 ],
      "id_str" : "395367768",
      "id" : 395367768
    }, {
      "name" : "Mozilla Science Lab",
      "screen_name" : "MozillaScience",
      "indices" : [ 26, 41 ],
      "id_str" : "1428575976",
      "id" : 1428575976
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 52, 68 ],
      "id_str" : "14286491",
      "id" : 14286491
    }, {
      "name" : "openSNP team",
      "screen_name" : "openSNPorg",
      "indices" : [ 70, 81 ],
      "id_str" : "380205172",
      "id" : 380205172
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "751852812758355968",
  "text" : "RT @abbycabs: Thx for the @MozillaScience shoutout, @gedankenstuecke! @openSNPorg is a gr8 project, glad you got more ppl involved https:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Mozilla Science Lab",
        "screen_name" : "MozillaScience",
        "indices" : [ 12, 27 ],
        "id_str" : "1428575976",
        "id" : 1428575976
      }, {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 38, 54 ],
        "id_str" : "14286491",
        "id" : 14286491
      }, {
        "name" : "openSNP team",
        "screen_name" : "openSNPorg",
        "indices" : [ 56, 67 ],
        "id_str" : "380205172",
        "id" : 380205172
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/abbycabs\/status\/751851233854488576\/photo\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/iNgEX6gmEM",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cm8ctNZWYAQLBgW.jpg",
        "id_str" : "751851225809838084",
        "id" : 751851225809838084,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cm8ctNZWYAQLBgW.jpg",
        "sizes" : [ {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 900,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/iNgEX6gmEM"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "751851233854488576",
    "text" : "Thx for the @MozillaScience shoutout, @gedankenstuecke! @openSNPorg is a gr8 project, glad you got more ppl involved https:\/\/t.co\/iNgEX6gmEM",
    "id" : 751851233854488576,
    "created_at" : "2016-07-09 18:51:17 +0000",
    "user" : {
      "name" : "Abby Cabunoc Mayes",
      "screen_name" : "abbycabs",
      "protected" : false,
      "id_str" : "395367768",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/789110152070823938\/O_ena-j7_normal.jpg",
      "id" : 395367768,
      "verified" : false
    }
  },
  "id" : 751852812758355968,
  "created_at" : "2016-07-09 18:57:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Abby Cabunoc Mayes",
      "screen_name" : "abbycabs",
      "indices" : [ 3, 12 ],
      "id_str" : "395367768",
      "id" : 395367768
    }, {
      "name" : "openSNP team",
      "screen_name" : "openSNPorg",
      "indices" : [ 27, 38 ],
      "id_str" : "380205172",
      "id" : 380205172
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 51, 67 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/abbycabs\/status\/751848753062117376\/photo\/1",
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/qG6sQeam8l",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cm8acdQXgAAD8ER.jpg",
      "id_str" : "751848738986098688",
      "id" : 751848738986098688,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cm8acdQXgAAD8ER.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/qG6sQeam8l"
    } ],
    "hashtags" : [ {
      "text" : "BOSC2016",
      "indices" : [ 76, 85 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "751852768382640128",
  "text" : "RT @abbycabs: State of the @openSNPorg Union! From @gedankenstuecke himself #BOSC2016 https:\/\/t.co\/qG6sQeam8l",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "openSNP team",
        "screen_name" : "openSNPorg",
        "indices" : [ 13, 24 ],
        "id_str" : "380205172",
        "id" : 380205172
      }, {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 37, 53 ],
        "id_str" : "14286491",
        "id" : 14286491
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/abbycabs\/status\/751848753062117376\/photo\/1",
        "indices" : [ 72, 95 ],
        "url" : "https:\/\/t.co\/qG6sQeam8l",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cm8acdQXgAAD8ER.jpg",
        "id_str" : "751848738986098688",
        "id" : 751848738986098688,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cm8acdQXgAAD8ER.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/qG6sQeam8l"
      } ],
      "hashtags" : [ {
        "text" : "BOSC2016",
        "indices" : [ 62, 71 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "751848753062117376",
    "text" : "State of the @openSNPorg Union! From @gedankenstuecke himself #BOSC2016 https:\/\/t.co\/qG6sQeam8l",
    "id" : 751848753062117376,
    "created_at" : "2016-07-09 18:41:26 +0000",
    "user" : {
      "name" : "Abby Cabunoc Mayes",
      "screen_name" : "abbycabs",
      "protected" : false,
      "id_str" : "395367768",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/789110152070823938\/O_ena-j7_normal.jpg",
      "id" : 395367768,
      "verified" : false
    }
  },
  "id" : 751852768382640128,
  "created_at" : "2016-07-09 18:57:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bosc2016",
      "indices" : [ 85, 94 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "751807972888678400",
  "geo" : { },
  "id_str" : "751840615386714114",
  "in_reply_to_user_id" : 14286491,
  "text" : "I can\u2019t iterate it enough: Biopython is one of the main reasons that I\u2019m here today. #bosc2016",
  "id" : 751840615386714114,
  "in_reply_to_status_id" : 751807972888678400,
  "created_at" : "2016-07-09 18:09:05 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Knudsen",
      "screen_name" : "micknudsen",
      "indices" : [ 0, 11 ],
      "id_str" : "586384665",
      "id" : 586384665
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "751812766395146240",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 28.36467082607542, -81.55913456598996 ]
  },
  "id_str" : "751813672159285248",
  "in_reply_to_user_id" : 586384665,
  "text" : "@micknudsen yes and yes.",
  "id" : 751813672159285248,
  "in_reply_to_status_id" : 751812766395146240,
  "created_at" : "2016-07-09 16:22:02 +0000",
  "in_reply_to_screen_name" : "micknudsen",
  "in_reply_to_user_id_str" : "586384665",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lorena Pantano",
      "screen_name" : "lopantano",
      "indices" : [ 0, 10 ],
      "id_str" : "91131784",
      "id" : 91131784
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "751811028451749888",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 28.36467249454507, -81.55910867918699 ]
  },
  "id_str" : "751811934350114817",
  "in_reply_to_user_id" : 91131784,
  "text" : "@lopantano will do! At least one person is working on orthology inference for miRNAs if that\u2019s of interest.",
  "id" : 751811934350114817,
  "in_reply_to_status_id" : 751811028451749888,
  "created_at" : "2016-07-09 16:15:07 +0000",
  "in_reply_to_screen_name" : "lopantano",
  "in_reply_to_user_id_str" : "91131784",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lorena Pantano",
      "screen_name" : "lopantano",
      "indices" : [ 14, 24 ],
      "id_str" : "91131784",
      "id" : 91131784
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bosc2016",
      "indices" : [ 93, 102 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "751800757180129280",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 28.36465532316956, -81.55917080324312 ]
  },
  "id_str" : "751807972888678400",
  "in_reply_to_user_id" : 14286491,
  "text" : "Great talk by @lopantano. Send all the links immediately to my colleagues working w\/ miRNAs. #bosc2016",
  "id" : 751807972888678400,
  "in_reply_to_status_id" : 751800757180129280,
  "created_at" : "2016-07-09 15:59:23 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Cock",
      "screen_name" : "pjacock",
      "indices" : [ 3, 11 ],
      "id_str" : "58756672",
      "id" : 58756672
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BOSC2016",
      "indices" : [ 35, 44 ]
    }, {
      "text" : "opensource",
      "indices" : [ 46, 57 ]
    }, {
      "text" : "blackbox",
      "indices" : [ 70, 79 ]
    }, {
      "text" : "raspberrypi",
      "indices" : [ 112, 124 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "751805745423847424",
  "text" : "RT @pjacock: Lorena Pantano Rubino #BOSC2016: #opensource opposite of #blackbox, illustrated with rainbow pibow #raspberrypi case https:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/pjacock\/status\/751805537864519680\/photo\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/Gx9DjcFAIz",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cm7zB8XWAAQ9CRk.jpg",
        "id_str" : "751805402526908420",
        "id" : 751805402526908420,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cm7zB8XWAAQ9CRk.jpg",
        "sizes" : [ {
          "h" : 3024,
          "resize" : "fit",
          "w" : 4032
        }, {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 900,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/Gx9DjcFAIz"
      } ],
      "hashtags" : [ {
        "text" : "BOSC2016",
        "indices" : [ 22, 31 ]
      }, {
        "text" : "opensource",
        "indices" : [ 33, 44 ]
      }, {
        "text" : "blackbox",
        "indices" : [ 57, 66 ]
      }, {
        "text" : "raspberrypi",
        "indices" : [ 99, 111 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "751805537864519680",
    "text" : "Lorena Pantano Rubino #BOSC2016: #opensource opposite of #blackbox, illustrated with rainbow pibow #raspberrypi case https:\/\/t.co\/Gx9DjcFAIz",
    "id" : 751805537864519680,
    "created_at" : "2016-07-09 15:49:42 +0000",
    "user" : {
      "name" : "Peter Cock",
      "screen_name" : "pjacock",
      "protected" : false,
      "id_str" : "58756672",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/324343873\/peter_cliff_normal.jpg",
      "id" : 58756672,
      "verified" : false
    }
  },
  "id" : 751805745423847424,
  "created_at" : "2016-07-09 15:50:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bosc2016",
      "indices" : [ 119, 128 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "751799892541075456",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 28.36464716812947, -81.55918434089605 ]
  },
  "id_str" : "751800757180129280",
  "in_reply_to_user_id" : 14286491,
  "text" : "Reproducibility of phylogenetics: If you run enough tree inferences you will publish each possible tree at some point. #bosc2016",
  "id" : 751800757180129280,
  "in_reply_to_status_id" : 751799892541075456,
  "created_at" : "2016-07-09 15:30:42 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Cock",
      "screen_name" : "pjacock",
      "indices" : [ 3, 11 ],
      "id_str" : "58756672",
      "id" : 58756672
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BOSC2016",
      "indices" : [ 61, 70 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "751800475092131840",
  "text" : "RT @pjacock: This is probably the first mention of Amazon at #BOSC2016 meaning the river\/ecosystem, and not AWS cloud computing https:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/pjacock\/status\/751800202185568256\/photo\/1",
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/hNdAexwFXO",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cm7uSacWEAEU99B.jpg",
        "id_str" : "751800187920715777",
        "id" : 751800187920715777,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cm7uSacWEAEU99B.jpg",
        "sizes" : [ {
          "h" : 3024,
          "resize" : "fit",
          "w" : 4032
        }, {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 900,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/hNdAexwFXO"
      } ],
      "hashtags" : [ {
        "text" : "BOSC2016",
        "indices" : [ 48, 57 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "751800202185568256",
    "text" : "This is probably the first mention of Amazon at #BOSC2016 meaning the river\/ecosystem, and not AWS cloud computing https:\/\/t.co\/hNdAexwFXO",
    "id" : 751800202185568256,
    "created_at" : "2016-07-09 15:28:30 +0000",
    "user" : {
      "name" : "Peter Cock",
      "screen_name" : "pjacock",
      "protected" : false,
      "id_str" : "58756672",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/324343873\/peter_cliff_normal.jpg",
      "id" : 58756672,
      "verified" : false
    }
  },
  "id" : 751800475092131840,
  "created_at" : "2016-07-09 15:29:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bosc2016",
      "indices" : [ 44, 53 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "751781220594380800",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 28.36464716812947, -81.55918434089605 ]
  },
  "id_str" : "751799892541075456",
  "in_reply_to_user_id" : 14286491,
  "text" : "Yay, now open source for doing phylogenies. #bosc2016",
  "id" : 751799892541075456,
  "in_reply_to_status_id" : 751781220594380800,
  "created_at" : "2016-07-09 15:27:16 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bosc2016",
      "indices" : [ 90, 99 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/fTQ9fQNjy9",
      "expanded_url" : "https:\/\/twitter.com\/abbycabs\/status\/751780296249446400",
      "display_url" : "twitter.com\/abbycabs\/statu\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "751779457090916352",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 28.36464514569197, -81.55918070720138 ]
  },
  "id_str" : "751781220594380800",
  "in_reply_to_user_id" : 14286491,
  "text" : "Slide reads: Science that's kept secret is no different from science that was never done. #bosc2016 https:\/\/t.co\/fTQ9fQNjy9",
  "id" : 751781220594380800,
  "in_reply_to_status_id" : 751779457090916352,
  "created_at" : "2016-07-09 14:13:05 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bosc2016",
      "indices" : [ 133, 142 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/10q5ALk2kc",
      "expanded_url" : "https:\/\/thewinnower.com\/papers\/4715-correlating-the-sci-hub-data-with-world-bank-indicators-and-identifying-academic-use",
      "display_url" : "thewinnower.com\/papers\/4715-co\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "751777676776599552",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 28.36464145174072, -81.55916981970103 ]
  },
  "id_str" : "751779457090916352",
  "in_reply_to_user_id" : 14286491,
  "text" : "Related to open data &amp; open access: Read my work on how people are using Sci-Hub to break down paywalls. https:\/\/t.co\/10q5ALk2kc #bosc2016",
  "id" : 751779457090916352,
  "in_reply_to_status_id" : 751777676776599552,
  "created_at" : "2016-07-09 14:06:04 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tardigate",
      "indices" : [ 4, 14 ]
    }, {
      "text" : "bosc2016",
      "indices" : [ 101, 110 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "751777014101712900",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 28.36465514173563, -81.55918275613884 ]
  },
  "id_str" : "751777676776599552",
  "in_reply_to_user_id" : 14286491,
  "text" : "The #tardigate is getting mentioned as one example of how bad science can be corrected by open data. #bosc2016",
  "id" : 751777676776599552,
  "in_reply_to_status_id" : 751777014101712900,
  "created_at" : "2016-07-09 13:59:00 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bosc2016",
      "indices" : [ 118, 127 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "751491201690398721",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 28.36465514173563, -81.55918275613884 ]
  },
  "id_str" : "751777014101712900",
  "in_reply_to_user_id" : 14286491,
  "text" : "Open Data for human genomics not that easy, but ethics &amp; privacy often just used as an excuse to not share data.  #bosc2016",
  "id" : 751777014101712900,
  "in_reply_to_status_id" : 751491201690398721,
  "created_at" : "2016-07-09 13:56:22 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GigaScience",
      "screen_name" : "GigaScience",
      "indices" : [ 3, 15 ],
      "id_str" : "208988759",
      "id" : 208988759
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BOSC2015",
      "indices" : [ 114, 123 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "751776716591431680",
  "text" : "RT @GigaScience: Example 2.: GTEx. Multi-year delays in publication limited re-use, held under embargo until 2015 #BOSC2015 https:\/\/t.co\/ZR\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/GigaScience\/status\/751776685087944704\/photo\/1",
        "indices" : [ 107, 130 ],
        "url" : "https:\/\/t.co\/ZR1ZuCg6H1",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cm7Y6AEW8AAseyk.jpg",
        "id_str" : "751776678779744256",
        "id" : 751776678779744256,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cm7Y6AEW8AAseyk.jpg",
        "sizes" : [ {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 900,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/ZR1ZuCg6H1"
      } ],
      "hashtags" : [ {
        "text" : "BOSC2015",
        "indices" : [ 97, 106 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "751775769865646080",
    "geo" : { },
    "id_str" : "751776685087944704",
    "in_reply_to_user_id" : 208988759,
    "text" : "Example 2.: GTEx. Multi-year delays in publication limited re-use, held under embargo until 2015 #BOSC2015 https:\/\/t.co\/ZR1ZuCg6H1",
    "id" : 751776685087944704,
    "in_reply_to_status_id" : 751775769865646080,
    "created_at" : "2016-07-09 13:55:03 +0000",
    "in_reply_to_screen_name" : "GigaScience",
    "in_reply_to_user_id_str" : "208988759",
    "user" : {
      "name" : "GigaScience",
      "screen_name" : "GigaScience",
      "protected" : false,
      "id_str" : "208988759",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1404305552\/profile-photo-GigaScience-96x96_normal.jpg",
      "id" : 208988759,
      "verified" : false
    }
  },
  "id" : 751776716591431680,
  "created_at" : "2016-07-09 13:55:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Monica Munoz-Torres",
      "screen_name" : "monimunozto",
      "indices" : [ 3, 15 ],
      "id_str" : "538714687",
      "id" : 538714687
    }, {
      "name" : "Steven Salzberg",
      "screen_name" : "StevenSalzberg1",
      "indices" : [ 63, 79 ],
      "id_str" : "782615960",
      "id" : 782615960
    }, {
      "name" : "ENCODE Project",
      "screen_name" : "ENCODE_NIH",
      "indices" : [ 85, 96 ],
      "id_str" : "543700209",
      "id" : 543700209
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Fails",
      "indices" : [ 45, 51 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "751776183822540800",
  "text" : "RT @monimunozto: Here comes the Data Sharing #Fails, listed by @StevenSalzberg1 : 1) @ENCODE_NIH Data release policy updated in March 2014\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Steven Salzberg",
        "screen_name" : "StevenSalzberg1",
        "indices" : [ 46, 62 ],
        "id_str" : "782615960",
        "id" : 782615960
      }, {
        "name" : "ENCODE Project",
        "screen_name" : "ENCODE_NIH",
        "indices" : [ 68, 79 ],
        "id_str" : "543700209",
        "id" : 543700209
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Fails",
        "indices" : [ 28, 34 ]
      }, {
        "text" : "BOSC2016",
        "indices" : [ 123, 132 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "751775958026350592",
    "text" : "Here comes the Data Sharing #Fails, listed by @StevenSalzberg1 : 1) @ENCODE_NIH Data release policy updated in March 2014  #BOSC2016",
    "id" : 751775958026350592,
    "created_at" : "2016-07-09 13:52:10 +0000",
    "user" : {
      "name" : "Monica Munoz-Torres",
      "screen_name" : "monimunozto",
      "protected" : false,
      "id_str" : "538714687",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/713239690309083136\/QlP8BsHj_normal.jpg",
      "id" : 538714687,
      "verified" : false
    }
  },
  "id" : 751776183822540800,
  "created_at" : "2016-07-09 13:53:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Heather L. Wiencko",
      "screen_name" : "HLWiencko",
      "indices" : [ 0, 10 ],
      "id_str" : "2657942712",
      "id" : 2657942712
    }, {
      "name" : "Monica Munoz-Torres",
      "screen_name" : "monimunozto",
      "indices" : [ 11, 23 ],
      "id_str" : "538714687",
      "id" : 538714687
    }, {
      "name" : "Malin Sandstr\u00F6m",
      "screen_name" : "msandstr",
      "indices" : [ 24, 33 ],
      "id_str" : "23945759",
      "id" : 23945759
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 66 ],
      "url" : "https:\/\/t.co\/g0TOij5bcH",
      "expanded_url" : "https:\/\/smallchangebio.wordpress.com\/2016\/07\/08\/notes-bioinformatics-open-source-conference-2016-day-1-afternoon-standards-panel-on-growing-communities",
      "display_url" : "smallchangebio.wordpress.com\/2016\/07\/08\/not\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "751774243558490112",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 28.36465345868288, -81.5592005727021 ]
  },
  "id_str" : "751774442448093184",
  "in_reply_to_user_id" : 2657942712,
  "text" : "@HLWiencko @monimunozto @msandstr see also https:\/\/t.co\/g0TOij5bcH",
  "id" : 751774442448093184,
  "in_reply_to_status_id" : 751774243558490112,
  "created_at" : "2016-07-09 13:46:09 +0000",
  "in_reply_to_screen_name" : "HLWiencko",
  "in_reply_to_user_id_str" : "2657942712",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Cock",
      "screen_name" : "pjacock",
      "indices" : [ 0, 8 ],
      "id_str" : "58756672",
      "id" : 58756672
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "751771695778820096",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 28.3646306716094, -81.55918225060346 ]
  },
  "id_str" : "751771802448367616",
  "in_reply_to_user_id" : 58756672,
  "text" : "@pjacock thanks for the clarification!",
  "id" : 751771802448367616,
  "in_reply_to_status_id" : 751771695778820096,
  "created_at" : "2016-07-09 13:35:39 +0000",
  "in_reply_to_screen_name" : "pjacock",
  "in_reply_to_user_id_str" : "58756672",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Cock",
      "screen_name" : "pjacock",
      "indices" : [ 3, 11 ],
      "id_str" : "58756672",
      "id" : 58756672
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 13, 29 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 88 ],
      "url" : "https:\/\/t.co\/j03xQEuy4k",
      "expanded_url" : "http:\/\/gatkforums.broadinstitute.org\/gatk\/discussion\/1250\/what-is-phone-home-and-how-does-it-affect-me",
      "display_url" : "gatkforums.broadinstitute.org\/gatk\/discussio\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "751771753517645826",
  "text" : "RT @pjacock: @gedankenstuecke they recently back-tracked on this https:\/\/t.co\/j03xQEuy4k",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 0, 16 ],
        "id_str" : "14286491",
        "id" : 14286491
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 52, 75 ],
        "url" : "https:\/\/t.co\/j03xQEuy4k",
        "expanded_url" : "http:\/\/gatkforums.broadinstitute.org\/gatk\/discussion\/1250\/what-is-phone-home-and-how-does-it-affect-me",
        "display_url" : "gatkforums.broadinstitute.org\/gatk\/discussio\u2026"
      } ]
    },
    "in_reply_to_status_id_str" : "751771328680689664",
    "geo" : { },
    "id_str" : "751771695778820096",
    "in_reply_to_user_id" : 14286491,
    "text" : "@gedankenstuecke they recently back-tracked on this https:\/\/t.co\/j03xQEuy4k",
    "id" : 751771695778820096,
    "in_reply_to_status_id" : 751771328680689664,
    "created_at" : "2016-07-09 13:35:14 +0000",
    "in_reply_to_screen_name" : "gedankenstuecke",
    "in_reply_to_user_id_str" : "14286491",
    "user" : {
      "name" : "Peter Cock",
      "screen_name" : "pjacock",
      "protected" : false,
      "id_str" : "58756672",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/324343873\/peter_cliff_normal.jpg",
      "id" : 58756672,
      "verified" : false
    }
  },
  "id" : 751771753517645826,
  "created_at" : "2016-07-09 13:35:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bosc2016",
      "indices" : [ 85, 94 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 28.3646306716094, -81.55918225060346 ]
  },
  "id_str" : "751771328680689664",
  "text" : "GATK phones home about the software use by default. Another annoying thing about it. #bosc2016",
  "id" : 751771328680689664,
  "created_at" : "2016-07-09 13:33:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Salzberg",
      "screen_name" : "StevenSalzberg1",
      "indices" : [ 33, 49 ],
      "id_str" : "782615960",
      "id" : 782615960
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bosc2016",
      "indices" : [ 88, 97 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 28.36464289121045, -81.55917437658488 ]
  },
  "id_str" : "751770722947727360",
  "text" : "Not all software is open source. @StevenSalzberg1 is putting GATK on the wall of shame. #bosc2016",
  "id" : 751770722947727360,
  "created_at" : "2016-07-09 13:31:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Salzberg",
      "screen_name" : "StevenSalzberg1",
      "indices" : [ 5, 21 ],
      "id_str" : "782615960",
      "id" : 782615960
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bosc2016",
      "indices" : [ 76, 85 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 28.3646547722599, -81.55917952530478 ]
  },
  "id_str" : "751768095023308800",
  "text" : "Now: @StevenSalzberg1 about free software, open data &amp; open publishing. #bosc2016",
  "id" : 751768095023308800,
  "created_at" : "2016-07-09 13:20:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Heather L. Wiencko",
      "screen_name" : "HLWiencko",
      "indices" : [ 0, 10 ],
      "id_str" : "2657942712",
      "id" : 2657942712
    }, {
      "name" : "Malin Sandstr\u00F6m",
      "screen_name" : "msandstr",
      "indices" : [ 11, 20 ],
      "id_str" : "23945759",
      "id" : 23945759
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "751764017006407682",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 28.36466720392513, -81.55917203512622 ]
  },
  "id_str" : "751764373278982145",
  "in_reply_to_user_id" : 2657942712,
  "text" : "@HLWiencko @msandstr thanks! \uD83C\uDF89",
  "id" : 751764373278982145,
  "in_reply_to_status_id" : 751764017006407682,
  "created_at" : "2016-07-09 13:06:08 +0000",
  "in_reply_to_screen_name" : "HLWiencko",
  "in_reply_to_user_id_str" : "2657942712",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/751762755829596160\/photo\/1",
      "indices" : [ 59, 82 ],
      "url" : "https:\/\/t.co\/rxCiimubSW",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cm7MPc2XEAAHv4j.jpg",
      "id_str" : "751762753631752192",
      "id" : 751762753631752192,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cm7MPc2XEAAHv4j.jpg",
      "sizes" : [ {
        "h" : 1741,
        "resize" : "fit",
        "w" : 1306
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1741,
        "resize" : "fit",
        "w" : 1306
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      } ],
      "display_url" : "pic.twitter.com\/rxCiimubSW"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 28.364873, -81.558666 ]
  },
  "id_str" : "751762755829596160",
  "text" : "Okay, US and Canadian openSNP friends. Watch your mailbox! https:\/\/t.co\/rxCiimubSW",
  "id" : 751762755829596160,
  "created_at" : "2016-07-09 12:59:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Malin Sandstr\u00F6m",
      "screen_name" : "msandstr",
      "indices" : [ 0, 9 ],
      "id_str" : "23945759",
      "id" : 23945759
    }, {
      "name" : "Heather L. Wiencko",
      "screen_name" : "HLWiencko",
      "indices" : [ 10, 20 ],
      "id_str" : "2657942712",
      "id" : 2657942712
    }, {
      "name" : "Monica Munoz-Torres",
      "screen_name" : "monimunozto",
      "indices" : [ 29, 41 ],
      "id_str" : "538714687",
      "id" : 538714687
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "751655122443366400",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 28.36623678917844, -81.558871474193 ]
  },
  "id_str" : "751737655986118656",
  "in_reply_to_user_id" : 23945759,
  "text" : "@msandstr @HLWiencko I think @monimunozto did take lots of notes :)",
  "id" : 751737655986118656,
  "in_reply_to_status_id" : 751655122443366400,
  "created_at" : "2016-07-09 11:19:58 +0000",
  "in_reply_to_screen_name" : "msandstr",
  "in_reply_to_user_id_str" : "23945759",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chunlei Wu",
      "screen_name" : "chunleiwu",
      "indices" : [ 0, 10 ],
      "id_str" : "182750072",
      "id" : 182750072
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "751507550118547457",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 28.36631078840357, -81.55889282767566 ]
  },
  "id_str" : "751606732225478656",
  "in_reply_to_user_id" : 182750072,
  "text" : "@chunleiwu let\u2019s try tomorrow in the coffee break?",
  "id" : 751606732225478656,
  "in_reply_to_status_id" : 751507550118547457,
  "created_at" : "2016-07-09 02:39:43 +0000",
  "in_reply_to_screen_name" : "chunleiwu",
  "in_reply_to_user_id_str" : "182750072",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/tnVKInF0Qa",
      "expanded_url" : "https:\/\/twitter.com\/HLWiencko\/status\/751508721168187393",
      "display_url" : "twitter.com\/HLWiencko\/stat\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 28.36625909188057, -81.55903568890498 ]
  },
  "id_str" : "751606590898307072",
  "text" : "See me desperately cling to my cup of coffee while (successfully) trying to stay awake. https:\/\/t.co\/tnVKInF0Qa",
  "id" : 751606590898307072,
  "created_at" : "2016-07-09 02:39:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bosc2016",
      "indices" : [ 67, 76 ]
    } ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/PF67Hvq4i9",
      "expanded_url" : "https:\/\/twitter.com\/natasha_wood\/status\/751585677905629185",
      "display_url" : "twitter.com\/natasha_wood\/s\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 28.36667394733836, -81.55787972740974 ]
  },
  "id_str" : "751606090383626240",
  "text" : "Same here, honored to be in the company of such a wonderful panel! #bosc2016 https:\/\/t.co\/PF67Hvq4i9",
  "id" : 751606090383626240,
  "created_at" : "2016-07-09 02:37:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/kF0UzM2vie",
      "expanded_url" : "https:\/\/twitter.com\/pjacock\/status\/751568935854673920",
      "display_url" : "twitter.com\/pjacock\/status\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 28.37097558126077, -81.51852347191787 ]
  },
  "id_str" : "751571724089585664",
  "text" : "Hello from the far-right end! Maybe we should start a Gitter for dinner conversations. https:\/\/t.co\/kF0UzM2vie",
  "id" : 751571724089585664,
  "created_at" : "2016-07-09 00:20:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bosc2016",
      "indices" : [ 107, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 28.36464917583779, -81.55918129896781 ]
  },
  "id_str" : "751527157013381121",
  "text" : "First time the OBF travel fellowships have been awarded. Great way to open up events for diverse audience. #bosc2016",
  "id" : 751527157013381121,
  "created_at" : "2016-07-08 21:23:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Blin",
      "screen_name" : "kaiblin",
      "indices" : [ 17, 25 ],
      "id_str" : "124202458",
      "id" : 124202458
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bosc2016",
      "indices" : [ 65, 74 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 28.36465364857458, -81.5591881683144 ]
  },
  "id_str" : "751526246769655808",
  "text" : "Big shout-out to @kaiblin for his work on the GSoC organization! #bosc2016",
  "id" : 751526246769655808,
  "created_at" : "2016-07-08 21:19:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chunlei Wu",
      "screen_name" : "chunleiwu",
      "indices" : [ 0, 10 ],
      "id_str" : "182750072",
      "id" : 182750072
    }, {
      "name" : "Andrew Su",
      "screen_name" : "andrewsu",
      "indices" : [ 11, 20 ],
      "id_str" : "25743783",
      "id" : 25743783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "751507550118547457",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 28.36465043687854, -81.55917703929639 ]
  },
  "id_str" : "751524680125784064",
  "in_reply_to_user_id" : 182750072,
  "text" : "@chunleiwu @andrewsu great, let\u2019s do that!",
  "id" : 751524680125784064,
  "in_reply_to_status_id" : 751507550118547457,
  "created_at" : "2016-07-08 21:13:41 +0000",
  "in_reply_to_screen_name" : "chunleiwu",
  "in_reply_to_user_id_str" : "182750072",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 0, 9 ],
      "id_str" : "14245811",
      "id" : 14245811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "751493242210947073",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 28.36465157018991, -81.55918350932029 ]
  },
  "id_str" : "751496861081534464",
  "in_reply_to_user_id" : 14245811,
  "text" : "@wilbanks I should have guessed so. Please tell me you\u2019ll be at opencon if possible.",
  "id" : 751496861081534464,
  "in_reply_to_status_id" : 751493242210947073,
  "created_at" : "2016-07-08 19:23:08 +0000",
  "in_reply_to_screen_name" : "wilbanks",
  "in_reply_to_user_id_str" : "14245811",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 0, 9 ],
      "id_str" : "14245811",
      "id" : 14245811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "751492850513305600",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 28.36462487114792, -81.55915095794624 ]
  },
  "id_str" : "751493141694472193",
  "in_reply_to_user_id" : 14245811,
  "text" : "@wilbanks what i will say: everything starts rotating in the other direction when being completely drunk in Australia.",
  "id" : 751493141694472193,
  "in_reply_to_status_id" : 751492850513305600,
  "created_at" : "2016-07-08 19:08:21 +0000",
  "in_reply_to_screen_name" : "wilbanks",
  "in_reply_to_user_id_str" : "14245811",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/bbHFnCc79m",
      "expanded_url" : "https:\/\/twitter.com\/mbeisen\/status\/751491701772939264",
      "display_url" : "twitter.com\/mbeisen\/status\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 28.36462487114792, -81.55915095794624 ]
  },
  "id_str" : "751492199842471936",
  "text" : "What I can tell you, after having been there: my body feels like my DNA was forcible twisted into being left-handed. https:\/\/t.co\/bbHFnCc79m",
  "id" : 751492199842471936,
  "created_at" : "2016-07-08 19:04:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bosc2016",
      "indices" : [ 44, 53 ]
    } ],
    "urls" : [ {
      "indices" : [ 54, 77 ],
      "url" : "https:\/\/t.co\/vCw0zAKTAY",
      "expanded_url" : "https:\/\/twitter.com\/abbycabs\/status\/751490551967539200",
      "display_url" : "twitter.com\/abbycabs\/statu\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "751452118364614656",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 28.3646587039385, -81.55918114297283 ]
  },
  "id_str" : "751491201690398721",
  "in_reply_to_user_id" : 14286491,
  "text" : "Phenotype: conspicuously happy disposition. #bosc2016 https:\/\/t.co\/vCw0zAKTAY",
  "id" : 751491201690398721,
  "in_reply_to_status_id" : 751452118364614656,
  "created_at" : "2016-07-08 19:00:39 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "openSNP team",
      "screen_name" : "openSNPorg",
      "indices" : [ 63, 74 ],
      "id_str" : "380205172",
      "id" : 380205172
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BOSC2016",
      "indices" : [ 75, 84 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/91NxAad9LA",
      "expanded_url" : "https:\/\/twitter.com\/pjacock\/status\/751486057535922180",
      "display_url" : "twitter.com\/pjacock\/status\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 28.36465990465068, -81.55918380427464 ]
  },
  "id_str" : "751486616435363841",
  "text" : "Will need to check those out to see whether we can add them to @openSNPorg #BOSC2016 https:\/\/t.co\/91NxAad9LA",
  "id" : 751486616435363841,
  "created_at" : "2016-07-08 18:42:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "D Robinson, PhD",
      "screen_name" : "daniellecrobins",
      "indices" : [ 0, 16 ],
      "id_str" : "383289779",
      "id" : 383289779
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "751474418660962304",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 28.36463324793731, -81.55917102139351 ]
  },
  "id_str" : "751477610551599104",
  "in_reply_to_user_id" : 383289779,
  "text" : "@daniellecrobins yay, thanks!",
  "id" : 751477610551599104,
  "in_reply_to_status_id" : 751474418660962304,
  "created_at" : "2016-07-08 18:06:38 +0000",
  "in_reply_to_screen_name" : "daniellecrobins",
  "in_reply_to_user_id_str" : "383289779",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "751460144727355393",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 28.36463324793731, -81.55917102139351 ]
  },
  "id_str" : "751477043913777153",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC hugs if wanted.",
  "id" : 751477043913777153,
  "in_reply_to_status_id" : 751460144727355393,
  "created_at" : "2016-07-08 18:04:23 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/751474281486356480\/photo\/1",
      "indices" : [ 50, 73 ],
      "url" : "https:\/\/t.co\/JdsTBau77d",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cm3F2HwW8AA0hF9.jpg",
      "id_str" : "751474246426226688",
      "id" : 751474246426226688,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cm3F2HwW8AA0hF9.jpg",
      "sizes" : [ {
        "h" : 4032,
        "resize" : "fit",
        "w" : 3024
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      } ],
      "display_url" : "pic.twitter.com\/JdsTBau77d"
    } ],
    "hashtags" : [ {
      "text" : "BOSC2016",
      "indices" : [ 40, 49 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 28.36464298537006, -81.5591460915496 ]
  },
  "id_str" : "751474281486356480",
  "text" : "Find the minimalistic openSNP poster at #BOSC2016 https:\/\/t.co\/JdsTBau77d",
  "id" : 751474281486356480,
  "created_at" : "2016-07-08 17:53:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bosc2016",
      "indices" : [ 67, 76 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "751431720474468352",
  "geo" : { },
  "id_str" : "751452118364614656",
  "in_reply_to_user_id" : 14286491,
  "text" : "tl;dr of the current talk: yep, you can do metagenomics in Galaxy. #bosc2016",
  "id" : 751452118364614656,
  "in_reply_to_status_id" : 751431720474468352,
  "created_at" : "2016-07-08 16:25:20 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BOSC",
      "screen_name" : "OBF_BOSC",
      "indices" : [ 0, 9 ],
      "id_str" : "583180584",
      "id" : 583180584
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "751432201800130560",
  "geo" : { },
  "id_str" : "751432640872538112",
  "in_reply_to_user_id" : 583180584,
  "text" : "@OBF_BOSC maybe every tool\/project could donate some of their stickers for it? ;)",
  "id" : 751432640872538112,
  "in_reply_to_status_id" : 751432201800130560,
  "created_at" : "2016-07-08 15:07:57 +0000",
  "in_reply_to_screen_name" : "OBF_BOSC",
  "in_reply_to_user_id_str" : "583180584",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Blin",
      "screen_name" : "kaiblin",
      "indices" : [ 0, 8 ],
      "id_str" : "124202458",
      "id" : 124202458
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "751431659065528321",
  "geo" : { },
  "id_str" : "751432010183368704",
  "in_reply_to_user_id" : 124202458,
  "text" : "@kaiblin oh, my bad! Google had filtered the status update into junk.",
  "id" : 751432010183368704,
  "in_reply_to_status_id" : 751431659065528321,
  "created_at" : "2016-07-08 15:05:26 +0000",
  "in_reply_to_screen_name" : "kaiblin",
  "in_reply_to_user_id_str" : "124202458",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael R. Crusoe",
      "screen_name" : "biocrusoe",
      "indices" : [ 6, 16 ],
      "id_str" : "17645638",
      "id" : 17645638
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bosc2016",
      "indices" : [ 27, 36 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "751416363944730626",
  "geo" : { },
  "id_str" : "751431720474468352",
  "in_reply_to_user_id" : 14286491,
  "text" : "Next: @biocrusoe about CWL #bosc2016",
  "id" : 751431720474468352,
  "in_reply_to_status_id" : 751416363944730626,
  "created_at" : "2016-07-08 15:04:17 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u24EA Rik Smith-Unna \uD83C\uDDF0\uD83C\uDDEA",
      "screen_name" : "blahah404",
      "indices" : [ 3, 13 ],
      "id_str" : "99173786",
      "id" : 99173786
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/VogPdvw3hr",
      "expanded_url" : "http:\/\/journals.plos.org\/plosone\/article\/authors?id=10.1371%2Fjournal.pone.0141854",
      "display_url" : "journals.plos.org\/plosone\/articl\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "751431203279015936",
  "text" : "RT @blahah404: \"significant bias in the killing of unarmed black Americans relative to unarmed white Americans\" https:\/\/t.co\/VogPdvw3hr via\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Christie Bahlai",
        "screen_name" : "cbahlai",
        "indices" : [ 125, 133 ],
        "id_str" : "958649520",
        "id" : 958649520
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 97, 120 ],
        "url" : "https:\/\/t.co\/VogPdvw3hr",
        "expanded_url" : "http:\/\/journals.plos.org\/plosone\/article\/authors?id=10.1371%2Fjournal.pone.0141854",
        "display_url" : "journals.plos.org\/plosone\/articl\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "751430675253911553",
    "text" : "\"significant bias in the killing of unarmed black Americans relative to unarmed white Americans\" https:\/\/t.co\/VogPdvw3hr via @cbahlai",
    "id" : 751430675253911553,
    "created_at" : "2016-07-08 15:00:08 +0000",
    "user" : {
      "name" : "\u24EA Rik Smith-Unna \uD83C\uDDF0\uD83C\uDDEA",
      "screen_name" : "blahah404",
      "protected" : false,
      "id_str" : "99173786",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/712249526577438720\/-dRs3Gg9_normal.jpg",
      "id" : 99173786,
      "verified" : false
    }
  },
  "id" : 751431203279015936,
  "created_at" : "2016-07-08 15:02:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Blin",
      "screen_name" : "kaiblin",
      "indices" : [ 0, 8 ],
      "id_str" : "124202458",
      "id" : 124202458
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "751430076072419328",
  "geo" : { },
  "id_str" : "751430497700634624",
  "in_reply_to_user_id" : 124202458,
  "text" : "@kaiblin btw. what ever happened to my jobs? ;)",
  "id" : 751430497700634624,
  "in_reply_to_status_id" : 751430076072419328,
  "created_at" : "2016-07-08 14:59:26 +0000",
  "in_reply_to_screen_name" : "kaiblin",
  "in_reply_to_user_id_str" : "124202458",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/0hdiMFe9II",
      "expanded_url" : "https:\/\/twitter.com\/HLWiencko\/status\/751419266994434048",
      "display_url" : "twitter.com\/HLWiencko\/stat\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 28.36462202445037, -81.5591546971215 ]
  },
  "id_str" : "751423946742988800",
  "text" : "Trying to avoid my own personal zombie apocalypse with more \u2615\uFE0F\u2615\uFE0F\u2615\uFE0F too. https:\/\/t.co\/0hdiMFe9II",
  "id" : 751423946742988800,
  "created_at" : "2016-07-08 14:33:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bosc2016",
      "indices" : [ 73, 82 ]
    } ],
    "urls" : [ {
      "indices" : [ 49, 72 ],
      "url" : "https:\/\/t.co\/80Dbpy3M3b",
      "expanded_url" : "http:\/\/biorxiv.org\/content\/early\/2013\/12\/16\/001388",
      "display_url" : "biorxiv.org\/content\/early\/\u2026"
    }, {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/NEZl0pamrk",
      "expanded_url" : "https:\/\/twitter.com\/pjacock\/status\/751415257705410564",
      "display_url" : "twitter.com\/pjacock\/status\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "751413217579196416",
  "geo" : { },
  "id_str" : "751416363944730626",
  "in_reply_to_user_id" : 14286491,
  "text" : "iirc this is the pre-print for the method itself https:\/\/t.co\/80Dbpy3M3b #bosc2016 https:\/\/t.co\/NEZl0pamrk",
  "id" : 751416363944730626,
  "in_reply_to_status_id" : 751413217579196416,
  "created_at" : "2016-07-08 14:03:16 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bosc2016",
      "indices" : [ 103, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/yDn5dDFO3b",
      "expanded_url" : "https:\/\/madisonleighrose.wordpress.com\/2012\/08\/27\/john-snow-and-the-cholera-myth\/",
      "display_url" : "madisonleighrose.wordpress.com\/2012\/08\/27\/joh\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "751412349039419392",
  "geo" : { },
  "id_str" : "751413217579196416",
  "in_reply_to_user_id" : 14286491,
  "text" : "If you\u2019re interested in the John Snow &amp; Broad Street story in more detail: https:\/\/t.co\/yDn5dDFO3b #bosc2016",
  "id" : 751413217579196416,
  "in_reply_to_status_id" : 751412349039419392,
  "created_at" : "2016-07-08 13:50:46 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bosc2016",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/EPmXc46q7v",
      "expanded_url" : "https:\/\/twitter.com\/monimunozto\/status\/751412155807825920",
      "display_url" : "twitter.com\/monimunozto\/st\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "751410106013773824",
  "geo" : { },
  "id_str" : "751412349039419392",
  "in_reply_to_user_id" : 14286491,
  "text" : "How to monitor food poisoning and food born illnesses using Twitter. #bosc2016 https:\/\/t.co\/EPmXc46q7v",
  "id" : 751412349039419392,
  "in_reply_to_status_id" : 751410106013773824,
  "created_at" : "2016-07-08 13:47:19 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Schawinski",
      "screen_name" : "kevinschawinski",
      "indices" : [ 0, 16 ],
      "id_str" : "242844365",
      "id" : 242844365
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "751410193825730560",
  "geo" : { },
  "id_str" : "751410308506349568",
  "in_reply_to_user_id" : 242844365,
  "text" : "@kevinschawinski yep, elephant crap in this case.",
  "id" : 751410308506349568,
  "in_reply_to_status_id" : 751410193825730560,
  "created_at" : "2016-07-08 13:39:12 +0000",
  "in_reply_to_screen_name" : "kevinschawinski",
  "in_reply_to_user_id_str" : "242844365",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bosc2016",
      "indices" : [ 82, 91 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "751407666505940992",
  "geo" : { },
  "id_str" : "751410106013773824",
  "in_reply_to_user_id" : 14286491,
  "text" : "Shout-out to Nanopore, because you can literally just sequence crap in the field. #bosc2016",
  "id" : 751410106013773824,
  "in_reply_to_status_id" : 751407666505940992,
  "created_at" : "2016-07-08 13:38:24 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bosc2016",
      "indices" : [ 110, 119 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "751407666505940992",
  "text" : "JD: \u00ABThere\u2019s a journal for emerging infectious diseases, if you want to terrify yourself on a monthly basis.\u00BB #bosc2016",
  "id" : 751407666505940992,
  "created_at" : "2016-07-08 13:28:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jennifer Gardy",
      "screen_name" : "jennifergardy",
      "indices" : [ 75, 89 ],
      "id_str" : "20478716",
      "id" : 20478716
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BOSC2016",
      "indices" : [ 125, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "751405819841880064",
  "text" : "\u00ABIt\u2019s a terrible idea to base your entire idea on a Dustin Hoffman movie\u2026\u00BB @jennifergardy on how Outbreak shaped her career. #BOSC2016",
  "id" : 751405819841880064,
  "created_at" : "2016-07-08 13:21:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Monica Munoz-Torres",
      "screen_name" : "monimunozto",
      "indices" : [ 0, 12 ],
      "id_str" : "538714687",
      "id" : 538714687
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "751405211126788097",
  "in_reply_to_user_id" : 538714687,
  "text" : "@monimunozto thanks for the remarks. Looking forward to the BOF.",
  "id" : 751405211126788097,
  "created_at" : "2016-07-08 13:18:57 +0000",
  "in_reply_to_screen_name" : "monimunozto",
  "in_reply_to_user_id_str" : "538714687",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bastien Chevreux",
      "screen_name" : "BaCh_mira",
      "indices" : [ 0, 10 ],
      "id_str" : "360258516",
      "id" : 360258516
    }, {
      "name" : "Kai Blin",
      "screen_name" : "kaiblin",
      "indices" : [ 11, 19 ],
      "id_str" : "124202458",
      "id" : 124202458
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "751404599534358528",
  "geo" : { },
  "id_str" : "751404805256609792",
  "in_reply_to_user_id" : 360258516,
  "text" : "@BaCh_mira @kaiblin yes, fitting the remarks about value for money we\u2019ve heard earlier here.",
  "id" : 751404805256609792,
  "in_reply_to_status_id" : 751404599534358528,
  "created_at" : "2016-07-08 13:17:20 +0000",
  "in_reply_to_screen_name" : "BaCh_mira",
  "in_reply_to_user_id_str" : "360258516",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nomi Harris",
      "screen_name" : "NomiHarris",
      "indices" : [ 83, 94 ],
      "id_str" : "351049850",
      "id" : 351049850
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BOSC2016",
      "indices" : [ 1, 10 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "751403954001547264",
  "text" : "\u00AB#BOSC2016 is a community of communities, it\u2019s more than the sum of it\u2019s parts.\u00BB \u2013 @NomiHarris",
  "id" : 751403954001547264,
  "created_at" : "2016-07-08 13:13:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nyborg",
      "screen_name" : "ny_borg",
      "indices" : [ 0, 8 ],
      "id_str" : "570156398",
      "id" : 570156398
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "751400522008190976",
  "geo" : { },
  "id_str" : "751401105762975744",
  "in_reply_to_user_id" : 570156398,
  "text" : "@ny_borg yep, wundert mich auch nicht ehrlich gesagt. W\u00E4re auch nicht freiwillig hier.",
  "id" : 751401105762975744,
  "in_reply_to_status_id" : 751400522008190976,
  "created_at" : "2016-07-08 13:02:38 +0000",
  "in_reply_to_screen_name" : "ny_borg",
  "in_reply_to_user_id_str" : "570156398",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Blin",
      "screen_name" : "kaiblin",
      "indices" : [ 0, 8 ],
      "id_str" : "124202458",
      "id" : 124202458
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "751398425338449920",
  "geo" : { },
  "id_str" : "751399811065274368",
  "in_reply_to_user_id" : 124202458,
  "text" : "@kaiblin more like Atlantikwall\u2026 :\/",
  "id" : 751399811065274368,
  "in_reply_to_status_id" : 751398425338449920,
  "created_at" : "2016-07-08 12:57:29 +0000",
  "in_reply_to_screen_name" : "kaiblin",
  "in_reply_to_user_id_str" : "124202458",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "751397492009406464",
  "geo" : { },
  "id_str" : "751398521484574720",
  "in_reply_to_user_id" : 14286491,
  "text" : "\u201EThe German\u2019s always have been good people\u201C is also a strong claim to make, especially if you have a German-Jewish last name\u2026",
  "id" : 751398521484574720,
  "in_reply_to_status_id" : 751397492009406464,
  "created_at" : "2016-07-08 12:52:22 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 28.36464620409137, -81.55917002184742 ]
  },
  "id_str" : "751397492009406464",
  "text" : "Disney, where your breakfast server tries to engage you in a discussion how the evil refugees are destroying Europe m(",
  "id" : 751397492009406464,
  "created_at" : "2016-07-08 12:48:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "751382483313328128",
  "text" : "Feeling not too jet lagged so far. \uD83C\uDF89\uD83C\uDF89\uD83C\uDF89",
  "id" : 751382483313328128,
  "created_at" : "2016-07-08 11:48:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Erickson",
      "screen_name" : "hooptysteve",
      "indices" : [ 0, 12 ],
      "id_str" : "148157038",
      "id" : 148157038
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "751188801494605829",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 28.38380228265038, -81.30900685683014 ]
  },
  "id_str" : "751189682998939648",
  "in_reply_to_user_id" : 148157038,
  "text" : "@hooptysteve luckily I\u2019m taking a shuttle bus. But was confused by why we\u2019re boarding it from the wrong side and then noticed ;)",
  "id" : 751189682998939648,
  "in_reply_to_status_id" : 751188801494605829,
  "created_at" : "2016-07-07 23:02:31 +0000",
  "in_reply_to_screen_name" : "hooptysteve",
  "in_reply_to_user_id_str" : "148157038",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 28.43011212577364, -81.30848642860917 ]
  },
  "id_str" : "751188592819638272",
  "text" : "By now I\u2019m fully confused about a) in which time zone I am \nb) the handedness of the traffic",
  "id" : 751188592819638272,
  "created_at" : "2016-07-07 22:58:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Cock",
      "screen_name" : "pjacock",
      "indices" : [ 0, 8 ],
      "id_str" : "58756672",
      "id" : 58756672
    }, {
      "name" : "Nomi Harris",
      "screen_name" : "NomiHarris",
      "indices" : [ 9, 20 ],
      "id_str" : "351049850",
      "id" : 351049850
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "751180611902136321",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 28.43012329976621, -81.30820616960001 ]
  },
  "id_str" : "751180955801583617",
  "in_reply_to_user_id" : 58756672,
  "text" : "@pjacock @NomiHarris yep, made it somehow. \uD83D\uDE0A",
  "id" : 751180955801583617,
  "in_reply_to_status_id" : 751180611902136321,
  "created_at" : "2016-07-07 22:27:50 +0000",
  "in_reply_to_screen_name" : "pjacock",
  "in_reply_to_user_id_str" : "58756672",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shreejoy Tripathy",
      "screen_name" : "neuronJoy",
      "indices" : [ 0, 10 ],
      "id_str" : "22292146",
      "id" : 22292146
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BOSC2016",
      "indices" : [ 20, 29 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "751103668754247680",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 28.42753058782412, -81.30041181979216 ]
  },
  "id_str" : "751171150202503168",
  "in_reply_to_user_id" : 22292146,
  "text" : "@neuronJoy only for #BOSC2016. Will miss out on the main conference.",
  "id" : 751171150202503168,
  "in_reply_to_status_id" : 751103668754247680,
  "created_at" : "2016-07-07 21:48:52 +0000",
  "in_reply_to_screen_name" : "neuronJoy",
  "in_reply_to_user_id_str" : "22292146",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 33.94050501532831, -118.4041653614404 ]
  },
  "id_str" : "751087681157865472",
  "text" : "Yay, last minute change to an aisle seat. And now LAX \u2708\uFE0F MCO.",
  "id" : 751087681157865472,
  "created_at" : "2016-07-07 16:17:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Misha Angrist",
      "screen_name" : "MishaAngrist",
      "indices" : [ 0, 13 ],
      "id_str" : "116877838",
      "id" : 116877838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "751080624367276032",
  "geo" : { },
  "id_str" : "751081376259018752",
  "in_reply_to_user_id" : 116877838,
  "text" : "@MishaAngrist \u201Elike reading an advice column by way of fMRI studies published in PNAS\u201C. Actually pretty spot-on to Lehrer\u2019s work\u2026",
  "id" : 751081376259018752,
  "in_reply_to_status_id" : 751080624367276032,
  "created_at" : "2016-07-07 15:52:09 +0000",
  "in_reply_to_screen_name" : "MishaAngrist",
  "in_reply_to_user_id_str" : "116877838",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Blin",
      "screen_name" : "kaiblin",
      "indices" : [ 0, 8 ],
      "id_str" : "124202458",
      "id" : 124202458
    }, {
      "name" : "Torsten Seemann",
      "screen_name" : "torstenseemann",
      "indices" : [ 9, 24 ],
      "id_str" : "42558652",
      "id" : 42558652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "751050763405778944",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 33.9405530886123, -118.4041923456709 ]
  },
  "id_str" : "751070518032404480",
  "in_reply_to_user_id" : 124202458,
  "text" : "@kaiblin @torstenseemann by now I have the feeling that snails could match my speed.",
  "id" : 751070518032404480,
  "in_reply_to_status_id" : 751050763405778944,
  "created_at" : "2016-07-07 15:09:00 +0000",
  "in_reply_to_screen_name" : "kaiblin",
  "in_reply_to_user_id_str" : "124202458",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Misha Angrist",
      "screen_name" : "MishaAngrist",
      "indices" : [ 0, 13 ],
      "id_str" : "116877838",
      "id" : 116877838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "751038515669004289",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 33.94057935118885, -118.4041910063073 ]
  },
  "id_str" : "751070262326681600",
  "in_reply_to_user_id" : 116877838,
  "text" : "@MishaAngrist we have the same taste in money quotes. ;)",
  "id" : 751070262326681600,
  "in_reply_to_status_id" : 751038515669004289,
  "created_at" : "2016-07-07 15:07:59 +0000",
  "in_reply_to_screen_name" : "MishaAngrist",
  "in_reply_to_user_id_str" : "116877838",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Malin Sandstr\u00F6m",
      "screen_name" : "msandstr",
      "indices" : [ 0, 9 ],
      "id_str" : "23945759",
      "id" : 23945759
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "750920278943862784",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 33.94649711513842, -118.4093283895941 ]
  },
  "id_str" : "751049496843386880",
  "in_reply_to_user_id" : 23945759,
  "text" : "@msandstr given that both post cards contain &lt; 140 characters that\u2019s two expensive tweets ;)",
  "id" : 751049496843386880,
  "in_reply_to_status_id" : 750920278943862784,
  "created_at" : "2016-07-07 13:45:28 +0000",
  "in_reply_to_screen_name" : "msandstr",
  "in_reply_to_user_id_str" : "23945759",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Torsten Seemann",
      "screen_name" : "torstenseemann",
      "indices" : [ 0, 15 ],
      "id_str" : "42558652",
      "id" : 42558652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "750889114312986624",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 33.94637531171239, -118.4103213201237 ]
  },
  "id_str" : "751049331499687937",
  "in_reply_to_user_id" : 42558652,
  "text" : "@torstenseemann none to be found so far. Let\u2019s see what the LAX \u2708\uFE0F MCO leg has in store.",
  "id" : 751049331499687937,
  "in_reply_to_status_id" : 750889114312986624,
  "created_at" : "2016-07-07 13:44:49 +0000",
  "in_reply_to_screen_name" : "torstenseemann",
  "in_reply_to_user_id_str" : "42558652",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 34 ],
      "url" : "https:\/\/t.co\/nwxhrNHpoU",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BHilNrtjIaf\/",
      "display_url" : "instagram.com\/p\/BHilNrtjIaf\/"
    } ]
  },
  "geo" : { },
  "id_str" : "750850663412862976",
  "text" : "BNE \u2708\uFE0F LAX https:\/\/t.co\/nwxhrNHpoU",
  "id" : 750850663412862976,
  "created_at" : "2016-07-07 00:35:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Istar Nil 0x47617921",
      "screen_name" : "istar_nil",
      "indices" : [ 0, 10 ],
      "id_str" : "314234855",
      "id" : 314234855
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "750849552408670208",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ -27.40369091221349, 153.1109209793192 ]
  },
  "id_str" : "750849911525027840",
  "in_reply_to_user_id" : 314234855,
  "text" : "@istar_nil great, hope to get them out before heading back to Frankfurt. And thanks!",
  "id" : 750849911525027840,
  "in_reply_to_status_id" : 750849552408670208,
  "created_at" : "2016-07-07 00:32:23 +0000",
  "in_reply_to_screen_name" : "istar_nil",
  "in_reply_to_user_id_str" : "314234855",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Istar Nil 0x47617921",
      "screen_name" : "istar_nil",
      "indices" : [ 0, 10 ],
      "id_str" : "314234855",
      "id" : 314234855
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 11, 24 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 25, 31 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "750843554226774016",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ -27.40377408043431, 153.1100184503473 ]
  },
  "id_str" : "750844028707418112",
  "in_reply_to_user_id" : 314234855,
  "text" : "@istar_nil @PhilippBayer @Lobot it\u2019s 30 mins before my plane over to the US is leaving and a got all stickers with me ;)",
  "id" : 750844028707418112,
  "in_reply_to_status_id" : 750843554226774016,
  "created_at" : "2016-07-07 00:09:01 +0000",
  "in_reply_to_screen_name" : "istar_nil",
  "in_reply_to_user_id_str" : "314234855",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Istar Nil 0x47617921",
      "screen_name" : "istar_nil",
      "indices" : [ 0, 10 ],
      "id_str" : "314234855",
      "id" : 314234855
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 11, 24 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 25, 31 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "750843554226774016",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ -27.40382031935718, 153.1100185323826 ]
  },
  "id_str" : "750843857659531264",
  "in_reply_to_user_id" : 314234855,
  "text" : "@istar_nil @PhilippBayer @Lobot mail me your postal address to bgreshake@gmail and I\u2019ll send you some.",
  "id" : 750843857659531264,
  "in_reply_to_status_id" : 750843554226774016,
  "created_at" : "2016-07-07 00:08:20 +0000",
  "in_reply_to_screen_name" : "istar_nil",
  "in_reply_to_user_id_str" : "314234855",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Istar Nil 0x47617921",
      "screen_name" : "istar_nil",
      "indices" : [ 0, 10 ],
      "id_str" : "314234855",
      "id" : 314234855
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 11, 24 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 25, 31 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "750840062816849920",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ -27.40390162301336, 153.1100315728545 ]
  },
  "id_str" : "750840160003067904",
  "in_reply_to_user_id" : 314234855,
  "text" : "@istar_nil @PhilippBayer @Lobot you\u2019re in the US, right?",
  "id" : 750840160003067904,
  "in_reply_to_status_id" : 750840062816849920,
  "created_at" : "2016-07-06 23:53:38 +0000",
  "in_reply_to_screen_name" : "istar_nil",
  "in_reply_to_user_id_str" : "314234855",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "david ehrlich",
      "screen_name" : "davidehrlich",
      "indices" : [ 3, 16 ],
      "id_str" : "22452361",
      "id" : 22452361
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "750839563648528385",
  "text" : "RT @davidehrlich: \"Jet lag is a privilege,\" he told himself as he poured the red bull directly into his eye holes.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "750817922973634560",
    "text" : "\"Jet lag is a privilege,\" he told himself as he poured the red bull directly into his eye holes.",
    "id" : 750817922973634560,
    "created_at" : "2016-07-06 22:25:17 +0000",
    "user" : {
      "name" : "david ehrlich",
      "screen_name" : "davidehrlich",
      "protected" : false,
      "id_str" : "22452361",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2250575322\/Screen_Shot_2012-05-26_at_12.12.33_AM_normal.png",
      "id" : 22452361,
      "verified" : true
    }
  },
  "id" : 750839563648528385,
  "created_at" : "2016-07-06 23:51:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 81 ],
      "url" : "https:\/\/t.co\/p9P5heN1XB",
      "expanded_url" : "https:\/\/twitter.com\/MaxNisen\/status\/750809605073170432",
      "display_url" : "twitter.com\/MaxNisen\/statu\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ -27.40392253116779, 153.1099797200156 ]
  },
  "id_str" : "750838372441071616",
  "text" : "\u00ABIt\u2019s like reading an advice column by way of JSTOR.\u00BB \uD83D\uDD25\uD83D\uDD25\uD83D\uDD25 https:\/\/t.co\/p9P5heN1XB",
  "id" : 750838372441071616,
  "created_at" : "2016-07-06 23:46:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Skellett",
      "screen_name" : "Gurdur",
      "indices" : [ 0, 7 ],
      "id_str" : "125928028",
      "id" : 125928028
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "750829212253257728",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ -27.40383956131782, 153.1099999922832 ]
  },
  "id_str" : "750831845646868480",
  "in_reply_to_user_id" : 125928028,
  "text" : "@Gurdur at least the Australian $ is even more worthless than the \u00A3 ;)",
  "id" : 750831845646868480,
  "in_reply_to_status_id" : 750829212253257728,
  "created_at" : "2016-07-06 23:20:36 +0000",
  "in_reply_to_screen_name" : "Gurdur",
  "in_reply_to_user_id_str" : "125928028",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "750828211248955392",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ -27.40373110568499, 153.1100620160525 ]
  },
  "id_str" : "750829114760663040",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot chance #2!",
  "id" : 750829114760663040,
  "in_reply_to_status_id" : 750828211248955392,
  "created_at" : "2016-07-06 23:09:45 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony Ross-Hellauer",
      "screen_name" : "tonyR_H",
      "indices" : [ 0, 8 ],
      "id_str" : "44890780",
      "id" : 44890780
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "750827566127349760",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ -27.40360113996226, 153.1097069967211 ]
  },
  "id_str" : "750829072616304640",
  "in_reply_to_user_id" : 44890780,
  "text" : "@tonyR_H thanks!",
  "id" : 750829072616304640,
  "in_reply_to_status_id" : 750827566127349760,
  "created_at" : "2016-07-06 23:09:35 +0000",
  "in_reply_to_screen_name" : "tonyR_H",
  "in_reply_to_user_id_str" : "44890780",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kingsley Shacklebolt",
      "screen_name" : "Sankore_Texte",
      "indices" : [ 0, 14 ],
      "id_str" : "168846668",
      "id" : 168846668
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "750826526803914752",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ -27.40344359141509, 153.1093405040119 ]
  },
  "id_str" : "750828950226497536",
  "in_reply_to_user_id" : 168846668,
  "text" : "@Sankore_Texte nope, wrong side of Australia for that :p",
  "id" : 750828950226497536,
  "in_reply_to_status_id" : 750826526803914752,
  "created_at" : "2016-07-06 23:09:06 +0000",
  "in_reply_to_screen_name" : "Sankore_Texte",
  "in_reply_to_user_id_str" : "168846668",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TriploidTree",
      "screen_name" : "TriploidTree",
      "indices" : [ 0, 13 ],
      "id_str" : "14165662",
      "id" : 14165662
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "750826389746642944",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ -27.40342980378657, 153.1096646662051 ]
  },
  "id_str" : "750826589823262720",
  "in_reply_to_user_id" : 14165662,
  "text" : "@TriploidTree probably, that would make a good story. Let me look for one!",
  "id" : 750826589823262720,
  "in_reply_to_status_id" : 750826389746642944,
  "created_at" : "2016-07-06 22:59:43 +0000",
  "in_reply_to_screen_name" : "TriploidTree",
  "in_reply_to_user_id_str" : "14165662",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ -27.40343979235681, 153.1097733685497 ]
  },
  "id_str" : "750826470486921217",
  "text" : "Also for the people suggesting mailing books back home: I just paid $5 to send two postcards to Europe.",
  "id" : 750826470486921217,
  "created_at" : "2016-07-06 22:59:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TriploidTree",
      "screen_name" : "TriploidTree",
      "indices" : [ 0, 13 ],
      "id_str" : "14165662",
      "id" : 14165662
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "750825028992860160",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ -27.40346182566954, 153.1094986640998 ]
  },
  "id_str" : "750826001161023489",
  "in_reply_to_user_id" : 14165662,
  "text" : "@TriploidTree last minute, in the airport terminal :p",
  "id" : 750826001161023489,
  "in_reply_to_status_id" : 750825028992860160,
  "created_at" : "2016-07-06 22:57:23 +0000",
  "in_reply_to_screen_name" : "TriploidTree",
  "in_reply_to_user_id_str" : "14165662",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TriploidTree",
      "screen_name" : "TriploidTree",
      "indices" : [ 0, 13 ],
      "id_str" : "14165662",
      "id" : 14165662
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "750824509540864000",
  "geo" : { },
  "id_str" : "750824583234674688",
  "in_reply_to_user_id" : 14165662,
  "text" : "@TriploidTree Neither, I just ran out of characters.",
  "id" : 750824583234674688,
  "in_reply_to_status_id" : 750824509540864000,
  "created_at" : "2016-07-06 22:51:44 +0000",
  "in_reply_to_screen_name" : "TriploidTree",
  "in_reply_to_user_id_str" : "14165662",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony Ross-Hellauer",
      "screen_name" : "tonyR_H",
      "indices" : [ 0, 8 ],
      "id_str" : "44890780",
      "id" : 44890780
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "750823806252482561",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ -27.40351269144814, 153.1094104689185 ]
  },
  "id_str" : "750824161841258496",
  "in_reply_to_user_id" : 44890780,
  "text" : "@tonyR_H will be on the next conference until 10th, then heading back from US to Germany.",
  "id" : 750824161841258496,
  "in_reply_to_status_id" : 750823806252482561,
  "created_at" : "2016-07-06 22:50:04 +0000",
  "in_reply_to_screen_name" : "tonyR_H",
  "in_reply_to_user_id_str" : "44890780",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ -27.4035980742033, 153.1093454397193 ]
  },
  "id_str" : "750823962167222272",
  "text" : "I went to Australia and wasn\u2019t bitten by a kangaroo, not bitten by a koala, not bitten by a snake. Folks home will be so disappointed.",
  "id" : 750823962167222272,
  "created_at" : "2016-07-06 22:49:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fiona Nielsen",
      "screen_name" : "glyn_dk",
      "indices" : [ 0, 8 ],
      "id_str" : "32340834",
      "id" : 32340834
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "750812466037350400",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ -27.40337940551593, 153.1096591494225 ]
  },
  "id_str" : "750815395079041024",
  "in_reply_to_user_id" : 32340834,
  "text" : "@glyn_dk I totally understand. Did it twice and it\u2019s so hard.",
  "id" : 750815395079041024,
  "in_reply_to_status_id" : 750812466037350400,
  "created_at" : "2016-07-06 22:15:14 +0000",
  "in_reply_to_screen_name" : "glyn_dk",
  "in_reply_to_user_id_str" : "32340834",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fiona Nielsen",
      "screen_name" : "glyn_dk",
      "indices" : [ 0, 8 ],
      "id_str" : "32340834",
      "id" : 32340834
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "750810721185914880",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ -27.4033232080074, 153.1097260864015 ]
  },
  "id_str" : "750812161237065730",
  "in_reply_to_user_id" : 32340834,
  "text" : "@glyn_dk then there\u2019s still mercy killing :\/",
  "id" : 750812161237065730,
  "in_reply_to_status_id" : 750810721185914880,
  "created_at" : "2016-07-06 22:02:23 +0000",
  "in_reply_to_screen_name" : "glyn_dk",
  "in_reply_to_user_id_str" : "32340834",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fiona Nielsen",
      "screen_name" : "glyn_dk",
      "indices" : [ 0, 8 ],
      "id_str" : "32340834",
      "id" : 32340834
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "750806257028755456",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ -27.53883150874408, 153.1184918807383 ]
  },
  "id_str" : "750806935050395648",
  "in_reply_to_user_id" : 32340834,
  "text" : "@glyn_dk i guess taking it to the vet isn\u2019t an option? :(",
  "id" : 750806935050395648,
  "in_reply_to_status_id" : 750806257028755456,
  "created_at" : "2016-07-06 21:41:37 +0000",
  "in_reply_to_screen_name" : "glyn_dk",
  "in_reply_to_user_id_str" : "32340834",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fiona Nielsen",
      "screen_name" : "glyn_dk",
      "indices" : [ 0, 8 ],
      "id_str" : "32340834",
      "id" : 32340834
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "750783208799756289",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ -27.60298546406217, 153.1168080402101 ]
  },
  "id_str" : "750805322663534592",
  "in_reply_to_user_id" : 32340834,
  "text" : "@glyn_dk the joys of having a cat. :\/",
  "id" : 750805322663534592,
  "in_reply_to_status_id" : 750783208799756289,
  "created_at" : "2016-07-06 21:35:12 +0000",
  "in_reply_to_screen_name" : "glyn_dk",
  "in_reply_to_user_id_str" : "32340834",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony Ross-Hellauer",
      "screen_name" : "tonyR_H",
      "indices" : [ 0, 8 ],
      "id_str" : "44890780",
      "id" : 44890780
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "750721962591318016",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ -28.00500663908542, 153.4236427571348 ]
  },
  "id_str" : "750771761642217473",
  "in_reply_to_user_id" : 44890780,
  "text" : "@tonyR_H did see it. Do you need a reply soon?",
  "id" : 750771761642217473,
  "in_reply_to_status_id" : 750721962591318016,
  "created_at" : "2016-07-06 19:21:51 +0000",
  "in_reply_to_screen_name" : "tonyR_H",
  "in_reply_to_user_id_str" : "44890780",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "smbe16",
      "indices" : [ 14, 21 ]
    }, {
      "text" : "BOSC2016",
      "indices" : [ 94, 103 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ -28.00496524799925, 153.4236602777893 ]
  },
  "id_str" : "750718585807319040",
  "text" : "Back from the #smbe16 conference dinner. Now 4 hours of sleep before heading to BNE to fly to #BOSC2016.",
  "id" : 750718585807319040,
  "created_at" : "2016-07-06 15:50:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ -28.02831564684195, 153.429200921104 ]
  },
  "id_str" : "750656826790686721",
  "text" : "Just to prove the lecture on how unlikely venomous bites are wrong: the Aussies are telling their favorite venom horror stories all evening.",
  "id" : 750656826790686721,
  "created_at" : "2016-07-06 11:45:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rutger Vos",
      "screen_name" : "rvosa",
      "indices" : [ 0, 6 ],
      "id_str" : "14819353",
      "id" : 14819353
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "750644418022105088",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ -28.02827744036312, 153.4294111073311 ]
  },
  "id_str" : "750646475021885441",
  "in_reply_to_user_id" : 14819353,
  "text" : "@rvosa I don\u2019t wanna try ;)",
  "id" : 750646475021885441,
  "in_reply_to_status_id" : 750644418022105088,
  "created_at" : "2016-07-06 11:04:00 +0000",
  "in_reply_to_screen_name" : "rvosa",
  "in_reply_to_user_id_str" : "14819353",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "750643022598119424",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ -28.02835451164854, 153.4291214980581 ]
  },
  "id_str" : "750643185836105728",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot biologists are all the same.",
  "id" : 750643185836105728,
  "in_reply_to_status_id" : 750643022598119424,
  "created_at" : "2016-07-06 10:50:56 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "smbe16",
      "indices" : [ 114, 121 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ -28.02831025400015, 153.4292017838652 ]
  },
  "id_str" : "750639959141281792",
  "text" : "\u00ABIf you die in Australia it\u2019s more likely to happen from something you eat tonight than from a venomous animal.\u00BB  #smbe16",
  "id" : 750639959141281792,
  "created_at" : "2016-07-06 10:38:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "smbe16",
      "indices" : [ 90, 97 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ -28.02832064120379, 153.4291897985268 ]
  },
  "id_str" : "750638010425749505",
  "text" : "\u00ABI know [the platypus] looks like roadkill, but trust me. It\u2019s alive, it\u2019s just resting.\u00BB #smbe16",
  "id" : 750638010425749505,
  "created_at" : "2016-07-06 10:30:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 14, 20 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "750634476363915264",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ -28.02831760313409, 153.4293651439093 ]
  },
  "id_str" : "750634780094443522",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @Lobot I asked for the most ridiculous ones!",
  "id" : 750634780094443522,
  "in_reply_to_status_id" : 750634476363915264,
  "created_at" : "2016-07-06 10:17:32 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "smbe16",
      "indices" : [ 98, 105 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ -28.02824911518558, 153.4292741390578 ]
  },
  "id_str" : "750634649697652736",
  "text" : "At the conference dinner they are playing \u201CCome to Australia, you might accidentally get killed\u201D. #smbe16",
  "id" : 750634649697652736,
  "created_at" : "2016-07-06 10:17:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/4r6cqGhGsp",
      "expanded_url" : "https:\/\/media.giphy.com\/media\/oy5qq4jzr9kJ2\/giphy.gif",
      "display_url" : "media.giphy.com\/media\/oy5qq4jz\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ -28.0278172122865, 153.4295255015702 ]
  },
  "id_str" : "750603603488808960",
  "text" : "They are playing the jackal in the lounge. Time for some West Wing cosplay. https:\/\/t.co\/4r6cqGhGsp",
  "id" : 750603603488808960,
  "created_at" : "2016-07-06 08:13:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gary Gates",
      "screen_name" : "DrGaryJGates",
      "indices" : [ 3, 16 ],
      "id_str" : "3178821942",
      "id" : 3178821942
    }, {
      "name" : "JAMAInternalMed",
      "screen_name" : "JAMAInternalMed",
      "indices" : [ 31, 47 ],
      "id_str" : "54664757",
      "id" : 54664757
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Bisexual",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "750598974478757888",
  "text" : "RT @DrGaryJGates: New research @JAMAInternalMed: #Bisexual men &amp; women highest severe psychological distress among LGBT https:\/\/t.co\/qwfJ1b\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "JAMAInternalMed",
        "screen_name" : "JAMAInternalMed",
        "indices" : [ 13, 29 ],
        "id_str" : "54664757",
        "id" : 54664757
      }, {
        "name" : "Bisexual Community",
        "screen_name" : "Bi_Calendar",
        "indices" : [ 130, 142 ],
        "id_str" : "623352774",
        "id" : 623352774
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Bisexual",
        "indices" : [ 31, 40 ]
      } ],
      "urls" : [ {
        "indices" : [ 106, 129 ],
        "url" : "https:\/\/t.co\/qwfJ1b5xz4",
        "expanded_url" : "http:\/\/ja.ma\/29nRgA9",
        "display_url" : "ja.ma\/29nRgA9"
      } ]
    },
    "geo" : { },
    "id_str" : "750363344041750528",
    "text" : "New research @JAMAInternalMed: #Bisexual men &amp; women highest severe psychological distress among LGBT https:\/\/t.co\/qwfJ1b5xz4 @Bi_Calendar",
    "id" : 750363344041750528,
    "created_at" : "2016-07-05 16:18:56 +0000",
    "user" : {
      "name" : "Gary Gates",
      "screen_name" : "DrGaryJGates",
      "protected" : false,
      "id_str" : "3178821942",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/819474281256144896\/bnMUsOIz_normal.jpg",
      "id" : 3178821942,
      "verified" : false
    }
  },
  "id" : 750598974478757888,
  "created_at" : "2016-07-06 07:55:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/750598541412794368\/photo\/1",
      "indices" : [ 59, 82 ],
      "url" : "https:\/\/t.co\/p4AvAltxg1",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CmqpYNuUMAAexMz.jpg",
      "id_str" : "750598521376485376",
      "id" : 750598521376485376,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CmqpYNuUMAAexMz.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      } ],
      "display_url" : "pic.twitter.com\/p4AvAltxg1"
    } ],
    "hashtags" : [ {
      "text" : "smbe16",
      "indices" : [ 51, 58 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ -28.02773467733341, 153.4294418805776 ]
  },
  "id_str" : "750598541412794368",
  "text" : "I think we might need to extend openSNP even more. #smbe16 https:\/\/t.co\/p4AvAltxg1",
  "id" : 750598541412794368,
  "created_at" : "2016-07-06 07:53:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 62 ],
      "url" : "https:\/\/t.co\/KjER5h3NyO",
      "expanded_url" : "http:\/\/existentialcomics.com\/comic\/139",
      "display_url" : "existentialcomics.com\/comic\/139"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ -28.028576, 153.429341 ]
  },
  "id_str" : "750566736806707206",
  "text" : "One is not born a badass motherfucker\u2026 https:\/\/t.co\/KjER5h3NyO",
  "id" : 750566736806707206,
  "created_at" : "2016-07-06 05:47:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "smbe16",
      "indices" : [ 8, 15 ]
    } ],
    "urls" : [ {
      "indices" : [ 39, 62 ],
      "url" : "https:\/\/t.co\/P2MDkw4zui",
      "expanded_url" : "http:\/\/whatshouldwecallgradschool.tumblr.com\/post\/146967270004",
      "display_url" : "whatshouldwecallgradschool.tumblr.com\/post\/146967270\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "750565682878840832",
  "text" : "Many at #smbe16 can relate, I assume.  https:\/\/t.co\/P2MDkw4zui",
  "id" : 750565682878840832,
  "created_at" : "2016-07-06 05:42:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/VWudMRf8yS",
      "expanded_url" : "http:\/\/journals.plos.org\/plosbiology\/article?id=10.1371%2Fjournal.pbio.1002501&utm_source=feedburner&utm_medium=feed&utm_campaign=Feed%3A+plosbiology%2FNewArticles+%28PLOS+Biology+-+New+Articles%29",
      "display_url" : "journals.plos.org\/plosbiology\/ar\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ -28.028719, 153.429124 ]
  },
  "id_str" : "750564340886110209",
  "text" : "Multiple Citation Indicators and Their Composite across Scientific Disciplines https:\/\/t.co\/VWudMRf8yS",
  "id" : 750564340886110209,
  "created_at" : "2016-07-06 05:37:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TheConstructor",
      "screen_name" : "TheConstructor",
      "indices" : [ 0, 15 ],
      "id_str" : "14362840",
      "id" : 14362840
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "750562535779213313",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ -28.02858271764192, 153.4293921091602 ]
  },
  "id_str" : "750562618503491585",
  "in_reply_to_user_id" : 14362840,
  "text" : "@TheConstructor no problem :D and thanks, it went well!",
  "id" : 750562618503491585,
  "in_reply_to_status_id" : 750562535779213313,
  "created_at" : "2016-07-06 05:30:47 +0000",
  "in_reply_to_screen_name" : "TheConstructor",
  "in_reply_to_user_id_str" : "14362840",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TheConstructor",
      "screen_name" : "TheConstructor",
      "indices" : [ 0, 15 ],
      "id_str" : "14362840",
      "id" : 14362840
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "750561808516255744",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ -28.02854167554781, 153.429401570705 ]
  },
  "id_str" : "750561996492464128",
  "in_reply_to_user_id" : 14362840,
  "text" : "@TheConstructor that\u2019s 9:30 in this time zone. So it was 6h ago :p",
  "id" : 750561996492464128,
  "in_reply_to_status_id" : 750561808516255744,
  "created_at" : "2016-07-06 05:28:19 +0000",
  "in_reply_to_screen_name" : "TheConstructor",
  "in_reply_to_user_id_str" : "14362840",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/750510585750491136\/photo\/1",
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/90mgp3BBEU",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CmpZZhxUcAAsJcO.jpg",
      "id_str" : "750510583007440896",
      "id" : 750510583007440896,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CmpZZhxUcAAsJcO.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 272
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 272
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 272
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 272
      } ],
      "display_url" : "pic.twitter.com\/90mgp3BBEU"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ -28.004964, 153.423594 ]
  },
  "id_str" : "750510585750491136",
  "text" : "Over the next 6 days I will have spent some nights in each of the time zones shown. \uD83D\uDE31 https:\/\/t.co\/90mgp3BBEU",
  "id" : 750510585750491136,
  "created_at" : "2016-07-06 02:04:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "smbe16",
      "indices" : [ 64, 71 ]
    } ],
    "urls" : [ {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/S0ZvK1rDCt",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/750235429899677696",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "750235429899677696",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ -28.02795224839068, 153.4293397095536 ]
  },
  "id_str" : "750457957951811585",
  "in_reply_to_user_id" : 14286491,
  "text" : "I\u2019m not a morning person. So come by and see me trying to cope. #smbe16 https:\/\/t.co\/S0ZvK1rDCt",
  "id" : 750457957951811585,
  "in_reply_to_status_id" : 750235429899677696,
  "created_at" : "2016-07-05 22:34:54 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 43 ],
      "url" : "https:\/\/t.co\/9YAUVef42M",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BHftJl7jGIV\/",
      "display_url" : "instagram.com\/p\/BHftJl7jGIV\/"
    } ]
  },
  "geo" : { },
  "id_str" : "750445902490468352",
  "text" : "Love All Capitalism https:\/\/t.co\/9YAUVef42M",
  "id" : 750445902490468352,
  "created_at" : "2016-07-05 21:47:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helen Taylor",
      "screen_name" : "HelenTaylorCG",
      "indices" : [ 73, 87 ],
      "id_str" : "3058881006",
      "id" : 3058881006
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/750266547688484864\/photo\/1",
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/MPFbUqTCEG",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cml7cNgVUAAAiTf.jpg",
      "id_str" : "750266537525727232",
      "id" : 750266537525727232,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cml7cNgVUAAAiTf.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 384
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 384
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 384
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 384
      } ],
      "display_url" : "pic.twitter.com\/MPFbUqTCEG"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ -28.02761320889962, 153.4291558248758 ]
  },
  "id_str" : "750266547688484864",
  "text" : "Now I can add the missing tree at least temporarily onto my skin. Thanks @HelenTaylorCG for the tip. https:\/\/t.co\/MPFbUqTCEG",
  "id" : 750266547688484864,
  "created_at" : "2016-07-05 09:54:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "750235429899677696",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ -28.0284458463139, 153.4294754539467 ]
  },
  "id_str" : "750235911451865088",
  "in_reply_to_user_id" : 14286491,
  "text" : "A lot of it will actually be about how to recover complete genomes from eukaryotic metagenomes.",
  "id" : 750235911451865088,
  "in_reply_to_status_id" : 750235429899677696,
  "created_at" : "2016-07-05 07:52:34 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "smbe16",
      "indices" : [ 103, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/RGY5M11yl5",
      "expanded_url" : "http:\/\/smbe-2016.p.asnevents.com.au\/days\/2016-07-06\/abstract\/34912",
      "display_url" : "smbe-2016.p.asnevents.com.au\/days\/2016-07-0\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ -28.02862501440881, 153.4292422546842 ]
  },
  "id_str" : "750235429899677696",
  "text" : "If you\u2019re up early tomorrow: I\u2019ll talk about the genomic footprint of lichenization at 0930 in room 6. #smbe16 https:\/\/t.co\/RGY5M11yl5",
  "id" : 750235429899677696,
  "created_at" : "2016-07-05 07:50:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/4n990kRkGV",
      "expanded_url" : "https:\/\/twitter.com\/PhilippBayer\/status\/750229473513992192",
      "display_url" : "twitter.com\/PhilippBayer\/s\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ -28.02853279127941, 153.4294550978547 ]
  },
  "id_str" : "750232753073819648",
  "text" : "I still laugh about that this was published in PNAS of all places. Mothership of all dubious fMRI studies. https:\/\/t.co\/4n990kRkGV",
  "id" : 750232753073819648,
  "created_at" : "2016-07-05 07:40:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Atossa Araxia Abrahamian",
      "screen_name" : "atossaaraxia",
      "indices" : [ 3, 16 ],
      "id_str" : "228437800",
      "id" : 228437800
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/n7mbFeBA9o",
      "expanded_url" : "https:\/\/www.foreignaffairs.com\/articles\/kuwait\/2016-06-30\/stateless-and-sale-gulf",
      "display_url" : "foreignaffairs.com\/articles\/kuwai\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "750229914327011328",
  "text" : "RT @atossaaraxia: I'm glad the Comoros\/UAE\/Kuwait citizenship scheme is finally getting more attention https:\/\/t.co\/n7mbFeBA9o",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 85, 108 ],
        "url" : "https:\/\/t.co\/n7mbFeBA9o",
        "expanded_url" : "https:\/\/www.foreignaffairs.com\/articles\/kuwait\/2016-06-30\/stateless-and-sale-gulf",
        "display_url" : "foreignaffairs.com\/articles\/kuwai\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "750224444250066944",
    "text" : "I'm glad the Comoros\/UAE\/Kuwait citizenship scheme is finally getting more attention https:\/\/t.co\/n7mbFeBA9o",
    "id" : 750224444250066944,
    "created_at" : "2016-07-05 07:07:00 +0000",
    "user" : {
      "name" : "Atossa Araxia Abrahamian",
      "screen_name" : "atossaaraxia",
      "protected" : false,
      "id_str" : "228437800",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/707884522738728960\/VqnZwF27_normal.jpg",
      "id" : 228437800,
      "verified" : true
    }
  },
  "id" : 750229914327011328,
  "created_at" : "2016-07-05 07:28:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Catherine Grueber",
      "screen_name" : "CEGrueber",
      "indices" : [ 3, 13 ],
      "id_str" : "2772661626",
      "id" : 2772661626
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "750224129500934144",
  "text" : "RT @CEGrueber: Sophisticated genetic models show how medieval religious reform 1000 years ago shaped the genome of modern chickens! @liisal\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Liisa Loog",
        "screen_name" : "liisaloog",
        "indices" : [ 117, 127 ],
        "id_str" : "2901021333",
        "id" : 2901021333
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SMBE16",
        "indices" : [ 128, 135 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "750223865184264192",
    "text" : "Sophisticated genetic models show how medieval religious reform 1000 years ago shaped the genome of modern chickens! @liisaloog #SMBE16",
    "id" : 750223865184264192,
    "created_at" : "2016-07-05 07:04:42 +0000",
    "user" : {
      "name" : "Catherine Grueber",
      "screen_name" : "CEGrueber",
      "protected" : false,
      "id_str" : "2772661626",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/504563000775163904\/CwT8PPgr_normal.jpeg",
      "id" : 2772661626,
      "verified" : false
    }
  },
  "id" : 750224129500934144,
  "created_at" : "2016-07-05 07:05:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helen Taylor",
      "screen_name" : "HelenTaylorCG",
      "indices" : [ 82, 96 ],
      "id_str" : "3058881006",
      "id" : 3058881006
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "smbe16",
      "indices" : [ 97, 104 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ -28.02856486059945, 153.4293761199447 ]
  },
  "id_str" : "750196361723670528",
  "text" : "Doing a \u201Cgood sperm vs bad sperm\u201D GWAS to study effects of inbreeding depression. @HelenTaylorCG #smbe16",
  "id" : 750196361723670528,
  "created_at" : "2016-07-05 05:15:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "smbe16",
      "indices" : [ 57, 64 ]
    } ],
    "urls" : [ {
      "indices" : [ 65, 88 ],
      "url" : "https:\/\/t.co\/X34syM6tTk",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/750194953125453824",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "750194953125453824",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ -28.02851471666113, 153.4293643918504 ]
  },
  "id_str" : "750195167970201600",
  "in_reply_to_user_id" : 14286491,
  "text" : "Designed mobile sperm lab for just that purpose, with \uD83D\uDD2C. #smbe16 https:\/\/t.co\/X34syM6tTk",
  "id" : 750195167970201600,
  "in_reply_to_status_id" : 750194953125453824,
  "created_at" : "2016-07-05 05:10:40 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helen Taylor",
      "screen_name" : "HelenTaylorCG",
      "indices" : [ 117, 131 ],
      "id_str" : "3058881006",
      "id" : 3058881006
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "smbe16",
      "indices" : [ 132, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ -28.02854260063737, 153.4293397087916 ]
  },
  "id_str" : "750194953125453824",
  "text" : "Wanna measure the movement speed of semen right there at the point of collection, especially when on remote islands. @HelenTaylorCG #smbe16",
  "id" : 750194953125453824,
  "created_at" : "2016-07-05 05:09:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "smbe16",
      "indices" : [ 96, 103 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ -28.02770394042744, 153.429250573146 ]
  },
  "id_str" : "750190180993150977",
  "text" : "Now: Emily Baker on Lager-brewing yeast hybrids: Celebrating 500 years German Beer Brewing Law. #smbe16",
  "id" : 750190180993150977,
  "created_at" : "2016-07-05 04:50:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "smbe16",
      "indices" : [ 117, 124 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ -28.02779839214358, 153.4292828482386 ]
  },
  "id_str" : "750181262728450048",
  "text" : "Damn, I\u2019m happy I don\u2019t have to work with those dinoflagellate genomes: repetitive and range between 1.5 to 112 Gbp! #smbe16",
  "id" : 750181262728450048,
  "created_at" : "2016-07-05 04:15:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Matute",
      "screen_name" : "danielrmatute",
      "indices" : [ 0, 14 ],
      "id_str" : "1413173948",
      "id" : 1413173948
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "750137827581579264",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ -28.02859036548045, 153.4293807054466 ]
  },
  "id_str" : "750138034293657600",
  "in_reply_to_user_id" : 1413173948,
  "text" : "@danielrmatute never heard the term before myself, just recognized the animation :-)",
  "id" : 750138034293657600,
  "in_reply_to_status_id" : 750137827581579264,
  "created_at" : "2016-07-05 01:23:38 +0000",
  "in_reply_to_screen_name" : "danielrmatute",
  "in_reply_to_user_id_str" : "1413173948",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Matute",
      "screen_name" : "danielrmatute",
      "indices" : [ 0, 14 ],
      "id_str" : "1413173948",
      "id" : 1413173948
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 38 ],
      "url" : "https:\/\/t.co\/NUGbhw9qyO",
      "expanded_url" : "https:\/\/en.m.wikipedia.org\/wiki\/Wave_(audience)",
      "display_url" : "en.m.wikipedia.org\/wiki\/Wave_(aud\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "750137215804510208",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ -28.02866961892418, 153.4293225718912 ]
  },
  "id_str" : "750137492074958849",
  "in_reply_to_user_id" : 1413173948,
  "text" : "@danielrmatute https:\/\/t.co\/NUGbhw9qyO",
  "id" : 750137492074958849,
  "in_reply_to_status_id" : 750137215804510208,
  "created_at" : "2016-07-05 01:21:29 +0000",
  "in_reply_to_screen_name" : "danielrmatute",
  "in_reply_to_user_id_str" : "1413173948",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "750102459972853760",
  "text" : "\u00ABI slept so long after the flight, for like 9 hours!\u00BB \u2013 \u00ABYou mean you slept like a regular human being for once?\u00BB",
  "id" : 750102459972853760,
  "created_at" : "2016-07-04 23:02:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helen Taylor",
      "screen_name" : "HelenTaylorCG",
      "indices" : [ 0, 14 ],
      "id_str" : "3058881006",
      "id" : 3058881006
    }, {
      "name" : "Biomatters",
      "screen_name" : "Biomatters",
      "indices" : [ 15, 26 ],
      "id_str" : "190564949",
      "id" : 190564949
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/750101633107832832\/photo\/1",
      "indices" : [ 63, 86 ],
      "url" : "https:\/\/t.co\/O18WpdbQef",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CmjldCrUsAAIEwq.jpg",
      "id_str" : "750101625054736384",
      "id" : 750101625054736384,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CmjldCrUsAAIEwq.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 384
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 384
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 384
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 384
      } ],
      "display_url" : "pic.twitter.com\/O18WpdbQef"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "750098707916296192",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ -28.00491258416899, 153.4235338446055 ]
  },
  "id_str" : "750101633107832832",
  "in_reply_to_user_id" : 3058881006,
  "text" : "@HelenTaylorCG @Biomatters left out the most important part! \uD83D\uDE02 https:\/\/t.co\/O18WpdbQef",
  "id" : 750101633107832832,
  "in_reply_to_status_id" : 750098707916296192,
  "created_at" : "2016-07-04 22:59:00 +0000",
  "in_reply_to_screen_name" : "HelenTaylorCG",
  "in_reply_to_user_id_str" : "3058881006",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BOSC2016",
      "indices" : [ 32, 41 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "750095879827181568",
  "text" : "Having a draft of my slides for #BOSC2016 \uD83C\uDF89",
  "id" : 750095879827181568,
  "created_at" : "2016-07-04 22:36:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/750001917783187458\/photo\/1",
      "indices" : [ 32, 55 ],
      "url" : "https:\/\/t.co\/4fs6GJfRBQ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CmiKwnrUsAMdEfj.jpg",
      "id_str" : "750001905846235139",
      "id" : 750001905846235139,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CmiKwnrUsAMdEfj.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 384
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 384
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 384
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 384
      } ],
      "display_url" : "pic.twitter.com\/4fs6GJfRBQ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ -28.00493264723305, 153.4236380311715 ]
  },
  "id_str" : "750001917783187458",
  "text" : "Vandalizing the price list: $75 https:\/\/t.co\/4fs6GJfRBQ",
  "id" : 750001917783187458,
  "created_at" : "2016-07-04 16:22:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan Rice",
      "screen_name" : "alanmrice",
      "indices" : [ 0, 10 ],
      "id_str" : "6872082",
      "id" : 6872082
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "749932228033978368",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ -28.00492434107742, 153.4237617687043 ]
  },
  "id_str" : "749941256340402176",
  "in_reply_to_user_id" : 6872082,
  "text" : "@alanmrice \uD83D\uDC96",
  "id" : 749941256340402176,
  "in_reply_to_status_id" : 749932228033978368,
  "created_at" : "2016-07-04 12:21:43 +0000",
  "in_reply_to_screen_name" : "alanmrice",
  "in_reply_to_user_id_str" : "6872082",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Blin",
      "screen_name" : "kaiblin",
      "indices" : [ 0, 8 ],
      "id_str" : "124202458",
      "id" : 124202458
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "749919621713649664",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ -28.02823692097145, 153.4311467596827 ]
  },
  "id_str" : "749920519416262656",
  "in_reply_to_user_id" : 124202458,
  "text" : "@kaiblin I tend to use the term relative to the status quo that used to be.",
  "id" : 749920519416262656,
  "in_reply_to_status_id" : 749919621713649664,
  "created_at" : "2016-07-04 10:59:19 +0000",
  "in_reply_to_screen_name" : "kaiblin",
  "in_reply_to_user_id_str" : "124202458",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Blin",
      "screen_name" : "kaiblin",
      "indices" : [ 0, 8 ],
      "id_str" : "124202458",
      "id" : 124202458
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "749916169843474433",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ -28.02827097951152, 153.4313213879739 ]
  },
  "id_str" : "749918657434624001",
  "in_reply_to_user_id" : 124202458,
  "text" : "@kaiblin oh, you already started ignoring the UK? :p",
  "id" : 749918657434624001,
  "in_reply_to_status_id" : 749916169843474433,
  "created_at" : "2016-07-04 10:51:55 +0000",
  "in_reply_to_screen_name" : "kaiblin",
  "in_reply_to_user_id_str" : "124202458",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan Rice",
      "screen_name" : "alanmrice",
      "indices" : [ 0, 10 ],
      "id_str" : "6872082",
      "id" : 6872082
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "749912550167310336",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ -28.0283124838893, 153.431256086652 ]
  },
  "id_str" : "749912862441680896",
  "in_reply_to_user_id" : 6872082,
  "text" : "@alanmrice perfect. See you! And no worries mate :)",
  "id" : 749912862441680896,
  "in_reply_to_status_id" : 749912550167310336,
  "created_at" : "2016-07-04 10:28:53 +0000",
  "in_reply_to_screen_name" : "alanmrice",
  "in_reply_to_user_id_str" : "6872082",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan Rice",
      "screen_name" : "alanmrice",
      "indices" : [ 0, 10 ],
      "id_str" : "6872082",
      "id" : 6872082
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "749910947116912640",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ -28.02833607998286, 153.4312571604452 ]
  },
  "id_str" : "749911129854316544",
  "in_reply_to_user_id" : 6872082,
  "text" : "@alanmrice how many are you?",
  "id" : 749911129854316544,
  "in_reply_to_status_id" : 749910947116912640,
  "created_at" : "2016-07-04 10:22:00 +0000",
  "in_reply_to_screen_name" : "alanmrice",
  "in_reply_to_user_id_str" : "6872082",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Blin",
      "screen_name" : "kaiblin",
      "indices" : [ 0, 8 ],
      "id_str" : "124202458",
      "id" : 124202458
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "749909900042600448",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ -28.02846569251744, 153.4312831926626 ]
  },
  "id_str" : "749909959463149569",
  "in_reply_to_user_id" : 124202458,
  "text" : "@kaiblin nah, the EU.",
  "id" : 749909959463149569,
  "in_reply_to_status_id" : 749909900042600448,
  "created_at" : "2016-07-04 10:17:21 +0000",
  "in_reply_to_screen_name" : "kaiblin",
  "in_reply_to_user_id_str" : "124202458",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan Rice",
      "screen_name" : "alanmrice",
      "indices" : [ 0, 10 ],
      "id_str" : "6872082",
      "id" : 6872082
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/749909915678814208\/photo\/1",
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/txqctHYeWn",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cmg3FSBUcAA_-cp.jpg",
      "id_str" : "749909901833433088",
      "id" : 749909901833433088,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cmg3FSBUcAA_-cp.jpg",
      "sizes" : [ {
        "h" : 384,
        "resize" : "fit",
        "w" : 512
      }, {
        "h" : 384,
        "resize" : "fit",
        "w" : 512
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 384,
        "resize" : "fit",
        "w" : 512
      }, {
        "h" : 384,
        "resize" : "fit",
        "w" : 512
      } ],
      "display_url" : "pic.twitter.com\/txqctHYeWn"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "749909587491377153",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ -28.02831316304863, 153.4312911243964 ]
  },
  "id_str" : "749909915678814208",
  "in_reply_to_user_id" : 6872082,
  "text" : "@alanmrice we\u2019re at Bonchu Thai. Could make room for 4 people right now. https:\/\/t.co\/txqctHYeWn",
  "id" : 749909915678814208,
  "in_reply_to_status_id" : 749909587491377153,
  "created_at" : "2016-07-04 10:17:11 +0000",
  "in_reply_to_screen_name" : "alanmrice",
  "in_reply_to_user_id_str" : "6872082",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ -28.02766893605833, 153.4292189526917 ]
  },
  "id_str" : "749904872531603456",
  "text" : "Wow, usually I end up traveling abroad to regions in crisis. Looks like this time I\u2019ll return to one\u2026",
  "id" : 749904872531603456,
  "created_at" : "2016-07-04 09:57:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SMBE16",
      "indices" : [ 78, 85 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/D0qUHIju3n",
      "expanded_url" : "https:\/\/twitter.com\/alanmrice\/status\/749867234873356289",
      "display_url" : "twitter.com\/alanmrice\/stat\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ -28.02765060530819, 153.429206384544 ]
  },
  "id_str" : "749886535638462464",
  "text" : "Go and visit him. He\u2019s doing a great job, especially considering the jet lag! #SMBE16 https:\/\/t.co\/D0qUHIju3n",
  "id" : 749886535638462464,
  "created_at" : "2016-07-04 08:44:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SMBE16",
      "indices" : [ 131, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ -28.02866261294507, 153.4293787127226 ]
  },
  "id_str" : "749873693107511297",
  "text" : "Manually curating 30k potentially interesting papers? \uD83D\uDE31 That sounds like an ideal task for crowdsourcing it to citizen scientists. #SMBE16",
  "id" : 749873693107511297,
  "created_at" : "2016-07-04 07:53:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Edmunds",
      "screen_name" : "SCEdmunds",
      "indices" : [ 0, 10 ],
      "id_str" : "176024190",
      "id" : 176024190
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "749871029736976385",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ -28.02854079088086, 153.4294728602822 ]
  },
  "id_str" : "749871208439492609",
  "in_reply_to_user_id" : 176024190,
  "text" : "@SCEdmunds \uD83C\uDF89\uD83C\uDF89\uD83C\uDF89 awesome, finally! Started to miss you already, it\u2019s been nearly 3 months!",
  "id" : 749871208439492609,
  "in_reply_to_status_id" : 749871029736976385,
  "created_at" : "2016-07-04 07:43:22 +0000",
  "in_reply_to_screen_name" : "SCEdmunds",
  "in_reply_to_user_id_str" : "176024190",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Edmunds",
      "screen_name" : "SCEdmunds",
      "indices" : [ 0, 10 ],
      "id_str" : "176024190",
      "id" : 176024190
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "749870443285196800",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ -28.02854079088086, 153.4294728602822 ]
  },
  "id_str" : "749870707119562752",
  "in_reply_to_user_id" : 176024190,
  "text" : "@SCEdmunds will you be there again?",
  "id" : 749870707119562752,
  "in_reply_to_status_id" : 749870443285196800,
  "created_at" : "2016-07-04 07:41:23 +0000",
  "in_reply_to_screen_name" : "SCEdmunds",
  "in_reply_to_user_id_str" : "176024190",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Edmunds",
      "screen_name" : "SCEdmunds",
      "indices" : [ 0, 10 ],
      "id_str" : "176024190",
      "id" : 176024190
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "749870443285196800",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ -28.02850240812797, 153.429491514852 ]
  },
  "id_str" : "749870679458091009",
  "in_reply_to_user_id" : 176024190,
  "text" : "@SCEdmunds thanks, mine will be on Wednesday (and is already prepped) but I\u2019ll go directly to BOSC and need to do my slides for that.",
  "id" : 749870679458091009,
  "in_reply_to_status_id" : 749870443285196800,
  "created_at" : "2016-07-04 07:41:16 +0000",
  "in_reply_to_screen_name" : "SCEdmunds",
  "in_reply_to_user_id_str" : "176024190",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/4NA2GttuUJ",
      "expanded_url" : "http:\/\/www.newyorker.com\/science\/maria-konnikova\/casual-sex-everyone-is-doing-it",
      "display_url" : "newyorker.com\/science\/maria-\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ -28.028614, 153.42942 ]
  },
  "id_str" : "749869795575607297",
  "text" : "\u00ABThe dirty little secret of casual sex today is not that we\u2019re having it but that we\u2019re not sharing our experiences\u00BB https:\/\/t.co\/4NA2GttuUJ",
  "id" : 749869795575607297,
  "created_at" : "2016-07-04 07:37:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Edmunds",
      "screen_name" : "SCEdmunds",
      "indices" : [ 0, 10 ],
      "id_str" : "176024190",
      "id" : 176024190
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "749868177014681600",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ -28.0285904153464, 153.4293830094794 ]
  },
  "id_str" : "749868501678977024",
  "in_reply_to_user_id" : 176024190,
  "text" : "@SCEdmunds I don\u2019t think so, I just laughed hard when I heard it and then went on to work on my slides.",
  "id" : 749868501678977024,
  "in_reply_to_status_id" : 749868177014681600,
  "created_at" : "2016-07-04 07:32:37 +0000",
  "in_reply_to_screen_name" : "SCEdmunds",
  "in_reply_to_user_id_str" : "176024190",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Greg Slodkowicz",
      "screen_name" : "greg_slodkowicz",
      "indices" : [ 11, 27 ],
      "id_str" : "16602000",
      "id" : 16602000
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "brexit",
      "indices" : [ 69, 76 ]
    }, {
      "text" : "SMBE16",
      "indices" : [ 97, 104 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ -28.02851113506676, 153.4294595465172 ]
  },
  "id_str" : "749868400072007680",
  "text" : "Very nice, @greg_slodkowicz putting \u201Ckeep calm and don\u2019t mention the #brexit\u201D on his last slide. #SMBE16",
  "id" : 749868400072007680,
  "created_at" : "2016-07-04 07:32:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SMBE16",
      "indices" : [ 107, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/rPsYZyAfCK",
      "expanded_url" : "https:\/\/twitter.com\/3rdreviewer\/status\/749857652063080448",
      "display_url" : "twitter.com\/3rdreviewer\/st\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ -28.02853187740669, 153.4294291020416 ]
  },
  "id_str" : "749861247873540096",
  "text" : "Simulating multiple nucleotide mutations +\/- always yield false positive inferences of positive selection. #SMBE16 https:\/\/t.co\/rPsYZyAfCK",
  "id" : 749861247873540096,
  "created_at" : "2016-07-04 07:03:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SMBE16",
      "indices" : [ 92, 99 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ -28.02754130999999, 153.4323144099999 ]
  },
  "id_str" : "749855853688164353",
  "text" : "\u00ABThe first thing you\u2019ll notice about our model: we\u2019ve put it on a diet, there\u2019s no more \u03C0.\u00BB #SMBE16",
  "id" : 749855853688164353,
  "created_at" : "2016-07-04 06:42:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luc Henry",
      "screen_name" : "heluc",
      "indices" : [ 0, 6 ],
      "id_str" : "850645992",
      "id" : 850645992
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "749840435451920385",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ -28.02625788431573, 153.4280779493632 ]
  },
  "id_str" : "749841130942926848",
  "in_reply_to_user_id" : 850645992,
  "text" : "@heluc \uD83D\uDC4D\uD83D\uDE02",
  "id" : 749841130942926848,
  "in_reply_to_status_id" : 749840435451920385,
  "created_at" : "2016-07-04 05:43:51 +0000",
  "in_reply_to_screen_name" : "heluc",
  "in_reply_to_user_id_str" : "850645992",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "smbe16",
      "indices" : [ 82, 89 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ -28.02849594654568, 153.4294658270109 ]
  },
  "id_str" : "749831915444711424",
  "text" : "Now presenting: The Beijing Institute of Genomics. Not to be confused with BGI. \uD83D\uDE02 #smbe16",
  "id" : 749831915444711424,
  "created_at" : "2016-07-04 05:07:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anna MacDonald",
      "screen_name" : "Dr_AnnaM",
      "indices" : [ 0, 9 ],
      "id_str" : "842669612",
      "id" : 842669612
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "749806620801011712",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ -28.02605206586944, 153.4340100166078 ]
  },
  "id_str" : "749807767242747904",
  "in_reply_to_user_id" : 842669612,
  "text" : "@Dr_AnnaM sure, sounds good to me!",
  "id" : 749807767242747904,
  "in_reply_to_status_id" : 749806620801011712,
  "created_at" : "2016-07-04 03:31:17 +0000",
  "in_reply_to_screen_name" : "Dr_AnnaM",
  "in_reply_to_user_id_str" : "842669612",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "smbe16",
      "indices" : [ 59, 66 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ -28.02794272964397, 153.4288239087961 ]
  },
  "id_str" : "749794052732645376",
  "text" : "Will there be a Twitter lunch meeting at some point again? #smbe16",
  "id" : 749794052732645376,
  "created_at" : "2016-07-04 02:36:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luc Henry",
      "screen_name" : "heluc",
      "indices" : [ 14, 20 ],
      "id_str" : "850645992",
      "id" : 850645992
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 45 ],
      "url" : "https:\/\/t.co\/tzKsSCRjDg",
      "expanded_url" : "https:\/\/twitter.com\/biocrusoe\/status\/749760422681731072",
      "display_url" : "twitter.com\/biocrusoe\/stat\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ -28.02863116778938, 153.4292652587691 ]
  },
  "id_str" : "749761277652668416",
  "text" : "Look at this, @heluc! https:\/\/t.co\/tzKsSCRjDg",
  "id" : 749761277652668416,
  "created_at" : "2016-07-04 00:26:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SMBE16",
      "indices" : [ 95, 102 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "749747851807174656",
  "text" : "RL: \u00ABUse all the biology if you know it.\u00BB Knowledge still beats purely data-driven algorithms. #SMBE16",
  "id" : 749747851807174656,
  "created_at" : "2016-07-03 23:33:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SMBE16",
      "indices" : [ 108, 115 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "749743969186160640",
  "text" : "Rob Lanfear: Worry about what you\u2019re doing wrong, when your method gives results much better than expected. #SMBE16",
  "id" : 749743969186160640,
  "created_at" : "2016-07-03 23:17:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/749602923227688960\/photo\/1",
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/spnatr2x65",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cmcf4jxVMAI501H.jpg",
      "id_str" : "749602919515762690",
      "id" : 749602919515762690,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cmcf4jxVMAI501H.jpg",
      "sizes" : [ {
        "h" : 618,
        "resize" : "fit",
        "w" : 2391
      }, {
        "h" : 176,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 310,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 529,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/spnatr2x65"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ -28.005047, 153.423563 ]
  },
  "id_str" : "749602923227688960",
  "text" : "One of the reasons why Stephen Jay Gould will be dearly missed for a while to come. https:\/\/t.co\/spnatr2x65",
  "id" : 749602923227688960,
  "created_at" : "2016-07-03 13:57:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Staley",
      "screen_name" : "peterstaley",
      "indices" : [ 3, 15 ],
      "id_str" : "30453099",
      "id" : 30453099
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/peterstaley\/status\/749588542540492800\/photo\/1",
      "indices" : [ 48, 71 ],
      "url" : "https:\/\/t.co\/JhdLX0K1IF",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CmcStLsWAAARHi7.jpg",
      "id_str" : "749588430422671360",
      "id" : 749588430422671360,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CmcStLsWAAARHi7.jpg",
      "sizes" : [ {
        "h" : 936,
        "resize" : "fit",
        "w" : 543
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 394
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 936,
        "resize" : "fit",
        "w" : 543
      }, {
        "h" : 936,
        "resize" : "fit",
        "w" : 543
      } ],
      "display_url" : "pic.twitter.com\/JhdLX0K1IF"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "749593883126820864",
  "text" : "RT @peterstaley: 35 years ago, today, page A20. https:\/\/t.co\/JhdLX0K1IF",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/peterstaley\/status\/749588542540492800\/photo\/1",
        "indices" : [ 31, 54 ],
        "url" : "https:\/\/t.co\/JhdLX0K1IF",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CmcStLsWAAARHi7.jpg",
        "id_str" : "749588430422671360",
        "id" : 749588430422671360,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CmcStLsWAAARHi7.jpg",
        "sizes" : [ {
          "h" : 936,
          "resize" : "fit",
          "w" : 543
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 394
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 936,
          "resize" : "fit",
          "w" : 543
        }, {
          "h" : 936,
          "resize" : "fit",
          "w" : 543
        } ],
        "display_url" : "pic.twitter.com\/JhdLX0K1IF"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "749588542540492800",
    "text" : "35 years ago, today, page A20. https:\/\/t.co\/JhdLX0K1IF",
    "id" : 749588542540492800,
    "created_at" : "2016-07-03 13:00:09 +0000",
    "user" : {
      "name" : "Peter Staley",
      "screen_name" : "peterstaley",
      "protected" : false,
      "id_str" : "30453099",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/680036738618638336\/MzBbKe_1_normal.jpg",
      "id" : 30453099,
      "verified" : true
    }
  },
  "id" : 749593883126820864,
  "created_at" : "2016-07-03 13:21:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Atossa Araxia Abrahamian",
      "screen_name" : "atossaaraxia",
      "indices" : [ 3, 16 ],
      "id_str" : "228437800",
      "id" : 228437800
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "749580140867297281",
  "text" : "RT @atossaaraxia: The French Parliament can pass a bill naturalizing Brits currently living in France or married to a French citizen https:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/OqzrgjUc2Y",
        "expanded_url" : "https:\/\/twitter.com\/patrickweil1\/status\/749540591306940416",
        "display_url" : "twitter.com\/patrickweil1\/s\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "749554909104771072",
    "text" : "The French Parliament can pass a bill naturalizing Brits currently living in France or married to a French citizen https:\/\/t.co\/OqzrgjUc2Y",
    "id" : 749554909104771072,
    "created_at" : "2016-07-03 10:46:31 +0000",
    "user" : {
      "name" : "Atossa Araxia Abrahamian",
      "screen_name" : "atossaaraxia",
      "protected" : false,
      "id_str" : "228437800",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/707884522738728960\/VqnZwF27_normal.jpg",
      "id" : 228437800,
      "verified" : true
    }
  },
  "id" : 749580140867297281,
  "created_at" : "2016-07-03 12:26:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uD83D\uDCABKelsey Merkley \uD83D\uDCAB",
      "screen_name" : "bella_velo",
      "indices" : [ 3, 14 ],
      "id_str" : "6745972",
      "id" : 6745972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/2RGwkNW3vg",
      "expanded_url" : "http:\/\/www.npr.org\/2008\/10\/09\/95520570\/dolly-partons-jolene-still-haunts-singers?utm_source=facebook.com&utm_medium=social&utm_campaign=npr&utm_term=nprnews&utm_content=20160703",
      "display_url" : "npr.org\/2008\/10\/09\/955\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "749579309271003137",
  "text" : "RT @bella_velo: Done of my favourite song - Dolly Parton's 'Jolene' Still Haunts Singers  https:\/\/t.co\/2RGwkNW3vg",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 74, 97 ],
        "url" : "https:\/\/t.co\/2RGwkNW3vg",
        "expanded_url" : "http:\/\/www.npr.org\/2008\/10\/09\/95520570\/dolly-partons-jolene-still-haunts-singers?utm_source=facebook.com&utm_medium=social&utm_campaign=npr&utm_term=nprnews&utm_content=20160703",
        "display_url" : "npr.org\/2008\/10\/09\/955\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "749549360871010306",
    "text" : "Done of my favourite song - Dolly Parton's 'Jolene' Still Haunts Singers  https:\/\/t.co\/2RGwkNW3vg",
    "id" : 749549360871010306,
    "created_at" : "2016-07-03 10:24:28 +0000",
    "user" : {
      "name" : "\uD83D\uDCABKelsey Merkley \uD83D\uDCAB",
      "screen_name" : "bella_velo",
      "protected" : false,
      "id_str" : "6745972",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/875913994929934336\/1aiBO2bG_normal.jpg",
      "id" : 6745972,
      "verified" : false
    }
  },
  "id" : 749579309271003137,
  "created_at" : "2016-07-03 12:23:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ -28.00094475255838, 153.4296111925149 ]
  },
  "id_str" : "749567187799580672",
  "text" : "\u00ABDo you folks have any wishes for tonight?\u00BB \u2014 \u00ABCould you try to not get us into an academic barroom fight today?\u00BB",
  "id" : 749567187799580672,
  "created_at" : "2016-07-03 11:35:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 57 ],
      "url" : "https:\/\/t.co\/9HDPx7hM3q",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BHZYFJQDblJ\/",
      "display_url" : "instagram.com\/p\/BHZYFJQDblJ\/"
    } ]
  },
  "geo" : { },
  "id_str" : "749555145126600708",
  "text" : "I heard you like quatrefoils, so\u2026 https:\/\/t.co\/9HDPx7hM3q",
  "id" : 749555145126600708,
  "created_at" : "2016-07-03 10:47:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 33 ],
      "url" : "https:\/\/t.co\/1aqAxoPmkf",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BHY1jiYDQKr\/",
      "display_url" : "instagram.com\/p\/BHY1jiYDQKr\/"
    } ]
  },
  "geo" : { },
  "id_str" : "749479223522430980",
  "text" : "Misplaced https:\/\/t.co\/1aqAxoPmkf",
  "id" : 749479223522430980,
  "created_at" : "2016-07-03 05:45:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Craig Primmer",
      "screen_name" : "FishConGen",
      "indices" : [ 0, 11 ],
      "id_str" : "562495967",
      "id" : 562495967
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "749472452686655488",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ -28.00498540462446, 153.4236906096611 ]
  },
  "id_str" : "749475646313668608",
  "in_reply_to_user_id" : 562495967,
  "text" : "@FishConGen shall try that one. Thanks for the suggestions!",
  "id" : 749475646313668608,
  "in_reply_to_status_id" : 749472452686655488,
  "created_at" : "2016-07-03 05:31:33 +0000",
  "in_reply_to_screen_name" : "FishConGen",
  "in_reply_to_user_id_str" : "562495967",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/749461844453040128\/photo\/1",
      "indices" : [ 45, 68 ],
      "url" : "https:\/\/t.co\/oW8YHMfKoR",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CmafkUFVMAAp7Fl.jpg",
      "id_str" : "749461834218942464",
      "id" : 749461834218942464,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CmafkUFVMAAp7Fl.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 384
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 384
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 384
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 384
      } ],
      "display_url" : "pic.twitter.com\/oW8YHMfKoR"
    } ],
    "hashtags" : [ {
      "text" : "smbe16",
      "indices" : [ 17, 24 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ -28.00061578399315, 153.4316478298543 ]
  },
  "id_str" : "749461844453040128",
  "text" : "That\u2019ll do until #smbe16 starts later today. https:\/\/t.co\/oW8YHMfKoR",
  "id" : 749461844453040128,
  "created_at" : "2016-07-03 04:36:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 54 ],
      "url" : "https:\/\/t.co\/ud3jqX6nwq",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BHYo9_Ajd3D\/",
      "display_url" : "instagram.com\/p\/BHYo9_Ajd3D\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ -28.0016388015, 153.430108089 ]
  },
  "id_str" : "749451545557729282",
  "text" : "Ohai! @ Surfers Paradise Beach https:\/\/t.co\/ud3jqX6nwq",
  "id" : 749451545557729282,
  "created_at" : "2016-07-03 03:55:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Craig Primmer",
      "screen_name" : "FishConGen",
      "indices" : [ 0, 11 ],
      "id_str" : "562495967",
      "id" : 562495967
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "749418352972427265",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ -28.00088061491894, 153.4306316890071 ]
  },
  "id_str" : "749448146950852609",
  "in_reply_to_user_id" : 562495967,
  "text" : "@FishConGen congrats!",
  "id" : 749448146950852609,
  "in_reply_to_status_id" : 749418352972427265,
  "created_at" : "2016-07-03 03:42:16 +0000",
  "in_reply_to_screen_name" : "FishConGen",
  "in_reply_to_user_id_str" : "562495967",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ -28.00062408207729, 153.4316008911966 ]
  },
  "id_str" : "749445416844800000",
  "text" : "Maybe you can also register an Australian SIM using your World Passport. \uD83D\uDE02",
  "id" : 749445416844800000,
  "created_at" : "2016-07-03 03:31:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Craig Primmer",
      "screen_name" : "FishConGen",
      "indices" : [ 0, 11 ],
      "id_str" : "562495967",
      "id" : 562495967
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "749437150500839424",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ -28.00094657979153, 153.4310809542237 ]
  },
  "id_str" : "749444744304963585",
  "in_reply_to_user_id" : 562495967,
  "text" : "@FishConGen it\u2019s all those things too. But also so much more. And this doesn\u2019t feel like any culture.",
  "id" : 749444744304963585,
  "in_reply_to_status_id" : 749437150500839424,
  "created_at" : "2016-07-03 03:28:45 +0000",
  "in_reply_to_screen_name" : "FishConGen",
  "in_reply_to_user_id_str" : "562495967",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Logsdon",
      "screen_name" : "johnlogsdon",
      "indices" : [ 0, 12 ],
      "id_str" : "18414364",
      "id" : 18414364
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "749270437465436160",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ -28.00501934255287, 153.4235638195215 ]
  },
  "id_str" : "749428125482844160",
  "in_reply_to_user_id" : 18414364,
  "text" : "@johnlogsdon will try my best!",
  "id" : 749428125482844160,
  "in_reply_to_status_id" : 749270437465436160,
  "created_at" : "2016-07-03 02:22:43 +0000",
  "in_reply_to_screen_name" : "johnlogsdon",
  "in_reply_to_user_id_str" : "18414364",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SMBE16",
      "indices" : [ 26, 33 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ -28.00504254623088, 153.4234251063684 ]
  },
  "id_str" : "749125021495398400",
  "text" : "Made it to Gold Coast for #SMBE16. Given how hardcore touristy-capitalist the whole area is, I somewhat wish it was in Vienna again.",
  "id" : 749125021495398400,
  "created_at" : "2016-07-02 06:18:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Logsdon",
      "screen_name" : "johnlogsdon",
      "indices" : [ 0, 12 ],
      "id_str" : "18414364",
      "id" : 18414364
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "749097561953230848",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ -28.00500148912415, 153.4234659926046 ]
  },
  "id_str" : "749124136178417664",
  "in_reply_to_user_id" : 18414364,
  "text" : "@johnlogsdon oh no, hoped to meet you here.",
  "id" : 749124136178417664,
  "in_reply_to_status_id" : 749097561953230848,
  "created_at" : "2016-07-02 06:14:46 +0000",
  "in_reply_to_screen_name" : "johnlogsdon",
  "in_reply_to_user_id_str" : "18414364",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u24EA Chris Hartgerink",
      "screen_name" : "chartgerink",
      "indices" : [ 0, 12 ],
      "id_str" : "439273539",
      "id" : 439273539
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "749115750095302656",
  "geo" : { },
  "id_str" : "749117816897429504",
  "in_reply_to_user_id" : 439273539,
  "text" : "@chartgerink It's my first longer trip with it. And it's already pretty good. Have the v2 plus the daypack.",
  "id" : 749117816897429504,
  "in_reply_to_status_id" : 749115750095302656,
  "created_at" : "2016-07-02 05:49:40 +0000",
  "in_reply_to_screen_name" : "chartgerink",
  "in_reply_to_user_id_str" : "439273539",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 142 ],
      "url" : "https:\/\/t.co\/cK5SQW8ga4",
      "expanded_url" : "https:\/\/twitter.com\/lteytelman\/status\/748948692091015168",
      "display_url" : "twitter.com\/lteytelman\/sta\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ -27.46799152246055, 153.0124540567564 ]
  },
  "id_str" : "749047217311260673",
  "text" : "\u00ABPowerless to do anything about the professors I personally know about. Universities &amp; departments protect them\u00BB \uD83D\uDE2D https:\/\/t.co\/cK5SQW8ga4",
  "id" : 749047217311260673,
  "created_at" : "2016-07-02 01:09:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kit Stubbs, Ph.D.",
      "screen_name" : "vortacist",
      "indices" : [ 3, 13 ],
      "id_str" : "347340056",
      "id" : 347340056
    }, {
      "name" : "RaceBaitR",
      "screen_name" : "RaceBaitR",
      "indices" : [ 99, 109 ],
      "id_str" : "2421318218",
      "id" : 2421318218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/cIlyLDI8yr",
      "expanded_url" : "http:\/\/everydayfeminism.com\/2016\/07\/non-binary-at-work\/",
      "display_url" : "everydayfeminism.com\/2016\/07\/non-bi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "749044597720911873",
  "text" : "RT @vortacist: \"After all, the most important part of being non-binary is what you feel inside.\" ~ @RaceBaitR https:\/\/t.co\/cIlyLDI8yr",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "RaceBaitR",
        "screen_name" : "RaceBaitR",
        "indices" : [ 84, 94 ],
        "id_str" : "2421318218",
        "id" : 2421318218
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 95, 118 ],
        "url" : "https:\/\/t.co\/cIlyLDI8yr",
        "expanded_url" : "http:\/\/everydayfeminism.com\/2016\/07\/non-binary-at-work\/",
        "display_url" : "everydayfeminism.com\/2016\/07\/non-bi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "748935223715528704",
    "text" : "\"After all, the most important part of being non-binary is what you feel inside.\" ~ @RaceBaitR https:\/\/t.co\/cIlyLDI8yr",
    "id" : 748935223715528704,
    "created_at" : "2016-07-01 17:44:06 +0000",
    "user" : {
      "name" : "Kit Stubbs, Ph.D.",
      "screen_name" : "vortacist",
      "protected" : false,
      "id_str" : "347340056",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/819220259148177408\/UYT71cyh_normal.jpg",
      "id" : 347340056,
      "verified" : false
    }
  },
  "id" : 749044597720911873,
  "created_at" : "2016-07-02 00:58:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/749039554225594368\/photo\/1",
      "indices" : [ 41, 64 ],
      "url" : "https:\/\/t.co\/1mBHYLyZKu",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CmUfa75VUAA07Se.jpg",
      "id_str" : "749039460642279424",
      "id" : 749039460642279424,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CmUfa75VUAA07Se.jpg",
      "sizes" : [ {
        "h" : 4032,
        "resize" : "fit",
        "w" : 3024
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      } ],
      "display_url" : "pic.twitter.com\/1mBHYLyZKu"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ -27.45726570023918, 153.0337919948185 ]
  },
  "id_str" : "749039554225594368",
  "text" : "Somehow managed to get all my books in \uD83D\uDE02 https:\/\/t.co\/1mBHYLyZKu",
  "id" : 749039554225594368,
  "created_at" : "2016-07-02 00:38:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ -27.46220449877125, 153.0410390595167 ]
  },
  "id_str" : "749026631981801472",
  "text" : "\u00ABWait, you took an Uber from the airport? You must have been really tired when even you come down from the moral high ground.\u00BB",
  "id" : 749026631981801472,
  "created_at" : "2016-07-01 23:47:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "748998483290488832",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ -27.4621854280765, 153.0410711149137 ]
  },
  "id_str" : "749002729268273153",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon ich kann dir einfach einen Stapel Sticker auf den Schreibtisch legen wenn ich aus Oz\/US zur\u00FCck bin. ;)",
  "id" : 749002729268273153,
  "in_reply_to_status_id" : 748998483290488832,
  "created_at" : "2016-07-01 22:12:21 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Malin Sandstr\u00F6m",
      "screen_name" : "msandstr",
      "indices" : [ 3, 12 ],
      "id_str" : "23945759",
      "id" : 23945759
    }, {
      "name" : "openSNP team",
      "screen_name" : "openSNPorg",
      "indices" : [ 34, 45 ],
      "id_str" : "380205172",
      "id" : 380205172
    }, {
      "name" : "Patreon",
      "screen_name" : "Patreon",
      "indices" : [ 49, 57 ],
      "id_str" : "1228325660",
      "id" : 1228325660
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 115, 131 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "748993871883841536",
  "text" : "RT @msandstr: Aww! I'm supporting @openSNPorg on @Patreon, &amp; they just sent me a nice thank you letter. Thanks @gedankenstuecke! https:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "openSNP team",
        "screen_name" : "openSNPorg",
        "indices" : [ 20, 31 ],
        "id_str" : "380205172",
        "id" : 380205172
      }, {
        "name" : "Patreon",
        "screen_name" : "Patreon",
        "indices" : [ 35, 43 ],
        "id_str" : "1228325660",
        "id" : 1228325660
      }, {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 101, 117 ],
        "id_str" : "14286491",
        "id" : 14286491
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/msandstr\/status\/748970535703412737\/photo\/1",
        "indices" : [ 119, 142 ],
        "url" : "https:\/\/t.co\/YhRcsJdc2I",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CmTguUoWcAEmmfH.jpg",
        "id_str" : "748970524466900993",
        "id" : 748970524466900993,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CmTguUoWcAEmmfH.jpg",
        "sizes" : [ {
          "h" : 1200,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/YhRcsJdc2I"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "748970535703412737",
    "text" : "Aww! I'm supporting @openSNPorg on @Patreon, &amp; they just sent me a nice thank you letter. Thanks @gedankenstuecke! https:\/\/t.co\/YhRcsJdc2I",
    "id" : 748970535703412737,
    "created_at" : "2016-07-01 20:04:25 +0000",
    "user" : {
      "name" : "Malin Sandstr\u00F6m",
      "screen_name" : "msandstr",
      "protected" : false,
      "id_str" : "23945759",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/888665853507645446\/MITsDShN_normal.jpg",
      "id" : 23945759,
      "verified" : false
    }
  },
  "id" : 748993871883841536,
  "created_at" : "2016-07-01 21:37:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Malin Sandstr\u00F6m",
      "screen_name" : "msandstr",
      "indices" : [ 0, 9 ],
      "id_str" : "23945759",
      "id" : 23945759
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "748970535703412737",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ -27.46216410882289, 153.0409525337397 ]
  },
  "id_str" : "748993831337533440",
  "in_reply_to_user_id" : 23945759,
  "text" : "@msandstr glad to hear they made it!",
  "id" : 748993831337533440,
  "in_reply_to_status_id" : 748970535703412737,
  "created_at" : "2016-07-01 21:36:59 +0000",
  "in_reply_to_screen_name" : "msandstr",
  "in_reply_to_user_id_str" : "23945759",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luc Henry",
      "screen_name" : "heluc",
      "indices" : [ 0, 6 ],
      "id_str" : "850645992",
      "id" : 850645992
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "748905657961676800",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ -27.46221601429512, 153.0409427914997 ]
  },
  "id_str" : "748905804174991360",
  "in_reply_to_user_id" : 850645992,
  "text" : "@heluc nah, 2% now and they have a graph showing the increase over time :)",
  "id" : 748905804174991360,
  "in_reply_to_status_id" : 748905657961676800,
  "created_at" : "2016-07-01 15:47:12 +0000",
  "in_reply_to_screen_name" : "heluc",
  "in_reply_to_user_id_str" : "850645992",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luc Henry",
      "screen_name" : "heluc",
      "indices" : [ 0, 6 ],
      "id_str" : "850645992",
      "id" : 850645992
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "748905254314467328",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ -27.46212591383943, 153.0409365492248 ]
  },
  "id_str" : "748905400112549888",
  "in_reply_to_user_id" : 850645992,
  "text" : "@heluc but it\u2019s not only two. It\u2019s data for many years that lead to the 2% we got to now :p",
  "id" : 748905400112549888,
  "in_reply_to_status_id" : 748905254314467328,
  "created_at" : "2016-07-01 15:45:36 +0000",
  "in_reply_to_screen_name" : "heluc",
  "in_reply_to_user_id_str" : "850645992",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luc Henry",
      "screen_name" : "heluc",
      "indices" : [ 0, 6 ],
      "id_str" : "850645992",
      "id" : 850645992
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "748904821441306624",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ -27.46217129625845, 153.0409501556735 ]
  },
  "id_str" : "748905067768532992",
  "in_reply_to_user_id" : 850645992,
  "text" : "@heluc yes, with a simple linear regression \uD83D\uDE02",
  "id" : 748905067768532992,
  "in_reply_to_status_id" : 748904821441306624,
  "created_at" : "2016-07-01 15:44:16 +0000",
  "in_reply_to_screen_name" : "heluc",
  "in_reply_to_user_id_str" : "850645992",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Egle Ramanauskaite \u2623",
      "screen_name" : "Seplute",
      "indices" : [ 3, 11 ],
      "id_str" : "188833865",
      "id" : 188833865
    }, {
      "name" : "Vytenis Andriukaitis",
      "screen_name" : "V_Andriukaitis",
      "indices" : [ 65, 80 ],
      "id_str" : "575269517",
      "id" : 575269517
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "weareseat123",
      "indices" : [ 84, 97 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/0UsSe3sSKg",
      "expanded_url" : "https:\/\/twitter.com\/V_Andriukaitis\/status\/748109476243382272",
      "display_url" : "twitter.com\/V_Andriukaitis\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "748904298709340160",
  "text" : "RT @Seplute: Proud of my countryman \uD83C\uDDF1\uD83C\uDDF9 - *the facepalm man* \uD83D\uDE02 Go @V_Andriukaitis !! #weareseat123 https:\/\/t.co\/0UsSe3sSKg",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Vytenis Andriukaitis",
        "screen_name" : "V_Andriukaitis",
        "indices" : [ 52, 67 ],
        "id_str" : "575269517",
        "id" : 575269517
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "weareseat123",
        "indices" : [ 71, 84 ]
      } ],
      "urls" : [ {
        "indices" : [ 85, 108 ],
        "url" : "https:\/\/t.co\/0UsSe3sSKg",
        "expanded_url" : "https:\/\/twitter.com\/V_Andriukaitis\/status\/748109476243382272",
        "display_url" : "twitter.com\/V_Andriukaitis\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "748904122083074051",
    "text" : "Proud of my countryman \uD83C\uDDF1\uD83C\uDDF9 - *the facepalm man* \uD83D\uDE02 Go @V_Andriukaitis !! #weareseat123 https:\/\/t.co\/0UsSe3sSKg",
    "id" : 748904122083074051,
    "created_at" : "2016-07-01 15:40:31 +0000",
    "user" : {
      "name" : "Egle Ramanauskaite \u2623",
      "screen_name" : "Seplute",
      "protected" : false,
      "id_str" : "188833865",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/733429172165574656\/JFlTQmja_normal.jpg",
      "id" : 188833865,
      "verified" : false
    }
  },
  "id" : 748904298709340160,
  "created_at" : "2016-07-01 15:41:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gunar C. Gessner",
      "screen_name" : "gunar",
      "indices" : [ 3, 9 ],
      "id_str" : "10417972",
      "id" : 10417972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 75 ],
      "url" : "https:\/\/t.co\/p7lQqP7iHN",
      "expanded_url" : "http:\/\/joelgrus.com\/2016\/05\/23\/fizz-buzz-in-tensorflow\/",
      "display_url" : "joelgrus.com\/2016\/05\/23\/fiz\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "748900470404423681",
  "text" : "RT @gunar: How (not) to nail a whiteboard interview\nhttps:\/\/t.co\/p7lQqP7iHN",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 41, 64 ],
        "url" : "https:\/\/t.co\/p7lQqP7iHN",
        "expanded_url" : "http:\/\/joelgrus.com\/2016\/05\/23\/fizz-buzz-in-tensorflow\/",
        "display_url" : "joelgrus.com\/2016\/05\/23\/fiz\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "748637389061492736",
    "text" : "How (not) to nail a whiteboard interview\nhttps:\/\/t.co\/p7lQqP7iHN",
    "id" : 748637389061492736,
    "created_at" : "2016-06-30 22:00:37 +0000",
    "user" : {
      "name" : "Gunar C. Gessner",
      "screen_name" : "gunar",
      "protected" : false,
      "id_str" : "10417972",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/704359736578318337\/gxEY3azk_normal.jpg",
      "id" : 10417972,
      "verified" : false
    }
  },
  "id" : 748900470404423681,
  "created_at" : "2016-07-01 15:26:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pall Melsted",
      "screen_name" : "pmelsted",
      "indices" : [ 3, 12 ],
      "id_str" : "1135472480",
      "id" : 1135472480
    }, {
      "name" : "SPAdes assembler",
      "screen_name" : "spadesassembler",
      "indices" : [ 107, 123 ],
      "id_str" : "569820386",
      "id" : 569820386
    }, {
      "name" : "Pierre Peterlongo",
      "screen_name" : "pierre350d",
      "indices" : [ 124, 135 ],
      "id_str" : "114578062",
      "id" : 114578062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 84 ],
      "url" : "https:\/\/t.co\/NHOM3nVIRW",
      "expanded_url" : "https:\/\/pmelsted.wordpress.com\/2016\/06\/22\/does-np-completeness-have-a-role-to-play-in-bioinformatics\/",
      "display_url" : "pmelsted.wordpress.com\/2016\/06\/22\/doe\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "748891465082736640",
  "text" : "RT @pmelsted: Thoughts on NP-completeness and Bioinformatics https:\/\/t.co\/NHOM3nVIRW related to thread cc: @spadesassembler @pierre350d @NP\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "SPAdes assembler",
        "screen_name" : "spadesassembler",
        "indices" : [ 93, 109 ],
        "id_str" : "569820386",
        "id" : 569820386
      }, {
        "name" : "Pierre Peterlongo",
        "screen_name" : "pierre350d",
        "indices" : [ 110, 121 ],
        "id_str" : "114578062",
        "id" : 114578062
      }, {
        "name" : "Malfoy Limasset",
        "screen_name" : "NPMalfoy",
        "indices" : [ 122, 131 ],
        "id_str" : "1110750576",
        "id" : 1110750576
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 47, 70 ],
        "url" : "https:\/\/t.co\/NHOM3nVIRW",
        "expanded_url" : "https:\/\/pmelsted.wordpress.com\/2016\/06\/22\/does-np-completeness-have-a-role-to-play-in-bioinformatics\/",
        "display_url" : "pmelsted.wordpress.com\/2016\/06\/22\/doe\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "745657814819930112",
    "text" : "Thoughts on NP-completeness and Bioinformatics https:\/\/t.co\/NHOM3nVIRW related to thread cc: @spadesassembler @pierre350d @NPMalfoy",
    "id" : 745657814819930112,
    "created_at" : "2016-06-22 16:40:51 +0000",
    "user" : {
      "name" : "Pall Melsted",
      "screen_name" : "pmelsted",
      "protected" : false,
      "id_str" : "1135472480",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3185781099\/3f5c881ce8adc3b5aaf3568530290c31_normal.jpeg",
      "id" : 1135472480,
      "verified" : false
    }
  },
  "id" : 748891465082736640,
  "created_at" : "2016-07-01 14:50:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Blin",
      "screen_name" : "kaiblin",
      "indices" : [ 0, 8 ],
      "id_str" : "124202458",
      "id" : 124202458
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "748886431637053440",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ -27.46212538877557, 153.0409432088019 ]
  },
  "id_str" : "748887705308717056",
  "in_reply_to_user_id" : 124202458,
  "text" : "@kaiblin 2038 \u2014 the year of a couple of beads on a wooden stick.",
  "id" : 748887705308717056,
  "in_reply_to_status_id" : 748886431637053440,
  "created_at" : "2016-07-01 14:35:17 +0000",
  "in_reply_to_screen_name" : "kaiblin",
  "in_reply_to_user_id_str" : "124202458",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u24EA Chris Hartgerink",
      "screen_name" : "chartgerink",
      "indices" : [ 0, 12 ],
      "id_str" : "439273539",
      "id" : 439273539
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "748883989541388288",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ -27.46216126119001, 153.0409595483353 ]
  },
  "id_str" : "748885362194296832",
  "in_reply_to_user_id" : 439273539,
  "text" : "@chartgerink \u2026but I enjoy interfacing those from my OSX running notebook ;)",
  "id" : 748885362194296832,
  "in_reply_to_status_id" : 748883989541388288,
  "created_at" : "2016-07-01 14:25:58 +0000",
  "in_reply_to_screen_name" : "chartgerink",
  "in_reply_to_user_id_str" : "439273539",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u24EA Chris Hartgerink",
      "screen_name" : "chartgerink",
      "indices" : [ 0, 12 ],
      "id_str" : "439273539",
      "id" : 439273539
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "748883989541388288",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ -27.46216126119001, 153.0409595483353 ]
  },
  "id_str" : "748885249254232064",
  "in_reply_to_user_id" : 439273539,
  "text" : "@chartgerink my workstation at work is running an Ubuntu, so is the cluster. I spent the majority of my time in one command line or another\u2026",
  "id" : 748885249254232064,
  "in_reply_to_status_id" : 748883989541388288,
  "created_at" : "2016-07-01 14:25:31 +0000",
  "in_reply_to_screen_name" : "chartgerink",
  "in_reply_to_user_id_str" : "439273539",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/6Td2l5gIuA",
      "expanded_url" : "https:\/\/twitter.com\/kaiblin\/status\/748879626517225472",
      "display_url" : "twitter.com\/kaiblin\/status\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ -27.46219901373189, 153.0409127827919 ]
  },
  "id_str" : "748883392024891393",
  "text" : "Year 2976 will be the year of Linux on the Desktop. (Remember my words and how I called it!) https:\/\/t.co\/6Td2l5gIuA",
  "id" : 748883392024891393,
  "created_at" : "2016-07-01 14:18:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/748882394334109696\/photo\/1",
      "indices" : [ 44, 67 ],
      "url" : "https:\/\/t.co\/5BrQ687MzQ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CmSQkTEUEAAWj0o.jpg",
      "id_str" : "748882391318401024",
      "id" : 748882391318401024,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CmSQkTEUEAAWj0o.jpg",
      "sizes" : [ {
        "h" : 400,
        "resize" : "fit",
        "w" : 266
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 266
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 266
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 266
      } ],
      "display_url" : "pic.twitter.com\/5BrQ687MzQ"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 43 ],
      "url" : "https:\/\/t.co\/URmxtz0fSx",
      "expanded_url" : "http:\/\/amzn.to\/29aE7sZ",
      "display_url" : "amzn.to\/29aE7sZ"
    } ]
  },
  "geo" : { },
  "id_str" : "748882394334109696",
  "text" : "Changing the Future https:\/\/t.co\/URmxtz0fSx https:\/\/t.co\/5BrQ687MzQ",
  "id" : 748882394334109696,
  "created_at" : "2016-07-01 14:14:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "748850064605507586",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ -27.46215006386116, 153.0409808345439 ]
  },
  "id_str" : "748850285586493440",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC both I\u2019d say. Read 79 books so far, this year. Also: it was a 25h travel time all in all ;)",
  "id" : 748850285586493440,
  "in_reply_to_status_id" : 748850064605507586,
  "created_at" : "2016-07-01 12:06:35 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "748840249758023681",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ -27.46223473481464, 153.0409567241114 ]
  },
  "id_str" : "748840783424270337",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC yes, and I managed to read 4 books on the way, so that\u2019s some plus :p",
  "id" : 748840783424270337,
  "in_reply_to_status_id" : 748840249758023681,
  "created_at" : "2016-07-01 11:28:50 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Heather L. Wiencko",
      "screen_name" : "HLWiencko",
      "indices" : [ 0, 10 ],
      "id_str" : "2657942712",
      "id" : 2657942712
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "748794777915711489",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ -27.46223473481464, 153.0409567241114 ]
  },
  "id_str" : "748840715447263233",
  "in_reply_to_user_id" : 2657942712,
  "text" : "@HLWiencko to the drinks? ;)",
  "id" : 748840715447263233,
  "in_reply_to_status_id" : 748794777915711489,
  "created_at" : "2016-07-01 11:28:34 +0000",
  "in_reply_to_screen_name" : "HLWiencko",
  "in_reply_to_user_id_str" : "2657942712",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 70 ],
      "url" : "https:\/\/t.co\/L2RoYmKbZE",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BHUS6IJD_6j\/",
      "display_url" : "instagram.com\/p\/BHUS6IJD_6j\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ -27.4779876696, 153.022574504 ]
  },
  "id_str" : "748840084405977088",
  "text" : "In case of getting lost @ South Bank, Brisbane https:\/\/t.co\/L2RoYmKbZE",
  "id" : 748840084405977088,
  "created_at" : "2016-07-01 11:26:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "latergram",
      "indices" : [ 23, 33 ]
    } ],
    "urls" : [ {
      "indices" : [ 49, 72 ],
      "url" : "https:\/\/t.co\/ybCzivd0Kq",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BHUR3F8DWVO\/",
      "display_url" : "instagram.com\/p\/BHUR3F8DWVO\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ -27.463752, 153.035699 ]
  },
  "id_str" : "748837781498171393",
  "text" : "The view from New Farm #latergram @ Story Bridge https:\/\/t.co\/ybCzivd0Kq",
  "id" : 748837781498171393,
  "created_at" : "2016-07-01 11:16:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Heather L. Wiencko",
      "screen_name" : "HLWiencko",
      "indices" : [ 0, 10 ],
      "id_str" : "2657942712",
      "id" : 2657942712
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "748793732925796352",
  "geo" : { },
  "id_str" : "748794672676352000",
  "in_reply_to_user_id" : 2657942712,
  "text" : "@HLWiencko have fun over there! :)",
  "id" : 748794672676352000,
  "in_reply_to_status_id" : 748793732925796352,
  "created_at" : "2016-07-01 08:25:36 +0000",
  "in_reply_to_screen_name" : "HLWiencko",
  "in_reply_to_user_id_str" : "2657942712",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/748790032295530496\/photo\/1",
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/7vvtbQWgSo",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CmQ8c4XUcAA07SF.jpg",
      "id_str" : "748789904914542592",
      "id" : 748789904914542592,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CmQ8c4XUcAA07SF.jpg",
      "sizes" : [ {
        "h" : 4032,
        "resize" : "fit",
        "w" : 3024
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      } ],
      "display_url" : "pic.twitter.com\/7vvtbQWgSo"
    } ],
    "hashtags" : [ {
      "text" : "SMBE16",
      "indices" : [ 77, 84 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ -27.46218340563054, 153.0408905475998 ]
  },
  "id_str" : "748790032295530496",
  "text" : "I think I got the right set of books at Lifeline Bookfest to accompany me to #SMBE16 https:\/\/t.co\/7vvtbQWgSo",
  "id" : 748790032295530496,
  "created_at" : "2016-07-01 08:07:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/P7X3kMosFv",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BHT7M9CDphh\/",
      "display_url" : "instagram.com\/p\/BHT7M9CDphh\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ -27.47171, 153.02556 ]
  },
  "id_str" : "748787955053891584",
  "text" : "Took me a while to understand that the ceiling fans were meant. @ Archives Fine Books https:\/\/t.co\/P7X3kMosFv",
  "id" : 748787955053891584,
  "created_at" : "2016-07-01 07:58:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ali",
      "screen_name" : "zoonpolitikon",
      "indices" : [ 0, 14 ],
      "id_str" : "13040652",
      "id" : 13040652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "748786763057934337",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ -27.46221840884121, 153.0409228950489 ]
  },
  "id_str" : "748786937880670208",
  "in_reply_to_user_id" : 13040652,
  "text" : "@zoonpolitikon they are just inventing it to push their fast food chains \uD83D\uDE31",
  "id" : 748786937880670208,
  "in_reply_to_status_id" : 748786763057934337,
  "created_at" : "2016-07-01 07:54:52 +0000",
  "in_reply_to_screen_name" : "zoonpolitikon",
  "in_reply_to_user_id_str" : "13040652",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ali",
      "screen_name" : "zoonpolitikon",
      "indices" : [ 0, 14 ],
      "id_str" : "13040652",
      "id" : 13040652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "748778918891577344",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ -27.46222046173541, 153.0409318003398 ]
  },
  "id_str" : "748786375059607553",
  "in_reply_to_user_id" : 13040652,
  "text" : "@zoonpolitikon sounds like a conspiracy theory \u201Cof course the US government wants you to believe that there is one!\u201D",
  "id" : 748786375059607553,
  "in_reply_to_status_id" : 748778918891577344,
  "created_at" : "2016-07-01 07:52:38 +0000",
  "in_reply_to_screen_name" : "zoonpolitikon",
  "in_reply_to_user_id_str" : "13040652",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Blin",
      "screen_name" : "kaiblin",
      "indices" : [ 0, 8 ],
      "id_str" : "124202458",
      "id" : 124202458
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "748785380086784000",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ -27.46219997316197, 153.0409838132107 ]
  },
  "id_str" : "748785679346208768",
  "in_reply_to_user_id" : 124202458,
  "text" : "@kaiblin the MIT knockoff-part I always have to laugh about when I read it. :D",
  "id" : 748785679346208768,
  "in_reply_to_status_id" : 748785380086784000,
  "created_at" : "2016-07-01 07:49:52 +0000",
  "in_reply_to_screen_name" : "kaiblin",
  "in_reply_to_user_id_str" : "124202458",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/748785047520489473\/photo\/1",
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/0GTMs3bJiu",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CmQ3yU6UIAAStuA.jpg",
      "id_str" : "748784775796629504",
      "id" : 748784775796629504,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CmQ3yU6UIAAStuA.jpg",
      "sizes" : [ {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 4032,
        "resize" : "fit",
        "w" : 3024
      } ],
      "display_url" : "pic.twitter.com\/0GTMs3bJiu"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/748785047520489473\/photo\/1",
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/0GTMs3bJiu",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CmQ3yYsUsAAH4aT.jpg",
      "id_str" : "748784776811687936",
      "id" : 748784776811687936,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CmQ3yYsUsAAH4aT.jpg",
      "sizes" : [ {
        "h" : 4032,
        "resize" : "fit",
        "w" : 3024
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      } ],
      "display_url" : "pic.twitter.com\/0GTMs3bJiu"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ -27.46218444807041, 153.0409764206039 ]
  },
  "id_str" : "748785047520489473",
  "text" : "I know a German Institute of Theoretical Physics that should check a Brisbane bookstore if it\u2019s missing something. https:\/\/t.co\/0GTMs3bJiu",
  "id" : 748785047520489473,
  "created_at" : "2016-07-01 07:47:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Malin Sandstr\u00F6m",
      "screen_name" : "msandstr",
      "indices" : [ 0, 9 ],
      "id_str" : "23945759",
      "id" : 23945759
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 10, 23 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "748780586337132544",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ -27.46222900027235, 153.040960650315 ]
  },
  "id_str" : "748780764209164292",
  "in_reply_to_user_id" : 23945759,
  "text" : "@msandstr @PhilippBayer let\u2019s say my bank account is the limiting factor. Or i\u2019d have to abandon them here, which would be a shame.",
  "id" : 748780764209164292,
  "in_reply_to_status_id" : 748780586337132544,
  "created_at" : "2016-07-01 07:30:20 +0000",
  "in_reply_to_screen_name" : "msandstr",
  "in_reply_to_user_id_str" : "23945759",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/uAHz9Lu5VO",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BHT3r8HjoNX\/",
      "display_url" : "instagram.com\/p\/BHT3r8HjoNX\/"
    } ]
  },
  "geo" : { },
  "id_str" : "748780223366180864",
  "text" : "It's like Powell's, but exclusively for 2nd hand (and \"Computer A-Z\" shares a shelf w\/ \"The\u2026 https:\/\/t.co\/uAHz9Lu5VO",
  "id" : 748780223366180864,
  "created_at" : "2016-07-01 07:28:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Malin Sandstr\u00F6m",
      "screen_name" : "msandstr",
      "indices" : [ 0, 9 ],
      "id_str" : "23945759",
      "id" : 23945759
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 10, 23 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "748778932632113152",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ -27.46228135629173, 153.0411220324897 ]
  },
  "id_str" : "748779258147844096",
  "in_reply_to_user_id" : 23945759,
  "text" : "@msandstr @PhilippBayer or just take it lightly this time. As I\u2019m not going back to Germany directly, so would need at least 4 friendly ppl.",
  "id" : 748779258147844096,
  "in_reply_to_status_id" : 748778932632113152,
  "created_at" : "2016-07-01 07:24:21 +0000",
  "in_reply_to_screen_name" : "msandstr",
  "in_reply_to_user_id_str" : "23945759",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Malin Sandstr\u00F6m",
      "screen_name" : "msandstr",
      "indices" : [ 0, 9 ],
      "id_str" : "23945759",
      "id" : 23945759
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 10, 23 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "748775408875679745",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ -27.46206922556843, 153.0408841487931 ]
  },
  "id_str" : "748777871041130496",
  "in_reply_to_user_id" : 23945759,
  "text" : "@msandstr @PhilippBayer yeah, but I was in the post office this morning. Sending heavy stuff from Australia isn\u2019t that cheap.",
  "id" : 748777871041130496,
  "in_reply_to_status_id" : 748775408875679745,
  "created_at" : "2016-07-01 07:18:50 +0000",
  "in_reply_to_screen_name" : "msandstr",
  "in_reply_to_user_id_str" : "23945759",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 44, 57 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/748749840746590209\/photo\/1",
      "indices" : [ 58, 81 ],
      "url" : "https:\/\/t.co\/ji09zGAxx2",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CmQX_ILVYAEgZ17.jpg",
      "id_str" : "748749811344564225",
      "id" : 748749811344564225,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CmQX_ILVYAEgZ17.jpg",
      "sizes" : [ {
        "h" : 3024,
        "resize" : "fit",
        "w" : 4032
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/ji09zGAxx2"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ -27.47208707620569, 153.0257155845723 ]
  },
  "id_str" : "748749840746590209",
  "text" : "And the next bookstore, also recommended by @PhilippBayer https:\/\/t.co\/ji09zGAxx2",
  "id" : 748749840746590209,
  "created_at" : "2016-07-01 05:27:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bi\u1ECA\u1ECAy Meinke",
      "screen_name" : "billymeinke",
      "indices" : [ 0, 12 ],
      "id_str" : "296003222",
      "id" : 296003222
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/748749736073584642\/photo\/1",
      "indices" : [ 22, 45 ],
      "url" : "https:\/\/t.co\/X9m99eKHPy",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CmQX3j3UEAA_dGG.jpg",
      "id_str" : "748749681337831424",
      "id" : 748749681337831424,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CmQX3j3UEAA_dGG.jpg",
      "sizes" : [ {
        "h" : 3024,
        "resize" : "fit",
        "w" : 4032
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/X9m99eKHPy"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "748748644971524096",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ -27.47207195500608, 153.0256413483555 ]
  },
  "id_str" : "748749736073584642",
  "in_reply_to_user_id" : 296003222,
  "text" : "@billymeinke like? :) https:\/\/t.co\/X9m99eKHPy",
  "id" : 748749736073584642,
  "in_reply_to_status_id" : 748748644971524096,
  "created_at" : "2016-07-01 05:27:02 +0000",
  "in_reply_to_screen_name" : "billymeinke",
  "in_reply_to_user_id_str" : "296003222",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bi\u1ECA\u1ECAy Meinke",
      "screen_name" : "billymeinke",
      "indices" : [ 0, 12 ],
      "id_str" : "296003222",
      "id" : 296003222
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "748743802236444672",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ -27.4734489340591, 153.0201908481801 ]
  },
  "id_str" : "748744586823032832",
  "in_reply_to_user_id" : 296003222,
  "text" : "@billymeinke kinda incomparable, this here is a week long 2nd hand festival to power a charity. But it\u2019s huge too.",
  "id" : 748744586823032832,
  "in_reply_to_status_id" : 748743802236444672,
  "created_at" : "2016-07-01 05:06:35 +0000",
  "in_reply_to_screen_name" : "billymeinke",
  "in_reply_to_user_id_str" : "296003222",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "748638549617020928",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ -27.48050578406777, 153.0251838640804 ]
  },
  "id_str" : "748726426875027456",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC nah, it\u2019s okay. Wanted to stay awake in any case and I can\u2019t imagine how much it sucks for the parents.",
  "id" : 748726426875027456,
  "in_reply_to_status_id" : 748638549617020928,
  "created_at" : "2016-07-01 03:54:25 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/748726093700472841\/photo\/1",
      "indices" : [ 60, 83 ],
      "url" : "https:\/\/t.co\/CMlFFuAUMp",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CmQCZ2JUEAAyFCP.jpg",
      "id_str" : "748726081104908288",
      "id" : 748726081104908288,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CmQCZ2JUEAAyFCP.jpg",
      "sizes" : [ {
        "h" : 4032,
        "resize" : "fit",
        "w" : 3024
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      } ],
      "display_url" : "pic.twitter.com\/CMlFFuAUMp"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "748718092969086976",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ -27.48050578406777, 153.0251838640804 ]
  },
  "id_str" : "748726093700472841",
  "in_reply_to_user_id" : 14286491,
  "text" : "This must have been one of my favorites. Spiritual Warfare. https:\/\/t.co\/CMlFFuAUMp",
  "id" : 748726093700472841,
  "in_reply_to_status_id" : 748718092969086976,
  "created_at" : "2016-07-01 03:53:06 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/748720492425674752\/photo\/1",
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/yEqFsvzAHI",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CmP9UaAWgAACN5o.jpg",
      "id_str" : "748720490093641728",
      "id" : 748720490093641728,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CmP9UaAWgAACN5o.jpg",
      "sizes" : [ {
        "h" : 1446,
        "resize" : "fit",
        "w" : 1085
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 1446,
        "resize" : "fit",
        "w" : 1085
      } ],
      "display_url" : "pic.twitter.com\/yEqFsvzAHI"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "748720492425674752",
  "text" : "If you don't change the name for long enough it becomes fitting again. \uD83D\uDE2D https:\/\/t.co\/yEqFsvzAHI",
  "id" : 748720492425674752,
  "created_at" : "2016-07-01 03:30:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 17, 30 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/748718092969086976\/photo\/1",
      "indices" : [ 121, 144 ],
      "url" : "https:\/\/t.co\/2doa0Txkw8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CmP7IuKUcAA105V.jpg",
      "id_str" : "748718090322472960",
      "id" : 748718090322472960,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CmP7IuKUcAA105V.jpg",
      "sizes" : [ {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1064,
        "resize" : "fit",
        "w" : 1418
      }, {
        "h" : 1064,
        "resize" : "fit",
        "w" : 1418
      } ],
      "display_url" : "pic.twitter.com\/2doa0Txkw8"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "748718092969086976",
  "text" : "Nerdgasm. Thanks @PhilippBayer for showing me Lifeline Bookfest. How will I carry these first to the US &amp; then home? https:\/\/t.co\/2doa0Txkw8",
  "id" : 748718092969086976,
  "created_at" : "2016-07-01 03:21:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 79 ],
      "url" : "https:\/\/t.co\/2V4gAiNAWw",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BHTSQLgDlnH\/",
      "display_url" : "instagram.com\/p\/BHTSQLgDlnH\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ -27.4696498813, 153.025347916 ]
  },
  "id_str" : "748697907516338178",
  "text" : "And I forgot to pack my ice skates! @ Queen Street Mall https:\/\/t.co\/2V4gAiNAWw",
  "id" : 748697907516338178,
  "created_at" : "2016-07-01 02:01:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ -27.46976307595844, 153.0223483500565 ]
  },
  "id_str" : "748694152905256961",
  "text" : "First to-do in Australia: send out stickers to local openSNP supporters \u2714\uFE0F",
  "id" : 748694152905256961,
  "created_at" : "2016-07-01 01:46:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
} ]