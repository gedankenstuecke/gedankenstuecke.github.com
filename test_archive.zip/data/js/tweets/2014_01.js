Grailbird.data.tweets_2014_01 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/FXHzwJrkoG",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=sz3Qr5SaU2Q",
      "display_url" : "youtube.com\/watch?v=sz3Qr5\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096706443, 8.28304939 ]
  },
  "id_str" : "429384459260289025",
  "text" : "Alt-J doing a mashup of Kylie Minogue's \"Slow\" and Dr Dre's \"Still D.R.E.\u201D http:\/\/t.co\/FXHzwJrkoG",
  "id" : 429384459260289025,
  "created_at" : "2014-01-31 22:43:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 57 ],
      "url" : "http:\/\/t.co\/VVS8RBfZv3",
      "expanded_url" : "http:\/\/boingboing.net\/2014\/01\/31\/dog-cant-get-to-tennis-ball.html",
      "display_url" : "boingboing.net\/2014\/01\/31\/dog\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096706443, 8.28304939 ]
  },
  "id_str" : "429376585847025664",
  "text" : "the most depressing game of fetch\u2026 http:\/\/t.co\/VVS8RBfZv3",
  "id" : 429376585847025664,
  "created_at" : "2014-01-31 22:12:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 3, 12 ],
      "id_str" : "14245811",
      "id" : 14245811
    }, {
      "name" : "Eric Kansa \uD83C\uDF39",
      "screen_name" : "ekansa",
      "indices" : [ 106, 113 ],
      "id_str" : "24961156",
      "id" : 24961156
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/0tWqSIqt3a",
      "expanded_url" : "http:\/\/blogs.lse.ac.uk\/impactofsocialsciences\/2014\/01\/27\/its-the-neoliberalism-stupid-kansa\/",
      "display_url" : "blogs.lse.ac.uk\/impactofsocial\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "429368344765276161",
  "text" : "RT @wilbanks: It\u2019s the neoliberalism, stupid. Why instrumentalist arguments aren\u2019t enough for \u201Copen\u201D - by @ekansa http:\/\/t.co\/0tWqSIqt3a",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Eric Kansa \uD83C\uDF39",
        "screen_name" : "ekansa",
        "indices" : [ 92, 99 ],
        "id_str" : "24961156",
        "id" : 24961156
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 100, 122 ],
        "url" : "http:\/\/t.co\/0tWqSIqt3a",
        "expanded_url" : "http:\/\/blogs.lse.ac.uk\/impactofsocialsciences\/2014\/01\/27\/its-the-neoliberalism-stupid-kansa\/",
        "display_url" : "blogs.lse.ac.uk\/impactofsocial\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "429367909706510336",
    "text" : "It\u2019s the neoliberalism, stupid. Why instrumentalist arguments aren\u2019t enough for \u201Copen\u201D - by @ekansa http:\/\/t.co\/0tWqSIqt3a",
    "id" : 429367909706510336,
    "created_at" : "2014-01-31 21:37:41 +0000",
    "user" : {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "protected" : false,
      "id_str" : "14245811",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/925696899566440448\/BUTdp410_normal.jpg",
      "id" : 14245811,
      "verified" : false
    }
  },
  "id" : 429368344765276161,
  "created_at" : "2014-01-31 21:39:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/HcfsQdQ9fY",
      "expanded_url" : "http:\/\/thescienceweb.wordpress.com\/2014\/01\/31\/plos-computational-biology-to-provide-relationship-advice\/",
      "display_url" : "thescienceweb.wordpress.com\/2014\/01\/31\/plo\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096706443, 8.28304939 ]
  },
  "id_str" : "429349148249554947",
  "text" : "PLOS Computational Biology to provide relationship\u00A0advice http:\/\/t.co\/HcfsQdQ9fY",
  "id" : 429349148249554947,
  "created_at" : "2014-01-31 20:23:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andreas Herten",
      "screen_name" : "AndiH",
      "indices" : [ 0, 6 ],
      "id_str" : "4586881",
      "id" : 4586881
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "429234499160125440",
  "geo" : { },
  "id_str" : "429236701504868352",
  "in_reply_to_user_id" : 4586881,
  "text" : "@AndiH danke :)",
  "id" : 429236701504868352,
  "in_reply_to_status_id" : 429234499160125440,
  "created_at" : "2014-01-31 12:56:19 +0000",
  "in_reply_to_screen_name" : "AndiH",
  "in_reply_to_user_id_str" : "4586881",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andreas Herten",
      "screen_name" : "AndiH",
      "indices" : [ 0, 6 ],
      "id_str" : "4586881",
      "id" : 4586881
    }, {
      "name" : "QS Meetup Cologne",
      "screen_name" : "QS_Cologne",
      "indices" : [ 7, 18 ],
      "id_str" : "1400648731",
      "id" : 1400648731
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "429232912203268096",
  "geo" : { },
  "id_str" : "429234427965624321",
  "in_reply_to_user_id" : 4586881,
  "text" : "@AndiH @QS_Cologne Ist noch gar nicht 100% sicher, wann ist es denn im M\u00E4rz? :)",
  "id" : 429234427965624321,
  "in_reply_to_status_id" : 429232912203268096,
  "created_at" : "2014-01-31 12:47:17 +0000",
  "in_reply_to_screen_name" : "AndiH",
  "in_reply_to_user_id_str" : "4586881",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/429234076684267521\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/tAmOTKzb8F",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BfTyHlrCMAAq8kw.jpg",
      "id_str" : "429234076692656128",
      "id" : 429234076692656128,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BfTyHlrCMAAq8kw.jpg",
      "sizes" : [ {
        "h" : 1994,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 662,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1994,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 1168,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/tAmOTKzb8F"
    } ],
    "hashtags" : [ {
      "text" : "quantifiedself",
      "indices" : [ 101, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "429234076684267521",
  "text" : "Looks like I have a realistic chance of becoming #1 in the intra office coffee drinking competition. #quantifiedself http:\/\/t.co\/tAmOTKzb8F",
  "id" : 429234076684267521,
  "created_at" : "2014-01-31 12:45:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 45 ],
      "url" : "http:\/\/t.co\/fvk1htsk0Q",
      "expanded_url" : "http:\/\/www.asofterworld.com\/index.php?id=1062",
      "display_url" : "asofterworld.com\/index.php?id=1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "429188376411918337",
  "text" : "love is a prime number http:\/\/t.co\/fvk1htsk0Q",
  "id" : 429188376411918337,
  "created_at" : "2014-01-31 09:44:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/g7UVUJJjLw",
      "expanded_url" : "https:\/\/www.goodreads.com\/review\/show\/437301397?book_show_action=false",
      "display_url" : "goodreads.com\/review\/show\/43\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "429171258937204736",
  "text" : "\u00ABRecommended for: People who like to drown in common misery. Academics\u00BB True, made me physic. uncomfortable at times https:\/\/t.co\/g7UVUJJjLw",
  "id" : 429171258937204736,
  "created_at" : "2014-01-31 08:36:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ashkan soltani",
      "screen_name" : "ashk4n",
      "indices" : [ 3, 10 ],
      "id_str" : "17241749",
      "id" : 17241749
    }, {
      "name" : "Chris Dixon",
      "screen_name" : "cdixon",
      "indices" : [ 36, 43 ],
      "id_str" : "2529971",
      "id" : 2529971
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/jeremyjarvis\/status\/428848527226437632\/photo\/1",
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/pi3udJxaFQ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BfOTdpkIUAA0UXA.jpg",
      "id_str" : "428848527113211904",
      "id" : 428848527113211904,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BfOTdpkIUAA0UXA.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1023
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1023
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 679
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1023
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/pi3udJxaFQ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "429161869598015488",
  "text" : "RT @ashk4n: aka 'number hipster' RT @cdixon: \"A data scientist is a statistician who lives in San Francisco\" https:\/\/t.co\/pi3udJxaFQ via @s\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Chris Dixon",
        "screen_name" : "cdixon",
        "indices" : [ 24, 31 ],
        "id_str" : "2529971",
        "id" : 2529971
      }, {
        "name" : "Sonal Chokshi",
        "screen_name" : "smc90",
        "indices" : [ 125, 131 ],
        "id_str" : "14161568",
        "id" : 14161568
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/jeremyjarvis\/status\/428848527226437632\/photo\/1",
        "indices" : [ 97, 120 ],
        "url" : "https:\/\/t.co\/pi3udJxaFQ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BfOTdpkIUAA0UXA.jpg",
        "id_str" : "428848527113211904",
        "id" : 428848527113211904,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BfOTdpkIUAA0UXA.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1023
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1023
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 679
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1023
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/pi3udJxaFQ"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "428914681911070720",
    "geo" : { },
    "id_str" : "429130278872027137",
    "in_reply_to_user_id" : 2529971,
    "text" : "aka 'number hipster' RT @cdixon: \"A data scientist is a statistician who lives in San Francisco\" https:\/\/t.co\/pi3udJxaFQ via @smc90",
    "id" : 429130278872027137,
    "in_reply_to_status_id" : 428914681911070720,
    "created_at" : "2014-01-31 05:53:26 +0000",
    "in_reply_to_screen_name" : "cdixon",
    "in_reply_to_user_id_str" : "2529971",
    "user" : {
      "name" : "ashkan soltani",
      "screen_name" : "ashk4n",
      "protected" : false,
      "id_str" : "17241749",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/63881072\/face_normal.jpg",
      "id" : 17241749,
      "verified" : true
    }
  },
  "id" : 429161869598015488,
  "created_at" : "2014-01-31 07:58:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0045490855, 8.3505950553 ]
  },
  "id_str" : "429151931580547072",
  "text" : "\u00ABI\u2019m trying to explain to whose underwear I\u2019m accidentally wearing today &amp; your answer is \u2018that will make a great international campaign\u2019?!\u00BB",
  "id" : 429151931580547072,
  "created_at" : "2014-01-31 07:19:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GrrlScientist",
      "screen_name" : "GrrlScientist",
      "indices" : [ 66, 80 ],
      "id_str" : "27834920",
      "id" : 27834920
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/EIiTWXwAeU",
      "expanded_url" : "http:\/\/whatthefuckismytwitterbio.com\/",
      "display_url" : "whatthefuckismytwitterbio.com"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096706443, 8.28304939 ]
  },
  "id_str" : "429004631541547009",
  "text" : "\u00ABBING CONSULTANT, SECURITY DOGE, SMS CZAR. DO WHAT YOU LOVE.\u00BB \/HT @GrrlScientist http:\/\/t.co\/EIiTWXwAeU",
  "id" : 429004631541547009,
  "created_at" : "2014-01-30 21:34:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00965649, 8.2830616231 ]
  },
  "id_str" : "428995237856690176",
  "text" : "\u00ABDid you even try to listen to me?\u00BB \u2014 \u00ABThere is a Siberian Husky looking at me while sitting in petting distance, what do you think?\u00BB",
  "id" : 428995237856690176,
  "created_at" : "2014-01-30 20:56:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\/Andreas K. Bittner",
      "screen_name" : "qwasi",
      "indices" : [ 0, 6 ],
      "id_str" : "15835452",
      "id" : 15835452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "428827300722126848",
  "geo" : { },
  "id_str" : "428829438264893440",
  "in_reply_to_user_id" : 15835452,
  "text" : "@qwasi wenn P\u00FCnktlichkeit nur selten genug vorkommt schon.",
  "id" : 428829438264893440,
  "in_reply_to_status_id" : 428827300722126848,
  "created_at" : "2014-01-30 09:58:00 +0000",
  "in_reply_to_screen_name" : "qwasi",
  "in_reply_to_user_id_str" : "15835452",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428825338269806592",
  "text" : "\u00ABImmerhin konditionierst du mit Kaffee bei P\u00FCnktlichkeit statt mit Elektroschock bei Versp\u00E4tung\u00BB\u2013\u00ABDie Stromrechnung k\u00F6nnt ich nicht zahlen\u2026\u00BB",
  "id" : 428825338269806592,
  "created_at" : "2014-01-30 09:41:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Richard Poynder",
      "screen_name" : "RickyPo",
      "indices" : [ 3, 11 ],
      "id_str" : "20298671",
      "id" : 20298671
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 73 ],
      "url" : "http:\/\/t.co\/aoKLTl5SbI",
      "expanded_url" : "http:\/\/bit.ly\/1fdNtPf",
      "display_url" : "bit.ly\/1fdNtPf"
    } ]
  },
  "geo" : { },
  "id_str" : "428788912220557312",
  "text" : "RT @RickyPo: The Open Access Debate Behind 23andMe http:\/\/t.co\/aoKLTl5SbI",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 38, 60 ],
        "url" : "http:\/\/t.co\/aoKLTl5SbI",
        "expanded_url" : "http:\/\/bit.ly\/1fdNtPf",
        "display_url" : "bit.ly\/1fdNtPf"
      } ]
    },
    "geo" : { },
    "id_str" : "428769059249729536",
    "text" : "The Open Access Debate Behind 23andMe http:\/\/t.co\/aoKLTl5SbI",
    "id" : 428769059249729536,
    "created_at" : "2014-01-30 05:58:04 +0000",
    "user" : {
      "name" : "Richard Poynder",
      "screen_name" : "RickyPo",
      "protected" : false,
      "id_str" : "20298671",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3717767146\/403a01e00544bcb47a5e179a068ab4ef_normal.jpeg",
      "id" : 20298671,
      "verified" : false
    }
  },
  "id" : 428788912220557312,
  "created_at" : "2014-01-30 07:16:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/C2Avnd2sRQ",
      "expanded_url" : "http:\/\/english.stackexchange.com\/questions\/148323\/is-there-a-non-sexual-phrase-for-sleeping-with-someone",
      "display_url" : "english.stackexchange.com\/questions\/1483\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096645981, 8.283058209 ]
  },
  "id_str" : "428689221583650816",
  "text" : "\u00ABIs there a non-sexual phrase for sleeping with someone?\u00BB guess I\u2019m not the only one who has a hard time phrasing it http:\/\/t.co\/C2Avnd2sRQ",
  "id" : 428689221583650816,
  "created_at" : "2014-01-30 00:40:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "overlyhonestjobopenings",
      "indices" : [ 116, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0098305429, 8.2829035074 ]
  },
  "id_str" : "428679562411917312",
  "text" : "The successful applicant will bring strong skills in converting nat. language student questions into google queries #overlyhonestjobopenings",
  "id" : 428679562411917312,
  "created_at" : "2014-01-30 00:02:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ali",
      "screen_name" : "zoonpolitikon",
      "indices" : [ 3, 17 ],
      "id_str" : "13040652",
      "id" : 13040652
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 19, 35 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428646197755379712",
  "text" : "RT @zoonpolitikon: @gedankenstuecke I can get no, satisficing!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 0, 16 ],
        "id_str" : "14286491",
        "id" : 14286491
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "428643948757008384",
    "geo" : { },
    "id_str" : "428645625492955136",
    "in_reply_to_user_id" : 14286491,
    "text" : "@gedankenstuecke I can get no, satisficing!",
    "id" : 428645625492955136,
    "in_reply_to_status_id" : 428643948757008384,
    "created_at" : "2014-01-29 21:47:35 +0000",
    "in_reply_to_screen_name" : "gedankenstuecke",
    "in_reply_to_user_id_str" : "14286491",
    "user" : {
      "name" : "ali",
      "screen_name" : "zoonpolitikon",
      "protected" : false,
      "id_str" : "13040652",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/875702734921629697\/1TUbd7IS_normal.jpg",
      "id" : 13040652,
      "verified" : false
    }
  },
  "id" : 428646197755379712,
  "created_at" : "2014-01-29 21:49:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096628567, 8.283077045 ]
  },
  "id_str" : "428643948757008384",
  "text" : "a crazy little thing called bounded rationality",
  "id" : 428643948757008384,
  "created_at" : "2014-01-29 21:40:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tobias Maier",
      "screen_name" : "weitergen",
      "indices" : [ 26, 36 ],
      "id_str" : "14717573",
      "id" : 14717573
    }, {
      "name" : "CRG",
      "screen_name" : "CRGenomica",
      "indices" : [ 71, 82 ],
      "id_str" : "202968431",
      "id" : 202968431
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "upallnightfordebugging",
      "indices" : [ 83, 106 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/Tejb5V8pjU",
      "expanded_url" : "http:\/\/youtu.be\/3ukyQ-v5pvk",
      "display_url" : "youtu.be\/3ukyQ-v5pvk"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096628567, 8.283077045 ]
  },
  "id_str" : "428640284424278016",
  "text" : "so close home it hurts MT @weitergen: [\u2026] in the bioinformatics lab of @CRGenomica #upallnightfordebugging http:\/\/t.co\/Tejb5V8pjU",
  "id" : 428640284424278016,
  "created_at" : "2014-01-29 21:26:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jennifer L. Rohn",
      "screen_name" : "JennyRohn",
      "indices" : [ 3, 13 ],
      "id_str" : "135583203",
      "id" : 135583203
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/QxbVyeLjmP",
      "expanded_url" : "http:\/\/www.timeshighereducation.co.uk\/features\/no-kidding-research-is-as-demanding-as-a-newborn\/1\/2010631.article",
      "display_url" : "timeshighereducation.co.uk\/features\/no-ki\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "428628866694119425",
  "text" : "RT @JennyRohn: Brilliant, can so relate: why it's hard for academics to stop working during maternity leave http:\/\/t.co\/QxbVyeLjmP",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 93, 115 ],
        "url" : "http:\/\/t.co\/QxbVyeLjmP",
        "expanded_url" : "http:\/\/www.timeshighereducation.co.uk\/features\/no-kidding-research-is-as-demanding-as-a-newborn\/1\/2010631.article",
        "display_url" : "timeshighereducation.co.uk\/features\/no-ki\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "428622076350840832",
    "text" : "Brilliant, can so relate: why it's hard for academics to stop working during maternity leave http:\/\/t.co\/QxbVyeLjmP",
    "id" : 428622076350840832,
    "created_at" : "2014-01-29 20:14:01 +0000",
    "user" : {
      "name" : "Jennifer L. Rohn",
      "screen_name" : "JennyRohn",
      "protected" : false,
      "id_str" : "135583203",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2103955269\/Twitter2_normal.jpg",
      "id" : 135583203,
      "verified" : true
    }
  },
  "id" : 428628866694119425,
  "created_at" : "2014-01-29 20:41:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1694318136, 8.6223468169 ]
  },
  "id_str" : "428584290059051008",
  "text" : "Should write a sudo-alias that first checks my level of sleep deprivation with fitbit &amp; denies access if amount of sleep is &lt;3 hours.",
  "id" : 428584290059051008,
  "created_at" : "2014-01-29 17:43:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723111111, 8.6276349922 ]
  },
  "id_str" : "428578833739296768",
  "text" : "\u00ABWir werden uns jetzt zur weiteren Beratung \u2013 also zum weinen \u00FCber die Ergebnisse \u2013 mit einer Flasche Schnaps ins Bett zur\u00FCckziehen.\u00BB",
  "id" : 428578833739296768,
  "created_at" : "2014-01-29 17:22:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723111111, 8.6276349922 ]
  },
  "id_str" : "428530062477242368",
  "text" : "\u00ABWillst du nicht mal langsam Vater werden? Du bist doch schon fast 30 und ich hab keine Lust mehr die Einzige mit Nachwuchs im AK zu sein!\u00BB",
  "id" : 428530062477242368,
  "created_at" : "2014-01-29 14:08:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Curry",
      "screen_name" : "Stephen_Curry",
      "indices" : [ 3, 17 ],
      "id_str" : "41358714",
      "id" : 41358714
    }, {
      "name" : "Paul Watson",
      "screen_name" : "paulmwatson",
      "indices" : [ 52, 64 ],
      "id_str" : "11214",
      "id" : 11214
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/paulmwatson\/status\/428431574766718977\/photo\/1",
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/VDmlIQN8Ui",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BfIYP0kIAAAwNKH.jpg",
      "id_str" : "428431574640885760",
      "id" : 428431574640885760,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BfIYP0kIAAAwNKH.jpg",
      "sizes" : [ {
        "h" : 808,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 505
      }, {
        "h" : 808,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 808,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/VDmlIQN8Ui"
    } ],
    "hashtags" : [ {
      "text" : "science",
      "indices" : [ 74, 82 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428495231156506624",
  "text" : "RT @Stephen_Curry: It's funny because it's true. RT @paulmwatson: Eureka? #science http:\/\/t.co\/VDmlIQN8Ui",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Paul Watson",
        "screen_name" : "paulmwatson",
        "indices" : [ 33, 45 ],
        "id_str" : "11214",
        "id" : 11214
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/paulmwatson\/status\/428431574766718977\/photo\/1",
        "indices" : [ 64, 86 ],
        "url" : "http:\/\/t.co\/VDmlIQN8Ui",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BfIYP0kIAAAwNKH.jpg",
        "id_str" : "428431574640885760",
        "id" : 428431574640885760,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BfIYP0kIAAAwNKH.jpg",
        "sizes" : [ {
          "h" : 808,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 505
        }, {
          "h" : 808,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 808,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/VDmlIQN8Ui"
      } ],
      "hashtags" : [ {
        "text" : "science",
        "indices" : [ 55, 63 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "428431574766718977",
    "geo" : { },
    "id_str" : "428493043839533056",
    "in_reply_to_user_id" : 11214,
    "text" : "It's funny because it's true. RT @paulmwatson: Eureka? #science http:\/\/t.co\/VDmlIQN8Ui",
    "id" : 428493043839533056,
    "in_reply_to_status_id" : 428431574766718977,
    "created_at" : "2014-01-29 11:41:17 +0000",
    "in_reply_to_screen_name" : "paulmwatson",
    "in_reply_to_user_id_str" : "11214",
    "user" : {
      "name" : "Stephen Curry",
      "screen_name" : "Stephen_Curry",
      "protected" : false,
      "id_str" : "41358714",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/814162182632075265\/1tXrvuPC_normal.jpg",
      "id" : 41358714,
      "verified" : true
    }
  },
  "id" : 428495231156506624,
  "created_at" : "2014-01-29 11:49:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 81, 94 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/N3aLnIVJkZ",
      "expanded_url" : "http:\/\/www.plosbiology.org\/article\/info%3Adoi%2F10.1371%2Fjournal.pbio.1001779",
      "display_url" : "plosbiology.org\/article\/info%3\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723111111, 8.6276349922 ]
  },
  "id_str" : "428458832302735360",
  "text" : "Troubleshooting Public Data Archiving: Suggestions to Increase Participation \/cc @PhilippBayer http:\/\/t.co\/N3aLnIVJkZ",
  "id" : 428458832302735360,
  "created_at" : "2014-01-29 09:25:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/fBSeboMcWn",
      "expanded_url" : "http:\/\/blogs.discovermagazine.com\/inkfish\/2014\/01\/27\/we-discovered-too-late-that-tortoises-are-expert-landscapers\/#.UujHo2Q1gnU",
      "display_url" : "blogs.discovermagazine.com\/inkfish\/2014\/0\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723111111, 8.6276349922 ]
  },
  "id_str" : "428458384921473024",
  "text" : "We Discovered Too Late That Tortoises Are Expert Landscapers http:\/\/t.co\/fBSeboMcWn",
  "id" : 428458384921473024,
  "created_at" : "2014-01-29 09:23:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mick Watson",
      "screen_name" : "BioMickWatson",
      "indices" : [ 3, 17 ],
      "id_str" : "228586748",
      "id" : 228586748
    }, {
      "name" : "The Science Web",
      "screen_name" : "TheScienceWeb",
      "indices" : [ 22, 36 ],
      "id_str" : "2315551122",
      "id" : 2315551122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/4mALzqSSDl",
      "expanded_url" : "http:\/\/wp.me\/p4ik2k-a",
      "display_url" : "wp.me\/p4ik2k-a"
    } ]
  },
  "geo" : { },
  "id_str" : "428440517324865536",
  "text" : "RT @BioMickWatson: RT @TheScienceWeb: Fairy genome sequenced, claim researchers http:\/\/t.co\/4mALzqSSDl",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The Science Web",
        "screen_name" : "TheScienceWeb",
        "indices" : [ 3, 17 ],
        "id_str" : "2315551122",
        "id" : 2315551122
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 61, 83 ],
        "url" : "http:\/\/t.co\/4mALzqSSDl",
        "expanded_url" : "http:\/\/wp.me\/p4ik2k-a",
        "display_url" : "wp.me\/p4ik2k-a"
      } ]
    },
    "geo" : { },
    "id_str" : "428439395298205696",
    "text" : "RT @TheScienceWeb: Fairy genome sequenced, claim researchers http:\/\/t.co\/4mALzqSSDl",
    "id" : 428439395298205696,
    "created_at" : "2014-01-29 08:08:06 +0000",
    "user" : {
      "name" : "Mick Watson",
      "screen_name" : "BioMickWatson",
      "protected" : false,
      "id_str" : "228586748",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/870214569679093760\/YIZGIDTS_normal.jpg",
      "id" : 228586748,
      "verified" : false
    }
  },
  "id" : 428440517324865536,
  "created_at" : "2014-01-29 08:12:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "428341695399227392",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009685666, 8.283083532 ]
  },
  "id_str" : "428345355659649024",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer me remembering which way around conditional probs. are notated is similarly slow :P",
  "id" : 428345355659649024,
  "in_reply_to_status_id" : 428341695399227392,
  "created_at" : "2014-01-29 01:54:25 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "428341609634095104",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009685666, 8.283083532 ]
  },
  "id_str" : "428342520234651648",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer p(the book will ever be done) or p(the book will be finished | I already have my PhD)? Or even p(I get a PhD)? ;)",
  "id" : 428342520234651648,
  "in_reply_to_status_id" : 428341609634095104,
  "created_at" : "2014-01-29 01:43:09 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "428341267093680128",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009685666, 8.283083532 ]
  },
  "id_str" : "428341389932638208",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer So even I will probably have done my PhD before you send me the details on what I should write about? ;)",
  "id" : 428341389932638208,
  "in_reply_to_status_id" : 428341267093680128,
  "created_at" : "2014-01-29 01:38:40 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "428340748124045312",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009685666, 8.283083532 ]
  },
  "id_str" : "428341069177454592",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer is it the book you talked about two years ago? :D",
  "id" : 428341069177454592,
  "in_reply_to_status_id" : 428340748124045312,
  "created_at" : "2014-01-29 01:37:23 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "428325095660998656",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096833167, 8.2831309344 ]
  },
  "id_str" : "428325168017326080",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer yeah, ~16 months should it be :)",
  "id" : 428325168017326080,
  "in_reply_to_status_id" : 428325095660998656,
  "created_at" : "2014-01-29 00:34:12 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "428324393345765377",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096833167, 8.2831309344 ]
  },
  "id_str" : "428324606479695872",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer meh, that sucks. Reminds me: No new reply from the billing department for the openSNP paper so far.",
  "id" : 428324606479695872,
  "in_reply_to_status_id" : 428324393345765377,
  "created_at" : "2014-01-29 00:31:58 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "428323612009848832",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096833167, 8.2831309344 ]
  },
  "id_str" : "428324178899763200",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer congrats!",
  "id" : 428324178899763200,
  "in_reply_to_status_id" : 428323612009848832,
  "created_at" : "2014-01-29 00:30:16 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jan Vanvinkenroye",
      "screen_name" : "jvanvinkenroye",
      "indices" : [ 0, 15 ],
      "id_str" : "4247301",
      "id" : 4247301
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 70 ],
      "url" : "https:\/\/t.co\/ySPVYsSRyi",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/389508570557210625",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "428298732103168001",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096833167, 8.2831309344 ]
  },
  "id_str" : "428299536160010240",
  "in_reply_to_user_id" : 4247301,
  "text" : "@jvanvinkenroye bislang nicht. ist \u00E4hnlich wie https:\/\/t.co\/ySPVYsSRyi reines grep\/awk\/sed um die Timestamps rauzuholen &amp; dann in R plotted.",
  "id" : 428299536160010240,
  "in_reply_to_status_id" : 428298732103168001,
  "created_at" : "2014-01-28 22:52:21 +0000",
  "in_reply_to_screen_name" : "jvanvinkenroye",
  "in_reply_to_user_id_str" : "4247301",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/428297019640532992\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/3neKx295B3",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BfGd3rkIUAAbhnz.png",
      "id_str" : "428297019489538048",
      "id" : 428297019489538048,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BfGd3rkIUAAbhnz.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1039,
        "resize" : "fit",
        "w" : 1367
      }, {
        "h" : 1039,
        "resize" : "fit",
        "w" : 1367
      }, {
        "h" : 517,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 912,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/3neKx295B3"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096833167, 8.2831309344 ]
  },
  "id_str" : "428297019640532992",
  "text" : "more fun analyzing chat logs with R: a density plot on how received messages varies over the day. n=10568\/1243 (A\/B) http:\/\/t.co\/3neKx295B3",
  "id" : 428297019640532992,
  "created_at" : "2014-01-28 22:42:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 97, 106 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/wiy97Kh0EV",
      "expanded_url" : "http:\/\/harebrained-schemes.com\/shadowrun\/dragonfall\/",
      "display_url" : "harebrained-schemes.com\/shadowrun\/drag\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096833167, 8.2831309344 ]
  },
  "id_str" : "428278215652966401",
  "text" : "Uh, totally missed that there\u2019s now a release date for the Berlin campaign of SRR: Feb 27th. \/cc @Senficon http:\/\/t.co\/wiy97Kh0EV",
  "id" : 428278215652966401,
  "created_at" : "2014-01-28 21:27:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096833167, 8.2831309344 ]
  },
  "id_str" : "428271611268317184",
  "text" : "Email subject: \u00ABLots of 500 errors today\u00BB Started panicing, before I noticed it\u2019s the Mendeley API mailinglist and not the one of openSNP.",
  "id" : 428271611268317184,
  "created_at" : "2014-01-28 21:01:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "History In Pictures",
      "screen_name" : "HistoryInPics",
      "indices" : [ 3, 17 ],
      "id_str" : "1582853809",
      "id" : 1582853809
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/AVfERudjmo",
      "expanded_url" : "http:\/\/sarahwerner.net\/blog\/index.php\/2014\/01\/its-history-not-a-viral-feed\/",
      "display_url" : "sarahwerner.net\/blog\/index.php\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096833167, 8.2831309344 ]
  },
  "id_str" : "428260447662669824",
  "text" : "On @HistoryInPics: \u00ABAttribution, citation, and accuracy are the basis of understanding history.\u00BB http:\/\/t.co\/AVfERudjmo",
  "id" : 428260447662669824,
  "created_at" : "2014-01-28 20:17:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096833167, 8.2831309344 ]
  },
  "id_str" : "428251859628077056",
  "text" : "yeah, autocorrect. it\u2019s most likely I wanted to send out an email saying \u2018thanks for being an awesome concussion partner\u2019\u2026",
  "id" : 428251859628077056,
  "created_at" : "2014-01-28 19:42:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/7nhlttxNLI",
      "expanded_url" : "https:\/\/www.kickstarter.com\/projects\/469596960\/kaki-king-the-neck-is-a-bridge-to-the-body",
      "display_url" : "kickstarter.com\/projects\/46959\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096833167, 8.2831309344 ]
  },
  "id_str" : "428234353257488384",
  "text" : "now I\u2019m really waiting for someone to put an OLED display onto a guitar body. https:\/\/t.co\/7nhlttxNLI",
  "id" : 428234353257488384,
  "created_at" : "2014-01-28 18:33:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0228223671, 8.2544363011 ]
  },
  "id_str" : "428211423400165376",
  "text" : "Why bioinformaticians should know some philosophy of science: you can derail every \u2018those are only in silico predictions\u2019 with epistemology.",
  "id" : 428211423400165376,
  "created_at" : "2014-01-28 17:02:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "428189832615952384",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1062863831, 8.5492361825 ]
  },
  "id_str" : "428193836196986880",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC the academic version of the Red Queen hypothesis: It\u2019s takes all the teaching just to stay in the same place.",
  "id" : 428193836196986880,
  "in_reply_to_status_id" : 428189832615952384,
  "created_at" : "2014-01-28 15:52:20 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "428188371718926336",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1196795127, 8.6509262407 ]
  },
  "id_str" : "428188862666772480",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC thought so, at least someone get\u2019s why \u2018just say no\u2019 isn\u2019t really a viable option.",
  "id" : 428188862666772480,
  "in_reply_to_status_id" : 428188371718926336,
  "created_at" : "2014-01-28 15:32:34 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1196787374, 8.6508718679 ]
  },
  "id_str" : "428187628803203072",
  "text" : "Took me four hours to go from \u2018I really should work less\u2019 to \u2018sure, I\u2019ll take another student to supervise\u2019\u2026",
  "id" : 428187628803203072,
  "created_at" : "2014-01-28 15:27:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "428128802493829120",
  "geo" : { },
  "id_str" : "428129482533126144",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC as the saying goes: if all you have are your bare hands, everything looks like it needs some punching.",
  "id" : 428129482533126144,
  "in_reply_to_status_id" : 428128802493829120,
  "created_at" : "2014-01-28 11:36:37 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1741538716, 8.6249771267 ]
  },
  "id_str" : "428124101195354112",
  "text" : "Zum Treffen der Flechten-Interessierten eingeladen worden. Time to reflect on my poor life decisions.",
  "id" : 428124101195354112,
  "created_at" : "2014-01-28 11:15:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russell Quotes",
      "screen_name" : "BertrandSez",
      "indices" : [ 3, 15 ],
      "id_str" : "2237380423",
      "id" : 2237380423
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428104756004151296",
  "text" : "RT @BertrandSez: The degree of one's emotion varies inversely with one's knowledge of the facts \u2013 the less you know the hotter you get.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/circular.io\" rel=\"nofollow\"\u003ECircular.io\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "428102549808615424",
    "text" : "The degree of one's emotion varies inversely with one's knowledge of the facts \u2013 the less you know the hotter you get.",
    "id" : 428102549808615424,
    "created_at" : "2014-01-28 09:49:36 +0000",
    "user" : {
      "name" : "Russell Quotes",
      "screen_name" : "BertrandSez",
      "protected" : false,
      "id_str" : "2237380423",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000849658233\/dcc804bf7c4e208b933a2f325fb7a35b_normal.jpeg",
      "id" : 2237380423,
      "verified" : false
    }
  },
  "id" : 428104756004151296,
  "created_at" : "2014-01-28 09:58:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "428085836882915328",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1726008161, 8.6275129672 ]
  },
  "id_str" : "428086579614482432",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC well, those tools also don\u2019t help too much if you don\u2019t have them at hand ;)",
  "id" : 428086579614482432,
  "in_reply_to_status_id" : 428085836882915328,
  "created_at" : "2014-01-28 08:46:08 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Istar Nil 0x47617921",
      "screen_name" : "istar_nil",
      "indices" : [ 0, 10 ],
      "id_str" : "314234855",
      "id" : 314234855
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 11, 24 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "427961201625022464",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0072340543, 8.283160226 ]
  },
  "id_str" : "428061661166329856",
  "in_reply_to_user_id" : 314234855,
  "text" : "@istar_nil @PhilippBayer thanks for the recommendation :)",
  "id" : 428061661166329856,
  "in_reply_to_status_id" : 427961201625022464,
  "created_at" : "2014-01-28 07:07:07 +0000",
  "in_reply_to_screen_name" : "istar_nil",
  "in_reply_to_user_id_str" : "314234855",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ed Yong",
      "screen_name" : "edyong209",
      "indices" : [ 3, 13 ],
      "id_str" : "19767193",
      "id" : 19767193
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "headdeskfacepalm",
      "indices" : [ 103, 120 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "427954793676804096",
  "text" : "RT @edyong209: \u201CDisappointed with your results? Boost your scientific paper! +10.000 correlations\/min\" #headdeskfacepalm http:\/\/t.co\/vSDJdQ\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Matt Wall",
        "screen_name" : "m_wall",
        "indices" : [ 132, 139 ],
        "id_str" : "155916643",
        "id" : 155916643
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "headdeskfacepalm",
        "indices" : [ 88, 105 ]
      } ],
      "urls" : [ {
        "indices" : [ 106, 128 ],
        "url" : "http:\/\/t.co\/vSDJdQVPYp",
        "expanded_url" : "http:\/\/andrewgelman.com\/2014\/01\/27\/disappointed-results-boost-scientific-paper\/",
        "display_url" : "andrewgelman.com\/2014\/01\/27\/dis\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "427934946779353088",
    "text" : "\u201CDisappointed with your results? Boost your scientific paper! +10.000 correlations\/min\" #headdeskfacepalm http:\/\/t.co\/vSDJdQVPYp HT @m_wall",
    "id" : 427934946779353088,
    "created_at" : "2014-01-27 22:43:36 +0000",
    "user" : {
      "name" : "Ed Yong",
      "screen_name" : "edyong209",
      "protected" : false,
      "id_str" : "19767193",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/926063794912153600\/962ygzzx_normal.jpg",
      "id" : 19767193,
      "verified" : true
    }
  },
  "id" : 427954793676804096,
  "created_at" : "2014-01-28 00:02:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "iwillshowmyselfout",
      "indices" : [ 110, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096833167, 8.2831309344 ]
  },
  "id_str" : "427954485299011585",
  "text" : "Hatte die Spackeria eigentlich damals auch beklagt das Datensch\u00FCtzer zu Night of Broken Google Glass aufruft? #iwillshowmyselfout",
  "id" : 427954485299011585,
  "created_at" : "2014-01-28 00:01:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 55, 68 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/ZH5BWkr4Y3",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=ruycfSQ9eIA",
      "display_url" : "youtube.com\/watch?v=ruycfS\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096607725, 8.2830516425 ]
  },
  "id_str" : "427943907847315456",
  "text" : "\u201Ci\u2019m on my way\u201D (with the kind of instrumentation that @PhilippBayer could love) http:\/\/t.co\/ZH5BWkr4Y3",
  "id" : 427943907847315456,
  "created_at" : "2014-01-27 23:19:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 44, 57 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 39 ],
      "url" : "http:\/\/t.co\/eZqZx2ifH6",
      "expanded_url" : "http:\/\/gunshowcomic.com\/801",
      "display_url" : "gunshowcomic.com\/801"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096607725, 8.2830516425 ]
  },
  "id_str" : "427934951053746176",
  "text" : "sign my petition http:\/\/t.co\/eZqZx2ifH6 \/HT @PhilippBayer",
  "id" : 427934951053746176,
  "created_at" : "2014-01-27 22:43:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 43 ],
      "url" : "http:\/\/t.co\/PuiPrY5Tdb",
      "expanded_url" : "http:\/\/www.qwantz.com\/index.php?comic=2564",
      "display_url" : "qwantz.com\/index.php?comi\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096607725, 8.2830516425 ]
  },
  "id_str" : "427914249135222784",
  "text" : "trading up religions http:\/\/t.co\/PuiPrY5Tdb",
  "id" : 427914249135222784,
  "created_at" : "2014-01-27 21:21:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096607725, 8.2830516425 ]
  },
  "id_str" : "427906722217611264",
  "text" : "Apparently i was promoted, from PhD to professor. If the spammy lab service providers say so it must be right!",
  "id" : 427906722217611264,
  "created_at" : "2014-01-27 20:51:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "427712556682055680",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0043091031, 8.2746757451 ]
  },
  "id_str" : "427871570594648064",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer just think of a conservative estimate of 25% of users getting notifications about new phenotypes. ;)",
  "id" : 427871570594648064,
  "in_reply_to_status_id" : 427712556682055680,
  "created_at" : "2014-01-27 18:31:46 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "427712556682055680",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0044135829, 8.2741107156 ]
  },
  "id_str" : "427871418236563456",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer forget what I said. We should do it sooner than later. I tend to forget how many users we have and what traffic that creates.",
  "id" : 427871418236563456,
  "in_reply_to_status_id" : 427712556682055680,
  "created_at" : "2014-01-27 18:31:10 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/Fa3EwkC31I",
      "expanded_url" : "http:\/\/rss.sciam.com\/~r\/all-blogs\/feed\/~3\/QMNlA1rvLkc\/",
      "display_url" : "rss.sciam.com\/~r\/all-blogs\/f\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.148428, 8.665726 ]
  },
  "id_str" : "427851117457068032",
  "text" : "Replication Crisis: \u00ABWe\u2019ve depleted inspiration from our work &amp; made everything a competition\u00BB http:\/\/t.co\/Fa3EwkC31I",
  "id" : 427851117457068032,
  "created_at" : "2014-01-27 17:10:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "427828528004866048",
  "text" : "Today another person away from keyboard correctly identified the tattoo on the back of my hand. That makes for a total of 3 in ~3 years.",
  "id" : 427828528004866048,
  "created_at" : "2014-01-27 15:40:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "427820773055930368",
  "geo" : { },
  "id_str" : "427822175794368512",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC sacrificed a tension wrench by bending into hook to unclog, afterwards hot-glued a net over it to prevent future clogging.",
  "id" : 427822175794368512,
  "in_reply_to_status_id" : 427820773055930368,
  "created_at" : "2014-01-27 15:15:29 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "427793249454284800",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722693229, 8.6276725677 ]
  },
  "id_str" : "427794010582052864",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC the tension wrench and hot-melt gun were applied to the shower\u2019s drain.",
  "id" : 427794010582052864,
  "in_reply_to_status_id" : 427793249454284800,
  "created_at" : "2014-01-27 13:23:34 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "427793249454284800",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722693229, 8.6276725677 ]
  },
  "id_str" : "427793837080469504",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC the dishwasher was saved (well, more like hot-fixed) by applying pure force in the end.",
  "id" : 427793837080469504,
  "in_reply_to_status_id" : 427793249454284800,
  "created_at" : "2014-01-27 13:22:53 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1612696888, 8.6246107317 ]
  },
  "id_str" : "427726127831191552",
  "text" : "Amazing how much better software works if you actually read the manual and not only skim it.",
  "id" : 427726127831191552,
  "created_at" : "2014-01-27 08:53:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "427712556682055680",
  "geo" : { },
  "id_str" : "427712788627062784",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer yeah, maybe not for this round of newsletters, but long-term we might hit that quota more often.",
  "id" : 427712788627062784,
  "in_reply_to_status_id" : 427712556682055680,
  "created_at" : "2014-01-27 08:00:49 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "427709263796903936",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1733131102, 8.6287127528 ]
  },
  "id_str" : "427710972988784640",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer but that sucks because then we again can\u2019t send any regular emails. Using another SMTP interface?",
  "id" : 427710972988784640,
  "in_reply_to_status_id" : 427709263796903936,
  "created_at" : "2014-01-27 07:53:37 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Atul Butte",
      "screen_name" : "atulbutte",
      "indices" : [ 3, 13 ],
      "id_str" : "262365030",
      "id" : 262365030
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/iOiNnMKUm5",
      "expanded_url" : "http:\/\/buff.ly\/MhGmxn",
      "display_url" : "buff.ly\/MhGmxn"
    } ]
  },
  "geo" : { },
  "id_str" : "427708743762333696",
  "text" : "RT @atulbutte: Realities of data sharing using genome wars as case study: historical perspective &amp; commentary http:\/\/t.co\/iOiNnMKUm5 #opend\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "opendata",
        "indices" : [ 122, 131 ]
      }, {
        "text" : "genomics",
        "indices" : [ 132, 141 ]
      } ],
      "urls" : [ {
        "indices" : [ 99, 121 ],
        "url" : "http:\/\/t.co\/iOiNnMKUm5",
        "expanded_url" : "http:\/\/buff.ly\/MhGmxn",
        "display_url" : "buff.ly\/MhGmxn"
      } ]
    },
    "geo" : { },
    "id_str" : "427669300829499393",
    "text" : "Realities of data sharing using genome wars as case study: historical perspective &amp; commentary http:\/\/t.co\/iOiNnMKUm5 #opendata #genomics",
    "id" : 427669300829499393,
    "created_at" : "2014-01-27 05:08:01 +0000",
    "user" : {
      "name" : "Atul Butte",
      "screen_name" : "atulbutte",
      "protected" : false,
      "id_str" : "262365030",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/685703528526950400\/C_EwTgXo_normal.jpg",
      "id" : 262365030,
      "verified" : true
    }
  },
  "id" : 427708743762333696,
  "created_at" : "2014-01-27 07:44:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "427708195599949825",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1581486302, 8.6543890509 ]
  },
  "id_str" : "427708595715997696",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer but yes, sounds reasonable. Though we might just run into that problem again then.",
  "id" : 427708595715997696,
  "in_reply_to_status_id" : 427708195599949825,
  "created_at" : "2014-01-27 07:44:10 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "427708195599949825",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1581486302, 8.6543890509 ]
  },
  "id_str" : "427708474764824576",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer don\u2019t have my machine with me to work, so can\u2019t check how the wrong number came to be in mail.",
  "id" : 427708474764824576,
  "in_reply_to_status_id" : 427708195599949825,
  "created_at" : "2014-01-27 07:43:41 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "427706089795108864",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1381631782, 8.6705763932 ]
  },
  "id_str" : "427706513122406400",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer yup, maybe Mail of MacOS had a display error. What does the web interface say?",
  "id" : 427706513122406400,
  "in_reply_to_status_id" : 427706089795108864,
  "created_at" : "2014-01-27 07:35:53 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "427608886586011648",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0040489994, 8.2972259168 ]
  },
  "id_str" : "427694087366774784",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer could look which addresses were used for the last mails and see whether IDs are sorted to check who didn\u2019t get one.",
  "id" : 427694087366774784,
  "in_reply_to_status_id" : 427608886586011648,
  "created_at" : "2014-01-27 06:46:31 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "427604110662062080",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096925349, 8.2830239553 ]
  },
  "id_str" : "427604400514011136",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer yes, but we can just re-enqueue the mails that failed (the day to day ones)",
  "id" : 427604400514011136,
  "in_reply_to_status_id" : 427604110662062080,
  "created_at" : "2014-01-27 00:50:08 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "427604073462759425",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009724428, 8.2830696367 ]
  },
  "id_str" : "427604205696995328",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer guess we still hit the quota or one of the quotas.",
  "id" : 427604205696995328,
  "in_reply_to_status_id" : 427604073462759425,
  "created_at" : "2014-01-27 00:49:21 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "427603234618736640",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009724428, 8.2830696367 ]
  },
  "id_str" : "427603933214019584",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer there the limit is 2000 according to that page.",
  "id" : 427603933214019584,
  "in_reply_to_status_id" : 427603234618736640,
  "created_at" : "2014-01-27 00:48:16 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "427603234618736640",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009724428, 8.2830696367 ]
  },
  "id_str" : "427603751567106050",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer ah, that\u2019s because the limit you refer to are recipients per single mail. We sent out one mail per user.",
  "id" : 427603751567106050,
  "in_reply_to_status_id" : 427603234618736640,
  "created_at" : "2014-01-27 00:47:33 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "427603234618736640",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009724428, 8.2830696367 ]
  },
  "id_str" : "427603503717314560",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer yes, but the sent mail folder says ~1300 newsletters were sent out.",
  "id" : 427603503717314560,
  "in_reply_to_status_id" : 427603234618736640,
  "created_at" : "2014-01-27 00:46:34 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "427589073692155905",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096607725, 8.2830516425 ]
  },
  "id_str" : "427589199005753344",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer well, at least the newsletter is out and at least one user already got in touch. :)",
  "id" : 427589199005753344,
  "in_reply_to_status_id" : 427589073692155905,
  "created_at" : "2014-01-26 23:49:43 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "427588344806002688",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096607725, 8.2830516425 ]
  },
  "id_str" : "427588633571622912",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer yeah, didn\u2019t remember that the subject is hardcoded into the mail-controller and not the view :P",
  "id" : 427588633571622912,
  "in_reply_to_status_id" : 427588344806002688,
  "created_at" : "2014-01-26 23:47:29 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/qX2ThIXwR4",
      "expanded_url" : "http:\/\/www.theallium.com\/computing\/westboro-baptist-church-adopts-assembler-as-their-official-programming-language\/",
      "display_url" : "theallium.com\/computing\/west\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096607725, 8.2830516425 ]
  },
  "id_str" : "427585885652414464",
  "text" : "WBC: \u00ABWe are hoping to have our first assembler program written by 2028.\u00A0 It will say \u201CHello World, God Hates Fags\u201D.\u00BB http:\/\/t.co\/qX2ThIXwR4",
  "id" : 427585885652414464,
  "created_at" : "2014-01-26 23:36:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096669233, 8.2830697956 ]
  },
  "id_str" : "427550707756326912",
  "text" : "Tragic: \u00ABA further four victims have become web developers.\u00BB",
  "id" : 427550707756326912,
  "created_at" : "2014-01-26 21:16:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Turner",
      "screen_name" : "genetics_blog",
      "indices" : [ 3, 17 ],
      "id_str" : "923639552874557440",
      "id" : 923639552874557440
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/MwxVFjnHTp",
      "expanded_url" : "http:\/\/www.theallium.com\/computing\/five-dead-twelve-injured-in-gangland-dispute-between-computer-scientists\/",
      "display_url" : "theallium.com\/computing\/five\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "427550610343600128",
  "text" : "RT @genetics_blog: Five dead, twelve injured in Perl vs Python dispute http:\/\/t.co\/MwxVFjnHTp",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 52, 74 ],
        "url" : "http:\/\/t.co\/MwxVFjnHTp",
        "expanded_url" : "http:\/\/www.theallium.com\/computing\/five-dead-twelve-injured-in-gangland-dispute-between-computer-scientists\/",
        "display_url" : "theallium.com\/computing\/five\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "427547053104054274",
    "text" : "Five dead, twelve injured in Perl vs Python dispute http:\/\/t.co\/MwxVFjnHTp",
    "id" : 427547053104054274,
    "created_at" : "2014-01-26 21:02:15 +0000",
    "user" : {
      "name" : "Stephen Turner",
      "screen_name" : "strnr",
      "protected" : false,
      "id_str" : "20444825",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/660439762856230913\/ARYE5YB6_normal.jpg",
      "id" : 20444825,
      "verified" : false
    }
  },
  "id" : 427550610343600128,
  "created_at" : "2014-01-26 21:16:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/poDTmBhQlA",
      "expanded_url" : "http:\/\/howdovaccinescauseautism.com\/",
      "display_url" : "howdovaccinescauseautism.com"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096607725, 8.2830516425 ]
  },
  "id_str" : "427527738355113984",
  "text" : "http:\/\/t.co\/poDTmBhQlA",
  "id" : 427527738355113984,
  "created_at" : "2014-01-26 19:45:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\/kala\u026A\u032Fd\u0254fo\u02D0n\/",
      "screen_name" : "Kaleidophon",
      "indices" : [ 94, 106 ],
      "id_str" : "103931655",
      "id" : 103931655
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "427521613622689792",
  "text" : "RT @melioriot: I think I finally found a research topic I can build my bachelor thesis on. RT @Kaleidophon Alcohol Language Corpus. http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "\/kala\u026A\u032Fd\u0254fo\u02D0n\/",
        "screen_name" : "Kaleidophon",
        "indices" : [ 79, 91 ],
        "id_str" : "103931655",
        "id" : 103931655
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/kAEr9b0zfd",
        "expanded_url" : "http:\/\/epub.ub.uni-muenchen.de\/13691\/",
        "display_url" : "epub.ub.uni-muenchen.de\/13691\/"
      } ]
    },
    "geo" : { },
    "id_str" : "427510625028169728",
    "text" : "I think I finally found a research topic I can build my bachelor thesis on. RT @Kaleidophon Alcohol Language Corpus. http:\/\/t.co\/kAEr9b0zfd",
    "id" : 427510625028169728,
    "created_at" : "2014-01-26 18:37:30 +0000",
    "user" : {
      "name" : "Melanie Tosik",
      "screen_name" : "meltomene",
      "protected" : false,
      "id_str" : "1329747854",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/875914925176115200\/i6nQPQdM_normal.jpg",
      "id" : 1329747854,
      "verified" : false
    }
  },
  "id" : 427521613622689792,
  "created_at" : "2014-01-26 19:21:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "C\u24D0thal G\u24D0rvey",
      "screen_name" : "onetruecathal",
      "indices" : [ 0, 14 ],
      "id_str" : "16066596",
      "id" : 16066596
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "427511310461333504",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096505978, 8.2830061612 ]
  },
  "id_str" : "427512669542035456",
  "in_reply_to_user_id" : 16066596,
  "text" : "@onetruecathal best of luck! Let me know if you think I can be of any help.",
  "id" : 427512669542035456,
  "in_reply_to_status_id" : 427511310461333504,
  "created_at" : "2014-01-26 18:45:37 +0000",
  "in_reply_to_screen_name" : "onetruecathal",
  "in_reply_to_user_id_str" : "16066596",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/jxXbMdZZzd",
      "expanded_url" : "http:\/\/www.treehugger.com\/bikes\/composer-makes-music-using-only-his-bike-instrument-video.html",
      "display_url" : "treehugger.com\/bikes\/composer\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096607725, 8.2830516425 ]
  },
  "id_str" : "427508787445252096",
  "text" : "Composer makes great music using only his bike as an instrument http:\/\/t.co\/jxXbMdZZzd",
  "id" : 427508787445252096,
  "created_at" : "2014-01-26 18:30:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathan Eisen, Guardian of Microbial Diversity \uD83D\uDCA5\uD83D\uDD06",
      "screen_name" : "phylogenomics",
      "indices" : [ 3, 17 ],
      "id_str" : "15154811",
      "id" : 15154811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "427506440958656512",
  "text" : "RT @phylogenomics: \u201CTime to consider not working w\/ BGI in any way until they address\" apparent bias against women speaking at meetings htt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/un2CxpdIF8",
        "expanded_url" : "http:\/\/phylogenomics.blogspot.com\/2014\/01\/kudos-to-doe-jgi-for-organizing.html",
        "display_url" : "phylogenomics.blogspot.com\/2014\/01\/kudos-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "427505547881897984",
    "text" : "\u201CTime to consider not working w\/ BGI in any way until they address\" apparent bias against women speaking at meetings http:\/\/t.co\/un2CxpdIF8",
    "id" : 427505547881897984,
    "created_at" : "2014-01-26 18:17:19 +0000",
    "user" : {
      "name" : "Jonathan Eisen, Guardian of Microbial Diversity \uD83D\uDCA5\uD83D\uDD06",
      "screen_name" : "phylogenomics",
      "protected" : false,
      "id_str" : "15154811",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/751288576403382273\/AKfTiFxx_normal.jpg",
      "id" : 15154811,
      "verified" : true
    }
  },
  "id" : 427506440958656512,
  "created_at" : "2014-01-26 18:20:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096607725, 8.2830516425 ]
  },
  "id_str" : "427502926442283008",
  "text" : "At the weeks beginning i burnt my hand with an acid, today with a base. That probably still makes for an average pH of 7.",
  "id" : 427502926442283008,
  "created_at" : "2014-01-26 18:06:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "-Boulet-",
      "screen_name" : "Bouletcorp",
      "indices" : [ 3, 14 ],
      "id_str" : "203530201",
      "id" : 203530201
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/c9r8clO8CA",
      "expanded_url" : "http:\/\/english.bouletcorp.com\/2014\/01\/26\/exobiology-my-love\/",
      "display_url" : "english.bouletcorp.com\/2014\/01\/26\/exo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "427496001847701504",
  "text" : "RT @Bouletcorp: English Blog - Exobiologists are assholes. http:\/\/t.co\/c9r8clO8CA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 43, 65 ],
        "url" : "http:\/\/t.co\/c9r8clO8CA",
        "expanded_url" : "http:\/\/english.bouletcorp.com\/2014\/01\/26\/exobiology-my-love\/",
        "display_url" : "english.bouletcorp.com\/2014\/01\/26\/exo\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "427494568158699520",
    "text" : "English Blog - Exobiologists are assholes. http:\/\/t.co\/c9r8clO8CA",
    "id" : 427494568158699520,
    "created_at" : "2014-01-26 17:33:42 +0000",
    "user" : {
      "name" : "-Boulet-",
      "screen_name" : "Bouletcorp",
      "protected" : false,
      "id_str" : "203530201",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/876481780752293888\/yZjD7VXI_normal.jpg",
      "id" : 203530201,
      "verified" : true
    }
  },
  "id" : 427496001847701504,
  "created_at" : "2014-01-26 17:39:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "C\u24D0thal G\u24D0rvey",
      "screen_name" : "onetruecathal",
      "indices" : [ 0, 14 ],
      "id_str" : "16066596",
      "id" : 16066596
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "427494502686027776",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096607725, 8.2830516425 ]
  },
  "id_str" : "427494624547307520",
  "in_reply_to_user_id" : 16066596,
  "text" : "@onetruecathal sure! Can\u2019t wait for \u2018not\u2019 using the kit due to legal limitations ;)",
  "id" : 427494624547307520,
  "in_reply_to_status_id" : 427494502686027776,
  "created_at" : "2014-01-26 17:33:55 +0000",
  "in_reply_to_screen_name" : "onetruecathal",
  "in_reply_to_user_id_str" : "16066596",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 125, 138 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096607725, 8.2830516425 ]
  },
  "id_str" : "427486583269646337",
  "text" : "Guess who just send out a newsletter to all openSNP users and forgot to change the mail subject from last years newsletter\u2026 \/@PhilippBayer",
  "id" : 427486583269646337,
  "created_at" : "2014-01-26 17:01:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "C\u24D0thal G\u24D0rvey",
      "screen_name" : "onetruecathal",
      "indices" : [ 12, 26 ],
      "id_str" : "16066596",
      "id" : 16066596
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/mLwjgrImzv",
      "expanded_url" : "http:\/\/www.indiegogo.com\/projects\/indiebb-your-first-gmo",
      "display_url" : "indiegogo.com\/projects\/indie\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096607725, 8.2830516425 ]
  },
  "id_str" : "427475070718869504",
  "text" : "Congrats to @onetruecathal for doing crowdfunding for a \u2018Your first GMO\u2019 DIYBio kit! Just contributed! http:\/\/t.co\/mLwjgrImzv",
  "id" : 427475070718869504,
  "created_at" : "2014-01-26 16:16:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Akshat Rathi",
      "screen_name" : "AkshatRathi",
      "indices" : [ 3, 15 ],
      "id_str" : "13766492",
      "id" : 13766492
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/OlwNOc2QKf",
      "expanded_url" : "https:\/\/medium.com\/the-year-of-the-looking-glass\/d0aa3b8af9b7",
      "display_url" : "medium.com\/the-year-of-th\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "427463759771471872",
  "text" : "RT @AkshatRathi: The cappybara sunset condition is how creative people suffer https:\/\/t.co\/OlwNOc2QKf",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 61, 84 ],
        "url" : "https:\/\/t.co\/OlwNOc2QKf",
        "expanded_url" : "https:\/\/medium.com\/the-year-of-the-looking-glass\/d0aa3b8af9b7",
        "display_url" : "medium.com\/the-year-of-th\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "427461678494912514",
    "text" : "The cappybara sunset condition is how creative people suffer https:\/\/t.co\/OlwNOc2QKf",
    "id" : 427461678494912514,
    "created_at" : "2014-01-26 15:23:00 +0000",
    "user" : {
      "name" : "Akshat Rathi",
      "screen_name" : "AkshatRathi",
      "protected" : false,
      "id_str" : "13766492",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/867091696508653568\/s5mhR4ru_normal.jpg",
      "id" : 13766492,
      "verified" : true
    }
  },
  "id" : 427463759771471872,
  "created_at" : "2014-01-26 15:31:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096761632, 8.2830077898 ]
  },
  "id_str" : "427451836275392512",
  "text" : "\u00ABit\u2019s comfortable to sleep on for two people (or three, but that is rather cosy). So you are very welcome to bring your girlfriend(s).\u00BB",
  "id" : 427451836275392512,
  "created_at" : "2014-01-26 14:43:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00962108, 8.2828545304 ]
  },
  "id_str" : "427426791125692416",
  "text" : "Advanced household problem solving, using a tension wrench and a hot-melt gun.",
  "id" : 427426791125692416,
  "created_at" : "2014-01-26 13:04:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russell Quotes",
      "screen_name" : "BertrandSez",
      "indices" : [ 3, 15 ],
      "id_str" : "2237380423",
      "id" : 2237380423
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "427380822015238144",
  "text" : "RT @BertrandSez: I have a very simple creed: that life and joy and beauty are better than dusty death.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/circular.io\" rel=\"nofollow\"\u003ECircular.io\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "427377787243331584",
    "text" : "I have a very simple creed: that life and joy and beauty are better than dusty death.",
    "id" : 427377787243331584,
    "created_at" : "2014-01-26 09:49:39 +0000",
    "user" : {
      "name" : "Russell Quotes",
      "screen_name" : "BertrandSez",
      "protected" : false,
      "id_str" : "2237380423",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000849658233\/dcc804bf7c4e208b933a2f325fb7a35b_normal.jpeg",
      "id" : 2237380423,
      "verified" : false
    }
  },
  "id" : 427380822015238144,
  "created_at" : "2014-01-26 10:01:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Dickison",
      "screen_name" : "adzebill",
      "indices" : [ 3, 12 ],
      "id_str" : "21178259",
      "id" : 21178259
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "427378573159444480",
  "text" : "RT @adzebill: Infographic designers: no more \u201CPeriodic Tables of x\u201D, please, unless 1. x exhibits ordered periodicity and 2. you know what \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "418521002776092672",
    "text" : "Infographic designers: no more \u201CPeriodic Tables of x\u201D, please, unless 1. x exhibits ordered periodicity and 2. you know what that means.",
    "id" : 418521002776092672,
    "created_at" : "2014-01-01 23:15:57 +0000",
    "user" : {
      "name" : "Mike Dickison",
      "screen_name" : "adzebill",
      "protected" : false,
      "id_str" : "21178259",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793041807781224448\/eAodxcTM_normal.png",
      "id" : 21178259,
      "verified" : false
    }
  },
  "id" : 427378573159444480,
  "created_at" : "2014-01-26 09:52:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/8tXkYJUqyi",
      "expanded_url" : "http:\/\/inurashii.tumblr.com\/post\/74445787111\/gothiccharmschool-meganphntmgrl-im-starting",
      "display_url" : "inurashii.tumblr.com\/post\/744457871\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0109488394, 8.2793382888 ]
  },
  "id_str" : "427219220678840320",
  "text" : "\u00ABwe really need to start using vampirism as a metaphor for privilege.\u00BB http:\/\/t.co\/8tXkYJUqyi",
  "id" : 427219220678840320,
  "created_at" : "2014-01-25 23:19:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "acid\u0FC8 \u1515\u1548\u1587\u1571\u15EF\u1602 \u1515\u1573\u157C\u15DD\u1602\u1571\u1587",
      "screen_name" : "acid23",
      "indices" : [ 0, 7 ],
      "id_str" : "35535998",
      "id" : 35535998
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 8, 17 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "427127464956297216",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1245329402, 8.626298603 ]
  },
  "id_str" : "427128054063063040",
  "in_reply_to_user_id" : 35535998,
  "text" : "@acid23 @Senficon in wie weit das \u2018Verrat an der guten Sache\u2019 ist war tats\u00E4chlich etwas was wir diskutiert haben.",
  "id" : 427128054063063040,
  "in_reply_to_status_id" : 427127464956297216,
  "created_at" : "2014-01-25 17:17:18 +0000",
  "in_reply_to_screen_name" : "acid23",
  "in_reply_to_user_id_str" : "35535998",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "acid\u0FC8 \u1515\u1548\u1587\u1571\u15EF\u1602 \u1515\u1573\u157C\u15DD\u1602\u1571\u1587",
      "screen_name" : "acid23",
      "indices" : [ 0, 7 ],
      "id_str" : "35535998",
      "id" : 35535998
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 13, 22 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "427124822301503488",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1225591163, 8.6297371674 ]
  },
  "id_str" : "427126177560797184",
  "in_reply_to_user_id" : 35535998,
  "text" : "@acid23 also @Senficon sagte irgendwann romantisch \u2018Wir sollten heiraten sobald es sich steuerlich lohnt!\u2019 und ich sagte \u2018na gut ;)",
  "id" : 427126177560797184,
  "in_reply_to_status_id" : 427124822301503488,
  "created_at" : "2014-01-25 17:09:51 +0000",
  "in_reply_to_screen_name" : "acid23",
  "in_reply_to_user_id_str" : "35535998",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1225717994, 8.629711924 ]
  },
  "id_str" : "427124600267624448",
  "text" : "\u00ABDu musst ja nicht politisch sein, du kannst auch ein verwaltender Verlobter sein.\u00BB",
  "id" : 427124600267624448,
  "created_at" : "2014-01-25 17:03:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 70 ],
      "url" : "http:\/\/t.co\/ubrjg2ZWTn",
      "expanded_url" : "http:\/\/instagram.com\/p\/jmWYNehwn5\/",
      "display_url" : "instagram.com\/p\/jmWYNehwn5\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.128892, 8.629462 ]
  },
  "id_str" : "427121816021504000",
  "text" : "electrocute the ones your with @ U Industriehof http:\/\/t.co\/ubrjg2ZWTn",
  "id" : 427121816021504000,
  "created_at" : "2014-01-25 16:52:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/Bi1gTnu2hK",
      "expanded_url" : "http:\/\/www.imgism.com\/the-greatest-generation-in-bed-how-millenials-are-changing-the-sexual-landscape\/",
      "display_url" : "imgism.com\/the-greatest-g\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1242691888, 8.6263340722 ]
  },
  "id_str" : "427116863194423297",
  "text" : "\u00ABBy the standards of our parents, we\u2019re all little Caligulas. And that\u2019s our greatest strength.\u00BB Yay, millennials! http:\/\/t.co\/Bi1gTnu2hK",
  "id" : 427116863194423297,
  "created_at" : "2014-01-25 16:32:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1248354029, 8.6262628395 ]
  },
  "id_str" : "427114999518330880",
  "text" : "\u00ABBe my n+1.\u00BB That escalated quickly to super cute nicknames.",
  "id" : 427114999518330880,
  "created_at" : "2014-01-25 16:25:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/io51FTgYhu",
      "expanded_url" : "http:\/\/www.slate.com\/blogs\/browbeat\/2014\/01\/24\/atheist_for_a_year_pastor_ryan_bell_explores_life_outside_seventh_day_adventist.html",
      "display_url" : "slate.com\/blogs\/browbeat\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096607725, 8.2830516425 ]
  },
  "id_str" : "427082119417180160",
  "text" : "Wonder how that will turn out: \u00ABFor the next 12 months I will live as if there is no God.\u00BB http:\/\/t.co\/io51FTgYhu",
  "id" : 427082119417180160,
  "created_at" : "2014-01-25 14:14:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 65 ],
      "url" : "http:\/\/t.co\/slSn7dnESb",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=Vug9Z7J7zmw",
      "display_url" : "youtube.com\/watch?v=Vug9Z7\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096607725, 8.2830516425 ]
  },
  "id_str" : "427079218602967040",
  "text" : "the earth don't give a damn if you're lost http:\/\/t.co\/slSn7dnESb",
  "id" : 427079218602967040,
  "created_at" : "2014-01-25 14:03:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Not New Scientist",
      "screen_name" : "NS_headlines",
      "indices" : [ 3, 16 ],
      "id_str" : "2302184618",
      "id" : 2302184618
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "426871817928966144",
  "text" : "RT @NS_headlines: Unexplained woodpecker orgies hint that your face was sculpted by junk DNA.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/endlessforms.net\" rel=\"nofollow\"\u003ENew Scientist Headline Generator\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "426481948308291584",
    "text" : "Unexplained woodpecker orgies hint that your face was sculpted by junk DNA.",
    "id" : 426481948308291584,
    "created_at" : "2014-01-23 22:29:54 +0000",
    "user" : {
      "name" : "Not New Scientist",
      "screen_name" : "NS_headlines",
      "protected" : false,
      "id_str" : "2302184618",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/425414883258023936\/lHCSqrAp_normal.jpeg",
      "id" : 2302184618,
      "verified" : false
    }
  },
  "id" : 426871817928966144,
  "created_at" : "2014-01-25 00:19:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 52 ],
      "url" : "http:\/\/t.co\/bZkx1zMCC8",
      "expanded_url" : "http:\/\/deep-dark-fears.tumblr.com\/post\/66748316121\/deep-dark-fears",
      "display_url" : "deep-dark-fears.tumblr.com\/post\/667483161\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096607725, 8.2830516425 ]
  },
  "id_str" : "426833493226954752",
  "text" : "bite each other\u2019s tongues off http:\/\/t.co\/bZkx1zMCC8",
  "id" : 426833493226954752,
  "created_at" : "2014-01-24 21:46:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/9OFdMknm8B",
      "expanded_url" : "http:\/\/onlinelibrary.wiley.com\/doi\/10.1111\/jcc4.12063\/full",
      "display_url" : "onlinelibrary.wiley.com\/doi\/10.1111\/jc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "426691124510482434",
  "text" : "The Communicative Functions of Emoticons in Workplace E-Mails http:\/\/t.co\/9OFdMknm8B",
  "id" : 426691124510482434,
  "created_at" : "2014-01-24 12:21:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shit Academics Say",
      "screen_name" : "AcademicsSay",
      "indices" : [ 3, 16 ],
      "id_str" : "1891806212",
      "id" : 1891806212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "426685875226173440",
  "text" : "RT @AcademicsSay: I need to stop calling my students kids.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "426685236001669120",
    "text" : "I need to stop calling my students kids.",
    "id" : 426685236001669120,
    "created_at" : "2014-01-24 11:57:42 +0000",
    "user" : {
      "name" : "Shit Academics Say",
      "screen_name" : "AcademicsSay",
      "protected" : false,
      "id_str" : "1891806212",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/748151916836716546\/Ldn_dhiC_normal.jpg",
      "id" : 1891806212,
      "verified" : false
    }
  },
  "id" : 426685875226173440,
  "created_at" : "2014-01-24 12:00:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/pfvSsDeliI",
      "expanded_url" : "http:\/\/nautil.us\/issue\/9\/time\/the-pleasure-and-pain-of-speed",
      "display_url" : "nautil.us\/issue\/9\/time\/t\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "426655364562427904",
  "text" : "The Pleasure and Pain of Speed \u00ABYou want to [\u2026] be able to write fast enough to keep up with what you are thinking.\u00BB http:\/\/t.co\/pfvSsDeliI",
  "id" : 426655364562427904,
  "created_at" : "2014-01-24 09:59:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "426652745802596352",
  "text" : "\u00ABSchau nicht so unschuldig, du hast schon wieder das Cluster zugespammt!\u00BB \u2013 \u00ABNo child node left behind!\u00BB",
  "id" : 426652745802596352,
  "created_at" : "2014-01-24 09:48:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/KymeZ8Zjn1",
      "expanded_url" : "http:\/\/www.newyorker.com\/online\/blogs\/elements\/2014\/01\/the-six-things-that-make-stories-go-viral-will-amaze-and-maybe-infuriate-you.html?mobify=0",
      "display_url" : "newyorker.com\/online\/blogs\/e\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "426641986066477056",
  "text" : "The Six Things That Make Stories Go Viral Will Amaze, and Maybe Infuriate, You http:\/\/t.co\/KymeZ8Zjn1",
  "id" : 426641986066477056,
  "created_at" : "2014-01-24 09:05:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/6PQCMg6Xhe",
      "expanded_url" : "http:\/\/i.imgur.com\/IFabAjC.jpg",
      "display_url" : "i.imgur.com\/IFabAjC.jpg"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1571489991, 8.5897658003 ]
  },
  "id_str" : "426625069524459520",
  "text" : "So Jesus could not have been riding a Velociraptor? Damn stratigraphy! http:\/\/t.co\/6PQCMg6Xhe",
  "id" : 426625069524459520,
  "created_at" : "2014-01-24 07:58:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 78, 91 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/UzgUHH67zw",
      "expanded_url" : "http:\/\/feedproxy.google.com\/~r\/ploscompbiol\/NewArticles\/~3\/umcMPdkADBA\/info%3Adoi%2F10.1371%2Fjournal.pcbi.1003404",
      "display_url" : "feedproxy.google.com\/~r\/ploscompbio\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "426622062019764224",
  "text" : "Bioinformatics Projects Supporting Life-Sciences Learning in High Schools \/cc @philippbayer http:\/\/t.co\/UzgUHH67zw",
  "id" : 426622062019764224,
  "created_at" : "2014-01-24 07:46:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    }, {
      "name" : "Sebastian Greiner",
      "screen_name" : "Seb666",
      "indices" : [ 7, 14 ],
      "id_str" : "2365333778",
      "id" : 2365333778
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "426522235805761537",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096347062, 8.2829917767 ]
  },
  "id_str" : "426522421072773120",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot @Seb666 ich dachte du h\u00E4ttest den Inhalt meiner B\u00FCrste mitgenommen?",
  "id" : 426522421072773120,
  "in_reply_to_status_id" : 426522235805761537,
  "created_at" : "2014-01-24 01:10:44 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Kreil",
      "screen_name" : "MichaelKreil",
      "indices" : [ 0, 13 ],
      "id_str" : "50503396",
      "id" : 50503396
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "426510042213658624",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096607725, 8.2830516425 ]
  },
  "id_str" : "426510171595345920",
  "in_reply_to_user_id" : 50503396,
  "text" : "@MichaelKreil viel Erfolg! Ich werd es am Wochenende noch mal mit mehr Zeit versuchen. :)",
  "id" : 426510171595345920,
  "in_reply_to_status_id" : 426510042213658624,
  "created_at" : "2014-01-24 00:22:03 +0000",
  "in_reply_to_screen_name" : "MichaelKreil",
  "in_reply_to_user_id_str" : "50503396",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Kreil",
      "screen_name" : "MichaelKreil",
      "indices" : [ 0, 13 ],
      "id_str" : "50503396",
      "id" : 50503396
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "426509281127845888",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096607725, 8.2830516425 ]
  },
  "id_str" : "426509781810294784",
  "in_reply_to_user_id" : 50503396,
  "text" : "@MichaelKreil das war der Trittversuch ;)",
  "id" : 426509781810294784,
  "in_reply_to_status_id" : 426509281127845888,
  "created_at" : "2014-01-24 00:20:30 +0000",
  "in_reply_to_screen_name" : "MichaelKreil",
  "in_reply_to_user_id_str" : "50503396",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096414456, 8.2829710353 ]
  },
  "id_str" : "426508393881538560",
  "text" : "Von \u2018Mal eben die Sp\u00FClmaschine reinigen\u2019 \u00FCber \u2018Letztes mal hat dagegen treten geholfen!\u2019 nach \u2018won\u2019t fix\u2019 in 30 Minuten.",
  "id" : 426508393881538560,
  "created_at" : "2014-01-24 00:14:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "426400721114644480",
  "text" : "\u00ABSorry to break the news: 'Hey Welpe, willst du mal meinen Regenwurm sezieren?' ist auch kein besserer Anmachspruch\u2026\u00BB",
  "id" : 426400721114644480,
  "created_at" : "2014-01-23 17:07:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "426371651702243328",
  "text" : "Playing the academic version of 'I'll show you mine if you show me yours': Mailing around theses.",
  "id" : 426371651702243328,
  "created_at" : "2014-01-23 15:11:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    }, {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 7, 16 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "426368119641083904",
  "geo" : { },
  "id_str" : "426371162394722304",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot @SuicideC snap, you beat me to it. Had that one prepared for days to bring it on the next possible occasion!",
  "id" : 426371162394722304,
  "in_reply_to_status_id" : 426368119641083904,
  "created_at" : "2014-01-23 15:09:41 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 127, 133 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "426364888584581120",
  "geo" : { },
  "id_str" : "426366815422255104",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC it could have been much worse. And I've learned some important lessons. I'll leave quoting the Dalai Lama on that to @Lobot",
  "id" : 426366815422255104,
  "in_reply_to_status_id" : 426364888584581120,
  "created_at" : "2014-01-23 14:52:24 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "426337087512526848",
  "text" : "\u00ABWenn du willst schmiere ich dir auch deine Innenseite mit Leckerlis ein.\u00BB \u2013 \u00ABWie kinky\u00BB \u2013 \u00ABDer Jacke!\u00BB",
  "id" : 426337087512526848,
  "created_at" : "2014-01-23 12:54:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722859996, 8.6276573082 ]
  },
  "id_str" : "426322895066124288",
  "text" : "\u00ABAww, du bist ein putziger\u2026Knutschehund!\u00BB\u2014\u00ABKurz dacht ich du meinst mich\u2026\u00BB\u2014\u00ABMeint ich auch, dann ist mir die falsche Spezies rausgerutscht.\u00BB",
  "id" : 426322895066124288,
  "created_at" : "2014-01-23 11:57:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722923039, 8.6276466344 ]
  },
  "id_str" : "426289414445473792",
  "text" : "And there finishes the last assembly, so redoing all the work lost due to my own stupidity took exactly a month.",
  "id" : 426289414445473792,
  "created_at" : "2014-01-23 09:44:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 13, 26 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/xYlBjc9EiE",
      "expanded_url" : "http:\/\/i.imgur.com\/4lLxIOr.gif",
      "display_url" : "i.imgur.com\/4lLxIOr.gif"
    } ]
  },
  "in_reply_to_status_id_str" : "426277354131165184",
  "geo" : { },
  "id_str" : "426278011449507840",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch @PhilippBayer thanks for the rescue, have a dog gif! http:\/\/t.co\/xYlBjc9EiE",
  "id" : 426278011449507840,
  "in_reply_to_status_id" : 426277354131165184,
  "created_at" : "2014-01-23 08:59:32 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 13, 26 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "426276711324717056",
  "geo" : { },
  "id_str" : "426276804169441280",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch @PhilippBayer thanks :)",
  "id" : 426276804169441280,
  "in_reply_to_status_id" : 426276711324717056,
  "created_at" : "2014-01-23 08:54:44 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 14, 26 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "426276588611588096",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @helgerausch the sidekiq-workers are down again, don't have ssh-access right now, could one of you restart them?",
  "id" : 426276588611588096,
  "created_at" : "2014-01-23 08:53:53 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "acid\u0FC8 \u1515\u1548\u1587\u1571\u15EF\u1602 \u1515\u1573\u157C\u15DD\u1602\u1571\u1587",
      "screen_name" : "acid23",
      "indices" : [ 0, 7 ],
      "id_str" : "35535998",
      "id" : 35535998
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 8, 17 ],
      "id_str" : "14861745",
      "id" : 14861745
    }, {
      "name" : "Fressesprecher",
      "screen_name" : "Bediko",
      "indices" : [ 18, 25 ],
      "id_str" : "56530362",
      "id" : 56530362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "426117144322252801",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095751529, 8.2829692357 ]
  },
  "id_str" : "426117457334763522",
  "in_reply_to_user_id" : 35535998,
  "text" : "@acid23 @Senficon @Bediko oh, gar nicht gesehen :)",
  "id" : 426117457334763522,
  "in_reply_to_status_id" : 426117144322252801,
  "created_at" : "2014-01-22 22:21:33 +0000",
  "in_reply_to_screen_name" : "acid23",
  "in_reply_to_user_id_str" : "35535998",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "acid\u0FC8 \u1515\u1548\u1587\u1571\u15EF\u1602 \u1515\u1573\u157C\u15DD\u1602\u1571\u1587",
      "screen_name" : "acid23",
      "indices" : [ 0, 7 ],
      "id_str" : "35535998",
      "id" : 35535998
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 8, 17 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "426116135827042306",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095751529, 8.2829692357 ]
  },
  "id_str" : "426116756810530816",
  "in_reply_to_user_id" : 35535998,
  "text" : "@acid23 @Senficon Raining Blood ist doch ziemlich klassisch. ;)",
  "id" : 426116756810530816,
  "in_reply_to_status_id" : 426116135827042306,
  "created_at" : "2014-01-22 22:18:46 +0000",
  "in_reply_to_screen_name" : "acid23",
  "in_reply_to_user_id_str" : "35535998",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "acid\u0FC8 \u1515\u1548\u1587\u1571\u15EF\u1602 \u1515\u1573\u157C\u15DD\u1602\u1571\u1587",
      "screen_name" : "acid23",
      "indices" : [ 0, 7 ],
      "id_str" : "35535998",
      "id" : 35535998
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 44, 53 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "426112291705090048",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095874734, 8.2829383738 ]
  },
  "id_str" : "426113001402667008",
  "in_reply_to_user_id" : 35535998,
  "text" : "@acid23 und just in dem Augenblick ergreift @Senficon ihre Gitarre m)",
  "id" : 426113001402667008,
  "in_reply_to_status_id" : 426112291705090048,
  "created_at" : "2014-01-22 22:03:50 +0000",
  "in_reply_to_screen_name" : "acid23",
  "in_reply_to_user_id_str" : "35535998",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 81 ],
      "url" : "https:\/\/t.co\/hXd47rWzME",
      "expanded_url" : "https:\/\/www.jacobinmag.com\/2014\/01\/in-the-name-of-love\/",
      "display_url" : "jacobinmag.com\/2014\/01\/in-the\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "426111334535950337",
  "text" : "\u00ABThe Problem With Doing What You Love\u00BB guilty as charged\u2026 https:\/\/t.co\/hXd47rWzME",
  "id" : 426111334535950337,
  "created_at" : "2014-01-22 21:57:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/b6kudXLKdj",
      "expanded_url" : "http:\/\/www.plosone.org\/article\/info%3Adoi%2F10.1371%2Fjournal.pone.0084997?utm_source=feedburner&utm_medium=feed&utm_campaign=Feed%3A+plosone%2FPLoSONE+%28PLOS+ONE+Alerts%3A+New+Articles%29",
      "display_url" : "plosone.org\/article\/info%3\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.010504, 8.283148 ]
  },
  "id_str" : "426109474286620672",
  "text" : "Predicting Active Users' Personality Based on Micro-Blogging Behaviors http:\/\/t.co\/b6kudXLKdj",
  "id" : 426109474286620672,
  "created_at" : "2014-01-22 21:49:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722994836, 8.6276483867 ]
  },
  "id_str" : "426025408086437888",
  "text" : "\u00ABAs a general rule, don\u2019t penetrate an orifice, pee, vomit, or bleed on someone, or slap them around without discussing the act first\u00BB",
  "id" : 426025408086437888,
  "created_at" : "2014-01-22 16:15:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laurie Penny",
      "screen_name" : "PennyRed",
      "indices" : [ 3, 12 ],
      "id_str" : "19530289",
      "id" : 19530289
    }, {
      "name" : "Stoya",
      "screen_name" : "stoya",
      "indices" : [ 68, 74 ],
      "id_str" : "14241468",
      "id" : 14241468
    }, {
      "name" : "New Statesman",
      "screen_name" : "NewStatesman",
      "indices" : [ 80, 93 ],
      "id_str" : "19906615",
      "id" : 19906615
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "426025321914449920",
  "text" : "RT @PennyRed: A porn star's guide to sexual consent. By the amazing @stoya, for @newstatesman. Honoured to have worked on this. http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Stoya",
        "screen_name" : "stoya",
        "indices" : [ 54, 60 ],
        "id_str" : "14241468",
        "id" : 14241468
      }, {
        "name" : "New Statesman",
        "screen_name" : "NewStatesman",
        "indices" : [ 66, 79 ],
        "id_str" : "19906615",
        "id" : 19906615
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/eLGCM6nPwc",
        "expanded_url" : "http:\/\/www.newstatesman.com\/voices\/2014\/01\/if-you-don%E2%80%99t-want-say-no-porn-stars-guide-sexual-consent",
        "display_url" : "newstatesman.com\/voices\/2014\/01\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "426014407483596801",
    "text" : "A porn star's guide to sexual consent. By the amazing @stoya, for @newstatesman. Honoured to have worked on this. http:\/\/t.co\/eLGCM6nPwc",
    "id" : 426014407483596801,
    "created_at" : "2014-01-22 15:32:04 +0000",
    "user" : {
      "name" : "Laurie Penny",
      "screen_name" : "PennyRed",
      "protected" : false,
      "id_str" : "19530289",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/887966692877504512\/hrvuIg4n_normal.jpg",
      "id" : 19530289,
      "verified" : true
    }
  },
  "id" : 426025321914449920,
  "created_at" : "2014-01-22 16:15:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Gori",
      "screen_name" : "kevin_gori",
      "indices" : [ 69, 80 ],
      "id_str" : "573832317",
      "id" : 573832317
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 122, 144 ],
      "url" : "http:\/\/t.co\/ix3AoovI2k",
      "expanded_url" : "http:\/\/wp.me\/p4aIA7-2u",
      "display_url" : "wp.me\/p4aIA7-2u"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1746633572, 8.6199533237 ]
  },
  "id_str" : "426005324047581184",
  "text" : "\u00ABa phylogen. analysis method that involves crystals &amp; prayer\u00BB RT @kevin_gori: So phylogenetics humour is a thing now: http:\/\/t.co\/ix3AoovI2k",
  "id" : 426005324047581184,
  "created_at" : "2014-01-22 14:55:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "425997961630208000",
  "text" : "\u00ABBei sowas merkt man halt das du nur Biologe bist. Und jetzt eine Erdnuss.\u00BB \u2013 \u00ABDas sind Waln\u00FCsse\u2026 Man merkt halt das du kein Biologe bist.\u00BB",
  "id" : 425997961630208000,
  "created_at" : "2014-01-22 14:26:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "425960708929355776",
  "text" : "\u00ABDas ist ein unfairer Vergleich! Jeder w\u00FCrde gegen den Kaktus verlieren!\u00BB",
  "id" : 425960708929355776,
  "created_at" : "2014-01-22 11:58:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "425957868802555904",
  "geo" : { },
  "id_str" : "425958815482134529",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer cool, do you just frequently google for openSNP \/w books &amp; scholar? ;)",
  "id" : 425958815482134529,
  "in_reply_to_status_id" : 425957868802555904,
  "created_at" : "2014-01-22 11:51:10 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "425955133843714048",
  "geo" : { },
  "id_str" : "425956885951287296",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer no, I hadn't seen it. So we're already mentioned in at least two books, that's pretty cool!",
  "id" : 425956885951287296,
  "in_reply_to_status_id" : 425955133843714048,
  "created_at" : "2014-01-22 11:43:30 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "425951114203123712",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722957084, 8.62765257 ]
  },
  "id_str" : "425954052707713024",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer that\u2019s the eucomaps-stuff as well ;)",
  "id" : 425954052707713024,
  "in_reply_to_status_id" : 425951114203123712,
  "created_at" : "2014-01-22 11:32:14 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "425951036868534272",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1679143246, 8.6365372159 ]
  },
  "id_str" : "425954046495969280",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer already fixed and sent out. :)",
  "id" : 425954046495969280,
  "in_reply_to_status_id" : 425951036868534272,
  "created_at" : "2014-01-22 11:32:13 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "425940692821479424",
  "text" : "Declaring UTF-8 characters in LaTeX: Raiders of the Lost Unicode Table",
  "id" : 425940692821479424,
  "created_at" : "2014-01-22 10:39:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723254853, 8.6276079152 ]
  },
  "id_str" : "425937587526959104",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer got feedback from PLOS ONE, will do the reformatting of the TeX and resubmit today. :-)",
  "id" : 425937587526959104,
  "created_at" : "2014-01-22 10:26:49 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/2tRVda6QQU",
      "expanded_url" : "http:\/\/www.wired.com\/wiredscience\/2014\/01\/how-to-hack-okcupid\/",
      "display_url" : "wired.com\/wiredscience\/2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "425922564066512896",
  "text" : "This makes it sound as if OkCupid wouldn't use imputation at all, which really would surprise me http:\/\/t.co\/2tRVda6QQU",
  "id" : 425922564066512896,
  "created_at" : "2014-01-22 09:27:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/pxt92kO4uM",
      "expanded_url" : "http:\/\/www.theatlantic.com\/technology\/archive\/2014\/01\/sit-back-relax-and-read-that-long-story-on-your-phone\/283205\/",
      "display_url" : "theatlantic.com\/technology\/arc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "425918524209385472",
  "text" : "Sit Back, Relax, and Read That Long Story\u2014on Your Phone http:\/\/t.co\/pxt92kO4uM",
  "id" : 425918524209385472,
  "created_at" : "2014-01-22 09:11:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 52 ],
      "url" : "http:\/\/t.co\/j9CHepMQV9",
      "expanded_url" : "http:\/\/boingboing.net\/2014\/01\/21\/howto-wash-your-hair-in-space.html",
      "display_url" : "boingboing.net\/2014\/01\/21\/how\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "425915833450115073",
  "text" : "HOWTO wash your hair in space http:\/\/t.co\/j9CHepMQV9",
  "id" : 425915833450115073,
  "created_at" : "2014-01-22 09:00:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 52 ],
      "url" : "http:\/\/t.co\/ipZuw6dstE",
      "expanded_url" : "http:\/\/i.imgur.com\/zFCyb8h.gif",
      "display_url" : "i.imgur.com\/zFCyb8h.gif"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0105007586, 8.2831268738 ]
  },
  "id_str" : "425892765877436416",
  "text" : "Trying to get up this morning http:\/\/t.co\/ipZuw6dstE",
  "id" : 425892765877436416,
  "created_at" : "2014-01-22 07:28:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ben goldacre",
      "screen_name" : "bengoldacre",
      "indices" : [ 3, 15 ],
      "id_str" : "6705042",
      "id" : 6705042
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/Ne5SVvd0pv",
      "expanded_url" : "http:\/\/www.vice.com\/read\/tony-blair-citizens-arrest-tramshed",
      "display_url" : "vice.com\/read\/tony-blai\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "425793273903710208",
  "text" : "RT @bengoldacre: \u201CMy boyfriend tried to put Blair under citizens arrest\u201D http:\/\/t.co\/Ne5SVvd0pv Also, mainly: fascinating bounty model http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 56, 78 ],
        "url" : "http:\/\/t.co\/Ne5SVvd0pv",
        "expanded_url" : "http:\/\/www.vice.com\/read\/tony-blair-citizens-arrest-tramshed",
        "display_url" : "vice.com\/read\/tony-blai\u2026"
      }, {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/ypmY11HzwV",
        "expanded_url" : "http:\/\/www.arrestblair.org\/",
        "display_url" : "arrestblair.org"
      } ]
    },
    "geo" : { },
    "id_str" : "425791617958543360",
    "text" : "\u201CMy boyfriend tried to put Blair under citizens arrest\u201D http:\/\/t.co\/Ne5SVvd0pv Also, mainly: fascinating bounty model http:\/\/t.co\/ypmY11HzwV",
    "id" : 425791617958543360,
    "created_at" : "2014-01-22 00:46:47 +0000",
    "user" : {
      "name" : "ben goldacre",
      "screen_name" : "bengoldacre",
      "protected" : false,
      "id_str" : "6705042",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/523118410419286016\/qXTUFTZR_normal.png",
      "id" : 6705042,
      "verified" : true
    }
  },
  "id" : 425793273903710208,
  "created_at" : "2014-01-22 00:53:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joshua Gourneau",
      "screen_name" : "gourneau",
      "indices" : [ 3, 12 ],
      "id_str" : "9552572",
      "id" : 9552572
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gourneau\/status\/425790566077857792\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/StjHfcbkI5",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bei2Q4mIAAAV9jd.png",
      "id_str" : "425790565972967424",
      "id" : 425790565972967424,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bei2Q4mIAAAV9jd.png",
      "sizes" : [ {
        "h" : 386,
        "resize" : "fit",
        "w" : 574
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 386,
        "resize" : "fit",
        "w" : 574
      }, {
        "h" : 386,
        "resize" : "fit",
        "w" : 574
      }, {
        "h" : 386,
        "resize" : "fit",
        "w" : 574
      } ],
      "display_url" : "pic.twitter.com\/StjHfcbkI5"
    } ],
    "hashtags" : [ {
      "text" : "google",
      "indices" : [ 99, 106 ]
    }, {
      "text" : "etymology",
      "indices" : [ 107, 117 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "425790687821697024",
  "text" : "RT @gourneau: Dang, Google has an etymology graph baked in to their search results now. Very cool. #google #etymology http:\/\/t.co\/StjHfcbkI5",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/gourneau\/status\/425790566077857792\/photo\/1",
        "indices" : [ 104, 126 ],
        "url" : "http:\/\/t.co\/StjHfcbkI5",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bei2Q4mIAAAV9jd.png",
        "id_str" : "425790565972967424",
        "id" : 425790565972967424,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bei2Q4mIAAAV9jd.png",
        "sizes" : [ {
          "h" : 386,
          "resize" : "fit",
          "w" : 574
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 386,
          "resize" : "fit",
          "w" : 574
        }, {
          "h" : 386,
          "resize" : "fit",
          "w" : 574
        }, {
          "h" : 386,
          "resize" : "fit",
          "w" : 574
        } ],
        "display_url" : "pic.twitter.com\/StjHfcbkI5"
      } ],
      "hashtags" : [ {
        "text" : "google",
        "indices" : [ 85, 92 ]
      }, {
        "text" : "etymology",
        "indices" : [ 93, 103 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "425790566077857792",
    "text" : "Dang, Google has an etymology graph baked in to their search results now. Very cool. #google #etymology http:\/\/t.co\/StjHfcbkI5",
    "id" : 425790566077857792,
    "created_at" : "2014-01-22 00:42:36 +0000",
    "user" : {
      "name" : "Joshua Gourneau",
      "screen_name" : "gourneau",
      "protected" : false,
      "id_str" : "9552572",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1244673486\/face_normal.jpg",
      "id" : 9552572,
      "verified" : false
    }
  },
  "id" : 425790687821697024,
  "created_at" : "2014-01-22 00:43:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "425787335129571328",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096647571, 8.2830767671 ]
  },
  "id_str" : "425788258522787840",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer next I should make the source-code of DrStickle public on GitHub for \u2018and now the same idiocy, just using Ruby (on Rails)\u2019 ;)",
  "id" : 425788258522787840,
  "in_reply_to_status_id" : 425787335129571328,
  "created_at" : "2014-01-22 00:33:26 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 126, 139 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096647571, 8.2830767671 ]
  },
  "id_str" : "425786046522343424",
  "text" : "\u00ABIch find turbo-shame ist ein toller Name.\u00BB \u2013 \u00ABKlingt nach einer Turbonegro-Coverband, f\u00FCr Leute die noch Inhibition haben.\u00BB \/@PhilippBayer",
  "id" : 425786046522343424,
  "created_at" : "2014-01-22 00:24:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ennomane",
      "screen_name" : "ennomane",
      "indices" : [ 0, 9 ],
      "id_str" : "850704103814705152",
      "id" : 850704103814705152
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "425784190547030017",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096647571, 8.2830767671 ]
  },
  "id_str" : "425785079655583744",
  "in_reply_to_user_id" : 16034275,
  "text" : "@ennomane ich dachte mehr an den Standard: \u2018Der Herr gibt es, der Herr nimmt es.\u2019",
  "id" : 425785079655583744,
  "in_reply_to_status_id" : 425784190547030017,
  "created_at" : "2014-01-22 00:20:48 +0000",
  "in_reply_to_screen_name" : "ennopark",
  "in_reply_to_user_id_str" : "16034275",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097162428, 8.2832271457 ]
  },
  "id_str" : "425783312679198720",
  "text" : "\u00ABBequeme 200\u20AC f\u00FCr einen Buttplug?!\u00BB \u2014 \u00ABMit 2.2 kg Gewicht bekommt man das Gewicht was der Geldbeutel verliert aber rektal zur\u00FCck.\u00BB",
  "id" : 425783312679198720,
  "created_at" : "2014-01-22 00:13:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "425780484405096448",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096647571, 8.2830767671 ]
  },
  "id_str" : "425780761745453056",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer thx! still have to laugh everytime I see that repo-title. :D",
  "id" : 425780761745453056,
  "in_reply_to_status_id" : 425780484405096448,
  "created_at" : "2014-01-22 00:03:38 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fitbit",
      "screen_name" : "fitbit",
      "indices" : [ 9, 16 ],
      "id_str" : "17424053",
      "id" : 17424053
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096647571, 8.2830767671 ]
  },
  "id_str" : "425777870460694529",
  "text" : "Learned: @fitbit sends out weight loss achievements even as you\u2019re becoming underweight.",
  "id" : 425777870460694529,
  "created_at" : "2014-01-21 23:52:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 72, 78 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 67 ],
      "url" : "http:\/\/t.co\/1pum256eJw",
      "expanded_url" : "http:\/\/www.plosbiology.org\/article\/info%3Adoi%2F10.1371%2Fjournal.pbio.1001767",
      "display_url" : "plosbiology.org\/article\/info%3\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096647571, 8.2830767671 ]
  },
  "id_str" : "425764820240306176",
  "text" : "Left Brain, Right Brain: Facts and Fantasies http:\/\/t.co\/1pum256eJw \/cc @Lobot",
  "id" : 425764820240306176,
  "created_at" : "2014-01-21 23:00:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Switek @MFF",
      "screen_name" : "Laelaps",
      "indices" : [ 3, 11 ],
      "id_str" : "29342640",
      "id" : 29342640
    }, {
      "name" : "keith kloor",
      "screen_name" : "keithkloor",
      "indices" : [ 128, 139 ],
      "id_str" : "20382472",
      "id" : 20382472
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/7dnXAsjFNE",
      "expanded_url" : "http:\/\/blogs.discovermagazine.com\/collideascape\/2014\/01\/21\/demise-easter-islands-eco-collapse-parable\/#.Ut70artHbCQ",
      "display_url" : "blogs.discovermagazine.com\/collideascape\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "425758603266760704",
  "text" : "RT @Laelaps: Jared Diamond's argument that Easter Island is a classic case of \"ecocide\" has fallen apart http:\/\/t.co\/7dnXAsjFNE @keithkloor",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "keith kloor",
        "screen_name" : "keithkloor",
        "indices" : [ 115, 126 ],
        "id_str" : "20382472",
        "id" : 20382472
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 92, 114 ],
        "url" : "http:\/\/t.co\/7dnXAsjFNE",
        "expanded_url" : "http:\/\/blogs.discovermagazine.com\/collideascape\/2014\/01\/21\/demise-easter-islands-eco-collapse-parable\/#.Ut70artHbCQ",
        "display_url" : "blogs.discovermagazine.com\/collideascape\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "425757495366135808",
    "text" : "Jared Diamond's argument that Easter Island is a classic case of \"ecocide\" has fallen apart http:\/\/t.co\/7dnXAsjFNE @keithkloor",
    "id" : 425757495366135808,
    "created_at" : "2014-01-21 22:31:11 +0000",
    "user" : {
      "name" : "Brian Switek @MFF",
      "screen_name" : "Laelaps",
      "protected" : false,
      "id_str" : "29342640",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/808347036579811328\/cy4jaooH_normal.jpg",
      "id" : 29342640,
      "verified" : true
    }
  },
  "id" : 425758603266760704,
  "created_at" : "2014-01-21 22:35:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096647571, 8.2830767671 ]
  },
  "id_str" : "425754572154761216",
  "text" : "\u00ABIch kenne die Unterw\u00E4sche die du aufh\u00E4ngst nicht &amp; du auch nicht? Zieht ihr einander im Dunkeln aus?!\u00BB \u2013 \u00ABNein, so schnell: Redshifting!\u00BB",
  "id" : 425754572154761216,
  "created_at" : "2014-01-21 22:19:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 65, 78 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 60 ],
      "url" : "http:\/\/t.co\/3eJmYPycyP",
      "expanded_url" : "http:\/\/english.mashkulture.net\/2014\/01\/21\/the-photography-of-hunter-s-thompson\/",
      "display_url" : "english.mashkulture.net\/2014\/01\/21\/the\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096647571, 8.2830767671 ]
  },
  "id_str" : "425740759237939200",
  "text" : "The Photography of Hunter S. Thompson http:\/\/t.co\/3eJmYPycyP \/cc @PhilippBayer",
  "id" : 425740759237939200,
  "created_at" : "2014-01-21 21:24:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096788766, 8.2830889358 ]
  },
  "id_str" : "425724931423625216",
  "text" : "Use \u2018lube\u2019 on \u2018a bunch of AA batteries\u2019. \u2026 \u2018Sticky battery acid\u2019 has been added to your inventory.",
  "id" : 425724931423625216,
  "created_at" : "2014-01-21 20:21:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "425716471604711424",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096515613, 8.2830589619 ]
  },
  "id_str" : "425717086246436864",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich ich werd es mit der lolcat bible versuchen denk ich. ;)",
  "id" : 425717086246436864,
  "in_reply_to_status_id" : 425716471604711424,
  "created_at" : "2014-01-21 19:50:37 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0085743404, 8.286416604 ]
  },
  "id_str" : "425714999118798848",
  "text" : "Kassiererin im Supermarkt will mich in ihr Abendgebet einschlie\u00DFen weil ich passend zahlen kann. Reflexartig mit \u2018danke, ebenso\u2019 antworten\u2026",
  "id" : 425714999118798848,
  "created_at" : "2014-01-21 19:42:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dvzrv",
      "screen_name" : "dvzrv",
      "indices" : [ 0, 6 ],
      "id_str" : "30868098",
      "id" : 30868098
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "425712606939471872",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0056916638, 8.2898984531 ]
  },
  "id_str" : "425713420462460928",
  "in_reply_to_user_id" : 30868098,
  "text" : "@dvzrv nah, those bumps on f and j to indicate the home row.",
  "id" : 425713420462460928,
  "in_reply_to_status_id" : 425712606939471872,
  "created_at" : "2014-01-21 19:36:03 +0000",
  "in_reply_to_screen_name" : "dvzrv",
  "in_reply_to_user_id_str" : "30868098",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.010512, 8.2831772538 ]
  },
  "id_str" : "425706730803458048",
  "text" : "\u00ABAchja, diese Nuppsies da auf der Tastatur\u2026\u00BB \u2014 \u00ABNoob-sies? Redest du von deinen Fingern?\u00BB",
  "id" : 425706730803458048,
  "created_at" : "2014-01-21 19:09:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Madeleine Price Ball",
      "screen_name" : "madprime",
      "indices" : [ 0, 9 ],
      "id_str" : "71557700",
      "id" : 71557700
    }, {
      "name" : "Yuri",
      "screen_name" : "Lucif0r",
      "indices" : [ 10, 18 ],
      "id_str" : "113398969",
      "id" : 113398969
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 19, 28 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "425692358424813568",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0076439951, 8.2826048655 ]
  },
  "id_str" : "425699556421279745",
  "in_reply_to_user_id" : 71557700,
  "text" : "@madprime @Lucif0r @Senficon that\u2019s one of the really important ones!",
  "id" : 425699556421279745,
  "in_reply_to_status_id" : 425692358424813568,
  "created_at" : "2014-01-21 18:40:58 +0000",
  "in_reply_to_screen_name" : "madprime",
  "in_reply_to_user_id_str" : "71557700",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yuri",
      "screen_name" : "Lucif0r",
      "indices" : [ 0, 8 ],
      "id_str" : "113398969",
      "id" : 113398969
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 9, 18 ],
      "id_str" : "14861745",
      "id" : 14861745
    }, {
      "name" : "Madeleine Price Ball",
      "screen_name" : "madprime",
      "indices" : [ 19, 28 ],
      "id_str" : "71557700",
      "id" : 71557700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "425688125156106240",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1085613419, 8.7042538179 ]
  },
  "id_str" : "425688746559037440",
  "in_reply_to_user_id" : 113398969,
  "text" : "@Lucif0r @Senficon @madprime guess roughly 40% are matching\/close enough, especially on reactions of other ppl.",
  "id" : 425688746559037440,
  "in_reply_to_status_id" : 425688125156106240,
  "created_at" : "2014-01-21 17:58:00 +0000",
  "in_reply_to_screen_name" : "Lucif0r",
  "in_reply_to_user_id_str" : "113398969",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1023942788, 8.7489466667 ]
  },
  "id_str" : "425686800318103552",
  "text" : "\u00ABWieso hat sie uns nur ein Besteck-Set gegeben?\u00BB\u2014\u00ABEventuell dachte sie nicht das wir teilen sondern das ich der f\u00FCtternde Altenpfleger bin?\u00BB",
  "id" : 425686800318103552,
  "created_at" : "2014-01-21 17:50:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 35, 44 ],
      "id_str" : "14861745",
      "id" : 14861745
    }, {
      "name" : "Madeleine Price Ball",
      "screen_name" : "madprime",
      "indices" : [ 48, 57 ],
      "id_str" : "71557700",
      "id" : 71557700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/MhtjmgxEkg",
      "expanded_url" : "http:\/\/www.buzzfeed.com\/jessicamisener\/21-things-that-happen-when-you-dont-eat-meat",
      "display_url" : "buzzfeed.com\/jessicamisener\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "425685583131054080",
  "text" : "Especially the elevator pitching\u2026 \/@Senficon RT @madprime: Hah \u2014 a bit of humor for veg*ns   http:\/\/t.co\/MhtjmgxEkg",
  "id" : 425685583131054080,
  "created_at" : "2014-01-21 17:45:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "425588778317910017",
  "text" : "\u00ABWas f\u00FCr Anl\u00E4sse zu weinen hast du denn sonst noch?\u00BB \u2014 \u00ABAu\u00DFer dir und Hunde-GIFs? Ich finde das f\u00FCllt meinen Tag schon ziemlich aus.\u00BB",
  "id" : 425588778317910017,
  "created_at" : "2014-01-21 11:20:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "425565030717734912",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.004543429, 8.3506357966 ]
  },
  "id_str" : "425565366220488704",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer you weren\u2019t even high school then :D",
  "id" : 425565366220488704,
  "in_reply_to_status_id" : 425565030717734912,
  "created_at" : "2014-01-21 09:47:44 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "425564120486653952",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0070758758, 8.2830740761 ]
  },
  "id_str" : "425564479154577408",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer oh, and your dating is off, we started our undergrad in autumn 2006, so it was 2007 or even 2008 (tend to think the latter)",
  "id" : 425564479154577408,
  "in_reply_to_status_id" : 425564120486653952,
  "created_at" : "2014-01-21 09:44:13 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "425564120486653952",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0070848981, 8.2830795947 ]
  },
  "id_str" : "425564285440655360",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer maybe the timestamps of your files can tell you?",
  "id" : 425564285440655360,
  "in_reply_to_status_id" : 425564120486653952,
  "created_at" : "2014-01-21 09:43:26 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "425563699152027648",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0071257281, 8.2831626145 ]
  },
  "id_str" : "425563948692549633",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer my best guess: it\u2019s the script we wrote last and had just then figured out biopython exists?",
  "id" : 425563948692549633,
  "in_reply_to_status_id" : 425563699152027648,
  "created_at" : "2014-01-21 09:42:06 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "425558931469905920",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.007316431, 8.2828563014 ]
  },
  "id_str" : "425563113128464384",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer on a positive side: it\u2019s virtually dependency free (apart from stupid from string import *). :D",
  "id" : 425563113128464384,
  "in_reply_to_status_id" : 425558931469905920,
  "created_at" : "2014-01-21 09:38:47 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 21, 33 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "425558931469905920",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096685107, 8.2830632115 ]
  },
  "id_str" : "425559500004020224",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer by now @helgerausch will either be really lucky he didn\u2019t know us what, 7(?!) years back? Or will think we still suck the same",
  "id" : 425559500004020224,
  "in_reply_to_status_id" : 425558931469905920,
  "created_at" : "2014-01-21 09:24:25 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 18, 31 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096685107, 8.2830632115 ]
  },
  "id_str" : "425557890137862144",
  "text" : "But hey, at least @PhilippBayer and I did start of with pair programming right away.",
  "id" : 425557890137862144,
  "created_at" : "2014-01-21 09:18:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 14, 27 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/3OWeikjo8x",
      "expanded_url" : "https:\/\/github.com\/drsnuggles\/turbo-shame",
      "display_url" : "github.com\/drsnuggles\/tur\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "425557767685160960",
  "text" : "Can\u2019t believe @PhilippBayer and I sucked even more at programming? this is the first stuff we ever wrote https:\/\/t.co\/3OWeikjo8x",
  "id" : 425557767685160960,
  "created_at" : "2014-01-21 09:17:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "425555429628735488",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096640493, 8.283041615 ]
  },
  "id_str" : "425555702615388160",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer yes, please! Will love to show this to my students to see where I come from when they say they will never learn programming!",
  "id" : 425555702615388160,
  "in_reply_to_status_id" : 425555429628735488,
  "created_at" : "2014-01-21 09:09:20 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "425554551987392512",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097011639, 8.283108586 ]
  },
  "id_str" : "425554679603671040",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer you should put it on GitHub! :D",
  "id" : 425554679603671040,
  "in_reply_to_status_id" : 425554551987392512,
  "created_at" : "2014-01-21 09:05:16 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "425554017129725952",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097181835, 8.283113474 ]
  },
  "id_str" : "425554280813056000",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer I\u2019d love to see that code today. :D hundreds of lines compared to what is SeqIO + Seq.obj.translate() ;)",
  "id" : 425554280813056000,
  "in_reply_to_status_id" : 425554017129725952,
  "created_at" : "2014-01-21 09:03:41 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "425496112615542785",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096739855, 8.2831043952 ]
  },
  "id_str" : "425553841321672704",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer haha, remember that this was +\/- the first huge error we encountered as we both started programming w\/ Paco (translat cds!)",
  "id" : 425553841321672704,
  "in_reply_to_status_id" : 425496112615542785,
  "created_at" : "2014-01-21 09:01:56 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "loydcase",
      "screen_name" : "loydcase",
      "indices" : [ 3, 12 ],
      "id_str" : "14187770",
      "id" : 14187770
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/nCgQatrvhn",
      "expanded_url" : "http:\/\/www.avclub.com\/article\/its-elementary-sherlock-how-the-cbs-procedural-sur-200870",
      "display_url" : "avclub.com\/article\/its-el\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "425547262266441728",
  "text" : "RT @loydcase: Yep, this is pretty much how I feel in the Sherlock vs. Elementary show debate. http:\/\/t.co\/nCgQatrvhn",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 80, 102 ],
        "url" : "http:\/\/t.co\/nCgQatrvhn",
        "expanded_url" : "http:\/\/www.avclub.com\/article\/its-elementary-sherlock-how-the-cbs-procedural-sur-200870",
        "display_url" : "avclub.com\/article\/its-el\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "425405863554060288",
    "text" : "Yep, this is pretty much how I feel in the Sherlock vs. Elementary show debate. http:\/\/t.co\/nCgQatrvhn",
    "id" : 425405863554060288,
    "created_at" : "2014-01-20 23:13:56 +0000",
    "user" : {
      "name" : "loydcase",
      "screen_name" : "loydcase",
      "protected" : false,
      "id_str" : "14187770",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/885160410638241793\/tgJCS4Tt_normal.jpg",
      "id" : 14187770,
      "verified" : false
    }
  },
  "id" : 425547262266441728,
  "created_at" : "2014-01-21 08:35:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David \u2603\uFE0FBaltrus \uD83C\uDF85\uD83C\uDF85\uD83C\uDF85\uD83C\uDF85\uD83C\uDF85\uD83C\uDF85\uD83C\uDF85\uD83C\uDF85\uD83C\uDF85\uD83C\uDF85\uD83C\uDF85\uD83C\uDF85\uD83C\uDF85\uD83C\uDF85\uD83C\uDF85",
      "screen_name" : "surt_lab",
      "indices" : [ 128, 137 ],
      "id_str" : "155230346",
      "id" : 155230346
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/wMaBVLSWA3",
      "expanded_url" : "https:\/\/twitter.com\/Dr24hours\/status\/425398567084511232\/photo\/1",
      "display_url" : "pic.twitter.com\/wMaBVLSWA3"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00968767, 8.2830140133 ]
  },
  "id_str" : "425443523123740672",
  "text" : "Where did I go wrong that my EcoEvo department never mentioned these fast tracked cocktail parties?! http:\/\/t.co\/wMaBVLSWA3 \/HT @surt_lab",
  "id" : 425443523123740672,
  "created_at" : "2014-01-21 01:43:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/AJouOEmcb4",
      "expanded_url" : "http:\/\/www.reddit.com\/r\/dogecoin\/comments\/1virfc\/lets_send_the_jamaican_bobsled_team_to_the_winter\/ceu5d3e",
      "display_url" : "reddit.com\/r\/dogecoin\/com\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00968767, 8.2830140133 ]
  },
  "id_str" : "425417768406884352",
  "text" : "\/r\/dogecoin collects 35 BTC to send the Jamaican bobsled team to the winter Olympics http:\/\/t.co\/AJouOEmcb4",
  "id" : 425417768406884352,
  "created_at" : "2014-01-21 00:01:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00968767, 8.2830140133 ]
  },
  "id_str" : "425417246576746497",
  "text" : "\u00ABHaven't you seen Cool Runnings? This is a documentary that will answer all those questions and all of life's other questions as well.\u00BB",
  "id" : 425417246576746497,
  "created_at" : "2014-01-20 23:59:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 44 ],
      "url" : "http:\/\/t.co\/Vzb2MZeLy3",
      "expanded_url" : "http:\/\/i.imgur.com\/Q3l6vJO.gif",
      "display_url" : "i.imgur.com\/Q3l6vJO.gif"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00968767, 8.2830140133 ]
  },
  "id_str" : "425413976886083584",
  "text" : "you\u2019re not a reptile\u2026 http:\/\/t.co\/Vzb2MZeLy3",
  "id" : 425413976886083584,
  "created_at" : "2014-01-20 23:46:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Q",
      "screen_name" : "DrisiS",
      "indices" : [ 3, 10 ],
      "id_str" : "769192045848035329",
      "id" : 769192045848035329
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 51 ],
      "url" : "http:\/\/t.co\/pqaHsNJQeA",
      "expanded_url" : "http:\/\/wp.me\/pxopP-10w",
      "display_url" : "wp.me\/pxopP-10w"
    } ]
  },
  "geo" : { },
  "id_str" : "425407576579518464",
  "text" : "RT @drisis: Be Not Afraid... http:\/\/t.co\/pqaHsNJQeA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 17, 39 ],
        "url" : "http:\/\/t.co\/pqaHsNJQeA",
        "expanded_url" : "http:\/\/wp.me\/pxopP-10w",
        "display_url" : "wp.me\/pxopP-10w"
      } ]
    },
    "geo" : { },
    "id_str" : "425393808470056961",
    "text" : "Be Not Afraid... http:\/\/t.co\/pqaHsNJQeA",
    "id" : 425393808470056961,
    "created_at" : "2014-01-20 22:26:02 +0000",
    "user" : {
      "name" : "DrBates",
      "screen_name" : "BatesPhysio",
      "protected" : false,
      "id_str" : "17156053",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/827517314128048133\/9d5mFk7Y_normal.jpg",
      "id" : 17156053,
      "verified" : false
    }
  },
  "id" : 425407576579518464,
  "created_at" : "2014-01-20 23:20:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/4dY9bwOKvn",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=ZDWTjkHb9nY",
      "display_url" : "youtube.com\/watch?v=ZDWTjk\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00968767, 8.2830140133 ]
  },
  "id_str" : "425405033296179200",
  "text" : "\u00ABMeine ganze liebevolle Musikauswahl wird hier voll gepwned von merengue-tanzenden Pudeln..\u00BB https:\/\/t.co\/4dY9bwOKvn",
  "id" : 425405033296179200,
  "created_at" : "2014-01-20 23:10:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00968767, 8.2830140133 ]
  },
  "id_str" : "425404099472150528",
  "text" : "Dinge die ich in IPython ausrechne: Den Verwendungszweck f\u00FCr die \u00DCberweisung zur Semesterr\u00FCckmeldung.",
  "id" : 425404099472150528,
  "created_at" : "2014-01-20 23:06:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/mZqaS17ZPx",
      "expanded_url" : "http:\/\/i.imgur.com\/bRL6eOw.jpg?1",
      "display_url" : "i.imgur.com\/bRL6eOw.jpg?1"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00966487, 8.2829890883 ]
  },
  "id_str" : "425400245045194752",
  "text" : "Oh noes, I missed Eddie\u2019s birthday. Still: Happy Birthday! http:\/\/t.co\/mZqaS17ZPx",
  "id" : 425400245045194752,
  "created_at" : "2014-01-20 22:51:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Mims\uD83E\uDD33",
      "screen_name" : "mims",
      "indices" : [ 3, 8 ],
      "id_str" : "1769191",
      "id" : 1769191
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "425380882535706624",
  "text" : "RT @mims: By putting the decision of whom to rent to in the hands of everyday people, AirBnB leads to racial discrimination http:\/\/t.co\/rt4\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sites.google.com\/site\/yorufukurou\/\" rel=\"nofollow\"\u003EYoruFukurou\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/rt4oi0kXeV",
        "expanded_url" : "http:\/\/www.bostonglobe.com\/metro\/2014\/01\/20\/study-airbnb-com-rental-site-suggests-online-marketplaces-may-encourage-discrimination\/fMelyoLMVr1tthDVx8DUAK\/story.html",
        "display_url" : "bostonglobe.com\/metro\/2014\/01\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "425380312315863040",
    "text" : "By putting the decision of whom to rent to in the hands of everyday people, AirBnB leads to racial discrimination http:\/\/t.co\/rt4oi0kXeV",
    "id" : 425380312315863040,
    "created_at" : "2014-01-20 21:32:24 +0000",
    "user" : {
      "name" : "Christopher Mims\uD83E\uDD33",
      "screen_name" : "mims",
      "protected" : false,
      "id_str" : "1769191",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/805781204381351936\/_P3k7Gmn_normal.jpg",
      "id" : 1769191,
      "verified" : true
    }
  },
  "id" : 425380882535706624,
  "created_at" : "2014-01-20 21:34:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "not best practice",
      "screen_name" : "moeffju",
      "indices" : [ 75, 83 ],
      "id_str" : "5618832",
      "id" : 5618832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0043895981, 8.3488265891 ]
  },
  "id_str" : "425353001814224896",
  "text" : "\u00ABWollen wir mal eine Konfrontationstherapie-Reise nach Hamburg machen?\u00BB \u2014 \u00AB@moeffju und Mumien?\u00BB",
  "id" : 425353001814224896,
  "created_at" : "2014-01-20 19:43:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leon \uD83C\uDFF3\uFE0F\u200D\uD83C\uDF08\uD83C\uDF3F\uD83D\uDD2C",
      "screen_name" : "orchidhunter",
      "indices" : [ 3, 16 ],
      "id_str" : "21607925",
      "id" : 21607925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "425350543096430593",
  "text" : "RT @orchidhunter: I want to tell those smart gay kids out there that choosing a career in science will expose you to so much wonder and so \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "425343075347890176",
    "text" : "I want to tell those smart gay kids out there that choosing a career in science will expose you to so much wonder and so many warm people.",
    "id" : 425343075347890176,
    "created_at" : "2014-01-20 19:04:26 +0000",
    "user" : {
      "name" : "Leon \uD83C\uDFF3\uFE0F\u200D\uD83C\uDF08\uD83C\uDF3F\uD83D\uDD2C",
      "screen_name" : "orchidhunter",
      "protected" : false,
      "id_str" : "21607925",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/860516945430429696\/NhIYG1Lp_normal.jpg",
      "id" : 21607925,
      "verified" : false
    }
  },
  "id" : 425350543096430593,
  "created_at" : "2014-01-20 19:34:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "skytee",
      "screen_name" : "skytee",
      "indices" : [ 3, 10 ],
      "id_str" : "14472998",
      "id" : 14472998
    }, {
      "name" : "P.G. Wokehouse (Aaron Muszalski)",
      "screen_name" : "sfslim",
      "indices" : [ 112, 119 ],
      "id_str" : "1211311",
      "id" : 1211311
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/P4gTc1byKl",
      "expanded_url" : "http:\/\/www.glassandsex.com\/",
      "display_url" : "glassandsex.com"
    } ]
  },
  "geo" : { },
  "id_str" : "425350020909793281",
  "text" : "RT @skytee: Rule 34 applies. \u201CWear Glass. Have Sex. See what your partner can see.\u201D http:\/\/t.co\/P4gTc1byKl (via @sfslim)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twicca.r246.jp\/\" rel=\"nofollow\"\u003Etwicca\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "P.G. Wokehouse (Aaron Muszalski)",
        "screen_name" : "sfslim",
        "indices" : [ 100, 107 ],
        "id_str" : "1211311",
        "id" : 1211311
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 72, 94 ],
        "url" : "http:\/\/t.co\/P4gTc1byKl",
        "expanded_url" : "http:\/\/www.glassandsex.com\/",
        "display_url" : "glassandsex.com"
      } ]
    },
    "geo" : { },
    "id_str" : "425320900666597376",
    "text" : "Rule 34 applies. \u201CWear Glass. Have Sex. See what your partner can see.\u201D http:\/\/t.co\/P4gTc1byKl (via @sfslim)",
    "id" : 425320900666597376,
    "created_at" : "2014-01-20 17:36:19 +0000",
    "user" : {
      "name" : "skytee",
      "screen_name" : "skytee",
      "protected" : false,
      "id_str" : "14472998",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000649725384\/53038b89c6e669d3eaa4724f30d76acf_normal.jpeg",
      "id" : 14472998,
      "verified" : false
    }
  },
  "id" : 425350020909793281,
  "created_at" : "2014-01-20 19:32:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1022951231, 8.7491359506 ]
  },
  "id_str" : "425341204356931584",
  "text" : "\u00ABIch bin so verliebt in dich, f\u00FCr dich w\u00FCrde ich sogar meine \u00D6tzi-Maske abnehmen.\u00BB",
  "id" : 425341204356931584,
  "created_at" : "2014-01-20 18:57:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1391671849, 8.6670104245 ]
  },
  "id_str" : "425296060706467840",
  "text" : "\u00ABStrassenbahn wurde von der Polizei gestoppt, S-Bahn verpasst, +5 min\u00BB \u2014 \u00ABGratulation, du konntest also noch fl\u00FCchten!\u00BB",
  "id" : 425296060706467840,
  "created_at" : "2014-01-20 15:57:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "425269423159529472",
  "geo" : { },
  "id_str" : "425270919662014464",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot Die UI sieht aber so aus als h\u00E4tten die Entwickler zu der Zeit das dann gerade moderne Rogue gespielt\u2026",
  "id" : 425270919662014464,
  "in_reply_to_status_id" : 425269423159529472,
  "created_at" : "2014-01-20 14:17:43 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "425268355570749440",
  "text" : "Der Horde-Webmailer heisst doch bestimmt so weil nur Barbaren mit dem UI leben k\u00F6nnen k\u00F6nnen\u2026",
  "id" : 425268355570749440,
  "created_at" : "2014-01-20 14:07:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/pYPx5hSJEm",
      "expanded_url" : "http:\/\/imgur.com\/a\/I2KoT",
      "display_url" : "imgur.com\/a\/I2KoT"
    } ]
  },
  "geo" : { },
  "id_str" : "425263186988658689",
  "text" : "\/r\/behindthegifs: \u00ABMaybe my life is mine to shape &amp; I'm not defined by your cultural expectations\u00BB http:\/\/t.co\/pYPx5hSJEm",
  "id" : 425263186988658689,
  "created_at" : "2014-01-20 13:46:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/Q6LbB7uN3e",
      "expanded_url" : "http:\/\/i.imgur.com\/36cR9q5.jpg",
      "display_url" : "i.imgur.com\/36cR9q5.jpg"
    } ]
  },
  "geo" : { },
  "id_str" : "425238170054033408",
  "text" : "\u00ABDu solltest ihr einen Leckstein besorgen.\u00BB \u2013 \u00ABIch w\u00FCrde mich auch anbieten!\u00BB http:\/\/t.co\/Q6LbB7uN3e",
  "id" : 425238170054033408,
  "created_at" : "2014-01-20 12:07:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723259983, 8.6276232757 ]
  },
  "id_str" : "425233060368777216",
  "text" : "\u00ABTraumatische Erinnerungen bleiben, Opa erz\u00E4hlt z.B. immer noch von Dresden 1945.\u00BB\u2014\u00ABIch kann mich auch noch an den Kindergarten erinnern!\u00BB",
  "id" : 425233060368777216,
  "created_at" : "2014-01-20 11:47:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "425199808861589504",
  "geo" : { },
  "id_str" : "425206254609240064",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer something about their assumptions bugs me from a pop-gen point of view, but I can't really point my finger on it yet.",
  "id" : 425206254609240064,
  "in_reply_to_status_id" : 425199808861589504,
  "created_at" : "2014-01-20 10:00:45 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 3, 16 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 84, 100 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/9ju02949XI",
      "expanded_url" : "http:\/\/arxiv.org\/abs\/1401.4181",
      "display_url" : "arxiv.org\/abs\/1401.4181"
    } ]
  },
  "geo" : { },
  "id_str" : "425203215488286720",
  "text" : "RT @PhilippBayer: Demography and the age of rare variants http:\/\/t.co\/9ju02949XI cc @gedankenstuecke",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 66, 82 ],
        "id_str" : "14286491",
        "id" : 14286491
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 40, 62 ],
        "url" : "http:\/\/t.co\/9ju02949XI",
        "expanded_url" : "http:\/\/arxiv.org\/abs\/1401.4181",
        "display_url" : "arxiv.org\/abs\/1401.4181"
      } ]
    },
    "geo" : { },
    "id_str" : "425199808861589504",
    "text" : "Demography and the age of rare variants http:\/\/t.co\/9ju02949XI cc @gedankenstuecke",
    "id" : 425199808861589504,
    "created_at" : "2014-01-20 09:35:08 +0000",
    "user" : {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "protected" : false,
      "id_str" : "121777206",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2013711027\/IMG_1088_normal.png",
      "id" : 121777206,
      "verified" : false
    }
  },
  "id" : 425203215488286720,
  "created_at" : "2014-01-20 09:48:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 8, 21 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/ne4E6v03RT",
      "expanded_url" : "http:\/\/m.nydailynews.com\/1.1433797",
      "display_url" : "m.nydailynews.com\/1.1433797"
    } ]
  },
  "geo" : { },
  "id_str" : "425196899247742976",
  "text" : "I think @PhilippBayer will be delighted: \u00ABScientists invent hydrating, hangover-free beer\u00BB http:\/\/t.co\/ne4E6v03RT",
  "id" : 425196899247742976,
  "created_at" : "2014-01-20 09:23:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "425191071753052160",
  "text" : "\u00ABDu hast 4h f\u00FCr den Weg nach Hause gebraucht?! Du hast doch ein Smartphone!\u00BB \u2013 \u00ABIch bin aber zu stolz f\u00FCr Google Maps.\u00BB \u2013 \u00ABStolz worauf?!\u00BB",
  "id" : 425191071753052160,
  "created_at" : "2014-01-20 09:00:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "425190218879094784",
  "geo" : { },
  "id_str" : "425190612686499840",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer the one game I played somewhat professionally. Mainly because spray &amp; pray worked so well with the Chicago Typewriter ;)",
  "id" : 425190612686499840,
  "in_reply_to_status_id" : 425190218879094784,
  "created_at" : "2014-01-20 08:58:36 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/mzSsucLToH",
      "expanded_url" : "http:\/\/dasnuf.de\/zeug\/messer-gabel-schere-licht-sind-fuer-kleine-kinder\/",
      "display_url" : "dasnuf.de\/zeug\/messer-ga\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "425189823029071874",
  "text" : "\u00ABMesser, Gabel, Schere, Licht \u2013 sind f\u00FCr kleine Kinder\u00BB http:\/\/t.co\/mzSsucLToH",
  "id" : 425189823029071874,
  "created_at" : "2014-01-20 08:55:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 39 ],
      "url" : "http:\/\/t.co\/ZlksgH7Za0",
      "expanded_url" : "http:\/\/www.boomcalifornia.com\/2014\/01\/hotel-california\/",
      "display_url" : "boomcalifornia.com\/2014\/01\/hotel-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "425188901586628608",
  "text" : "Hotel California http:\/\/t.co\/ZlksgH7Za0",
  "id" : 425188901586628608,
  "created_at" : "2014-01-20 08:51:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "425161672114704385",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0691808091, 8.4850987727 ]
  },
  "id_str" : "425162832343490560",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon btw: after making it through the first third of \u2018The Victory Lab\u2019 I think that it would be right up your alley.",
  "id" : 425162832343490560,
  "in_reply_to_status_id" : 425161672114704385,
  "created_at" : "2014-01-20 07:08:13 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "425160669067870208",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0668266565, 8.4771560711 ]
  },
  "id_str" : "425161541714186240",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon misread: WakeUpRoomba m)",
  "id" : 425161541714186240,
  "in_reply_to_status_id" : 425160669067870208,
  "created_at" : "2014-01-20 07:03:05 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Lillie",
      "screen_name" : "BenLillie",
      "indices" : [ 3, 13 ],
      "id_str" : "15949242",
      "id" : 15949242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "425158623632044032",
  "text" : "RT @BenLillie: \"No, Jane Austen Was Not a Game Theorist\" *Fantastic* article on a certain style of art\/science writing. http:\/\/t.co\/micvfde\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 105, 127 ],
        "url" : "http:\/\/t.co\/micvfde1xn",
        "expanded_url" : "http:\/\/www.newrepublic.com\/article\/116170\/jane-austen-game-theorist-michael-suk-young-chwe-joke",
        "display_url" : "newrepublic.com\/article\/116170\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "425071363464777728",
    "text" : "\"No, Jane Austen Was Not a Game Theorist\" *Fantastic* article on a certain style of art\/science writing. http:\/\/t.co\/micvfde1xn",
    "id" : 425071363464777728,
    "created_at" : "2014-01-20 01:04:45 +0000",
    "user" : {
      "name" : "Ben Lillie",
      "screen_name" : "BenLillie",
      "protected" : false,
      "id_str" : "15949242",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/438743857908695040\/SkeP0H-u_normal.jpeg",
      "id" : 15949242,
      "verified" : false
    }
  },
  "id" : 425158623632044032,
  "created_at" : "2014-01-20 06:51:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "425080465762947075",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096413324, 8.2830073302 ]
  },
  "id_str" : "425151381482536960",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer see, for me it would be Ultima Online &amp; Day of Defeat. Completely different set of experiences. ;)",
  "id" : 425151381482536960,
  "in_reply_to_status_id" : 425080465762947075,
  "created_at" : "2014-01-20 06:22:42 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "425073458179874816",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096659621, 8.2829682921 ]
  },
  "id_str" : "425075744419897344",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer guess we just had different experiences while coming of age (after all: neither me nor my relatives ever used explosives! :p)",
  "id" : 425075744419897344,
  "in_reply_to_status_id" : 425073458179874816,
  "created_at" : "2014-01-20 01:22:09 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "425073458179874816",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096993242, 8.2831284776 ]
  },
  "id_str" : "425074122809704448",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer I see, I\u2019m fine with that kind of mashup (but then I actually could relate to many of the characters)",
  "id" : 425074122809704448,
  "in_reply_to_status_id" : 425073458179874816,
  "created_at" : "2014-01-20 01:15:43 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "425063262334365696",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00966487, 8.2829890883 ]
  },
  "id_str" : "425063662752395264",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer nice! Not sure whether I\u2019ll be awake in an hour, but tomorrow morning (EST) should be good enough :)",
  "id" : 425063662752395264,
  "in_reply_to_status_id" : 425063262334365696,
  "created_at" : "2014-01-20 00:34:09 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "425062224093126656",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00966487, 8.2829890883 ]
  },
  "id_str" : "425062348806971392",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer great, let me know if you\u2019re done with it and I will send the answers out, the author has a deadline as well :)",
  "id" : 425062348806971392,
  "in_reply_to_status_id" : 425062224093126656,
  "created_at" : "2014-01-20 00:28:55 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 44 ],
      "url" : "http:\/\/t.co\/GVAr9PER82",
      "expanded_url" : "http:\/\/whatshouldwecallgradschool.tumblr.com\/post\/73874603294\/when-i-meet-a-bioinformatics-student",
      "display_url" : "whatshouldwecallgradschool.tumblr.com\/post\/738746032\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00966487, 8.2829890883 ]
  },
  "id_str" : "425061987094376448",
  "text" : "funny cause it\u2019s true http:\/\/t.co\/GVAr9PER82",
  "id" : 425061987094376448,
  "created_at" : "2014-01-20 00:27:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "425061238519767040",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00966487, 8.2829890883 ]
  },
  "id_str" : "425061747830296576",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer btw. did you find time to have a look at the interview-answers in the pad?",
  "id" : 425061747830296576,
  "in_reply_to_status_id" : 425061238519767040,
  "created_at" : "2014-01-20 00:26:32 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "425061238519767040",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00966487, 8.2829890883 ]
  },
  "id_str" : "425061440798859264",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer you\u2019ll never encounter a specimen that shows 100% of all the features, but the ideal. drawing gives you an idea what to expect",
  "id" : 425061440798859264,
  "in_reply_to_status_id" : 425061238519767040,
  "created_at" : "2014-01-20 00:25:19 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "425058769794371584",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00966487, 8.2829890883 ]
  },
  "id_str" : "425061041907974144",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer yes, the characters are idealized\/romanticised mashups for good part. But it\u2019s a bit like drawing organisms\/taking photographs",
  "id" : 425061041907974144,
  "in_reply_to_status_id" : 425058769794371584,
  "created_at" : "2014-01-20 00:23:44 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/0g7nU1SgF4",
      "expanded_url" : "http:\/\/en.wikipedia.org\/wiki\/The_Perks_of_Being_a_Wallflower#Background",
      "display_url" : "en.wikipedia.org\/wiki\/The_Perks\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "425058769794371584",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00966487, 8.2829890883 ]
  },
  "id_str" : "425060682485489664",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer interesting opinion on the Perks. Disagree slightly, see the background according to Wikipedia: http:\/\/t.co\/0g7nU1SgF4",
  "id" : 425060682485489664,
  "in_reply_to_status_id" : 425058769794371584,
  "created_at" : "2014-01-20 00:22:18 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096674391, 8.2830027485 ]
  },
  "id_str" : "425057498429947904",
  "text" : "\u00ABPasst: Es sind nur 3 Akkorde &amp; wir haben 3 Gitarren. Jeder ein Open Tuning und schon k\u00F6nnen wir literally \u2018One Hand In My Pocket\u2019 spielen!\u00BB",
  "id" : 425057498429947904,
  "created_at" : "2014-01-20 00:09:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    }, {
      "name" : "not best practice",
      "screen_name" : "moeffju",
      "indices" : [ 24, 32 ],
      "id_str" : "5618832",
      "id" : 5618832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "425014260549177344",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1003623539, 8.2649952556 ]
  },
  "id_str" : "425049317846810624",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot und Sascha Lobo! @moeffju",
  "id" : 425049317846810624,
  "in_reply_to_status_id" : 425014260549177344,
  "created_at" : "2014-01-19 23:37:09 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1001759025, 8.2647936069 ]
  },
  "id_str" : "425013270899351552",
  "text" : "\u00ABIch bin jetzt auch ein Goatse!\u00BB \u2014 \u00ABCome again?!\u00BB \u2014 \u00ABIch kann jetzt Go spielen\u2026\u00BB",
  "id" : 425013270899351552,
  "created_at" : "2014-01-19 21:13:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1012688626, 8.2646965988 ]
  },
  "id_str" : "424976153603231744",
  "text" : "\u00ABIn der Suchtpr\u00E4vention ist es nat\u00FCrlich nicht meine Aufgabe den Kids zu sagen das sie nicht an Joints nuckeln sollen, finden die voll geil\u00BB",
  "id" : 424976153603231744,
  "created_at" : "2014-01-19 18:46:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096605391, 8.2830749966 ]
  },
  "id_str" : "424898574959529984",
  "text" : "\u00ABIch habe dir gerade das Mayorship vom Elfenbeinturm geklaut. Beim Kacken!\u00BB",
  "id" : 424898574959529984,
  "created_at" : "2014-01-19 13:38:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 79 ],
      "url" : "http:\/\/t.co\/7PezZJMJTf",
      "expanded_url" : "http:\/\/www.amazon.com\/gp\/aw\/d\/B005MR3IVO",
      "display_url" : "amazon.com\/gp\/aw\/d\/B005MR\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096268434, 8.2831254744 ]
  },
  "id_str" : "424865434341736448",
  "text" : "\u00ABIch zieh mit meiner Zahnb\u00FCrste in ein Fass. Voll Lube!\u00BB http:\/\/t.co\/7PezZJMJTf",
  "id" : 424865434341736448,
  "created_at" : "2014-01-19 11:26:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Weber",
      "screen_name" : "scy",
      "indices" : [ 0, 4 ],
      "id_str" : "8308632",
      "id" : 8308632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 48 ],
      "url" : "http:\/\/t.co\/qjLyuriuZp",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=fXUozbjbERg",
      "display_url" : "youtube.com\/watch?v=fXUozb\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "424571904473972736",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00966487, 8.2829890883 ]
  },
  "id_str" : "424573702223953920",
  "in_reply_to_user_id" : 8308632,
  "text" : "@scy suck a bag of dicks! http:\/\/t.co\/qjLyuriuZp",
  "id" : 424573702223953920,
  "in_reply_to_status_id" : 424571904473972736,
  "created_at" : "2014-01-18 16:07:13 +0000",
  "in_reply_to_screen_name" : "scy",
  "in_reply_to_user_id_str" : "8308632",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/N99tXFY9GL",
      "expanded_url" : "http:\/\/www.plosone.org\/article\/info%3Adoi%2F10.1371%2Fjournal.pone.0084896",
      "display_url" : "plosone.org\/article\/info%3\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00966487, 8.2829890883 ]
  },
  "id_str" : "424544534656454656",
  "text" : "Surprise \u00ABWhy Publishing Everything Is More Effective than Selective Publishing of Statistically Significant Results\u00BB http:\/\/t.co\/N99tXFY9GL",
  "id" : 424544534656454656,
  "created_at" : "2014-01-18 14:11:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 80, 93 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/XO1BVrJhNc",
      "expanded_url" : "http:\/\/www.plosone.org\/article\/info%3Adoi%2F10.1371%2Fjournal.pone.0085710",
      "display_url" : "plosone.org\/article\/info%3\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00966487, 8.2829890883 ]
  },
  "id_str" : "424534066172801024",
  "text" : "Ecoinformatics Reveals Effects of Crop Rotational Histories on Cotton Yield \/cc @PhilippBayer http:\/\/t.co\/XO1BVrJhNc",
  "id" : 424534066172801024,
  "created_at" : "2014-01-18 13:29:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 0, 10 ],
      "id_str" : "14700783",
      "id" : 14700783
    }, {
      "name" : "Rya",
      "screen_name" : "_Rya_",
      "indices" : [ 11, 17 ],
      "id_str" : "89234537",
      "id" : 89234537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "424507239152746497",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00966487, 8.2829890883 ]
  },
  "id_str" : "424507395927474176",
  "in_reply_to_user_id" : 14700783,
  "text" : "@Fischblog @_Rya_ etwa auch gerade erst erfolgreich den SIWOTI-Entzug durchgemacht? ;)",
  "id" : 424507395927474176,
  "in_reply_to_status_id" : 424507239152746497,
  "created_at" : "2014-01-18 11:43:44 +0000",
  "in_reply_to_screen_name" : "Fischblog",
  "in_reply_to_user_id_str" : "14700783",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dvzrv",
      "screen_name" : "dvzrv",
      "indices" : [ 0, 6 ],
      "id_str" : "30868098",
      "id" : 30868098
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 7, 20 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "424494686544609280",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00966487, 8.2829890883 ]
  },
  "id_str" : "424494847123521536",
  "in_reply_to_user_id" : 30868098,
  "text" : "@dvzrv @PhilippBayer then best of luck for the courses as well :)",
  "id" : 424494847123521536,
  "in_reply_to_status_id" : 424494686544609280,
  "created_at" : "2014-01-18 10:53:52 +0000",
  "in_reply_to_screen_name" : "dvzrv",
  "in_reply_to_user_id_str" : "30868098",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dvzrv",
      "screen_name" : "dvzrv",
      "indices" : [ 0, 6 ],
      "id_str" : "30868098",
      "id" : 30868098
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 27, 40 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "424493856768270336",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00966487, 8.2829890883 ]
  },
  "id_str" : "424494038218448896",
  "in_reply_to_user_id" : 30868098,
  "text" : "@dvzrv yeah, let me (or us @PhilippBayer) know if we can be of any help. :)",
  "id" : 424494038218448896,
  "in_reply_to_status_id" : 424493856768270336,
  "created_at" : "2014-01-18 10:50:40 +0000",
  "in_reply_to_screen_name" : "dvzrv",
  "in_reply_to_user_id_str" : "30868098",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dvzrv",
      "screen_name" : "dvzrv",
      "indices" : [ 0, 6 ],
      "id_str" : "30868098",
      "id" : 30868098
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "424493441733517312",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00966487, 8.2829890883 ]
  },
  "id_str" : "424493637624664064",
  "in_reply_to_user_id" : 30868098,
  "text" : "@dvzrv you could ask my supervisor, just argue that it\u2019s really applied bioinformatics :p",
  "id" : 424493637624664064,
  "in_reply_to_status_id" : 424493441733517312,
  "created_at" : "2014-01-18 10:49:04 +0000",
  "in_reply_to_screen_name" : "dvzrv",
  "in_reply_to_user_id_str" : "30868098",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dvzrv",
      "screen_name" : "dvzrv",
      "indices" : [ 0, 6 ],
      "id_str" : "30868098",
      "id" : 30868098
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "424493100384260096",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00966487, 8.2829890883 ]
  },
  "id_str" : "424493155141312512",
  "in_reply_to_user_id" : 30868098,
  "text" : "@dvzrv that would be so cool, best of luck with it!",
  "id" : 424493155141312512,
  "in_reply_to_status_id" : 424493100384260096,
  "created_at" : "2014-01-18 10:47:09 +0000",
  "in_reply_to_screen_name" : "dvzrv",
  "in_reply_to_user_id_str" : "30868098",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dvzrv",
      "screen_name" : "dvzrv",
      "indices" : [ 0, 6 ],
      "id_str" : "30868098",
      "id" : 30868098
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "424492684250583040",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00966487, 8.2829890883 ]
  },
  "id_str" : "424492878661160960",
  "in_reply_to_user_id" : 30868098,
  "text" : "@dvzrv great, still the frqrec-address? :)",
  "id" : 424492878661160960,
  "in_reply_to_status_id" : 424492684250583040,
  "created_at" : "2014-01-18 10:46:03 +0000",
  "in_reply_to_screen_name" : "dvzrv",
  "in_reply_to_user_id_str" : "30868098",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dvzrv",
      "screen_name" : "dvzrv",
      "indices" : [ 0, 6 ],
      "id_str" : "30868098",
      "id" : 30868098
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "424492437575184385",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00966487, 8.2829890883 ]
  },
  "id_str" : "424492611421093888",
  "in_reply_to_user_id" : 30868098,
  "text" : "@dvzrv thx, can I share your email if she is interested in knowing more about the project?",
  "id" : 424492611421093888,
  "in_reply_to_status_id" : 424492437575184385,
  "created_at" : "2014-01-18 10:44:59 +0000",
  "in_reply_to_screen_name" : "dvzrv",
  "in_reply_to_user_id_str" : "30868098",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dvzrv",
      "screen_name" : "dvzrv",
      "indices" : [ 0, 6 ],
      "id_str" : "30868098",
      "id" : 30868098
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00966487, 8.2829890883 ]
  },
  "id_str" : "424490872043241472",
  "in_reply_to_user_id" : 30868098,
  "text" : "@dvzrv do you have a website for your genome sonification stuff I could link to? Just doing an interview on how openSNP data is used. :)",
  "id" : 424490872043241472,
  "created_at" : "2014-01-18 10:38:05 +0000",
  "in_reply_to_screen_name" : "dvzrv",
  "in_reply_to_user_id_str" : "30868098",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Auntie Silke",
      "screen_name" : "TanteSilke",
      "indices" : [ 0, 11 ],
      "id_str" : "56062177",
      "id" : 56062177
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "424481568439029760",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096920339, 8.2831212171 ]
  },
  "id_str" : "424481698165051392",
  "in_reply_to_user_id" : 56062177,
  "text" : "@TanteSilke ja, und jetzt auch wach ;)",
  "id" : 424481698165051392,
  "in_reply_to_status_id" : 424481568439029760,
  "created_at" : "2014-01-18 10:01:37 +0000",
  "in_reply_to_screen_name" : "TanteSilke",
  "in_reply_to_user_id_str" : "56062177",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "424481285646852096",
  "geo" : { },
  "id_str" : "424481534058692608",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich in unserer Hood weiss man nie ob es nicht die Polizei ist und die finden das immer nicht so toll\u2026",
  "id" : 424481534058692608,
  "in_reply_to_status_id" : 424481285646852096,
  "created_at" : "2014-01-18 10:00:58 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "424481058059718656",
  "text" : "Es klingelt an der T\u00FCr. Lossprinten w\u00E4hrend man sich noch eine Hose anzieht. Dabei auf Katzenkotze ausrutschen\u2026",
  "id" : 424481058059718656,
  "created_at" : "2014-01-18 09:59:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Yoder \uD83D\uDD96\uD83C\uDFFB",
      "screen_name" : "JBYoder",
      "indices" : [ 0, 8 ],
      "id_str" : "19984919",
      "id" : 19984919
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "424342861086064640",
  "geo" : { },
  "id_str" : "424343229363138560",
  "in_reply_to_user_id" : 19984919,
  "text" : "@JBYoder congrats!",
  "id" : 424343229363138560,
  "in_reply_to_status_id" : 424342861086064640,
  "created_at" : "2014-01-18 00:51:24 +0000",
  "in_reply_to_screen_name" : "JBYoder",
  "in_reply_to_user_id_str" : "19984919",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Yoder \uD83D\uDD96\uD83C\uDFFB",
      "screen_name" : "JBYoder",
      "indices" : [ 3, 11 ],
      "id_str" : "19984919",
      "id" : 19984919
    }, {
      "name" : "Genetics Soc of Amer",
      "screen_name" : "GeneticsGSA",
      "indices" : [ 117, 129 ],
      "id_str" : "47983577",
      "id" : 47983577
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "424343181220937728",
  "text" : "RT @JBYoder: Yoder et al. (2014) \"Genomic signature of adaptation to climate in Medicago truncatula\u201D online early at @GeneticsGSA http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Genetics Soc of Amer",
        "screen_name" : "GeneticsGSA",
        "indices" : [ 104, 116 ],
        "id_str" : "47983577",
        "id" : 47983577
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/Yh48LHSzMA",
        "expanded_url" : "http:\/\/www.genetics.org\/content\/early\/2014\/01\/15\/genetics.113.159319.abstract",
        "display_url" : "genetics.org\/content\/early\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "424342861086064640",
    "text" : "Yoder et al. (2014) \"Genomic signature of adaptation to climate in Medicago truncatula\u201D online early at @GeneticsGSA http:\/\/t.co\/Yh48LHSzMA",
    "id" : 424342861086064640,
    "created_at" : "2014-01-18 00:49:56 +0000",
    "user" : {
      "name" : "Jeremy Yoder \uD83D\uDD96\uD83C\uDFFB",
      "screen_name" : "JBYoder",
      "protected" : false,
      "id_str" : "19984919",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/870850169759072256\/r0kxCgGs_normal.jpg",
      "id" : 19984919,
      "verified" : true
    }
  },
  "id" : 424343181220937728,
  "created_at" : "2014-01-18 00:51:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathan Eisen, Guardian of Microbial Diversity \uD83D\uDCA5\uD83D\uDD06",
      "screen_name" : "phylogenomics",
      "indices" : [ 0, 14 ],
      "id_str" : "15154811",
      "id" : 15154811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/AMCzWrQgaO",
      "expanded_url" : "https:\/\/s3.amazonaws.com\/refersion_client\/917\/creatives\/11-12-13-02-13-35_deepak_336dw.jpg",
      "display_url" : "s3.amazonaws.com\/refersion_clie\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "424325264496021504",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00966487, 8.2829890883 ]
  },
  "id_str" : "424327506871988225",
  "in_reply_to_user_id" : 15154811,
  "text" : "@phylogenomics and what ad did wordpress put below the comments? this one: https:\/\/t.co\/AMCzWrQgaO",
  "id" : 424327506871988225,
  "in_reply_to_status_id" : 424325264496021504,
  "created_at" : "2014-01-17 23:48:55 +0000",
  "in_reply_to_screen_name" : "phylogenomics",
  "in_reply_to_user_id_str" : "15154811",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/NPtnJFslQv",
      "expanded_url" : "http:\/\/blogs.plos.org\/paleo\/2014\/01\/17\/sharing-phylogenetic-data-public-comment-invited\/",
      "display_url" : "blogs.plos.org\/paleo\/2014\/01\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00966487, 8.2829890883 ]
  },
  "id_str" : "424310044310929408",
  "text" : "Working with phylogenetic data? You can help to write a draft on best practice guidelines for sharing data. http:\/\/t.co\/NPtnJFslQv",
  "id" : 424310044310929408,
  "created_at" : "2014-01-17 22:39:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Poly Horror",
      "screen_name" : "polyhorror",
      "indices" : [ 3, 14 ],
      "id_str" : "2276885364",
      "id" : 2276885364
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "424309447843119105",
  "text" : "RT @polyhorror: I am looking for a secondary who can come over whenever my husband is out of town on business.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "424281700814704640",
    "text" : "I am looking for a secondary who can come over whenever my husband is out of town on business.",
    "id" : 424281700814704640,
    "created_at" : "2014-01-17 20:46:54 +0000",
    "user" : {
      "name" : "Poly Horror",
      "screen_name" : "polyhorror",
      "protected" : false,
      "id_str" : "2276885364",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/419640689865920513\/baOsfC1__normal.jpeg",
      "id" : 2276885364,
      "verified" : false
    }
  },
  "id" : 424309447843119105,
  "created_at" : "2014-01-17 22:37:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shit Academics Say",
      "screen_name" : "AcademicsSay",
      "indices" : [ 3, 16 ],
      "id_str" : "1891806212",
      "id" : 1891806212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "424306117842575360",
  "text" : "RT @AcademicsSay: I'm so tired, but I can't sleep. Might as well get some work done.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "424034390063452160",
    "text" : "I'm so tired, but I can't sleep. Might as well get some work done.",
    "id" : 424034390063452160,
    "created_at" : "2014-01-17 04:24:11 +0000",
    "user" : {
      "name" : "Shit Academics Say",
      "screen_name" : "AcademicsSay",
      "protected" : false,
      "id_str" : "1891806212",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/748151916836716546\/Ldn_dhiC_normal.jpg",
      "id" : 1891806212,
      "verified" : false
    }
  },
  "id" : 424306117842575360,
  "created_at" : "2014-01-17 22:23:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John S. Wilkins",
      "screen_name" : "john_s_wilkins",
      "indices" : [ 0, 15 ],
      "id_str" : "76013938",
      "id" : 76013938
    }, {
      "name" : "Bob O'Hara",
      "screen_name" : "BobOHara",
      "indices" : [ 16, 25 ],
      "id_str" : "19146944",
      "id" : 19146944
    }, {
      "name" : "((MarkCC))",
      "screen_name" : "MarkCC",
      "indices" : [ 26, 33 ],
      "id_str" : "17811689",
      "id" : 17811689
    }, {
      "name" : "Mr. M-of-Eris",
      "screen_name" : "MasksofEris",
      "indices" : [ 34, 46 ],
      "id_str" : "237405989",
      "id" : 237405989
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/1sK6LUUCm6",
      "expanded_url" : "https:\/\/twitter.com\/JoergR\/statuses\/286558785961607168",
      "display_url" : "twitter.com\/JoergR\/statuse\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "424301788083134465",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00966487, 8.2829890883 ]
  },
  "id_str" : "424303376781017088",
  "in_reply_to_user_id" : 76013938,
  "text" : "@john_s_wilkins @BobOHara @MarkCC @MasksofEris could also have tried this, though they are a bit hidden sometimes. https:\/\/t.co\/1sK6LUUCm6",
  "id" : 424303376781017088,
  "in_reply_to_status_id" : 424301788083134465,
  "created_at" : "2014-01-17 22:13:02 +0000",
  "in_reply_to_screen_name" : "john_s_wilkins",
  "in_reply_to_user_id_str" : "76013938",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00966487, 8.2829890883 ]
  },
  "id_str" : "424300647786508288",
  "text" : "multiplayer video games: travel the net, meet interesting people, virtually kill them and learn all the swearing!",
  "id" : 424300647786508288,
  "created_at" : "2014-01-17 22:02:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 3, 12 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "424294590167130113",
  "text" : "RT @SuicideC: Dressing conventions for hen nights, anyone? Is it ok for a non-bridal partygoer to dress (potentially) sexier than the bride\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "424294558730432512",
    "text" : "Dressing conventions for hen nights, anyone? Is it ok for a non-bridal partygoer to dress (potentially) sexier than the bride-to-be?",
    "id" : 424294558730432512,
    "created_at" : "2014-01-17 21:38:00 +0000",
    "user" : {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "protected" : false,
      "id_str" : "78977466",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/720571127198822400\/Ozg-hXsT_normal.jpg",
      "id" : 78977466,
      "verified" : false
    }
  },
  "id" : 424294590167130113,
  "created_at" : "2014-01-17 21:38:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/Qmc764NK1E",
      "expanded_url" : "http:\/\/simplystatistics.org\/2014\/01\/17\/missing-not-at-random-data-makes-some-facebook-users-feel-sad\/",
      "display_url" : "simplystatistics.org\/2014\/01\/17\/mis\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00966487, 8.2829890883 ]
  },
  "id_str" : "424260065491963904",
  "text" : "Missing not at random data makes some Facebook users feel sad http:\/\/t.co\/Qmc764NK1E",
  "id" : 424260065491963904,
  "created_at" : "2014-01-17 19:20:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/TWjERMA0Pe",
      "expanded_url" : "http:\/\/i.imgur.com\/6ETb4.gif",
      "display_url" : "i.imgur.com\/6ETb4.gif"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0063045277, 8.3245966863 ]
  },
  "id_str" : "424244007859159040",
  "text" : "willpower, the most underrated finite resource http:\/\/t.co\/TWjERMA0Pe",
  "id" : 424244007859159040,
  "created_at" : "2014-01-17 18:17:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/tTiMW0bkkP",
      "expanded_url" : "http:\/\/pubs.acs.org\/doi\/abs\/10.1021\/jf404402v",
      "display_url" : "pubs.acs.org\/doi\/abs\/10.102\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "424197771705344000",
  "text" : "SNP fingerprinting to identify variety of a single Cacao beans http:\/\/t.co\/tTiMW0bkkP",
  "id" : 424197771705344000,
  "created_at" : "2014-01-17 15:13:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 10, 19 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "424169538003824641",
  "geo" : { },
  "id_str" : "424170243351519232",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC @Senficon just head over to some crowdfunding site, sounds solid enough that people will give money for it ;)",
  "id" : 424170243351519232,
  "in_reply_to_status_id" : 424169538003824641,
  "created_at" : "2014-01-17 13:24:01 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 14, 23 ],
      "id_str" : "14861745",
      "id" : 14861745
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 24, 36 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "424130678620299264",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1774703136, 8.624170865 ]
  },
  "id_str" : "424131717591728128",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @Senficon @helgerausch you have such a non-standard way to spell \u2018devastating\u2019 ;)",
  "id" : 424131717591728128,
  "in_reply_to_status_id" : 424130678620299264,
  "created_at" : "2014-01-17 10:50:56 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 10, 23 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 24, 36 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/ROP4vddvJH",
      "expanded_url" : "http:\/\/www.edge.org\/response-detail\/25445",
      "display_url" : "edge.org\/response-detai\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "424128998298636288",
  "geo" : { },
  "id_str" : "424129684448636928",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon @PhilippBayer @helgerausch well, I might just leave this here\u2026 http:\/\/t.co\/ROP4vddvJH",
  "id" : 424129684448636928,
  "in_reply_to_status_id" : 424128998298636288,
  "created_at" : "2014-01-17 10:42:51 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 14, 26 ],
      "id_str" : "52747896",
      "id" : 52747896
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 27, 36 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "424126957123416065",
  "geo" : { },
  "id_str" : "424127656129732608",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @helgerausch @Senficon can\u2019t believe it\u2019s over! \u201CAll reviewers\u2019 comments &amp; concerns have been satisfactorily addressed\u201D :D",
  "id" : 424127656129732608,
  "in_reply_to_status_id" : 424126957123416065,
  "created_at" : "2014-01-17 10:34:47 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PLOS",
      "screen_name" : "PLOS",
      "indices" : [ 93, 98 ],
      "id_str" : "12819112",
      "id" : 12819112
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 103, 112 ],
      "id_str" : "14861745",
      "id" : 14861745
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 113, 125 ],
      "id_str" : "52747896",
      "id" : 52747896
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 126, 139 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "424123065669136384",
  "text" : "Yay! \u00ABpleased to inform you that your manuscript has been deemed suitable for publication in @PLOS 1\u00BB \/@Senficon @helgerausch @PhilippBayer",
  "id" : 424123065669136384,
  "created_at" : "2014-01-17 10:16:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1724951622, 8.6277190782 ]
  },
  "id_str" : "424103476067840000",
  "text" : "Drau\u00DFen laufen Menschen mit Mundschutz rum. Memo to self: Rausfinden was die h\u00F6chste genutzte Lab-Schutzstufe am Campus ist.",
  "id" : 424103476067840000,
  "created_at" : "2014-01-17 08:58:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tobler Lab",
      "screen_name" : "michitobler",
      "indices" : [ 3, 15 ],
      "id_str" : "47138807",
      "id" : 47138807
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/michitobler\/status\/424026689983623169\/photo\/1",
      "indices" : [ 53, 75 ],
      "url" : "http:\/\/t.co\/xdhverYt9k",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BeJyBygCMAA43Kq.jpg",
      "id_str" : "424026689987817472",
      "id" : 424026689987817472,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BeJyBygCMAA43Kq.jpg",
      "sizes" : [ {
        "h" : 1538,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 901,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 1538,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 511,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/xdhverYt9k"
    } ],
    "hashtags" : [ {
      "text" : "OSUevol",
      "indices" : [ 44, 52 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "424079425542840320",
  "text" : "RT @michitobler: The domestication of dogs. #OSUevol http:\/\/t.co\/xdhverYt9k",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/michitobler\/status\/424026689983623169\/photo\/1",
        "indices" : [ 36, 58 ],
        "url" : "http:\/\/t.co\/xdhverYt9k",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BeJyBygCMAA43Kq.jpg",
        "id_str" : "424026689987817472",
        "id" : 424026689987817472,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BeJyBygCMAA43Kq.jpg",
        "sizes" : [ {
          "h" : 1538,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 901,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 1538,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 511,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/xdhverYt9k"
      } ],
      "hashtags" : [ {
        "text" : "OSUevol",
        "indices" : [ 27, 35 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "424026689983623169",
    "text" : "The domestication of dogs. #OSUevol http:\/\/t.co\/xdhverYt9k",
    "id" : 424026689983623169,
    "created_at" : "2014-01-17 03:53:35 +0000",
    "user" : {
      "name" : "Tobler Lab",
      "screen_name" : "michitobler",
      "protected" : false,
      "id_str" : "47138807",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/874444153295208448\/MxaAI_uk_normal.jpg",
      "id" : 47138807,
      "verified" : false
    }
  },
  "id" : 424079425542840320,
  "created_at" : "2014-01-17 07:23:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 47 ],
      "url" : "https:\/\/t.co\/XwVnlCOHMy",
      "expanded_url" : "https:\/\/elliepritts.exposure.so\/the-valley-of-the-elves",
      "display_url" : "elliepritts.exposure.so\/the-valley-of-\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009691, 8.28309 ]
  },
  "id_str" : "424078277826068480",
  "text" : "The Valley of The Elves https:\/\/t.co\/XwVnlCOHMy",
  "id" : 424078277826068480,
  "created_at" : "2014-01-17 07:18:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "T\u0AE6m\u1D0D\u04AF Leu\u0358\u0489n\u0315g\u0337",
      "screen_name" : "The_Episiarch",
      "indices" : [ 3, 17 ],
      "id_str" : "537028278",
      "id" : 537028278
    }, {
      "name" : "Kelly Hills",
      "screen_name" : "rocza",
      "indices" : [ 34, 40 ],
      "id_str" : "14075844",
      "id" : 14075844
    }, {
      "name" : "Hope Jahren",
      "screen_name" : "HopeJahren",
      "indices" : [ 43, 54 ],
      "id_str" : "322658299",
      "id" : 322658299
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "423989890649686017",
  "text" : "RT @The_Episiarch: Follow on from @rocza + @HopeJahren's posts, my far less eloquent thoughts about *that* letter in Nature http:\/\/t.co\/4wt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Kelly Hills",
        "screen_name" : "rocza",
        "indices" : [ 15, 21 ],
        "id_str" : "14075844",
        "id" : 14075844
      }, {
        "name" : "Hope Jahren",
        "screen_name" : "HopeJahren",
        "indices" : [ 24, 35 ],
        "id_str" : "322658299",
        "id" : 322658299
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/The_Episiarch\/status\/423962101715968000\/photo\/1",
        "indices" : [ 105, 127 ],
        "url" : "http:\/\/t.co\/4wtF7L4atr",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BeI3SQeCIAAMR_6.png",
        "id_str" : "423962101724356608",
        "id" : 423962101724356608,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BeI3SQeCIAAMR_6.png",
        "sizes" : [ {
          "h" : 983,
          "resize" : "fit",
          "w" : 635
        }, {
          "h" : 983,
          "resize" : "fit",
          "w" : 635
        }, {
          "h" : 983,
          "resize" : "fit",
          "w" : 635
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 439
        } ],
        "display_url" : "pic.twitter.com\/4wtF7L4atr"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "423962101715968000",
    "text" : "Follow on from @rocza + @HopeJahren's posts, my far less eloquent thoughts about *that* letter in Nature http:\/\/t.co\/4wtF7L4atr",
    "id" : 423962101715968000,
    "created_at" : "2014-01-16 23:36:56 +0000",
    "user" : {
      "name" : "T\u0AE6m\u1D0D\u04AF Leu\u0358\u0489n\u0315g\u0337",
      "screen_name" : "The_Episiarch",
      "protected" : false,
      "id_str" : "537028278",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/927348999094386690\/kYmQN0FS_normal.jpg",
      "id" : 537028278,
      "verified" : false
    }
  },
  "id" : 423989890649686017,
  "created_at" : "2014-01-17 01:27:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 10, 19 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "423979940011208704",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096766774, 8.2830077018 ]
  },
  "id_str" : "423981046917767168",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC @Senficon yet another technological fix for social problems. ;)",
  "id" : 423981046917767168,
  "in_reply_to_status_id" : 423979940011208704,
  "created_at" : "2014-01-17 00:52:13 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    }, {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 10, 19 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "423949821947678721",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00966487, 8.2829890883 ]
  },
  "id_str" : "423951689419603968",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon @SuicideC that is filed under \u2018business as usual\u2019",
  "id" : 423951689419603968,
  "in_reply_to_status_id" : 423949821947678721,
  "created_at" : "2014-01-16 22:55:34 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 90, 99 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "423949129673220096",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00966487, 8.2829890883 ]
  },
  "id_str" : "423949444191903744",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC though I really should have used copying instead of stealing. Because otherwise @Senficon will throw me out. ;)",
  "id" : 423949444191903744,
  "in_reply_to_status_id" : 423949129673220096,
  "created_at" : "2014-01-16 22:46:38 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brad Voytek",
      "screen_name" : "bradleyvoytek",
      "indices" : [ 3, 17 ],
      "id_str" : "162535413",
      "id" : 162535413
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/bradleyvoytek\/status\/423947308435116032\/photo\/1",
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/2XhYxcJBPA",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BeIp1LNCEAAUoTF.jpg",
      "id_str" : "423947308443504640",
      "id" : 423947308443504640,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BeIp1LNCEAAUoTF.jpg",
      "sizes" : [ {
        "h" : 1010,
        "resize" : "fit",
        "w" : 964
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 649
      }, {
        "h" : 1010,
        "resize" : "fit",
        "w" : 964
      }, {
        "h" : 1010,
        "resize" : "fit",
        "w" : 964
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/2XhYxcJBPA"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 63 ],
      "url" : "http:\/\/t.co\/Ilxi2d8smt",
      "expanded_url" : "http:\/\/bit.ly\/1j4aXZU",
      "display_url" : "bit.ly\/1j4aXZU"
    } ]
  },
  "geo" : { },
  "id_str" : "423947607443255296",
  "text" : "RT @bradleyvoytek: See also: Scientisht (http:\/\/t.co\/Ilxi2d8smt) http:\/\/t.co\/2XhYxcJBPA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/bradleyvoytek\/status\/423947308435116032\/photo\/1",
        "indices" : [ 46, 68 ],
        "url" : "http:\/\/t.co\/2XhYxcJBPA",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BeIp1LNCEAAUoTF.jpg",
        "id_str" : "423947308443504640",
        "id" : 423947308443504640,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BeIp1LNCEAAUoTF.jpg",
        "sizes" : [ {
          "h" : 1010,
          "resize" : "fit",
          "w" : 964
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 649
        }, {
          "h" : 1010,
          "resize" : "fit",
          "w" : 964
        }, {
          "h" : 1010,
          "resize" : "fit",
          "w" : 964
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/2XhYxcJBPA"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 22, 44 ],
        "url" : "http:\/\/t.co\/Ilxi2d8smt",
        "expanded_url" : "http:\/\/bit.ly\/1j4aXZU",
        "display_url" : "bit.ly\/1j4aXZU"
      } ]
    },
    "geo" : { },
    "id_str" : "423947308435116032",
    "text" : "See also: Scientisht (http:\/\/t.co\/Ilxi2d8smt) http:\/\/t.co\/2XhYxcJBPA",
    "id" : 423947308435116032,
    "created_at" : "2014-01-16 22:38:09 +0000",
    "user" : {
      "name" : "Brad Voytek",
      "screen_name" : "bradleyvoytek",
      "protected" : false,
      "id_str" : "162535413",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/688408740651909124\/mz2GSnS0_normal.jpg",
      "id" : 162535413,
      "verified" : true
    }
  },
  "id" : 423947607443255296,
  "created_at" : "2014-01-16 22:39:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonas",
      "screen_name" : "lsanoj",
      "indices" : [ 0, 7 ],
      "id_str" : "18918915",
      "id" : 18918915
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "423945708275007490",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096399512, 8.2830067015 ]
  },
  "id_str" : "423946098924077056",
  "in_reply_to_user_id" : 18918915,
  "text" : "@lsanoj survival of the finest?",
  "id" : 423946098924077056,
  "in_reply_to_status_id" : 423945708275007490,
  "created_at" : "2014-01-16 22:33:21 +0000",
  "in_reply_to_screen_name" : "lsanoj",
  "in_reply_to_user_id_str" : "18918915",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    }, {
      "name" : "Maarten den Braber",
      "screen_name" : "mdbraber",
      "indices" : [ 10, 19 ],
      "id_str" : "9938952",
      "id" : 9938952
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "423942441138270209",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00966487, 8.2829890883 ]
  },
  "id_str" : "423943050919174146",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez @mdbraber ah, thanks for the pointer :)",
  "id" : 423943050919174146,
  "in_reply_to_status_id" : 423942441138270209,
  "created_at" : "2014-01-16 22:21:14 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "423942136128487424",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00966487, 8.2829890883 ]
  },
  "id_str" : "423942336385916928",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez too bad, can\u2019t wait to finally count altitude again. Any chance you could ship one over? :p",
  "id" : 423942336385916928,
  "in_reply_to_status_id" : 423942136128487424,
  "created_at" : "2014-01-16 22:18:24 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "423941996810473473",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00966487, 8.2829890883 ]
  },
  "id_str" : "423942035717246977",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez great, thanks!",
  "id" : 423942035717246977,
  "in_reply_to_status_id" : 423941996810473473,
  "created_at" : "2014-01-16 22:17:12 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "423941517917437952",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00966487, 8.2829890883 ]
  },
  "id_str" : "423941945501958144",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez oh, and do you have any idea when the Force will come to Europe? ;)",
  "id" : 423941945501958144,
  "in_reply_to_status_id" : 423941517917437952,
  "created_at" : "2014-01-16 22:16:50 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "423941517917437952",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00966487, 8.2829890883 ]
  },
  "id_str" : "423941740526313473",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez thanks, I will just forget who posted that link ;)",
  "id" : 423941740526313473,
  "in_reply_to_status_id" : 423941517917437952,
  "created_at" : "2014-01-16 22:16:02 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "423940685083840512",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00966487, 8.2829890883 ]
  },
  "id_str" : "423941159627792385",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez btw.: is there another way to access intraday data than asking nicely for extended API access?",
  "id" : 423941159627792385,
  "in_reply_to_status_id" : 423940685083840512,
  "created_at" : "2014-01-16 22:13:43 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "423940685083840512",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00966487, 8.2829890883 ]
  },
  "id_str" : "423941026957778946",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez wouldn\u2019t even imply bad faith on their behalf, maybe just a horrible lack of search-skills\u2026",
  "id" : 423941026957778946,
  "in_reply_to_status_id" : 423940685083840512,
  "created_at" : "2014-01-16 22:13:11 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "423939119274659840",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00966487, 8.2829890883 ]
  },
  "id_str" : "423940518696189952",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez that\u2019s nice. Was just making fun of selling heatmaps (which have been around at least since 1950s) as a new thing w\/ new name.",
  "id" : 423940518696189952,
  "in_reply_to_status_id" : 423939119274659840,
  "created_at" : "2014-01-16 22:11:10 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "figshare",
      "screen_name" : "figshare",
      "indices" : [ 74, 83 ],
      "id_str" : "224631899",
      "id" : 224631899
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00966487, 8.2829890883 ]
  },
  "id_str" : "423939373873504256",
  "text" : "About those quilt plots: They uploaded their R code to create heatmaps to @figshare. In a *.doc file\u2026 This must be another OA sting, right?",
  "id" : 423939373873504256,
  "created_at" : "2014-01-16 22:06:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ed Yong",
      "screen_name" : "edyong209",
      "indices" : [ 113, 123 ],
      "id_str" : "19767193",
      "id" : 19767193
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/VxN3VPYpkd",
      "expanded_url" : "http:\/\/www.plosone.org\/article\/info:doi\/10.1371\/journal.pone.0085047?utm_source=feedburner",
      "display_url" : "plosone.org\/article\/info:d\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00966487, 8.2829890883 ]
  },
  "id_str" : "423938226462916609",
  "text" : "\u2018Quilt Plots\u2019. And that kids, is why you need to learn how to google your R problems\u2026 http:\/\/t.co\/VxN3VPYpkd \/HT @edyong209",
  "id" : 423938226462916609,
  "created_at" : "2014-01-16 22:02:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 51 ],
      "url" : "http:\/\/t.co\/wWrnWX2Tsc",
      "expanded_url" : "http:\/\/boingboing.net\/2014\/01\/16\/super-slow-motion-beatboxing.html",
      "display_url" : "boingboing.net\/2014\/01\/16\/sup\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00966487, 8.2829890883 ]
  },
  "id_str" : "423934353908178944",
  "text" : "Super-slow motion\u00A0beatboxing http:\/\/t.co\/wWrnWX2Tsc",
  "id" : 423934353908178944,
  "created_at" : "2014-01-16 21:46:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 59 ],
      "url" : "http:\/\/t.co\/3vuOf2Ht3g",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=55GnWh4TqY4",
      "display_url" : "youtube.com\/watch?v=55GnWh\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00966487, 8.2829890883 ]
  },
  "id_str" : "423931353932238850",
  "text" : "the floor is lava. Cambridge edition http:\/\/t.co\/3vuOf2Ht3g",
  "id" : 423931353932238850,
  "created_at" : "2014-01-16 21:34:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "423877436510830592",
  "text" : "\u00ABWirst du mich an der Leine in ein Caf\u00E9 f\u00FChren?\u00BB\u2014\u00ABNat\u00FCrlich nicht, die haben meist \u2018Wir m\u00FCssen leider draussen bleiben\u2019-Schilder im Fenster\u00BB",
  "id" : 423877436510830592,
  "created_at" : "2014-01-16 18:00:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "423876406595293184",
  "text" : "Kurz gefreut das der Karnevalsverein seine Veranstaltungen ehrlich mit \u2018Fremdsch\u00E4men!\u2019 bewirbt. Leider nur bei \u2018Fremdensitzung\u2019 verlesen.",
  "id" : 423876406595293184,
  "created_at" : "2014-01-16 17:56:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "423853023673057280",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1270131076, 8.6773356329 ]
  },
  "id_str" : "423860999280922624",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC interdisciplinary: stealing all the actually useful stuff other people have learned during their studies. ;)",
  "id" : 423860999280922624,
  "in_reply_to_status_id" : 423853023673057280,
  "created_at" : "2014-01-16 16:55:11 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "423821289011171329",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172288021, 8.6276404944 ]
  },
  "id_str" : "423821615722668032",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC and that\u2019s the real reason why you avoid peers and look outside your field? :p",
  "id" : 423821615722668032,
  "in_reply_to_status_id" : 423821289011171329,
  "created_at" : "2014-01-16 14:18:42 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 56, 69 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/848PE5UhPO",
      "expanded_url" : "http:\/\/rsbl.royalsocietypublishing.org\/content\/10\/1\/20130935.full",
      "display_url" : "rsbl.royalsocietypublishing.org\/content\/10\/1\/2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "423815543024390144",
  "text" : "Natural selection can favour \u2018irrational\u2019 behaviour \/cc @PhilippBayer http:\/\/t.co\/848PE5UhPO",
  "id" : 423815543024390144,
  "created_at" : "2014-01-16 13:54:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shit Academics Say",
      "screen_name" : "AcademicsSay",
      "indices" : [ 3, 16 ],
      "id_str" : "1891806212",
      "id" : 1891806212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "423813498133807104",
  "text" : "RT @AcademicsSay: I don't mean to criticize. Have you perhaps considered. Perhaps I missed something. With all due respect.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "423810021210611712",
    "text" : "I don't mean to criticize. Have you perhaps considered. Perhaps I missed something. With all due respect.",
    "id" : 423810021210611712,
    "created_at" : "2014-01-16 13:32:37 +0000",
    "user" : {
      "name" : "Shit Academics Say",
      "screen_name" : "AcademicsSay",
      "protected" : false,
      "id_str" : "1891806212",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/748151916836716546\/Ldn_dhiC_normal.jpg",
      "id" : 1891806212,
      "verified" : false
    }
  },
  "id" : 423813498133807104,
  "created_at" : "2014-01-16 13:46:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "423811341313249281",
  "geo" : { },
  "id_str" : "423811957880139776",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC \"if you don't tear my earlaps, that is. but no pressure!\" ;)",
  "id" : 423811957880139776,
  "in_reply_to_status_id" : 423811341313249281,
  "created_at" : "2014-01-16 13:40:19 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "423803417899700224",
  "geo" : { },
  "id_str" : "423808490373533696",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC I predict horrible failure and ensuing laughs ;)",
  "id" : 423808490373533696,
  "in_reply_to_status_id" : 423803417899700224,
  "created_at" : "2014-01-16 13:26:32 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "423799425547255808",
  "geo" : { },
  "id_str" : "423801182100783105",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer awesome, thanks! :)",
  "id" : 423801182100783105,
  "in_reply_to_status_id" : 423799425547255808,
  "created_at" : "2014-01-16 12:57:30 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/k1SW1DgYMT",
      "expanded_url" : "http:\/\/www.peerreviewedbymyneurons.com\/2014\/01\/16\/theres-placebo-effect-sleep\/",
      "display_url" : "peerreviewedbymyneurons.com\/2014\/01\/16\/the\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "423791258813739008",
  "text" : "I should randomly spice up my sleep data to feel more awake: There\u2019s a Placebo Effect For Sleep http:\/\/t.co\/k1SW1DgYMT",
  "id" : 423791258813739008,
  "created_at" : "2014-01-16 12:18:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 45 ],
      "url" : "http:\/\/t.co\/JiWncUppBQ",
      "expanded_url" : "http:\/\/instagram.com\/p\/jOpdIohwlP\/",
      "display_url" : "instagram.com\/p\/jOpdIohwlP\/"
    } ]
  },
  "geo" : { },
  "id_str" : "423786065712123904",
  "text" : "Behavioral Experiments http:\/\/t.co\/JiWncUppBQ",
  "id" : 423786065712123904,
  "created_at" : "2014-01-16 11:57:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "423780315513880576",
  "text" : "\u00ABDu bist im Teamspeak ja auch viel lustiger wenn du nicht reden kannst.\u00BB",
  "id" : 423780315513880576,
  "created_at" : "2014-01-16 11:34:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "423775090245787648",
  "text" : "\u00ABDu siehst doch aus wie der strahlende Fr\u00FChling. Ich m\u00F6chte dir 'Holla die Waldfee!' als Spitznamen geben!\u00BB",
  "id" : 423775090245787648,
  "created_at" : "2014-01-16 11:13:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "423613404004483072",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722893873, 8.6276461147 ]
  },
  "id_str" : "423748585541632000",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC so now I need to prove my alleged pickset pickpocketing skills?",
  "id" : 423748585541632000,
  "in_reply_to_status_id" : 423613404004483072,
  "created_at" : "2014-01-16 09:28:30 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722554902, 8.6276754307 ]
  },
  "id_str" : "423747376172765184",
  "text" : "\u00ABHast du gerade der Kaffeemaschine gut zugeredet?!\u00BB \u2014 \u00ABPsst! Nicht so laut, sie kann sich und den Kaffee sonst nicht konzentrieren.\u00BB",
  "id" : 423747376172765184,
  "created_at" : "2014-01-16 09:23:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 3, 13 ],
      "id_str" : "14700783",
      "id" : 14700783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/GCP87Rr0Ja",
      "expanded_url" : "http:\/\/www.faz.net\/aktuell\/wissen\/medizin\/kampagne-gegen-greenpeace-machtkampf-um-den-goldenen-reis-12750595.html",
      "display_url" : "faz.net\/aktuell\/wissen\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "423736596358512640",
  "text" : "RT @Fischblog: Die Reichen dieser Welt opfern ihrem Aberglauben sechs Millionen Arme. http:\/\/t.co\/GCP87Rr0Ja",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.metrotwit.com\/\" rel=\"nofollow\"\u003EMetroTwit\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 71, 93 ],
        "url" : "http:\/\/t.co\/GCP87Rr0Ja",
        "expanded_url" : "http:\/\/www.faz.net\/aktuell\/wissen\/medizin\/kampagne-gegen-greenpeace-machtkampf-um-den-goldenen-reis-12750595.html",
        "display_url" : "faz.net\/aktuell\/wissen\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "423527206586159104",
    "text" : "Die Reichen dieser Welt opfern ihrem Aberglauben sechs Millionen Arme. http:\/\/t.co\/GCP87Rr0Ja",
    "id" : 423527206586159104,
    "created_at" : "2014-01-15 18:48:49 +0000",
    "user" : {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "protected" : false,
      "id_str" : "14700783",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/929627167125921792\/t5PPk1W-_normal.jpg",
      "id" : 14700783,
      "verified" : false
    }
  },
  "id" : 423736596358512640,
  "created_at" : "2014-01-16 08:40:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "423733909063761920",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1017856507, 8.6551962285 ]
  },
  "id_str" : "423734712935653376",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon dachte ich mir ;)",
  "id" : 423734712935653376,
  "in_reply_to_status_id" : 423733909063761920,
  "created_at" : "2014-01-16 08:33:22 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 67 ],
      "url" : "http:\/\/t.co\/XanZPaFvgZ",
      "expanded_url" : "http:\/\/instagram.com\/p\/jOPZhUBwlW\/",
      "display_url" : "instagram.com\/p\/jOPZhUBwlW\/"
    } ]
  },
  "geo" : { },
  "id_str" : "423728766746365952",
  "text" : "Nur mittelgro\u00DFe Hunde (gilt nicht f\u00FCr Pudel) http:\/\/t.co\/XanZPaFvgZ",
  "id" : 423728766746365952,
  "created_at" : "2014-01-16 08:09:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097001624, 8.282881882 ]
  },
  "id_str" : "423633403406462976",
  "text" : "Und zum Einschlafen massiert mir die Katze den Nacken. Bis aufs Blut.",
  "id" : 423633403406462976,
  "created_at" : "2014-01-16 01:50:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/dRZa59oZZh",
      "expanded_url" : "http:\/\/imgur.com\/pqwKNdI",
      "display_url" : "imgur.com\/pqwKNdI"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009565054, 8.282962576 ]
  },
  "id_str" : "423625579871895554",
  "text" : "Know Your Poop (plus: this pretty much sums up how people who care about data visualization feel about 3D pie charts) http:\/\/t.co\/dRZa59oZZh",
  "id" : 423625579871895554,
  "created_at" : "2014-01-16 01:19:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "423622160427409408",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009678178, 8.28300312 ]
  },
  "id_str" : "423622381215944704",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer I rather like to think that the fungi will be cultivated in the lab (as if\u2026)",
  "id" : 423622381215944704,
  "in_reply_to_status_id" : 423622160427409408,
  "created_at" : "2014-01-16 01:07:00 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 124, 137 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/KVsnGVWfT0",
      "expanded_url" : "http:\/\/www.plosone.org\/article\/info%3Adoi%2F10.1371%2Fjournal.pone.0084549",
      "display_url" : "plosone.org\/article\/info%3\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009678178, 8.28300312 ]
  },
  "id_str" : "423621787885535232",
  "text" : "Sloth Hair as a Novel Source of Fungi with Potent Anti-Parasitic &amp; Anti-Bacterial Bioactivity http:\/\/t.co\/KVsnGVWfT0 \/\/ @PhilippBayer",
  "id" : 423621787885535232,
  "created_at" : "2014-01-16 01:04:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/Lf0oPkrAIl",
      "expanded_url" : "http:\/\/i.imgur.com\/WyD2PBH.gif",
      "display_url" : "i.imgur.com\/WyD2PBH.gif"
    } ]
  },
  "in_reply_to_status_id_str" : "423616774668419072",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009678178, 8.28300312 ]
  },
  "id_str" : "423618461072650240",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot had to use all my willpower to not post that! instead it felt like: http:\/\/t.co\/Lf0oPkrAIl",
  "id" : 423618461072650240,
  "in_reply_to_status_id" : 423616774668419072,
  "created_at" : "2014-01-16 00:51:26 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Martin F. Robbins",
      "screen_name" : "mjrobbins",
      "indices" : [ 3, 13 ],
      "id_str" : "14315063",
      "id" : 14315063
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "423613257522626560",
  "text" : "RT @mjrobbins: In fact, someone should do a Tumblr or something of famous art and literature in history and how SEO people would have utter\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "423612621518929920",
    "text" : "In fact, someone should do a Tumblr or something of famous art and literature in history and how SEO people would have utterly ruined it.",
    "id" : 423612621518929920,
    "created_at" : "2014-01-16 00:28:13 +0000",
    "user" : {
      "name" : "Martin F. Robbins",
      "screen_name" : "mjrobbins",
      "protected" : false,
      "id_str" : "14315063",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/889888866257297408\/smSw_n3y_normal.jpg",
      "id" : 14315063,
      "verified" : true
    }
  },
  "id" : 423613257522626560,
  "created_at" : "2014-01-16 00:30:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "423606340003430400",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009678178, 8.28300312 ]
  },
  "id_str" : "423606753008566272",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer yeah, that\u2019s how they do sell it, but I see no reason not to throw other species into it?",
  "id" : 423606753008566272,
  "in_reply_to_status_id" : 423606340003430400,
  "created_at" : "2014-01-16 00:04:54 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 45 ],
      "url" : "http:\/\/t.co\/jNDMJ3yxqK",
      "expanded_url" : "http:\/\/imgur.com\/gallery\/h4PcYXQ",
      "display_url" : "imgur.com\/gallery\/h4PcYXQ"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009678178, 8.28300312 ]
  },
  "id_str" : "423591954644234241",
  "text" : "dog drinking in slowmo http:\/\/t.co\/jNDMJ3yxqK",
  "id" : 423591954644234241,
  "created_at" : "2014-01-15 23:06:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "423590616195293184",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009678178, 8.28300312 ]
  },
  "id_str" : "423590826955272193",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer yes, but still the pipeline is mostly for data for individuals (regardless of species) from what I\u2019ve read.",
  "id" : 423590826955272193,
  "in_reply_to_status_id" : 423590616195293184,
  "created_at" : "2014-01-15 23:01:37 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 55 ],
      "url" : "http:\/\/t.co\/78WrCDeMCz",
      "expanded_url" : "http:\/\/boingboing.net\/2014\/01\/15\/booth-babes-are-bad-for-busine.html",
      "display_url" : "boingboing.net\/2014\/01\/15\/boo\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009678178, 8.28300312 ]
  },
  "id_str" : "423588950952120320",
  "text" : "Booth babes are bad for\u00A0business http:\/\/t.co\/78WrCDeMCz",
  "id" : 423588950952120320,
  "created_at" : "2014-01-15 22:54:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 58 ],
      "url" : "http:\/\/t.co\/7jxDUmj0cq",
      "expanded_url" : "http:\/\/www.companionanimalpsychology.com\/2014\/01\/dangerous-dogs-time-for-rethink.html",
      "display_url" : "companionanimalpsychology.com\/2014\/01\/danger\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009678178, 8.28300312 ]
  },
  "id_str" : "423586039413092353",
  "text" : "Dangerous Dogs: Time for a Rethink? http:\/\/t.co\/7jxDUmj0cq",
  "id" : 423586039413092353,
  "created_at" : "2014-01-15 22:42:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "423584344628670464",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009678178, 8.28300312 ]
  },
  "id_str" : "423584936042700801",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer what other data would you want to use it for?",
  "id" : 423584936042700801,
  "in_reply_to_status_id" : 423584344628670464,
  "created_at" : "2014-01-15 22:38:13 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 68 ],
      "url" : "http:\/\/t.co\/TW52St04Py",
      "expanded_url" : "http:\/\/thefinchandpea.com\/2014\/01\/14\/yellowstone-national-park-birthplace-of-taq\/",
      "display_url" : "thefinchandpea.com\/2014\/01\/14\/yel\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009678178, 8.28300312 ]
  },
  "id_str" : "423582169085509634",
  "text" : "Yellowstone National Park \u2013 birthplace of\u00A0Taq http:\/\/t.co\/TW52St04Py",
  "id" : 423582169085509634,
  "created_at" : "2014-01-15 22:27:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "423568290363887616",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0982062047, 8.5472114219 ]
  },
  "id_str" : "423569756193824769",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot given their shared history that sounds too much like revenge fuck\u2026",
  "id" : 423569756193824769,
  "in_reply_to_status_id" : 423568290363887616,
  "created_at" : "2014-01-15 21:37:54 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 10, 16 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "423533636629966848",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0976703353, 8.546714934 ]
  },
  "id_str" : "423534117636943872",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC @Lobot yeah, I\u2019d also prefer if pre publication peer review would die in all other fields as well.",
  "id" : 423534117636943872,
  "in_reply_to_status_id" : 423533636629966848,
  "created_at" : "2014-01-15 19:16:17 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 10, 16 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "423512269171851264",
  "geo" : { },
  "id_str" : "423514237823369217",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC @Lobot peer review becomes so much easier once you can claim the reviewers living on another plane of existence gave their ok.",
  "id" : 423514237823369217,
  "in_reply_to_status_id" : 423512269171851264,
  "created_at" : "2014-01-15 17:57:17 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "423503395693948928",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1693691909, 8.6223636403 ]
  },
  "id_str" : "423506882788339712",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC thanks, I\u2019m pretty indiscriminate when it comes to learning new stuff.",
  "id" : 423506882788339712,
  "in_reply_to_status_id" : 423503395693948928,
  "created_at" : "2014-01-15 17:28:03 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "423490786361999360",
  "geo" : { },
  "id_str" : "423493995512086528",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot maybe he's just not into interspecies kink, especially not foxes after one bit of his tail? (btw: it's just \"dog\")",
  "id" : 423493995512086528,
  "in_reply_to_status_id" : 423490786361999360,
  "created_at" : "2014-01-15 16:36:51 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "423491649025503232",
  "geo" : { },
  "id_str" : "423493560688590848",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC enlighten me, was sollte ich denn lesen?",
  "id" : 423493560688590848,
  "in_reply_to_status_id" : 423491649025503232,
  "created_at" : "2014-01-15 16:35:07 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/ApUH1VKsoC",
      "expanded_url" : "http:\/\/i.imgur.com\/5DJEWWP.png",
      "display_url" : "i.imgur.com\/5DJEWWP.png"
    } ]
  },
  "geo" : { },
  "id_str" : "423490326053928960",
  "text" : "\u00ABmy dog bit me severely after I inserted the butt-plug\u00BB well, what did you expect, it's a fox tail after all! http:\/\/t.co\/ApUH1VKsoC",
  "id" : 423490326053928960,
  "created_at" : "2014-01-15 16:22:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "423486416509616128",
  "geo" : { },
  "id_str" : "423486938293616641",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC meine Schlafeckdaten sind schon in der Public Domain. Und n=2 klingt nach einer typischen Psych-Stichprobengr\u00F6\u00DFe ;)",
  "id" : 423486938293616641,
  "in_reply_to_status_id" : 423486416509616128,
  "created_at" : "2014-01-15 16:08:48 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "423477727925379072",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723026931, 8.6276413165 ]
  },
  "id_str" : "423478571672547328",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC accessory to sleep deprivation? Ich denke nicht, idr kann ich mich selbst ins Bett schicken.",
  "id" : 423478571672547328,
  "in_reply_to_status_id" : 423477727925379072,
  "created_at" : "2014-01-15 15:35:34 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    }, {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 13, 23 ],
      "id_str" : "14700783",
      "id" : 14700783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "423475927440691200",
  "geo" : { },
  "id_str" : "423476585220825088",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch @Fischblog Skimming mal anders: Aktenvernichter vorschalten.",
  "id" : 423476585220825088,
  "in_reply_to_status_id" : 423475927440691200,
  "created_at" : "2014-01-15 15:27:40 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 0, 10 ],
      "id_str" : "14700783",
      "id" : 14700783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "423472363007533056",
  "geo" : { },
  "id_str" : "423472891964170240",
  "in_reply_to_user_id" : 14700783,
  "text" : "@Fischblog ich glaube zukleben ist nicht mal n\u00F6tig, das Drama kommt von alleine.",
  "id" : 423472891964170240,
  "in_reply_to_status_id" : 423472363007533056,
  "created_at" : "2014-01-15 15:12:59 +0000",
  "in_reply_to_screen_name" : "Fischblog",
  "in_reply_to_user_id_str" : "14700783",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "423467081388929024",
  "geo" : { },
  "id_str" : "423472687260786688",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot dabei hatte ich immer auf leather man oder GI gehofft!",
  "id" : 423472687260786688,
  "in_reply_to_status_id" : 423467081388929024,
  "created_at" : "2014-01-15 15:12:11 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Prof Neil Martin",
      "screen_name" : "ThatNeilMartin",
      "indices" : [ 3, 18 ],
      "id_str" : "82242654",
      "id" : 82242654
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/7Naie1pPcl",
      "expanded_url" : "http:\/\/tinyurl.com\/pewx8w5",
      "display_url" : "tinyurl.com\/pewx8w5"
    } ]
  },
  "geo" : { },
  "id_str" : "423471914175430656",
  "text" : "RT @ThatNeilMartin: Through the looking glass. Author claims to have found evidence of PTSD in the, er, dead.  http:\/\/t.co\/7Naie1pPcl (via \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Keith R Laws",
        "screen_name" : "Keith_Laws",
        "indices" : [ 119, 130 ],
        "id_str" : "161296632",
        "id" : 161296632
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 91, 113 ],
        "url" : "http:\/\/t.co\/7Naie1pPcl",
        "expanded_url" : "http:\/\/tinyurl.com\/pewx8w5",
        "display_url" : "tinyurl.com\/pewx8w5"
      } ]
    },
    "geo" : { },
    "id_str" : "423434634660024320",
    "text" : "Through the looking glass. Author claims to have found evidence of PTSD in the, er, dead.  http:\/\/t.co\/7Naie1pPcl (via @Keith_Laws)",
    "id" : 423434634660024320,
    "created_at" : "2014-01-15 12:40:58 +0000",
    "user" : {
      "name" : "Prof Neil Martin",
      "screen_name" : "ThatNeilMartin",
      "protected" : false,
      "id_str" : "82242654",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/702174598528430080\/RSApTvcV_normal.jpg",
      "id" : 82242654,
      "verified" : false
    }
  },
  "id" : 423471914175430656,
  "created_at" : "2014-01-15 15:09:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 0, 10 ],
      "id_str" : "14700783",
      "id" : 14700783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "423470162579169281",
  "geo" : { },
  "id_str" : "423471636055339009",
  "in_reply_to_user_id" : 14700783,
  "text" : "@Fischblog heute Abend k\u00F6nnte man bestimmt wieder nette Szenen am Fristenbriefkasten beobachten. ;)",
  "id" : 423471636055339009,
  "in_reply_to_status_id" : 423470162579169281,
  "created_at" : "2014-01-15 15:08:00 +0000",
  "in_reply_to_screen_name" : "Fischblog",
  "in_reply_to_user_id_str" : "14700783",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "423469736543150080",
  "text" : "\u00ABWann l\u00E4uft hier eigentlich die Bewerbungsfrist f\u00FCr den Master aus?\u00BB \u2014 \u00ABAm 15.01. Das ist \u00FCbrigens heute.\u00BB",
  "id" : 423469736543150080,
  "created_at" : "2014-01-15 15:00:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723020805, 8.627574474 ]
  },
  "id_str" : "423453828969951233",
  "text" : "\u00ABDein Hund ist voll schmutzig, schau doch mal!\u00BB\u2014\u00ABDas kann gar nicht sein. Wo hast du sie denn gekrault?!\u00BB\u2014\u00ABNur am Hintern\u2026\u00BB\u2014\u00ABAm oder im?\u00BB",
  "id" : 423453828969951233,
  "created_at" : "2014-01-15 13:57:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723007888, 8.6276513564 ]
  },
  "id_str" : "423398499183771648",
  "text" : "\u00ABIch will ja nichts sagen, aber\u2026\u00BB \u2014 \u00ABDas trifft sich hervorragend, ich will dir auch gar nicht zuh\u00F6ren.\u00BB",
  "id" : 423398499183771648,
  "created_at" : "2014-01-15 10:17:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/CFSUqadbab",
      "expanded_url" : "http:\/\/www.theatlantic.com\/health\/archive\/2014\/01\/how-sex-affects-intelligence-and-vice-versa\/282889\/",
      "display_url" : "theatlantic.com\/health\/archive\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "423389251783254017",
  "text" : "The things you do to keep your brain in working condition\u2026 (take that Sudoku!) http:\/\/t.co\/CFSUqadbab",
  "id" : 423389251783254017,
  "created_at" : "2014-01-15 09:40:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722641988, 8.6275895778 ]
  },
  "id_str" : "423383496326139904",
  "text" : "M\u00FCdigkeitslevel: Vergesse andauernd wo meine Kaffeetasse steht. This will not end well.",
  "id" : 423383496326139904,
  "created_at" : "2014-01-15 09:17:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sally \"Punch Nazis\" Strange",
      "screen_name" : "SallyStrange",
      "indices" : [ 3, 16 ],
      "id_str" : "228950242",
      "id" : 228950242
    }, {
      "name" : "Lauren Laverne",
      "screen_name" : "laurenlaverne",
      "indices" : [ 37, 51 ],
      "id_str" : "89486038",
      "id" : 89486038
    }, {
      "name" : "Philippa_Perry",
      "screen_name" : "Philippa_Perry",
      "indices" : [ 97, 112 ],
      "id_str" : "18667799",
      "id" : 18667799
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Philippa_Perry\/status\/423176428365303808\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/DDCkZhkoVR",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bd9suCkIMAAcNo7.jpg",
      "id_str" : "423176428214300672",
      "id" : 423176428214300672,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bd9suCkIMAAcNo7.jpg",
      "sizes" : [ {
        "h" : 263,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 278,
        "resize" : "fit",
        "w" : 720
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 278,
        "resize" : "fit",
        "w" : 720
      }, {
        "h" : 278,
        "resize" : "fit",
        "w" : 720
      } ],
      "display_url" : "pic.twitter.com\/DDCkZhkoVR"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "423360966495989760",
  "text" : "RT @SallyStrange: Oh dear oh dear RT @laurenlaverne So close to the truth it actually hurts (via @Philippa_Perry) http:\/\/t.co\/DDCkZhkoVR",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Lauren Laverne",
        "screen_name" : "laurenlaverne",
        "indices" : [ 19, 33 ],
        "id_str" : "89486038",
        "id" : 89486038
      }, {
        "name" : "Philippa_Perry",
        "screen_name" : "Philippa_Perry",
        "indices" : [ 79, 94 ],
        "id_str" : "18667799",
        "id" : 18667799
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Philippa_Perry\/status\/423176428365303808\/photo\/1",
        "indices" : [ 96, 118 ],
        "url" : "http:\/\/t.co\/DDCkZhkoVR",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bd9suCkIMAAcNo7.jpg",
        "id_str" : "423176428214300672",
        "id" : 423176428214300672,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bd9suCkIMAAcNo7.jpg",
        "sizes" : [ {
          "h" : 263,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 278,
          "resize" : "fit",
          "w" : 720
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 278,
          "resize" : "fit",
          "w" : 720
        }, {
          "h" : 278,
          "resize" : "fit",
          "w" : 720
        } ],
        "display_url" : "pic.twitter.com\/DDCkZhkoVR"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "423178782284210176",
    "geo" : { },
    "id_str" : "423336820303081472",
    "in_reply_to_user_id" : 89486038,
    "text" : "Oh dear oh dear RT @laurenlaverne So close to the truth it actually hurts (via @Philippa_Perry) http:\/\/t.co\/DDCkZhkoVR",
    "id" : 423336820303081472,
    "in_reply_to_status_id" : 423178782284210176,
    "created_at" : "2014-01-15 06:12:17 +0000",
    "in_reply_to_screen_name" : "laurenlaverne",
    "in_reply_to_user_id_str" : "89486038",
    "user" : {
      "name" : "Sally \"Punch Nazis\" Strange",
      "screen_name" : "SallyStrange",
      "protected" : false,
      "id_str" : "228950242",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/759737281473351680\/LvzEVNVt_normal.jpg",
      "id" : 228950242,
      "verified" : false
    }
  },
  "id" : 423360966495989760,
  "created_at" : "2014-01-15 07:48:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian D. Ackley",
      "screen_name" : "DrWorms",
      "indices" : [ 3, 11 ],
      "id_str" : "532644877",
      "id" : 532644877
    }, {
      "name" : "Daniel MacArthur",
      "screen_name" : "dgmacarthur",
      "indices" : [ 13, 25 ],
      "id_str" : "16629477",
      "id" : 16629477
    }, {
      "name" : "National DNA Day",
      "screen_name" : "DNAday",
      "indices" : [ 26, 33 ],
      "id_str" : "21928178",
      "id" : 21928178
    }, {
      "name" : "NaturalHistoryMuseum",
      "screen_name" : "NHM_London",
      "indices" : [ 34, 45 ],
      "id_str" : "35749264",
      "id" : 35749264
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "423281491700117505",
  "text" : "RT @DrWorms: @dgmacarthur @DNAday @NHM_London I share everything with my bananas - secrets, dreams, hopes. They are terrific listeners.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Daniel MacArthur",
        "screen_name" : "dgmacarthur",
        "indices" : [ 0, 12 ],
        "id_str" : "16629477",
        "id" : 16629477
      }, {
        "name" : "National DNA Day",
        "screen_name" : "DNAday",
        "indices" : [ 13, 20 ],
        "id_str" : "21928178",
        "id" : 21928178
      }, {
        "name" : "NaturalHistoryMuseum",
        "screen_name" : "NHM_London",
        "indices" : [ 21, 32 ],
        "id_str" : "35749264",
        "id" : 35749264
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "423278780980146176",
    "geo" : { },
    "id_str" : "423279796622082048",
    "in_reply_to_user_id" : 16629477,
    "text" : "@dgmacarthur @DNAday @NHM_London I share everything with my bananas - secrets, dreams, hopes. They are terrific listeners.",
    "id" : 423279796622082048,
    "in_reply_to_status_id" : 423278780980146176,
    "created_at" : "2014-01-15 02:25:42 +0000",
    "in_reply_to_screen_name" : "dgmacarthur",
    "in_reply_to_user_id_str" : "16629477",
    "user" : {
      "name" : "Brian D. Ackley",
      "screen_name" : "DrWorms",
      "protected" : false,
      "id_str" : "532644877",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/614826718562512900\/mEOcwz3g_normal.jpg",
      "id" : 532644877,
      "verified" : false
    }
  },
  "id" : 423281491700117505,
  "created_at" : "2014-01-15 02:32:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel MacArthur",
      "screen_name" : "dgmacarthur",
      "indices" : [ 3, 15 ],
      "id_str" : "16629477",
      "id" : 16629477
    }, {
      "name" : "National DNA Day",
      "screen_name" : "DNAday",
      "indices" : [ 27, 34 ],
      "id_str" : "21928178",
      "id" : 21928178
    }, {
      "name" : "NaturalHistoryMuseum",
      "screen_name" : "NHM_London",
      "indices" : [ 126, 137 ],
      "id_str" : "35749264",
      "id" : 35749264
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "423281476327989248",
  "text" : "RT @dgmacarthur: False. RT @DNAday: Did you know humans share approximately half of our DNA sequences with bananas?! (Source: @NHM_London)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "National DNA Day",
        "screen_name" : "DNAday",
        "indices" : [ 10, 17 ],
        "id_str" : "21928178",
        "id" : 21928178
      }, {
        "name" : "NaturalHistoryMuseum",
        "screen_name" : "NHM_London",
        "indices" : [ 109, 120 ],
        "id_str" : "35749264",
        "id" : 35749264
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "423278780980146176",
    "text" : "False. RT @DNAday: Did you know humans share approximately half of our DNA sequences with bananas?! (Source: @NHM_London)",
    "id" : 423278780980146176,
    "created_at" : "2014-01-15 02:21:40 +0000",
    "user" : {
      "name" : "Daniel MacArthur",
      "screen_name" : "dgmacarthur",
      "protected" : false,
      "id_str" : "16629477",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/856238606507180033\/GWLCCqUC_normal.jpg",
      "id" : 16629477,
      "verified" : false
    }
  },
  "id" : 423281476327989248,
  "created_at" : "2014-01-15 02:32:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009678178, 8.28300312 ]
  },
  "id_str" : "423241148220854272",
  "text" : "\u00ABD\u00FCrfen meine Haare auch Poly sein?\u00BB \u2013 \u00ABWaaas?! Du Schwein! Na gut, sie darf auch f\u00E4rben. Aber keine andere Farbe, da will ich zuerst!\u00BB",
  "id" : 423241148220854272,
  "created_at" : "2014-01-14 23:52:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/Y6rSJGeOnF",
      "expanded_url" : "http:\/\/www.namemydaughter.com\/",
      "display_url" : "namemydaughter.com"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009678178, 8.28300312 ]
  },
  "id_str" : "423231631730950144",
  "text" : "Hard to decide whether Cthulhu or Megatron is the better first name. http:\/\/t.co\/Y6rSJGeOnF",
  "id" : 423231631730950144,
  "created_at" : "2014-01-14 23:14:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/VbZvthD2u6",
      "expanded_url" : "http:\/\/www.utsandiego.com\/news\/2014\/Jan\/14\/illumina-thousand-dollar-genome\/2\/?#article-copy",
      "display_url" : "utsandiego.com\/news\/2014\/Jan\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009678178, 8.28300312 ]
  },
  "id_str" : "423209044904783873",
  "text" : "Let\u2019s see how that turns out: Illumina announces $1,000 genome. http:\/\/t.co\/VbZvthD2u6",
  "id" : 423209044904783873,
  "created_at" : "2014-01-14 21:44:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Glasser",
      "screen_name" : "glasserp",
      "indices" : [ 0, 9 ],
      "id_str" : "15051699",
      "id" : 15051699
    }, {
      "name" : "Robert West PhD",
      "screen_name" : "westr",
      "indices" : [ 10, 16 ],
      "id_str" : "14267832",
      "id" : 14267832
    }, {
      "name" : "beau",
      "screen_name" : "beaugunderson",
      "indices" : [ 17, 31 ],
      "id_str" : "5746882",
      "id" : 5746882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "423205426230870018",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009678178, 8.28300312 ]
  },
  "id_str" : "423205782940045312",
  "in_reply_to_user_id" : 15051699,
  "text" : "@glasserp @westr @beaugunderson once you get the results you can tell. The v3 files have approx. 900k SNPs compared to the 600k in v4.",
  "id" : 423205782940045312,
  "in_reply_to_status_id" : 423205426230870018,
  "created_at" : "2014-01-14 21:31:36 +0000",
  "in_reply_to_screen_name" : "glasserp",
  "in_reply_to_user_id_str" : "15051699",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert West PhD",
      "screen_name" : "westr",
      "indices" : [ 0, 6 ],
      "id_str" : "14267832",
      "id" : 14267832
    }, {
      "name" : "Paul Glasser",
      "screen_name" : "glasserp",
      "indices" : [ 7, 16 ],
      "id_str" : "15051699",
      "id" : 15051699
    }, {
      "name" : "beau",
      "screen_name" : "beaugunderson",
      "indices" : [ 17, 31 ],
      "id_str" : "5746882",
      "id" : 5746882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "423204822733451264",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009678178, 8.28300312 ]
  },
  "id_str" : "423205268437348352",
  "in_reply_to_user_id" : 14267832,
  "text" : "@westr @glasserp @beaugunderson yeah, that might be. I haven\u2019t checked any v4 data against exomes etc. so far.",
  "id" : 423205268437348352,
  "in_reply_to_status_id" : 423204822733451264,
  "created_at" : "2014-01-14 21:29:33 +0000",
  "in_reply_to_screen_name" : "westr",
  "in_reply_to_user_id_str" : "14267832",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert West PhD",
      "screen_name" : "westr",
      "indices" : [ 0, 6 ],
      "id_str" : "14267832",
      "id" : 14267832
    }, {
      "name" : "Paul Glasser",
      "screen_name" : "glasserp",
      "indices" : [ 7, 16 ],
      "id_str" : "15051699",
      "id" : 15051699
    }, {
      "name" : "beau",
      "screen_name" : "beaugunderson",
      "indices" : [ 17, 31 ],
      "id_str" : "5746882",
      "id" : 5746882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "423202752425365504",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095010922, 8.2829933614 ]
  },
  "id_str" : "423203147474296832",
  "in_reply_to_user_id" : 14267832,
  "text" : "@westr @glasserp @beaugunderson yeah, from what I\u2019ve read it is. In any way losing ~300k SNPs is a bit sad.",
  "id" : 423203147474296832,
  "in_reply_to_status_id" : 423202752425365504,
  "created_at" : "2014-01-14 21:21:07 +0000",
  "in_reply_to_screen_name" : "westr",
  "in_reply_to_user_id_str" : "14267832",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joerg Roehlig",
      "screen_name" : "JoergR",
      "indices" : [ 0, 7 ],
      "id_str" : "774628164177985537",
      "id" : 774628164177985537
    }, {
      "name" : "Paul Glasser",
      "screen_name" : "glasserp",
      "indices" : [ 8, 17 ],
      "id_str" : "15051699",
      "id" : 15051699
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096617825, 8.2830534397 ]
  },
  "id_str" : "423203004515635200",
  "text" : "@JoergR @glasserp actually that\u2019s a useful info as well. :)",
  "id" : 423203004515635200,
  "created_at" : "2014-01-14 21:20:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    }, {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 7, 16 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "423199650900758528",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095207475, 8.2829134025 ]
  },
  "id_str" : "423199968938438656",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot @JP_Stich Ich kann (noch) h\u00F6ren, wie du das _noch_ betonst\u2026",
  "id" : 423199968938438656,
  "in_reply_to_status_id" : 423199650900758528,
  "created_at" : "2014-01-14 21:08:29 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/1NjwD3JQTm",
      "expanded_url" : "http:\/\/www.psychologicalscience.org\/index.php\/publications\/observer\/obsonline\/religious-infusion-predicts-intergroup-conflict-around-the-world.html",
      "display_url" : "psychologicalscience.org\/index.php\/publ\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095207475, 8.2829134025 ]
  },
  "id_str" : "423199292082630656",
  "text" : "Religious Infusion Predicts Intergroup Conflict Around the World http:\/\/t.co\/1NjwD3JQTm",
  "id" : 423199292082630656,
  "created_at" : "2014-01-14 21:05:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laurie Penny",
      "screen_name" : "PennyRed",
      "indices" : [ 3, 12 ],
      "id_str" : "19530289",
      "id" : 19530289
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/DT97u7fbvP",
      "expanded_url" : "http:\/\/bit.ly\/1almuS8",
      "display_url" : "bit.ly\/1almuS8"
    } ]
  },
  "geo" : { },
  "id_str" : "423197862529626112",
  "text" : "RT @PennyRed: The Pope's views on abortion will become ethically relevant the day the Pope gets pregnant. http:\/\/t.co\/DT97u7fbvP",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 92, 114 ],
        "url" : "http:\/\/t.co\/DT97u7fbvP",
        "expanded_url" : "http:\/\/bit.ly\/1almuS8",
        "display_url" : "bit.ly\/1almuS8"
      } ]
    },
    "geo" : { },
    "id_str" : "423152946453676032",
    "text" : "The Pope's views on abortion will become ethically relevant the day the Pope gets pregnant. http:\/\/t.co\/DT97u7fbvP",
    "id" : 423152946453676032,
    "created_at" : "2014-01-14 18:01:38 +0000",
    "user" : {
      "name" : "Laurie Penny",
      "screen_name" : "PennyRed",
      "protected" : false,
      "id_str" : "19530289",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/887966692877504512\/hrvuIg4n_normal.jpg",
      "id" : 19530289,
      "verified" : true
    }
  },
  "id" : 423197862529626112,
  "created_at" : "2014-01-14 21:00:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Glasser",
      "screen_name" : "glasserp",
      "indices" : [ 0, 9 ],
      "id_str" : "15051699",
      "id" : 15051699
    }, {
      "name" : "beau",
      "screen_name" : "beaugunderson",
      "indices" : [ 10, 24 ],
      "id_str" : "5746882",
      "id" : 5746882
    }, {
      "name" : "Robert West PhD",
      "screen_name" : "westr",
      "indices" : [ 25, 31 ],
      "id_str" : "14267832",
      "id" : 14267832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/6ynXxWNEpk",
      "expanded_url" : "http:\/\/blog.23andme.com\/news\/23andmes-new-custom-chip\/",
      "display_url" : "blog.23andme.com\/news\/23andmes-\u2026"
    }, {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/8tlmnY6oUy",
      "expanded_url" : "http:\/\/www.yourgeneticgenealogist.com\/2013\/12\/23andme-releases-sample-of-their-new-v4.html",
      "display_url" : "yourgeneticgenealogist.com\/2013\/12\/23andm\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "423196734647316480",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095207475, 8.2829134025 ]
  },
  "id_str" : "423197082305183744",
  "in_reply_to_user_id" : 15051699,
  "text" : "@glasserp @beaugunderson @westr actually I guess it will be v4, see http:\/\/t.co\/6ynXxWNEpk and http:\/\/t.co\/8tlmnY6oUy",
  "id" : 423197082305183744,
  "in_reply_to_status_id" : 423196734647316480,
  "created_at" : "2014-01-14 20:57:01 +0000",
  "in_reply_to_screen_name" : "glasserp",
  "in_reply_to_user_id_str" : "15051699",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/YSitBkfapx",
      "expanded_url" : "https:\/\/www.spotify.com\/de\/2013\/",
      "display_url" : "spotify.com\/de\/2013\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095207475, 8.2829134025 ]
  },
  "id_str" : "423194060158173184",
  "text" : "TIL (yes, totally late on this): I listened to 62 days of music in 2013. Removing sleep that gives ~25% of the time. https:\/\/t.co\/YSitBkfapx",
  "id" : 423194060158173184,
  "created_at" : "2014-01-14 20:45:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 49.999994574, 8.3051224928 ]
  },
  "id_str" : "423184595417587712",
  "text" : "\u00ABDu siehst so charmant abgeranzt intellektuell aus. Niemand der es sich nicht leisten kann w\u00FCrde so rumlaufen.\u00BB",
  "id" : 423184595417587712,
  "created_at" : "2014-01-14 20:07:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Nico Rose",
      "screen_name" : "DrNicoRose",
      "indices" : [ 3, 14 ],
      "id_str" : "216697973",
      "id" : 216697973
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Happiness",
      "indices" : [ 45, 55 ]
    }, {
      "text" : "Music",
      "indices" : [ 65, 71 ]
    } ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/MM9fF9u63c",
      "expanded_url" : "http:\/\/wp.me\/p3Prbi-eR",
      "display_url" : "wp.me\/p3Prbi-eR"
    } ]
  },
  "geo" : { },
  "id_str" : "423174168876953601",
  "text" : "RT @DrNicoRose: Heavy. Metal. Heart. Finding #Happiness in Angry #Music... http:\/\/t.co\/MM9fF9u63c",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Happiness",
        "indices" : [ 29, 39 ]
      }, {
        "text" : "Music",
        "indices" : [ 49, 55 ]
      } ],
      "urls" : [ {
        "indices" : [ 59, 81 ],
        "url" : "http:\/\/t.co\/MM9fF9u63c",
        "expanded_url" : "http:\/\/wp.me\/p3Prbi-eR",
        "display_url" : "wp.me\/p3Prbi-eR"
      } ]
    },
    "geo" : { },
    "id_str" : "423154406834462721",
    "text" : "Heavy. Metal. Heart. Finding #Happiness in Angry #Music... http:\/\/t.co\/MM9fF9u63c",
    "id" : 423154406834462721,
    "created_at" : "2014-01-14 18:07:27 +0000",
    "user" : {
      "name" : "Dr. Nico Rose",
      "screen_name" : "DrNicoRose",
      "protected" : false,
      "id_str" : "216697973",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/819859033037348865\/Y19sOGKX_normal.jpg",
      "id" : 216697973,
      "verified" : false
    }
  },
  "id" : 423174168876953601,
  "created_at" : "2014-01-14 19:25:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Glasser",
      "screen_name" : "glasserp",
      "indices" : [ 0, 9 ],
      "id_str" : "15051699",
      "id" : 15051699
    }, {
      "name" : "Robert West PhD",
      "screen_name" : "westr",
      "indices" : [ 95, 101 ],
      "id_str" : "14267832",
      "id" : 14267832
    }, {
      "name" : "samantha based clark",
      "screen_name" : "eltonjohn",
      "indices" : [ 102, 112 ],
      "id_str" : "15661851",
      "id" : 15661851
    }, {
      "name" : "beau",
      "screen_name" : "beaugunderson",
      "indices" : [ 113, 127 ],
      "id_str" : "5746882",
      "id" : 5746882
    }, {
      "name" : "Joerg Roehlig",
      "screen_name" : "JoergR",
      "indices" : [ 128, 135 ],
      "id_str" : "774628164177985537",
      "id" : 774628164177985537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "423171125930360832",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095642888, 8.2829517113 ]
  },
  "id_str" : "423173516176162816",
  "in_reply_to_user_id" : 15051699,
  "text" : "@glasserp good luck. Know there are some openSNP users on Twitter you could possibly ask, e.g. @westr @eltonjohn @beaugunderson @JoergR",
  "id" : 423173516176162816,
  "in_reply_to_status_id" : 423171125930360832,
  "created_at" : "2014-01-14 19:23:23 +0000",
  "in_reply_to_screen_name" : "glasserp",
  "in_reply_to_user_id_str" : "15051699",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 35, 41 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "423169263948795904",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095642888, 8.2829517113 ]
  },
  "id_str" : "423169828103663616",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich for now, irgendwann wird @Lobot noch \u00FCberm\u00FCtig und ich kann mir Stereo-Kopfh\u00F6rer sparen.",
  "id" : 423169828103663616,
  "in_reply_to_status_id" : 423169263948795904,
  "created_at" : "2014-01-14 19:08:43 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Glasser",
      "screen_name" : "glasserp",
      "indices" : [ 0, 9 ],
      "id_str" : "15051699",
      "id" : 15051699
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "423162087985410049",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095642888, 8.2829517113 ]
  },
  "id_str" : "423169096482836480",
  "in_reply_to_user_id" : 15051699,
  "text" : "@glasserp let us know if we can answer any questions you might have :)",
  "id" : 423169096482836480,
  "in_reply_to_status_id" : 423162087985410049,
  "created_at" : "2014-01-14 19:05:49 +0000",
  "in_reply_to_screen_name" : "glasserp",
  "in_reply_to_user_id_str" : "15051699",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/l5zc8okJEA",
      "expanded_url" : "http:\/\/www.artble.com\/imgs\/3\/2\/c\/55784\/vincent_van_gogh.jpg",
      "display_url" : "artble.com\/imgs\/3\/2\/c\/557\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "423165655375159296",
  "text" : "Die blinde Frau mit den unruhigen H\u00E4nden war wieder zum Bart schneiden da. Neuer Look jetzt: http:\/\/t.co\/l5zc8okJEA",
  "id" : 423165655375159296,
  "created_at" : "2014-01-14 18:52:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "423124447646593024",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095553817, 8.2829633217 ]
  },
  "id_str" : "423125597842571264",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC yes, testing always is worth the time. That\u2019s what I tell my students right after having long speeches on work-life-balance.",
  "id" : 423125597842571264,
  "in_reply_to_status_id" : 423124447646593024,
  "created_at" : "2014-01-14 16:12:58 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Wenz",
      "screen_name" : "sparta644",
      "indices" : [ 0, 10 ],
      "id_str" : "17988190",
      "id" : 17988190
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "423124382056460288",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095553817, 8.2829633217 ]
  },
  "id_str" : "423125442498146304",
  "in_reply_to_user_id" : 17988190,
  "text" : "@sparta644 das war die andere Assoziation dazu.",
  "id" : 423125442498146304,
  "in_reply_to_status_id" : 423124382056460288,
  "created_at" : "2014-01-14 16:12:21 +0000",
  "in_reply_to_screen_name" : "sparta644",
  "in_reply_to_user_id_str" : "17988190",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "423120593655848960",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095553817, 8.2829633217 ]
  },
  "id_str" : "423123770573066240",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC code quick &amp; dirty, so you can submit faster. So you can wait even longer for the reviewers.",
  "id" : 423123770573066240,
  "in_reply_to_status_id" : 423120593655848960,
  "created_at" : "2014-01-14 16:05:42 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 121, 144 ],
      "url" : "https:\/\/t.co\/oSaNCpEJ4z",
      "expanded_url" : "https:\/\/medium.com\/p\/3e78d22b6a04",
      "display_url" : "medium.com\/p\/3e78d22b6a04"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095553817, 8.2829633217 ]
  },
  "id_str" : "423119230138347520",
  "text" : "Sex, trash &amp; nature in the city \u00ABPublic shame didn\u2019t seem to be an operative force for people who had sex in public\u00BB https:\/\/t.co\/oSaNCpEJ4z",
  "id" : 423119230138347520,
  "created_at" : "2014-01-14 15:47:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "423117988644925440",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095553817, 8.2829633217 ]
  },
  "id_str" : "423118596844584960",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC but at least I could figure it out in the end. And all the bugs I fixed did not change my main result of my MSc thesis. \\o\/",
  "id" : 423118596844584960,
  "in_reply_to_status_id" : 423117988644925440,
  "created_at" : "2014-01-14 15:45:09 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "423117988644925440",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095553817, 8.2829633217 ]
  },
  "id_str" : "423118557124526080",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC I know why we call it computational biology or bioinformatics and not some flavor of computer \u2018science\u2019 ;)",
  "id" : 423118557124526080,
  "in_reply_to_status_id" : 423117988644925440,
  "created_at" : "2014-01-14 15:44:59 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 58 ],
      "url" : "http:\/\/t.co\/Ucy7rLPSGb",
      "expanded_url" : "http:\/\/instagram.com\/p\/jJ3zmdBwi6\/",
      "display_url" : "instagram.com\/p\/jJ3zmdBwi6\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.167350769, 8.6857995987 ]
  },
  "id_str" : "423113936356270080",
  "text" : "\u00ABJetzt schluck schon!\u00BB @ ProWoKultA http:\/\/t.co\/Ucy7rLPSGb",
  "id" : 423113936356270080,
  "created_at" : "2014-01-14 15:26:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 58 ],
      "url" : "http:\/\/t.co\/6QRlWDe333",
      "expanded_url" : "http:\/\/blogs.scientificamerican.com\/roots-of-unity\/2014\/01\/14\/collective-noun-for-mathematicians\/",
      "display_url" : "blogs.scientificamerican.com\/roots-of-unity\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095996983, 8.282942485 ]
  },
  "id_str" : "423110963626528768",
  "text" : "Collective Nouns for Mathematicians http:\/\/t.co\/6QRlWDe333",
  "id" : 423110963626528768,
  "created_at" : "2014-01-14 15:14:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/xlX6NAEAKZ",
      "expanded_url" : "http:\/\/i1.kym-cdn.com\/photos\/images\/original\/000\/656\/560\/f04.jpg",
      "display_url" : "i1.kym-cdn.com\/photos\/images\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095996983, 8.282942485 ]
  },
  "id_str" : "423096541080215552",
  "text" : "reading my 1yo undocumented &amp; uncommented code that I hoped would never have to use again\u2026 http:\/\/t.co\/xlX6NAEAKZ",
  "id" : 423096541080215552,
  "created_at" : "2014-01-14 14:17:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/99uyZqNd5A",
      "expanded_url" : "http:\/\/www.plosone.org\/article\/info%3Adoi%2F10.1371%2Fjournal.pone.0085042",
      "display_url" : "plosone.org\/article\/info%3\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009512848, 8.282936602 ]
  },
  "id_str" : "423067965425483776",
  "text" : "Economic Decisions for Others: An Exception to Loss Aversion Law http:\/\/t.co\/99uyZqNd5A",
  "id" : 423067965425483776,
  "created_at" : "2014-01-14 12:23:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 53 ],
      "url" : "http:\/\/t.co\/aoHeARDQcQ",
      "expanded_url" : "http:\/\/www.plosone.org\/article\/info%3Adoi%2F10.1371%2Fjournal.pone.0084490",
      "display_url" : "plosone.org\/article\/info%3\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009512848, 8.282936602 ]
  },
  "id_str" : "423067311445409793",
  "text" : "Detecting Unidentified Changes http:\/\/t.co\/aoHeARDQcQ",
  "id" : 423067311445409793,
  "created_at" : "2014-01-14 12:21:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russell Quotes",
      "screen_name" : "BertrandSez",
      "indices" : [ 3, 15 ],
      "id_str" : "2237380423",
      "id" : 2237380423
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "423053461241229312",
  "text" : "RT @BertrandSez: Do not feel envious of the happiness of those who live in a fool's paradise, for only a fool will think that it is happine\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/circular.io\" rel=\"nofollow\"\u003ECircular.io\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "423029216498962432",
    "text" : "Do not feel envious of the happiness of those who live in a fool's paradise, for only a fool will think that it is happiness.",
    "id" : 423029216498962432,
    "created_at" : "2014-01-14 09:49:59 +0000",
    "user" : {
      "name" : "Russell Quotes",
      "screen_name" : "BertrandSez",
      "protected" : false,
      "id_str" : "2237380423",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000849658233\/dcc804bf7c4e208b933a2f325fb7a35b_normal.jpeg",
      "id" : 2237380423,
      "verified" : false
    }
  },
  "id" : 423053461241229312,
  "created_at" : "2014-01-14 11:26:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "423030985953796096",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096532313, 8.2829583957 ]
  },
  "id_str" : "423045340963803136",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer was still awake, replied to your tweet while setting the alarm and then went to bed.",
  "id" : 423045340963803136,
  "in_reply_to_status_id" : 423030985953796096,
  "created_at" : "2014-01-14 10:54:03 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "422930080235405312",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096512189, 8.282958937 ]
  },
  "id_str" : "423045147031777280",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer ah, yes. I forgot the lecturers name but it wasn\u2019t bad but he couldn\u2019t really answer our questions about this iirc.",
  "id" : 423045147031777280,
  "in_reply_to_status_id" : 422930080235405312,
  "created_at" : "2014-01-14 10:53:17 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "422904102738096128",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096838678, 8.2831761767 ]
  },
  "id_str" : "422918854365679616",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer haha, nice. what was it? second year of undergrad? :D",
  "id" : 422918854365679616,
  "in_reply_to_status_id" : 422904102738096128,
  "created_at" : "2014-01-14 02:31:26 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shit Academics Say",
      "screen_name" : "AcademicsSay",
      "indices" : [ 3, 16 ],
      "id_str" : "1891806212",
      "id" : 1891806212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "422834817982812160",
  "text" : "RT @AcademicsSay: If you can't say anything nice, say it as a question.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "422479033738485760",
    "text" : "If you can't say anything nice, say it as a question.",
    "id" : 422479033738485760,
    "created_at" : "2014-01-12 21:23:45 +0000",
    "user" : {
      "name" : "Shit Academics Say",
      "screen_name" : "AcademicsSay",
      "protected" : false,
      "id_str" : "1891806212",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/748151916836716546\/Ldn_dhiC_normal.jpg",
      "id" : 1891806212,
      "verified" : false
    }
  },
  "id" : 422834817982812160,
  "created_at" : "2014-01-13 20:57:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1001944092, 8.7522047011 ]
  },
  "id_str" : "422801433256546305",
  "text" : "\u00ABDu schaust so ernst?\u00BB \u2014 \u00ABIch hab grade dar\u00FCber nachgedacht wieviel Spass wir zusammen haben.\u00BB",
  "id" : 422801433256546305,
  "created_at" : "2014-01-13 18:44:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ed Yong",
      "screen_name" : "edyong209",
      "indices" : [ 3, 13 ],
      "id_str" : "19767193",
      "id" : 19767193
    }, {
      "name" : "Megan Garber",
      "screen_name" : "megangarber",
      "indices" : [ 36, 48 ],
      "id_str" : "18751963",
      "id" : 18751963
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/S1u7XPSS2Q",
      "expanded_url" : "http:\/\/theatln.tc\/JUKjq5",
      "display_url" : "theatln.tc\/JUKjq5"
    } ]
  },
  "geo" : { },
  "id_str" : "422727261079764992",
  "text" : "RT @edyong209: Spot-on analysis. RT @megangarber: Try not to get cancer, guys\u2014you might end up offending people. http:\/\/t.co\/S1u7XPSS2Q",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Megan Garber",
        "screen_name" : "megangarber",
        "indices" : [ 21, 33 ],
        "id_str" : "18751963",
        "id" : 18751963
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 98, 120 ],
        "url" : "http:\/\/t.co\/S1u7XPSS2Q",
        "expanded_url" : "http:\/\/theatln.tc\/JUKjq5",
        "display_url" : "theatln.tc\/JUKjq5"
      } ]
    },
    "geo" : { },
    "id_str" : "422726494704521216",
    "text" : "Spot-on analysis. RT @megangarber: Try not to get cancer, guys\u2014you might end up offending people. http:\/\/t.co\/S1u7XPSS2Q",
    "id" : 422726494704521216,
    "created_at" : "2014-01-13 13:47:04 +0000",
    "user" : {
      "name" : "Ed Yong",
      "screen_name" : "edyong209",
      "protected" : false,
      "id_str" : "19767193",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/926063794912153600\/962ygzzx_normal.jpg",
      "id" : 19767193,
      "verified" : true
    }
  },
  "id" : 422727261079764992,
  "created_at" : "2014-01-13 13:50:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 54 ],
      "url" : "http:\/\/t.co\/ohg0Bq1b1E",
      "expanded_url" : "http:\/\/www.bbc.co.uk\/news\/magazine-25551393",
      "display_url" : "bbc.co.uk\/news\/magazine-\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "422543582377951232",
  "geo" : { },
  "id_str" : "422715630786080769",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer relevant to that: http:\/\/t.co\/ohg0Bq1b1E ;)",
  "id" : 422715630786080769,
  "in_reply_to_status_id" : 422543582377951232,
  "created_at" : "2014-01-13 13:03:54 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/OGALyKEgpt",
      "expanded_url" : "http:\/\/www.reddit.com\/r\/AskReddit\/comments\/1v1zes\/what_is_a_gross_smell_that_you_actually_kind_of\/",
      "display_url" : "reddit.com\/r\/AskReddit\/co\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "422712346243395584",
  "text" : "What is a \"gross\" smell that you actually kind of like? \u00ABA Dutch oven selfie\u00BB \u2013 \u00ABInstagram that shit\u00BB http:\/\/t.co\/OGALyKEgpt",
  "id" : 422712346243395584,
  "created_at" : "2014-01-13 12:50:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 37 ],
      "url" : "http:\/\/t.co\/DNdYdxlgPP",
      "expanded_url" : "http:\/\/i.imgur.com\/pXhNQwr.gif",
      "display_url" : "i.imgur.com\/pXhNQwr.gif"
    } ]
  },
  "geo" : { },
  "id_str" : "422706238489493505",
  "text" : "having a drink http:\/\/t.co\/DNdYdxlgPP",
  "id" : 422706238489493505,
  "created_at" : "2014-01-13 12:26:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/u5oqKH2EO6",
      "expanded_url" : "http:\/\/bps-occupational-digest.blogspot.de\/2014\/01\/what-does-volunteering-say-about-how.html",
      "display_url" : "bps-occupational-digest.blogspot.de\/2014\/01\/what-d\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "422697592808415232",
  "text" : "Meaning-rich work doesn't satiate our hunger for meaning, but galvanises us to seek roles that might supply even more http:\/\/t.co\/u5oqKH2EO6",
  "id" : 422697592808415232,
  "created_at" : "2014-01-13 11:52:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723473254, 8.6276151795 ]
  },
  "id_str" : "422670200946036736",
  "text" : "\u00ABVoll rutschig wenn man den Hut der Schande mit der Weihnachtsm\u00FCtze zusammen tr\u00E4gt!\u00BB \u2014 \u00ABDu tr\u00E4gst den noch?!\u00BB \u2014 \u00ABSeit der Weihnachtsfeier\u2026\u00BB",
  "id" : 422670200946036736,
  "created_at" : "2014-01-13 10:03:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/H5Vb2BX0P0",
      "expanded_url" : "http:\/\/i.imgur.com\/6I8YDM7.gif",
      "display_url" : "i.imgur.com\/6I8YDM7.gif"
    } ]
  },
  "geo" : { },
  "id_str" : "422666052091138048",
  "text" : "after eyeballing the results: assembly quality has finally improved http:\/\/t.co\/H5Vb2BX0P0",
  "id" : 422666052091138048,
  "created_at" : "2014-01-13 09:46:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723399491, 8.6276058381 ]
  },
  "id_str" : "422653757307240448",
  "text" : "\u00ABWas?! Du bist um diese Zeit schon im B\u00FCro und produkt\u2026 \u2026ah, du liest reddit.\u00BB",
  "id" : 422653757307240448,
  "created_at" : "2014-01-13 08:58:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "422543582377951232",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096893497, 8.2827338576 ]
  },
  "id_str" : "422618378273320960",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer yeah, the one big advantage of commuting with public transportation. ~ 2 1\/2 - 3 h of reading time a day for me.",
  "id" : 422618378273320960,
  "in_reply_to_status_id" : 422543582377951232,
  "created_at" : "2014-01-13 06:37:27 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "stolpermarathon",
      "indices" : [ 120, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096640108, 8.2830500849 ]
  },
  "id_str" : "422539942615855104",
  "text" : "Nachts sind alle Katzen grau. Und der Teppich. Und der W\u00E4schest\u00E4nder. Und die Kartons die auf dem Fu\u00DFboden stehen. Und\u2026 #stolpermarathon",
  "id" : 422539942615855104,
  "created_at" : "2014-01-13 01:25:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "422538520280829952",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096955775, 8.2830400125 ]
  },
  "id_str" : "422538778864275456",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer that\u2019s so sad!",
  "id" : 422538778864275456,
  "in_reply_to_status_id" : 422538520280829952,
  "created_at" : "2014-01-13 01:21:09 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "422538123529031682",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096955775, 8.2830400125 ]
  },
  "id_str" : "422538413271965696",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer np, let me know if you need anything else. Will have to check your lists soon enough :D",
  "id" : 422538413271965696,
  "in_reply_to_status_id" : 422538123529031682,
  "created_at" : "2014-01-13 01:19:42 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "422536739865894912",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096955775, 8.2830400125 ]
  },
  "id_str" : "422537559177445376",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer sure, should just have been added to the folder :)",
  "id" : 422537559177445376,
  "in_reply_to_status_id" : 422536739865894912,
  "created_at" : "2014-01-13 01:16:19 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/rTAbzUHtRf",
      "expanded_url" : "http:\/\/ilovesymposia.com\/2014\/01\/09\/best-practices-addendum-find-and-follow-the-conventions-of-your-programming-community\/",
      "display_url" : "ilovesymposia.com\/2014\/01\/09\/bes\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00964754, 8.2829954971 ]
  },
  "id_str" : "422532115398680576",
  "text" : "Best practices addendum: find and follow the conventions of your programming\u00A0community http:\/\/t.co\/rTAbzUHtRf",
  "id" : 422532115398680576,
  "created_at" : "2014-01-13 00:54:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/3pXlyCiA5w",
      "expanded_url" : "http:\/\/techcrunch.com\/2014\/01\/11\/such-dfw-very-orwell-so-doge-wow\/",
      "display_url" : "techcrunch.com\/2014\/01\/11\/suc\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00964754, 8.2829954971 ]
  },
  "id_str" : "422526409253588992",
  "text" : "\u00ABNow people who write in Clinical Standard Written English actually mark themselves as untrustworthy by doing so\u00BB http:\/\/t.co\/3pXlyCiA5w",
  "id" : 422526409253588992,
  "created_at" : "2014-01-13 00:32:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 3, 13 ],
      "id_str" : "14700783",
      "id" : 14700783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/zkvYcMyBph",
      "expanded_url" : "http:\/\/lostinscientia.wordpress.com\/2014\/01\/12\/new-sister-journal-to-nature-chemistry\/",
      "display_url" : "lostinscientia.wordpress.com\/2014\/01\/12\/new\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "422515881428910081",
  "text" : "RT @Fischblog: *kicher* New sister journal for Nature Chemistry http:\/\/t.co\/zkvYcMyBph",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.metrotwit.com\/\" rel=\"nofollow\"\u003EMetroTwit\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 49, 71 ],
        "url" : "http:\/\/t.co\/zkvYcMyBph",
        "expanded_url" : "http:\/\/lostinscientia.wordpress.com\/2014\/01\/12\/new-sister-journal-to-nature-chemistry\/",
        "display_url" : "lostinscientia.wordpress.com\/2014\/01\/12\/new\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "422511178448134145",
    "text" : "*kicher* New sister journal for Nature Chemistry http:\/\/t.co\/zkvYcMyBph",
    "id" : 422511178448134145,
    "created_at" : "2014-01-12 23:31:29 +0000",
    "user" : {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "protected" : false,
      "id_str" : "14700783",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/929627167125921792\/t5PPk1W-_normal.jpg",
      "id" : 14700783,
      "verified" : false
    }
  },
  "id" : 422515881428910081,
  "created_at" : "2014-01-12 23:50:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 14, 23 ],
      "id_str" : "14861745",
      "id" : 14861745
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 24, 30 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/fRMyiteFPY",
      "expanded_url" : "http:\/\/1.bp.blogspot.com\/-G6PZzA4_gfI\/UfKiC-JDuBI\/AAAAAAAAN8g\/wDIwu-DbxaU\/s1600\/guitar-prank.gif",
      "display_url" : "1.bp.blogspot.com\/-G6PZzA4_gfI\/U\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "422513124567031808",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00964754, 8.2829954971 ]
  },
  "id_str" : "422513981644091392",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @Senficon @Lobot now we only need to learn to play our instruments while asleep? http:\/\/t.co\/fRMyiteFPY",
  "id" : 422513981644091392,
  "in_reply_to_status_id" : 422513124567031808,
  "created_at" : "2014-01-12 23:42:37 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 57, 66 ],
      "id_str" : "14861745",
      "id" : 14861745
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 71, 77 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "422512368501796864",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00964754, 8.2829954971 ]
  },
  "id_str" : "422512963447422976",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer at least that\u2019s what I\u2019m told. You may ask @Senficon and @Lobot whether they can give any details (should start doing records)",
  "id" : 422512963447422976,
  "in_reply_to_status_id" : 422512368501796864,
  "created_at" : "2014-01-12 23:38:35 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "422511541464727552",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00964754, 8.2829954971 ]
  },
  "id_str" : "422511952989257728",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer welcome to the club!",
  "id" : 422511952989257728,
  "in_reply_to_status_id" : 422511541464727552,
  "created_at" : "2014-01-12 23:34:34 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ed Yong",
      "screen_name" : "edyong209",
      "indices" : [ 3, 13 ],
      "id_str" : "19767193",
      "id" : 19767193
    }, {
      "name" : "The Neurocritic",
      "screen_name" : "neurocritic",
      "indices" : [ 127, 139 ],
      "id_str" : "87321664",
      "id" : 87321664
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/bOQkzt9Zfk",
      "expanded_url" : "http:\/\/neurocritic.blogspot.co.uk\/2014\/01\/neurocrap-funded-by-masses-neuroon-and.html",
      "display_url" : "neurocritic.blogspot.co.uk\/2014\/01\/neuroc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "422511541041508352",
  "text" : "RT @edyong209: Crowdfunding: making it easier for YOU to help spurious neurononsense become reality. http:\/\/t.co\/bOQkzt9Zfk HT @neurocritic",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The Neurocritic",
        "screen_name" : "neurocritic",
        "indices" : [ 112, 124 ],
        "id_str" : "87321664",
        "id" : 87321664
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 86, 108 ],
        "url" : "http:\/\/t.co\/bOQkzt9Zfk",
        "expanded_url" : "http:\/\/neurocritic.blogspot.co.uk\/2014\/01\/neurocrap-funded-by-masses-neuroon-and.html",
        "display_url" : "neurocritic.blogspot.co.uk\/2014\/01\/neuroc\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "422422415696592898",
    "text" : "Crowdfunding: making it easier for YOU to help spurious neurononsense become reality. http:\/\/t.co\/bOQkzt9Zfk HT @neurocritic",
    "id" : 422422415696592898,
    "created_at" : "2014-01-12 17:38:46 +0000",
    "user" : {
      "name" : "Ed Yong",
      "screen_name" : "edyong209",
      "protected" : false,
      "id_str" : "19767193",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/926063794912153600\/962ygzzx_normal.jpg",
      "id" : 19767193,
      "verified" : true
    }
  },
  "id" : 422511541041508352,
  "created_at" : "2014-01-12 23:32:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "J\u00FCrgen Geuter",
      "screen_name" : "tante",
      "indices" : [ 0, 6 ],
      "id_str" : "14179278",
      "id" : 14179278
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/QuOMw1Vnn1",
      "expanded_url" : "http:\/\/25.media.tumblr.com\/RaAhBBk4Tigo5nmlX5ye9xtHo1_500.png",
      "display_url" : "25.media.tumblr.com\/RaAhBBk4Tigo5n\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "422492541880369153",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00964754, 8.2829954971 ]
  },
  "id_str" : "422493013332742144",
  "in_reply_to_user_id" : 14179278,
  "text" : "@tante read that as chimps and immediately thought of http:\/\/t.co\/QuOMw1Vnn1",
  "id" : 422493013332742144,
  "in_reply_to_status_id" : 422492541880369153,
  "created_at" : "2014-01-12 22:19:18 +0000",
  "in_reply_to_screen_name" : "tante",
  "in_reply_to_user_id_str" : "14179278",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ella Giles",
      "screen_name" : "DrBondar",
      "indices" : [ 3, 12 ],
      "id_str" : "4018649255",
      "id" : 4018649255
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MileyCyrus",
      "indices" : [ 52, 63 ]
    }, {
      "text" : "evolution",
      "indices" : [ 67, 77 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/ijA9EqH7o5",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=dx-Sy5M3bME",
      "display_url" : "youtube.com\/watch?v=dx-Sy5\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "422482156041277441",
  "text" : "RT @DrBondar: There needs to be a science parody of #MileyCyrus on #evolution.  good thing I made one: http:\/\/t.co\/ijA9EqH7o5",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MileyCyrus",
        "indices" : [ 38, 49 ]
      }, {
        "text" : "evolution",
        "indices" : [ 53, 63 ]
      } ],
      "urls" : [ {
        "indices" : [ 89, 111 ],
        "url" : "http:\/\/t.co\/ijA9EqH7o5",
        "expanded_url" : "http:\/\/www.youtube.com\/watch?v=dx-Sy5M3bME",
        "display_url" : "youtube.com\/watch?v=dx-Sy5\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "422452646687952896",
    "text" : "There needs to be a science parody of #MileyCyrus on #evolution.  good thing I made one: http:\/\/t.co\/ijA9EqH7o5",
    "id" : 422452646687952896,
    "created_at" : "2014-01-12 19:38:54 +0000",
    "user" : {
      "name" : "Carin Anne Bondar",
      "screen_name" : "carinbondar",
      "protected" : false,
      "id_str" : "104070525",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/906245755685318657\/X2Uvi2AA_normal.jpg",
      "id" : 104070525,
      "verified" : true
    }
  },
  "id" : 422482156041277441,
  "created_at" : "2014-01-12 21:36:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Misha Angrist",
      "screen_name" : "MishaAngrist",
      "indices" : [ 3, 16 ],
      "id_str" : "116877838",
      "id" : 116877838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "422465521708068864",
  "text" : "RT @MishaAngrist: \"Gladwell ignores the 100 [other] bands in Europe working this same circuit [and] playing the same grueling schedule\u201D htt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/uawD0yJDbb",
        "expanded_url" : "http:\/\/www.premierguitar.com\/articles\/20137-last-call-practice-makes",
        "display_url" : "premierguitar.com\/articles\/20137\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "422463792174227458",
    "text" : "\"Gladwell ignores the 100 [other] bands in Europe working this same circuit [and] playing the same grueling schedule\u201D http:\/\/t.co\/uawD0yJDbb",
    "id" : 422463792174227458,
    "created_at" : "2014-01-12 20:23:11 +0000",
    "user" : {
      "name" : "Misha Angrist",
      "screen_name" : "MishaAngrist",
      "protected" : false,
      "id_str" : "116877838",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747461459974717441\/GIrZkLT-_normal.jpg",
      "id" : 116877838,
      "verified" : false
    }
  },
  "id" : 422465521708068864,
  "created_at" : "2014-01-12 20:30:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00964754, 8.2829954971 ]
  },
  "id_str" : "422463918863572992",
  "text" : "\u00ABDas sind keine Spermaflecken! Das sind Zeugnisse von eating yoghurt while bearded!\u00BB",
  "id" : 422463918863572992,
  "created_at" : "2014-01-12 20:23:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 75 ],
      "url" : "http:\/\/t.co\/1uHYQ9nBr5",
      "expanded_url" : "http:\/\/instagram.com\/p\/jFH981hwpY\/",
      "display_url" : "instagram.com\/p\/jFH981hwpY\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0094076368, 8.2804512978 ]
  },
  "id_str" : "422445788565094400",
  "text" : "Mr. Trash @ Br\u00FCckenkopf Kastel Graffiti Hall Of Fame http:\/\/t.co\/1uHYQ9nBr5",
  "id" : 422445788565094400,
  "created_at" : "2014-01-12 19:11:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "422402974506569729",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00964754, 8.2829954971 ]
  },
  "id_str" : "422404187016929280",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon yay, ich hab das Fass bald also f\u00FCr mich allein?",
  "id" : 422404187016929280,
  "in_reply_to_status_id" : 422402974506569729,
  "created_at" : "2014-01-12 16:26:20 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/PfAyVGXvlV",
      "expanded_url" : "http:\/\/instagram.com\/p\/jEn5hZhwq2\/",
      "display_url" : "instagram.com\/p\/jEn5hZhwq2\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.005452, 8.269108 ]
  },
  "id_str" : "422375268347838464",
  "text" : "Christuskirche @ Dativius-Victor-Bogen http:\/\/t.co\/PfAyVGXvlV",
  "id" : 422375268347838464,
  "created_at" : "2014-01-12 14:31:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 121, 143 ],
      "url" : "http:\/\/t.co\/dVE2kMcnQi",
      "expanded_url" : "http:\/\/www.radiolab.org\/story\/apocalyptical-live-paramount-seattle\/",
      "display_url" : "radiolab.org\/story\/apocalyp\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "422366640488325120",
  "text" : "\u00ABThe only thing that\u2019s constant, that\u2019s always, is change.\u00BB The parts on the Dinocalypse &amp; Endgame are so beautiful! http:\/\/t.co\/dVE2kMcnQi",
  "id" : 422366640488325120,
  "created_at" : "2014-01-12 13:57:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 36 ],
      "url" : "http:\/\/t.co\/fCNyy3jYKK",
      "expanded_url" : "http:\/\/instagram.com\/p\/jEf2X1Bwg1\/",
      "display_url" : "instagram.com\/p\/jEf2X1Bwg1\/"
    } ]
  },
  "geo" : { },
  "id_str" : "422357567441211392",
  "text" : "Let Love Grow http:\/\/t.co\/fCNyy3jYKK",
  "id" : 422357567441211392,
  "created_at" : "2014-01-12 13:21:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u03B8ourkni\u02D0r\u0325",
      "screen_name" : "thorgnyr",
      "indices" : [ 0, 9 ],
      "id_str" : "38015980",
      "id" : 38015980
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "422335290217623552",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009684614, 8.2829186786 ]
  },
  "id_str" : "422335393313603585",
  "in_reply_to_user_id" : 38015980,
  "text" : "@thorgnyr okay, just drop me a note once you know more! :)",
  "id" : 422335393313603585,
  "in_reply_to_status_id" : 422335290217623552,
  "created_at" : "2014-01-12 11:52:59 +0000",
  "in_reply_to_screen_name" : "thorgnyr",
  "in_reply_to_user_id_str" : "38015980",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u03B8ourkni\u02D0r\u0325",
      "screen_name" : "thorgnyr",
      "indices" : [ 0, 9 ],
      "id_str" : "38015980",
      "id" : 38015980
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "422334807138635776",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096550536, 8.2831550848 ]
  },
  "id_str" : "422335018036641792",
  "in_reply_to_user_id" : 38015980,
  "text" : "@thorgnyr reminds me: you still owe me a scouting related email. :)",
  "id" : 422335018036641792,
  "in_reply_to_status_id" : 422334807138635776,
  "created_at" : "2014-01-12 11:51:29 +0000",
  "in_reply_to_screen_name" : "thorgnyr",
  "in_reply_to_user_id_str" : "38015980",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u03B8ourkni\u02D0r\u0325",
      "screen_name" : "thorgnyr",
      "indices" : [ 0, 9 ],
      "id_str" : "38015980",
      "id" : 38015980
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "422333437459320832",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096420258, 8.2830551219 ]
  },
  "id_str" : "422333563678511104",
  "in_reply_to_user_id" : 38015980,
  "text" : "@thorgnyr congratulations!",
  "id" : 422333563678511104,
  "in_reply_to_status_id" : 422333437459320832,
  "created_at" : "2014-01-12 11:45:42 +0000",
  "in_reply_to_screen_name" : "thorgnyr",
  "in_reply_to_user_id_str" : "38015980",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/kindle.amazon.com\" rel=\"nofollow\"\u003EKindle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/ylgN427YUH",
      "expanded_url" : "http:\/\/amzn.com\/k\/hzDONzOCQUCT-qq0TrL2Zg",
      "display_url" : "amzn.com\/k\/hzDONzOCQUCT\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "422165413662048256",
  "text" : "\u00AB[\u2026] we should be willing to sing our swan song with joy\u2014sic transit gloria mundi.\u00BB http:\/\/t.co\/ylgN427YUH The average species of fos...",
  "id" : 422165413662048256,
  "created_at" : "2014-01-12 00:37:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "li5a",
      "screen_name" : "li5a",
      "indices" : [ 0, 5 ],
      "id_str" : "11712822",
      "id" : 11712822
    }, {
      "name" : "samantha based clark",
      "screen_name" : "eltonjohn",
      "indices" : [ 6, 16 ],
      "id_str" : "15661851",
      "id" : 15661851
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "422159737883721728",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009678314, 8.28300256 ]
  },
  "id_str" : "422160326545899521",
  "in_reply_to_user_id" : 11712822,
  "text" : "@li5a @eltonjohn plus: virtually all bioinformatics is very DIY-like. \u00B1 all tools (+lots of data) are open source and freely available.",
  "id" : 422160326545899521,
  "in_reply_to_status_id" : 422159737883721728,
  "created_at" : "2014-01-12 00:17:19 +0000",
  "in_reply_to_screen_name" : "li5a",
  "in_reply_to_user_id_str" : "11712822",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "C\u24D0thal G\u24D0rvey",
      "screen_name" : "onetruecathal",
      "indices" : [ 0, 14 ],
      "id_str" : "16066596",
      "id" : 16066596
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "422154921346334720",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009678314, 8.28300256 ]
  },
  "id_str" : "422155128314290176",
  "in_reply_to_user_id" : 16066596,
  "text" : "@onetruecathal Stephen Jay Gould in \u2018The Panda\u2019s Thumb\u2019.",
  "id" : 422155128314290176,
  "in_reply_to_status_id" : 422154921346334720,
  "created_at" : "2014-01-11 23:56:40 +0000",
  "in_reply_to_screen_name" : "onetruecathal",
  "in_reply_to_user_id_str" : "16066596",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096653671, 8.2830822214 ]
  },
  "id_str" : "422150438746853376",
  "text" : "\u00ABIf genius has any common denominator, I would propose breadth of interest and the ability to construct fruitful analogies between fields.\u00BB",
  "id" : 422150438746853376,
  "created_at" : "2014-01-11 23:38:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/RpPMfotdsC",
      "expanded_url" : "http:\/\/occamstypewriter.org\/scurry\/2014\/01\/11\/unfinished-business\/",
      "display_url" : "occamstypewriter.org\/scurry\/2014\/01\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096653671, 8.2830822214 ]
  },
  "id_str" : "422135230070550528",
  "text" : "Unfinished Business \u00ABfailure punctuated by enough triumphs to keep the show on the road\u00BB http:\/\/t.co\/RpPMfotdsC",
  "id" : 422135230070550528,
  "created_at" : "2014-01-11 22:37:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/kindle.amazon.com\" rel=\"nofollow\"\u003EKindle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/QXuGI2doQ2",
      "expanded_url" : "http:\/\/amzn.com\/k\/7VpgeqW9Tqqh7DjXRNESzw",
      "display_url" : "amzn.com\/k\/7VpgeqW9Tqqh\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "422118524027666432",
  "text" : "Stephen Jay Gould was lured into the field by same empty promises as I was half a century later! http:\/\/t.co\/QXuGI2doQ2 I was lucky t...",
  "id" : 422118524027666432,
  "created_at" : "2014-01-11 21:31:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\/Andreas K. Bittner",
      "screen_name" : "qwasi",
      "indices" : [ 0, 6 ],
      "id_str" : "15835452",
      "id" : 15835452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "422111897341935616",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009664998, 8.283039414 ]
  },
  "id_str" : "422112143354650624",
  "in_reply_to_user_id" : 15835452,
  "text" : "@qwasi long time no see! Wie l\u00E4uft es in MS?",
  "id" : 422112143354650624,
  "in_reply_to_status_id" : 422111897341935616,
  "created_at" : "2014-01-11 21:05:52 +0000",
  "in_reply_to_screen_name" : "qwasi",
  "in_reply_to_user_id_str" : "15835452",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "422111044643737600",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009664998, 8.283039414 ]
  },
  "id_str" : "422111407338164225",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot could we please go for cetacean baculum, that sounds so much nicer for a nickname.",
  "id" : 422111407338164225,
  "in_reply_to_status_id" : 422111044643737600,
  "created_at" : "2014-01-11 21:02:56 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "422110202310037504",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096943789, 8.2829756755 ]
  },
  "id_str" : "422110616468586496",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot you should be afraid of the answers and believe Wikipedia if in doubt.",
  "id" : 422110616468586496,
  "in_reply_to_status_id" : 422110202310037504,
  "created_at" : "2014-01-11 20:59:48 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "422104166522044416",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096488697, 8.2830522601 ]
  },
  "id_str" : "422109883589492736",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot well thanks to my laughs I now always have to guess whether you actually still have questions. ;)",
  "id" : 422109883589492736,
  "in_reply_to_status_id" : 422104166522044416,
  "created_at" : "2014-01-11 20:56:53 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/Bl1cOJmBXR",
      "expanded_url" : "http:\/\/en.wikipedia.org\/wiki\/Banjo_guitar",
      "display_url" : "en.wikipedia.org\/wiki\/Banjo_gui\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009664998, 8.283039414 ]
  },
  "id_str" : "422109080699027456",
  "text" : "According to Wikipedia Sylvester Stallone plays 6-string banjo [citation needed] http:\/\/t.co\/Bl1cOJmBXR",
  "id" : 422109080699027456,
  "created_at" : "2014-01-11 20:53:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/whuhvVqUUE",
      "expanded_url" : "http:\/\/boingboing.net\/2014\/01\/11\/crowdsourced-realtime-date-ad.html",
      "display_url" : "boingboing.net\/2014\/01\/11\/cro\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009664998, 8.283039414 ]
  },
  "id_str" : "422092297539702784",
  "text" : "Crowdsourced, realtime date advice: networked hivemind\u00A0Cyrano http:\/\/t.co\/whuhvVqUUE",
  "id" : 422092297539702784,
  "created_at" : "2014-01-11 19:47:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/yrSaKgoWoa",
      "expanded_url" : "http:\/\/www.plosone.org\/article\/info%3Adoi%2F10.1371%2Fjournal.pone.0084727",
      "display_url" : "plosone.org\/article\/info%3\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096629013, 8.283070775 ]
  },
  "id_str" : "422074607429246976",
  "text" : "The Quality of Registration of Clinical Trials: Still a Problem http:\/\/t.co\/yrSaKgoWoa",
  "id" : 422074607429246976,
  "created_at" : "2014-01-11 18:36:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/xngvSyOlPl",
      "expanded_url" : "http:\/\/boingboing.net\/2014\/01\/10\/maker-doctor-builds-his-own-ru.html",
      "display_url" : "boingboing.net\/2014\/01\/10\/mak\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096629013, 8.283070775 ]
  },
  "id_str" : "422073959287652353",
  "text" : "Maker doctor builds his own rural hospital equipment out of\u00A0scrap http:\/\/t.co\/xngvSyOlPl",
  "id" : 422073959287652353,
  "created_at" : "2014-01-11 18:34:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 82, 91 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 77 ],
      "url" : "http:\/\/t.co\/7yoZhH6UsU",
      "expanded_url" : "http:\/\/www.radiolab.org\/story\/sex-ducks-and-founding-feud\/",
      "display_url" : "radiolab.org\/story\/sex-duck\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096629013, 8.283070775 ]
  },
  "id_str" : "422068622501351424",
  "text" : "Sex, Ducks &amp; The Founding Feud: On US treaty power http:\/\/t.co\/7yoZhH6UsU \/cc @Senficon",
  "id" : 422068622501351424,
  "created_at" : "2014-01-11 18:12:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 109, 115 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/JrHW5NTUxm",
      "expanded_url" : "http:\/\/99percentinvisible.org\/episode\/numbers-stations\/",
      "display_url" : "99percentinvisible.org\/episode\/number\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0129268129, 8.2649295387 ]
  },
  "id_str" : "422056875182800896",
  "text" : "An intro to numbers stations (w\/ questions you might have asked hadn\u2019t I mistakin. laughed at your ignorance @Lobot) http:\/\/t.co\/JrHW5NTUxm",
  "id" : 422056875182800896,
  "created_at" : "2014-01-11 17:26:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096629013, 8.283070775 ]
  },
  "id_str" : "422014705998495744",
  "text" : "Der verlorene Sohn* ist heimgekehrt! \n\n*Der Roomba(, mit neuem B\u00FCrstenkopf)",
  "id" : 422014705998495744,
  "created_at" : "2014-01-11 14:38:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Arzheimer",
      "screen_name" : "kai_arzheimer",
      "indices" : [ 3, 17 ],
      "id_str" : "16736320",
      "id" : 16736320
    }, {
      "name" : "Chris Blattman",
      "screen_name" : "cblatts",
      "indices" : [ 48, 56 ],
      "id_str" : "74051281",
      "id" : 74051281
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 79 ],
      "url" : "http:\/\/t.co\/G11NCC2IKy",
      "expanded_url" : "http:\/\/buff.ly\/1iZhebK",
      "display_url" : "buff.ly\/1iZhebK"
    } ]
  },
  "geo" : { },
  "id_str" : "422013107192750080",
  "text" : "RT @kai_arzheimer: Our intellectual cowardice | @cblatts http:\/\/t.co\/G11NCC2IKy",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Chris Blattman",
        "screen_name" : "cblatts",
        "indices" : [ 29, 37 ],
        "id_str" : "74051281",
        "id" : 74051281
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 38, 60 ],
        "url" : "http:\/\/t.co\/G11NCC2IKy",
        "expanded_url" : "http:\/\/buff.ly\/1iZhebK",
        "display_url" : "buff.ly\/1iZhebK"
      } ]
    },
    "geo" : { },
    "id_str" : "422006751383523328",
    "text" : "Our intellectual cowardice | @cblatts http:\/\/t.co\/G11NCC2IKy",
    "id" : 422006751383523328,
    "created_at" : "2014-01-11 14:07:04 +0000",
    "user" : {
      "name" : "Kai Arzheimer",
      "screen_name" : "kai_arzheimer",
      "protected" : false,
      "id_str" : "16736320",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/74112233\/kai_1_normal.jpg",
      "id" : 16736320,
      "verified" : false
    }
  },
  "id" : 422013107192750080,
  "created_at" : "2014-01-11 14:32:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/EEa0QABExm",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=BcIXujJdNPQ",
      "display_url" : "youtube.com\/watch?v=BcIXuj\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096629013, 8.283070775 ]
  },
  "id_str" : "422012465489408000",
  "text" : "\u00ABalone in a cold north scene in the blue sky above a plane flew over me. The banner it pulled said, you\u2019re a fool\u2026\u00BB http:\/\/t.co\/EEa0QABExm",
  "id" : 422012465489408000,
  "created_at" : "2014-01-11 14:29:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009667275, 8.2830604903 ]
  },
  "id_str" : "422003795984658433",
  "text" : "Autokorrektur macht aus \u2018vielen Dank\u2019 mal lieber \u2018Coelenterates\u2019. Dachte das die Gruppe nun eigentlich \u00FCberfl\u00FCssig ist weil paraphyletisch?",
  "id" : 422003795984658433,
  "created_at" : "2014-01-11 13:55:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andreas Krennmair",
      "screen_name" : "der_ak",
      "indices" : [ 0, 7 ],
      "id_str" : "26962623",
      "id" : 26962623
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 8, 14 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/sJ4VX7S5HI",
      "expanded_url" : "http:\/\/ccca.concordia.ca\/c\/images\/screen\/m\/mars\/mars112.jpg",
      "display_url" : "ccca.concordia.ca\/c\/images\/scree\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "421979038451007488",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1671993938, 8.6860352056 ]
  },
  "id_str" : "421979967174762497",
  "in_reply_to_user_id" : 26962623,
  "text" : "@der_ak @Lobot more like http:\/\/t.co\/sJ4VX7S5HI",
  "id" : 421979967174762497,
  "in_reply_to_status_id" : 421979038451007488,
  "created_at" : "2014-01-11 12:20:38 +0000",
  "in_reply_to_screen_name" : "der_ak",
  "in_reply_to_user_id_str" : "26962623",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1672051335, 8.6860487424 ]
  },
  "id_str" : "421977729027018752",
  "text" : "\u00ABDie Spermaflecken auf meinem T-Shirt sehen aus wie dein Penis.\u00BB \u2014 \u00ABRohrschach!\u00BB",
  "id" : 421977729027018752,
  "created_at" : "2014-01-11 12:11:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 63, 72 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "alpacacontent",
      "indices" : [ 74, 88 ]
    } ],
    "urls" : [ {
      "indices" : [ 37, 59 ],
      "url" : "http:\/\/t.co\/rfVZz4Ru6i",
      "expanded_url" : "http:\/\/nocountryfornewnashville.com\/wp-content\/uploads\/2013\/01\/david-bowie-001.jpeg",
      "display_url" : "nocountryfornewnashville.com\/wp-content\/upl\u2026"
    }, {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/tCx527sfP1",
      "expanded_url" : "http:\/\/justsomething.co\/the-22-sexiest-alpaca-hairstyles\/",
      "display_url" : "justsomething.co\/the-22-sexiest\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1671900179, 8.686073218 ]
  },
  "id_str" : "421969996030693376",
  "text" : "#3 looks just like David Bowie &lt;3 http:\/\/t.co\/rfVZz4Ru6i RT @Senficon: #alpacacontent http:\/\/t.co\/tCx527sfP1",
  "id" : 421969996030693376,
  "created_at" : "2014-01-11 11:41:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1671794564, 8.6860827459 ]
  },
  "id_str" : "421967335420096512",
  "text" : "\u00ABIch hab gar nicht mitbekommen das sie auf mich steht.\u00BB \u2014 \u00ABAlter, sie hat dich massiert und dabei dein Ohr ausgeleckt!\u00BB",
  "id" : 421967335420096512,
  "created_at" : "2014-01-11 11:30:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1672296036, 8.6859614225 ]
  },
  "id_str" : "421775865589268482",
  "text" : "\u00ABIn meiner alten WG waren immer 3 Heilpraktiker und ein Krankenpfleger.\u00BB \u2014 \u00ABWas ist ein Quantenpfleger?!\u00BB",
  "id" : 421775865589268482,
  "created_at" : "2014-01-10 22:49:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722790133, 8.6276605258 ]
  },
  "id_str" : "421701261361438720",
  "text" : "\u00ABMein Anmachspruch am WE wird sein: \u2018Hey Kleines, willst du meinen R\u00FCssel sehen? Ich bin ein haarloses Mammut\u2019.\u00BB \u2013 \u00ABAuch Elefant genannt\u2026\u00BB",
  "id" : 421701261361438720,
  "created_at" : "2014-01-10 17:53:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pedro Danger S\u00E1nchez",
      "screen_name" : "sunside",
      "indices" : [ 0, 8 ],
      "id_str" : "17739510",
      "id" : 17739510
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "421689076614701056",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722790133, 8.6276605258 ]
  },
  "id_str" : "421689383843274752",
  "in_reply_to_user_id" : 17739510,
  "text" : "@sunside sondern high-density lipoprotein.",
  "id" : 421689383843274752,
  "in_reply_to_status_id" : 421689076614701056,
  "created_at" : "2014-01-10 17:05:58 +0000",
  "in_reply_to_screen_name" : "sunside",
  "in_reply_to_user_id_str" : "17739510",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "421671237685751809",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722790133, 8.6276605258 ]
  },
  "id_str" : "421671596634693632",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC totally, works nearly as well as talking dogs (or talking experimental design)",
  "id" : 421671596634693632,
  "in_reply_to_status_id" : 421671237685751809,
  "created_at" : "2014-01-10 15:55:17 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "421670038534234113",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722790133, 8.6276605258 ]
  },
  "id_str" : "421670386980651008",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC thx, so far the procrastination works out just fine ;)",
  "id" : 421670386980651008,
  "in_reply_to_status_id" : 421670038534234113,
  "created_at" : "2014-01-10 15:50:29 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 73 ],
      "url" : "http:\/\/t.co\/WyZFtg4qwo",
      "expanded_url" : "http:\/\/imgur.com\/eCCnsL9",
      "display_url" : "imgur.com\/eCCnsL9"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722790133, 8.6276605258 ]
  },
  "id_str" : "421664421694681088",
  "text" : "On the internet, no one knows you are a god. &lt;3 http:\/\/t.co\/WyZFtg4qwo",
  "id" : 421664421694681088,
  "created_at" : "2014-01-10 15:26:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "D\u00FCsseldorf",
      "indices" : [ 67, 78 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "421661891103313920",
  "text" : "RT @MIWFNRW: Elfen und Gnome statt Lehrb\u00FCcher: Studierende der Uni #D\u00FCsseldorf lernen Seminarstoff per Fantasy-Computerspiel. http:\/\/t.co\/M\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "D\u00FCsseldorf",
        "indices" : [ 54, 65 ]
      } ],
      "urls" : [ {
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/MtZyQunBBD",
        "expanded_url" : "http:\/\/bit.ly\/KahVjr",
        "display_url" : "bit.ly\/KahVjr"
      } ]
    },
    "geo" : { },
    "id_str" : "421660801846358016",
    "text" : "Elfen und Gnome statt Lehrb\u00FCcher: Studierende der Uni #D\u00FCsseldorf lernen Seminarstoff per Fantasy-Computerspiel. http:\/\/t.co\/MtZyQunBBD",
    "id" : 421660801846358016,
    "created_at" : "2014-01-10 15:12:23 +0000",
    "user" : {
      "name" : "MKW_NRW",
      "screen_name" : "MKW_NRW",
      "protected" : false,
      "id_str" : "193328135",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/889386811449126912\/k8Tjmn2A_normal.jpg",
      "id" : 193328135,
      "verified" : false
    }
  },
  "id" : 421661891103313920,
  "created_at" : "2014-01-10 15:16:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722790133, 8.6276605258 ]
  },
  "id_str" : "421642939199397888",
  "text" : "\u00ABArg, es kommen immer mehr Feature-W\u00FCnsche\u2026\u00BB \u2013 \u00ABWenn wir dabei sind: Ich f\u00E4nd es gut wenn der Panda auch kalte Fusion k\u00F6nnte!\u00BB",
  "id" : 421642939199397888,
  "created_at" : "2014-01-10 14:01:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 54 ],
      "url" : "http:\/\/t.co\/GNY9laWwOW",
      "expanded_url" : "http:\/\/i.imgur.com\/nwGDbnI.jpg",
      "display_url" : "i.imgur.com\/nwGDbnI.jpg"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722790133, 8.6276605258 ]
  },
  "id_str" : "421636765615939584",
  "text" : "i put on my robe and wizard hat http:\/\/t.co\/GNY9laWwOW",
  "id" : 421636765615939584,
  "created_at" : "2014-01-10 13:36:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "421632506929381376",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722790133, 8.6276605258 ]
  },
  "id_str" : "421632730984886272",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon du solltest, feedback++",
  "id" : 421632730984886272,
  "in_reply_to_status_id" : 421632506929381376,
  "created_at" : "2014-01-10 13:20:51 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "421612114042978304",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722790133, 8.6276605258 ]
  },
  "id_str" : "421631039971557376",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon schreibst du dem Prof aus den Lecture-Videos eine Dankesmail?",
  "id" : 421631039971557376,
  "in_reply_to_status_id" : 421612114042978304,
  "created_at" : "2014-01-10 13:14:08 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gareth Ware",
      "screen_name" : "musicismyradar",
      "indices" : [ 3, 18 ],
      "id_str" : "19973699",
      "id" : 19973699
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "421629758603276288",
  "text" : "RT @musicismyradar: Oh dear Lord. David Attenborough did an AMA on Reddit and in the middle of it this happened. Best. Thing. EVER. http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/RobSamCreatives\/status\/421256342108520448\/photo\/1",
        "indices" : [ 112, 134 ],
        "url" : "http:\/\/t.co\/4hUTE8yRKh",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BdiaaUdCQAAh3m6.png",
        "id_str" : "421256342116909056",
        "id" : 421256342116909056,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BdiaaUdCQAAh3m6.png",
        "sizes" : [ {
          "h" : 724,
          "resize" : "fit",
          "w" : 869
        }, {
          "h" : 567,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 724,
          "resize" : "fit",
          "w" : 869
        }, {
          "h" : 724,
          "resize" : "fit",
          "w" : 869
        } ],
        "display_url" : "pic.twitter.com\/4hUTE8yRKh"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "421612712322293760",
    "text" : "Oh dear Lord. David Attenborough did an AMA on Reddit and in the middle of it this happened. Best. Thing. EVER. http:\/\/t.co\/4hUTE8yRKh",
    "id" : 421612712322293760,
    "created_at" : "2014-01-10 12:01:18 +0000",
    "user" : {
      "name" : "Gareth Ware",
      "screen_name" : "musicismyradar",
      "protected" : false,
      "id_str" : "19973699",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/691714065274703872\/vtH0Bl21_normal.jpg",
      "id" : 19973699,
      "verified" : false
    }
  },
  "id" : 421629758603276288,
  "created_at" : "2014-01-10 13:09:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/CixVLrCsQt",
      "expanded_url" : "http:\/\/www.polygon.com\/features\/2014\/1\/6\/5223440\/super-columbine-massacre-rpg",
      "display_url" : "polygon.com\/features\/2014\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722790133, 8.6276605258 ]
  },
  "id_str" : "421610383657689088",
  "text" : "\u00ABi, school shooter\u00BB on the ideas behind and fallout of the Super Columbine Massacre RPG http:\/\/t.co\/CixVLrCsQt",
  "id" : 421610383657689088,
  "created_at" : "2014-01-10 11:52:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "421577355539140608",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722790133, 8.6276605258 ]
  },
  "id_str" : "421577938191261696",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer close but no CIGAR? ;)",
  "id" : 421577938191261696,
  "in_reply_to_status_id" : 421577355539140608,
  "created_at" : "2014-01-10 09:43:07 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "421576054935801857",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1724580406, 8.6273805231 ]
  },
  "id_str" : "421576601386889217",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer now with 500% more multiple testing errors? ;)",
  "id" : 421576601386889217,
  "in_reply_to_status_id" : 421576054935801857,
  "created_at" : "2014-01-10 09:37:48 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "421568862929182720",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722790133, 8.6276605258 ]
  },
  "id_str" : "421569090957107200",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer let\u2019s just maintain openSNP for 30 more years and then we can reap the rewards? ;)",
  "id" : 421569090957107200,
  "in_reply_to_status_id" : 421568862929182720,
  "created_at" : "2014-01-10 09:07:58 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "421567461943570433",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722790133, 8.6276605258 ]
  },
  "id_str" : "421568687444086784",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer if it\u2019s any consolation: once we hit ~ age 57 we may be the most famous scientists, &gt; physics &amp; chemistry!",
  "id" : 421568687444086784,
  "in_reply_to_status_id" : 421567461943570433,
  "created_at" : "2014-01-10 09:06:22 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/00juKSZOSy",
      "expanded_url" : "http:\/\/www.sciencemag.org\/content\/331\/6014\/176\/F3.large.jpg",
      "display_url" : "sciencemag.org\/content\/331\/60\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "421567461943570433",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722790133, 8.6276605258 ]
  },
  "id_str" : "421568230415937536",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer here\u2019s the graph (figure F) of the original publication (maybe paywalled) http:\/\/t.co\/00juKSZOSy",
  "id" : 421568230415937536,
  "in_reply_to_status_id" : 421567461943570433,
  "created_at" : "2014-01-10 09:04:33 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "421566243825405952",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722790133, 8.6276605258 ]
  },
  "id_str" : "421567088495710208",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer having just read the book on culturomics project I can ease your mind (and mine): scientist\u2019s fame does peak good bit later.",
  "id" : 421567088495710208,
  "in_reply_to_status_id" : 421566243825405952,
  "created_at" : "2014-01-10 09:00:00 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 68 ],
      "url" : "http:\/\/t.co\/qeG7htK0IT",
      "expanded_url" : "http:\/\/www.foreignpolicy.com\/articles\/2014\/01\/07\/the_stringer_molhem_barakat_reuters_syria#sthash.P4MjG8z8.hmnWs7Xd.dpbs",
      "display_url" : "foreignpolicy.com\/articles\/2014\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.163136, 8.647233 ]
  },
  "id_str" : "421562359623454720",
  "text" : "The Controversial Death of a Teenage Stringer http:\/\/t.co\/qeG7htK0IT",
  "id" : 421562359623454720,
  "created_at" : "2014-01-10 08:41:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.102351096, 8.5441696248 ]
  },
  "id_str" : "421555042530131969",
  "text" : "That weird day where random people congratulate you for not having died in the past 12 months\u2026 uh, thanks?",
  "id" : 421555042530131969,
  "created_at" : "2014-01-10 08:12:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0039680303, 8.3628407959 ]
  },
  "id_str" : "421549834261528576",
  "text" : "\u00ABToday, two wrongs still don\u2019t make a right. But fortunately, too many wrongs do make a rights movement.\u00BB",
  "id" : 421549834261528576,
  "created_at" : "2014-01-10 07:51:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 13, 26 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "421433821360586752",
  "geo" : { },
  "id_str" : "421434184218193920",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch @PhilippBayer okay :D basically: 3 not downwards compatible, virtually all libraries are written for 2. -&gt; Disaster.",
  "id" : 421434184218193920,
  "in_reply_to_status_id" : 421433821360586752,
  "created_at" : "2014-01-10 00:11:54 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 13, 26 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "421433534365310978",
  "geo" : { },
  "id_str" : "421433645023637504",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch @PhilippBayer thanks, read this a while ago :)",
  "id" : 421433645023637504,
  "in_reply_to_status_id" : 421433534365310978,
  "created_at" : "2014-01-10 00:09:45 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 13, 26 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "421433300927143937",
  "geo" : { },
  "id_str" : "421433417646227456",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch @PhilippBayer ack",
  "id" : 421433417646227456,
  "in_reply_to_status_id" : 421433300927143937,
  "created_at" : "2014-01-10 00:08:51 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 13, 26 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "421432858038005761",
  "geo" : { },
  "id_str" : "421433246933843968",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch @PhilippBayer agreed in principle. But my remark was meant to point out why basically no one switches to python3 :)",
  "id" : 421433246933843968,
  "in_reply_to_status_id" : 421432858038005761,
  "created_at" : "2014-01-10 00:08:10 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "421428059112493056",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096912225, 8.2831083782 ]
  },
  "id_str" : "421428820399640576",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch and that's especially true with Python 2.x vs 3.x once your codebase is somewhat established.",
  "id" : 421428820399640576,
  "in_reply_to_status_id" : 421428059112493056,
  "created_at" : "2014-01-09 23:50:35 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "421428059112493056",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097152079, 8.2829519548 ]
  },
  "id_str" : "421428637028843520",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch my point: even w\/o business side you're likely 2 end up with tech debt cause (up2a point) it's easier to maintain than rewrite.",
  "id" : 421428637028843520,
  "in_reply_to_status_id" : 421428059112493056,
  "created_at" : "2014-01-09 23:49:51 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Skellett",
      "screen_name" : "Gurdur",
      "indices" : [ 0, 7 ],
      "id_str" : "125928028",
      "id" : 125928028
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "421426942282174464",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009678774, 8.28300193 ]
  },
  "id_str" : "421427117050822656",
  "in_reply_to_user_id" : 125928028,
  "text" : "@Gurdur thanks though :)",
  "id" : 421427117050822656,
  "in_reply_to_status_id" : 421426942282174464,
  "created_at" : "2014-01-09 23:43:49 +0000",
  "in_reply_to_screen_name" : "Gurdur",
  "in_reply_to_user_id_str" : "125928028",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Skellett",
      "screen_name" : "Gurdur",
      "indices" : [ 0, 7 ],
      "id_str" : "125928028",
      "id" : 125928028
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "421426535334019072",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009678774, 8.28300193 ]
  },
  "id_str" : "421426643044143105",
  "in_reply_to_user_id" : 125928028,
  "text" : "@Gurdur now you actually got the date right ;)",
  "id" : 421426643044143105,
  "in_reply_to_status_id" : 421426535334019072,
  "created_at" : "2014-01-09 23:41:56 +0000",
  "in_reply_to_screen_name" : "Gurdur",
  "in_reply_to_user_id_str" : "125928028",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "421420965026099200",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009678774, 8.28300193 ]
  },
  "id_str" : "421426219511709696",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch guess that depends highly on your definition of value. ;)",
  "id" : 421426219511709696,
  "in_reply_to_status_id" : 421420965026099200,
  "created_at" : "2014-01-09 23:40:15 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Misha Angrist",
      "screen_name" : "MishaAngrist",
      "indices" : [ 3, 16 ],
      "id_str" : "116877838",
      "id" : 116877838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "421423932013821952",
  "text" : "RT @MishaAngrist: 254 separate PMAs for 23andMe? \"completely unworkable and at odds with a risk-based regulatory framework\" http:\/\/t.co\/Pfu\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 106, 128 ],
        "url" : "http:\/\/t.co\/Pfuxr1wzJC",
        "expanded_url" : "http:\/\/www.nature.com\/nbt\/journal\/v32\/n1\/full\/nbt.2805.html?WT.ec_id=NBT-201401",
        "display_url" : "nature.com\/nbt\/journal\/v3\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "421423369716641794",
    "text" : "254 separate PMAs for 23andMe? \"completely unworkable and at odds with a risk-based regulatory framework\" http:\/\/t.co\/Pfuxr1wzJC",
    "id" : 421423369716641794,
    "created_at" : "2014-01-09 23:28:55 +0000",
    "user" : {
      "name" : "Misha Angrist",
      "screen_name" : "MishaAngrist",
      "protected" : false,
      "id_str" : "116877838",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747461459974717441\/GIrZkLT-_normal.jpg",
      "id" : 116877838,
      "verified" : false
    }
  },
  "id" : 421423932013821952,
  "created_at" : "2014-01-09 23:31:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonas",
      "screen_name" : "lsanoj",
      "indices" : [ 0, 7 ],
      "id_str" : "18918915",
      "id" : 18918915
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009678774, 8.28300193 ]
  },
  "id_str" : "421418025192280064",
  "in_reply_to_user_id" : 18918915,
  "text" : "@lsanoj Happy Birthday, wie ist es auf der anderen Seite?",
  "id" : 421418025192280064,
  "created_at" : "2014-01-09 23:07:41 +0000",
  "in_reply_to_screen_name" : "lsanoj",
  "in_reply_to_user_id_str" : "18918915",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 90, 99 ],
      "id_str" : "14861745",
      "id" : 14861745
    }, {
      "name" : "Anne Helm",
      "screen_name" : "SeeroiberJenny",
      "indices" : [ 101, 116 ],
      "id_str" : "145180684",
      "id" : 145180684
    }, {
      "name" : "Jens",
      "screen_name" : "Seipenbusch",
      "indices" : [ 118, 130 ],
      "id_str" : "63738086",
      "id" : 63738086
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "421416562793648128",
  "text" : "\u00ABDer Kompetenz der FAZ k\u00F6nnen die Piraten ja auch ihren eigenen Dreiklang entgegenhalten: @Senficon, @SeeroiberJenny, @Seipenbusch!\u00BB",
  "id" : 421416562793648128,
  "created_at" : "2014-01-09 23:01:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0125038054, 8.2791051221 ]
  },
  "id_str" : "421412777568509953",
  "text" : "\u00ABDie FAZ hat doch auch ihre Dreifaltigkeit was Internetkompetenz angeht: Fefe, Fonsi, Frank Rieger.\u00BB",
  "id" : 421412777568509953,
  "created_at" : "2014-01-09 22:46:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 41 ],
      "url" : "http:\/\/t.co\/CpErXf8HIL",
      "expanded_url" : "http:\/\/www.asofterworld.com\/index.php?id=1055",
      "display_url" : "asofterworld.com\/index.php?id=1\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009678774, 8.28300193 ]
  },
  "id_str" : "421393542683324416",
  "text" : "my favorite insult http:\/\/t.co\/CpErXf8HIL",
  "id" : 421393542683324416,
  "created_at" : "2014-01-09 21:30:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/NmPe0UunBL",
      "expanded_url" : "http:\/\/www.thedailybeast.com\/articles\/2013\/05\/12\/world-war-ii-s-strangest-battle-when-americans-and-germans-fought-together.html",
      "display_url" : "thedailybeast.com\/articles\/2013\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009678774, 8.28300193 ]
  },
  "id_str" : "421386585855504384",
  "text" : "World War II\u2019s Strangest Battle: When Americans and Germans Fought Together http:\/\/t.co\/NmPe0UunBL",
  "id" : 421386585855504384,
  "created_at" : "2014-01-09 21:02:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009678774, 8.28300193 ]
  },
  "id_str" : "421384594718732288",
  "text" : "\u00ABIch h\u00E4tte ja gern ein Andreaskreuz im Wohnzimmer, aber wie meinen Eltern verkaufen?\u00BB \u2013 \u00ABRot-Weiss streichen &amp; Eisenbahnerm\u00FCtze dranh\u00E4ngen?\u00BB",
  "id" : 421384594718732288,
  "created_at" : "2014-01-09 20:54:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009678774, 8.28300193 ]
  },
  "id_str" : "421346582123282432",
  "text" : "In seinen Chatlogs danach suchen nach was f\u00FCr einem Term man in seinem Twitterarchiv suchen wollte\u2026",
  "id" : 421346582123282432,
  "created_at" : "2014-01-09 18:23:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722790133, 8.6276605258 ]
  },
  "id_str" : "421300799839690752",
  "text" : "\u00ABEs ist gleich erst halb 5? Ich f\u00FChle mich als w\u00FCrde ich schon Stunden auf diese Sequenzen starren!\u00BB \u2013 \u00ABDas machst du auch seit ~6h\u2026\u00BB",
  "id" : 421300799839690752,
  "created_at" : "2014-01-09 15:21:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/iHm6GdBoWe",
      "expanded_url" : "http:\/\/www.robg3d.com\/?p=1175",
      "display_url" : "robg3d.com\/?p=1175"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722790133, 8.6276605258 ]
  },
  "id_str" : "421291481555795969",
  "text" : "\u00ABWhy CCP is still using Python 2\u00BB But those reasons apply to basically anyone, even if you\u2019re not working corporate\u2026 http:\/\/t.co\/iHm6GdBoWe",
  "id" : 421291481555795969,
  "created_at" : "2014-01-09 14:44:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/7n7ulZCriL",
      "expanded_url" : "http:\/\/www.plosone.org\/article\/info%3Adoi%2F10.1371%2Fjournal.pone.0083259",
      "display_url" : "plosone.org\/article\/info%3\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722790133, 8.6276605258 ]
  },
  "id_str" : "421284749588824064",
  "text" : "Awesome photos: \u00ABThe Covert World of Fish Biofluorescence\u00BB http:\/\/t.co\/7n7ulZCriL",
  "id" : 421284749588824064,
  "created_at" : "2014-01-09 14:18:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722790133, 8.6276605258 ]
  },
  "id_str" : "421275549139755009",
  "text" : "Losing all hope as even science writers of WIRED still don\u2019t get the idea of linking back to primary sources\u2026 especially for OA articles\u2026",
  "id" : 421275549139755009,
  "created_at" : "2014-01-09 13:41:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 39 ],
      "url" : "http:\/\/t.co\/TC6Nx3yhu2",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=LHRSUEYSs5o",
      "display_url" : "youtube.com\/watch?v=LHRSUE\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "421272747101011968",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722790133, 8.6276605258 ]
  },
  "id_str" : "421273745815531520",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot more like http:\/\/t.co\/TC6Nx3yhu2",
  "id" : 421273745815531520,
  "in_reply_to_status_id" : 421272747101011968,
  "created_at" : "2014-01-09 13:34:22 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722790133, 8.6276605258 ]
  },
  "id_str" : "421271676324970497",
  "text" : "\u00ABAm ersten August hat sie Geburtstag.\u00BB \u2013 \u00ABYay, bekommen wir dann alle Hundekuchen mitgebracht?\u00BB",
  "id" : 421271676324970497,
  "created_at" : "2014-01-09 13:26:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722790133, 8.6276605258 ]
  },
  "id_str" : "421269059532242944",
  "text" : "\u00ABDein Plan ist strippen zu lernen wenn es mit der akademischen Karriere nicht klappt?\u00BB \u2013 \u00ABIch kann es sogar schon.\u00BB \u2013 \u00ABDas wollt ich h\u00F6ren!\u00BB",
  "id" : 421269059532242944,
  "created_at" : "2014-01-09 13:15:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 37 ],
      "url" : "http:\/\/t.co\/X6OLn5zE0k",
      "expanded_url" : "http:\/\/science.howstuffworks.com\/life\/human-biology\/10-ways-to-die3.htm",
      "display_url" : "science.howstuffworks.com\/life\/human-bio\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722790133, 8.6276605258 ]
  },
  "id_str" : "421252201890471936",
  "text" : "Death by Beard http:\/\/t.co\/X6OLn5zE0k",
  "id" : 421252201890471936,
  "created_at" : "2014-01-09 12:08:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722790133, 8.6276605258 ]
  },
  "id_str" : "421241508910866432",
  "text" : "\u00ABBevor ich das Problem l\u00F6sen kann brauche ich einen vierfachen Espresso. Oder muss mich von dem Hund lecken lassen.\u00BB",
  "id" : 421241508910866432,
  "created_at" : "2014-01-09 11:26:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katie Mack",
      "screen_name" : "AstroKatie",
      "indices" : [ 3, 14 ],
      "id_str" : "33773592",
      "id" : 33773592
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "academia",
      "indices" : [ 19, 28 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "421229909508636672",
  "text" : "RT @AstroKatie: In #academia, you get to choose your own hours, just so long as you are sure to select all of them.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "academia",
        "indices" : [ 3, 12 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "421226308866043904",
    "text" : "In #academia, you get to choose your own hours, just so long as you are sure to select all of them.",
    "id" : 421226308866043904,
    "created_at" : "2014-01-09 10:25:52 +0000",
    "user" : {
      "name" : "Katie Mack",
      "screen_name" : "AstroKatie",
      "protected" : false,
      "id_str" : "33773592",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2818477708\/0ef050189a11bb7f9cf56306f5d171bf_normal.png",
      "id" : 33773592,
      "verified" : true
    }
  },
  "id" : 421229909508636672,
  "created_at" : "2014-01-09 10:40:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 8, 30 ],
      "url" : "http:\/\/t.co\/25sI3K7PXH",
      "expanded_url" : "http:\/\/i.imgur.com\/Kz5gdps.gif",
      "display_url" : "i.imgur.com\/Kz5gdps.gif"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722790133, 8.6276605258 ]
  },
  "id_str" : "421229795712983040",
  "text" : "trapped http:\/\/t.co\/25sI3K7PXH",
  "id" : 421229795712983040,
  "created_at" : "2014-01-09 10:39:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/f0n7zFrcSI",
      "expanded_url" : "http:\/\/www.economist.com\/blogs\/economist-explains\/2014\/01\/economist-explains-4",
      "display_url" : "economist.com\/blogs\/economis\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722790133, 8.6276605258 ]
  },
  "id_str" : "421226909624979456",
  "text" : "\u00ABIn parts of Africa, where the gun is seen as a symbol of the ousting of colonial rulers, Kalash is a popular name.\u00BB http:\/\/t.co\/f0n7zFrcSI",
  "id" : 421226909624979456,
  "created_at" : "2014-01-09 10:28:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 122, 132 ],
      "id_str" : "14700783",
      "id" : 14700783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/KTBDDnEpix",
      "expanded_url" : "http:\/\/www.plosone.org\/article\/info%3Adoi%2F10.1371%2Fjournal.pone.0084949",
      "display_url" : "plosone.org\/article\/info%3\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722790133, 8.6276605258 ]
  },
  "id_str" : "421225524288303104",
  "text" : "getting a grip: yet another adaptionist explanation that was wrinkled out with the bath water. http:\/\/t.co\/KTBDDnEpix \/HT @Fischblog",
  "id" : 421225524288303104,
  "created_at" : "2014-01-09 10:22:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 73 ],
      "url" : "http:\/\/t.co\/H08mXiQrOO",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=HOfll06X16c",
      "display_url" : "youtube.com\/watch?v=HOfll0\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722790133, 8.6276605258 ]
  },
  "id_str" : "421220032740597760",
  "text" : "Tech Demo for Pillow Castle's First Person Puzzler http:\/\/t.co\/H08mXiQrOO",
  "id" : 421220032740597760,
  "created_at" : "2014-01-09 10:00:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "421218601899552768",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722790133, 8.6276605258 ]
  },
  "id_str" : "421218941403664384",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer guess that\u2019s too much of a sociopathic god-complex even for my taste. ;)",
  "id" : 421218941403664384,
  "in_reply_to_status_id" : 421218601899552768,
  "created_at" : "2014-01-09 09:56:36 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 126, 139 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722790133, 8.6276605258 ]
  },
  "id_str" : "421215429299040256",
  "text" : "Uh, no jobs (parsing files, fetching data from Fitbit or sending genotypes\u2026) were running for ~6 days on openSNP. Fixed thx 2 @PhilippBayer",
  "id" : 421215429299040256,
  "created_at" : "2014-01-09 09:42:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/tgTC6IYpWd",
      "expanded_url" : "http:\/\/mishaanouk.com\/2014\/01\/08\/tuerke-sein-is-schlimmer-in-deutschland-dank-mal-nach-wie-auf-der-bild-facebookseite-der-respekt-fuer-das-outing-von-thomas-hitzlsperger-in-eine-rassistische-hetzjagd-umschlug\/",
      "display_url" : "mishaanouk.com\/2014\/01\/08\/tue\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722790133, 8.6276605258 ]
  },
  "id_str" : "421209917501214720",
  "text" : "\u00ABSo sieht es im Jahr 2014 in den BILD-Facebookkommentaren aus: Homophobie pfui, Rassismus hui.\u00BB http:\/\/t.co\/tgTC6IYpWd",
  "id" : 421209917501214720,
  "created_at" : "2014-01-09 09:20:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "samantha based clark",
      "screen_name" : "eltonjohn",
      "indices" : [ 100, 110 ],
      "id_str" : "15661851",
      "id" : 15661851
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/B2v12Wu9wQ",
      "expanded_url" : "http:\/\/www.plosone.org\/article\/info%3Adoi%2F10.1371%2Fjournal.pone.0084265",
      "display_url" : "plosone.org\/article\/info%3\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722790133, 8.6276605258 ]
  },
  "id_str" : "421204946357612544",
  "text" : "Two Types of Well Followed Users in the Followership Networks of Twitter http:\/\/t.co\/B2v12Wu9wQ \/cc @eltonjohn",
  "id" : 421204946357612544,
  "created_at" : "2014-01-09 09:00:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "421092627409145859",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0069115032, 8.2825872582 ]
  },
  "id_str" : "421179344149831680",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer Whatever in creation exists without my knowledge exists without my consent.",
  "id" : 421179344149831680,
  "in_reply_to_status_id" : 421092627409145859,
  "created_at" : "2014-01-09 07:19:15 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "421090353706319872",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097347796, 8.2829832193 ]
  },
  "id_str" : "421091456351469568",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer you're using quotation marks, which makes the whole thing unbelievable!",
  "id" : 421091456351469568,
  "in_reply_to_status_id" : 421090353706319872,
  "created_at" : "2014-01-09 01:30:01 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096810595, 8.2830059598 ]
  },
  "id_str" : "421091277590265856",
  "text" : "Neighbor living above just started to vacuum his flat. So awesome, he also never complains when I practice 'Raining Blood' at 3am.",
  "id" : 421091277590265856,
  "created_at" : "2014-01-09 01:29:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096738013, 8.2829983067 ]
  },
  "id_str" : "421087744069468160",
  "text" : "10 Minuten lang die Bettdecke suchen, dann feststellen das man sie die ganze Zeit als Kissen w\u00E4hrend des Lesens verwendet hat\u2026",
  "id" : 421087744069468160,
  "created_at" : "2014-01-09 01:15:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 85, 98 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/eJA1DCMfNn",
      "expanded_url" : "http:\/\/www.japanesebugfights.com\/",
      "display_url" : "japanesebugfights.com"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096587583, 8.283070145 ]
  },
  "id_str" : "421057039272779776",
  "text" : "Last tweet reminds me a bit of Japanese Bug Fights for which the HT probably goes to @PhilippBayer http:\/\/t.co\/eJA1DCMfNn",
  "id" : 421057039272779776,
  "created_at" : "2014-01-08 23:13:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/s8oz1viNQY",
      "expanded_url" : "http:\/\/boingboing.net\/2014\/01\/08\/assassin-bug-covers-itself-wit.html",
      "display_url" : "boingboing.net\/2014\/01\/08\/ass\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096587583, 8.283070145 ]
  },
  "id_str" : "421056834603347968",
  "text" : "Assassin bug covers itself with a meat-shield of its\u00A0victims http:\/\/t.co\/s8oz1viNQY",
  "id" : 421056834603347968,
  "created_at" : "2014-01-08 23:12:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "421052245749149696",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096587583, 8.283070145 ]
  },
  "id_str" : "421052743370162176",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer makes you wonder about cause &amp; effect\u2026",
  "id" : 421052743370162176,
  "in_reply_to_status_id" : 421052245749149696,
  "created_at" : "2014-01-08 22:56:11 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/3SMWHyJo25",
      "expanded_url" : "http:\/\/www.uproxx.com\/filmdrunk\/2014\/01\/cormac-mccarthys-ex-arrested-brandishing-gun-pulled-vagina-dispute-aliens\/#ixzz2pqjCeIO7",
      "display_url" : "uproxx.com\/filmdrunk\/2014\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096587583, 8.283070145 ]
  },
  "id_str" : "421051624359211009",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer I will just leave this link here and you\u2019ll figure out what that means http:\/\/t.co\/3SMWHyJo25",
  "id" : 421051624359211009,
  "created_at" : "2014-01-08 22:51:44 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/rLuqh6c0Wl",
      "expanded_url" : "http:\/\/www.thepsychologist.org.uk\/archive\/archive_home.cfm?volumeID=27&editionID=235&ArticleID=2403",
      "display_url" : "thepsychologist.org.uk\/archive\/archiv\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096587583, 8.283070145 ]
  },
  "id_str" : "421035771723014144",
  "text" : "Looking Back: Interpreting lobotomy \u2013 the patients\u2019 stories http:\/\/t.co\/rLuqh6c0Wl",
  "id" : 421035771723014144,
  "created_at" : "2014-01-08 21:48:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "supergarv",
      "screen_name" : "supergarv",
      "indices" : [ 0, 10 ],
      "id_str" : "14340395",
      "id" : 14340395
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "421034211437711362",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096966575, 8.2830414425 ]
  },
  "id_str" : "421034827224469505",
  "in_reply_to_user_id" : 14340395,
  "text" : "@supergarv die ist in der verlinkten Originalquelle drin. Startet bei 1840 und endet auf 1970 -&gt; 2 bars = 10 Jahre.",
  "id" : 421034827224469505,
  "in_reply_to_status_id" : 421034211437711362,
  "created_at" : "2014-01-08 21:44:59 +0000",
  "in_reply_to_screen_name" : "supergarv",
  "in_reply_to_user_id_str" : "14340395",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 51 ],
      "url" : "http:\/\/t.co\/tdEPq4IxDV",
      "expanded_url" : "http:\/\/flowingdata.com\/2014\/01\/08\/facial-hair-trends-over-time\/",
      "display_url" : "flowingdata.com\/2014\/01\/08\/fac\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096966575, 8.2830414425 ]
  },
  "id_str" : "421033054581567488",
  "text" : "Facial hair trends over time http:\/\/t.co\/tdEPq4IxDV",
  "id" : 421033054581567488,
  "created_at" : "2014-01-08 21:37:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096966575, 8.2830414425 ]
  },
  "id_str" : "421030054756646913",
  "text" : "\u00ABWe\u2019re waiting for a fellow by the name of Dogot.\u00BB Recommending a book about talking dogs. Aka: the obvious cheat code to win my good will.",
  "id" : 421030054756646913,
  "created_at" : "2014-01-08 21:26:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 48, 61 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/t5tVcp5ymr",
      "expanded_url" : "http:\/\/www.reddit.com\/r\/IAmA\/comments\/1un3wn\/we_are_the_pornhub_team_ask_us_anything\/",
      "display_url" : "reddit.com\/r\/IAmA\/comment\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722790133, 8.6276605258 ]
  },
  "id_str" : "420950639376875520",
  "text" : "\u00ABWe are the Pornhub team. Ask Us Anything.\u00BB \/cc @PhilippBayer http:\/\/t.co\/t5tVcp5ymr",
  "id" : 420950639376875520,
  "created_at" : "2014-01-08 16:10:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bob O'Hara",
      "screen_name" : "BobOHara",
      "indices" : [ 3, 12 ],
      "id_str" : "19146944",
      "id" : 19146944
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/M1IDLUcARY",
      "expanded_url" : "http:\/\/www.bik-f.de\/files\/stellenausschreibungen\/ausschreibung_statist-modelling_jan-14.pdf",
      "display_url" : "bik-f.de\/files\/stellena\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "420944517509177345",
  "text" : "RT @BobOHara: Come and work with me! We've got a post-doc position open here in Frankfurt: http:\/\/t.co\/M1IDLUcARY (pdf)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 77, 99 ],
        "url" : "http:\/\/t.co\/M1IDLUcARY",
        "expanded_url" : "http:\/\/www.bik-f.de\/files\/stellenausschreibungen\/ausschreibung_statist-modelling_jan-14.pdf",
        "display_url" : "bik-f.de\/files\/stellena\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "420944231608250369",
    "text" : "Come and work with me! We've got a post-doc position open here in Frankfurt: http:\/\/t.co\/M1IDLUcARY (pdf)",
    "id" : 420944231608250369,
    "created_at" : "2014-01-08 15:45:00 +0000",
    "user" : {
      "name" : "Bob O'Hara",
      "screen_name" : "BobOHara",
      "protected" : false,
      "id_str" : "19146944",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/624292977\/twitterProfilePhoto_normal.jpg",
      "id" : 19146944,
      "verified" : false
    }
  },
  "id" : 420944517509177345,
  "created_at" : "2014-01-08 15:46:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Heidi K Smith-Parker",
      "screen_name" : "HeidiKayDeidi",
      "indices" : [ 3, 17 ],
      "id_str" : "274000727",
      "id" : 274000727
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "420942093738340353",
  "text" : "RT @HeidiKayDeidi: Happy Birthday to Alfred Russel Wallace! Love your beard and the flying frog.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "420941627008376832",
    "text" : "Happy Birthday to Alfred Russel Wallace! Love your beard and the flying frog.",
    "id" : 420941627008376832,
    "created_at" : "2014-01-08 15:34:39 +0000",
    "user" : {
      "name" : "Heidi K Smith-Parker",
      "screen_name" : "HeidiKayDeidi",
      "protected" : false,
      "id_str" : "274000727",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/929843620613562368\/4MFguBcs_normal.jpg",
      "id" : 274000727,
      "verified" : false
    }
  },
  "id" : 420942093738340353,
  "created_at" : "2014-01-08 15:36:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Mims\uD83E\uDD33",
      "screen_name" : "mims",
      "indices" : [ 49, 54 ],
      "id_str" : "1769191",
      "id" : 1769191
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/x23TXi9sJ1",
      "expanded_url" : "http:\/\/www.wired.com\/wiredenterprise\/2014\/01\/odesk\/",
      "display_url" : "wired.com\/wiredenterpris\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722790133, 8.6276605258 ]
  },
  "id_str" : "420934633875046400",
  "text" : "on the internet nobody knows you\u2019re beardless RT @mims: How a Fake Beard Can Get You Hired on the Internet http:\/\/t.co\/x23TXi9sJ1",
  "id" : 420934633875046400,
  "created_at" : "2014-01-08 15:06:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722781994, 8.6276897425 ]
  },
  "id_str" : "420915470834098176",
  "text" : "\u00ABIch hab hier einen Tag nach meinem Geburtstag angefangen und hatte deshalb noch einen Kater.\u00BB \u2014 \u00ABUnd der ist bis heute geblieben!\u00BB",
  "id" : 420915470834098176,
  "created_at" : "2014-01-08 13:50:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172300352, 8.6276463017 ]
  },
  "id_str" : "420908281411158018",
  "text" : "\u00ABUnd was war dein letzter gl\u00FCcklicher Einfall? Nur verlobt zu sein und noch nicht geheiratet zu haben?\u00BB",
  "id" : 420908281411158018,
  "created_at" : "2014-01-08 13:22:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723281961, 8.627612151 ]
  },
  "id_str" : "420905588705742848",
  "text" : "\u00ABWenn da drau\u00DFen freilaufende Monitore grasen w\u00FCrden, wie cool w\u00E4re das?! Echte Bioinformatik!\u00BB",
  "id" : 420905588705742848,
  "created_at" : "2014-01-08 13:11:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 45 ],
      "url" : "http:\/\/t.co\/ARq1eOkdhC",
      "expanded_url" : "http:\/\/instagram.com\/p\/i6GGIBhwvU\/",
      "display_url" : "instagram.com\/p\/i6GGIBhwvU\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723745458, 8.6276945674 ]
  },
  "id_str" : "420893558976307200",
  "text" : "Bugfixing @ Biologicum http:\/\/t.co\/ARq1eOkdhC",
  "id" : 420893558976307200,
  "created_at" : "2014-01-08 12:23:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ed Yong",
      "screen_name" : "edyong209",
      "indices" : [ 3, 13 ],
      "id_str" : "19767193",
      "id" : 19767193
    }, {
      "name" : "Zach Weinersmith",
      "screen_name" : "ZachWeiner",
      "indices" : [ 29, 40 ],
      "id_str" : "20745130",
      "id" : 20745130
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/uuxVwuMjJb",
      "expanded_url" : "https:\/\/medium.com\/p\/8ae20a9d208a",
      "display_url" : "medium.com\/p\/8ae20a9d208a"
    } ]
  },
  "geo" : { },
  "id_str" : "420892730790002688",
  "text" : "RT @edyong209: Brilliant. RT @ZachWeiner: I just published \u201CA Dolphin Hypothesis\u201D https:\/\/t.co\/uuxVwuMjJb",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Zach Weinersmith",
        "screen_name" : "ZachWeiner",
        "indices" : [ 14, 25 ],
        "id_str" : "20745130",
        "id" : 20745130
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 67, 90 ],
        "url" : "https:\/\/t.co\/uuxVwuMjJb",
        "expanded_url" : "https:\/\/medium.com\/p\/8ae20a9d208a",
        "display_url" : "medium.com\/p\/8ae20a9d208a"
      } ]
    },
    "geo" : { },
    "id_str" : "420892243512545280",
    "text" : "Brilliant. RT @ZachWeiner: I just published \u201CA Dolphin Hypothesis\u201D https:\/\/t.co\/uuxVwuMjJb",
    "id" : 420892243512545280,
    "created_at" : "2014-01-08 12:18:25 +0000",
    "user" : {
      "name" : "Ed Yong",
      "screen_name" : "edyong209",
      "protected" : false,
      "id_str" : "19767193",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/926063794912153600\/962ygzzx_normal.jpg",
      "id" : 19767193,
      "verified" : true
    }
  },
  "id" : 420892730790002688,
  "created_at" : "2014-01-08 12:20:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722790133, 8.6276605258 ]
  },
  "id_str" : "420887815191527424",
  "text" : "brain status: too stupid to manually write a valid Newick tree consisting of four taxa\u2026",
  "id" : 420887815191527424,
  "created_at" : "2014-01-08 12:00:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722790133, 8.6276605258 ]
  },
  "id_str" : "420875409866366976",
  "text" : "\u00ABBioinformatik. Unser Motto ist: \u2018Das sollte eigentlich gar nicht vorkommen\u2019\u2026\u00BB",
  "id" : 420875409866366976,
  "created_at" : "2014-01-08 11:11:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/zwpkCAUMY5",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=kGEgY6A7Ric",
      "display_url" : "youtube.com\/watch?v=kGEgY6\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722790133, 8.6276605258 ]
  },
  "id_str" : "420869548171354112",
  "text" : "\u00ABturns out that nothing is fair\u00BB just world fallacy for beginners\u2026 http:\/\/t.co\/zwpkCAUMY5",
  "id" : 420869548171354112,
  "created_at" : "2014-01-08 10:48:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722790133, 8.6276605258 ]
  },
  "id_str" : "420864533826392064",
  "text" : "\u00ABHuh, was machst du im B\u00FCro?!\u00BB \u2013 \u00ABBei mir zuhause sind alle Steckdosen au\u00DFer der f\u00FCr den K\u00FChlschrank kaputt &amp; ich muss meine Devices laden.\u00BB",
  "id" : 420864533826392064,
  "created_at" : "2014-01-08 10:28:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "420856306862260224",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722790133, 8.6276605258 ]
  },
  "id_str" : "420856679434309632",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer at least I will find the time to fix the broken uploads to openSNP :p",
  "id" : 420856679434309632,
  "in_reply_to_status_id" : 420856306862260224,
  "created_at" : "2014-01-08 09:57:06 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "420854022203904001",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722790133, 8.6276605258 ]
  },
  "id_str" : "420855449182044160",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer as even the cafeteria is still doing holidays I might have to read up on agriculture next!",
  "id" : 420855449182044160,
  "in_reply_to_status_id" : 420854022203904001,
  "created_at" : "2014-01-08 09:52:12 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "420854022203904001",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722790133, 8.6276605258 ]
  },
  "id_str" : "420855299499917312",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer yeah, the broken key-based login just bombed us back into the middle ages!",
  "id" : 420855299499917312,
  "in_reply_to_status_id" : 420854022203904001,
  "created_at" : "2014-01-08 09:51:37 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 56 ],
      "url" : "https:\/\/t.co\/nDc321qZ1L",
      "expanded_url" : "https:\/\/24.media.tumblr.com\/852f01861d9d43e437d0af41da4ded23\/tumblr_mqtpw3dZ1v1qc3gvno1_500.jpg",
      "display_url" : "24.media.tumblr.com\/852f01861d9d43\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722790133, 8.6276605258 ]
  },
  "id_str" : "420854981798137857",
  "text" : "who said the job couldn\u2019t be fun https:\/\/t.co\/nDc321qZ1L",
  "id" : 420854981798137857,
  "created_at" : "2014-01-08 09:50:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "420852978723991552",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722790133, 8.6276605258 ]
  },
  "id_str" : "420853767505203200",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer good luck! our ssh system has been \u2018fixed\u2019 and thus stopped working\u2026 so I actually had to go to the office today!",
  "id" : 420853767505203200,
  "in_reply_to_status_id" : 420852978723991552,
  "created_at" : "2014-01-08 09:45:31 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722790133, 8.6276605258 ]
  },
  "id_str" : "420850533944270848",
  "text" : "\u00ABOh, schau mal! Sonnenschein! Weisst du was das heisst?!\u00BB \u2013 \u00ABIch lass die Rollos ja schon runter\u2026\u00BB",
  "id" : 420850533944270848,
  "created_at" : "2014-01-08 09:32:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 46 ],
      "url" : "http:\/\/t.co\/GAfvXuhPZe",
      "expanded_url" : "http:\/\/instagram.com\/p\/i5xMQgBwhs\/",
      "display_url" : "instagram.com\/p\/i5xMQgBwhs\/"
    } ]
  },
  "geo" : { },
  "id_str" : "420847590411091969",
  "text" : "Big Fucking Coffeemaker http:\/\/t.co\/GAfvXuhPZe",
  "id" : 420847590411091969,
  "created_at" : "2014-01-08 09:20:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 38 ],
      "url" : "http:\/\/t.co\/CuzJ0VLDy5",
      "expanded_url" : "http:\/\/i.imgur.com\/9G6CKcE.jpg",
      "display_url" : "i.imgur.com\/9G6CKcE.jpg"
    } ]
  },
  "geo" : { },
  "id_str" : "420841511719555072",
  "text" : "totally forgot\u2026 http:\/\/t.co\/CuzJ0VLDy5",
  "id" : 420841511719555072,
  "created_at" : "2014-01-08 08:56:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 62 ],
      "url" : "http:\/\/t.co\/aaeFVQAWFS",
      "expanded_url" : "http:\/\/www.plosbiology.org\/article\/info%3Adoi%2F10.1371%2Fjournal.pbio.1001745",
      "display_url" : "plosbiology.org\/article\/info%3\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096966575, 8.2830414425 ]
  },
  "id_str" : "420694723184328704",
  "text" : "Best Practices for Scientific Computing http:\/\/t.co\/aaeFVQAWFS",
  "id" : 420694723184328704,
  "created_at" : "2014-01-07 23:13:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 57 ],
      "url" : "http:\/\/t.co\/L4tKnzsWm5",
      "expanded_url" : "http:\/\/www.plosbiology.org\/article\/info%3Adoi%2F10.1371%2Fjournal.pbio.1001744",
      "display_url" : "plosbiology.org\/article\/info%3\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096966575, 8.2830414425 ]
  },
  "id_str" : "420691014270328833",
  "text" : "A Field Guide to Genomics Research http:\/\/t.co\/L4tKnzsWm5",
  "id" : 420691014270328833,
  "created_at" : "2014-01-07 22:58:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 69, 82 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/HhXERB5dQ0",
      "expanded_url" : "http:\/\/www.plosone.org\/article\/info%3Adoi%2F10.1371%2Fjournal.pone.0084540",
      "display_url" : "plosone.org\/article\/info%3\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096966575, 8.2830414425 ]
  },
  "id_str" : "420689657765330944",
  "text" : "Fluctuating Selection Models and Mcdonald-Kreitman Type Analyses \/cc @PhilippBayer http:\/\/t.co\/HhXERB5dQ0",
  "id" : 420689657765330944,
  "created_at" : "2014-01-07 22:53:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/so21tJ8jUz",
      "expanded_url" : "http:\/\/distractify.com\/fun\/humor\/the-most-ridiculously-good-looking-alpaca-hairdos\/",
      "display_url" : "distractify.com\/fun\/humor\/the-\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096966575, 8.2830414425 ]
  },
  "id_str" : "420685728969129984",
  "text" : "First headline I get: \u00ABYou\u2019ve Probably Heard Of The Alpaca, But Most People Don\u2019t Know It's One Sexy Secret\u2026\u00BB http:\/\/t.co\/so21tJ8jUz",
  "id" : 420685728969129984,
  "created_at" : "2014-01-07 22:37:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/gsBZb40TY9",
      "expanded_url" : "http:\/\/www.headlinesagainsthumanity.com\/",
      "display_url" : "headlinesagainsthumanity.com"
    } ]
  },
  "geo" : { },
  "id_str" : "420685079879630848",
  "text" : "\u2018Journalism\u2019 in the 21st century: Headlines Against Humanity http:\/\/t.co\/gsBZb40TY9",
  "id" : 420685079879630848,
  "created_at" : "2014-01-07 22:35:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 72 ],
      "url" : "http:\/\/t.co\/IGA7tKe5bW",
      "expanded_url" : "http:\/\/www.literature.org\/authors\/darwin-charles\/the-voyage-of-the-beagle\/chapter-21.html",
      "display_url" : "literature.org\/authors\/darwin\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "420674456726425600",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096966575, 8.2830414425 ]
  },
  "id_str" : "420674922693029891",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer (and here\u2019s the link to the chapter http:\/\/t.co\/IGA7tKe5bW )",
  "id" : 420674922693029891,
  "in_reply_to_status_id" : 420674456726425600,
  "created_at" : "2014-01-07 21:54:51 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "420674456726425600",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096966575, 8.2830414425 ]
  },
  "id_str" : "420674861787537410",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer yeah, the whole part in the last chapter is even longer. grep for \u201CI thank God, I shall never again visit a slave-country.\u201D ;)",
  "id" : 420674861787537410,
  "in_reply_to_status_id" : 420674456726425600,
  "created_at" : "2014-01-07 21:54:37 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dario Blazirani \u010Cepo",
      "screen_name" : "CepoDario",
      "indices" : [ 3, 13 ],
      "id_str" : "882467556",
      "id" : 882467556
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "420654307076485121",
  "text" : "RT @CepoDario: A good quote I read today: \"Nations are like God. One chooses to believe in them or not.\" From J. R. Lindsey: The Concealmen\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "420649541273022464",
    "text" : "A good quote I read today: \"Nations are like God. One chooses to believe in them or not.\" From J. R. Lindsey: The Concealment of the State",
    "id" : 420649541273022464,
    "created_at" : "2014-01-07 20:14:00 +0000",
    "user" : {
      "name" : "Dario Blazirani \u010Cepo",
      "screen_name" : "CepoDario",
      "protected" : false,
      "id_str" : "882467556",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/931471571675435008\/fnlnk3-w_normal.jpg",
      "id" : 882467556,
      "verified" : false
    }
  },
  "id" : 420654307076485121,
  "created_at" : "2014-01-07 20:32:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/kindle.amazon.com\" rel=\"nofollow\"\u003EKindle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 87, 100 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/YXp53pBm16",
      "expanded_url" : "http:\/\/amzn.com\/k\/qrhtMvy6SfGoGw_cqfazZg",
      "display_url" : "amzn.com\/k\/qrhtMvy6SfGo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "420653747644420096",
  "text" : "Darwin's take on slavery while leaving Brazil, as told in The Voyage of the Beagle \/cc @philippbayer http:\/\/t.co\/YXp53pBm16 And these...",
  "id" : 420653747644420096,
  "created_at" : "2014-01-07 20:30:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Akshat Rathi",
      "screen_name" : "AkshatRathi",
      "indices" : [ 3, 15 ],
      "id_str" : "13766492",
      "id" : 13766492
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/7ZDRIgnVOT",
      "expanded_url" : "http:\/\/www.nytimes.com\/2014\/01\/05\/sunday-review\/why-everyone-seems-to-have-cancer.html?smid=tw-share&_r=1&&pagewanted=all",
      "display_url" : "nytimes.com\/2014\/01\/05\/sun\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "420641746360729600",
  "text" : "RT @AkshatRathi: A good antidote for whenever you hear a cancer cure story: http:\/\/t.co\/7ZDRIgnVOT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 59, 81 ],
        "url" : "http:\/\/t.co\/7ZDRIgnVOT",
        "expanded_url" : "http:\/\/www.nytimes.com\/2014\/01\/05\/sunday-review\/why-everyone-seems-to-have-cancer.html?smid=tw-share&_r=1&&pagewanted=all",
        "display_url" : "nytimes.com\/2014\/01\/05\/sun\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "420549070605012992",
    "text" : "A good antidote for whenever you hear a cancer cure story: http:\/\/t.co\/7ZDRIgnVOT",
    "id" : 420549070605012992,
    "created_at" : "2014-01-07 13:34:46 +0000",
    "user" : {
      "name" : "Akshat Rathi",
      "screen_name" : "AkshatRathi",
      "protected" : false,
      "id_str" : "13766492",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/867091696508653568\/s5mhR4ru_normal.jpg",
      "id" : 13766492,
      "verified" : true
    }
  },
  "id" : 420641746360729600,
  "created_at" : "2014-01-07 19:43:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u24B6\u03BB\u03BB\u03B7\u03BB\u03B5\u03B3\u03B3\u03CD\u03B7\u2122 \u2691\u2605\uD83C\uDF08 \u203A\u2982\u22F9",
      "screen_name" : "eigensinn83",
      "indices" : [ 0, 12 ],
      "id_str" : "44315494",
      "id" : 44315494
    }, {
      "name" : "@F0O0",
      "screen_name" : "F0O0",
      "indices" : [ 13, 18 ],
      "id_str" : "105943845",
      "id" : 105943845
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "420581251880198144",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1038552723, 8.6900714614 ]
  },
  "id_str" : "420617368495456256",
  "in_reply_to_user_id" : 44315494,
  "text" : "@eigensinn83 @F0O0 hab es so verstanden. :)",
  "id" : 420617368495456256,
  "in_reply_to_status_id" : 420581251880198144,
  "created_at" : "2014-01-07 18:06:10 +0000",
  "in_reply_to_screen_name" : "eigensinn83",
  "in_reply_to_user_id_str" : "44315494",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0948812279, 8.751981471 ]
  },
  "id_str" : "420597588459794432",
  "text" : "\u00ABDas Blut war da \u00FCber einen Tag lang drin &amp; riecht nach K\u00E4se. Wenn ich dich das jetzt trinken lasse dann kann ich dich nicht mehr k\u00FCssen!\u00BB",
  "id" : 420597588459794432,
  "created_at" : "2014-01-07 16:47:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CancerGeek",
      "screen_name" : "CancerGeek",
      "indices" : [ 3, 14 ],
      "id_str" : "50200233",
      "id" : 50200233
    }, {
      "name" : "Lisa Gualtieri",
      "screen_name" : "lisagualtieri",
      "indices" : [ 34, 48 ],
      "id_str" : "10748252",
      "id" : 10748252
    }, {
      "name" : "Gilles Frydman",
      "screen_name" : "gfry",
      "indices" : [ 114, 119 ],
      "id_str" : "14104401",
      "id" : 14104401
    }, {
      "name" : "Beth Toner, RN",
      "screen_name" : "BethTonerRN",
      "indices" : [ 123, 135 ],
      "id_str" : "30859805",
      "id" : 30859805
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gfry\/status\/420374726494531586\/photo\/1",
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/qYp4vSQBP8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BdV4lhlCQAA6w4q.jpg",
      "id_str" : "420374726293209088",
      "id" : 420374726293209088,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BdV4lhlCQAA6w4q.jpg",
      "sizes" : [ {
        "h" : 535,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 535,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 535,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 535,
        "resize" : "fit",
        "w" : 500
      } ],
      "display_url" : "pic.twitter.com\/qYp4vSQBP8"
    } ],
    "hashtags" : [ {
      "text" : "hcpt",
      "indices" : [ 81, 86 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "420518587192082432",
  "text" : "RT @CancerGeek: MT: So true--&gt; @lisagualtieri: Your Medical Diagnosis Options #hcpt http:\/\/t.co\/qYp4vSQBP8 via @gfry cc @BethTonerRN",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Lisa Gualtieri",
        "screen_name" : "lisagualtieri",
        "indices" : [ 18, 32 ],
        "id_str" : "10748252",
        "id" : 10748252
      }, {
        "name" : "Gilles Frydman",
        "screen_name" : "gfry",
        "indices" : [ 98, 103 ],
        "id_str" : "14104401",
        "id" : 14104401
      }, {
        "name" : "Beth Toner, RN",
        "screen_name" : "BethTonerRN",
        "indices" : [ 107, 119 ],
        "id_str" : "30859805",
        "id" : 30859805
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/gfry\/status\/420374726494531586\/photo\/1",
        "indices" : [ 71, 93 ],
        "url" : "http:\/\/t.co\/qYp4vSQBP8",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BdV4lhlCQAA6w4q.jpg",
        "id_str" : "420374726293209088",
        "id" : 420374726293209088,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BdV4lhlCQAA6w4q.jpg",
        "sizes" : [ {
          "h" : 535,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 535,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 535,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 535,
          "resize" : "fit",
          "w" : 500
        } ],
        "display_url" : "pic.twitter.com\/qYp4vSQBP8"
      } ],
      "hashtags" : [ {
        "text" : "hcpt",
        "indices" : [ 65, 70 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "420387485135286272",
    "geo" : { },
    "id_str" : "420407674899939328",
    "in_reply_to_user_id" : 10748252,
    "text" : "MT: So true--&gt; @lisagualtieri: Your Medical Diagnosis Options #hcpt http:\/\/t.co\/qYp4vSQBP8 via @gfry cc @BethTonerRN",
    "id" : 420407674899939328,
    "in_reply_to_status_id" : 420387485135286272,
    "created_at" : "2014-01-07 04:12:55 +0000",
    "in_reply_to_screen_name" : "lisagualtieri",
    "in_reply_to_user_id_str" : "10748252",
    "user" : {
      "name" : "CancerGeek",
      "screen_name" : "CancerGeek",
      "protected" : false,
      "id_str" : "50200233",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800438414789214208\/1uIr0nif_normal.jpg",
      "id" : 50200233,
      "verified" : false
    }
  },
  "id" : 420518587192082432,
  "created_at" : "2014-01-07 11:33:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "420509227569147904",
  "text" : "\u00ABDreh dich rum, beiss ins Kissen. Ich mach jetzt reddit auf!\u00BB",
  "id" : 420509227569147904,
  "created_at" : "2014-01-07 10:56:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 62 ],
      "url" : "http:\/\/t.co\/fXbovP0hRE",
      "expanded_url" : "http:\/\/i.imgur.com\/rzxlndt.png",
      "display_url" : "i.imgur.com\/rzxlndt.png"
    } ]
  },
  "geo" : { },
  "id_str" : "420508453401292800",
  "text" : "not only his spider senses are tingling http:\/\/t.co\/fXbovP0hRE",
  "id" : 420508453401292800,
  "created_at" : "2014-01-07 10:53:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/E3AZA2YHA2",
      "expanded_url" : "http:\/\/www.united-academics.org\/magazine\/sex-society\/older-gamers-play-for-different-reasons-than-youngsters\/?utm_source=feedburner&utm_medium=feed&utm_campaign=Feed%3A+ResearchBloggingSocialScienceEnglish+%28Research+Blogging+-+English+-+Social+Science%29",
      "display_url" : "united-academics.org\/magazine\/sex-s\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.094818, 8.751897 ]
  },
  "id_str" : "420506723779362816",
  "text" : "Older Gamers Play For Different Reasons Than Youngsters http:\/\/t.co\/E3AZA2YHA2",
  "id" : 420506723779362816,
  "created_at" : "2014-01-07 10:46:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/VFZz7JHJ8K",
      "expanded_url" : "http:\/\/feeds.boingboing.net\/~r\/boingboing\/iBag\/~3\/A9LYbIz-iaE\/story01.htm",
      "display_url" : "feeds.boingboing.net\/~r\/boingboing\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.01746, 8.316741 ]
  },
  "id_str" : "420505426023960576",
  "text" : "Passive Aggressive Notes' best of\u00A02013 http:\/\/t.co\/VFZz7JHJ8K",
  "id" : 420505426023960576,
  "created_at" : "2014-01-07 10:41:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "@xAndy",
      "screen_name" : "xAndy",
      "indices" : [ 132, 138 ],
      "id_str" : "15198735",
      "id" : 15198735
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/IHcYjomgLE",
      "expanded_url" : "http:\/\/thedogsnobs.com\/category\/sex-toy-or-dog-toy\/",
      "display_url" : "thedogsnobs.com\/category\/sex-t\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.094826349, 8.751906628 ]
  },
  "id_str" : "420496592832303104",
  "text" : "sex toy or dog toy: \u00ABdog toy manufacturers stop using the word \u201Cstimulating\u201D to describe toys for dogs\u00BB  http:\/\/t.co\/IHcYjomgLE \/HT @xAndy",
  "id" : 420496592832303104,
  "created_at" : "2014-01-07 10:06:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonas",
      "screen_name" : "lsanoj",
      "indices" : [ 0, 7 ],
      "id_str" : "18918915",
      "id" : 18918915
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "420488727170154496",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0948306525, 8.7519954011 ]
  },
  "id_str" : "420494121070239744",
  "in_reply_to_user_id" : 18918915,
  "text" : "@lsanoj danke &lt;3",
  "id" : 420494121070239744,
  "in_reply_to_status_id" : 420488727170154496,
  "created_at" : "2014-01-07 09:56:25 +0000",
  "in_reply_to_screen_name" : "lsanoj",
  "in_reply_to_user_id_str" : "18918915",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shane Mcintyre",
      "screen_name" : "ClimateHotNews",
      "indices" : [ 3, 18 ],
      "id_str" : "3332115838",
      "id" : 3332115838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "420468044847398912",
  "text" : "RT @ClimateHotNews: POLAR VORTEX CAUSES 100'S OF INJURIES AS PEOPLE MAKING SNIDE REMARKS ABOUT CLIMATE CHANGE ARE PUNCHED IN FACE http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 110, 132 ],
        "url" : "http:\/\/t.co\/63iR9FakHm",
        "expanded_url" : "http:\/\/ow.ly\/skk5A",
        "display_url" : "ow.ly\/skk5A"
      } ]
    },
    "geo" : { },
    "id_str" : "420363225545596928",
    "text" : "POLAR VORTEX CAUSES 100'S OF INJURIES AS PEOPLE MAKING SNIDE REMARKS ABOUT CLIMATE CHANGE ARE PUNCHED IN FACE http:\/\/t.co\/63iR9FakHm NYer",
    "id" : 420363225545596928,
    "created_at" : "2014-01-07 01:16:17 +0000",
    "user" : {
      "name" : "Climate Nexus",
      "screen_name" : "ClimateNexus",
      "protected" : false,
      "id_str" : "456864723",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/545693884664119297\/mCDJfUgm_normal.jpeg",
      "id" : 456864723,
      "verified" : true
    }
  },
  "id" : 420468044847398912,
  "created_at" : "2014-01-07 08:12:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/HZg0uzFfkl",
      "expanded_url" : "http:\/\/i.imgur.com\/oDNXRwx.jpg",
      "display_url" : "i.imgur.com\/oDNXRwx.jpg"
    } ]
  },
  "geo" : { },
  "id_str" : "420363673870532608",
  "text" : "\u00ABHow?! Why?! Wie benutzt man das?!\u00BB \u2014 \u00ABDas ist ein Spielzeug f\u00FCr Hunde\u2026\u00BB \u2014 \u00ABOh\u2026\u00BB http:\/\/t.co\/HZg0uzFfkl",
  "id" : 420363673870532608,
  "created_at" : "2014-01-07 01:18:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097018694, 8.2831242138 ]
  },
  "id_str" : "420362650959486976",
  "text" : "\u00ABIt may be said there exists no limit to the blindness of interest and selfish habit.\u00BB",
  "id" : 420362650959486976,
  "created_at" : "2014-01-07 01:14:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/SOaRzRGlNS",
      "expanded_url" : "http:\/\/jeremiahstanghini.com\/2014\/01\/06\/facebook-is-a-poor-predictor-of-performance-of-job-applicants\/",
      "display_url" : "jeremiahstanghini.com\/2014\/01\/06\/fac\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096966575, 8.2830414425 ]
  },
  "id_str" : "420330360980144129",
  "text" : "\u00ABFacebook is a Poor Predictor of Performance of Job\u00A0Applicants\u00BB color me surprised\u2026 http:\/\/t.co\/SOaRzRGlNS",
  "id" : 420330360980144129,
  "created_at" : "2014-01-06 23:05:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 46 ],
      "url" : "http:\/\/t.co\/fuqeZuGjoV",
      "expanded_url" : "http:\/\/www.crackajack.de\/2014\/01\/06\/unix-shell-rpg-tutorial\/",
      "display_url" : "crackajack.de\/2014\/01\/06\/uni\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096966575, 8.2830414425 ]
  },
  "id_str" : "420328949731045376",
  "text" : "Unix Shell RPG-Tutorial http:\/\/t.co\/fuqeZuGjoV",
  "id" : 420328949731045376,
  "created_at" : "2014-01-06 23:00:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 45, 58 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/HqULgJja4M",
      "expanded_url" : "http:\/\/www.biostars.org\/p\/90087\/",
      "display_url" : "biostars.org\/p\/90087\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096966575, 8.2830414425 ]
  },
  "id_str" : "420326628611596288",
  "text" : "Think the team would be fun to work with: RT @PhilippBayer: The people around Jalview are hiring Java devs http:\/\/t.co\/HqULgJja4M",
  "id" : 420326628611596288,
  "created_at" : "2014-01-06 22:50:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 43 ],
      "url" : "http:\/\/t.co\/Q36pUUtEfb",
      "expanded_url" : "http:\/\/www.asofterworld.com\/index.php?id=1053",
      "display_url" : "asofterworld.com\/index.php?id=1\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096966575, 8.2830414425 ]
  },
  "id_str" : "420324551768428544",
  "text" : "i know your weakness http:\/\/t.co\/Q36pUUtEfb",
  "id" : 420324551768428544,
  "created_at" : "2014-01-06 22:42:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 0, 10 ],
      "id_str" : "14700783",
      "id" : 14700783
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 11, 24 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 25, 31 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "420323167735799808",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096966575, 8.2830414425 ]
  },
  "id_str" : "420323735892398080",
  "in_reply_to_user_id" : 14700783,
  "text" : "@Fischblog @PhilippBayer @Lobot following that quiz I\u2019d rather start by reciting SJ Gould on IQ-tests\u2026",
  "id" : 420323735892398080,
  "in_reply_to_status_id" : 420323167735799808,
  "created_at" : "2014-01-06 22:39:22 +0000",
  "in_reply_to_screen_name" : "Fischblog",
  "in_reply_to_user_id_str" : "14700783",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gunnar Ries",
      "screen_name" : "amphibol",
      "indices" : [ 3, 12 ],
      "id_str" : "85903538",
      "id" : 85903538
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/M6bBEDlKdC",
      "expanded_url" : "http:\/\/nblo.gs\/SC42L",
      "display_url" : "nblo.gs\/SC42L"
    } ]
  },
  "geo" : { },
  "id_str" : "420323211046572032",
  "text" : "RT @amphibol: Alfred Wegener vs. The Fixists (Continental Drift) - Science History Battle Rap http:\/\/t.co\/M6bBEDlKdC",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.networkedblogs.com\/\" rel=\"nofollow\"\u003ENetworkedBlogs\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 80, 102 ],
        "url" : "http:\/\/t.co\/M6bBEDlKdC",
        "expanded_url" : "http:\/\/nblo.gs\/SC42L",
        "display_url" : "nblo.gs\/SC42L"
      } ]
    },
    "geo" : { },
    "id_str" : "420320900303429632",
    "text" : "Alfred Wegener vs. The Fixists (Continental Drift) - Science History Battle Rap http:\/\/t.co\/M6bBEDlKdC",
    "id" : 420320900303429632,
    "created_at" : "2014-01-06 22:28:06 +0000",
    "user" : {
      "name" : "Gunnar Ries",
      "screen_name" : "amphibol",
      "protected" : false,
      "id_str" : "85903538",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3161978561\/e34078b1950857935b3a8a2c9da3c8b2_normal.jpeg",
      "id" : 85903538,
      "verified" : false
    }
  },
  "id" : 420323211046572032,
  "created_at" : "2014-01-06 22:37:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    }, {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 7, 17 ],
      "id_str" : "14700783",
      "id" : 14700783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "420321832982429697",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096966575, 8.2830414425 ]
  },
  "id_str" : "420322162021769216",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot @Fischblog you\u2019re already annoyed if someone starts to recite a single tweet!",
  "id" : 420322162021769216,
  "in_reply_to_status_id" : 420321832982429697,
  "created_at" : "2014-01-06 22:33:07 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 0, 10 ],
      "id_str" : "14700783",
      "id" : 14700783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "420319810682372096",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096966575, 8.2830414425 ]
  },
  "id_str" : "420319934208819200",
  "in_reply_to_user_id" : 14700783,
  "text" : "@Fischblog die erste Frage war bei mir nicht so dumm das sie deine Reaktion gerechtfertigt h\u00E4tte, deshalb hab ich es getestet. ;)",
  "id" : 420319934208819200,
  "in_reply_to_status_id" : 420319810682372096,
  "created_at" : "2014-01-06 22:24:16 +0000",
  "in_reply_to_screen_name" : "Fischblog",
  "in_reply_to_user_id_str" : "14700783",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 0, 10 ],
      "id_str" : "14700783",
      "id" : 14700783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "420319010652446720",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096966575, 8.2830414425 ]
  },
  "id_str" : "420319427402670080",
  "in_reply_to_user_id" : 14700783,
  "text" : "@Fischblog verdammt, die Fragen-Reihenfolge ist random. :)",
  "id" : 420319427402670080,
  "in_reply_to_status_id" : 420319010652446720,
  "created_at" : "2014-01-06 22:22:15 +0000",
  "in_reply_to_screen_name" : "Fischblog",
  "in_reply_to_user_id_str" : "14700783",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 0, 10 ],
      "id_str" : "14700783",
      "id" : 14700783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "420318669332557825",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096966575, 8.2830414425 ]
  },
  "id_str" : "420318880960368640",
  "in_reply_to_user_id" : 14700783,
  "text" : "@Fischblog link or didn\u2019t happen!",
  "id" : 420318880960368640,
  "in_reply_to_status_id" : 420318669332557825,
  "created_at" : "2014-01-06 22:20:05 +0000",
  "in_reply_to_screen_name" : "Fischblog",
  "in_reply_to_user_id_str" : "14700783",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 3, 12 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Piraten",
      "indices" : [ 130, 138 ]
    }, {
      "text" : "EP14",
      "indices" : [ 139, 144 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/weWy2dm0te",
      "expanded_url" : "http:\/\/tandemnachbruessel.eu\/durchstarten-in-den-wahlkampf\/",
      "display_url" : "tandemnachbruessel.eu\/durchstarten-i\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "420315061283201024",
  "text" : "RT @Senficon: Gebloggt: Warum Demokratieupgrade, Asyl &amp; Urheberrecht die idealen Wahlkampfthemen sind! http:\/\/t.co\/weWy2dm0te #Piraten #EP14",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Piraten",
        "indices" : [ 116, 124 ]
      }, {
        "text" : "EP14",
        "indices" : [ 125, 130 ]
      } ],
      "urls" : [ {
        "indices" : [ 93, 115 ],
        "url" : "http:\/\/t.co\/weWy2dm0te",
        "expanded_url" : "http:\/\/tandemnachbruessel.eu\/durchstarten-in-den-wahlkampf\/",
        "display_url" : "tandemnachbruessel.eu\/durchstarten-i\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "420314094944542720",
    "text" : "Gebloggt: Warum Demokratieupgrade, Asyl &amp; Urheberrecht die idealen Wahlkampfthemen sind! http:\/\/t.co\/weWy2dm0te #Piraten #EP14",
    "id" : 420314094944542720,
    "created_at" : "2014-01-06 22:01:03 +0000",
    "user" : {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "protected" : false,
      "id_str" : "14861745",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/637016870638350336\/QrtPmoul_normal.jpg",
      "id" : 14861745,
      "verified" : true
    }
  },
  "id" : 420315061283201024,
  "created_at" : "2014-01-06 22:04:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/94ymUht6eZ",
      "expanded_url" : "http:\/\/md-protestfotografie.com\/2014\/01\/06\/erfahrungsbericht-einer-spaziergangerin-im-gefahrengebiet\/",
      "display_url" : "md-protestfotografie.com\/2014\/01\/06\/erf\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096966575, 8.2830414425 ]
  },
  "id_str" : "420313103809912832",
  "text" : "Trolling-Level Expert: Erfahrungsbericht einer Spazierg\u00E4ngerin im\u00A0Gefahrengebiet http:\/\/t.co\/94ymUht6eZ",
  "id" : 420313103809912832,
  "created_at" : "2014-01-06 21:57:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "420309130708910080",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096966575, 8.2830414425 ]
  },
  "id_str" : "420309240751095808",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot story of my life!",
  "id" : 420309240751095808,
  "in_reply_to_status_id" : 420309130708910080,
  "created_at" : "2014-01-06 21:41:46 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "420307835822407680",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096966575, 8.2830414425 ]
  },
  "id_str" : "420308321829408768",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot nein, \u00FCber die Katze bin ich gestolpert weil ich Hundefotos bei reddit geschaut habe.",
  "id" : 420308321829408768,
  "in_reply_to_status_id" : 420307835822407680,
  "created_at" : "2014-01-06 21:38:07 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "420305032722915328",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096966575, 8.2830414425 ]
  },
  "id_str" : "420305348625711104",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot fast h\u00E4tte es Katzenblut gegeben weil ich \u00FCber ebendiese gestolpert bin.",
  "id" : 420305348625711104,
  "in_reply_to_status_id" : 420305032722915328,
  "created_at" : "2014-01-06 21:26:18 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "420301652768202752",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096966575, 8.2830414425 ]
  },
  "id_str" : "420304871821430784",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot die Deko habe ich gerade auch ganz ohne Staubsauger mit Johannisbeeren in der K\u00FCche hergestellt\u2026",
  "id" : 420304871821430784,
  "in_reply_to_status_id" : 420301652768202752,
  "created_at" : "2014-01-06 21:24:24 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 41 ],
      "url" : "http:\/\/t.co\/bZjgWq6GA2",
      "expanded_url" : "http:\/\/www.coolstuff.de\/Blut-Energy-Drink",
      "display_url" : "coolstuff.de\/Blut-Energy-Dr\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "420296441584549888",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096966575, 8.2830414425 ]
  },
  "id_str" : "420298679657193472",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot also diese? http:\/\/t.co\/bZjgWq6GA2",
  "id" : 420298679657193472,
  "in_reply_to_status_id" : 420296441584549888,
  "created_at" : "2014-01-06 20:59:48 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096966575, 8.2830414425 ]
  },
  "id_str" : "420282219627044864",
  "text" : "\u00ABDer Paketbote war \u00FCbrigens da.\u00BB \u2013 \u00ABGut, dann haben wir ja nun die Kondome f\u00FCr den Staubsauger. \u00C4h, die Beutel.\u00BB",
  "id" : 420282219627044864,
  "created_at" : "2014-01-06 19:54:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/HFu1TAnSCs",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=IKhHTZ0y2hw",
      "display_url" : "youtube.com\/watch?v=IKhHTZ\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096966575, 8.2830414425 ]
  },
  "id_str" : "420273023305121792",
  "text" : "\u00ABIt may seem strange that I still stay with you, if it's true you're not really the one\u00BB http:\/\/t.co\/HFu1TAnSCs",
  "id" : 420273023305121792,
  "created_at" : "2014-01-06 19:17:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Weber",
      "screen_name" : "scy",
      "indices" : [ 0, 4 ],
      "id_str" : "8308632",
      "id" : 8308632
    }, {
      "name" : "Sebastian Greiner",
      "screen_name" : "Seb666",
      "indices" : [ 5, 12 ],
      "id_str" : "2365333778",
      "id" : 2365333778
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "420267196838084609",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096966575, 8.2830414425 ]
  },
  "id_str" : "420267478858866688",
  "in_reply_to_user_id" : 8308632,
  "text" : "@scy @Seb666 ah, hatte noch nicht so weit gescrollt. Mach das :)",
  "id" : 420267478858866688,
  "in_reply_to_status_id" : 420267196838084609,
  "created_at" : "2014-01-06 18:55:49 +0000",
  "in_reply_to_screen_name" : "scy",
  "in_reply_to_user_id_str" : "8308632",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Weber",
      "screen_name" : "scy",
      "indices" : [ 0, 4 ],
      "id_str" : "8308632",
      "id" : 8308632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "420265892145278976",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096966575, 8.2830414425 ]
  },
  "id_str" : "420266907926028289",
  "in_reply_to_user_id" : 8308632,
  "text" : "@scy sag bescheid wenn man helfen kann, dann versuch ich es irgendwo unterzubringen.",
  "id" : 420266907926028289,
  "in_reply_to_status_id" : 420265892145278976,
  "created_at" : "2014-01-06 18:53:33 +0000",
  "in_reply_to_screen_name" : "scy",
  "in_reply_to_user_id_str" : "8308632",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096966575, 8.2830414425 ]
  },
  "id_str" : "420260702415515648",
  "text" : "\u00ABWieso fiept der Hund so?\u00BB \u2013 \u00ABWeil er Angst vor Verkehr hat.\u00BB \u2013 \u00ABAber der hat uns doch gerade gar nicht zugeschaut?\u00BB",
  "id" : 420260702415515648,
  "created_at" : "2014-01-06 18:28:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096966575, 8.2830414425 ]
  },
  "id_str" : "420221277795012608",
  "text" : "\u00ABWieso schaust du so traurig?\u00BB \u2013 \u00ABIch will mit dir schlafen\u2026\u00BB",
  "id" : 420221277795012608,
  "created_at" : "2014-01-06 15:52:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/420181309664002048\/photo\/1",
      "indices" : [ 30, 52 ],
      "url" : "http:\/\/t.co\/kpyH83kUva",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BdTIrLvIQAAmjTZ.jpg",
      "id_str" : "420181309462691840",
      "id" : 420181309462691840,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BdTIrLvIQAAmjTZ.jpg",
      "sizes" : [ {
        "h" : 583,
        "resize" : "fit",
        "w" : 853
      }, {
        "h" : 465,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 583,
        "resize" : "fit",
        "w" : 853
      }, {
        "h" : 583,
        "resize" : "fit",
        "w" : 853
      } ],
      "display_url" : "pic.twitter.com\/kpyH83kUva"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 7, 29 ],
      "url" : "http:\/\/t.co\/kKbN6aFJeS",
      "expanded_url" : "http:\/\/i.imgur.com\/lUHyr.jpg",
      "display_url" : "i.imgur.com\/lUHyr.jpg"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00967, 8.283058 ]
  },
  "id_str" : "420181309664002048",
  "text" : "squirt http:\/\/t.co\/kKbN6aFJeS http:\/\/t.co\/kpyH83kUva",
  "id" : 420181309664002048,
  "created_at" : "2014-01-06 13:13:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "420154067537891328",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096375885, 8.2829882988 ]
  },
  "id_str" : "420154637661257728",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon das sind nur 8h, die 24h sind f\u00FCr sexual activities in general und Waschen.",
  "id" : 420154637661257728,
  "in_reply_to_status_id" : 420154067537891328,
  "created_at" : "2014-01-06 11:27:26 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/3gq827Lf33",
      "expanded_url" : "http:\/\/imgur.com\/Rs05x0s",
      "display_url" : "imgur.com\/Rs05x0s"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096746943, 8.2830482657 ]
  },
  "id_str" : "420152294370725888",
  "text" : "Always suspected that our games of Munchkin were lacking some basic cards http:\/\/t.co\/3gq827Lf33",
  "id" : 420152294370725888,
  "created_at" : "2014-01-06 11:18:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 68 ],
      "url" : "http:\/\/t.co\/cpV0RW8AeF",
      "expanded_url" : "http:\/\/bps-research-digest.blogspot.de\/2014\/01\/some-bisexual-men-are-aroused-by-women.html?utm_source=feedburner&utm_medium=feed&utm_campaign=Feed:+BpsResearchDigest+(BPS+Research+Digest",
      "display_url" : "bps-research-digest.blogspot.de\/2014\/01\/some-b\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096966575, 8.2830414425 ]
  },
  "id_str" : "420149081634512897",
  "text" : "Male bisexual arousal: A matter of curiosity? http:\/\/t.co\/cpV0RW8AeF)",
  "id" : 420149081634512897,
  "created_at" : "2014-01-06 11:05:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096966575, 8.2830414425 ]
  },
  "id_str" : "420143463121039360",
  "text" : "On a positive note: Der Parteitag war so wenig Spass, endlich konnte ich mal meine baseline mouth, gut &amp; genital microbiomes samplen.",
  "id" : 420143463121039360,
  "created_at" : "2014-01-06 10:43:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "420014056200613888",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096966575, 8.2830414425 ]
  },
  "id_str" : "420015486425137152",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer [] magic [x] more magic",
  "id" : 420015486425137152,
  "in_reply_to_status_id" : 420014056200613888,
  "created_at" : "2014-01-06 02:14:30 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 97, 110 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/aNHyayQccK",
      "expanded_url" : "http:\/\/www.plosone.org\/article\/info%3Adoi%2F10.1371%2Fjournal.pone.0084655",
      "display_url" : "plosone.org\/article\/info%3\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096966575, 8.2830414425 ]
  },
  "id_str" : "420013701471539200",
  "text" : "An Image Encryption Algorithm Utilizing Julia Sets and Hilbert Curves http:\/\/t.co\/aNHyayQccK \/cc @PhilippBayer",
  "id" : 420013701471539200,
  "created_at" : "2014-01-06 02:07:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096966575, 8.2830414425 ]
  },
  "id_str" : "420003186091765760",
  "text" : "\u00ABIch kann gar nicht schlafen!\u00BB \u2013 \u00ABDann lies doch noch ein paar Texte f\u00FCr deine Pr\u00FCfung?\u00BB \u2013 \u00ABOh, auf einmal werd ich ganz m\u00FCde\u2026\u00BB",
  "id" : 420003186091765760,
  "created_at" : "2014-01-06 01:25:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "419975886301974528",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096966575, 8.2830414425 ]
  },
  "id_str" : "419976108621443072",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer yay, thanks! :)",
  "id" : 419976108621443072,
  "in_reply_to_status_id" : 419975886301974528,
  "created_at" : "2014-01-05 23:38:01 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 64 ],
      "url" : "http:\/\/t.co\/Zm6zqTDALh",
      "expanded_url" : "http:\/\/questioning-answers.blogspot.de\/2014\/01\/how-many-steps-day-should-i-be-walking.html",
      "display_url" : "questioning-answers.blogspot.de\/2014\/01\/how-ma\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096966575, 8.2830414425 ]
  },
  "id_str" : "419973760989794304",
  "text" : "How many steps a day should I be walking? http:\/\/t.co\/Zm6zqTDALh",
  "id" : 419973760989794304,
  "created_at" : "2014-01-05 23:28:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zombie Bug Girl",
      "screen_name" : "bug_girl",
      "indices" : [ 3, 12 ],
      "id_str" : "2335958610",
      "id" : 2335958610
    }, {
      "name" : "Ted MacRae",
      "screen_name" : "tcmacrae",
      "indices" : [ 51, 60 ],
      "id_str" : "19806974",
      "id" : 19806974
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "419971853097398272",
  "text" : "RT @bug_girl: Best out of context tweet of day: MT @tcmacrae: Best to pull genitalia when specimens are fresh",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Ted MacRae",
        "screen_name" : "tcmacrae",
        "indices" : [ 37, 46 ],
        "id_str" : "19806974",
        "id" : 19806974
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "419970695461109760",
    "text" : "Best out of context tweet of day: MT @tcmacrae: Best to pull genitalia when specimens are fresh",
    "id" : 419970695461109760,
    "created_at" : "2014-01-05 23:16:31 +0000",
    "user" : {
      "name" : "Gwen Pearson\uD83D\uDC1C\uD83D\uDC1B",
      "screen_name" : "bug_gwen",
      "protected" : false,
      "id_str" : "19563103",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/842443534779207681\/BFGaXLCD_normal.jpg",
      "id" : 19563103,
      "verified" : true
    }
  },
  "id" : 419971853097398272,
  "created_at" : "2014-01-05 23:21:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "419960044629667840",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096545775, 8.28301833 ]
  },
  "id_str" : "419961290854236161",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer running an experiment for 20 bucks is fair enough :)",
  "id" : 419961290854236161,
  "in_reply_to_status_id" : 419960044629667840,
  "created_at" : "2014-01-05 22:39:08 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "419959020657467392",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096545775, 8.28301833 ]
  },
  "id_str" : "419959860726603776",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer so we lost all of our profits, but that\u2019s okay :)",
  "id" : 419959860726603776,
  "in_reply_to_status_id" : 419959020657467392,
  "created_at" : "2014-01-05 22:33:27 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Wenz",
      "screen_name" : "sparta644",
      "indices" : [ 0, 10 ],
      "id_str" : "17988190",
      "id" : 17988190
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 33, 42 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "419952055730847744",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096545775, 8.28301833 ]
  },
  "id_str" : "419952375227768832",
  "in_reply_to_user_id" : 17988190,
  "text" : "@sparta644 ich glaube mich &amp; @Senficon simultan werden weder Hund noch Lama tragen k\u00F6nnen. Aber so k\u00F6nnen wir die Last aufteilen.",
  "id" : 419952375227768832,
  "in_reply_to_status_id" : 419952055730847744,
  "created_at" : "2014-01-05 22:03:43 +0000",
  "in_reply_to_screen_name" : "sparta644",
  "in_reply_to_user_id_str" : "17988190",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Wenz",
      "screen_name" : "sparta644",
      "indices" : [ 0, 10 ],
      "id_str" : "17988190",
      "id" : 17988190
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/8FqTgwSiOt",
      "expanded_url" : "http:\/\/i1159.photobucket.com\/albums\/p634\/electricpickles12\/tumblr_m6tfczWU8P1qe8r5ro3_250-1.gif",
      "display_url" : "i1159.photobucket.com\/albums\/p634\/el\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "419942597197836288",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096758758, 8.2830072719 ]
  },
  "id_str" : "419943005957943297",
  "in_reply_to_user_id" : 17988190,
  "text" : "@sparta644 und deshalb bekomme ich das Lama und den Hund. Dann kann ich auf ihm nach Hause reiten nach dem trinken. http:\/\/t.co\/8FqTgwSiOt",
  "id" : 419943005957943297,
  "in_reply_to_status_id" : 419942597197836288,
  "created_at" : "2014-01-05 21:26:29 +0000",
  "in_reply_to_screen_name" : "sparta644",
  "in_reply_to_user_id_str" : "17988190",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    }, {
      "name" : "Peter Wenz",
      "screen_name" : "sparta644",
      "indices" : [ 49, 59 ],
      "id_str" : "17988190",
      "id" : 17988190
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "419940748176281600",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096323947, 8.2830209378 ]
  },
  "id_str" : "419940998278823936",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot in dem Fall nehme ich den Gleichstand und @sparta644 ist Gewinn und gibt mir den Hund. Win-Win-Win!",
  "id" : 419940998278823936,
  "in_reply_to_status_id" : 419940748176281600,
  "created_at" : "2014-01-05 21:18:30 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Wenz",
      "screen_name" : "sparta644",
      "indices" : [ 0, 10 ],
      "id_str" : "17988190",
      "id" : 17988190
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "419940119765069824",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096778931, 8.2830870641 ]
  },
  "id_str" : "419940424942645249",
  "in_reply_to_user_id" : 17988190,
  "text" : "@sparta644 lass uns ein LimeSurvey daf\u00FCr verwenden und danach einen Parteitag befragen. ;)",
  "id" : 419940424942645249,
  "in_reply_to_status_id" : 419940119765069824,
  "created_at" : "2014-01-05 21:16:14 +0000",
  "in_reply_to_screen_name" : "sparta644",
  "in_reply_to_user_id_str" : "17988190",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 36 ],
      "url" : "http:\/\/t.co\/Hq2t9p6hlu",
      "expanded_url" : "http:\/\/www.phdcomics.com\/comics.php?f=1670",
      "display_url" : "phdcomics.com\/comics.php?f=1\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096545775, 8.28301833 ]
  },
  "id_str" : "419930290455592960",
  "text" : "those choices http:\/\/t.co\/Hq2t9p6hlu",
  "id" : 419930290455592960,
  "created_at" : "2014-01-05 20:35:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Wenz",
      "screen_name" : "sparta644",
      "indices" : [ 0, 10 ],
      "id_str" : "17988190",
      "id" : 17988190
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "419929038153867265",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096545775, 8.28301833 ]
  },
  "id_str" : "419929616972001281",
  "in_reply_to_user_id" : 17988190,
  "text" : "@sparta644 vielen Dank f\u00FCrs fahren und gemeinsames Ranten. Es war der spassigere Teil des Wochenendes.",
  "id" : 419929616972001281,
  "in_reply_to_status_id" : 419929038153867265,
  "created_at" : "2014-01-05 20:33:17 +0000",
  "in_reply_to_screen_name" : "sparta644",
  "in_reply_to_user_id_str" : "17988190",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "419926560305459200",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096545775, 8.28301833 ]
  },
  "id_str" : "419926759447207936",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot ich bin so stolz auf deine wachsenden Bestimmungsskills &lt;3",
  "id" : 419926759447207936,
  "in_reply_to_status_id" : 419926560305459200,
  "created_at" : "2014-01-05 20:21:55 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/BwdC9QB26x",
      "expanded_url" : "http:\/\/i.imgur.com\/f1tWLkh.jpg",
      "display_url" : "i.imgur.com\/f1tWLkh.jpg"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096545775, 8.28301833 ]
  },
  "id_str" : "419924977551671296",
  "text" : "\u00ABOh, suchst du schon ein H\u00FCndchen aus? \u2026 Das ist ja gar kein H\u00FCndchen! Ohne Brille sah es wie eine Dogge aus!\u00BB http:\/\/t.co\/BwdC9QB26x",
  "id" : 419924977551671296,
  "created_at" : "2014-01-05 20:14:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.2288950608, 8.249459127 ]
  },
  "id_str" : "419913838746939392",
  "text" : "\u00ABJetzt wo meine Stimmabgabe ein \u00FCberdurchschnittliches Gewicht hatte erwarte ich aber auch einen \u00FCberdurchschnittlich gro\u00DFen Hund!\u00BB",
  "id" : 419913838746939392,
  "created_at" : "2014-01-05 19:30:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 38 ],
      "url" : "http:\/\/t.co\/uUjNCeHIoh",
      "expanded_url" : "http:\/\/24.media.tumblr.com\/aea3e7148d6d37eee15a1298c301fe58\/tumblr_mgjrojBC6F1righ6xo3_250.gif",
      "display_url" : "24.media.tumblr.com\/aea3e7148d6d37\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "419872968605700097",
  "text" : "one step closer http:\/\/t.co\/uUjNCeHIoh",
  "id" : 419872968605700097,
  "created_at" : "2014-01-05 16:48:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "419826974484602880",
  "text" : "In den Fluren reden sie von \u2018Medienkompetenz lehren\u2019\u2026 W\u00E4hrend ~80% der Versammlung daf\u00FCr sind Antr\u00E4ge abzustimmen die nur 50% gelesen haben\u2026",
  "id" : 419826974484602880,
  "created_at" : "2014-01-05 13:45:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bpt141",
      "indices" : [ 68, 75 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "419810065215127552",
  "text" : "F\u00FCr die weniger Bibelfesten: Das entspricht auch ca 2 1\/2 Saarland. #bpt141",
  "id" : 419810065215127552,
  "created_at" : "2014-01-05 12:38:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bpt141",
      "indices" : [ 131, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "419809713807966208",
  "text" : "Fun fact: Der Programmantrag WP004 enth\u00E4lt ~ so viele W\u00F6rter wie die Bibel von Genesis 1:1 aus bis Abraham seinen Sohn t\u00F6ten will. #bpt141",
  "id" : 419809713807966208,
  "created_at" : "2014-01-05 12:36:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "419805976863453184",
  "text" : "\u00ABWenn ich Parteimitglied w\u00E4re w\u00FCrde ich mich ja ans Mikro stellen und den Unfug den er da redet kommentieren\u2026\u00BB",
  "id" : 419805976863453184,
  "created_at" : "2014-01-05 12:21:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 38 ],
      "url" : "http:\/\/t.co\/iy0lYOMJLS",
      "expanded_url" : "http:\/\/imgur.com\/cfUpxvX",
      "display_url" : "imgur.com\/cfUpxvX"
    } ]
  },
  "geo" : { },
  "id_str" : "419797376317263872",
  "text" : "think about it! http:\/\/t.co\/iy0lYOMJLS",
  "id" : 419797376317263872,
  "created_at" : "2014-01-05 11:47:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 54 ],
      "url" : "http:\/\/t.co\/0AgLQ0rKEz",
      "expanded_url" : "http:\/\/i.imgur.com\/hf8dVfm.gif",
      "display_url" : "i.imgur.com\/hf8dVfm.gif"
    } ]
  },
  "geo" : { },
  "id_str" : "419789273605611520",
  "text" : "Es gibt kein schlechtes Wetter\u2026 http:\/\/t.co\/0AgLQ0rKEz",
  "id" : 419789273605611520,
  "created_at" : "2014-01-05 11:15:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 56 ],
      "url" : "http:\/\/t.co\/muKEwRjRhb",
      "expanded_url" : "http:\/\/i.imgur.com\/VIfp3Ai.gif",
      "display_url" : "i.imgur.com\/VIfp3Ai.gif"
    } ]
  },
  "geo" : { },
  "id_str" : "419767947826323457",
  "text" : "how i got out of bed this morning http:\/\/t.co\/muKEwRjRhb",
  "id" : 419767947826323457,
  "created_at" : "2014-01-05 09:50:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 35 ],
      "url" : "http:\/\/t.co\/Q3dFGhahUA",
      "expanded_url" : "http:\/\/cdn.iwastesomuchtime.com\/142014005531.gif",
      "display_url" : "cdn.iwastesomuchtime.com\/142014005531.g\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "419752531867492352",
  "text" : "good morning http:\/\/t.co\/Q3dFGhahUA",
  "id" : 419752531867492352,
  "created_at" : "2014-01-05 08:49:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 77 ],
      "url" : "http:\/\/t.co\/zAwkMUBJ99",
      "expanded_url" : "http:\/\/www.plosone.org\/article\/info%3Adoi%2F10.1371%2Fjournal.pone.0084475",
      "display_url" : "plosone.org\/article\/info%3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "419747448245223424",
  "text" : "Mining Rare Associations between Biological Ontologies http:\/\/t.co\/zAwkMUBJ99",
  "id" : 419747448245223424,
  "created_at" : "2014-01-05 08:29:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.4909403645, 7.234045308 ]
  },
  "id_str" : "419742896292888576",
  "text" : "\u00ABDuschen?! N\u00F6, hier ist doch Parteitag und nicht gamescom!\u00BB",
  "id" : 419742896292888576,
  "created_at" : "2014-01-05 08:11:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 65 ],
      "url" : "http:\/\/t.co\/OqJpF5poiI",
      "expanded_url" : "http:\/\/i.imgur.com\/7Hnf9SJ.gif",
      "display_url" : "i.imgur.com\/7Hnf9SJ.gif"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.4813573024, 7.2239996869 ]
  },
  "id_str" : "419646355569926144",
  "text" : "now: me, trying to sneak into the bunk bed http:\/\/t.co\/OqJpF5poiI",
  "id" : 419646355569926144,
  "created_at" : "2014-01-05 01:47:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Razib Khan",
      "screen_name" : "razibkhan",
      "indices" : [ 3, 13 ],
      "id_str" : "35304791",
      "id" : 35304791
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "419644880919728128",
  "text" : "RT @razibkhan: greek surprises. but probably due to large distance from everywhere... Lexical Distance Among the Languages of Europe http:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/gkYX9nmMvj",
        "expanded_url" : "http:\/\/elms.wordpress.com\/2008\/03\/04\/lexical-distance-among-languages-of-europe\/",
        "display_url" : "elms.wordpress.com\/2008\/03\/04\/lex\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "419644311244771329",
    "text" : "greek surprises. but probably due to large distance from everywhere... Lexical Distance Among the Languages of Europe http:\/\/t.co\/gkYX9nmMvj",
    "id" : 419644311244771329,
    "created_at" : "2014-01-05 01:39:35 +0000",
    "user" : {
      "name" : "Razib Khan",
      "screen_name" : "razibkhan",
      "protected" : false,
      "id_str" : "35304791",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/890083843385958400\/YKPy0Uup_normal.jpg",
      "id" : 35304791,
      "verified" : true
    }
  },
  "id" : 419644880919728128,
  "created_at" : "2014-01-05 01:41:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/419611024388407296\/photo\/1",
      "indices" : [ 50, 72 ],
      "url" : "http:\/\/t.co\/ObwagzevtJ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BdLCAN4CcAAEnSb.jpg",
      "id_str" : "419611024279367680",
      "id" : 419611024279367680,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BdLCAN4CcAAEnSb.jpg",
      "sizes" : [ {
        "h" : 203,
        "resize" : "fit",
        "w" : 360
      }, {
        "h" : 203,
        "resize" : "fit",
        "w" : 360
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 203,
        "resize" : "fit",
        "w" : 360
      }, {
        "h" : 203,
        "resize" : "fit",
        "w" : 360
      } ],
      "display_url" : "pic.twitter.com\/ObwagzevtJ"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 49 ],
      "url" : "http:\/\/t.co\/YIiOfCedad",
      "expanded_url" : "http:\/\/i.imgur.com\/wLnMfSV.gif",
      "display_url" : "i.imgur.com\/wLnMfSV.gif"
    } ]
  },
  "geo" : { },
  "id_str" : "419611024388407296",
  "text" : "What I will need on Monday http:\/\/t.co\/YIiOfCedad http:\/\/t.co\/ObwagzevtJ",
  "id" : 419611024388407296,
  "created_at" : "2014-01-04 23:27:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 43 ],
      "url" : "https:\/\/t.co\/tLxknSo9Dv",
      "expanded_url" : "https:\/\/imgur.com\/a\/deovZ?gallery",
      "display_url" : "imgur.com\/a\/deovZ?gallery"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.484729, 7.226746 ]
  },
  "id_str" : "419608941103185920",
  "text" : "The Selfie Olympics https:\/\/t.co\/tLxknSo9Dv",
  "id" : 419608941103185920,
  "created_at" : "2014-01-04 23:19:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.4843190347, 7.2158552257 ]
  },
  "id_str" : "419597725253267456",
  "text" : "\u00ABStop to speak about boring stuff in German. Do it in English, so at least we know it\u2019s boring!\u00BB",
  "id" : 419597725253267456,
  "created_at" : "2014-01-04 22:34:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.4847936357, 7.2158369184 ]
  },
  "id_str" : "419594889861799936",
  "text" : "\u00ABHe has lots of excellent qualities!\u00BB \u2014 \u00ABYes, he starts bashing people right away!\u00BB",
  "id" : 419594889861799936,
  "created_at" : "2014-01-04 22:23:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.48924833, 7.2329357618 ]
  },
  "id_str" : "419563737943928832",
  "text" : "\u00ABOh, c\u2019mon! The restaurant is named just like Hitler\u2019s dog, how could you possibly forget it\u2019s name in less than 5 minutes?!\u00BB",
  "id" : 419563737943928832,
  "created_at" : "2014-01-04 20:19:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "419544005211222016",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.4909482382, 7.2340248635 ]
  },
  "id_str" : "419544420548349952",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot das w\u00E4re so sch\u00F6n! Hund und botfly maggots vereint. &lt;3",
  "id" : 419544420548349952,
  "in_reply_to_status_id" : 419544005211222016,
  "created_at" : "2014-01-04 19:02:39 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 10, 16 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "419540800251645952",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.4909436945, 7.2340505458 ]
  },
  "id_str" : "419541319875575808",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich @Lobot den M\u00F6ter f\u00E4nde ich so viel toller als einen Humanzee!",
  "id" : 419541319875575808,
  "in_reply_to_status_id" : 419540800251645952,
  "created_at" : "2014-01-04 18:50:20 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "419540321387556865",
  "geo" : { },
  "id_str" : "419540492993691648",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot mein Bauchspeck l\u00E4sst sich dehnen, das weisst du doch!",
  "id" : 419540492993691648,
  "in_reply_to_status_id" : 419540321387556865,
  "created_at" : "2014-01-04 18:47:02 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 10, 16 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "419539799817854977",
  "geo" : { },
  "id_str" : "419540290605973504",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich @Lobot kann ich einen Welpen unter der Haut ausbr\u00FCten?",
  "id" : 419540290605973504,
  "in_reply_to_status_id" : 419539799817854977,
  "created_at" : "2014-01-04 18:46:14 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "419539469042077696",
  "geo" : { },
  "id_str" : "419540055343263744",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot kommt drauf an: Einen Welpen oder eine ganze Box?",
  "id" : 419540055343263744,
  "in_reply_to_status_id" : 419539469042077696,
  "created_at" : "2014-01-04 18:45:18 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.4909659, 7.23396279 ]
  },
  "id_str" : "419533524493156352",
  "text" : "Das lang erwartete neue Album der Piratenpartei: Schreinese Democracy\u2026",
  "id" : 419533524493156352,
  "created_at" : "2014-01-04 18:19:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 49 ],
      "url" : "http:\/\/t.co\/kbRNVgT9xH",
      "expanded_url" : "http:\/\/i.imgur.com\/0JtIN8I.gif",
      "display_url" : "i.imgur.com\/0JtIN8I.gif"
    } ]
  },
  "geo" : { },
  "id_str" : "419530984372305920",
  "text" : "look who just fell asleep! http:\/\/t.co\/kbRNVgT9xH",
  "id" : 419530984372305920,
  "created_at" : "2014-01-04 18:09:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/SdDf3q5mkN",
      "expanded_url" : "http:\/\/i.imgur.com\/yDzeEHY.png",
      "display_url" : "i.imgur.com\/yDzeEHY.png"
    } ]
  },
  "geo" : { },
  "id_str" : "419527847892762624",
  "text" : "Was einen Hund bekommen angeht muss ich glaube ich noch mal nachverhandeln. http:\/\/t.co\/SdDf3q5mkN",
  "id" : 419527847892762624,
  "created_at" : "2014-01-04 17:56:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.4894256651, 7.2329572521 ]
  },
  "id_str" : "419520085683097600",
  "text" : "\u00ABDu k\u00F6nntest mich auch als deine Mutter ausgeben, dann h\u00E4ttest du wenigstens eine coole Mama!\u00BB\u2014\u00ABIch hab aber lieber eine coole Ex-Freundin\u2026\u00BB",
  "id" : 419520085683097600,
  "created_at" : "2014-01-04 17:25:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "419517464397885440",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.4908769017, 7.2335470803 ]
  },
  "id_str" : "419517635127410689",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot I can do it both ways!",
  "id" : 419517635127410689,
  "in_reply_to_status_id" : 419517464397885440,
  "created_at" : "2014-01-04 17:16:13 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "419515612717522944",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.4907431318, 7.2335951335 ]
  },
  "id_str" : "419516861278334977",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot nur behaarter!",
  "id" : 419516861278334977,
  "in_reply_to_status_id" : 419515612717522944,
  "created_at" : "2014-01-04 17:13:08 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.4909659, 7.23396279 ]
  },
  "id_str" : "419477963126882304",
  "text" : "So kurz nach Weihnachten, kein Wunder sind noch so viele Allgemeinpl\u00E4tzchen \u00FCbrig\u2026",
  "id" : 419477963126882304,
  "created_at" : "2014-01-04 14:38:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yara Sanchez",
      "screen_name" : "yara_elena",
      "indices" : [ 81, 92 ],
      "id_str" : "1360330398",
      "id" : 1360330398
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/yara_elena\/status\/419299622444482560\/photo\/1",
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/Jt057pGVtH",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BdGmyPqCQAEBIeX.jpg",
      "id_str" : "419299622448676865",
      "id" : 419299622448676865,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BdGmyPqCQAEBIeX.jpg",
      "sizes" : [ {
        "h" : 750,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 750,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 531,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 750,
        "resize" : "fit",
        "w" : 960
      } ],
      "display_url" : "pic.twitter.com\/Jt057pGVtH"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.49096761, 7.23395432 ]
  },
  "id_str" : "419449683866845184",
  "text" : "at least that\u2019s what computational biology promises before you start doing it RT @yara_elena: Contrast... http:\/\/t.co\/Jt057pGVtH",
  "id" : 419449683866845184,
  "created_at" : "2014-01-04 12:46:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 58 ],
      "url" : "http:\/\/t.co\/QKeAzK6pFW",
      "expanded_url" : "http:\/\/i.imgur.com\/bDYDA65.jpg",
      "display_url" : "i.imgur.com\/bDYDA65.jpg"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.49096419, 7.23397126 ]
  },
  "id_str" : "419441396542881792",
  "text" : "whatever floats the hamster\u2019s coat\u2026 http:\/\/t.co\/QKeAzK6pFW",
  "id" : 419441396542881792,
  "created_at" : "2014-01-04 12:13:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 63 ],
      "url" : "https:\/\/t.co\/WbL9NoFL3H",
      "expanded_url" : "https:\/\/pbs.twimg.com\/media\/BH6waT2CAAIyS2H.jpg",
      "display_url" : "pbs.twimg.com\/media\/BH6waT2C\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.4909659, 7.23396279 ]
  },
  "id_str" : "419427069895147520",
  "text" : "some social norms are useful after all\u2026 https:\/\/t.co\/WbL9NoFL3H",
  "id" : 419427069895147520,
  "created_at" : "2014-01-04 11:16:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 53 ],
      "url" : "http:\/\/t.co\/Iddxs6AbEq",
      "expanded_url" : "http:\/\/www.qwantz.com\/index.php?comic=2549",
      "display_url" : "qwantz.com\/index.php?comi\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.4909381933, 7.2339275633 ]
  },
  "id_str" : "419400759378444288",
  "text" : "useful skills for the new year http:\/\/t.co\/Iddxs6AbEq",
  "id" : 419400759378444288,
  "created_at" : "2014-01-04 09:31:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/YlQN2fIsRG",
      "expanded_url" : "http:\/\/www.plosone.org\/article\/info%3Adoi%2F10.1371%2Fjournal.pone.0084872",
      "display_url" : "plosone.org\/article\/info%3\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.4909381933, 7.2339275633 ]
  },
  "id_str" : "419393540352114688",
  "text" : "Heterozyg. Superiority Hypothesis for Polymorph. Color Vision Not Supported by Fitness Data from Neotropical Monkeys http:\/\/t.co\/YlQN2fIsRG",
  "id" : 419393540352114688,
  "created_at" : "2014-01-04 09:03:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.4893408839, 7.2329740914 ]
  },
  "id_str" : "419374902261870593",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer $23.75 for AWS :p",
  "id" : 419374902261870593,
  "created_at" : "2014-01-04 07:49:02 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.4810388398, 7.2243577605 ]
  },
  "id_str" : "419247760299552768",
  "text" : "Autocorrect f\u00FCr 500: \u00ABIch liebe dich so sehr.\u00BB \u2014 \u00ABIch liebe doof auch so sehr.\u00BB",
  "id" : 419247760299552768,
  "created_at" : "2014-01-03 23:23:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jacquelyn Gill",
      "screen_name" : "JacquelynGill",
      "indices" : [ 3, 17 ],
      "id_str" : "112475924",
      "id" : 112475924
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/5ryBSWSuPJ",
      "expanded_url" : "http:\/\/bit.ly\/192WzQT",
      "display_url" : "bit.ly\/192WzQT"
    } ]
  },
  "geo" : { },
  "id_str" : "419242227807035392",
  "text" : "RT @JacquelynGill: Sometimes, we can have nice things: Academic kindness: http:\/\/t.co\/5ryBSWSuPJ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/janetter.net\/\" rel=\"nofollow\"\u003EJanetter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 55, 77 ],
        "url" : "http:\/\/t.co\/5ryBSWSuPJ",
        "expanded_url" : "http:\/\/bit.ly\/192WzQT",
        "display_url" : "bit.ly\/192WzQT"
      } ]
    },
    "geo" : { },
    "id_str" : "419240155044933632",
    "text" : "Sometimes, we can have nice things: Academic kindness: http:\/\/t.co\/5ryBSWSuPJ",
    "id" : 419240155044933632,
    "created_at" : "2014-01-03 22:53:36 +0000",
    "user" : {
      "name" : "Jacquelyn Gill",
      "screen_name" : "JacquelynGill",
      "protected" : false,
      "id_str" : "112475924",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/816027573343965184\/qUfIq3xY_normal.jpg",
      "id" : 112475924,
      "verified" : true
    }
  },
  "id" : 419242227807035392,
  "created_at" : "2014-01-03 23:01:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Fern Riddell",
      "screen_name" : "FernRiddell",
      "indices" : [ 3, 15 ],
      "id_str" : "65399201",
      "id" : 65399201
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/FernRiddell\/status\/418851235056607232\/photo\/1",
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/Qtv5JZMfk6",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BdAO-qAIYAIRmme.jpg",
      "id_str" : "418851234934972418",
      "id" : 418851234934972418,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BdAO-qAIYAIRmme.jpg",
      "sizes" : [ {
        "h" : 695,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 462,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 695,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 695,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/Qtv5JZMfk6"
    } ],
    "hashtags" : [ {
      "text" : "spot",
      "indices" : [ 91, 96 ]
    }, {
      "text" : "hemmingway",
      "indices" : [ 97, 108 ]
    } ],
    "urls" : [ {
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/M5wMRvZChg",
      "expanded_url" : "http:\/\/www.buzzfeed.com\/alanwhite\/spectacular-acts-of-wikipedia-vandalism",
      "display_url" : "buzzfeed.com\/alanwhite\/spec\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "419240384985038849",
  "text" : "RT @FernRiddell: This is my favourite moment of Wikipedia Vandalism http:\/\/t.co\/M5wMRvZChg #spot #hemmingway http:\/\/t.co\/Qtv5JZMfk6",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FernRiddell\/status\/418851235056607232\/photo\/1",
        "indices" : [ 92, 114 ],
        "url" : "http:\/\/t.co\/Qtv5JZMfk6",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BdAO-qAIYAIRmme.jpg",
        "id_str" : "418851234934972418",
        "id" : 418851234934972418,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BdAO-qAIYAIRmme.jpg",
        "sizes" : [ {
          "h" : 695,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 462,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 695,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 695,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/Qtv5JZMfk6"
      } ],
      "hashtags" : [ {
        "text" : "spot",
        "indices" : [ 74, 79 ]
      }, {
        "text" : "hemmingway",
        "indices" : [ 80, 91 ]
      } ],
      "urls" : [ {
        "indices" : [ 51, 73 ],
        "url" : "http:\/\/t.co\/M5wMRvZChg",
        "expanded_url" : "http:\/\/www.buzzfeed.com\/alanwhite\/spectacular-acts-of-wikipedia-vandalism",
        "display_url" : "buzzfeed.com\/alanwhite\/spec\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "418851235056607232",
    "text" : "This is my favourite moment of Wikipedia Vandalism http:\/\/t.co\/M5wMRvZChg #spot #hemmingway http:\/\/t.co\/Qtv5JZMfk6",
    "id" : 418851235056607232,
    "created_at" : "2014-01-02 21:08:10 +0000",
    "user" : {
      "name" : "Dr Fern Riddell",
      "screen_name" : "FernRiddell",
      "protected" : false,
      "id_str" : "65399201",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/912797345972150272\/HEOdqG9y_normal.jpg",
      "id" : 65399201,
      "verified" : true
    }
  },
  "id" : 419240384985038849,
  "created_at" : "2014-01-03 22:54:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/CYiddcdBoo",
      "expanded_url" : "http:\/\/youtube.com\/watch?v=DzkrVDQoHQI",
      "display_url" : "youtube.com\/watch?v=DzkrVD\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.4812608568, 7.2249016887 ]
  },
  "id_str" : "419240203510116353",
  "text" : "it takes more than fucking someone you don\u2019t know to keep warm http:\/\/t.co\/CYiddcdBoo",
  "id" : 419240203510116353,
  "created_at" : "2014-01-03 22:53:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 67 ],
      "url" : "http:\/\/t.co\/DSM22TnlC5",
      "expanded_url" : "http:\/\/instagram.com\/p\/iuSOw7Bwso\/",
      "display_url" : "instagram.com\/p\/iuSOw7Bwso\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.621986, 6.972841 ]
  },
  "id_str" : "419231396297981952",
  "text" : "I'll wait at the wormhole @ Bermuda Triangle http:\/\/t.co\/DSM22TnlC5",
  "id" : 419231396297981952,
  "created_at" : "2014-01-03 22:18:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "419218087339372544",
  "geo" : { },
  "id_str" : "419218693894455296",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot Liebe auf den ersten drip.",
  "id" : 419218693894455296,
  "in_reply_to_status_id" : 419218087339372544,
  "created_at" : "2014-01-03 21:28:19 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrea Kuszewski \uD83E\uDDE0",
      "screen_name" : "AndreaKuszewski",
      "indices" : [ 50, 66 ],
      "id_str" : "15150453",
      "id" : 15150453
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/MaRgcG7iSb",
      "expanded_url" : "http:\/\/jezebel.com\/this-might-be-the-most-romantic-and-pee-soaked-missed-c-1493343091\/@madeleine",
      "display_url" : "jezebel.com\/this-might-be-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "419209504014999552",
  "text" : "Always thought my first date stories were fun! RT @AndreaKuszewski: Nothing says \u2018I love you\u2019 like getting peed on. http:\/\/t.co\/MaRgcG7iSb",
  "id" : 419209504014999552,
  "created_at" : "2014-01-03 20:51:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/BGW2nfVaxm",
      "expanded_url" : "http:\/\/instagram.com\/p\/it-qtXBwuA\/",
      "display_url" : "instagram.com\/p\/it-qtXBwuA\/"
    } ]
  },
  "geo" : { },
  "id_str" : "419188374436851712",
  "text" : "Hat eigentlich schon ein Pirat medienwirksam dieses Werk geheiratet? http:\/\/t.co\/BGW2nfVaxm",
  "id" : 419188374436851712,
  "created_at" : "2014-01-03 19:27:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.4811232603, 7.2241118607 ]
  },
  "id_str" : "419186647042129920",
  "text" : "\u00ABIch liebe dich, du Hurensohn.\u00BB \u2014 \u00ABIch dich auch, mein Kacknoob.\u00BB",
  "id" : 419186647042129920,
  "created_at" : "2014-01-03 19:20:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.4810682701, 7.2220525926 ]
  },
  "id_str" : "419171214805188608",
  "text" : "\u00ABNach einer halben Stunde hier: Willst du immer noch Kinder?\u00BB \u2014 \u00ABYep!\u00BB \u2014 \u00ABNa, zum Gl\u00FCck hast du noch eine andere Freundin!\u00BB",
  "id" : 419171214805188608,
  "created_at" : "2014-01-03 18:19:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "419132577103245313",
  "text" : "\u00ABIst es eigentlich Zufall das dein Musikgeschmack immer gruftiger wird?\u00BB \u2014 \u00ABDas liegt daran das wir dem Parteitag immer n\u00E4her kommen.\u00BB",
  "id" : 419132577103245313,
  "created_at" : "2014-01-03 15:46:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 49 ],
      "url" : "http:\/\/t.co\/30WzVpIsC4",
      "expanded_url" : "http:\/\/feeds.boingboing.net\/~r\/boingboing\/iBag\/~3\/LgbjqGD-ktQ\/story01.htm",
      "display_url" : "feeds.boingboing.net\/~r\/boingboing\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.323506, 7.269569 ]
  },
  "id_str" : "419129083210268672",
  "text" : "GOP declares war on\u00A0itself http:\/\/t.co\/30WzVpIsC4",
  "id" : 419129083210268672,
  "created_at" : "2014-01-03 15:32:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Austin Richardson",
      "screen_name" : "heyaudy",
      "indices" : [ 0, 8 ],
      "id_str" : "14534523",
      "id" : 14534523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "419115590553333760",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.8730827285, 7.1960262966 ]
  },
  "id_str" : "419116895028396032",
  "in_reply_to_user_id" : 14534523,
  "text" : "@heyaudy Thanks :)",
  "id" : 419116895028396032,
  "in_reply_to_status_id" : 419115590553333760,
  "created_at" : "2014-01-03 14:43:49 +0000",
  "in_reply_to_screen_name" : "heyaudy",
  "in_reply_to_user_id_str" : "14534523",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.7791021653, 7.2372116182 ]
  },
  "id_str" : "419115828018438144",
  "text" : "\u00ABDu bist heut Nacht in meinem wirren Traum aufgetaucht &amp; wollt dir sagen das du dein Kind nicht Lisa nennen sollst. Frag nich warum\u2026\u00BB",
  "id" : 419115828018438144,
  "created_at" : "2014-01-03 14:39:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 14, 26 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "419040682016124928",
  "geo" : { },
  "id_str" : "419108491870351360",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @helgerausch awesome, thanks. I will be away from a ssh-capable machine for most of the day but can investigate over WE.",
  "id" : 419108491870351360,
  "in_reply_to_status_id" : 419040682016124928,
  "created_at" : "2014-01-03 14:10:25 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.3943546821, 8.0756406214 ]
  },
  "id_str" : "419105869046231041",
  "text" : "\u00ABIch finde Ohren statt Nasen auslecken fast noch geiler.\u00BB \u2014 \u00ABWeil deine Geh\u00F6rg\u00E4nge noch weiter sind als deine schon riesigen Nasenl\u00F6cher?\u00BB",
  "id" : 419105869046231041,
  "created_at" : "2014-01-03 14:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "purrrlegon",
      "screen_name" : "pulegon",
      "indices" : [ 0, 8 ],
      "id_str" : "107502279",
      "id" : 107502279
    }, {
      "name" : "jhermes",
      "screen_name" : "spinfocl",
      "indices" : [ 9, 18 ],
      "id_str" : "214008538",
      "id" : 214008538
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "419059332802961408",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096746224, 8.2830401466 ]
  },
  "id_str" : "419100133499084800",
  "in_reply_to_user_id" : 107502279,
  "text" : "@pulegon @spinfoCL @DRadioWissen danke, aber sie haben zumindest individuelle Observationen und f\u00FCr Magnetfeldschwankungen korrigiert.",
  "id" : 419100133499084800,
  "in_reply_to_status_id" : 419059332802961408,
  "created_at" : "2014-01-03 13:37:12 +0000",
  "in_reply_to_screen_name" : "pulegon",
  "in_reply_to_user_id_str" : "107502279",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "419024349396365313",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097151241, 8.2828848995 ]
  },
  "id_str" : "419030210684547072",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer apache is also up and running but passenger whines about pgsql.",
  "id" : 419030210684547072,
  "in_reply_to_status_id" : 419024349396365313,
  "created_at" : "2014-01-03 08:59:22 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "419024349396365313",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096893293, 8.2830529646 ]
  },
  "id_str" : "419029865460142080",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer ok, graceful did not work out. Did hard reset, now ssh works for me.",
  "id" : 419029865460142080,
  "in_reply_to_status_id" : 419024349396365313,
  "created_at" : "2014-01-03 08:57:59 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "419024349396365313",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0098095881, 8.283114899 ]
  },
  "id_str" : "419024543500734464",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer site still down apparently, does ssh work on your end?",
  "id" : 419024543500734464,
  "in_reply_to_status_id" : 419024349396365313,
  "created_at" : "2014-01-03 08:36:50 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "419020603094360065",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096684237, 8.2832335065 ]
  },
  "id_str" : "419022743989145600",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer okay, tried a graceful reboot just now. Let\u2019s see whether that was enough or if we need to opt for harder procedures.",
  "id" : 419022743989145600,
  "in_reply_to_status_id" : 419020603094360065,
  "created_at" : "2014-01-03 08:29:41 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "419020306431213568",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097020902, 8.2827331871 ]
  },
  "id_str" : "419020498455265280",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer oh, thought you had access to that as well. Then let me get out of bed and restart :)",
  "id" : 419020498455265280,
  "in_reply_to_status_id" : 419020306431213568,
  "created_at" : "2014-01-03 08:20:46 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "418923555498115072",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096993107, 8.2830570545 ]
  },
  "id_str" : "419020157722591232",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer same here, can you restart the machine?",
  "id" : 419020157722591232,
  "in_reply_to_status_id" : 418923555498115072,
  "created_at" : "2014-01-03 08:19:25 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Yoder \uD83D\uDD96\uD83C\uDFFB",
      "screen_name" : "JBYoder",
      "indices" : [ 3, 11 ],
      "id_str" : "19984919",
      "id" : 19984919
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "418916689611599872",
  "text" : "RT @JBYoder: And then: \u201CAlthough Tolkien never said that the elves DID have hot gay sex, he also never said that they DIDN'T.\" http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/32v25pD6HC",
        "expanded_url" : "http:\/\/www.ansereg.com\/what_tolkien_officially_said_abo.htm",
        "display_url" : "ansereg.com\/what_tolkien_o\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "418916180770824193",
    "text" : "And then: \u201CAlthough Tolkien never said that the elves DID have hot gay sex, he also never said that they DIDN'T.\" http:\/\/t.co\/32v25pD6HC",
    "id" : 418916180770824193,
    "created_at" : "2014-01-03 01:26:15 +0000",
    "user" : {
      "name" : "Jeremy Yoder \uD83D\uDD96\uD83C\uDFFB",
      "screen_name" : "JBYoder",
      "protected" : false,
      "id_str" : "19984919",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/870850169759072256\/r0kxCgGs_normal.jpg",
      "id" : 19984919,
      "verified" : true
    }
  },
  "id" : 418916689611599872,
  "created_at" : "2014-01-03 01:28:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 3, 16 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "418914032637452288",
  "text" : "RT @PhilippBayer: \"what's the worst lab mistake you've ever made?\" - \"Once I gave myself plague. Literally. Bubonic plague.\" http:\/\/t.co\/RT\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 107, 129 ],
        "url" : "http:\/\/t.co\/RTym9mMjDV",
        "expanded_url" : "http:\/\/www.reddit.com\/r\/labrats\/comments\/1stoib\/so_i_broke_a_20000_machine_last_week_fellow\/",
        "display_url" : "reddit.com\/r\/labrats\/comm\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "418913647121797120",
    "text" : "\"what's the worst lab mistake you've ever made?\" - \"Once I gave myself plague. Literally. Bubonic plague.\" http:\/\/t.co\/RTym9mMjDV",
    "id" : 418913647121797120,
    "created_at" : "2014-01-03 01:16:11 +0000",
    "user" : {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "protected" : false,
      "id_str" : "121777206",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2013711027\/IMG_1088_normal.png",
      "id" : 121777206,
      "verified" : false
    }
  },
  "id" : 418914032637452288,
  "created_at" : "2014-01-03 01:17:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Michael Johnson",
      "screen_name" : "ericmjohnson",
      "indices" : [ 3, 16 ],
      "id_str" : "19084034",
      "id" : 19084034
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/IaEQLRhZ37",
      "expanded_url" : "http:\/\/www.thedailybeast.com\/articles\/2014\/01\/02\/2013-was-a-terrible-year-for-evolution.html",
      "display_url" : "thedailybeast.com\/articles\/2014\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "418904328188219393",
  "text" : "RT @ericmjohnson: 2013 Was a Terrible Year for Evolution: http:\/\/t.co\/IaEQLRhZ37",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 40, 62 ],
        "url" : "http:\/\/t.co\/IaEQLRhZ37",
        "expanded_url" : "http:\/\/www.thedailybeast.com\/articles\/2014\/01\/02\/2013-was-a-terrible-year-for-evolution.html",
        "display_url" : "thedailybeast.com\/articles\/2014\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "418903659716415488",
    "text" : "2013 Was a Terrible Year for Evolution: http:\/\/t.co\/IaEQLRhZ37",
    "id" : 418903659716415488,
    "created_at" : "2014-01-03 00:36:29 +0000",
    "user" : {
      "name" : "Eric Michael Johnson",
      "screen_name" : "ericmjohnson",
      "protected" : false,
      "id_str" : "19084034",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/434953612825858048\/DckRYRye_normal.png",
      "id" : 19084034,
      "verified" : false
    }
  },
  "id" : 418904328188219393,
  "created_at" : "2014-01-03 00:39:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 75 ],
      "url" : "http:\/\/t.co\/7R5zTwZ9MX",
      "expanded_url" : "http:\/\/www.npr.org\/blogs\/alltechconsidered\/2014\/01\/01\/258670211\/more-than-300-sharks-in-australia-are-now-on-twitter?rss=1",
      "display_url" : "npr.org\/blogs\/alltechc\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009668, 8.283132 ]
  },
  "id_str" : "418901348898578432",
  "text" : "Soon on Twitter: More Australian sharks than Germans http:\/\/t.co\/7R5zTwZ9MX",
  "id" : 418901348898578432,
  "created_at" : "2014-01-03 00:27:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096478593, 8.2830558065 ]
  },
  "id_str" : "418900183586701312",
  "text" : "\u00ABDu musst W\u00E4rmflasche spielen, du bist mein Mann! Was hab ich sonst davon!?\u00BB\u2014\u00ABDie intellektuelle Herausforderung: teaching a robot to love.\u00BB",
  "id" : 418900183586701312,
  "created_at" : "2014-01-03 00:22:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096698648, 8.2831319961 ]
  },
  "id_str" : "418898976600252416",
  "text" : "\u00ABIch will ja nichts sagen, aber deine Katze ist im Bett.\u00BB\u2014\u00ABOh, wie typisch! Kaum ist sie im Weg ist sie meine Katze\u2026\u00BB",
  "id" : 418898976600252416,
  "created_at" : "2014-01-03 00:17:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/PksGGrCaZg",
      "expanded_url" : "http:\/\/boingboing.net\/2014\/01\/02\/scientific-paper-searching-th.html",
      "display_url" : "boingboing.net\/2014\/01\/02\/sci\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00965538, 8.2830085717 ]
  },
  "id_str" : "418824477649412096",
  "text" : "Searching the Internet for time travelers, the scientific\u00A0paper. Spoiler: \u00ABNo time travelers were discovered.\u00BB http:\/\/t.co\/PksGGrCaZg",
  "id" : 418824477649412096,
  "created_at" : "2014-01-02 19:21:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 48 ],
      "url" : "http:\/\/t.co\/WTvcSE8zVG",
      "expanded_url" : "http:\/\/www.asofterworld.com\/index.php?id=1051",
      "display_url" : "asofterworld.com\/index.php?id=1\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00965538, 8.2830085717 ]
  },
  "id_str" : "418823331736211456",
  "text" : "it\u2019s okay to laugh at me. http:\/\/t.co\/WTvcSE8zVG",
  "id" : 418823331736211456,
  "created_at" : "2014-01-02 19:17:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 60 ],
      "url" : "http:\/\/t.co\/r5LOef2ogh",
      "expanded_url" : "http:\/\/instagram.com\/p\/irRebnhwjU\/",
      "display_url" : "instagram.com\/p\/irRebnhwjU\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0066633432, 8.2770395279 ]
  },
  "id_str" : "418807521126912000",
  "text" : "after the rain @ Theodor-Heuss-Br\u00FCcke http:\/\/t.co\/r5LOef2ogh",
  "id" : 418807521126912000,
  "created_at" : "2014-01-02 18:14:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/905KOIybuQ",
      "expanded_url" : "http:\/\/instagram.com\/p\/irOnEeBwuq\/",
      "display_url" : "instagram.com\/p\/irOnEeBwuq\/"
    } ]
  },
  "geo" : { },
  "id_str" : "418801221173268480",
  "text" : "\u00ABMir sind Leichen im Zimmer \u00FCber mir lieber als Menschen mit St\u00F6ckelschuhen. Die sind wenigstens leise!\u00BB http:\/\/t.co\/905KOIybuQ",
  "id" : 418801221173268480,
  "created_at" : "2014-01-02 17:49:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00965538, 8.2830085717 ]
  },
  "id_str" : "418791620839243776",
  "text" : "\u00ABNerv ich dich gerade eigentlich?\u00BB \u2013 \u00ABNein, schon gut.\u00BB \u2013 \u00ABAlso ein klares \u2018Ja, aber du darfst trotzdem bleiben\u2019?\u00BB",
  "id" : 418791620839243776,
  "created_at" : "2014-01-02 17:11:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00965538, 8.2830085717 ]
  },
  "id_str" : "418788483063623680",
  "text" : "\u00ABIst das dein Traumstaubsauger?\u00BB \u2013 \u00ABIch hab eigentlich nur eine Bedingung an ihn: Das er mir nicht den Penis abreisst.\u00BB",
  "id" : 418788483063623680,
  "created_at" : "2014-01-02 16:58:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "li5a",
      "screen_name" : "li5a",
      "indices" : [ 0, 5 ],
      "id_str" : "11712822",
      "id" : 11712822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "418779303854100481",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00965538, 8.2830085717 ]
  },
  "id_str" : "418779790079188992",
  "in_reply_to_user_id" : 11712822,
  "text" : "@li5a in Kombination auch sehr sch\u00F6n, f\u00FCr die linksextremen BDSMler. ;)",
  "id" : 418779790079188992,
  "in_reply_to_status_id" : 418779303854100481,
  "created_at" : "2014-01-02 16:24:17 +0000",
  "in_reply_to_screen_name" : "li5a",
  "in_reply_to_user_id_str" : "11712822",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0064681352, 8.2657477244 ]
  },
  "id_str" : "418772387417833472",
  "text" : "\u00ABAuf den Parteitag habe ich mal gar keine Lust. Aber ich freu mich auf dich. Gehen wir was trinken?\u00BB\u2014\u00ABIch wollte exakt dasselbe schreiben!\u00BB",
  "id" : 418772387417833472,
  "created_at" : "2014-01-02 15:54:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 46 ],
      "url" : "http:\/\/t.co\/VP2eJGJNMv",
      "expanded_url" : "http:\/\/i.imgur.com\/8Jd0Kpd.jpg",
      "display_url" : "i.imgur.com\/8Jd0Kpd.jpg"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.001139, 8.258647 ]
  },
  "id_str" : "418767807594397697",
  "text" : "this might take a while http:\/\/t.co\/VP2eJGJNMv",
  "id" : 418767807594397697,
  "created_at" : "2014-01-02 15:36:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0011259893, 8.258725203 ]
  },
  "id_str" : "418765398671392768",
  "text" : "Autocorrect: \u00ABGrobes Neues!\u00BB Klingt auch mehr nach Hack. Halb und halb.",
  "id" : 418765398671392768,
  "created_at" : "2014-01-02 15:27:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Weber",
      "screen_name" : "scy",
      "indices" : [ 0, 4 ],
      "id_str" : "8308632",
      "id" : 8308632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "418748546964525056",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00965538, 8.2830085717 ]
  },
  "id_str" : "418751203703808000",
  "in_reply_to_user_id" : 8308632,
  "text" : "@scy you\u2019re double-welcome ;)",
  "id" : 418751203703808000,
  "in_reply_to_status_id" : 418748546964525056,
  "created_at" : "2014-01-02 14:30:41 +0000",
  "in_reply_to_screen_name" : "scy",
  "in_reply_to_user_id_str" : "8308632",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00965538, 8.2830085717 ]
  },
  "id_str" : "418750562394730496",
  "text" : "\u00ABWhen you helicopter, is it really super impressive?\u00BB \u2013 \u00ABgetting them to go different directions, thats something I'd love to be able to do\u00BB",
  "id" : 418750562394730496,
  "created_at" : "2014-01-02 14:28:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andreas Herten",
      "screen_name" : "AndiH",
      "indices" : [ 0, 6 ],
      "id_str" : "4586881",
      "id" : 4586881
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 51 ],
      "url" : "http:\/\/t.co\/TV73Wrlv8R",
      "expanded_url" : "http:\/\/www.reddit.com\/r\/IAmA\/comments\/1u75hh\/i_am_the_guy_with_two_penises_ama\/cefaw8v",
      "display_url" : "reddit.com\/r\/IAmA\/comment\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "418744037307604992",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00965538, 8.2830085717 ]
  },
  "id_str" : "418745197951193088",
  "in_reply_to_user_id" : 4586881,
  "text" : "@AndiH best comment on that: http:\/\/t.co\/TV73Wrlv8R ;)",
  "id" : 418745197951193088,
  "in_reply_to_status_id" : 418744037307604992,
  "created_at" : "2014-01-02 14:06:49 +0000",
  "in_reply_to_screen_name" : "AndiH",
  "in_reply_to_user_id_str" : "4586881",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andreas Herten",
      "screen_name" : "AndiH",
      "indices" : [ 0, 6 ],
      "id_str" : "4586881",
      "id" : 4586881
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "418744037307604992",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00965538, 8.2830085717 ]
  },
  "id_str" : "418744630130536448",
  "in_reply_to_user_id" : 4586881,
  "text" : "@AndiH that\u2019s the one that convinced me, but maybe just because my spatial reasoning was challenged as well. ;)",
  "id" : 418744630130536448,
  "in_reply_to_status_id" : 418744037307604992,
  "created_at" : "2014-01-02 14:04:34 +0000",
  "in_reply_to_screen_name" : "AndiH",
  "in_reply_to_user_id_str" : "4586881",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andreas Herten",
      "screen_name" : "AndiH",
      "indices" : [ 0, 6 ],
      "id_str" : "4586881",
      "id" : 4586881
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 62 ],
      "url" : "http:\/\/t.co\/9N3rwCvKaX",
      "expanded_url" : "http:\/\/www.reddit.com\/r\/IAmA\/comments\/1u75hh\/i_am_the_guy_with_two_penises_ama\/cef61lf",
      "display_url" : "reddit.com\/r\/IAmA\/comment\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "418743561593847808",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00965538, 8.2830085717 ]
  },
  "id_str" : "418743859276169216",
  "in_reply_to_user_id" : 4586881,
  "text" : "@AndiH nevermind, scrolled down to this http:\/\/t.co\/9N3rwCvKaX ;)",
  "id" : 418743859276169216,
  "in_reply_to_status_id" : 418743561593847808,
  "created_at" : "2014-01-02 14:01:30 +0000",
  "in_reply_to_screen_name" : "AndiH",
  "in_reply_to_user_id_str" : "4586881",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andreas Herten",
      "screen_name" : "AndiH",
      "indices" : [ 0, 6 ],
      "id_str" : "4586881",
      "id" : 4586881
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "418742696262782976",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00965538, 8.2830085717 ]
  },
  "id_str" : "418743306802442240",
  "in_reply_to_user_id" : 4586881,
  "text" : "@AndiH ich hab noch nicht alle Q&amp;A gelesen. Woher deine Vermutung? :)",
  "id" : 418743306802442240,
  "in_reply_to_status_id" : 418742696262782976,
  "created_at" : "2014-01-02 13:59:18 +0000",
  "in_reply_to_screen_name" : "AndiH",
  "in_reply_to_user_id_str" : "4586881",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 60 ],
      "url" : "http:\/\/t.co\/s4epMISd6y",
      "expanded_url" : "http:\/\/www.reddit.com\/r\/IAmA\/comments\/1u75hh\/i_am_the_guy_with_two_penises_ama\/",
      "display_url" : "reddit.com\/r\/IAmA\/comment\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "418742436354330624",
  "text" : "\u00ABI am the guy with two penises. AMA.\u00BB http:\/\/t.co\/s4epMISd6y",
  "id" : 418742436354330624,
  "created_at" : "2014-01-02 13:55:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 33 ],
      "url" : "http:\/\/t.co\/YdtFlJ54Qq",
      "expanded_url" : "http:\/\/i.imgur.com\/mDPcpKn.png",
      "display_url" : "i.imgur.com\/mDPcpKn.png"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00965538, 8.2830085717 ]
  },
  "id_str" : "418736910182649856",
  "text" : "Awww &lt;3 http:\/\/t.co\/YdtFlJ54Qq",
  "id" : 418736910182649856,
  "created_at" : "2014-01-02 13:33:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert",
      "screen_name" : "kventil",
      "indices" : [ 0, 8 ],
      "id_str" : "7431192",
      "id" : 7431192
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 113, 122 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "418731710486818816",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00965538, 8.2830085717 ]
  },
  "id_str" : "418731984236838912",
  "in_reply_to_user_id" : 7431192,
  "text" : "@kventil da f\u00E4llt mir ein das ich einen Ira Glass-Fanclub namens TALiban immer noch f\u00FCr eine gute Idee halte. ;) @Senficon",
  "id" : 418731984236838912,
  "in_reply_to_status_id" : 418731710486818816,
  "created_at" : "2014-01-02 13:14:19 +0000",
  "in_reply_to_screen_name" : "kventil",
  "in_reply_to_user_id_str" : "7431192",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 60, 69 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/SGr3wRxCv4",
      "expanded_url" : "http:\/\/feedproxy.google.com\/~r\/plosone\/PLoSONE\/~3\/Qu74GcxHfZM\/info%3Adoi%2F10.1371%2Fjournal.pone.0084078",
      "display_url" : "feedproxy.google.com\/~r\/plosone\/PLo\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009713, 8.283211 ]
  },
  "id_str" : "418730878186323968",
  "text" : "Bounded Rationality and Voting Decisions over 160 Years \/cc @senficon  http:\/\/t.co\/SGr3wRxCv4",
  "id" : 418730878186323968,
  "created_at" : "2014-01-02 13:09:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 44 ],
      "url" : "http:\/\/t.co\/IQUTNXoryk",
      "expanded_url" : "http:\/\/www.crackajack.de\/2014\/01\/02\/ultrasound-levitation\/?utm_source=feedburner&utm_medium=feed&utm_campaign=Feed%3A+NerdcoreRSS2+%28Crackajack%29",
      "display_url" : "crackajack.de\/2014\/01\/02\/ult\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "418730375947776000",
  "text" : "Ultrasound Levitation http:\/\/t.co\/IQUTNXoryk",
  "id" : 418730375947776000,
  "created_at" : "2014-01-02 13:07:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00965538, 8.2830085717 ]
  },
  "id_str" : "418722188754452480",
  "text" : "Wie fixen eigentlich Leute die kein Pr\u00E4p-Besteck im Haus haben ihre Haushaltsger\u00E4te?",
  "id" : 418722188754452480,
  "created_at" : "2014-01-02 12:35:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 67 ],
      "url" : "http:\/\/t.co\/jvgICKxnrL",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=1ifJkquRzlo",
      "display_url" : "youtube.com\/watch?v=1ifJkq\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00965538, 8.2830085717 ]
  },
  "id_str" : "418708141434740736",
  "text" : "Poke at my iris, why can't I cry about this? http:\/\/t.co\/jvgICKxnrL",
  "id" : 418708141434740736,
  "created_at" : "2014-01-02 11:39:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 79 ],
      "url" : "http:\/\/t.co\/BZDUyiyI64",
      "expanded_url" : "http:\/\/en.wikipedia.org\/wiki\/Tobler%27s_hiking_function",
      "display_url" : "en.wikipedia.org\/wiki\/Tobler%27\u2026"
    }, {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/G0s0Yjt4Kc",
      "expanded_url" : "http:\/\/en.wikipedia.org\/wiki\/Naismith",
      "display_url" : "en.wikipedia.org\/wiki\/Naismith"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00965538, 8.2830085717 ]
  },
  "id_str" : "418694375074697217",
  "text" : "TIL about Tobler's hiking function\n&amp; Naismith's rule http:\/\/t.co\/BZDUyiyI64 http:\/\/t.co\/G0s0Yjt4Kc\u2019s_rule",
  "id" : 418694375074697217,
  "created_at" : "2014-01-02 10:44:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Akshat Rathi",
      "screen_name" : "AkshatRathi",
      "indices" : [ 0, 12 ],
      "id_str" : "13766492",
      "id" : 13766492
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "418690533733576704",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096422923, 8.2830586191 ]
  },
  "id_str" : "418691377158168576",
  "in_reply_to_user_id" : 13766492,
  "text" : "@AkshatRathi awesome, Thanks :)",
  "id" : 418691377158168576,
  "in_reply_to_status_id" : 418690533733576704,
  "created_at" : "2014-01-02 10:32:57 +0000",
  "in_reply_to_screen_name" : "AkshatRathi",
  "in_reply_to_user_id_str" : "13766492",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Akshat Rathi",
      "screen_name" : "AkshatRathi",
      "indices" : [ 0, 12 ],
      "id_str" : "13766492",
      "id" : 13766492
    }, {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 13, 23 ],
      "id_str" : "14700783",
      "id" : 14700783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "418690228946092033",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096422923, 8.2830586191 ]
  },
  "id_str" : "418690690001162240",
  "in_reply_to_user_id" : 13766492,
  "text" : "@AkshatRathi @Fischblog (and ffs: embargoes need to die already)",
  "id" : 418690690001162240,
  "in_reply_to_status_id" : 418690228946092033,
  "created_at" : "2014-01-02 10:30:14 +0000",
  "in_reply_to_screen_name" : "AkshatRathi",
  "in_reply_to_user_id_str" : "13766492",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Akshat Rathi",
      "screen_name" : "AkshatRathi",
      "indices" : [ 0, 12 ],
      "id_str" : "13766492",
      "id" : 13766492
    }, {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 13, 23 ],
      "id_str" : "14700783",
      "id" : 14700783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "418690228946092033",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097044372, 8.2829744183 ]
  },
  "id_str" : "418690372278427648",
  "in_reply_to_user_id" : 13766492,
  "text" : "@AkshatRathi @Fischblog that would be great, you still have my address? :)",
  "id" : 418690372278427648,
  "in_reply_to_status_id" : 418690228946092033,
  "created_at" : "2014-01-02 10:28:58 +0000",
  "in_reply_to_screen_name" : "AkshatRathi",
  "in_reply_to_user_id_str" : "13766492",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 0, 10 ],
      "id_str" : "14700783",
      "id" : 14700783
    }, {
      "name" : "Akshat Rathi",
      "screen_name" : "AkshatRathi",
      "indices" : [ 11, 23 ],
      "id_str" : "13766492",
      "id" : 13766492
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "418680820204072960",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097841504, 8.2830357718 ]
  },
  "id_str" : "418690094384816128",
  "in_reply_to_user_id" : 14700783,
  "text" : "@Fischblog @AkshatRathi where can I find that? :)",
  "id" : 418690094384816128,
  "in_reply_to_status_id" : 418680820204072960,
  "created_at" : "2014-01-02 10:27:52 +0000",
  "in_reply_to_screen_name" : "Fischblog",
  "in_reply_to_user_id_str" : "14700783",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 32 ],
      "url" : "http:\/\/t.co\/7DR3FXpy7E",
      "expanded_url" : "http:\/\/i.imgur.com\/6J0AGfl.gif",
      "display_url" : "i.imgur.com\/6J0AGfl.gif"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009767, 8.283031 ]
  },
  "id_str" : "418570622382637056",
  "text" : "Caffeine! http:\/\/t.co\/7DR3FXpy7E",
  "id" : 418570622382637056,
  "created_at" : "2014-01-02 02:33:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "418551795418271744",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00965538, 8.2830085717 ]
  },
  "id_str" : "418558229518766080",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer ah, I found it somewhere else, while reading up on fixing the bugs in my scripts :D",
  "id" : 418558229518766080,
  "in_reply_to_status_id" : 418551795418271744,
  "created_at" : "2014-01-02 01:43:53 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "418549599138095104",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00965538, 8.2830085717 ]
  },
  "id_str" : "418551656515911681",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer haha, where did you find that!? I also read this today!",
  "id" : 418551656515911681,
  "in_reply_to_status_id" : 418549599138095104,
  "created_at" : "2014-01-02 01:17:45 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "418522737611509761",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00965538, 8.2830085717 ]
  },
  "id_str" : "418523060514615296",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer hard to tell without knowing the PAML-version used, but that\u2019s why I never updated from version supplied with my parsers. ;)",
  "id" : 418523060514615296,
  "in_reply_to_status_id" : 418522737611509761,
  "created_at" : "2014-01-01 23:24:08 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "418511006285832193",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00965538, 8.2830085717 ]
  },
  "id_str" : "418512470777810944",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer because PAML is pure evil in terms of consistency of output formatting from version to version? ;)",
  "id" : 418512470777810944,
  "in_reply_to_status_id" : 418511006285832193,
  "created_at" : "2014-01-01 22:42:03 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/RfhgHEOosN",
      "expanded_url" : "http:\/\/imgur.com\/d33BbiK",
      "display_url" : "imgur.com\/d33BbiK"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00965538, 8.2830085717 ]
  },
  "id_str" : "418491672675483648",
  "text" : "\u00ABI'm tempted to find another black dog to put on top and make a dog based oreo\u2026\u00BB http:\/\/t.co\/RfhgHEOosN",
  "id" : 418491672675483648,
  "created_at" : "2014-01-01 21:19:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/FZqpoOBoKE",
      "expanded_url" : "http:\/\/www.nature.com\/news\/the-mystery-of-the-magnetic-cows-1.9350",
      "display_url" : "nature.com\/news\/the-myste\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00965538, 8.2830085717 ]
  },
  "id_str" : "418423524144189440",
  "text" : "First guess on dogs pooping in alignment with magnetic field: Replication will be as dubious as in case of the cows http:\/\/t.co\/FZqpoOBoKE",
  "id" : 418423524144189440,
  "created_at" : "2014-01-01 16:48:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00965538, 8.2830085717 ]
  },
  "id_str" : "418423000044933120",
  "text" : "Paper \u00ABDogs Poop in Alignment with Earth's Magnetic Field\u00BB is on the reddit frontpage &amp; looks like the journal couldn\u2019t handle the traffic.",
  "id" : 418423000044933120,
  "created_at" : "2014-01-01 16:46:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00965538, 8.2830085717 ]
  },
  "id_str" : "418414302895550464",
  "text" : "good: scripts used for my thesis reproducibly yield the same results. bad: they reproducibly yield the same wrong results\u2026 m(",
  "id" : 418414302895550464,
  "created_at" : "2014-01-01 16:11:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0122089917, 8.2622706145 ]
  },
  "id_str" : "418398524699869184",
  "text" : "Typo-inspired exit strategy if academia doesn\u2019t work is now becoming a fortune teller. Project name: hoboscope.",
  "id" : 418398524699869184,
  "created_at" : "2014-01-01 15:09:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00965538, 8.2830085717 ]
  },
  "id_str" : "418377429024247808",
  "text" : "Any1 here familiar with GeneWise? What\u2019s the reasoning for predicted coding sequences containing stop codons within the CDS?",
  "id" : 418377429024247808,
  "created_at" : "2014-01-01 13:45:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00965538, 8.2830085717 ]
  },
  "id_str" : "418363251211399168",
  "text" : "\u2018Last login: Tue Dec 31 23:43:07 2013\u2019 If able the cluster\u2019s ssh-logs would start to laugh every time I start talking work-life-balance.",
  "id" : 418363251211399168,
  "created_at" : "2014-01-01 12:49:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/GnjDBnqItm",
      "expanded_url" : "http:\/\/web.law.duke.edu\/cspd\/publicdomainday\/2014\/pre-1976",
      "display_url" : "web.law.duke.edu\/cspd\/publicdom\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00965538, 8.2830085717 ]
  },
  "id_str" : "418353763712524288",
  "text" : "What Could Have Entered the Public Domain on January\u00A01,\u00A02014? http:\/\/t.co\/GnjDBnqItm",
  "id" : 418353763712524288,
  "created_at" : "2014-01-01 12:11:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/0zSFkGi43V",
      "expanded_url" : "http:\/\/vimeo.com\/81441769",
      "display_url" : "vimeo.com\/81441769"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00965538, 8.2830085717 ]
  },
  "id_str" : "418350193927806976",
  "text" : "\u2018The Animated Life of Alfred Russel Wallace\u2019. A paper puppet video on evolution\u2019s often forgotten co-discoverer http:\/\/t.co\/0zSFkGi43V",
  "id" : 418350193927806976,
  "created_at" : "2014-01-01 11:57:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 54, 67 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "samantha based clark",
      "screen_name" : "eltonjohn",
      "indices" : [ 68, 78 ],
      "id_str" : "15661851",
      "id" : 15661851
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 49 ],
      "url" : "http:\/\/t.co\/bILioG0K0w",
      "expanded_url" : "http:\/\/www.plosone.org\/article\/info%3Adoi%2F10.1371%2Fjournal.pone.0084133",
      "display_url" : "plosone.org\/article\/info%3\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00965538, 8.2830085717 ]
  },
  "id_str" : "418347612971212800",
  "text" : "Extracting Tag Hierarchies http:\/\/t.co\/bILioG0K0w \/cc @PhilippBayer @eltonjohn",
  "id" : 418347612971212800,
  "created_at" : "2014-01-01 11:46:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/1I2nd9DhyW",
      "expanded_url" : "http:\/\/i.imgur.com\/q2G9VjJ.gif",
      "display_url" : "i.imgur.com\/q2G9VjJ.gif"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00965538, 8.2830085717 ]
  },
  "id_str" : "418342624454770688",
  "text" : "MRW I figured out my sex life drifts towards japanese fetish porn http:\/\/t.co\/1I2nd9DhyW",
  "id" : 418342624454770688,
  "created_at" : "2014-01-01 11:27:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096637316, 8.2830599843 ]
  },
  "id_str" : "418330183289278465",
  "text" : "Orr! Orr never changes.",
  "id" : 418330183289278465,
  "created_at" : "2014-01-01 10:37:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "418206725280657409",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096637316, 8.2830599843 ]
  },
  "id_str" : "418209780277452800",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC tats\u00E4chlich passt \u00ABHe who knows when he can fight and when he cannot will be victorious.\u00BB In dem Sinne gehe manchmal aufs Sofa.",
  "id" : 418209780277452800,
  "in_reply_to_status_id" : 418206725280657409,
  "created_at" : "2014-01-01 02:39:16 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "418206725280657409",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096637316, 8.2830599843 ]
  },
  "id_str" : "418209381701156864",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC one you should like: \u00ABBe extremely mysterious, even to the point of soundlessness\u00BB ;)",
  "id" : 418209381701156864,
  "in_reply_to_status_id" : 418206725280657409,
  "created_at" : "2014-01-01 02:37:41 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0094844582, 8.283160453 ]
  },
  "id_str" : "418204157338984448",
  "text" : "Katzen im Bett: Wie man takt. Stellungskampf lernt. \u00ABGeh \u00FCber ihre linke, ich ihre rechte Flanke. Dahinter k\u00F6nnen wir die Reihen schlie\u00DFen!\u00BB",
  "id" : 418204157338984448,
  "created_at" : "2014-01-01 02:16:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
} ]