Grailbird.data.tweets_2014_05 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 6, 28 ],
      "url" : "http:\/\/t.co\/Bw7QJYBSz9",
      "expanded_url" : "http:\/\/instagram.com\/p\/oq93SYBwmR\/",
      "display_url" : "instagram.com\/p\/oq93SYBwmR\/"
    } ]
  },
  "geo" : { },
  "id_str" : "472807592331190272",
  "text" : "Smile http:\/\/t.co\/Bw7QJYBSz9",
  "id" : 472807592331190272,
  "created_at" : "2014-05-31 18:31:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesus del Valle",
      "screen_name" : "yeysus",
      "indices" : [ 0, 7 ],
      "id_str" : "21502180",
      "id" : 21502180
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 8, 21 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "472763162035773440",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 49.9961669401, 8.2831548307 ]
  },
  "id_str" : "472771476480098304",
  "in_reply_to_user_id" : 21502180,
  "text" : "@yeysus @PhilippBayer so did you get my mail? :)",
  "id" : 472771476480098304,
  "in_reply_to_status_id" : 472763162035773440,
  "created_at" : "2014-05-31 16:07:58 +0000",
  "in_reply_to_screen_name" : "yeysus",
  "in_reply_to_user_id_str" : "21502180",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 73 ],
      "url" : "http:\/\/t.co\/YmGYcm2JOe",
      "expanded_url" : "http:\/\/www.smbc-comics.com\/index.php?db=comics&id=3374",
      "display_url" : "smbc-comics.com\/index.php?db=c\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00966226, 8.2830607714 ]
  },
  "id_str" : "472744525673537536",
  "text" : "\u00ABwhat's the scientific way to say \"we fucked up\u201D?\u00BB http:\/\/t.co\/YmGYcm2JOe",
  "id" : 472744525673537536,
  "created_at" : "2014-05-31 14:20:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 35 ],
      "url" : "http:\/\/t.co\/IMqAWI4jak",
      "expanded_url" : "http:\/\/instagram.com\/p\/oqLADvBwjn\/",
      "display_url" : "instagram.com\/p\/oqLADvBwjn\/"
    } ]
  },
  "geo" : { },
  "id_str" : "472695742864166914",
  "text" : "Party Animal http:\/\/t.co\/IMqAWI4jak",
  "id" : 472695742864166914,
  "created_at" : "2014-05-31 11:07:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009547574, 8.2828943 ]
  },
  "id_str" : "472683301942349827",
  "text" : "\u00ABIch bin GABA-Gandalf!\u00BB",
  "id" : 472683301942349827,
  "created_at" : "2014-05-31 10:17:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 31 ],
      "url" : "http:\/\/t.co\/idUhcE1V0o",
      "expanded_url" : "http:\/\/boingboing.net\/2014\/05\/30\/super-mario-dress.html",
      "display_url" : "boingboing.net\/2014\/05\/30\/sup\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009547574, 8.2828943 ]
  },
  "id_str" : "472679152467075073",
  "text" : "do want! http:\/\/t.co\/idUhcE1V0o",
  "id" : 472679152467075073,
  "created_at" : "2014-05-31 10:01:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonas",
      "screen_name" : "lsanoj",
      "indices" : [ 0, 7 ],
      "id_str" : "18918915",
      "id" : 18918915
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "472678797205340160",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009547574, 8.2828943 ]
  },
  "id_str" : "472679052579733504",
  "in_reply_to_user_id" : 18918915,
  "text" : "@lsanoj und der Poncho dr\u00FCckt dich auch noch so nieder!",
  "id" : 472679052579733504,
  "in_reply_to_status_id" : 472678797205340160,
  "created_at" : "2014-05-31 10:00:42 +0000",
  "in_reply_to_screen_name" : "lsanoj",
  "in_reply_to_user_id_str" : "18918915",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Jesus del Valle",
      "screen_name" : "yeysus",
      "indices" : [ 14, 21 ],
      "id_str" : "21502180",
      "id" : 21502180
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "472678768515895296",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009547574, 8.2828943 ]
  },
  "id_str" : "472678982404829184",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @yeysus after all: getting more computing power becomes more import week for week ;)",
  "id" : 472678982404829184,
  "in_reply_to_status_id" : 472678768515895296,
  "created_at" : "2014-05-31 10:00:26 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonas",
      "screen_name" : "lsanoj",
      "indices" : [ 27, 34 ],
      "id_str" : "18918915",
      "id" : 18918915
    }, {
      "name" : "Jonas",
      "screen_name" : "lsanoj",
      "indices" : [ 50, 57 ],
      "id_str" : "18918915",
      "id" : 18918915
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009547574, 8.2828943 ]
  },
  "id_str" : "472678416911974400",
  "text" : "\u00ABEs haben schon alle einen @lsanoj gepullt. Au\u00DFer @lsanoj.\u00BB",
  "id" : 472678416911974400,
  "created_at" : "2014-05-31 09:58:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Jesus del Valle",
      "screen_name" : "yeysus",
      "indices" : [ 50, 57 ],
      "id_str" : "21502180",
      "id" : 21502180
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "472677272277622784",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009590652, 8.282945292 ]
  },
  "id_str" : "472678223630045185",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer reminds me: I now once again bugged @yeysus ;)",
  "id" : 472678223630045185,
  "in_reply_to_status_id" : 472677272277622784,
  "created_at" : "2014-05-31 09:57:25 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 3, 16 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 83 ],
      "url" : "https:\/\/t.co\/9fQUVVjeXG",
      "expanded_url" : "https:\/\/opensnp.wordpress.com\/2014\/05\/31\/1000-genotypings-and-3-years-of-opensnp\/",
      "display_url" : "opensnp.wordpress.com\/2014\/05\/31\/100\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "472677431384764417",
  "text" : "RT @PhilippBayer: 1000 genotypings, and 3 years of openSNP! https:\/\/t.co\/9fQUVVjeXG",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 42, 65 ],
        "url" : "https:\/\/t.co\/9fQUVVjeXG",
        "expanded_url" : "https:\/\/opensnp.wordpress.com\/2014\/05\/31\/1000-genotypings-and-3-years-of-opensnp\/",
        "display_url" : "opensnp.wordpress.com\/2014\/05\/31\/100\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "472677272277622784",
    "text" : "1000 genotypings, and 3 years of openSNP! https:\/\/t.co\/9fQUVVjeXG",
    "id" : 472677272277622784,
    "created_at" : "2014-05-31 09:53:38 +0000",
    "user" : {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "protected" : false,
      "id_str" : "121777206",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2013711027\/IMG_1088_normal.png",
      "id" : 121777206,
      "verified" : false
    }
  },
  "id" : 472677431384764417,
  "created_at" : "2014-05-31 09:54:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "472676986435813376",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009590652, 8.282945292 ]
  },
  "id_str" : "472677221522767872",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer great, thanks for the nice post :)",
  "id" : 472677221522767872,
  "in_reply_to_status_id" : 472676986435813376,
  "created_at" : "2014-05-31 09:53:26 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "472578210098454528",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095507786, 8.2829479729 ]
  },
  "id_str" : "472676098363654144",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer otherwise good to go, so feel free to publish. :)",
  "id" : 472676098363654144,
  "in_reply_to_status_id" : 472578210098454528,
  "created_at" : "2014-05-31 09:48:58 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "472578210098454528",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095507786, 8.2829479729 ]
  },
  "id_str" : "472676028566233088",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer nice draft, just exchanged the 2012 with 2011 in the opening paragraph (30 genotypes were reached by 2011-10-19 ;))",
  "id" : 472676028566233088,
  "in_reply_to_status_id" : 472578210098454528,
  "created_at" : "2014-05-31 09:48:41 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096134191, 8.2830110659 ]
  },
  "id_str" : "472669395857448960",
  "text" : "\u00ABLos, pair dich schon, du Sau!\u00BB \u2014 \u00ABDas ist aber nicht sehr poly\u2026\u00BB",
  "id" : 472669395857448960,
  "created_at" : "2014-05-31 09:22:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "472574607090671616",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096847816, 8.2831040863 ]
  },
  "id_str" : "472574735218651137",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer great, will write you an email :)",
  "id" : 472574735218651137,
  "in_reply_to_status_id" : 472574607090671616,
  "created_at" : "2014-05-31 03:06:11 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "472573330554228736",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097314661, 8.2833332247 ]
  },
  "id_str" : "472574182585548800",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer will have to log in for that and given that it's 5am and I just wanted to go to bed this will have to wait for ~5 hours. Ok?",
  "id" : 472574182585548800,
  "in_reply_to_status_id" : 472573330554228736,
  "created_at" : "2014-05-31 03:03:59 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095766729, 8.2829954623 ]
  },
  "id_str" : "472571811134459904",
  "text" : "\u00ABWenn man dabei ist viel ins Phrasenschwein zu zahlen dann ist man schon fast so weit als Esoteriker viel Geld zu verdienen.\u00BB",
  "id" : 472571811134459904,
  "created_at" : "2014-05-31 02:54:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095992835, 8.2829176293 ]
  },
  "id_str" : "472561705965608960",
  "text" : "\u00ABAndere haben ihre Flashbacks zur\u00FCck nach Vietnam. Ich zum PUR-Konzert.\u00BB",
  "id" : 472561705965608960,
  "created_at" : "2014-05-31 02:14:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096152655, 8.2829236002 ]
  },
  "id_str" : "472474319281717248",
  "text" : "\u00ABAls Macker hat man es schon wirklich schwer. St\u00E4ndig muss man die Beine breit haben. Und dann bekommt man Stei\u00DFbeinprobleme.\u00BB",
  "id" : 472474319281717248,
  "created_at" : "2014-05-30 20:27:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonas",
      "screen_name" : "lsanoj",
      "indices" : [ 1, 8 ],
      "id_str" : "18918915",
      "id" : 18918915
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "claimyourparty",
      "indices" : [ 19, 34 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095993606, 8.2829092546 ]
  },
  "id_str" : "472472927922057216",
  "text" : ".@lsanoj for BuVo! #claimyourparty",
  "id" : 472472927922057216,
  "created_at" : "2014-05-30 20:21:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095429825, 8.2828565682 ]
  },
  "id_str" : "472465875434741760",
  "text" : "I only drink to be merry but unfortunately, I'm in the wrong prison cell and the wrong company.",
  "id" : 472465875434741760,
  "created_at" : "2014-05-30 19:53:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 40 ],
      "url" : "http:\/\/t.co\/xHOLGxaQHl",
      "expanded_url" : "http:\/\/instagram.com\/p\/ooc80zBwli\/",
      "display_url" : "instagram.com\/p\/ooc80zBwli\/"
    } ]
  },
  "geo" : { },
  "id_str" : "472453738557603840",
  "text" : "a series of tubes http:\/\/t.co\/xHOLGxaQHl",
  "id" : 472453738557603840,
  "created_at" : "2014-05-30 19:05:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ashley Friedman",
      "screen_name" : "AshFrieds",
      "indices" : [ 3, 13 ],
      "id_str" : "16244938",
      "id" : 16244938
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "472437838936813568",
  "text" : "RT @AshFrieds: A Kickstarter where you donate yearly based on your income and they build roads and hospitals and your kids can go to school\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "410974183435567104",
    "text" : "A Kickstarter where you donate yearly based on your income and they build roads and hospitals and your kids can go to school for free",
    "id" : 410974183435567104,
    "created_at" : "2013-12-12 03:27:35 +0000",
    "user" : {
      "name" : "Ashley Friedman",
      "screen_name" : "AshFrieds",
      "protected" : false,
      "id_str" : "16244938",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/735635743054274560\/NRAXBO8i_normal.jpg",
      "id" : 16244938,
      "verified" : false
    }
  },
  "id" : 472437838936813568,
  "created_at" : "2014-05-30 18:02:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.158923639, 8.6529745831 ]
  },
  "id_str" : "472437068015345665",
  "text" : "\u00ABWith polyamory you can disappoint more people in the same amount of time, as it's parallel instead of serial. Redefining teraFLOPs.\u00BB",
  "id" : 472437068015345665,
  "created_at" : "2014-05-30 17:59:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "li5a",
      "screen_name" : "li5a",
      "indices" : [ 0, 5 ],
      "id_str" : "11712822",
      "id" : 11712822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "472404562469736448",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723270398, 8.6276063932 ]
  },
  "id_str" : "472408344125534208",
  "in_reply_to_user_id" : 11712822,
  "text" : "@li5a we stumbled upon it just by accident, fun coincidence.",
  "id" : 472408344125534208,
  "in_reply_to_status_id" : 472404562469736448,
  "created_at" : "2014-05-30 16:05:00 +0000",
  "in_reply_to_screen_name" : "li5a",
  "in_reply_to_user_id_str" : "11712822",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "li5a",
      "screen_name" : "li5a",
      "indices" : [ 7, 12 ],
      "id_str" : "11712822",
      "id" : 11712822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723679249, 8.6275873147 ]
  },
  "id_str" : "472401575991054336",
  "text" : "Thanks @li5a, we just gave your published DNA isolation protocol a test at work! Tastes great.",
  "id" : 472401575991054336,
  "created_at" : "2014-05-30 15:38:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/mMoBVDj40j",
      "expanded_url" : "http:\/\/i.imgur.com\/ZSYiOlH.gif",
      "display_url" : "i.imgur.com\/ZSYiOlH.gif"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.14110217, 11.55678529 ]
  },
  "id_str" : "472358964567744512",
  "text" : "http:\/\/t.co\/mMoBVDj40j",
  "id" : 472358964567744512,
  "created_at" : "2014-05-30 12:48:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/9H3uxBxsj2",
      "expanded_url" : "http:\/\/googlemail.com",
      "display_url" : "googlemail.com"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.14110217, 11.55678529 ]
  },
  "id_str" : "472351815263354880",
  "text" : "SEO-Idiots gone wrong: \u00AB\u2026ein Angebot bzgl. der Erh\u00F6hung Ihrer Internetseite: http:\/\/t.co\/9H3uxBxsj2 in der Google-Suchmaschine unterbreiten\u00BB",
  "id" : 472351815263354880,
  "created_at" : "2014-05-30 12:20:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 75 ],
      "url" : "http:\/\/t.co\/93uwSSa1Bk",
      "expanded_url" : "http:\/\/www.nerve.com\/love-sex\/why-the-galactic-cap-cannot-be-the-future-of-condoms",
      "display_url" : "nerve.com\/love-sex\/why-t\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.14110217, 11.55678529 ]
  },
  "id_str" : "472349874143649792",
  "text" : "Why the Galactic Cap Cannot Be the Future of Condoms http:\/\/t.co\/93uwSSa1Bk",
  "id" : 472349874143649792,
  "created_at" : "2014-05-30 12:12:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 39 ],
      "url" : "http:\/\/t.co\/2LWUg6QNyC",
      "expanded_url" : "http:\/\/whatshouldwecallgradschool.tumblr.com\/post\/87221857845\/living-on-a-grad-student-stipend",
      "display_url" : "whatshouldwecallgradschool.tumblr.com\/post\/872218578\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.14110217, 11.55678529 ]
  },
  "id_str" : "472347321284698112",
  "text" : "doing so awesome http:\/\/t.co\/2LWUg6QNyC",
  "id" : 472347321284698112,
  "created_at" : "2014-05-30 12:02:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Stafford",
      "screen_name" : "tomstafford",
      "indices" : [ 3, 15 ],
      "id_str" : "11939852",
      "id" : 11939852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 75 ],
      "url" : "http:\/\/t.co\/YCzpBEBRUY",
      "expanded_url" : "http:\/\/www.ma.utexas.edu\/users\/mks\/statmistakes\/TOC.html",
      "display_url" : "ma.utexas.edu\/users\/mks\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "472343985936429058",
  "text" : "RT @tomstafford: Common mistakes in using statistics http:\/\/t.co\/YCzpBEBRUY",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 36, 58 ],
        "url" : "http:\/\/t.co\/YCzpBEBRUY",
        "expanded_url" : "http:\/\/www.ma.utexas.edu\/users\/mks\/statmistakes\/TOC.html",
        "display_url" : "ma.utexas.edu\/users\/mks\/stat\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "472337409947222016",
    "text" : "Common mistakes in using statistics http:\/\/t.co\/YCzpBEBRUY",
    "id" : 472337409947222016,
    "created_at" : "2014-05-30 11:23:08 +0000",
    "user" : {
      "name" : "Tom Stafford",
      "screen_name" : "tomstafford",
      "protected" : false,
      "id_str" : "11939852",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/916606386443866113\/472eitlv_normal.jpg",
      "id" : 11939852,
      "verified" : false
    }
  },
  "id" : 472343985936429058,
  "created_at" : "2014-05-30 11:49:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/vDDOxLFcGZ",
      "expanded_url" : "http:\/\/evolang.the-comic.org\/comics\/9",
      "display_url" : "evolang.the-comic.org\/comics\/9"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.14110217, 11.55678529 ]
  },
  "id_str" : "472341905876217856",
  "text" : "\u00ABThe kind of thing that Chomsky would say (oh wait, he's also one of the co-authors).\u00BB http:\/\/t.co\/vDDOxLFcGZ",
  "id" : 472341905876217856,
  "created_at" : "2014-05-30 11:41:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 55 ],
      "url" : "http:\/\/t.co\/WUFpFX4DvB",
      "expanded_url" : "http:\/\/www.reuters.com\/article\/2014\/05\/29\/usa-starbucks-texas-idUSL6N0OF4KE20140529",
      "display_url" : "reuters.com\/article\/2014\/0\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.14110217, 11.55678529 ]
  },
  "id_str" : "472340174022934528",
  "text" : "I should try this for getting up http:\/\/t.co\/WUFpFX4DvB",
  "id" : 472340174022934528,
  "created_at" : "2014-05-30 11:34:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "472320970880200704",
  "geo" : { },
  "id_str" : "472332278669250561",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot take it as a gentle reminder of the task you wanted to look into :p",
  "id" : 472332278669250561,
  "in_reply_to_status_id" : 472320970880200704,
  "created_at" : "2014-05-30 11:02:45 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "472331456362971136",
  "geo" : { },
  "id_str" : "472331566413533184",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer ah, already wondered why I\u2019m the only one taking care of those. Sure, will do :)",
  "id" : 472331566413533184,
  "in_reply_to_status_id" : 472331456362971136,
  "created_at" : "2014-05-30 10:59:55 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "472330562498084864",
  "geo" : { },
  "id_str" : "472331074237112320",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer btw. have a look at the latest two emails to the info@.",
  "id" : 472331074237112320,
  "in_reply_to_status_id" : 472330562498084864,
  "created_at" : "2014-05-30 10:57:58 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 63 ],
      "url" : "https:\/\/t.co\/N8hiBTUJtn",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/472303683938840576",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "472330562498084864",
  "geo" : { },
  "id_str" : "472330758577995776",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer look who already noticed: https:\/\/t.co\/N8hiBTUJtn ;)",
  "id" : 472330758577995776,
  "in_reply_to_status_id" : 472330562498084864,
  "created_at" : "2014-05-30 10:56:43 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.14110217, 11.55678529 ]
  },
  "id_str" : "472328699648679936",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer Thanks for taking care of the space problems :3",
  "id" : 472328699648679936,
  "created_at" : "2014-05-30 10:48:32 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 57 ],
      "url" : "https:\/\/t.co\/d4RZYGjfCJ",
      "expanded_url" : "https:\/\/opensnp.org\/genotypes",
      "display_url" : "opensnp.org\/genotypes"
    } ]
  },
  "geo" : { },
  "id_str" : "472303683938840576",
  "text" : "Yay, &gt;1000. Celebratory dance! https:\/\/t.co\/d4RZYGjfCJ",
  "id" : 472303683938840576,
  "created_at" : "2014-05-30 09:09:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Yoder \uD83D\uDD96\uD83C\uDFFB",
      "screen_name" : "JBYoder",
      "indices" : [ 3, 11 ],
      "id_str" : "19984919",
      "id" : 19984919
    }, {
      "name" : "Kyle Hill",
      "screen_name" : "Sci_Phile",
      "indices" : [ 53, 63 ],
      "id_str" : "60709500",
      "id" : 60709500
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "472150630761783296",
  "text" : "RT @JBYoder: Uhura in the background, selling it. RT @Sci_Phile: Stabilized Star Trek looks as ridiculous as you think http:\/\/t.co\/zRr8mlqO\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Kyle Hill",
        "screen_name" : "Sci_Phile",
        "indices" : [ 40, 50 ],
        "id_str" : "60709500",
        "id" : 60709500
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 106, 128 ],
        "url" : "http:\/\/t.co\/zRr8mlqOQZ",
        "expanded_url" : "http:\/\/i.imgur.com\/kFdf2kM.gif",
        "display_url" : "i.imgur.com\/kFdf2kM.gif"
      } ]
    },
    "geo" : { },
    "id_str" : "472093165738926080",
    "text" : "Uhura in the background, selling it. RT @Sci_Phile: Stabilized Star Trek looks as ridiculous as you think http:\/\/t.co\/zRr8mlqOQZ",
    "id" : 472093165738926080,
    "created_at" : "2014-05-29 19:12:36 +0000",
    "user" : {
      "name" : "Jeremy Yoder \uD83D\uDD96\uD83C\uDFFB",
      "screen_name" : "JBYoder",
      "protected" : false,
      "id_str" : "19984919",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/870850169759072256\/r0kxCgGs_normal.jpg",
      "id" : 19984919,
      "verified" : true
    }
  },
  "id" : 472150630761783296,
  "created_at" : "2014-05-29 23:00:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "471777807706910720",
  "geo" : { },
  "id_str" : "472004199413465088",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon the pirate seal of approval?",
  "id" : 472004199413465088,
  "in_reply_to_status_id" : 471777807706910720,
  "created_at" : "2014-05-29 13:19:05 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.14079948, 11.55797726 ]
  },
  "id_str" : "471752964433272832",
  "text" : "crashing the cluster twice in a week. that\u2019s a new low\u2026",
  "id" : 471752964433272832,
  "created_at" : "2014-05-28 20:40:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/3SlWhMMq0d",
      "expanded_url" : "http:\/\/youtube.com\/watch?v=wK19gptEk10",
      "display_url" : "youtube.com\/watch?v=wK19gp\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 49.4046896434, 8.6722798471 ]
  },
  "id_str" : "471702074796040192",
  "text" : "\u00ABI like to think I'm not a complicated man, but then again I can't be sure. So gimme just a little more time.\u00BB http:\/\/t.co\/3SlWhMMq0d",
  "id" : 471702074796040192,
  "created_at" : "2014-05-28 17:18:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ed Yong",
      "screen_name" : "edyong209",
      "indices" : [ 3, 13 ],
      "id_str" : "19767193",
      "id" : 19767193
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/RwP6WCrv7k",
      "expanded_url" : "http:\/\/www.sheffield.ac.uk\/news\/nr\/worlds-first-air-cleansing-poem-1.373843",
      "display_url" : "sheffield.ac.uk\/news\/nr\/worlds\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "471696124857049088",
  "text" : "RT @edyong209: \"This poem alone will eradicate the nitrogen oxide pollution created by about 20 cars every day\" http:\/\/t.co\/RwP6WCrv7k",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 97, 119 ],
        "url" : "http:\/\/t.co\/RwP6WCrv7k",
        "expanded_url" : "http:\/\/www.sheffield.ac.uk\/news\/nr\/worlds-first-air-cleansing-poem-1.373843",
        "display_url" : "sheffield.ac.uk\/news\/nr\/worlds\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "471693253734313984",
    "text" : "\"This poem alone will eradicate the nitrogen oxide pollution created by about 20 cars every day\" http:\/\/t.co\/RwP6WCrv7k",
    "id" : 471693253734313984,
    "created_at" : "2014-05-28 16:43:29 +0000",
    "user" : {
      "name" : "Ed Yong",
      "screen_name" : "edyong209",
      "protected" : false,
      "id_str" : "19767193",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/926063794912153600\/962ygzzx_normal.jpg",
      "id" : 19767193,
      "verified" : true
    }
  },
  "id" : 471696124857049088,
  "created_at" : "2014-05-28 16:54:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 49.88987066, 8.63495554 ]
  },
  "id_str" : "471690314751967232",
  "text" : "My business model: relying on random acts of kindness.",
  "id" : 471690314751967232,
  "created_at" : "2014-05-28 16:31:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alom Shaha",
      "screen_name" : "alomshaha",
      "indices" : [ 3, 13 ],
      "id_str" : "92733167",
      "id" : 92733167
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/u9MSOU6uBX",
      "expanded_url" : "http:\/\/www.thedailybeast.com\/articles\/2014\/05\/27\/your-princess-is-in-another-castle-misogyny-entitlement-and-nerds.html?utm_content=buffer5f26f&utm_medium=social&utm_source=twitter.com&utm_campaign=buffer",
      "display_url" : "thedailybeast.com\/articles\/2014\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "471676440657027072",
  "text" : "RT @alomshaha: \"So, a question, to my fellow male nerds: What the fuck is wrong with us?\" http:\/\/t.co\/u9MSOU6uBX",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 75, 97 ],
        "url" : "http:\/\/t.co\/u9MSOU6uBX",
        "expanded_url" : "http:\/\/www.thedailybeast.com\/articles\/2014\/05\/27\/your-princess-is-in-another-castle-misogyny-entitlement-and-nerds.html?utm_content=buffer5f26f&utm_medium=social&utm_source=twitter.com&utm_campaign=buffer",
        "display_url" : "thedailybeast.com\/articles\/2014\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "471665643256049664",
    "text" : "\"So, a question, to my fellow male nerds: What the fuck is wrong with us?\" http:\/\/t.co\/u9MSOU6uBX",
    "id" : 471665643256049664,
    "created_at" : "2014-05-28 14:53:47 +0000",
    "user" : {
      "name" : "Alom Shaha",
      "screen_name" : "alomshaha",
      "protected" : false,
      "id_str" : "92733167",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/923965687831425024\/scJQJeUL_normal.jpg",
      "id" : 92733167,
      "verified" : true
    }
  },
  "id" : 471676440657027072,
  "created_at" : "2014-05-28 15:36:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 35 ],
      "url" : "https:\/\/t.co\/d4RZYGjfCJ",
      "expanded_url" : "https:\/\/opensnp.org\/genotypes",
      "display_url" : "opensnp.org\/genotypes"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17231317, 8.627600415 ]
  },
  "id_str" : "471662242052984832",
  "text" : "Five to go! https:\/\/t.co\/d4RZYGjfCJ",
  "id" : 471662242052984832,
  "created_at" : "2014-05-28 14:40:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/tmp4pX4hOv",
      "expanded_url" : "http:\/\/www.vanityfair.com\/society\/2014\/06\/monica-lewinsky-humiliation-culture",
      "display_url" : "vanityfair.com\/society\/2014\/0\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17231317, 8.627600415 ]
  },
  "id_str" : "471659664481198080",
  "text" : "\u00ABIt may surprise you to learn that I\u2019m actually a person.\u00BB http:\/\/t.co\/tmp4pX4hOv",
  "id" : 471659664481198080,
  "created_at" : "2014-05-28 14:30:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 52 ],
      "url" : "http:\/\/t.co\/nrxoSNvWc9",
      "expanded_url" : "http:\/\/hipsterlogo.com\/",
      "display_url" : "hipsterlogo.com"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17231317, 8.627600415 ]
  },
  "id_str" : "471655966908616704",
  "text" : "The Hipster Logo Design Guide http:\/\/t.co\/nrxoSNvWc9",
  "id" : 471655966908616704,
  "created_at" : "2014-05-28 14:15:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "fineRainN",
      "screen_name" : "hipscumbag",
      "indices" : [ 3, 14 ],
      "id_str" : "2569508017",
      "id" : 2569508017
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "471655854824247296",
  "text" : "RT @hipscumbag: As a student I am LEAST afraid of \"hostile replication\". I'm MOST afraid of wasting 3 years trying to build on someone's Ty\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "471654107431055363",
    "text" : "As a student I am LEAST afraid of \"hostile replication\". I'm MOST afraid of wasting 3 years trying to build on someone's Type I.",
    "id" : 471654107431055363,
    "created_at" : "2014-05-28 14:07:56 +0000",
    "user" : {
      "name" : "Joe Hilgard, that psych prof we all know and love.",
      "screen_name" : "JoeHilgard",
      "protected" : false,
      "id_str" : "262424781",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/694357423587495936\/hCzr_uX8_normal.jpg",
      "id" : 262424781,
      "verified" : false
    }
  },
  "id" : 471655854824247296,
  "created_at" : "2014-05-28 14:14:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 50 ],
      "url" : "http:\/\/t.co\/YQAYj2QiCZ",
      "expanded_url" : "http:\/\/boingboing.net\/2014\/05\/27\/divorce-complaint-of-richard-f.html",
      "display_url" : "boingboing.net\/2014\/05\/27\/div\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17231317, 8.627600415 ]
  },
  "id_str" : "471652435854110721",
  "text" : "What\u2019s wrong with calculus? http:\/\/t.co\/YQAYj2QiCZ",
  "id" : 471652435854110721,
  "created_at" : "2014-05-28 14:01:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 59 ],
      "url" : "http:\/\/t.co\/ZXvd6VfY5P",
      "expanded_url" : "http:\/\/instagram.com\/p\/oiuKx8hwgz\/",
      "display_url" : "instagram.com\/p\/oiuKx8hwgz\/"
    } ]
  },
  "geo" : { },
  "id_str" : "471647177240895490",
  "text" : "Next step: neighbor joining by hand. http:\/\/t.co\/ZXvd6VfY5P",
  "id" : 471647177240895490,
  "created_at" : "2014-05-28 13:40:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172243189, 8.6275796502 ]
  },
  "id_str" : "471607376119078912",
  "text" : "\u00ABEin halbes Kilo was? Um was f\u00FCr einen Drogendeal geht es gerade.\u00BB \u2014 \u00ABIch glaube es geht um Erdbeeren.\u00BB",
  "id" : 471607376119078912,
  "created_at" : "2014-05-28 11:02:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1824217673, 8.619918412 ]
  },
  "id_str" : "471583240730730496",
  "text" : "Instant productivity loss: now everyone is doing bead-based sequence alignments and discussing scoring matrices.",
  "id" : 471583240730730496,
  "created_at" : "2014-05-28 09:26:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "471566041085386752",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17231317, 8.627600415 ]
  },
  "id_str" : "471569519845339136",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot w\u00E4re gegangen mit passender Formatierung, aber fair enough, given your brain. ;)",
  "id" : 471569519845339136,
  "in_reply_to_status_id" : 471566041085386752,
  "created_at" : "2014-05-28 08:31:49 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 34 ],
      "url" : "http:\/\/t.co\/uhxKgfq989",
      "expanded_url" : "http:\/\/instagram.com\/p\/oiJOQaBws-\/",
      "display_url" : "instagram.com\/p\/oiJOQaBws-\/"
    } ]
  },
  "geo" : { },
  "id_str" : "471565933295976448",
  "text" : "Melone FTW! http:\/\/t.co\/uhxKgfq989",
  "id" : 471565933295976448,
  "created_at" : "2014-05-28 08:17:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/ncBpR2l8w1",
      "expanded_url" : "http:\/\/what-if.xkcd.com\/98\/",
      "display_url" : "what-if.xkcd.com\/98\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17231317, 8.627600415 ]
  },
  "id_str" : "471564669652828160",
  "text" : "Could you get drunk from drinking a drunk person's blood? http:\/\/t.co\/ncBpR2l8w1",
  "id" : 471564669652828160,
  "created_at" : "2014-05-28 08:12:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17231317, 8.627600415 ]
  },
  "id_str" : "471556847569494016",
  "text" : "\u00ABWeisst du wer die Taschent\u00FCcher auf meinem Schreibtisch zusammengetackert hat?\u00BB",
  "id" : 471556847569494016,
  "created_at" : "2014-05-28 07:41:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 56 ],
      "url" : "http:\/\/t.co\/qhpyKf3DmY",
      "expanded_url" : "http:\/\/xkcd.com\/927\/",
      "display_url" : "xkcd.com\/927\/"
    } ]
  },
  "in_reply_to_status_id_str" : "471554596759166976",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17231317, 8.627600415 ]
  },
  "id_str" : "471556265312010240",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC seems like mild case of http:\/\/t.co\/qhpyKf3DmY",
  "id" : 471556265312010240,
  "in_reply_to_status_id" : 471554596759166976,
  "created_at" : "2014-05-28 07:39:09 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "471539529334423553",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17231317, 8.627600415 ]
  },
  "id_str" : "471555880367190016",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot ich sagte \u201Cseit langem\u201D, und das war bevor du dich \u00FCber die Foursquare-Checkups am\u00FCsiertest!",
  "id" : 471555880367190016,
  "in_reply_to_status_id" : 471539529334423553,
  "created_at" : "2014-05-28 07:37:37 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "471412003563528195",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096900077, 8.2830404083 ]
  },
  "id_str" : "471414970987462656",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot so romantisch, ich schmelze dahin.",
  "id" : 471414970987462656,
  "in_reply_to_status_id" : 471412003563528195,
  "created_at" : "2014-05-27 22:17:42 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Linus Schumacher",
      "screen_name" : "LinusSchumacher",
      "indices" : [ 0, 16 ],
      "id_str" : "2289913051",
      "id" : 2289913051
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "471413238328868864",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096684788, 8.2832164876 ]
  },
  "id_str" : "471413582974812160",
  "in_reply_to_user_id" : 2289913051,
  "text" : "@LinusSchumacher ich vermute link-rotting bewahrt uns davor ;)",
  "id" : 471413582974812160,
  "in_reply_to_status_id" : 471413238328868864,
  "created_at" : "2014-05-27 22:12:11 +0000",
  "in_reply_to_screen_name" : "LinusSchumacher",
  "in_reply_to_user_id_str" : "2289913051",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Linus Schumacher",
      "screen_name" : "LinusSchumacher",
      "indices" : [ 0, 16 ],
      "id_str" : "2289913051",
      "id" : 2289913051
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "471403182539939840",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096684788, 8.2832164876 ]
  },
  "id_str" : "471412671540396032",
  "in_reply_to_user_id" : 2289913051,
  "text" : "@LinusSchumacher waren das nicht die AC\/OC-Vorlesungen?",
  "id" : 471412671540396032,
  "in_reply_to_status_id" : 471403182539939840,
  "created_at" : "2014-05-27 22:08:33 +0000",
  "in_reply_to_screen_name" : "LinusSchumacher",
  "in_reply_to_user_id_str" : "2289913051",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097051931, 8.2831337386 ]
  },
  "id_str" : "471412487745966080",
  "text" : "The biggest problem with cross dressing: why, oh why, are the buttons on the other side?",
  "id" : 471412487745966080,
  "created_at" : "2014-05-27 22:07:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096806172, 8.2830810528 ]
  },
  "id_str" : "471383284438818816",
  "text" : "Der Hoden ist Lava!",
  "id" : 471383284438818816,
  "created_at" : "2014-05-27 20:11:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Yoder \uD83D\uDD96\uD83C\uDFFB",
      "screen_name" : "JBYoder",
      "indices" : [ 3, 11 ],
      "id_str" : "19984919",
      "id" : 19984919
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/APEGCdZKpZ",
      "expanded_url" : "http:\/\/nblo.gs\/Xd4yh",
      "display_url" : "nblo.gs\/Xd4yh"
    } ]
  },
  "geo" : { },
  "id_str" : "471382795873689601",
  "text" : "RT @JBYoder: Nothing in Biology Makes Sense: Why evolutionary biologists are stoked about pot http:\/\/t.co\/APEGCdZKpZ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.networkedblogs.com\/\" rel=\"nofollow\"\u003ENetworkedBlogs\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 81, 103 ],
        "url" : "http:\/\/t.co\/APEGCdZKpZ",
        "expanded_url" : "http:\/\/nblo.gs\/Xd4yh",
        "display_url" : "nblo.gs\/Xd4yh"
      } ]
    },
    "geo" : { },
    "id_str" : "471363082631909378",
    "text" : "Nothing in Biology Makes Sense: Why evolutionary biologists are stoked about pot http:\/\/t.co\/APEGCdZKpZ",
    "id" : 471363082631909378,
    "created_at" : "2014-05-27 18:51:31 +0000",
    "user" : {
      "name" : "Jeremy Yoder \uD83D\uDD96\uD83C\uDFFB",
      "screen_name" : "JBYoder",
      "protected" : false,
      "id_str" : "19984919",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/870850169759072256\/r0kxCgGs_normal.jpg",
      "id" : 19984919,
      "verified" : true
    }
  },
  "id" : 471382795873689601,
  "created_at" : "2014-05-27 20:09:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096586054, 8.2832379581 ]
  },
  "id_str" : "471379366786916352",
  "text" : "\u00ABDu bist doch kein Jubelperser, du bist ein Jubelperverser!\u00BB",
  "id" : 471379366786916352,
  "created_at" : "2014-05-27 19:56:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/ajpBRhFj9B",
      "expanded_url" : "http:\/\/instagram.com\/p\/ogOQlqBwil\/",
      "display_url" : "instagram.com\/p\/ogOQlqBwil\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172192593, 8.630112991 ]
  },
  "id_str" : "471295534070640643",
  "text" : "Alignment Simulator 3.0 @ Goethe-Universit\u00E4t Frankfurt, Campus Riedberg http:\/\/t.co\/ajpBRhFj9B",
  "id" : 471295534070640643,
  "created_at" : "2014-05-27 14:23:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "471276569659711488",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723440709, 8.627588009 ]
  },
  "id_str" : "471278610478034945",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot \uD83C\uDF4E\uD83C\uDF4F\uD83C\uDF4A\uD83C\uDF4B\uD83C\uDF52\uD83C\uDF47\uD83C\uDF49\uD83C\uDF53\uD83C\uDF51\uD83C\uDF48\uD83C\uDF4C\uD83C\uDF45\uD83C\uDF4D\uD83C\uDF50\uD83C\uDF6C\uD83C\uDF6D\uD83C\uDF6B\uD83C\uDF70\uD83C\uDF6A\uD83C\uDF67\uD83D\uDC0B\uD83D\uDC39",
  "id" : 471278610478034945,
  "in_reply_to_status_id" : 471276569659711488,
  "created_at" : "2014-05-27 13:15:51 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "471272860359864320",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17231317, 8.627600415 ]
  },
  "id_str" : "471273714496307200",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot weil du verfressen \u00FCber die Autobahn gekrabbelt bist um Bananen einzusammeln?",
  "id" : 471273714496307200,
  "in_reply_to_status_id" : 471272860359864320,
  "created_at" : "2014-05-27 12:56:24 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Turner",
      "screen_name" : "genetics_blog",
      "indices" : [ 3, 17 ],
      "id_str" : "923639552874557440",
      "id" : 923639552874557440
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/rrLFQWzLqq",
      "expanded_url" : "http:\/\/www.npr.org\/2014\/05\/26\/316124174\/a-simple-elegant-invention-that-draws-water-from-air",
      "display_url" : "npr.org\/2014\/05\/26\/316\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "471267265279975424",
  "text" : "RT @genetics_blog: The warkawater is a real-life version of the Fremen windtraps of Dune http:\/\/t.co\/rrLFQWzLqq",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 70, 92 ],
        "url" : "http:\/\/t.co\/rrLFQWzLqq",
        "expanded_url" : "http:\/\/www.npr.org\/2014\/05\/26\/316124174\/a-simple-elegant-invention-that-draws-water-from-air",
        "display_url" : "npr.org\/2014\/05\/26\/316\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "471266877042610176",
    "text" : "The warkawater is a real-life version of the Fremen windtraps of Dune http:\/\/t.co\/rrLFQWzLqq",
    "id" : 471266877042610176,
    "created_at" : "2014-05-27 12:29:13 +0000",
    "user" : {
      "name" : "Stephen Turner",
      "screen_name" : "strnr",
      "protected" : false,
      "id_str" : "20444825",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/660439762856230913\/ARYE5YB6_normal.jpg",
      "id" : 20444825,
      "verified" : false
    }
  },
  "id" : 471267265279975424,
  "created_at" : "2014-05-27 12:30:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Primitives Element",
      "screen_name" : "drseilzug",
      "indices" : [ 0, 10 ],
      "id_str" : "243633845",
      "id" : 243633845
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 33 ],
      "url" : "http:\/\/t.co\/09m5CkScQh",
      "expanded_url" : "http:\/\/www.quickmeme.com\/img\/8b\/8bd9cb2e4e082b7b67492db5a33a709c4a739a1aed479bcd8c1d8ab6661e7bf4.jpg",
      "display_url" : "quickmeme.com\/img\/8b\/8bd9cb2\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "471265808107450368",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17231317, 8.627600415 ]
  },
  "id_str" : "471266207312916480",
  "in_reply_to_user_id" : 243633845,
  "text" : "@drseilzug http:\/\/t.co\/09m5CkScQh",
  "id" : 471266207312916480,
  "in_reply_to_status_id" : 471265808107450368,
  "created_at" : "2014-05-27 12:26:34 +0000",
  "in_reply_to_screen_name" : "drseilzug",
  "in_reply_to_user_id_str" : "243633845",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17231317, 8.627600415 ]
  },
  "id_str" : "471265580931375105",
  "text" : "\u00ABJetzt hast du einen Bluterguss auf der anderen Seite vom Hals. Bist du etwa wieder von dem gleichen wilden Eichh\u00F6rnchen angefallen worden?\u00BB",
  "id" : 471265580931375105,
  "created_at" : "2014-05-27 12:24:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 43 ],
      "url" : "http:\/\/t.co\/ELOSioU0gf",
      "expanded_url" : "http:\/\/www.smbc-comics.com\/?id=3366#comic",
      "display_url" : "smbc-comics.com\/?id=3366#comic"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17231317, 8.627600415 ]
  },
  "id_str" : "471255278990917632",
  "text" : "statistical modeling http:\/\/t.co\/ELOSioU0gf",
  "id" : 471255278990917632,
  "created_at" : "2014-05-27 11:43:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/sLkbG8Izan",
      "expanded_url" : "http:\/\/projects.aljazeera.com\/2014\/portrait-of-down-syndrome\/index.html?src=longreads&utm_content=bufferaf63b&utm_medium=social&utm_source=twitter.com&utm_campaign=buffer",
      "display_url" : "projects.aljazeera.com\/2014\/portrait-\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17231317, 8.627600415 ]
  },
  "id_str" : "471253674942275584",
  "text" : "\u00ABFor Hire: Dedicated Young Man with Down Syndrome \u2013 A father reflects on his son's search for employment\u00BB http:\/\/t.co\/sLkbG8Izan",
  "id" : 471253674942275584,
  "created_at" : "2014-05-27 11:36:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 72 ],
      "url" : "http:\/\/t.co\/OVYuZw775p",
      "expanded_url" : "http:\/\/existentialcomics.com\/comic\/30",
      "display_url" : "existentialcomics.com\/comic\/30"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17231317, 8.627600415 ]
  },
  "id_str" : "471248862389489665",
  "text" : "\u00ABCamus was sexy as fuck\u00BB The Analytics at the Bar http:\/\/t.co\/OVYuZw775p",
  "id" : 471248862389489665,
  "created_at" : "2014-05-27 11:17:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/Nj149EaHH5",
      "expanded_url" : "https:\/\/fbcdn-sphotos-c-a.akamaihd.net\/hphotos-ak-prn2\/t1.0-9\/10346296_655122997870483_4338656448899583833_n.jpg",
      "display_url" : "fbcdn-sphotos-c-a.akamaihd.net\/hphotos-ak-prn\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17231317, 8.627600415 ]
  },
  "id_str" : "471243194987204608",
  "text" : "\u00ABSeid ihr eigentlich Geschwister?\u00BB \u2013 \u00ABJa, wir haben eine ganz innige Beziehung.\u00BB https:\/\/t.co\/Nj149EaHH5",
  "id" : 471243194987204608,
  "created_at" : "2014-05-27 10:55:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723647478, 8.6275649528 ]
  },
  "id_str" : "471240502764118016",
  "text" : "\u00ABNat\u00FCrlich mache ich bei deinem Marathon-Team 'Random Walk' mit!\u00BB",
  "id" : 471240502764118016,
  "created_at" : "2014-05-27 10:44:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17231317, 8.627600415 ]
  },
  "id_str" : "471227572299517952",
  "text" : "\u00ABThe Frankfurt Marathon is coming! Last year we made an tremendous impact ... at least on the duration of the competition.\u00BB",
  "id" : 471227572299517952,
  "created_at" : "2014-05-27 09:53:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723389151, 8.6276018347 ]
  },
  "id_str" : "471222613428412416",
  "text" : "\u00ABIch w\u00FCrd sagen: schepp aber sch\u00F6n.\u00BB",
  "id" : 471222613428412416,
  "created_at" : "2014-05-27 09:33:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095938245, 8.2829410028 ]
  },
  "id_str" : "471037117645463552",
  "text" : "So proud of our cats, no matter which one got the mouse. Either it was the stupid one or the old one.",
  "id" : 471037117645463552,
  "created_at" : "2014-05-26 21:16:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 23, 32 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/ZlpbzjkyzM",
      "expanded_url" : "http:\/\/instagram.com\/p\/oeYY75Bwus\/",
      "display_url" : "instagram.com\/p\/oeYY75Bwus\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096073081, 8.2829816055 ]
  },
  "id_str" : "471036445113982976",
  "text" : "You know how it works, @senficon: 'dead $organism, do not eat' is to be taken seriously in our freezer. http:\/\/t.co\/ZlpbzjkyzM",
  "id" : 471036445113982976,
  "created_at" : "2014-05-26 21:13:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 46 ],
      "url" : "http:\/\/t.co\/YqxDz4XSkT",
      "expanded_url" : "http:\/\/instagram.com\/p\/oeS297BwlC\/",
      "display_url" : "instagram.com\/p\/oeS297BwlC\/"
    } ]
  },
  "geo" : { },
  "id_str" : "471024173267943424",
  "text" : "Alignment Simulator 2.0 http:\/\/t.co\/YqxDz4XSkT",
  "id" : 471024173267943424,
  "created_at" : "2014-05-26 20:24:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1134825824, 8.6787056085 ]
  },
  "id_str" : "470988925608415233",
  "text" : "More first world problems: having too many nodes to put them all on the current UPS, with the latest node being too large for the rack.",
  "id" : 470988925608415233,
  "created_at" : "2014-05-26 18:04:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "470959728525594624",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1446724495, 8.6656127343 ]
  },
  "id_str" : "470969391216340992",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot als ob die K\u00E4tzchen das nicht schon zur gen\u00FCge sagen w\u00FCrden ;)",
  "id" : 470969391216340992,
  "in_reply_to_status_id" : 470959728525594624,
  "created_at" : "2014-05-26 16:47:07 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17231317, 8.627600415 ]
  },
  "id_str" : "470955758218412034",
  "text" : "\u00ABHessentag?! Das klingt nach einem Ku Klux Klan-Treffen f\u00FCr Hessen. Apfelwein statt Kapuze oder so.\u00BB",
  "id" : 470955758218412034,
  "created_at" : "2014-05-26 15:52:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 40 ],
      "url" : "http:\/\/t.co\/ajqLrOoXXR",
      "expanded_url" : "http:\/\/www.smbc-comics.com\/index.php?db=comics&id=3368",
      "display_url" : "smbc-comics.com\/index.php?db=c\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17231317, 8.627600415 ]
  },
  "id_str" : "470892553660030976",
  "text" : "know your biology http:\/\/t.co\/ajqLrOoXXR",
  "id" : 470892553660030976,
  "created_at" : "2014-05-26 11:41:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723425082, 8.6276007034 ]
  },
  "id_str" : "470890746405744640",
  "text" : "\u00ABSie hat sich so lustig erschreckt als ihre Zigarette angez\u00FCndet hat.\u00BB \u2014 \u00ABSie hat gebrannt!\u00BB",
  "id" : 470890746405744640,
  "created_at" : "2014-05-26 11:34:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 37 ],
      "url" : "http:\/\/t.co\/mRkcpsNRdJ",
      "expanded_url" : "http:\/\/www.phdcomics.com\/comics.php?f=1711",
      "display_url" : "phdcomics.com\/comics.php?f=1\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17231317, 8.627600415 ]
  },
  "id_str" : "470856159118000128",
  "text" : "I did research http:\/\/t.co\/mRkcpsNRdJ",
  "id" : 470856159118000128,
  "created_at" : "2014-05-26 09:17:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "470851466341928960",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17231317, 8.627600415 ]
  },
  "id_str" : "470854747734700032",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich i see what you did there!",
  "id" : 470854747734700032,
  "in_reply_to_status_id" : 470851466341928960,
  "created_at" : "2014-05-26 09:11:34 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 38 ],
      "url" : "http:\/\/t.co\/DnPUFFD63b",
      "expanded_url" : "http:\/\/i.imgur.com\/dRINAmG.gif",
      "display_url" : "i.imgur.com\/dRINAmG.gif"
    } ]
  },
  "in_reply_to_status_id_str" : "470837758811201537",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17231317, 8.627600415 ]
  },
  "id_str" : "470850559566938112",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich as in http:\/\/t.co\/DnPUFFD63b ?",
  "id" : 470850559566938112,
  "in_reply_to_status_id" : 470837758811201537,
  "created_at" : "2014-05-26 08:54:56 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/KpWDIVVUah",
      "expanded_url" : "http:\/\/www.plosone.org\/article\/info%3Adoi%2F10.1371%2Fjournal.pone.0096653",
      "display_url" : "plosone.org\/article\/info%3\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17231317, 8.627600415 ]
  },
  "id_str" : "470848200015097856",
  "text" : "Preference-Based Serial Decision Dynamics: Your First Sushi Reveals Your Eating Order at the Sushi Table http:\/\/t.co\/KpWDIVVUah",
  "id" : 470848200015097856,
  "created_at" : "2014-05-26 08:45:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 75 ],
      "url" : "http:\/\/t.co\/P2xYCWyTRu",
      "expanded_url" : "http:\/\/boingboing.net\/2014\/05\/22\/if-gay-guys-said-the-stuff-str.html",
      "display_url" : "boingboing.net\/2014\/05\/22\/if-\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17231317, 8.627600415 ]
  },
  "id_str" : "470846768083906560",
  "text" : "If gay guys said the stuff straight guys say to them http:\/\/t.co\/P2xYCWyTRu",
  "id" : 470846768083906560,
  "created_at" : "2014-05-26 08:39:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 115, 128 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/uG1FrTkDMb",
      "expanded_url" : "http:\/\/techcrunch.com\/2014\/05\/24\/dont-believe-anyone-who-tells-you-learning-to-code-is-easy\/",
      "display_url" : "techcrunch.com\/2014\/05\/24\/don\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17231317, 8.627600415 ]
  },
  "id_str" : "470845707268935680",
  "text" : "\u00ABWhat I forgot is that the most common state for a programmer is a sense of inadequacy\u00BB http:\/\/t.co\/uG1FrTkDMb \/HT @PhilippBayer",
  "id" : 470845707268935680,
  "created_at" : "2014-05-26 08:35:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "470652485494140928",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096678921, 8.283047257 ]
  },
  "id_str" : "470694713448988673",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich so als ob ich das st\u00E4ndig IRL tun w\u00FCrde :p",
  "id" : 470694713448988673,
  "in_reply_to_status_id" : 470652485494140928,
  "created_at" : "2014-05-25 22:35:39 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 83, 92 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/sWeuNjVcOC",
      "expanded_url" : "http:\/\/www.auntiepixelante.com\/games\/",
      "display_url" : "auntiepixelante.com\/games\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009628245, 8.282997725 ]
  },
  "id_str" : "470649538919686144",
  "text" : "Triad \u2013 The ultimate puzzle: fit three people in a bed! http:\/\/t.co\/sWeuNjVcOC \/HT @JP_Stich (solved it!)",
  "id" : 470649538919686144,
  "created_at" : "2014-05-25 19:36:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dvzrv",
      "screen_name" : "dvzrv",
      "indices" : [ 0, 6 ],
      "id_str" : "30868098",
      "id" : 30868098
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 7, 13 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "470596595780968448",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0070828985, 8.2620035638 ]
  },
  "id_str" : "470608212602126336",
  "in_reply_to_user_id" : 30868098,
  "text" : "@dvzrv @Lobot ich hab geh\u00F6rt wir sehen uns n\u00E4chstes Jahr wieder?",
  "id" : 470608212602126336,
  "in_reply_to_status_id" : 470596595780968448,
  "created_at" : "2014-05-25 16:51:56 +0000",
  "in_reply_to_screen_name" : "dvzrv",
  "in_reply_to_user_id_str" : "30868098",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 53 ],
      "url" : "http:\/\/t.co\/w8xV82FplU",
      "expanded_url" : "http:\/\/instagram.com\/p\/obVS6yhwgB\/",
      "display_url" : "instagram.com\/p\/obVS6yhwgB\/"
    } ]
  },
  "geo" : { },
  "id_str" : "470607318988500992",
  "text" : "Mein Herz ist Asbestverseucht! http:\/\/t.co\/w8xV82FplU",
  "id" : 470607318988500992,
  "created_at" : "2014-05-25 16:48:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bodyandcloud",
      "indices" : [ 85, 98 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1077695121, 8.7650192519 ]
  },
  "id_str" : "470575886870536192",
  "text" : "\u00ABJetzt fasst mal jeder von euch beiden hier einen Kontakt an. Und jetzt k\u00FCsst euch!\u00BB #bodyandcloud",
  "id" : 470575886870536192,
  "created_at" : "2014-05-25 14:43:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    }, {
      "name" : "Christian M.",
      "screen_name" : "chris2newz",
      "indices" : [ 10, 21 ],
      "id_str" : "15479389",
      "id" : 15479389
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "470548466662244352",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1080636166, 8.7650893205 ]
  },
  "id_str" : "470553571579420672",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon @chris2newz danke ;)",
  "id" : 470553571579420672,
  "in_reply_to_status_id" : 470548466662244352,
  "created_at" : "2014-05-25 13:14:48 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/fukXYjrrxC",
      "expanded_url" : "http:\/\/instagram.com\/p\/oa4sThhwtT\/",
      "display_url" : "instagram.com\/p\/oa4sThhwtT\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.107461811, 8.769610644 ]
  },
  "id_str" : "470544419830394880",
  "text" : "\u00ABDu bist so niedlich in deinem kleinen Cowboyoutfit.\u00BB @ Offenbach Main Ufer http:\/\/t.co\/fukXYjrrxC",
  "id" : 470544419830394880,
  "created_at" : "2014-05-25 12:38:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "esomesse",
      "indices" : [ 71, 80 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1079707993, 8.7649918787 ]
  },
  "id_str" : "470541842397036544",
  "text" : "\u00ABLasst den Lichtgott der Alphawellen euch durchzucken.\u00BB Ich dachte die #esomesse war letztes Wochenende.",
  "id" : 470541842397036544,
  "created_at" : "2014-05-25 12:28:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1077352003, 8.7650892849 ]
  },
  "id_str" : "470538964634710016",
  "text" : "\u00ABLauf, schnell, bevor dein Intellekt schaden nimmt.\u00BB",
  "id" : 470538964634710016,
  "created_at" : "2014-05-25 12:16:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bodyandcloud",
      "indices" : [ 96, 109 ]
    } ],
    "urls" : [ {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/66oR1UAOzS",
      "expanded_url" : "https:\/\/vine.co\/v\/MwjgmmL1QIH",
      "display_url" : "vine.co\/v\/MwjgmmL1QIH"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1080725541, 8.7650650984 ]
  },
  "id_str" : "470529139720863744",
  "text" : "How the SNPs on my 24 chromosomes and the mt-genome are mapped to sound https:\/\/t.co\/66oR1UAOzS #bodyandcloud",
  "id" : 470529139720863744,
  "created_at" : "2014-05-25 11:37:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dvzrv",
      "screen_name" : "dvzrv",
      "indices" : [ 88, 94 ],
      "id_str" : "30868098",
      "id" : 30868098
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bodyandcloud",
      "indices" : [ 96, 109 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1081381391, 8.7647495447 ]
  },
  "id_str" : "470525744058478592",
  "text" : "Listening to my genotype as 6-channel audio installation is pretty weird indeed. Thanks @dvzrv! #bodyandcloud",
  "id" : 470525744058478592,
  "created_at" : "2014-05-25 11:24:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0994073973, 8.7502008956 ]
  },
  "id_str" : "470509471211749376",
  "text" : "\u00ABIch finde \u2018The Pink Socks\u2019 w\u00E4re ein guter Bandname f\u00FCr uns.\u00BB \u2014 \u00ABWenn wir Hip Hop machen w\u00FCrden k\u00F6nnten wir auch \u2018Anal Bead Box\u2019 nutzen.\u00BB",
  "id" : 470509471211749376,
  "created_at" : "2014-05-25 10:19:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096403489, 8.2829921503 ]
  },
  "id_str" : "470452046613999617",
  "text" : "\u00ABIch hab dir eine Journalistin gefangen\u00BB \u2014 \u00ABMusstest du sie gleich mit ins Bett nehmen?\u00BB \u2014 \u00ABSie ist embettet!\u00BB",
  "id" : 470452046613999617,
  "created_at" : "2014-05-25 06:31:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096435206, 8.2830002224 ]
  },
  "id_str" : "470450486194503680",
  "text" : "\u00ABWillst du mit uns ins Bett? Du darfst es auch wie Wallraff machen und ganz unten liegen.\u00BB",
  "id" : 470450486194503680,
  "created_at" : "2014-05-25 06:25:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096593116, 8.2829821283 ]
  },
  "id_str" : "470358513890648065",
  "text" : "\u00BBMeine Definition von \u2018Marketing was nicht verwerflich ist\u2019: Wenn es f\u00FCr riesige Dinge ist die ich in meinen Arsch schieben kann.\u00BB",
  "id" : 470358513890648065,
  "created_at" : "2014-05-25 00:19:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bodyandcloud",
      "indices" : [ 0, 13 ]
    } ],
    "urls" : [ {
      "indices" : [ 14, 36 ],
      "url" : "http:\/\/t.co\/jqvCiULOFW",
      "expanded_url" : "http:\/\/instagram.com\/p\/oY-T0hhwpp\/",
      "display_url" : "instagram.com\/p\/oY-T0hhwpp\/"
    } ]
  },
  "geo" : { },
  "id_str" : "470275298097762304",
  "text" : "#bodyandcloud http:\/\/t.co\/jqvCiULOFW",
  "id" : 470275298097762304,
  "created_at" : "2014-05-24 18:49:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bodyandcloud",
      "indices" : [ 53, 66 ]
    } ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/6KBT0T2DOn",
      "expanded_url" : "http:\/\/instagram.com\/p\/oY8Yzzhwlh\/",
      "display_url" : "instagram.com\/p\/oY8Yzzhwlh\/"
    } ]
  },
  "geo" : { },
  "id_str" : "470271076271161345",
  "text" : "\u00ABI think we might need a 'circuit-bending-be-gone'.\u00BB #bodyandcloud http:\/\/t.co\/6KBT0T2DOn",
  "id" : 470271076271161345,
  "created_at" : "2014-05-24 18:32:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bodyandcloud",
      "indices" : [ 81, 94 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1080803182, 8.7650035426 ]
  },
  "id_str" : "470260560421208064",
  "text" : "\u00ABBut with Google Glass we all will soon wear our prisons directly on our faces!\u00BB #bodyandcloud",
  "id" : 470260560421208064,
  "created_at" : "2014-05-24 17:50:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bodyandcloud",
      "indices" : [ 104, 117 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1080683613, 8.7650620227 ]
  },
  "id_str" : "470259381645639681",
  "text" : "Surprise: It\u2019s the people that chose to keep jobs they hate who don\u2019t believe you can do what you love. #bodyandcloud",
  "id" : 470259381645639681,
  "created_at" : "2014-05-24 17:45:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1080407094, 8.7650925722 ]
  },
  "id_str" : "470255624551694336",
  "text" : "\u00ABI still do laundry &amp; I don\u2019t love doing it. But I love clean clothes, so it\u2019s worth it.\u00BB \u2014 \u00ABAccording to Buddhism you love doing laundry!\u00BB",
  "id" : 470255624551694336,
  "created_at" : "2014-05-24 17:30:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 70 ],
      "url" : "http:\/\/t.co\/5dM0uoNq5U",
      "expanded_url" : "http:\/\/instagram.com\/p\/oYojKKBwsw\/",
      "display_url" : "instagram.com\/p\/oYojKKBwsw\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1075, 8.764722222 ]
  },
  "id_str" : "470227447112138752",
  "text" : "World Wide Hard Core Fish Union @ HfG Offenbach http:\/\/t.co\/5dM0uoNq5U",
  "id" : 470227447112138752,
  "created_at" : "2014-05-24 15:38:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan North",
      "screen_name" : "ryanqnorth",
      "indices" : [ 3, 14 ],
      "id_str" : "14162415",
      "id" : 14162415
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/ryanqnorth\/status\/470213748083286016\/photo\/1",
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/qSY8xnXQsK",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BoaI6Y9CUAAulEV.jpg",
      "id_str" : "470213747819040768",
      "id" : 470213747819040768,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BoaI6Y9CUAAulEV.jpg",
      "sizes" : [ {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 3264,
        "resize" : "fit",
        "w" : 2448
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      } ],
      "display_url" : "pic.twitter.com\/qSY8xnXQsK"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "470227232703938560",
  "text" : "RT @ryanqnorth: start your day right... with shower ice cream http:\/\/t.co\/qSY8xnXQsK",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ryanqnorth\/status\/470213748083286016\/photo\/1",
        "indices" : [ 46, 68 ],
        "url" : "http:\/\/t.co\/qSY8xnXQsK",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BoaI6Y9CUAAulEV.jpg",
        "id_str" : "470213747819040768",
        "id" : 470213747819040768,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BoaI6Y9CUAAulEV.jpg",
        "sizes" : [ {
          "h" : 1200,
          "resize" : "fit",
          "w" : 900
        }, {
          "h" : 3264,
          "resize" : "fit",
          "w" : 2448
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1536
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 510
        } ],
        "display_url" : "pic.twitter.com\/qSY8xnXQsK"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "470213748083286016",
    "text" : "start your day right... with shower ice cream http:\/\/t.co\/qSY8xnXQsK",
    "id" : 470213748083286016,
    "created_at" : "2014-05-24 14:44:28 +0000",
    "user" : {
      "name" : "Ryan North",
      "screen_name" : "ryanqnorth",
      "protected" : false,
      "id_str" : "14162415",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/926142482743681024\/hCXzp300_normal.jpg",
      "id" : 14162415,
      "verified" : true
    }
  },
  "id" : 470227232703938560,
  "created_at" : "2014-05-24 15:38:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    }, {
      "name" : "dvzrv",
      "screen_name" : "dvzrv",
      "indices" : [ 7, 13 ],
      "id_str" : "30868098",
      "id" : 30868098
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "470216815344623617",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1080748147, 8.765082076 ]
  },
  "id_str" : "470218635907440641",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot @dvzrv I don\u2019t want to fly handk\u00E4s runs. I don\u2019t want to be in the war anymore!",
  "id" : 470218635907440641,
  "in_reply_to_status_id" : 470216815344623617,
  "created_at" : "2014-05-24 15:03:53 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dvzrv",
      "screen_name" : "dvzrv",
      "indices" : [ 0, 6 ],
      "id_str" : "30868098",
      "id" : 30868098
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "470211954502795264",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1080417107, 8.7650903342 ]
  },
  "id_str" : "470214666007085056",
  "in_reply_to_user_id" : 30868098,
  "text" : "@dvzrv wie weit ist das von der HfG aus? :)",
  "id" : 470214666007085056,
  "in_reply_to_status_id" : 470211954502795264,
  "created_at" : "2014-05-24 14:48:07 +0000",
  "in_reply_to_screen_name" : "dvzrv",
  "in_reply_to_user_id_str" : "30868098",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bodyandcloud",
      "indices" : [ 86, 99 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.108042234, 8.7650916057 ]
  },
  "id_str" : "470214500923506689",
  "text" : "\u00ABLuftfahrrad fahren. Das hei\u00DFt auf Niederl\u00E4ndisch so viel wie \u2018Hirngespinste haben\u2019.\u00BB #bodyandcloud",
  "id" : 470214500923506689,
  "created_at" : "2014-05-24 14:47:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bodyandcloud",
      "indices" : [ 75, 88 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.108067456, 8.7650620736 ]
  },
  "id_str" : "470206223401615360",
  "text" : "\u00ABWorum geht es gerade?\u00BB \u2014 \u00ABOral Traditions.\u00BB \u2014 \u00ABAh, langweilige Blowjobs.\u00BB #bodyandcloud",
  "id" : 470206223401615360,
  "created_at" : "2014-05-24 14:14:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bodyandcloud",
      "indices" : [ 0, 13 ]
    } ],
    "urls" : [ {
      "indices" : [ 30, 52 ],
      "url" : "http:\/\/t.co\/AdMv2ZElCH",
      "expanded_url" : "http:\/\/instagram.com\/p\/oYdzj3hwpc\/",
      "display_url" : "instagram.com\/p\/oYdzj3hwpc\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1075, 8.764722222 ]
  },
  "id_str" : "470203821600161792",
  "text" : "#bodyandcloud @ HfG Offenbach http:\/\/t.co\/AdMv2ZElCH",
  "id" : 470203821600161792,
  "created_at" : "2014-05-24 14:05:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bodyandcloud",
      "indices" : [ 75, 88 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1078913774, 8.7650805865 ]
  },
  "id_str" : "470202445344563200",
  "text" : "\u00ABWir k\u00F6nnen alles programmieren! Auch Liebe! Alles eine Frage des Geldes!\u00BB #bodyandcloud",
  "id" : 470202445344563200,
  "created_at" : "2014-05-24 13:59:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bodyandcloud",
      "indices" : [ 19, 32 ]
    } ],
    "urls" : [ {
      "indices" : [ 49, 71 ],
      "url" : "http:\/\/t.co\/L6Vhrr0wBm",
      "expanded_url" : "http:\/\/instagram.com\/p\/oYb0Anhwli\/",
      "display_url" : "instagram.com\/p\/oYb0Anhwli\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1075, 8.764722222 ]
  },
  "id_str" : "470199438728626177",
  "text" : "L\u00F6ten in der Sonne #bodyandcloud @ HfG Offenbach http:\/\/t.co\/L6Vhrr0wBm",
  "id" : 470199438728626177,
  "created_at" : "2014-05-24 13:47:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 7, 29 ],
      "url" : "http:\/\/t.co\/IRtpSyMgKL",
      "expanded_url" : "http:\/\/instagram.com\/p\/oYXWuMBwut\/",
      "display_url" : "instagram.com\/p\/oYXWuMBwut\/"
    } ]
  },
  "geo" : { },
  "id_str" : "470189635725828097",
  "text" : "Gollum http:\/\/t.co\/IRtpSyMgKL",
  "id" : 470189635725828097,
  "created_at" : "2014-05-24 13:08:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 54 ],
      "url" : "http:\/\/t.co\/VGFlaB3seW",
      "expanded_url" : "http:\/\/instagram.com\/p\/oYRgfRhwmX\/",
      "display_url" : "instagram.com\/p\/oYRgfRhwmX\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1075, 8.764722222 ]
  },
  "id_str" : "470176777449402368",
  "text" : "Hipster Central @ HfG Offenbach http:\/\/t.co\/VGFlaB3seW",
  "id" : 470176777449402368,
  "created_at" : "2014-05-24 12:17:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dvzrv",
      "screen_name" : "dvzrv",
      "indices" : [ 0, 6 ],
      "id_str" : "30868098",
      "id" : 30868098
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "470173007827468288",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1079132269, 8.7650817912 ]
  },
  "id_str" : "470173301185445890",
  "in_reply_to_user_id" : 30868098,
  "text" : "@dvzrv nope, but thunderbolt to VGA   ETA: 1min",
  "id" : 470173301185445890,
  "in_reply_to_status_id" : 470173007827468288,
  "created_at" : "2014-05-24 12:03:45 +0000",
  "in_reply_to_screen_name" : "dvzrv",
  "in_reply_to_user_id_str" : "30868098",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 10, 19 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/nptHoQCWWD",
      "expanded_url" : "https:\/\/www.piratenpartei.de\/2014\/05\/24\/julia-reda-europa-grenzenlos-ein-wahlaufruf\/",
      "display_url" : "piratenpartei.de\/2014\/05\/24\/jul\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1068060286, 8.6469298926 ]
  },
  "id_str" : "470167124410109952",
  "text" : "Ich w\u00E4hle @senficon f\u00FCr einen Weltraumaufzug und eine gr\u00F6\u00DFere Wohnung! https:\/\/t.co\/nptHoQCWWD",
  "id" : 470167124410109952,
  "created_at" : "2014-05-24 11:39:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 35 ],
      "url" : "http:\/\/t.co\/nWN9BeueHI",
      "expanded_url" : "http:\/\/instagram.com\/p\/oYLjJyhwtf\/",
      "display_url" : "instagram.com\/p\/oYLjJyhwtf\/"
    } ]
  },
  "geo" : { },
  "id_str" : "470163674062012416",
  "text" : "sounds legit http:\/\/t.co\/nWN9BeueHI",
  "id" : 470163674062012416,
  "created_at" : "2014-05-24 11:25:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Berufsquerulant",
      "screen_name" : "Stefan51278",
      "indices" : [ 0, 12 ],
      "id_str" : "18631049",
      "id" : 18631049
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "470157716103892992",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1043756337, 8.6188328789 ]
  },
  "id_str" : "470158133516853249",
  "in_reply_to_user_id" : 18631049,
  "text" : "@Stefan51278 als ich die Notification sah dachte ich an \u2018we can\u2019t stop here, this is EDGE-land\u2019 ;)",
  "id" : 470158133516853249,
  "in_reply_to_status_id" : 470157716103892992,
  "created_at" : "2014-05-24 11:03:28 +0000",
  "in_reply_to_screen_name" : "Stefan51278",
  "in_reply_to_user_id_str" : "18631049",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Berufsquerulant",
      "screen_name" : "Stefan51278",
      "indices" : [ 0, 12 ],
      "id_str" : "18631049",
      "id" : 18631049
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "470150653302820865",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1014237038, 8.560981196 ]
  },
  "id_str" : "470157561404985344",
  "in_reply_to_user_id" : 18631049,
  "text" : "@Stefan51278 ich sollte mir Bahn-Philosoph in die Bio schreiben. ;)",
  "id" : 470157561404985344,
  "in_reply_to_status_id" : 470150653302820865,
  "created_at" : "2014-05-24 11:01:12 +0000",
  "in_reply_to_screen_name" : "Stefan51278",
  "in_reply_to_user_id_str" : "18631049",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1007703521, 8.5336641526 ]
  },
  "id_str" : "470155912947458048",
  "text" : "\u00ABIch frage dich um Rat weil du mich nicht verurteilen wirst.\u00BB \u2014 \u00ABDu willst also meine moralische Einsch\u00E4tzung weil ich keine Moral habe\u2026\u00BB",
  "id" : 470155912947458048,
  "created_at" : "2014-05-24 10:54:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dvzrv",
      "screen_name" : "dvzrv",
      "indices" : [ 0, 6 ],
      "id_str" : "30868098",
      "id" : 30868098
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "470120741166669824",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095846659, 8.2829080718 ]
  },
  "id_str" : "470124106953003008",
  "in_reply_to_user_id" : 30868098,
  "text" : "@dvzrv will be there around 1425, just got up. :)",
  "id" : 470124106953003008,
  "in_reply_to_status_id" : 470120741166669824,
  "created_at" : "2014-05-24 08:48:16 +0000",
  "in_reply_to_screen_name" : "dvzrv",
  "in_reply_to_user_id_str" : "30868098",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095352434, 8.282654593 ]
  },
  "id_str" : "469991661909852160",
  "text" : "\u00ABPinkelst du immer so weit?\u00BB \u2014 \u00ABJa, meistens bist du nur vorher im Weg.\u00BB",
  "id" : 469991661909852160,
  "created_at" : "2014-05-24 00:01:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "469989066126393344",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095352434, 8.282654593 ]
  },
  "id_str" : "469991253372055552",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC I guess it makes a difference whether medical procedures force you or you make a free decision based on expected pleasure.",
  "id" : 469991253372055552,
  "in_reply_to_status_id" : 469989066126393344,
  "created_at" : "2014-05-24 00:00:21 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bodyandcloud",
      "indices" : [ 26, 39 ]
    } ],
    "urls" : [ {
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/68iDPMV8tR",
      "expanded_url" : "http:\/\/instagram.com\/p\/oWaSbQhwtP\/",
      "display_url" : "instagram.com\/p\/oWaSbQhwtP\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.107445074, 8.771173484 ]
  },
  "id_str" : "469914610569871361",
  "text" : "Diese Gottverdammte Stadt #bodyandcloud @ Mainufer Offenbach http:\/\/t.co\/68iDPMV8tR",
  "id" : 469914610569871361,
  "created_at" : "2014-05-23 18:55:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1080088838, 8.7653379289 ]
  },
  "id_str" : "469912621442138112",
  "text" : "\u00ABOffenbach ist auch so ein Holodeck.\u00BB \u2014 \u00ABDu meinst ein Prolo-Deck.\u00BB",
  "id" : 469912621442138112,
  "created_at" : "2014-05-23 18:47:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.108085238, 8.7649621193 ]
  },
  "id_str" : "469890527610302465",
  "text" : "\u00ABBesorg uns lieber noch ne Mate statt mich hier Hipster zu schimpfen!\u00BB",
  "id" : 469890527610302465,
  "created_at" : "2014-05-23 17:20:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1080413982, 8.7650984412 ]
  },
  "id_str" : "469888441577406464",
  "text" : "\u00ABLieutenant LaForge benutzt ein Personalpronomen.\u00BB TNG \u2014 Die fr\u00FChen Jahre",
  "id" : 469888441577406464,
  "created_at" : "2014-05-23 17:11:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "469886781715132416",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1080583873, 8.7650030957 ]
  },
  "id_str" : "469887268233412611",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich &lt;3",
  "id" : 469887268233412611,
  "in_reply_to_status_id" : 469886781715132416,
  "created_at" : "2014-05-23 17:07:09 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "469885376430370816",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1080342797, 8.765156747 ]
  },
  "id_str" : "469886448385417217",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich warte auf meine n\u00E4chsten Posts bei Vine und Instagram!",
  "id" : 469886448385417217,
  "in_reply_to_status_id" : 469885376430370816,
  "created_at" : "2014-05-23 17:03:54 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/QmwowhjxLb",
      "expanded_url" : "http:\/\/www.nerve.com\/love-sex\/true-stories\/sensible-sounding-why-i-inserted-a-metal-rod-into-my-penis-on-purpose",
      "display_url" : "nerve.com\/love-sex\/true-\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1080347967, 8.7650312721 ]
  },
  "id_str" : "469885061698170880",
  "text" : "Sensible Sounding: Why I Inserted a Metal Rod into My Penis on Purpose http:\/\/t.co\/QmwowhjxLb",
  "id" : 469885061698170880,
  "created_at" : "2014-05-23 16:58:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/veIHZAgXRg",
      "expanded_url" : "https:\/\/www.vocativ.com\/underworld\/crime\/exclusive-interview-elf-dropped-acid-jousted-car\/",
      "display_url" : "vocativ.com\/underworld\/cri\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723336829, 8.6276165514 ]
  },
  "id_str" : "469820076276060160",
  "text" : "An Exclusive Interview With the Elf Who Dropped Acid and Jousted a Car https:\/\/t.co\/veIHZAgXRg",
  "id" : 469820076276060160,
  "created_at" : "2014-05-23 12:40:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 71, 83 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/XTQrD2riB9",
      "expanded_url" : "https:\/\/medium.com\/message\/81e5f33a24e1",
      "display_url" : "medium.com\/message\/81e5f3\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723336829, 8.6276165514 ]
  },
  "id_str" : "469809691665920000",
  "text" : "On Computers &amp; Security: \u00ABBy now, you know this ends in tears.\u00BB RT @helgerausch: Everything Is Broken https:\/\/t.co\/XTQrD2riB9",
  "id" : 469809691665920000,
  "created_at" : "2014-05-23 11:58:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/sAXsmAT8gP",
      "expanded_url" : "http:\/\/www.nerve.com\/love-sex\/this-wall-of-wiggling-penises-is-mesmerizing",
      "display_url" : "nerve.com\/love-sex\/this-\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723336829, 8.6276165514 ]
  },
  "id_str" : "469793845254045696",
  "text" : "\u00ABThis Wall of Wiggling Penises Is Absolutely Mesmerizing\u00BB http:\/\/t.co\/sAXsmAT8gP",
  "id" : 469793845254045696,
  "created_at" : "2014-05-23 10:55:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723336829, 8.6276165514 ]
  },
  "id_str" : "469772181837475841",
  "text" : "Spring cleaning aka \u2018somehow I completely filled our 25 TB of storage and people start getting mad at me because of it\u2019.",
  "id" : 469772181837475841,
  "created_at" : "2014-05-23 09:29:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "catch22",
      "indices" : [ 106, 114 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723336829, 8.6276165514 ]
  },
  "id_str" : "469765103819423744",
  "text" : "Need motor skills to refill the coffee grinder. Without having a coffee my motor skills are non-existent. #catch22",
  "id" : 469765103819423744,
  "created_at" : "2014-05-23 09:01:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/gRnoIPKCMv",
      "expanded_url" : "http:\/\/whatshouldwecallgradschool.tumblr.com\/post\/86559182811\/after-a-16-hour-day",
      "display_url" : "whatshouldwecallgradschool.tumblr.com\/post\/865591828\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723336829, 8.6276165514 ]
  },
  "id_str" : "469756526501310465",
  "text" : "http:\/\/t.co\/gRnoIPKCMv",
  "id" : 469756526501310465,
  "created_at" : "2014-05-23 08:27:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 3, 16 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 70 ],
      "url" : "http:\/\/t.co\/qV33wFvzqa",
      "expanded_url" : "http:\/\/f1000research.com\/articles\/3-80\/v1",
      "display_url" : "f1000research.com\/articles\/3-80\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "469731447470043136",
  "text" : "RT @PhilippBayer: On genomics, kin, and privacy http:\/\/t.co\/qV33wFvzqa",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 30, 52 ],
        "url" : "http:\/\/t.co\/qV33wFvzqa",
        "expanded_url" : "http:\/\/f1000research.com\/articles\/3-80\/v1",
        "display_url" : "f1000research.com\/articles\/3-80\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "469729269132697600",
    "text" : "On genomics, kin, and privacy http:\/\/t.co\/qV33wFvzqa",
    "id" : 469729269132697600,
    "created_at" : "2014-05-23 06:39:19 +0000",
    "user" : {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "protected" : false,
      "id_str" : "121777206",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2013711027\/IMG_1088_normal.png",
      "id" : 121777206,
      "verified" : false
    }
  },
  "id" : 469731447470043136,
  "created_at" : "2014-05-23 06:47:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096292267, 8.2829992117 ]
  },
  "id_str" : "469618202277056513",
  "text" : "\u00ABWas ist mit deinem Arm?\u00BB \u2013 \u00ABIch hatte meinen ersten Arbeitsunfall. Ich bin beim Fussballspielen auf der nassen Dachterrasse ausgerutscht.\u00BB",
  "id" : 469618202277056513,
  "created_at" : "2014-05-22 23:17:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 75 ],
      "url" : "http:\/\/t.co\/amFCMrGJGT",
      "expanded_url" : "http:\/\/boingboing.net\/2014\/05\/22\/dont-believe-everything-you.html",
      "display_url" : "boingboing.net\/2014\/05\/22\/don\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096292267, 8.2829992117 ]
  },
  "id_str" : "469611316492378113",
  "text" : "Everything you know about teenage brains is\u00A0bullshit http:\/\/t.co\/amFCMrGJGT",
  "id" : 469611316492378113,
  "created_at" : "2014-05-22 22:50:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/Od8iExt7rQ",
      "expanded_url" : "http:\/\/imgur.com\/gallery\/LUm4g",
      "display_url" : "imgur.com\/gallery\/LUm4g"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096292267, 8.2829992117 ]
  },
  "id_str" : "469608563573547008",
  "text" : "added to the list of things that would never work with my cats: http:\/\/t.co\/Od8iExt7rQ",
  "id" : 469608563573547008,
  "created_at" : "2014-05-22 22:39:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ed Yong",
      "screen_name" : "edyong209",
      "indices" : [ 3, 13 ],
      "id_str" : "19767193",
      "id" : 19767193
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "evolutionWTF",
      "indices" : [ 112, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "469605984097558528",
  "text" : "RT @edyong209: Surprise! The closest relative of the towering extinct elephant bird of Madagascar is\u2026 the kiwi. #evolutionWTF http:\/\/t.co\/W\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "evolutionWTF",
        "indices" : [ 97, 110 ]
      } ],
      "urls" : [ {
        "indices" : [ 111, 133 ],
        "url" : "http:\/\/t.co\/Wt1Y4JhCUD",
        "expanded_url" : "http:\/\/phenomena.nationalgeographic.com\/2014\/05\/22\/the-surprising-closest-relative-of-the-huge-elephant-birds\/",
        "display_url" : "phenomena.nationalgeographic.com\/2014\/05\/22\/the\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "469541148298842112",
    "text" : "Surprise! The closest relative of the towering extinct elephant bird of Madagascar is\u2026 the kiwi. #evolutionWTF http:\/\/t.co\/Wt1Y4JhCUD",
    "id" : 469541148298842112,
    "created_at" : "2014-05-22 18:11:48 +0000",
    "user" : {
      "name" : "Ed Yong",
      "screen_name" : "edyong209",
      "protected" : false,
      "id_str" : "19767193",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/926063794912153600\/962ygzzx_normal.jpg",
      "id" : 19767193,
      "verified" : true
    }
  },
  "id" : 469605984097558528,
  "created_at" : "2014-05-22 22:29:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/HwuHVso4Tu",
      "expanded_url" : "http:\/\/www.nytimes.com\/2014\/05\/25\/magazine\/my-no-soap-no-shampoo-bacteria-rich-hygiene-experiment.html?_r=0",
      "display_url" : "nytimes.com\/2014\/05\/25\/mag\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.155893, 8.590793 ]
  },
  "id_str" : "469579843072700417",
  "text" : "\u00ABMy No-Soap, No-Shampoo, Bacteria-Rich Hygiene Experiment\u00BB http:\/\/t.co\/HwuHVso4Tu",
  "id" : 469579843072700417,
  "created_at" : "2014-05-22 20:45:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 8, 31 ],
      "url" : "https:\/\/t.co\/NI3xfC7kW9",
      "expanded_url" : "https:\/\/www.kickstarter.com\/projects\/erikamoen\/oh-joy-sex-toy-the-book\/posts\/852293",
      "display_url" : "kickstarter.com\/projects\/erika\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723415586, 8.6276149857 ]
  },
  "id_str" : "469510394361708544",
  "text" : "Yay \\o\/ https:\/\/t.co\/NI3xfC7kW9",
  "id" : 469510394361708544,
  "created_at" : "2014-05-22 16:09:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "469503404902187008",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723415586, 8.6276149857 ]
  },
  "id_str" : "469506513787424768",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot I blame the esoteric outfit for making the misanthrope pass as the great philanthropist.",
  "id" : 469506513787424768,
  "in_reply_to_status_id" : 469503404902187008,
  "created_at" : "2014-05-22 15:54:10 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fabian Zimmer",
      "screen_name" : "fbnzimmer",
      "indices" : [ 0, 10 ],
      "id_str" : "1515775878",
      "id" : 1515775878
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "469497186687123456",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723415586, 8.6276149857 ]
  },
  "id_str" : "469502918098685952",
  "in_reply_to_user_id" : 1515775878,
  "text" : "@fbnzimmer yeah, though I don\u2019t care about that too much any longer, I just stopped caring about missing out. :p",
  "id" : 469502918098685952,
  "in_reply_to_status_id" : 469497186687123456,
  "created_at" : "2014-05-22 15:39:53 +0000",
  "in_reply_to_screen_name" : "fbnzimmer",
  "in_reply_to_user_id_str" : "1515775878",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723415586, 8.6276149857 ]
  },
  "id_str" : "469502574484520960",
  "text" : "Students have a warped perception of me: \u00ABHe will rip off his t-shirt &amp; underneath he\u2019s wearing a second one, saying: \u2018I love you all\u2019.\u00BB",
  "id" : 469502574484520960,
  "created_at" : "2014-05-22 15:38:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Weber",
      "screen_name" : "scy",
      "indices" : [ 0, 4 ],
      "id_str" : "8308632",
      "id" : 8308632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 5, 27 ],
      "url" : "http:\/\/t.co\/Vwfeu5DcWm",
      "expanded_url" : "http:\/\/static.fjcdn.com\/gifs\/Doctor_5506c2_2429420.gif",
      "display_url" : "static.fjcdn.com\/gifs\/Doctor_55\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "469491971846049793",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723415586, 8.6276149857 ]
  },
  "id_str" : "469494145430867968",
  "in_reply_to_user_id" : 8308632,
  "text" : "@scy http:\/\/t.co\/Vwfeu5DcWm",
  "id" : 469494145430867968,
  "in_reply_to_status_id" : 469491971846049793,
  "created_at" : "2014-05-22 15:05:01 +0000",
  "in_reply_to_screen_name" : "scy",
  "in_reply_to_user_id_str" : "8308632",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 62 ],
      "url" : "http:\/\/t.co\/THwCwZSdH0",
      "expanded_url" : "http:\/\/boingboing.net\/2014\/05\/22\/cyberpocalypse-the-cyberpunk.html",
      "display_url" : "boingboing.net\/2014\/05\/22\/cyb\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723415586, 8.6276149857 ]
  },
  "id_str" : "469491878250172417",
  "text" : "Cyberpocalypse: the cyberpunk Lego\u00A0city http:\/\/t.co\/THwCwZSdH0",
  "id" : 469491878250172417,
  "created_at" : "2014-05-22 14:56:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fabian Zimmer",
      "screen_name" : "fbnzimmer",
      "indices" : [ 0, 10 ],
      "id_str" : "1515775878",
      "id" : 1515775878
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "469489342764023808",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723415586, 8.6276149857 ]
  },
  "id_str" : "469491591183626240",
  "in_reply_to_user_id" : 1515775878,
  "text" : "@fbnzimmer I\u2019m mainly using it as the iOS clients are really cool and they sync, so no matter which device: you are where you stopped readin",
  "id" : 469491591183626240,
  "in_reply_to_status_id" : 469489342764023808,
  "created_at" : "2014-05-22 14:54:52 +0000",
  "in_reply_to_screen_name" : "fbnzimmer",
  "in_reply_to_user_id_str" : "1515775878",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fabian Zimmer",
      "screen_name" : "fbnzimmer",
      "indices" : [ 0, 10 ],
      "id_str" : "1515775878",
      "id" : 1515775878
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/469487898447056896\/photo\/1",
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/0fad6jwpxz",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BoP0wYBIIAAx7k7.png",
      "id_str" : "469487898094739456",
      "id" : 469487898094739456,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BoP0wYBIIAAx7k7.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 761,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 431,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1138,
        "resize" : "fit",
        "w" : 1794
      }, {
        "h" : 1138,
        "resize" : "fit",
        "w" : 1794
      } ],
      "display_url" : "pic.twitter.com\/0fad6jwpxz"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 42 ],
      "url" : "http:\/\/t.co\/a3uYgURa5x",
      "expanded_url" : "http:\/\/tapbots.com\/software\/tweetbot\/mac\/",
      "display_url" : "tapbots.com\/software\/tweet\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "469487053777158144",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723415586, 8.6276149857 ]
  },
  "id_str" : "469487898447056896",
  "in_reply_to_user_id" : 1515775878,
  "text" : "@fbnzimmer Tweetbot http:\/\/t.co\/a3uYgURa5x Looks like this http:\/\/t.co\/0fad6jwpxz",
  "id" : 469487898447056896,
  "in_reply_to_status_id" : 469487053777158144,
  "created_at" : "2014-05-22 14:40:12 +0000",
  "in_reply_to_screen_name" : "fbnzimmer",
  "in_reply_to_user_id_str" : "1515775878",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fabian Zimmer",
      "screen_name" : "fbnzimmer",
      "indices" : [ 0, 10 ],
      "id_str" : "1515775878",
      "id" : 1515775878
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "469432839361265664",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723194083, 8.6276321872 ]
  },
  "id_str" : "469434415681404928",
  "in_reply_to_user_id" : 1515775878,
  "text" : "@fbnzimmer do them in Open Office, paste to Lyx, export to LaTeX ;)",
  "id" : 469434415681404928,
  "in_reply_to_status_id" : 469432839361265664,
  "created_at" : "2014-05-22 11:07:41 +0000",
  "in_reply_to_screen_name" : "fbnzimmer",
  "in_reply_to_user_id_str" : "1515775878",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fabian Zimmer",
      "screen_name" : "fbnzimmer",
      "indices" : [ 0, 10 ],
      "id_str" : "1515775878",
      "id" : 1515775878
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "469429892791406592",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723415586, 8.6276149857 ]
  },
  "id_str" : "469432389501214720",
  "in_reply_to_user_id" : 1515775878,
  "text" : "@fbnzimmer yeah, \u201Cwere\u201D, right\u2026 ;)",
  "id" : 469432389501214720,
  "in_reply_to_status_id" : 469429892791406592,
  "created_at" : "2014-05-22 10:59:37 +0000",
  "in_reply_to_screen_name" : "fbnzimmer",
  "in_reply_to_user_id_str" : "1515775878",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723415586, 8.6276149857 ]
  },
  "id_str" : "469428072861958144",
  "text" : "The LaTeX syntax for creating tables. Leading cause for alcoholism amongst academics.",
  "id" : 469428072861958144,
  "created_at" : "2014-05-22 10:42:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 49 ],
      "url" : "http:\/\/t.co\/tJNR1xarPX",
      "expanded_url" : "http:\/\/fc00.deviantart.net\/fs70\/f\/2013\/271\/6\/4\/ceci_nest_pas_une_pipette_by_prooffreader-d6oa27q.png",
      "display_url" : "fc00.deviantart.net\/fs70\/f\/2013\/27\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723415586, 8.6276149857 ]
  },
  "id_str" : "469405373070594049",
  "text" : "Ceci n'est pas une pipette http:\/\/t.co\/tJNR1xarPX",
  "id" : 469405373070594049,
  "created_at" : "2014-05-22 09:12:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1109236263, 8.6882656482 ]
  },
  "id_str" : "469374974189662208",
  "text" : "The problem with just having a quick look whether my computations are still running fine before going to bed: you might see they are not\u2026",
  "id" : 469374974189662208,
  "created_at" : "2014-05-22 07:11:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dvzrv",
      "screen_name" : "dvzrv",
      "indices" : [ 0, 6 ],
      "id_str" : "30868098",
      "id" : 30868098
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 49, 62 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/qx4hSBOqXZ",
      "expanded_url" : "https:\/\/github.com\/philippbayer\/turbo-shame",
      "display_url" : "github.com\/philippbayer\/t\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "469256549014446082",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009636914, 8.283036846 ]
  },
  "id_str" : "469256943933345792",
  "in_reply_to_user_id" : 30868098,
  "text" : "@dvzrv no judgement on that. I can only say that @PhilippBayer and I had a unique style in the beginning as well ;) https:\/\/t.co\/qx4hSBOqXZ",
  "id" : 469256943933345792,
  "in_reply_to_status_id" : 469256549014446082,
  "created_at" : "2014-05-21 23:22:28 +0000",
  "in_reply_to_screen_name" : "dvzrv",
  "in_reply_to_user_id_str" : "30868098",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dvzrv",
      "screen_name" : "dvzrv",
      "indices" : [ 0, 6 ],
      "id_str" : "30868098",
      "id" : 30868098
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "469256082662359040",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009636914, 8.283036846 ]
  },
  "id_str" : "469256208130789377",
  "in_reply_to_user_id" : 30868098,
  "text" : "@dvzrv looking forward to it, I skimmed the code a bit today, looks crazy :D",
  "id" : 469256208130789377,
  "in_reply_to_status_id" : 469256082662359040,
  "created_at" : "2014-05-21 23:19:33 +0000",
  "in_reply_to_screen_name" : "dvzrv",
  "in_reply_to_user_id_str" : "30868098",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Malcolm M. Campbell",
      "screen_name" : "m_m_campbell",
      "indices" : [ 3, 16 ],
      "id_str" : "159951505",
      "id" : 159951505
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SixIncredibleThingsBeforeBreakfast",
      "indices" : [ 18, 53 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/CQfLQbPCPz",
      "expanded_url" : "http:\/\/phenomena.nationalgeographic.com\/2014\/05\/20\/parasite-forces-host-to-dig-its-own-grave\/",
      "display_url" : "phenomena.nationalgeographic.com\/2014\/05\/20\/par\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "469250660270342144",
  "text" : "RT @m_m_campbell: #SixIncredibleThingsBeforeBreakfast:\nGrave behaviour.\nParasite makes host dig its own tomb.\nhttp:\/\/t.co\/CQfLQbPCPz #insec\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Ed Yong",
        "screen_name" : "edyong209",
        "indices" : [ 127, 137 ],
        "id_str" : "19767193",
        "id" : 19767193
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SixIncredibleThingsBeforeBreakfast",
        "indices" : [ 0, 35 ]
      }, {
        "text" : "insects",
        "indices" : [ 115, 123 ]
      } ],
      "urls" : [ {
        "indices" : [ 92, 114 ],
        "url" : "http:\/\/t.co\/CQfLQbPCPz",
        "expanded_url" : "http:\/\/phenomena.nationalgeographic.com\/2014\/05\/20\/parasite-forces-host-to-dig-its-own-grave\/",
        "display_url" : "phenomena.nationalgeographic.com\/2014\/05\/20\/par\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "469074021397856256",
    "text" : "#SixIncredibleThingsBeforeBreakfast:\nGrave behaviour.\nParasite makes host dig its own tomb.\nhttp:\/\/t.co\/CQfLQbPCPz #insects by @edyong209",
    "id" : 469074021397856256,
    "created_at" : "2014-05-21 11:15:36 +0000",
    "user" : {
      "name" : "Malcolm M. Campbell",
      "screen_name" : "m_m_campbell",
      "protected" : false,
      "id_str" : "159951505",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1752503297\/260714_100000752280655_74601805_n_normal.jpg",
      "id" : 159951505,
      "verified" : false
    }
  },
  "id" : 469250660270342144,
  "created_at" : "2014-05-21 22:57:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathan Eisen, Guardian of Microbial Diversity \uD83D\uDCA5\uD83D\uDD06",
      "screen_name" : "phylogenomics",
      "indices" : [ 3, 17 ],
      "id_str" : "15154811",
      "id" : 15154811
    }, {
      "name" : "Paula Olsiewski",
      "screen_name" : "polsiewski",
      "indices" : [ 122, 133 ],
      "id_str" : "196263489",
      "id" : 196263489
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/Z2uZI6INw9",
      "expanded_url" : "http:\/\/www.bu.edu\/news\/2014\/05\/19\/boston-universitys-141st-commencement-baccalaureate-address-nancy-hopkins\/",
      "display_url" : "bu.edu\/news\/2014\/05\/1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "469248617694629888",
  "text" : "RT @phylogenomics: An important read: Nancy Hopkins' commencement address to BU on gender bias http:\/\/t.co\/Z2uZI6INw9 h\/t @polsiewski",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Paula Olsiewski",
        "screen_name" : "polsiewski",
        "indices" : [ 103, 114 ],
        "id_str" : "196263489",
        "id" : 196263489
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 76, 98 ],
        "url" : "http:\/\/t.co\/Z2uZI6INw9",
        "expanded_url" : "http:\/\/www.bu.edu\/news\/2014\/05\/19\/boston-universitys-141st-commencement-baccalaureate-address-nancy-hopkins\/",
        "display_url" : "bu.edu\/news\/2014\/05\/1\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "469245110933553153",
    "text" : "An important read: Nancy Hopkins' commencement address to BU on gender bias http:\/\/t.co\/Z2uZI6INw9 h\/t @polsiewski",
    "id" : 469245110933553153,
    "created_at" : "2014-05-21 22:35:27 +0000",
    "user" : {
      "name" : "Jonathan Eisen, Guardian of Microbial Diversity \uD83D\uDCA5\uD83D\uDD06",
      "screen_name" : "phylogenomics",
      "protected" : false,
      "id_str" : "15154811",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/751288576403382273\/AKfTiFxx_normal.jpg",
      "id" : 15154811,
      "verified" : true
    }
  },
  "id" : 469248617694629888,
  "created_at" : "2014-05-21 22:49:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rachel Kalmar",
      "screen_name" : "grapealope",
      "indices" : [ 3, 14 ],
      "id_str" : "18372260",
      "id" : 18372260
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/w26iCfncPg",
      "expanded_url" : "http:\/\/solidcon.com\/solid2014\/public\/schedule\/detail\/33074",
      "display_url" : "solidcon.com\/solid2014\/publ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "469240315732566016",
  "text" : "RT @grapealope: What's the environmental impact of all that 3D printing? http:\/\/t.co\/w26iCfncPg (I propose printing prototypes with chocola\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "OReillySolid",
        "indices" : [ 127, 140 ]
      } ],
      "urls" : [ {
        "indices" : [ 57, 79 ],
        "url" : "http:\/\/t.co\/w26iCfncPg",
        "expanded_url" : "http:\/\/solidcon.com\/solid2014\/public\/schedule\/detail\/33074",
        "display_url" : "solidcon.com\/solid2014\/publ\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "469240142558146560",
    "text" : "What's the environmental impact of all that 3D printing? http:\/\/t.co\/w26iCfncPg (I propose printing prototypes with chocolate) #OReillySolid",
    "id" : 469240142558146560,
    "created_at" : "2014-05-21 22:15:42 +0000",
    "user" : {
      "name" : "Rachel Kalmar",
      "screen_name" : "grapealope",
      "protected" : false,
      "id_str" : "18372260",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1780881616\/rachelPortraitSq-sm_normal.jpg",
      "id" : 18372260,
      "verified" : false
    }
  },
  "id" : 469240315732566016,
  "created_at" : "2014-05-21 22:16:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009636914, 8.283036846 ]
  },
  "id_str" : "469238784002117632",
  "text" : "fixate nearly-neutral alleles by random genetic drift or die",
  "id" : 469238784002117632,
  "created_at" : "2014-05-21 22:10:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "469214940017201152",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095403, 8.2828841538 ]
  },
  "id_str" : "469215126009434112",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon sounds like those cupcakes you praised are not only vegan",
  "id" : 469215126009434112,
  "in_reply_to_status_id" : 469214940017201152,
  "created_at" : "2014-05-21 20:36:18 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 62, 71 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/BUWLD08aGR",
      "expanded_url" : "http:\/\/www.katu.com\/news\/local\/Womans-car-attacked-by-self-identified-high-elf-battling-evil-259598811.html",
      "display_url" : "katu.com\/news\/local\/Wom\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095403, 8.2828841538 ]
  },
  "id_str" : "469214218039091200",
  "text" : "This is how you should have tried to convince me of Portland, @Senficon http:\/\/t.co\/BUWLD08aGR",
  "id" : 469214218039091200,
  "created_at" : "2014-05-21 20:32:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "adapt",
      "indices" : [ 134, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0417358382, 8.4579919092 ]
  },
  "id_str" : "469169609334333440",
  "text" : "\u00ABThe moral is not that we should admire stubborn geniuses. It\u2019s that we shouldn\u2019t require stubbornness as a quality in our geniuses.\u00BB #adapt",
  "id" : 469169609334333440,
  "created_at" : "2014-05-21 17:35:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 75 ],
      "url" : "http:\/\/t.co\/s7K2biJqUh",
      "expanded_url" : "http:\/\/www.psychologytoday.com\/blog\/strictly-casual\/201405\/most-people-do-not-regret-their-hookups-much",
      "display_url" : "psychologytoday.com\/blog\/strictly-\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723415586, 8.6276149857 ]
  },
  "id_str" : "469148091736924161",
  "text" : "Casual sex is regretted a bit, but enjoyed much more http:\/\/t.co\/s7K2biJqUh",
  "id" : 469148091736924161,
  "created_at" : "2014-05-21 16:09:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 7, 29 ],
      "url" : "http:\/\/t.co\/46FS7r1LRw",
      "expanded_url" : "http:\/\/i.giflike.com\/CZXut8v.gif",
      "display_url" : "i.giflike.com\/CZXut8v.gif"
    } ]
  },
  "in_reply_to_status_id_str" : "469135569231286272",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723415586, 8.6276149857 ]
  },
  "id_str" : "469137708615745537",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot http:\/\/t.co\/46FS7r1LRw",
  "id" : 469137708615745537,
  "in_reply_to_status_id" : 469135569231286272,
  "created_at" : "2014-05-21 15:28:40 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/9txL7cvMqY",
      "expanded_url" : "http:\/\/rsbl.royalsocietypublishing.org\/content\/10\/4\/20131091.full",
      "display_url" : "rsbl.royalsocietypublishing.org\/content\/10\/4\/2\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723415586, 8.6276149857 ]
  },
  "id_str" : "469116575371788288",
  "text" : "Awesome, investigating the Red Queen hypothesis with snails: Exposure to parasites increases promiscuity http:\/\/t.co\/9txL7cvMqY",
  "id" : 469116575371788288,
  "created_at" : "2014-05-21 14:04:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nathan Pearson",
      "screen_name" : "GenomeNathan",
      "indices" : [ 55, 68 ],
      "id_str" : "543876839",
      "id" : 543876839
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/Imf5IGoOah",
      "expanded_url" : "http:\/\/mendelspod.com\/podcast\/philosophy-science-part-iv-nathan-pearson-scientist-responds",
      "display_url" : "mendelspod.com\/podcast\/philos\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723415586, 8.6276149857 ]
  },
  "id_str" : "469112267964182528",
  "text" : "Genomes, Language and Philosophy. A fun interview with @GenomeNathan http:\/\/t.co\/Imf5IGoOah",
  "id" : 469112267964182528,
  "created_at" : "2014-05-21 13:47:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 122, 144 ],
      "url" : "http:\/\/t.co\/JhhcEJIDAF",
      "expanded_url" : "http:\/\/blogs.scientificamerican.com\/primate-diaries\/2014\/05\/21\/on-the-origin-of-white-power\/",
      "display_url" : "blogs.scientificamerican.com\/primate-diarie\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723415586, 8.6276149857 ]
  },
  "id_str" : "469097984337399808",
  "text" : "On the Origin of White Power \u00ABwrong in its facts, sloppy in its logic &amp; blatantly misrepresents evolutionary biology\u00BB http:\/\/t.co\/JhhcEJIDAF",
  "id" : 469097984337399808,
  "created_at" : "2014-05-21 12:50:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723415586, 8.6276149857 ]
  },
  "id_str" : "469093639382380545",
  "text" : "People who ask me for help with their database structure clearly never looked into the openSNP database \u2018design\u2019.",
  "id" : 469093639382380545,
  "created_at" : "2014-05-21 12:33:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dvzrv",
      "screen_name" : "dvzrv",
      "indices" : [ 0, 6 ],
      "id_str" : "30868098",
      "id" : 30868098
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "469057687280713728",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723415586, 8.6276149857 ]
  },
  "id_str" : "469086109847535616",
  "in_reply_to_user_id" : 30868098,
  "text" : "@dvzrv you got mail",
  "id" : 469086109847535616,
  "in_reply_to_status_id" : 469057687280713728,
  "created_at" : "2014-05-21 12:03:38 +0000",
  "in_reply_to_screen_name" : "dvzrv",
  "in_reply_to_user_id_str" : "30868098",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SciLogs",
      "screen_name" : "scilogs",
      "indices" : [ 0, 8 ],
      "id_str" : "14980634",
      "id" : 14980634
    }, {
      "name" : "Dierk Haasis",
      "screen_name" : "Evo2Me",
      "indices" : [ 9, 16 ],
      "id_str" : "22910316",
      "id" : 22910316
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "469083310153809920",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723415586, 8.6276149857 ]
  },
  "id_str" : "469083429058129920",
  "in_reply_to_user_id" : 14980634,
  "text" : "@scilogs @Evo2Me gibt bestimmt schon eine South Park-Folge dar\u00FCber.",
  "id" : 469083429058129920,
  "in_reply_to_status_id" : 469083310153809920,
  "created_at" : "2014-05-21 11:52:59 +0000",
  "in_reply_to_screen_name" : "scilogs",
  "in_reply_to_user_id_str" : "14980634",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dierk Haasis",
      "screen_name" : "Evo2Me",
      "indices" : [ 0, 7 ],
      "id_str" : "22910316",
      "id" : 22910316
    }, {
      "name" : "SciLogs",
      "screen_name" : "scilogs",
      "indices" : [ 8, 16 ],
      "id_str" : "14980634",
      "id" : 14980634
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "469081417549635584",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723415586, 8.6276149857 ]
  },
  "id_str" : "469083004653297664",
  "in_reply_to_user_id" : 22910316,
  "text" : "@Evo2Me @scilogs hipster-hitler-mullah, die Vergleiche diese Woche werden immer besser!",
  "id" : 469083004653297664,
  "in_reply_to_status_id" : 469081417549635584,
  "created_at" : "2014-05-21 11:51:18 +0000",
  "in_reply_to_screen_name" : "Evo2Me",
  "in_reply_to_user_id_str" : "22910316",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723415586, 8.6276149857 ]
  },
  "id_str" : "469079905171677184",
  "text" : "\u00ABDas sind so \u00E4hnliche Menschen wie du. Also die haben auch einen Bart.\u00BB",
  "id" : 469079905171677184,
  "created_at" : "2014-05-21 11:38:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723415586, 8.6276149857 ]
  },
  "id_str" : "469051249682575360",
  "text" : "\u00ABIf you\u2019re reporting bugs like \u2018the dishwasher is broken\u2019 please give a detailed bug description.\u00BB",
  "id" : 469051249682575360,
  "created_at" : "2014-05-21 09:45:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bended Realities",
      "screen_name" : "bendedrealities",
      "indices" : [ 3, 19 ],
      "id_str" : "1332989701",
      "id" : 1332989701
    }, {
      "name" : "dvzrv",
      "screen_name" : "dvzrv",
      "indices" : [ 50, 56 ],
      "id_str" : "30868098",
      "id" : 30868098
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 83, 99 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "469050057049014272",
  "text" : "RT @bendedrealities: Sorry, my mistake: David aka @dvzrv will present the sound of @gedankenstuecke on Sunday, May 25th, 1 pm. Not Saturday!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "dvzrv",
        "screen_name" : "dvzrv",
        "indices" : [ 29, 35 ],
        "id_str" : "30868098",
        "id" : 30868098
      }, {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 62, 78 ],
        "id_str" : "14286491",
        "id" : 14286491
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "469046558663929857",
    "text" : "Sorry, my mistake: David aka @dvzrv will present the sound of @gedankenstuecke on Sunday, May 25th, 1 pm. Not Saturday!",
    "id" : 469046558663929857,
    "created_at" : "2014-05-21 09:26:28 +0000",
    "user" : {
      "name" : "Bended Realities",
      "screen_name" : "bendedrealities",
      "protected" : false,
      "id_str" : "1332989701",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/453446975455637504\/bIoGf0dC_normal.jpeg",
      "id" : 1332989701,
      "verified" : false
    }
  },
  "id" : 469050057049014272,
  "created_at" : "2014-05-21 09:40:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723363069, 8.6276167934 ]
  },
  "id_str" : "469042310089822208",
  "text" : "\u00ABWas?! Deine Freundin war gestern auch da?! Wird sie mir jetzt den Kopf abrei\u00DFen weil ich dir die Haare geflochten habe?\u00BB",
  "id" : 469042310089822208,
  "created_at" : "2014-05-21 09:09:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fabian Zimmer",
      "screen_name" : "fbnzimmer",
      "indices" : [ 35, 45 ],
      "id_str" : "1515775878",
      "id" : 1515775878
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/OHQnqvZxZ1",
      "expanded_url" : "http:\/\/existentialcomics.com\/comic\/29",
      "display_url" : "existentialcomics.com\/comic\/29"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.094907, 8.75201 ]
  },
  "id_str" : "468842051493441536",
  "text" : "We Must Imagine Sisyphus Happy \/cc @fbnzimmer  http:\/\/t.co\/OHQnqvZxZ1",
  "id" : 468842051493441536,
  "created_at" : "2014-05-20 19:53:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/0ygjwf4fLT",
      "expanded_url" : "http:\/\/www.psmag.com\/navigation\/health-and-behavior\/admitted-children-sex-primarily-pleasure-81691\/",
      "display_url" : "psmag.com\/navigation\/hea\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723415586, 8.6276149857 ]
  },
  "id_str" : "468762903622205440",
  "text" : "What If We Admitted to Children That Sex Is Primarily About Pleasure? http:\/\/t.co\/0ygjwf4fLT",
  "id" : 468762903622205440,
  "created_at" : "2014-05-20 14:39:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/AP7LNkSGHq",
      "expanded_url" : "http:\/\/instagram.com\/p\/oOC0mhhwue\/",
      "display_url" : "instagram.com\/p\/oOC0mhhwue\/"
    } ]
  },
  "geo" : { },
  "id_str" : "468737107679141891",
  "text" : "\u00ABYou're performing worse than clustalw on this alignment!\u00BB http:\/\/t.co\/AP7LNkSGHq",
  "id" : 468737107679141891,
  "created_at" : "2014-05-20 12:56:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/zO0TyegWrk",
      "expanded_url" : "http:\/\/instagram.com\/p\/oN9wXNhwoS\/",
      "display_url" : "instagram.com\/p\/oN9wXNhwoS\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172192593, 8.630112991 ]
  },
  "id_str" : "468725979901198336",
  "text" : "\u00ABPendelt ihr schon wieder Sequenzen aus?!\u00BB @ Goethe-Universit\u00E4t Frankfurt, Campus Riedberg http:\/\/t.co\/zO0TyegWrk",
  "id" : 468725979901198336,
  "created_at" : "2014-05-20 12:12:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723302811, 8.6276288043 ]
  },
  "id_str" : "468696396926029824",
  "text" : "\u00ABWas bastelt ihr da?\u00BB \u2014 \u00ABEine neue Compute-Node f\u00FCrs Cluster.\u00BB \u2014 \u00BBAber das ist ein Abakus?!\u00BB",
  "id" : 468696396926029824,
  "created_at" : "2014-05-20 10:15:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert Lanfear",
      "screen_name" : "RobLanfear",
      "indices" : [ 3, 14 ],
      "id_str" : "745320876",
      "id" : 745320876
    }, {
      "name" : "PLOS",
      "screen_name" : "PLOS",
      "indices" : [ 71, 76 ],
      "id_str" : "12819112",
      "id" : 12819112
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/RobLanfear\/status\/468543156108001280\/photo\/1",
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/F8BZSBLmud",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BoCZhBlIQAAUSyY.jpg",
      "id_str" : "468543153885429760",
      "id" : 468543153885429760,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BoCZhBlIQAAUSyY.jpg",
      "sizes" : [ {
        "h" : 596,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 920,
        "resize" : "fit",
        "w" : 1050
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 920,
        "resize" : "fit",
        "w" : 1050
      }, {
        "h" : 920,
        "resize" : "fit",
        "w" : 1050
      } ],
      "display_url" : "pic.twitter.com\/F8BZSBLmud"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "468545071324082176",
  "text" : "RT @RobLanfear: The distribution of significant p values  from all the @PLOS papers published so far... http:\/\/t.co\/F8BZSBLmud",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "PLOS",
        "screen_name" : "PLOS",
        "indices" : [ 55, 60 ],
        "id_str" : "12819112",
        "id" : 12819112
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/RobLanfear\/status\/468543156108001280\/photo\/1",
        "indices" : [ 88, 110 ],
        "url" : "http:\/\/t.co\/F8BZSBLmud",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BoCZhBlIQAAUSyY.jpg",
        "id_str" : "468543153885429760",
        "id" : 468543153885429760,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BoCZhBlIQAAUSyY.jpg",
        "sizes" : [ {
          "h" : 596,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 920,
          "resize" : "fit",
          "w" : 1050
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 920,
          "resize" : "fit",
          "w" : 1050
        }, {
          "h" : 920,
          "resize" : "fit",
          "w" : 1050
        } ],
        "display_url" : "pic.twitter.com\/F8BZSBLmud"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "468543156108001280",
    "text" : "The distribution of significant p values  from all the @PLOS papers published so far... http:\/\/t.co\/F8BZSBLmud",
    "id" : 468543156108001280,
    "created_at" : "2014-05-20 00:06:08 +0000",
    "user" : {
      "name" : "Robert Lanfear",
      "screen_name" : "RobLanfear",
      "protected" : false,
      "id_str" : "745320876",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/484920977222946816\/Rm9HHa2b_normal.jpeg",
      "id" : 745320876,
      "verified" : false
    }
  },
  "id" : 468545071324082176,
  "created_at" : "2014-05-20 00:13:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Weber",
      "screen_name" : "scy",
      "indices" : [ 0, 4 ],
      "id_str" : "8308632",
      "id" : 8308632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "468482625385283585",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1153519552, 8.6829472732 ]
  },
  "id_str" : "468483006462976000",
  "in_reply_to_user_id" : 8308632,
  "text" : "@scy k\u00FCmmere dich um deinen Penis und der Rest folgt?",
  "id" : 468483006462976000,
  "in_reply_to_status_id" : 468482625385283585,
  "created_at" : "2014-05-19 20:07:07 +0000",
  "in_reply_to_screen_name" : "scy",
  "in_reply_to_user_id_str" : "8308632",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Weber",
      "screen_name" : "scy",
      "indices" : [ 0, 4 ],
      "id_str" : "8308632",
      "id" : 8308632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "468480814217691137",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1153575383, 8.6829832464 ]
  },
  "id_str" : "468481823753113600",
  "in_reply_to_user_id" : 8308632,
  "text" : "@scy oh, warst du gestern auch auf der Esomesse? ;)",
  "id" : 468481823753113600,
  "in_reply_to_status_id" : 468480814217691137,
  "created_at" : "2014-05-19 20:02:25 +0000",
  "in_reply_to_screen_name" : "scy",
  "in_reply_to_user_id_str" : "8308632",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1153372629, 8.6829690492 ]
  },
  "id_str" : "468477144944095233",
  "text" : "\u00ABKrass, deine Haut schmeckt total nach den Gew\u00FCrzen die gerade im Essen waren! Nach Salz!\u00BB",
  "id" : 468477144944095233,
  "created_at" : "2014-05-19 19:43:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bended Realities",
      "screen_name" : "bendedrealities",
      "indices" : [ 3, 19 ],
      "id_str" : "1332989701",
      "id" : 1332989701
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 52, 68 ],
      "id_str" : "14286491",
      "id" : 14286491
    }, {
      "name" : "dvzrv",
      "screen_name" : "dvzrv",
      "indices" : [ 81, 87 ],
      "id_str" : "30868098",
      "id" : 30868098
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "468431303470485504",
  "text" : "RT @bendedrealities: You can listen to the sound of @gedankenstuecke sonified by @dvzrv on Saturday, May 24th, at our festival. https:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 31, 47 ],
        "id_str" : "14286491",
        "id" : 14286491
      }, {
        "name" : "dvzrv",
        "screen_name" : "dvzrv",
        "indices" : [ 60, 66 ],
        "id_str" : "30868098",
        "id" : 30868098
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 107, 130 ],
        "url" : "https:\/\/t.co\/w1gYQTYdan",
        "expanded_url" : "https:\/\/soundcloud.com\/thesoundofpeople",
        "display_url" : "soundcloud.com\/thesoundofpeop\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "468421135236087808",
    "text" : "You can listen to the sound of @gedankenstuecke sonified by @dvzrv on Saturday, May 24th, at our festival. https:\/\/t.co\/w1gYQTYdan",
    "id" : 468421135236087808,
    "created_at" : "2014-05-19 16:01:16 +0000",
    "user" : {
      "name" : "Bended Realities",
      "screen_name" : "bendedrealities",
      "protected" : false,
      "id_str" : "1332989701",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/453446975455637504\/bIoGf0dC_normal.jpeg",
      "id" : 1332989701,
      "verified" : false
    }
  },
  "id" : 468431303470485504,
  "created_at" : "2014-05-19 16:41:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 66 ],
      "url" : "http:\/\/t.co\/rWXauQbPl1",
      "expanded_url" : "http:\/\/www.avclub.com\/article\/why-unplugged-matters-even-when-it-doesnt-204612",
      "display_url" : "avclub.com\/article\/why-un\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723415586, 8.6276149857 ]
  },
  "id_str" : "468412120452042752",
  "text" : "Why Unplugged matters, even when it doesn\u2019t http:\/\/t.co\/rWXauQbPl1",
  "id" : 468412120452042752,
  "created_at" : "2014-05-19 15:25:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723415586, 8.6276149857 ]
  },
  "id_str" : "468397566812749824",
  "text" : "\u00ABErstaunlich wie schnell wir vom Esoterik-Thema zu Prostatauntersuchungen gekommen sind.\u00BB",
  "id" : 468397566812749824,
  "created_at" : "2014-05-19 14:27:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 73 ],
      "url" : "http:\/\/t.co\/sc9tXUBsNy",
      "expanded_url" : "http:\/\/i.imgur.com\/Gy4oMZ7.gif",
      "display_url" : "i.imgur.com\/Gy4oMZ7.gif"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723415586, 8.6276149857 ]
  },
  "id_str" : "468387815584452608",
  "text" : "a standard coping strategy for dealing with stress http:\/\/t.co\/sc9tXUBsNy",
  "id" : 468387815584452608,
  "created_at" : "2014-05-19 13:48:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 97, 106 ],
      "id_str" : "14245811",
      "id" : 14245811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/E8ZKoAAjwo",
      "expanded_url" : "http:\/\/etinarcadiaeg0.wordpress.com\/2014\/05\/18\/personal-genome-project-email-storm\/",
      "display_url" : "etinarcadiaeg0.wordpress.com\/2014\/05\/18\/per\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723415586, 8.6276149857 ]
  },
  "id_str" : "468384653783875585",
  "text" : "On getting mailing list settings right: Personal Genome Project\u00A0Party http:\/\/t.co\/E8ZKoAAjwo \/HT @wilbanks",
  "id" : 468384653783875585,
  "created_at" : "2014-05-19 13:36:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "468356081409069056",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723415586, 8.6276149857 ]
  },
  "id_str" : "468357347531030528",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot Biceratops?",
  "id" : 468357347531030528,
  "in_reply_to_status_id" : 468356081409069056,
  "created_at" : "2014-05-19 11:47:47 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/468355288828227585\/photo\/1",
      "indices" : [ 16, 38 ],
      "url" : "http:\/\/t.co\/1mhw1bIV8I",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bn_up1JIUAAduka.jpg",
      "id_str" : "468355288677240832",
      "id" : 468355288677240832,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bn_up1JIUAAduka.jpg",
      "sizes" : [ {
        "h" : 225,
        "resize" : "fit",
        "w" : 225
      }, {
        "h" : 225,
        "resize" : "fit",
        "w" : 225
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 225,
        "resize" : "fit",
        "w" : 225
      }, {
        "h" : 225,
        "resize" : "fit",
        "w" : 225
      } ],
      "display_url" : "pic.twitter.com\/1mhw1bIV8I"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "468351246307692544",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723415586, 8.6276149857 ]
  },
  "id_str" : "468355288828227585",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot welches? http:\/\/t.co\/1mhw1bIV8I",
  "id" : 468355288828227585,
  "in_reply_to_status_id" : 468351246307692544,
  "created_at" : "2014-05-19 11:39:37 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "468354462847733761",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723415586, 8.6276149857 ]
  },
  "id_str" : "468354618410696704",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer too bad, looking for a way to optimize the parameters in a sensible way.",
  "id" : 468354618410696704,
  "in_reply_to_status_id" : 468354462847733761,
  "created_at" : "2014-05-19 11:36:57 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "468354107124633601",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723415586, 8.6276149857 ]
  },
  "id_str" : "468354362616852481",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer btw: did you ever use the string graph assembler?",
  "id" : 468354362616852481,
  "in_reply_to_status_id" : 468354107124633601,
  "created_at" : "2014-05-19 11:35:56 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Ezra Brooks",
      "screen_name" : "ezbrooks",
      "indices" : [ 14, 23 ],
      "id_str" : "18346745",
      "id" : 18346745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "468350864663392256",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723415586, 8.6276149857 ]
  },
  "id_str" : "468350887229149184",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @ezbrooks dito :)",
  "id" : 468350887229149184,
  "in_reply_to_status_id" : 468350864663392256,
  "created_at" : "2014-05-19 11:22:07 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 55 ],
      "url" : "http:\/\/t.co\/MNIR5RoTmd",
      "expanded_url" : "http:\/\/www.smbc-comics.com\/index.php?db=comics&id=3361",
      "display_url" : "smbc-comics.com\/index.php?db=c\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723415586, 8.6276149857 ]
  },
  "id_str" : "468348370835501056",
  "text" : "your anus will never be the same http:\/\/t.co\/MNIR5RoTmd",
  "id" : 468348370835501056,
  "created_at" : "2014-05-19 11:12:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723415586, 8.6276149857 ]
  },
  "id_str" : "468347325614927872",
  "text" : "\u00ABDeine Haare gef\u00E4rbt oder ist das ein Biss?\u00BB\u2013\u00ABK\u00F6nnte beides sein, aber vermutlich letzteres.\u00BB\u2013\u00ABDu wilder Kerl! Oh, oder war es ein Tier!?\u00BB",
  "id" : 468347325614927872,
  "created_at" : "2014-05-19 11:07:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "li5a",
      "screen_name" : "li5a",
      "indices" : [ 69, 74 ],
      "id_str" : "11712822",
      "id" : 11712822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "468329925783465984",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723415586, 8.6276149857 ]
  },
  "id_str" : "468333202671935488",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer ah, nice review. And the thanks for recommending go to @li5a in the end :)",
  "id" : 468333202671935488,
  "in_reply_to_status_id" : 468329925783465984,
  "created_at" : "2014-05-19 10:11:51 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "468321780294111232",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723415586, 8.6276149857 ]
  },
  "id_str" : "468328267930685440",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer what\u2019s your final opinion? :)",
  "id" : 468328267930685440,
  "in_reply_to_status_id" : 468321780294111232,
  "created_at" : "2014-05-19 09:52:14 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 3, 16 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/3iKKmtdRyy",
      "expanded_url" : "http:\/\/www.qwantz.com\/index.php?comic=2628",
      "display_url" : "qwantz.com\/index.php?comi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "468176474609287168",
  "text" : "RT @PhilippBayer: If I know two languages, am I a double-cyborg? http:\/\/t.co\/3iKKmtdRyy",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 47, 69 ],
        "url" : "http:\/\/t.co\/3iKKmtdRyy",
        "expanded_url" : "http:\/\/www.qwantz.com\/index.php?comic=2628",
        "display_url" : "qwantz.com\/index.php?comi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "468173542270316544",
    "text" : "If I know two languages, am I a double-cyborg? http:\/\/t.co\/3iKKmtdRyy",
    "id" : 468173542270316544,
    "created_at" : "2014-05-18 23:37:25 +0000",
    "user" : {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "protected" : false,
      "id_str" : "121777206",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2013711027\/IMG_1088_normal.png",
      "id" : 121777206,
      "verified" : false
    }
  },
  "id" : 468176474609287168,
  "created_at" : "2014-05-18 23:49:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "esomesse",
      "indices" : [ 44, 53 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096688005, 8.2832810468 ]
  },
  "id_str" : "468164133704437763",
  "text" : "\u00ABW\u00FCrdest du das Outfit auch au\u00DFerhalb einer #esomesse tragen?\u00BB \u2014 \u00ABIch wollte morgen so zur Arbeit gehen.\u00BB",
  "id" : 468164133704437763,
  "created_at" : "2014-05-18 23:00:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 10, 16 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "468097162740789249",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096418615, 8.2829721001 ]
  },
  "id_str" : "468127212424953856",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich @Lobot danke :)",
  "id" : 468127212424953856,
  "in_reply_to_status_id" : 468097162740789249,
  "created_at" : "2014-05-18 20:33:19 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Frau Fragmente",
      "screen_name" : "fragmente",
      "indices" : [ 0, 10 ],
      "id_str" : "7207642",
      "id" : 7207642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "468099740031545344",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096418615, 8.2829721001 ]
  },
  "id_str" : "468127182678921216",
  "in_reply_to_user_id" : 7207642,
  "text" : "@fragmente ja, das mache ich oft.",
  "id" : 468127182678921216,
  "in_reply_to_status_id" : 468099740031545344,
  "created_at" : "2014-05-18 20:33:12 +0000",
  "in_reply_to_screen_name" : "fragmente",
  "in_reply_to_user_id_str" : "7207642",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dodger",
      "screen_name" : "zuendelkind",
      "indices" : [ 0, 12 ],
      "id_str" : "14610725",
      "id" : 14610725
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 34, 40 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "468094760650293249",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096135968, 8.2830071376 ]
  },
  "id_str" : "468095142201946112",
  "in_reply_to_user_id" : 14610725,
  "text" : "@zuendelkind das haarige Tier ist @lobot ;)",
  "id" : 468095142201946112,
  "in_reply_to_status_id" : 468094760650293249,
  "created_at" : "2014-05-18 18:25:53 +0000",
  "in_reply_to_screen_name" : "zuendelkind",
  "in_reply_to_user_id_str" : "14610725",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    }, {
      "name" : "Frau Fragmente",
      "screen_name" : "fragmente",
      "indices" : [ 7, 17 ],
      "id_str" : "7207642",
      "id" : 7207642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "468094487718551552",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096135968, 8.2830071376 ]
  },
  "id_str" : "468094635232206848",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot @fragmente und manche machen beides gern.",
  "id" : 468094635232206848,
  "in_reply_to_status_id" : 468094487718551552,
  "created_at" : "2014-05-18 18:23:52 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "esomesse",
      "indices" : [ 27, 36 ]
    } ],
    "urls" : [ {
      "indices" : [ 37, 59 ],
      "url" : "http:\/\/t.co\/hFJxkxhFFJ",
      "expanded_url" : "http:\/\/instagram.com\/p\/oJecIaBwtL\/",
      "display_url" : "instagram.com\/p\/oJecIaBwtL\/"
    } ]
  },
  "geo" : { },
  "id_str" : "468094151763177472",
  "text" : "Wie ist unser Eso-Passing? #esomesse http:\/\/t.co\/hFJxkxhFFJ",
  "id" : 468094151763177472,
  "created_at" : "2014-05-18 18:21:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Frau Fragmente",
      "screen_name" : "fragmente",
      "indices" : [ 0, 10 ],
      "id_str" : "7207642",
      "id" : 7207642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 62 ],
      "url" : "https:\/\/t.co\/Aqag8gyJcF",
      "expanded_url" : "https:\/\/twitter.com\/Lobot\/status\/468032600205172736",
      "display_url" : "twitter.com\/Lobot\/status\/4\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "468053185085837312",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1242591039, 8.7043756445 ]
  },
  "id_str" : "468053998684344321",
  "in_reply_to_user_id" : 7207642,
  "text" : "@fragmente weil ich so ungern verliere https:\/\/t.co\/Aqag8gyJcF",
  "id" : 468053998684344321,
  "in_reply_to_status_id" : 468053185085837312,
  "created_at" : "2014-05-18 15:42:23 +0000",
  "in_reply_to_screen_name" : "fragmente",
  "in_reply_to_user_id_str" : "7207642",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "esomesse",
      "indices" : [ 76, 85 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1235052615, 8.7041788975 ]
  },
  "id_str" : "468046055947632641",
  "text" : "\u00ABNa, darf ich mit meinen Divine Healing Hands deine Verstopfung entfernen?\u00BB #esomesse",
  "id" : 468046055947632641,
  "created_at" : "2014-05-18 15:10:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "esomesse",
      "indices" : [ 83, 92 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1235197402, 8.70413059 ]
  },
  "id_str" : "468034890215485440",
  "text" : "\u00ABWieso haben hier eigentlich die Violetten einen Infostand und die Piraten nicht?\u00BB #esomesse",
  "id" : 468034890215485440,
  "created_at" : "2014-05-18 14:26:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "esomesse",
      "indices" : [ 129, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1235251154, 8.7041782561 ]
  },
  "id_str" : "468034433917153280",
  "text" : "Eso-Datenschutzdebatte: \u00ABWas mache ich wenn mein Nachbar der Remote Viewing kann ganz unethisch remote in mein Haus eindringt?\u00BB  #esomesse",
  "id" : 468034433917153280,
  "created_at" : "2014-05-18 14:24:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "esomesse",
      "indices" : [ 128, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1234884115, 8.7040845597 ]
  },
  "id_str" : "468026374763335680",
  "text" : "Aha, die US Army hat Major Ed im Hellsehen ausgebildet. Er hat es dann im Rahmen einer UFO-Konferenz nach Deutschland gebracht. #esomesse",
  "id" : 468026374763335680,
  "created_at" : "2014-05-18 13:52:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "esomesse",
      "indices" : [ 114, 123 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1234058756, 8.7041531997 ]
  },
  "id_str" : "468017687827062785",
  "text" : "Was alle meine Vorurteile best\u00E4tigt: In Frankfurt beten sie auf der Esoterikmesse zu Jesus f\u00FCr bessere Finanzen.  #esomesse",
  "id" : 468017687827062785,
  "created_at" : "2014-05-18 13:18:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "esomesse",
      "indices" : [ 96, 105 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1232878472, 8.7041369862 ]
  },
  "id_str" : "468007999978864640",
  "text" : "\u00ABWie ist das mit Horrorfilmen. Ist das auch eine energetische Einladung f\u00FCr diese Wesenheiten?\u00BB #esomesse",
  "id" : 468007999978864640,
  "created_at" : "2014-05-18 12:39:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/gXfxa8oIZ0",
      "expanded_url" : "http:\/\/i.imgur.com\/AvIUz.gif",
      "display_url" : "i.imgur.com\/AvIUz.gif"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1233292343, 8.7040308788 ]
  },
  "id_str" : "468006035014561792",
  "text" : "\u00ABDie Seele ist viel leichter und muss von den schwereren Fremdbesetzungen getrennt werden.\u00BB science knows how! http:\/\/t.co\/gXfxa8oIZ0",
  "id" : 468006035014561792,
  "created_at" : "2014-05-18 12:31:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1234041174, 8.703911897 ]
  },
  "id_str" : "468002028925779968",
  "text" : "\u00BBGibt es Menschen die f\u00FCr Fremdbesetzungen pr\u00E4destiniert sind?\u00BB \u2014 \u00ABJa, das ist genetisch.\u00BB",
  "id" : 468002028925779968,
  "created_at" : "2014-05-18 12:15:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1233504458, 8.7040157052 ]
  },
  "id_str" : "468001798813650945",
  "text" : "\u00ABOh, sie redet von dir: \u2018Die Wesenheiten die sich gerne im Genitalbereich festsetzen\u2019.\u00BB",
  "id" : 468001798813650945,
  "created_at" : "2014-05-18 12:14:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1233610565, 8.7041471206 ]
  },
  "id_str" : "467997913239814144",
  "text" : "Wenn jemand fragt: Mein Stimmungsring wurde mit Erz aus den Minen von Moronia geschmiedet.",
  "id" : 467997913239814144,
  "created_at" : "2014-05-18 11:59:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Terrorzicke",
      "screen_name" : "terrorzicke",
      "indices" : [ 0, 12 ],
      "id_str" : "14728378",
      "id" : 14728378
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 44 ],
      "url" : "https:\/\/t.co\/fGowExkwKm",
      "expanded_url" : "https:\/\/twitter.com\/Lobot\/status\/467995734475022336",
      "display_url" : "twitter.com\/Lobot\/status\/4\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "467995871339352064",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.123319073, 8.7040505528 ]
  },
  "id_str" : "467997465338458112",
  "in_reply_to_user_id" : 14728378,
  "text" : "@terrorzicke dieses: https:\/\/t.co\/fGowExkwKm",
  "id" : 467997465338458112,
  "in_reply_to_status_id" : 467995871339352064,
  "created_at" : "2014-05-18 11:57:45 +0000",
  "in_reply_to_screen_name" : "terrorzicke",
  "in_reply_to_user_id_str" : "14728378",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.123287771, 8.7041358355 ]
  },
  "id_str" : "467995689256255488",
  "text" : "Die Heilpraktikerin f\u00FCr Psychotherapie erz\u00E4hlt jetzt \u00FCber \u00ABUmgang mit fremden Energien, D\u00E4monen und Fremdbesetzungen\u00BB.",
  "id" : 467995689256255488,
  "created_at" : "2014-05-18 11:50:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 40 ],
      "url" : "http:\/\/t.co\/PAC0rJaBkq",
      "expanded_url" : "http:\/\/toe.prx.org\/2014\/05\/a-better-tomorrow\/",
      "display_url" : "toe.prx.org\/2014\/05\/a-bett\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.12226705, 8.6997712518 ]
  },
  "id_str" : "467985794406567937",
  "text" : "a better tomorrow http:\/\/t.co\/PAC0rJaBkq",
  "id" : 467985794406567937,
  "created_at" : "2014-05-18 11:11:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0011206931, 8.2587862555 ]
  },
  "id_str" : "467962242211020801",
  "text" : "\u00ABImmerhin kommt \u2018[Ll]iebe\u2019 25x h\u00E4ufiger in unseren Logs vor als \u2018[Hh]itler\u2019.\u00BB",
  "id" : 467962242211020801,
  "created_at" : "2014-05-18 09:37:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/etWb3g4fjI",
      "expanded_url" : "http:\/\/www.plosone.org\/article\/info%3Adoi%2F10.1371%2Fjournal.pone.0097686",
      "display_url" : "plosone.org\/article\/info%3\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095995957, 8.2829889043 ]
  },
  "id_str" : "467814072227229697",
  "text" : "Are All Data Created Equal? - Exploring Some Boundary Conditions for a Lazy Intuitive Statistician http:\/\/t.co\/etWb3g4fjI",
  "id" : 467814072227229697,
  "created_at" : "2014-05-17 23:49:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/ZunglVP6Jq",
      "expanded_url" : "http:\/\/www.plosone.org\/article\/info%3Adoi%2F10.1371%2Fjournal.pone.0097075",
      "display_url" : "plosone.org\/article\/info%3\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095995957, 8.2829889043 ]
  },
  "id_str" : "467811395825049601",
  "text" : "Belief in a Just World Lowers Perceived Intention of Corruption: The Mediating Role of Perceived Punishment http:\/\/t.co\/ZunglVP6Jq",
  "id" : 467811395825049601,
  "created_at" : "2014-05-17 23:38:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096712029, 8.2829071954 ]
  },
  "id_str" : "467808959823609856",
  "text" : "\u00ABUrks, was ist denn hier ausgelaufen? Ich habe mehrere Vermutungen, aber keine davon w\u00FCrde mir sonderlich gefallen.\u00BB",
  "id" : 467808959823609856,
  "created_at" : "2014-05-17 23:28:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095995957, 8.2829889043 ]
  },
  "id_str" : "467793608150904832",
  "text" : "\u201Chitler: du gehst du auch ins bett, du schl\u00E4fst nur nicht so lang wie ich\u201D Meine Chatlogs bilden meine Beziehungen so gut ab.",
  "id" : 467793608150904832,
  "created_at" : "2014-05-17 22:27:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/5nj2K7r3CI",
      "expanded_url" : "http:\/\/blog.assaflavie.com\/time-zones-considered-harmful\/",
      "display_url" : "blog.assaflavie.com\/time-zones-con\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095995957, 8.2829889043 ]
  },
  "id_str" : "467784880001413120",
  "text" : "\u00ABNobody\u2019s asking if it was Klingon time or Romulan savings time.\u00BB http:\/\/t.co\/5nj2K7r3CI",
  "id" : 467784880001413120,
  "created_at" : "2014-05-17 21:53:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095995957, 8.2829889043 ]
  },
  "id_str" : "467782613596639232",
  "text" : "\u00ABKlar darfst du fahren. Au\u00DFer du bist betrunken oder besessen oder so.\u00BB\u2013\u00ABBetrunken von all der Lichtnahrung die ich aufgenommen haben werd?\u00BB",
  "id" : 467782613596639232,
  "created_at" : "2014-05-17 21:44:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "S\u00F6ren Schewe",
      "screen_name" : "Roterhai",
      "indices" : [ 0, 9 ],
      "id_str" : "25101713",
      "id" : 25101713
    }, {
      "name" : "antiglitzerfee\uD83D\uDC19",
      "screen_name" : "Molossoidea",
      "indices" : [ 10, 22 ],
      "id_str" : "1874599292",
      "id" : 1874599292
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "467777616830029824",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095995957, 8.2829889043 ]
  },
  "id_str" : "467778540835188736",
  "in_reply_to_user_id" : 25101713,
  "text" : "@Roterhai @Molossoidea that was from an episode of Psych and I didn\u2019t assume those exist. I should have known better\u2026",
  "id" : 467778540835188736,
  "in_reply_to_status_id" : 467777616830029824,
  "created_at" : "2014-05-17 21:27:49 +0000",
  "in_reply_to_screen_name" : "Roterhai",
  "in_reply_to_user_id_str" : "25101713",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095995957, 8.2829889043 ]
  },
  "id_str" : "467777345416609792",
  "text" : "\u00ABA veterinarian who designs cosmetic testicles for neutered dogs.\u00BB \u2013 \u00ABRestoring their dognety.\u00BB\u00A0",
  "id" : 467777345416609792,
  "created_at" : "2014-05-17 21:23:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "gegengewalt",
      "screen_name" : "ekelias",
      "indices" : [ 0, 8 ],
      "id_str" : "15890805",
      "id" : 15890805
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "467723825732665344",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096352948, 8.2829863176 ]
  },
  "id_str" : "467749528226238464",
  "in_reply_to_user_id" : 15890805,
  "text" : "@ekelias honk if you\u2019re horny!",
  "id" : 467749528226238464,
  "in_reply_to_status_id" : 467723825732665344,
  "created_at" : "2014-05-17 19:32:32 +0000",
  "in_reply_to_screen_name" : "ekelias",
  "in_reply_to_user_id_str" : "15890805",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 33 ],
      "url" : "http:\/\/t.co\/NAyZmCHzZ4",
      "expanded_url" : "http:\/\/instagram.com\/p\/oHAHD6hwvC\/",
      "display_url" : "instagram.com\/p\/oHAHD6hwvC\/"
    } ]
  },
  "geo" : { },
  "id_str" : "467745982877143041",
  "text" : "Monitoring http:\/\/t.co\/NAyZmCHzZ4",
  "id" : 467745982877143041,
  "created_at" : "2014-05-17 19:18:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Minten",
      "screen_name" : "p_minten",
      "indices" : [ 3, 12 ],
      "id_str" : "1956224965",
      "id" : 1956224965
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "467745554198712321",
  "text" : "RT @p_minten: Gender is to biology what datetime is to programming: something people think is simple, except those who have to deal with it\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "467608040133656576",
    "text" : "Gender is to biology what datetime is to programming: something people think is simple, except those who have to deal with it in depth.",
    "id" : 467608040133656576,
    "created_at" : "2014-05-17 10:10:19 +0000",
    "user" : {
      "name" : "Peter Minten",
      "screen_name" : "p_minten",
      "protected" : false,
      "id_str" : "1956224965",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/589735813342228480\/wh1j45S-_normal.png",
      "id" : 1956224965,
      "verified" : false
    }
  },
  "id" : 467745554198712321,
  "created_at" : "2014-05-17 19:16:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096043718, 8.2830763061 ]
  },
  "id_str" : "467740440469708802",
  "text" : "\u00ABThey decriminalized drugs in Iceland.\u00BB \u2014 \u00ABJust in time for our vacation!\u00BB",
  "id" : 467740440469708802,
  "created_at" : "2014-05-17 18:56:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lara",
      "screen_name" : "alibi_ranch",
      "indices" : [ 0, 12 ],
      "id_str" : "265371167",
      "id" : 265371167
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "467661459489832960",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0059184991, 8.2810772583 ]
  },
  "id_str" : "467727355201740801",
  "in_reply_to_user_id" : 265371167,
  "text" : "@alibi_ranch genau das war mein erster Gedanke :3",
  "id" : 467727355201740801,
  "in_reply_to_status_id" : 467661459489832960,
  "created_at" : "2014-05-17 18:04:26 +0000",
  "in_reply_to_screen_name" : "alibi_ranch",
  "in_reply_to_user_id_str" : "265371167",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 63 ],
      "url" : "http:\/\/t.co\/zxnzhnl4po",
      "expanded_url" : "http:\/\/m.thisamericanlife.org\/radio-archives\/episode\/524\/i-was-so-high",
      "display_url" : "m.thisamericanlife.org\/radio-archives\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0015427238, 8.2598760932 ]
  },
  "id_str" : "467651384335409152",
  "text" : "I Was So High\u2026 \u00ABI\u2019m a skateboard-rabbi!\u00BB http:\/\/t.co\/zxnzhnl4po",
  "id" : 467651384335409152,
  "created_at" : "2014-05-17 13:02:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/L4XsqKvHFf",
      "expanded_url" : "http:\/\/instagram.com\/p\/oGUi1Xhwsl\/",
      "display_url" : "instagram.com\/p\/oGUi1Xhwsl\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 49.996123103, 8.322767454 ]
  },
  "id_str" : "467650179353415680",
  "text" : "Rapper gesucht. Diplom von Vorteil. @ Mainz - Gustavsburg http:\/\/t.co\/L4XsqKvHFf",
  "id" : 467650179353415680,
  "created_at" : "2014-05-17 12:57:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "467626391241256961",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009553725, 8.28293028 ]
  },
  "id_str" : "467626696422985728",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon hat jetzt noch mal ne Ration Antibiotikum, Entz\u00FCndungshemmer &amp; Schmerzmittel bekommen.",
  "id" : 467626696422985728,
  "in_reply_to_status_id" : 467626391241256961,
  "created_at" : "2014-05-17 11:24:27 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "467625766621310976",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009553725, 8.28293028 ]
  },
  "id_str" : "467625900922896384",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon na, liegt vermutlich daran das ich ihn rumgetragen habe in seiner Box und er wie bl\u00F6d im Kreis gelaufen ist drin.",
  "id" : 467625900922896384,
  "in_reply_to_status_id" : 467625766621310976,
  "created_at" : "2014-05-17 11:21:17 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ali",
      "screen_name" : "zoonpolitikon",
      "indices" : [ 0, 14 ],
      "id_str" : "13040652",
      "id" : 13040652
    }, {
      "name" : "Dierk Haasis",
      "screen_name" : "Evo2Me",
      "indices" : [ 15, 22 ],
      "id_str" : "22910316",
      "id" : 22910316
    }, {
      "name" : "Helmut Wicht",
      "screen_name" : "h_wicht",
      "indices" : [ 23, 31 ],
      "id_str" : "322062420",
      "id" : 322062420
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/rC3zgz3DgG",
      "expanded_url" : "http:\/\/media0.giphy.com\/media\/Flr2XEiLtajU4\/200.gif",
      "display_url" : "media0.giphy.com\/media\/Flr2XEiL\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "467614505120571392",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096611016, 8.2830493619 ]
  },
  "id_str" : "467615096462921728",
  "in_reply_to_user_id" : 13040652,
  "text" : "@zoonpolitikon @Evo2Me @h_wicht Twitter, the gift that keeps on giving\u2026 http:\/\/t.co\/rC3zgz3DgG",
  "id" : 467615096462921728,
  "in_reply_to_status_id" : 467614505120571392,
  "created_at" : "2014-05-17 10:38:21 +0000",
  "in_reply_to_screen_name" : "zoonpolitikon",
  "in_reply_to_user_id_str" : "13040652",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helmut Wicht",
      "screen_name" : "h_wicht",
      "indices" : [ 0, 8 ],
      "id_str" : "322062420",
      "id" : 322062420
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "467613246737117184",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096409593, 8.2829947797 ]
  },
  "id_str" : "467613408708534272",
  "in_reply_to_user_id" : 322062420,
  "text" : "@h_wicht das scheitert aber auch nur am Familienstand.",
  "id" : 467613408708534272,
  "in_reply_to_status_id" : 467613246737117184,
  "created_at" : "2014-05-17 10:31:39 +0000",
  "in_reply_to_screen_name" : "h_wicht",
  "in_reply_to_user_id_str" : "322062420",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "467607080955019264",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096430119, 8.283042566 ]
  },
  "id_str" : "467613294094991360",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich ah, das w\u00FCrde schon gehen, aber wann passt es dir dann mal? :)",
  "id" : 467613294094991360,
  "in_reply_to_status_id" : 467607080955019264,
  "created_at" : "2014-05-17 10:31:11 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096259849, 8.2830302271 ]
  },
  "id_str" : "467612689804840960",
  "text" : "Perfekter Start in den Tag: Vom Kater angekotzt werden.",
  "id" : 467612689804840960,
  "created_at" : "2014-05-17 10:28:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "467602889947774976",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0086871423, 8.2924703774 ]
  },
  "id_str" : "467605497865310208",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich ich bin heut Nachmittag gegen 1500 am Hbf in Mainz. Aber es eilt wirklich nicht, also wenn du noch Einsatzzwecke hast go for it :)",
  "id" : 467605497865310208,
  "in_reply_to_status_id" : 467602889947774976,
  "created_at" : "2014-05-17 10:00:13 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/BM4804bsCV",
      "expanded_url" : "http:\/\/www.crackajack.de\/2014\/05\/16\/weekend-bat-brothers\/",
      "display_url" : "crackajack.de\/2014\/05\/16\/wee\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096292267, 8.2829992117 ]
  },
  "id_str" : "467445375029477376",
  "text" : "Step 1: Video bats. Step 2: Turn it upside down. Step 3: Add a soundtrack http:\/\/t.co\/BM4804bsCV",
  "id" : 467445375029477376,
  "created_at" : "2014-05-16 23:23:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/U1h5w5T3Zg",
      "expanded_url" : "http:\/\/icelandweatherreport.com\/why-i-wont-give-a-sample-of-my-dna-to-decode-genetics\/",
      "display_url" : "icelandweatherreport.com\/why-i-wont-giv\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "467331143243952128",
  "text" : "On the massive DNA collection efforts in Iceland: \u00ABWhy I won\u2019t give a sample of my DNA to Decode Genetics\u00BB http:\/\/t.co\/U1h5w5T3Zg",
  "id" : 467331143243952128,
  "created_at" : "2014-05-16 15:50:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "467323187458736128",
  "text" : "\u00ABWir haben auf das Schnabeltier gehofft\u2026\u00BB \u2013 \u00ABUnd was haben wir bekommen? Entt\u00E4uschung und Trauer\u2026\u00BB",
  "id" : 467323187458736128,
  "created_at" : "2014-05-16 15:18:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hipster",
      "indices" : [ 43, 51 ]
    }, {
      "text" : "swag",
      "indices" : [ 52, 57 ]
    }, {
      "text" : "yolo",
      "indices" : [ 58, 63 ]
    }, {
      "text" : "blogger",
      "indices" : [ 64, 72 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "467320226410147840",
  "geo" : { },
  "id_str" : "467321100742180866",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot 27 shellshocking facts about tanks. #hipster #swag #yolo #blogger",
  "id" : 467321100742180866,
  "in_reply_to_status_id" : 467320226410147840,
  "created_at" : "2014-05-16 15:10:07 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "467316945877225472",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723392389, 8.6275979064 ]
  },
  "id_str" : "467319764885700608",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot ist doch ganz dein Ding: deception as a service.",
  "id" : 467319764885700608,
  "in_reply_to_status_id" : 467316945877225472,
  "created_at" : "2014-05-16 15:04:48 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 66 ],
      "url" : "https:\/\/t.co\/IDnEhW5Ase",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=q_MLi2wAfdM",
      "display_url" : "youtube.com\/watch?v=q_MLi2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "467299066897268736",
  "text" : "How to Talk to Your Kids About Michael Sam https:\/\/t.co\/IDnEhW5Ase",
  "id" : 467299066897268736,
  "created_at" : "2014-05-16 13:42:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "467276459686760448",
  "text" : "Gotta love probabilistic programming: By just rerunning every step of my pipeline with identical parameters I 'solved' my problem\u2026",
  "id" : 467276459686760448,
  "created_at" : "2014-05-16 12:12:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "467262011311931392",
  "text" : "\u00ABBut with a 3D printer we could do our own Tablets of Law!\u00BB \u2013 \u00ABThou shalt not kill jobs and thou shalt not steal memory\u2026\u00BB",
  "id" : 467262011311931392,
  "created_at" : "2014-05-16 11:15:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "467253846012477440",
  "geo" : { },
  "id_str" : "467260284718313472",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer did the same this morning. Great find :)",
  "id" : 467260284718313472,
  "in_reply_to_status_id" : 467253846012477440,
  "created_at" : "2014-05-16 11:08:27 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 105, 118 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/FBV1VSFDE1",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=F3jk3pflofk",
      "display_url" : "youtube.com\/watch?v=F3jk3p\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096219286, 8.2829954014 ]
  },
  "id_str" : "467222018472296448",
  "text" : "\u00ABi think what's next is my trip hop career. and then, who knows? jazz-metal.\u00BB http:\/\/t.co\/FBV1VSFDE1 \/HT @PhilippBayer",
  "id" : 467222018472296448,
  "created_at" : "2014-05-16 08:36:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0082357182, 8.2898181584 ]
  },
  "id_str" : "467219223581065216",
  "text" : "\u00ABEs bricht mir das Herz ihn so zu sehen.\u00BB \u2014 \u00ABUnter Schmerzen?\u00BB \u2014 \u00ABNein, rasiert.\u00BB",
  "id" : 467219223581065216,
  "created_at" : "2014-05-16 08:25:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sylvain \u2744\uFE0F\uD83D\uDC68\uD83C\uDFFB\u200D\uD83C\uDF93",
      "screen_name" : "DevilleSy",
      "indices" : [ 3, 13 ],
      "id_str" : "331228486",
      "id" : 331228486
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/DevilleSy\/status\/467202743950917632\/photo\/1",
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/PfWfLedPB2",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BnvWazHCIAAeu3k.jpg",
      "id_str" : "467202742247628800",
      "id" : 467202742247628800,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BnvWazHCIAAeu3k.jpg",
      "sizes" : [ {
        "h" : 330,
        "resize" : "fit",
        "w" : 540
      }, {
        "h" : 330,
        "resize" : "fit",
        "w" : 540
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 330,
        "resize" : "fit",
        "w" : 540
      }, {
        "h" : 330,
        "resize" : "fit",
        "w" : 540
      } ],
      "display_url" : "pic.twitter.com\/PfWfLedPB2"
    } ],
    "hashtags" : [ {
      "text" : "chemistry",
      "indices" : [ 47, 57 ]
    }, {
      "text" : "chocolate",
      "indices" : [ 58, 68 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "467214012070256640",
  "text" : "RT @DevilleSy: aaaahhhh ! that's one fore me ! #chemistry #chocolate http:\/\/t.co\/PfWfLedPB2",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/DevilleSy\/status\/467202743950917632\/photo\/1",
        "indices" : [ 54, 76 ],
        "url" : "http:\/\/t.co\/PfWfLedPB2",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BnvWazHCIAAeu3k.jpg",
        "id_str" : "467202742247628800",
        "id" : 467202742247628800,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BnvWazHCIAAeu3k.jpg",
        "sizes" : [ {
          "h" : 330,
          "resize" : "fit",
          "w" : 540
        }, {
          "h" : 330,
          "resize" : "fit",
          "w" : 540
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 330,
          "resize" : "fit",
          "w" : 540
        }, {
          "h" : 330,
          "resize" : "fit",
          "w" : 540
        } ],
        "display_url" : "pic.twitter.com\/PfWfLedPB2"
      } ],
      "hashtags" : [ {
        "text" : "chemistry",
        "indices" : [ 32, 42 ]
      }, {
        "text" : "chocolate",
        "indices" : [ 43, 53 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "467202743950917632",
    "text" : "aaaahhhh ! that's one fore me ! #chemistry #chocolate http:\/\/t.co\/PfWfLedPB2",
    "id" : 467202743950917632,
    "created_at" : "2014-05-16 07:19:49 +0000",
    "user" : {
      "name" : "Sylvain \u2744\uFE0F\uD83D\uDC68\uD83C\uDFFB\u200D\uD83C\uDF93",
      "screen_name" : "DevilleSy",
      "protected" : false,
      "id_str" : "331228486",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/887046588954226688\/p3UlM_8C_normal.jpg",
      "id" : 331228486,
      "verified" : false
    }
  },
  "id" : 467214012070256640,
  "created_at" : "2014-05-16 08:04:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jakob Err",
      "screen_name" : "Jakob_Err",
      "indices" : [ 0, 10 ],
      "id_str" : "490871541",
      "id" : 490871541
    }, {
      "name" : "Lukas Martini",
      "screen_name" : "lutoma",
      "indices" : [ 11, 18 ],
      "id_str" : "41419667",
      "id" : 41419667
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "467037748038492160",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096219286, 8.2829954014 ]
  },
  "id_str" : "467039356008800256",
  "in_reply_to_user_id" : 490871541,
  "text" : "@Jakob_Err @lutoma problem is that amazon can\u2019t deliver those to .de due to export restrictions ;)",
  "id" : 467039356008800256,
  "in_reply_to_status_id" : 467037748038492160,
  "created_at" : "2014-05-15 20:30:34 +0000",
  "in_reply_to_screen_name" : "Jakob_Err",
  "in_reply_to_user_id_str" : "490871541",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jakob Err",
      "screen_name" : "Jakob_Err",
      "indices" : [ 0, 10 ],
      "id_str" : "490871541",
      "id" : 490871541
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "467035404127178752",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096219286, 8.2829954014 ]
  },
  "id_str" : "467035664660566017",
  "in_reply_to_user_id" : 490871541,
  "text" : "@Jakob_Err damn. I only changed it because the book I\u2019m currently reading wasn\u2019t available as ebook and the print version isn\u2019t backlit. ;)",
  "id" : 467035664660566017,
  "in_reply_to_status_id" : 467035404127178752,
  "created_at" : "2014-05-15 20:15:54 +0000",
  "in_reply_to_screen_name" : "Jakob_Err",
  "in_reply_to_user_id_str" : "490871541",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096219286, 8.2829954014 ]
  },
  "id_str" : "467024019842416640",
  "text" : "Let there be light! Took me just two weeks to change a lightbulb in the bedroom. Call me procrastinating god.",
  "id" : 467024019842416640,
  "created_at" : "2014-05-15 19:29:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PeerJ - the journal",
      "screen_name" : "thePeerJ",
      "indices" : [ 0, 9 ],
      "id_str" : "402875257",
      "id" : 402875257
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "466959160467546112",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096219286, 8.2829954014 ]
  },
  "id_str" : "466967952311730176",
  "in_reply_to_user_id" : 402875257,
  "text" : "@thePeerJ nice!",
  "id" : 466967952311730176,
  "in_reply_to_status_id" : 466959160467546112,
  "created_at" : "2014-05-15 15:46:50 +0000",
  "in_reply_to_screen_name" : "thePeerJ",
  "in_reply_to_user_id_str" : "402875257",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172340705, 8.62761983 ]
  },
  "id_str" : "466933089412079616",
  "text" : "\u00ABSchau doch nicht immer so l\u00FCstern!\u00BB \u2013 \u00ABNa, in mein B\u00FCro oder in deins?\u00BB",
  "id" : 466933089412079616,
  "created_at" : "2014-05-15 13:28:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "li5a",
      "screen_name" : "li5a",
      "indices" : [ 0, 5 ],
      "id_str" : "11712822",
      "id" : 11712822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "466923006020030464",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172340705, 8.62761983 ]
  },
  "id_str" : "466924945197785089",
  "in_reply_to_user_id" : 11712822,
  "text" : "@li5a though I wonder how large the group of dirty minded Bayesians is.",
  "id" : 466924945197785089,
  "in_reply_to_status_id" : 466923006020030464,
  "created_at" : "2014-05-15 12:55:56 +0000",
  "in_reply_to_screen_name" : "li5a",
  "in_reply_to_user_id_str" : "11712822",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "li5a",
      "screen_name" : "li5a",
      "indices" : [ 0, 5 ],
      "id_str" : "11712822",
      "id" : 11712822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "466922583464873984",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172340705, 8.62761983 ]
  },
  "id_str" : "466922795054944256",
  "in_reply_to_user_id" : 11712822,
  "text" : "@li5a no need to be sorry for that. tbh: that\u2019s virtually the same response my brain gave me upon reading that.",
  "id" : 466922795054944256,
  "in_reply_to_status_id" : 466922583464873984,
  "created_at" : "2014-05-15 12:47:24 +0000",
  "in_reply_to_screen_name" : "li5a",
  "in_reply_to_user_id_str" : "11712822",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "li5a",
      "screen_name" : "li5a",
      "indices" : [ 3, 8 ],
      "id_str" : "11712822",
      "id" : 11712822
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 10, 26 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "466922622299955200",
  "text" : "RT @li5a: @gedankenstuecke gnihihi. why are bayesian lovers into anal? because they like posteriors.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 0, 16 ],
        "id_str" : "14286491",
        "id" : 14286491
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "466922352895594496",
    "in_reply_to_user_id" : 14286491,
    "text" : "@gedankenstuecke gnihihi. why are bayesian lovers into anal? because they like posteriors.",
    "id" : 466922352895594496,
    "created_at" : "2014-05-15 12:45:38 +0000",
    "in_reply_to_screen_name" : "gedankenstuecke",
    "in_reply_to_user_id_str" : "14286491",
    "user" : {
      "name" : "li5a",
      "screen_name" : "li5a",
      "protected" : false,
      "id_str" : "11712822",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/42645812\/P1010897_normal.JPG",
      "id" : 11712822,
      "verified" : false
    }
  },
  "id" : 466922622299955200,
  "created_at" : "2014-05-15 12:46:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fabian Zimmer",
      "screen_name" : "fbnzimmer",
      "indices" : [ 3, 13 ],
      "id_str" : "1515775878",
      "id" : 1515775878
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Bayes",
      "indices" : [ 68, 74 ]
    }, {
      "text" : "stats",
      "indices" : [ 75, 81 ]
    }, {
      "text" : "python",
      "indices" : [ 82, 89 ]
    } ],
    "urls" : [ {
      "indices" : [ 44, 67 ],
      "url" : "https:\/\/t.co\/2PWOyDJf8J",
      "expanded_url" : "https:\/\/github.com\/CamDavidsonPilon\/Probabilistic-Programming-and-Bayesian-Methods-for-Hackers",
      "display_url" : "github.com\/CamDavidsonPil\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "466917650464251904",
  "text" : "RT @fbnzimmer: For all the Bayesian lovers: https:\/\/t.co\/2PWOyDJf8J #Bayes #stats #python",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Bayes",
        "indices" : [ 53, 59 ]
      }, {
        "text" : "stats",
        "indices" : [ 60, 66 ]
      }, {
        "text" : "python",
        "indices" : [ 67, 74 ]
      } ],
      "urls" : [ {
        "indices" : [ 29, 52 ],
        "url" : "https:\/\/t.co\/2PWOyDJf8J",
        "expanded_url" : "https:\/\/github.com\/CamDavidsonPilon\/Probabilistic-Programming-and-Bayesian-Methods-for-Hackers",
        "display_url" : "github.com\/CamDavidsonPil\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "466898752352321536",
    "text" : "For all the Bayesian lovers: https:\/\/t.co\/2PWOyDJf8J #Bayes #stats #python",
    "id" : 466898752352321536,
    "created_at" : "2014-05-15 11:11:51 +0000",
    "user" : {
      "name" : "Fabian Zimmer",
      "screen_name" : "fbnzimmer",
      "protected" : false,
      "id_str" : "1515775878",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623120804230901760\/NTggDagy_normal.jpg",
      "id" : 1515775878,
      "verified" : false
    }
  },
  "id" : 466917650464251904,
  "created_at" : "2014-05-15 12:26:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/nYgs8SLEzM",
      "expanded_url" : "http:\/\/boingboing.net\/2014\/05\/14\/nude-closeups-of-people-who-ar.html",
      "display_url" : "boingboing.net\/2014\/05\/14\/nud\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172340705, 8.62761983 ]
  },
  "id_str" : "466917430535917568",
  "text" : "Nude closeups of people who are more than 100 years\u00A0old &lt;3 http:\/\/t.co\/nYgs8SLEzM",
  "id" : 466917430535917568,
  "created_at" : "2014-05-15 12:26:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/tP9qblDFL4",
      "expanded_url" : "http:\/\/9wows.com\/files\/2012\/05\/High-Speed-Disorganization.gif",
      "display_url" : "9wows.com\/files\/2012\/05\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172340705, 8.62761983 ]
  },
  "id_str" : "466909199767986176",
  "text" : "http:\/\/t.co\/tP9qblDFL4",
  "id" : 466909199767986176,
  "created_at" : "2014-05-15 11:53:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172340705, 8.62761983 ]
  },
  "id_str" : "466890408300396544",
  "text" : "\u00ABWillkommen auf dem Riedberg. Wo sich windstill und wind-chill im Minutentakt abwechseln.\u00BB",
  "id" : 466890408300396544,
  "created_at" : "2014-05-15 10:38:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fabian Zimmer",
      "screen_name" : "fbnzimmer",
      "indices" : [ 0, 10 ],
      "id_str" : "1515775878",
      "id" : 1515775878
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "466871968734924800",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172340705, 8.62761983 ]
  },
  "id_str" : "466878066409893888",
  "in_reply_to_user_id" : 1515775878,
  "text" : "@fbnzimmer it involves paper, I\u2019m already highly skeptical of that by principle!",
  "id" : 466878066409893888,
  "in_reply_to_status_id" : 466871968734924800,
  "created_at" : "2014-05-15 09:49:39 +0000",
  "in_reply_to_screen_name" : "fbnzimmer",
  "in_reply_to_user_id_str" : "1515775878",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/TzeELe6d6r",
      "expanded_url" : "http:\/\/stream1.gifsoup.com\/view3\/3333866\/its-in-the-computer-o.gif",
      "display_url" : "stream1.gifsoup.com\/view3\/3333866\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172340705, 8.62761983 ]
  },
  "id_str" : "466865985530920960",
  "text" : "oh noes, the only person who still knows how to use the fax machine already went home! http:\/\/t.co\/TzeELe6d6r",
  "id" : 466865985530920960,
  "created_at" : "2014-05-15 09:01:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PeerJ - the journal",
      "screen_name" : "thePeerJ",
      "indices" : [ 54, 63 ],
      "id_str" : "402875257",
      "id" : 402875257
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/WUcHIr5853",
      "expanded_url" : "http:\/\/bit.ly\/TZgySz",
      "display_url" : "bit.ly\/TZgySz"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172340705, 8.62761983 ]
  },
  "id_str" : "466864954793287680",
  "text" : "I wish articles would include rotatable 3D models! MT @thePeerJ: Examining the coiled-shells of snails. http:\/\/t.co\/WUcHIr5853",
  "id" : 466864954793287680,
  "created_at" : "2014-05-15 08:57:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/ks7ObjcBjL",
      "expanded_url" : "http:\/\/emperorx.bandcamp.com\/album\/10000-year-earworm-to-discourage-settlement-near-nuclear-waste-repositories",
      "display_url" : "emperorx.bandcamp.com\/album\/10000-ye\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172340705, 8.62761983 ]
  },
  "id_str" : "466855244786577408",
  "text" : "starting the day with the \u2018don\u2019t change color, kitty\u2019 song http:\/\/t.co\/ks7ObjcBjL",
  "id" : 466855244786577408,
  "created_at" : "2014-05-15 08:18:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096555775, 8.2830264825 ]
  },
  "id_str" : "466732337729130496",
  "text" : "\u00ABDa wir nur minimale Spendenbetr\u00E4ge brauchen ist das wohl egal. Wir kaufen ja keine Schiffe um damit Japaner zu rammen (oder doch???)\u00BB",
  "id" : 466732337729130496,
  "created_at" : "2014-05-15 00:10:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ed Yong",
      "screen_name" : "edyong209",
      "indices" : [ 0, 10 ],
      "id_str" : "19767193",
      "id" : 19767193
    }, {
      "name" : "Carl Zimmer",
      "screen_name" : "carlzimmer",
      "indices" : [ 11, 22 ],
      "id_str" : "14085070",
      "id" : 14085070
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "466723438019633152",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096555775, 8.2830264825 ]
  },
  "id_str" : "466723821509431296",
  "in_reply_to_user_id" : 19767193,
  "text" : "@edyong209 @carlzimmer I knew it! It\u2019s Teenage Mutant Hero Turtles all the way down!",
  "id" : 466723821509431296,
  "in_reply_to_status_id" : 466723438019633152,
  "created_at" : "2014-05-14 23:36:45 +0000",
  "in_reply_to_screen_name" : "edyong209",
  "in_reply_to_user_id_str" : "19767193",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tlm",
      "indices" : [ 91, 95 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096301963, 8.2830660813 ]
  },
  "id_str" : "466691393768144896",
  "text" : "\u00ABWhen Kandel tickled the siphon of the snail, it flinched and contracted its gill.\u00BB kinky! #tlm",
  "id" : 466691393768144896,
  "created_at" : "2014-05-14 21:27:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 76 ],
      "url" : "https:\/\/t.co\/tUD2Gadvph",
      "expanded_url" : "https:\/\/rbt.asia\/g\/thread\/41920845",
      "display_url" : "rbt.asia\/g\/thread\/41920\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096301963, 8.2830660813 ]
  },
  "id_str" : "466680086046195712",
  "text" : "\u00ABHow I got my girlfriend pregnant using JavaScript.\u00BB https:\/\/t.co\/tUD2Gadvph",
  "id" : 466680086046195712,
  "created_at" : "2014-05-14 20:42:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/uOMlYwzz7L",
      "expanded_url" : "http:\/\/31.media.tumblr.com\/b45e61beda1228205c4315c3f478b95b\/tumblr_mscejvGs731rkpfcgo1_500.gif",
      "display_url" : "31.media.tumblr.com\/b45e61beda1228\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096301963, 8.2830660813 ]
  },
  "id_str" : "466663252974657538",
  "text" : "looks like the problems with my computations are only partially solved\u2026 http:\/\/t.co\/uOMlYwzz7L",
  "id" : 466663252974657538,
  "created_at" : "2014-05-14 19:36:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/9SonnvKpdx",
      "expanded_url" : "http:\/\/99percentinvisible.org\/episode\/ten-thousand-years\/",
      "display_url" : "99percentinvisible.org\/episode\/ten-th\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095462333, 8.2828439322 ]
  },
  "id_str" : "466647416528453635",
  "text" : "on one of the most intriguing design problems: \u00ABmay the ray cats keep us safe.\u00BB http:\/\/t.co\/9SonnvKpdx",
  "id" : 466647416528453635,
  "created_at" : "2014-05-14 18:33:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Liliana Demir \uD83C\uDDEA\uD83C\uDDFA",
      "screen_name" : "Cohnina",
      "indices" : [ 78, 86 ],
      "id_str" : "15438679",
      "id" : 15438679
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 73 ],
      "url" : "https:\/\/t.co\/6AhMmTHV95",
      "expanded_url" : "https:\/\/www.behance.net\/gallery\/9633585\/Found-In-Translation",
      "display_url" : "behance.net\/gallery\/963358\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095995957, 8.2829889043 ]
  },
  "id_str" : "466625010212569088",
  "text" : "\u00ABrire dans sa barbe\u00BB untranslatable words\/phrases https:\/\/t.co\/6AhMmTHV95 \/ht @Cohnina",
  "id" : 466625010212569088,
  "created_at" : "2014-05-14 17:04:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723342467, 8.62761305 ]
  },
  "id_str" : "466579593076690944",
  "text" : "\u00ABLoseritis? Was besseres ist dir nicht eingefallen?\u00BB \u2013 \u00ABWie h\u00E4ttest du es denn genannt? Failomania?\u00BB",
  "id" : 466579593076690944,
  "created_at" : "2014-05-14 14:03:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sebastian Greiner",
      "screen_name" : "Seb666",
      "indices" : [ 0, 7 ],
      "id_str" : "2365333778",
      "id" : 2365333778
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 8, 17 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 58 ],
      "url" : "http:\/\/t.co\/pTqKppseES",
      "expanded_url" : "http:\/\/25.media.tumblr.com\/3f1bb02d7c13f73db579c99de31b50a7\/tumblr_mv73r0fJDD1rdfgw4o1_500.gif",
      "display_url" : "25.media.tumblr.com\/3f1bb02d7c13f7\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "466500486070153216",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723342467, 8.62761305 ]
  },
  "id_str" : "466502495318343680",
  "in_reply_to_user_id" : 18362640,
  "text" : "@Seb666 @Senficon Damn, you got me! http:\/\/t.co\/pTqKppseES",
  "id" : 466502495318343680,
  "in_reply_to_status_id" : 466500486070153216,
  "created_at" : "2014-05-14 08:57:16 +0000",
  "in_reply_to_screen_name" : "NieMehrPiraten",
  "in_reply_to_user_id_str" : "18362640",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723342467, 8.62761305 ]
  },
  "id_str" : "466499993965453312",
  "text" : "\u00ABDiese Schlangenlinie ist deine Unterschrift?!\u00BB \u2013 \u00ABJa, man muss kein Graphologe sein um mich als \u2018lazy bastard\u2019 zu profilen.\u00BB",
  "id" : 466499993965453312,
  "created_at" : "2014-05-14 08:47:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Todd Vision",
      "screen_name" : "tjvision",
      "indices" : [ 3, 12 ],
      "id_str" : "127003086",
      "id" : 127003086
    }, {
      "name" : "PHD Comics",
      "screen_name" : "PHDcomics",
      "indices" : [ 80, 90 ],
      "id_str" : "15521075",
      "id" : 15521075
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "466498193773973504",
  "text" : "RT @tjvision: I dearly hope that last number is wrong, but suspect it isn't. RT @phdcomics: Academic Salaries Exposed: http:\/\/t.co\/zUiUld5a\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "PHD Comics",
        "screen_name" : "PHDcomics",
        "indices" : [ 66, 76 ],
        "id_str" : "15521075",
        "id" : 15521075
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 105, 127 ],
        "url" : "http:\/\/t.co\/zUiUld5ao5",
        "expanded_url" : "http:\/\/tapastic.com\/episode\/40050",
        "display_url" : "tapastic.com\/episode\/40050"
      } ]
    },
    "geo" : { },
    "id_str" : "466397030987079681",
    "text" : "I dearly hope that last number is wrong, but suspect it isn't. RT @phdcomics: Academic Salaries Exposed: http:\/\/t.co\/zUiUld5ao5",
    "id" : 466397030987079681,
    "created_at" : "2014-05-14 01:58:12 +0000",
    "user" : {
      "name" : "Todd Vision",
      "screen_name" : "tjvision",
      "protected" : false,
      "id_str" : "127003086",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/922261858714730496\/UyxNRM8l_normal.jpg",
      "id" : 127003086,
      "verified" : false
    }
  },
  "id" : 466498193773973504,
  "created_at" : "2014-05-14 08:40:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 54 ],
      "url" : "http:\/\/t.co\/3JVI67j8xc",
      "expanded_url" : "http:\/\/loonylabs.org\/2014\/05\/13\/climate-talks-game-theory\/",
      "display_url" : "loonylabs.org\/2014\/05\/13\/cli\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723342467, 8.62761305 ]
  },
  "id_str" : "466481630648229888",
  "text" : "Climate Talks &amp; Game Theory http:\/\/t.co\/3JVI67j8xc",
  "id" : 466481630648229888,
  "created_at" : "2014-05-14 07:34:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tlm",
      "indices" : [ 121, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1615868078, 8.6491979837 ]
  },
  "id_str" : "466469099728822272",
  "text" : "\u00ABBenzer had believed that happiness is the pursuit of curiosity and that a fall from pure science is a fall from grace.\u00BB #tlm",
  "id" : 466469099728822272,
  "created_at" : "2014-05-14 06:44:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 74 ],
      "url" : "http:\/\/t.co\/19t6EStr3R",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=ickYBD9iaxY",
      "display_url" : "youtube.com\/watch?v=ickYBD\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009632704, 8.28304719 ]
  },
  "id_str" : "466340525847883778",
  "text" : "i\u2019m such a sucker for simple acoustic guitar stuff\u2026 http:\/\/t.co\/19t6EStr3R",
  "id" : 466340525847883778,
  "created_at" : "2014-05-13 22:13:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "466326028131270656",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009632704, 8.28304719 ]
  },
  "id_str" : "466328663408254976",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot survival of the fattest",
  "id" : 466328663408254976,
  "in_reply_to_status_id" : 466326028131270656,
  "created_at" : "2014-05-13 21:26:31 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/kkvaPIsFJZ",
      "expanded_url" : "http:\/\/nymag.com\/daily\/intelligencer\/2014\/05\/bounce-house-blows-away-with-three-kids-inside.html",
      "display_url" : "nymag.com\/daily\/intellig\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009632704, 8.28304719 ]
  },
  "id_str" : "466327630980349952",
  "text" : "\u00ABIt was like a horror movie\u00BB Maybe if it was based on a Stephen King novel\u2026 http:\/\/t.co\/kkvaPIsFJZ",
  "id" : 466327630980349952,
  "created_at" : "2014-05-13 21:22:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095431413, 8.2828830113 ]
  },
  "id_str" : "466304330493345793",
  "text" : "\u00ABWir k\u00F6nnen da ja mal anrufen und fragen was die Villa ohne den G\u00E4rtner kosten w\u00FCrde.\u00BB",
  "id" : 466304330493345793,
  "created_at" : "2014-05-13 19:49:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 57 ],
      "url" : "http:\/\/t.co\/o6TikTtF1i",
      "expanded_url" : "http:\/\/stream1.gifsoup.com\/view2\/1108864\/home-alone-is-a-rly-gud-movie-o.gif",
      "display_url" : "stream1.gifsoup.com\/view2\/1108864\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0150589073, 8.4281529914 ]
  },
  "id_str" : "466273152952463360",
  "text" : "the right to be forgotten you say? http:\/\/t.co\/o6TikTtF1i",
  "id" : 466273152952463360,
  "created_at" : "2014-05-13 17:45:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/UA5F3dk0G4",
      "expanded_url" : "http:\/\/blogs.scientificamerican.com\/guest-blog\/2014\/05\/13\/the-frustrations-of-being-scientifically-literate\/",
      "display_url" : "blogs.scientificamerican.com\/guest-blog\/201\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "466220898547404800",
  "text" : "\u00AB[Mad scientists] were probably just marine biologists who had to explain one too many times that whales aren\u2019t fish\u00BB http:\/\/t.co\/UA5F3dk0G4",
  "id" : 466220898547404800,
  "created_at" : "2014-05-13 14:18:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "466219360919777280",
  "text" : "\u00ABWenn ich nicht so Angst vor Nadeln h\u00E4tte w\u00FCrde ich auch zur Blutspende gehen. Und w\u00E4re heroinabh\u00E4ngig.\u00BB",
  "id" : 466219360919777280,
  "created_at" : "2014-05-13 14:12:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "466205599060226048",
  "text" : "\u00ABDas k\u00F6nnen keine Bioinformatiker sein. Die reden \u00FCber One-Night-Stands! Wir haben keine Zeit f\u00FCr sowas, wir m\u00FCssen nachts coden!\u00BB",
  "id" : 466205599060226048,
  "created_at" : "2014-05-13 13:17:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 49.9932666978, 8.26129255 ]
  },
  "id_str" : "466150768685633536",
  "text" : "\u00ABIch bin hier wegen des Geldes. Das geht ja schnell. Rein, raus, B\u00C4M! 27.50 \u20AC\u00BB",
  "id" : 466150768685633536,
  "created_at" : "2014-05-13 09:39:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emanuel Wyler",
      "screen_name" : "ewyler",
      "indices" : [ 0, 7 ],
      "id_str" : "122329006",
      "id" : 122329006
    }, {
      "name" : "DetritusBlog",
      "screen_name" : "gedankenabfall",
      "indices" : [ 8, 23 ],
      "id_str" : "2175883684",
      "id" : 2175883684
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "465885708679647233",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 49.993085557, 8.2627908944 ]
  },
  "id_str" : "466149267229655040",
  "in_reply_to_user_id" : 122329006,
  "text" : "@ewyler @gedankenabfall sehr sch\u00F6n :)",
  "id" : 466149267229655040,
  "in_reply_to_status_id" : 465885708679647233,
  "created_at" : "2014-05-13 09:33:40 +0000",
  "in_reply_to_screen_name" : "ewyler",
  "in_reply_to_user_id_str" : "122329006",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emanuel Wyler",
      "screen_name" : "ewyler",
      "indices" : [ 3, 10 ],
      "id_str" : "122329006",
      "id" : 122329006
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "lndw2014",
      "indices" : [ 63, 72 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/p1ZtQBRu6H",
      "expanded_url" : "http:\/\/emanuelwyler.wordpress.com\/2014\/05\/12\/meine-gene-gehoren-mir-technische-moglichkeiten-und-ethische-grenzen-der-bestimmung-des-menschlichen-erbgutes\/",
      "display_url" : "emanuelwyler.wordpress.com\/2014\/05\/12\/mei\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "466149227652198401",
  "text" : "RT @ewyler: Erbgutbestimmung und Ged\u00F6ns \u2013 mein Vortrag bei der #lndw2014 letzten Samstag jetzt auch auf http:\/\/t.co\/p1ZtQBRu6H http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ewyler\/status\/465885708679647233\/photo\/1",
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/UOHu6hyIXa",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BncolR6IgAA0Dcl.jpg",
        "id_str" : "465885707383635968",
        "id" : 465885707383635968,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BncolR6IgAA0Dcl.jpg",
        "sizes" : [ {
          "h" : 360,
          "resize" : "fit",
          "w" : 480
        }, {
          "h" : 360,
          "resize" : "fit",
          "w" : 480
        }, {
          "h" : 360,
          "resize" : "fit",
          "w" : 480
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 360,
          "resize" : "fit",
          "w" : 480
        } ],
        "display_url" : "pic.twitter.com\/UOHu6hyIXa"
      } ],
      "hashtags" : [ {
        "text" : "lndw2014",
        "indices" : [ 51, 60 ]
      } ],
      "urls" : [ {
        "indices" : [ 92, 114 ],
        "url" : "http:\/\/t.co\/p1ZtQBRu6H",
        "expanded_url" : "http:\/\/emanuelwyler.wordpress.com\/2014\/05\/12\/meine-gene-gehoren-mir-technische-moglichkeiten-und-ethische-grenzen-der-bestimmung-des-menschlichen-erbgutes\/",
        "display_url" : "emanuelwyler.wordpress.com\/2014\/05\/12\/mei\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "465885708679647233",
    "text" : "Erbgutbestimmung und Ged\u00F6ns \u2013 mein Vortrag bei der #lndw2014 letzten Samstag jetzt auch auf http:\/\/t.co\/p1ZtQBRu6H http:\/\/t.co\/UOHu6hyIXa",
    "id" : 465885708679647233,
    "created_at" : "2014-05-12 16:06:23 +0000",
    "user" : {
      "name" : "Emanuel Wyler",
      "screen_name" : "ewyler",
      "protected" : false,
      "id_str" : "122329006",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/748080119\/twitter_normal.jpg",
      "id" : 122329006,
      "verified" : false
    }
  },
  "id" : 466149227652198401,
  "created_at" : "2014-05-13 09:33:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 49.9930267126, 8.2628276688 ]
  },
  "id_str" : "466135468879646720",
  "text" : "Das hat man davon wenn ein Land an \u2018Musik, nur wenn sie laut ist\u2019 statt an \u2018Musik, nur wenn sie gut ist\u2019 glaubt\u2026",
  "id" : 466135468879646720,
  "created_at" : "2014-05-13 08:38:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "466134486900809728",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 49.9929492595, 8.2626266129 ]
  },
  "id_str" : "466134759966785536",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot klar, mit meinen mad tapping skills (auf der air guitar) bekomme ich das einh\u00E4ndig hin.",
  "id" : 466134759966785536,
  "in_reply_to_status_id" : 466134486900809728,
  "created_at" : "2014-05-13 08:36:01 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "466132910245163008",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 49.9930343182, 8.262582409 ]
  },
  "id_str" : "466133284473552896",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot the stupid, it doesn\u2019t burn? :p",
  "id" : 466133284473552896,
  "in_reply_to_status_id" : 466132910245163008,
  "created_at" : "2014-05-13 08:30:10 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 49.9928958136, 8.2628722928 ]
  },
  "id_str" : "466132238422528000",
  "text" : "Wenn sie noch mehr Westernhagen in der Transfusionszentrale spielen m\u00F6chte ich das sie mich einfach ausbluten lassen.",
  "id" : 466132238422528000,
  "created_at" : "2014-05-13 08:26:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097449637, 8.2830610033 ]
  },
  "id_str" : "466096619545690112",
  "text" : "Overslept because the guy with the jackhammer just outside my bedroom made so much noise I couldn\u2019t hear my alarm.",
  "id" : 466096619545690112,
  "created_at" : "2014-05-13 06:04:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "465998926823161856",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097201736, 8.2830774119 ]
  },
  "id_str" : "465999693311660032",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer just gave it a try. That works perfectly!",
  "id" : 465999693311660032,
  "in_reply_to_status_id" : 465998926823161856,
  "created_at" : "2014-05-12 23:39:19 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "465998108942282752",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009632704, 8.28304719 ]
  },
  "id_str" : "465998482877476864",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer thanks, I\u2019ll just claim I have a nature paper and utter the \u2018communications\u2019 under my breath. ;)",
  "id" : 465998482877476864,
  "in_reply_to_status_id" : 465998108942282752,
  "created_at" : "2014-05-12 23:34:30 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fabian Zimmer",
      "screen_name" : "fbnzimmer",
      "indices" : [ 0, 10 ],
      "id_str" : "1515775878",
      "id" : 1515775878
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 73 ],
      "url" : "http:\/\/t.co\/yqaCdDRSmF",
      "expanded_url" : "http:\/\/www.dildo-generator.com\/",
      "display_url" : "dildo-generator.com"
    } ]
  },
  "in_reply_to_status_id_str" : "465983733980725248",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009632704, 8.28304719 ]
  },
  "id_str" : "465984487906881536",
  "in_reply_to_user_id" : 1515775878,
  "text" : "@fbnzimmer yeah, to tie into the discussion we had http:\/\/t.co\/yqaCdDRSmF :P",
  "id" : 465984487906881536,
  "in_reply_to_status_id" : 465983733980725248,
  "created_at" : "2014-05-12 22:38:54 +0000",
  "in_reply_to_screen_name" : "fbnzimmer",
  "in_reply_to_user_id_str" : "1515775878",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fabian Zimmer",
      "screen_name" : "fbnzimmer",
      "indices" : [ 0, 10 ],
      "id_str" : "1515775878",
      "id" : 1515775878
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "465982159338340352",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009632704, 8.28304719 ]
  },
  "id_str" : "465982988413849602",
  "in_reply_to_user_id" : 1515775878,
  "text" : "@fbnzimmer wow, that\u2019s cool!",
  "id" : 465982988413849602,
  "in_reply_to_status_id" : 465982159338340352,
  "created_at" : "2014-05-12 22:32:56 +0000",
  "in_reply_to_screen_name" : "fbnzimmer",
  "in_reply_to_user_id_str" : "1515775878",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fabian Zimmer",
      "screen_name" : "fbnzimmer",
      "indices" : [ 0, 10 ],
      "id_str" : "1515775878",
      "id" : 1515775878
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "465980875734536192",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009632704, 8.28304719 ]
  },
  "id_str" : "465981041485045760",
  "in_reply_to_user_id" : 1515775878,
  "text" : "@fbnzimmer please tell me you\u2019re not trying to do it with Inkscape &amp; Mac OS :D",
  "id" : 465981041485045760,
  "in_reply_to_status_id" : 465980875734536192,
  "created_at" : "2014-05-12 22:25:12 +0000",
  "in_reply_to_screen_name" : "fbnzimmer",
  "in_reply_to_user_id_str" : "1515775878",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fabian Zimmer",
      "screen_name" : "fbnzimmer",
      "indices" : [ 0, 10 ],
      "id_str" : "1515775878",
      "id" : 1515775878
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "465977890971344896",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009632704, 8.28304719 ]
  },
  "id_str" : "465978010714505217",
  "in_reply_to_user_id" : 1515775878,
  "text" : "@fbnzimmer yay! And you should make some for your cephalopod-brain-friend :D",
  "id" : 465978010714505217,
  "in_reply_to_status_id" : 465977890971344896,
  "created_at" : "2014-05-12 22:13:09 +0000",
  "in_reply_to_screen_name" : "fbnzimmer",
  "in_reply_to_user_id_str" : "1515775878",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fabian Zimmer",
      "screen_name" : "fbnzimmer",
      "indices" : [ 25, 35 ],
      "id_str" : "1515775878",
      "id" : 1515775878
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 58 ],
      "url" : "http:\/\/t.co\/jNXEaEOejm",
      "expanded_url" : "http:\/\/boingboing.net\/2014\/05\/12\/cephalodpod-pancakes.html",
      "display_url" : "boingboing.net\/2014\/05\/12\/cep\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009632704, 8.28304719 ]
  },
  "id_str" : "465963147556573184",
  "text" : "Cephalopod pancakes! \/cc @fbnzimmer http:\/\/t.co\/jNXEaEOejm",
  "id" : 465963147556573184,
  "created_at" : "2014-05-12 21:14:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095459005, 8.2828122416 ]
  },
  "id_str" : "465957553500082176",
  "text" : "My freezer at home now contains: rat heads, a DNA sample and ice cream. That\u2019s work-life balance, right?",
  "id" : 465957553500082176,
  "created_at" : "2014-05-12 20:51:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/NtceIR9M2S",
      "expanded_url" : "http:\/\/instagram.com\/p\/n6EWXwBwlL\/",
      "display_url" : "instagram.com\/p\/n6EWXwBwlL\/"
    } ]
  },
  "geo" : { },
  "id_str" : "465925716811345920",
  "text" : "Maybe I should have used another ice box to carry a DNA library on public transport. People start to\u2026 http:\/\/t.co\/NtceIR9M2S",
  "id" : 465925716811345920,
  "created_at" : "2014-05-12 18:45:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172331468, 8.6276004016 ]
  },
  "id_str" : "465910523717246976",
  "text" : "\u00ABWir m\u00FCssen dann noch ein Kilo Meth aus deinem B\u00FCro holen.\u00BB \u2014 \u00ABWir sind Twitterer. Wir holen h\u00F6chstens ein Kilo Mett aus meinem B\u00FCro.\u00BB",
  "id" : 465910523717246976,
  "created_at" : "2014-05-12 17:44:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/JQPyHttnQl",
      "expanded_url" : "http:\/\/blogs.scientificamerican.com\/oscillator\/2014\/05\/12\/which-bacteria-are-in-my-poop-it-depends-where-you-look\/",
      "display_url" : "blogs.scientificamerican.com\/oscillator\/201\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723342467, 8.62761305 ]
  },
  "id_str" : "465881237132177408",
  "text" : "Which bacteria are in my poop? It depends where you look\u2026 http:\/\/t.co\/JQPyHttnQl",
  "id" : 465881237132177408,
  "created_at" : "2014-05-12 15:48:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723342467, 8.62761305 ]
  },
  "id_str" : "465866015407374339",
  "text" : "But apparently my university lacks a subscription to Nature Communications, so I can\u2019t access the article\u2026 Yay for traditional publishing\u2026",
  "id" : 465866015407374339,
  "created_at" : "2014-05-12 14:48:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/Fw8BzvqQVb",
      "expanded_url" : "http:\/\/www.nature.com\/ncomms\/2014\/140512\/ncomms4873\/full\/ncomms4873.html",
      "display_url" : "nature.com\/ncomms\/2014\/14\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723342467, 8.62761305 ]
  },
  "id_str" : "465865354183737344",
  "text" : "Our paper on parallel evolution of cox genes in H2S-tolerant fish as key adaptation to a toxic environment is out \\o\/ http:\/\/t.co\/Fw8BzvqQVb",
  "id" : 465865354183737344,
  "created_at" : "2014-05-12 14:45:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tobler Lab",
      "screen_name" : "michitobler",
      "indices" : [ 0, 12 ],
      "id_str" : "47138807",
      "id" : 47138807
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "465861551614746624",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723342467, 8.62761305 ]
  },
  "id_str" : "465862495534845952",
  "in_reply_to_user_id" : 47138807,
  "text" : "@michitobler oh, congratulations, Mr. Co-Author :)",
  "id" : 465862495534845952,
  "in_reply_to_status_id" : 465861551614746624,
  "created_at" : "2014-05-12 14:34:08 +0000",
  "in_reply_to_screen_name" : "michitobler",
  "in_reply_to_user_id_str" : "47138807",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 7, 29 ],
      "url" : "http:\/\/t.co\/D9Fmlz78As",
      "expanded_url" : "http:\/\/instagram.com\/p\/n5mQJNBwo9\/",
      "display_url" : "instagram.com\/p\/n5mQJNBwo9\/"
    } ]
  },
  "geo" : { },
  "id_str" : "465859531193733120",
  "text" : "sleepy http:\/\/t.co\/D9Fmlz78As",
  "id" : 465859531193733120,
  "created_at" : "2014-05-12 14:22:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723342467, 8.62761305 ]
  },
  "id_str" : "465841307831648256",
  "text" : "\u00ABIch verstehe Hypes sowieso nicht. Die erzeugen immer nur Erwartungen die dann nicht erf\u00FCllt werden.\u00BB \u2013 \u00ABAu\u00DFer bei Scooter-Songs!\u00BB",
  "id" : 465841307831648256,
  "created_at" : "2014-05-12 13:09:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andreas Herten",
      "screen_name" : "AndiH",
      "indices" : [ 0, 6 ],
      "id_str" : "4586881",
      "id" : 4586881
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "465830002635063296",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723342467, 8.62761305 ]
  },
  "id_str" : "465830247968280576",
  "in_reply_to_user_id" : 4586881,
  "text" : "@AndiH klar, heut bis 1800 Uhr, morgen vermutlich erst ab mittags und daf\u00FCr nachmittags l\u00E4nger. :)",
  "id" : 465830247968280576,
  "in_reply_to_status_id" : 465830002635063296,
  "created_at" : "2014-05-12 12:26:00 +0000",
  "in_reply_to_screen_name" : "AndiH",
  "in_reply_to_user_id_str" : "4586881",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andreas Herten",
      "screen_name" : "AndiH",
      "indices" : [ 0, 6 ],
      "id_str" : "4586881",
      "id" : 4586881
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "465829073131163648",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723342467, 8.62761305 ]
  },
  "id_str" : "465829462182219776",
  "in_reply_to_user_id" : 4586881,
  "text" : "@AndiH in dem roten Ding ganz rechts auf deinem Bild. ;) (Biologicum, Fl\u00FCgel B, 3 OG)",
  "id" : 465829462182219776,
  "in_reply_to_status_id" : 465829073131163648,
  "created_at" : "2014-05-12 12:22:53 +0000",
  "in_reply_to_screen_name" : "AndiH",
  "in_reply_to_user_id_str" : "4586881",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 73, 86 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 68 ],
      "url" : "http:\/\/t.co\/JDYx9V9ohu",
      "expanded_url" : "http:\/\/www.replicatedtypo.com\/the-evolution-of-language-the-webcomic\/8575.html",
      "display_url" : "replicatedtypo.com\/the-evolution-\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723342467, 8.62761305 ]
  },
  "id_str" : "465827710204641280",
  "text" : "Nice: a webcomic on the evolution of language http:\/\/t.co\/JDYx9V9ohu \/cc @PhilippBayer",
  "id" : 465827710204641280,
  "created_at" : "2014-05-12 12:15:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andreas Herten",
      "screen_name" : "AndiH",
      "indices" : [ 0, 6 ],
      "id_str" : "4586881",
      "id" : 4586881
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "465825723568361473",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723342467, 8.62761305 ]
  },
  "id_str" : "465826272904744960",
  "in_reply_to_user_id" : 4586881,
  "text" : "@AndiH In dem Fall bist du herzlich eingeladen mal auf einen Kaffee r\u00FCberzukommen :)",
  "id" : 465826272904744960,
  "in_reply_to_status_id" : 465825723568361473,
  "created_at" : "2014-05-12 12:10:12 +0000",
  "in_reply_to_screen_name" : "AndiH",
  "in_reply_to_user_id_str" : "4586881",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andreas Herten",
      "screen_name" : "AndiH",
      "indices" : [ 0, 6 ],
      "id_str" : "4586881",
      "id" : 4586881
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "465825319958876160",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723342467, 8.62761305 ]
  },
  "id_str" : "465825523172929536",
  "in_reply_to_user_id" : 4586881,
  "text" : "@AndiH Oh, wir sind aktuell Nachbarn?",
  "id" : 465825523172929536,
  "in_reply_to_status_id" : 465825319958876160,
  "created_at" : "2014-05-12 12:07:14 +0000",
  "in_reply_to_screen_name" : "AndiH",
  "in_reply_to_user_id_str" : "4586881",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 67 ],
      "url" : "http:\/\/t.co\/ZL4iRfio4Y",
      "expanded_url" : "http:\/\/i.imgur.com\/wIF3QXr.gif",
      "display_url" : "i.imgur.com\/wIF3QXr.gif"
    } ]
  },
  "in_reply_to_status_id_str" : "465822709663166464",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723342467, 8.62761305 ]
  },
  "id_str" : "465824593606115328",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot is there anything we need talk about? http:\/\/t.co\/ZL4iRfio4Y",
  "id" : 465824593606115328,
  "in_reply_to_status_id" : 465822709663166464,
  "created_at" : "2014-05-12 12:03:32 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "465820243374657536",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723342467, 8.62761305 ]
  },
  "id_str" : "465821566019043329",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot this makes me wonder about your recent interest in lock picking.",
  "id" : 465821566019043329,
  "in_reply_to_status_id" : 465820243374657536,
  "created_at" : "2014-05-12 11:51:30 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/n7AM32EtkO",
      "expanded_url" : "http:\/\/www.yosefk.com\/blog\/why-bad-scientific-code-beats-code-following-best-practices.html",
      "display_url" : "yosefk.com\/blog\/why-bad-s\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723342467, 8.62761305 ]
  },
  "id_str" : "465817380372103168",
  "text" : "Scientific code: \u00ABSimple-minded, care-free near-incompetence can be better than industrial-strength good intentions\u00BB http:\/\/t.co\/n7AM32EtkO",
  "id" : 465817380372103168,
  "created_at" : "2014-05-12 11:34:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 74 ],
      "url" : "http:\/\/t.co\/l3IwC8DGi8",
      "expanded_url" : "http:\/\/www.skullsunlimited.com\/products_by_order.php?id=34",
      "display_url" : "skullsunlimited.com\/products_by_or\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "465808127611641856",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723342467, 8.62761305 ]
  },
  "id_str" : "465808440276025344",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot someone already made a business out of this: http:\/\/t.co\/l3IwC8DGi8",
  "id" : 465808440276025344,
  "in_reply_to_status_id" : 465808127611641856,
  "created_at" : "2014-05-12 10:59:21 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "465805847265026048",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723342467, 8.62761305 ]
  },
  "id_str" : "465807947713769472",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot I expected owls, how disappointing!",
  "id" : 465807947713769472,
  "in_reply_to_status_id" : 465805847265026048,
  "created_at" : "2014-05-12 10:57:23 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 65 ],
      "url" : "http:\/\/t.co\/HBWGeBEdpR",
      "expanded_url" : "http:\/\/blogs.plos.org\/biologue\/2014\/05\/06\/scientists-ignore-female-genitalia\/?utm_source=feedburner&utm_medium=feed&utm_campaign=Feed%3A+plos%2Fblogs%2Fbiologue+%28Blogs+-+Biologue%29",
      "display_url" : "blogs.plos.org\/biologue\/2014\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723342467, 8.62761305 ]
  },
  "id_str" : "465788637574336512",
  "text" : "Why Do Scientists Ignore Female Genitalia? http:\/\/t.co\/HBWGeBEdpR",
  "id" : 465788637574336512,
  "created_at" : "2014-05-12 09:40:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723342467, 8.62761305 ]
  },
  "id_str" : "465786531316502528",
  "text" : "\u00ABMein schlechtes Gewissen hat mir geraten: Trink jeden Schnaps den du siehst.\u00BB",
  "id" : 465786531316502528,
  "created_at" : "2014-05-12 09:32:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723342467, 8.62761305 ]
  },
  "id_str" : "465777064944353280",
  "text" : "\u00ABWie hast du den Eukalyptushonig importiert?\u00BB \u2013 \u00ABDirekt aus Australien. In Koalam\u00E4gen!\u00BB",
  "id" : 465777064944353280,
  "created_at" : "2014-05-12 08:54:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "465585172826832897",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009575589, 8.2829192575 ]
  },
  "id_str" : "465587209194975232",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC Caveat emptor, I really got it by now ;)",
  "id" : 465587209194975232,
  "in_reply_to_status_id" : 465585172826832897,
  "created_at" : "2014-05-11 20:20:15 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "465573886432923648",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096234513, 8.2829833167 ]
  },
  "id_str" : "465583083019042816",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC I wondered what that link would bring, even better than expected :) \uD83D\uDC3C",
  "id" : 465583083019042816,
  "in_reply_to_status_id" : 465573886432923648,
  "created_at" : "2014-05-11 20:03:51 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0480723634, 8.5830444321 ]
  },
  "id_str" : "465535973129211904",
  "text" : "\u00ABWe\u2019ll have a bumpy ride due to what the British call \u2018good weather\u2019.\u00BB",
  "id" : 465535973129211904,
  "created_at" : "2014-05-11 16:56:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "465489825257512960",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.4713720605, -0.4893072601 ]
  },
  "id_str" : "465493225336504320",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC cuteness, I know it when I see it ;)",
  "id" : 465493225336504320,
  "in_reply_to_status_id" : 465489825257512960,
  "created_at" : "2014-05-11 14:06:48 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "465459144280260608",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.573508191, -0.1268511359 ]
  },
  "id_str" : "465472413594304512",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC the mild form of cephalopodophilia?",
  "id" : 465472413594304512,
  "in_reply_to_status_id" : 465459144280260608,
  "created_at" : "2014-05-11 12:44:06 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/8HmorVV1G2",
      "expanded_url" : "http:\/\/www.ruralmodernhome.com\/sites\/default\/files\/content\/images\/chicken%2B-%2Bsilkie.jpg",
      "display_url" : "ruralmodernhome.com\/sites\/default\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.5798046251, -0.1262896796 ]
  },
  "id_str" : "465471668153249792",
  "text" : "\u00ABLike which of these chickens do you feel right now?\u00BB http:\/\/t.co\/8HmorVV1G2",
  "id" : 465471668153249792,
  "created_at" : "2014-05-11 12:41:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.5287507, -0.1272176371 ]
  },
  "id_str" : "465422637431549952",
  "text" : "TIL: Performing the \u2018yay, my computations finally works\u2019-dance in public will get you some strange looks.",
  "id" : 465422637431549952,
  "created_at" : "2014-05-11 09:26:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephan Urbach",
      "screen_name" : "herrurbach",
      "indices" : [ 0, 11 ],
      "id_str" : "28090494",
      "id" : 28090494
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "465405068217704448",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.528745173, -0.127228798 ]
  },
  "id_str" : "465422082718064640",
  "in_reply_to_user_id" : 28090494,
  "text" : "@herrurbach Vernunft ist nichts, eh? ;)",
  "id" : 465422082718064640,
  "in_reply_to_status_id" : 465405068217704448,
  "created_at" : "2014-05-11 09:24:06 +0000",
  "in_reply_to_screen_name" : "herrurbach",
  "in_reply_to_user_id_str" : "28090494",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.5243517654, -0.1301525161 ]
  },
  "id_str" : "465420521111556096",
  "text" : "\u00ABI have this cool tool to create really long scaffolds. It\u2019s called \u2018cat\u2019!\u00BB",
  "id" : 465420521111556096,
  "created_at" : "2014-05-11 09:17:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 38 ],
      "url" : "http:\/\/t.co\/jWz6CrL0th",
      "expanded_url" : "http:\/\/instagram.com\/p\/n2PWqwhwjy\/",
      "display_url" : "instagram.com\/p\/n2PWqwhwjy\/"
    } ]
  },
  "geo" : { },
  "id_str" : "465386969422262272",
  "text" : "Cthulhu fhtagn! http:\/\/t.co\/jWz6CrL0th",
  "id" : 465386969422262272,
  "created_at" : "2014-05-11 07:04:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.5246492392, -0.1303736307 ]
  },
  "id_str" : "465261482268430337",
  "text" : "\u00ABMy place or yours?\u00BB \u2014 \u00ABI guess now would be the time to clarify for the others what will happen.\u00BB \u2014 \u00ABYou mean what will not happen.\u00BB",
  "id" : 465261482268430337,
  "created_at" : "2014-05-10 22:45:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Keith Bradnam",
      "screen_name" : "kbradnam",
      "indices" : [ 3, 12 ],
      "id_str" : "17061155",
      "id" : 17061155
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/JDnzjTOdRX",
      "expanded_url" : "http:\/\/buff.ly\/1kFjouB",
      "display_url" : "buff.ly\/1kFjouB"
    } ]
  },
  "geo" : { },
  "id_str" : "465124009907331072",
  "text" : "RT @kbradnam: New ACGT blog post: What is the extent of gender bias in bioinformatics? Please help me find out. http:\/\/t.co\/JDnzjTOdRX",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 98, 120 ],
        "url" : "http:\/\/t.co\/JDnzjTOdRX",
        "expanded_url" : "http:\/\/buff.ly\/1kFjouB",
        "display_url" : "buff.ly\/1kFjouB"
      } ]
    },
    "geo" : { },
    "id_str" : "463346808589410304",
    "text" : "New ACGT blog post: What is the extent of gender bias in bioinformatics? Please help me find out. http:\/\/t.co\/JDnzjTOdRX",
    "id" : 463346808589410304,
    "created_at" : "2014-05-05 15:57:42 +0000",
    "user" : {
      "name" : "Keith Bradnam",
      "screen_name" : "kbradnam",
      "protected" : false,
      "id_str" : "17061155",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/583756306919489538\/D2fFCYq4_normal.jpg",
      "id" : 17061155,
      "verified" : false
    }
  },
  "id" : 465124009907331072,
  "created_at" : "2014-05-10 13:39:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.5288631886, -0.1274387535 ]
  },
  "id_str" : "465120126023761920",
  "text" : "Next stop: \u2018Art and Anarchy in the UK\u2019.",
  "id" : 465120126023761920,
  "created_at" : "2014-05-10 13:24:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan O'Connor",
      "screen_name" : "drdanoconnor",
      "indices" : [ 12, 25 ],
      "id_str" : "5862622",
      "id" : 5862622
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "465119353726590977",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.5291035183, -0.1271967831 ]
  },
  "id_str" : "465119623751663617",
  "in_reply_to_user_id" : 18343072,
  "text" : "@dire_tribe @drdanoconnor thanks :)",
  "id" : 465119623751663617,
  "in_reply_to_status_id" : 465119353726590977,
  "created_at" : "2014-05-10 13:22:14 +0000",
  "in_reply_to_screen_name" : "NavjoytLadher",
  "in_reply_to_user_id_str" : "18343072",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 51 ],
      "url" : "http:\/\/t.co\/1gnzRCN6TB",
      "expanded_url" : "http:\/\/feedproxy.google.com\/~r\/smbc-comics\/PvLb\/~3\/nBosKm5ulhg\/index.php",
      "display_url" : "feedproxy.google.com\/~r\/smbc-comics\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.526685, -0.130947 ]
  },
  "id_str" : "465049706910208000",
  "text" : "Developmental psych research http:\/\/t.co\/1gnzRCN6TB",
  "id" : 465049706910208000,
  "created_at" : "2014-05-10 08:44:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.520154646, -0.1260255659 ]
  },
  "id_str" : "464903128782241793",
  "text" : "Talking about what\u2019s unique about participant-led research: the latest phenotype entered on openSNP is \u2018third nipple\u2019.",
  "id" : 464903128782241793,
  "created_at" : "2014-05-09 23:01:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.5293698323, -0.1260287329 ]
  },
  "id_str" : "464877350300434432",
  "text" : "Being asked whether I\u2019ve ever heard of the Spice Girls. I must look pretty young for my age.",
  "id" : 464877350300434432,
  "created_at" : "2014-05-09 21:19:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "antiglitzerfee\uD83D\uDC19",
      "screen_name" : "Molossoidea",
      "indices" : [ 0, 12 ],
      "id_str" : "1874599292",
      "id" : 1874599292
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "464816854385819648",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.5266543682, -0.1309885264 ]
  },
  "id_str" : "464819121486831616",
  "in_reply_to_user_id" : 1874599292,
  "text" : "@Molossoidea was man findet: give it a try. Was man sucht: die Art consent mit der sich IRBs auseinandersetzen.",
  "id" : 464819121486831616,
  "in_reply_to_status_id" : 464816854385819648,
  "created_at" : "2014-05-09 17:28:09 +0000",
  "in_reply_to_screen_name" : "Molossoidea",
  "in_reply_to_user_id_str" : "1874599292",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.5266273113, -0.1310210863 ]
  },
  "id_str" : "464815197572825088",
  "text" : "TIL: googling for \u2018consent fetishism\u2019 didn\u2019t exactly deliver the results I expected.",
  "id" : 464815197572825088,
  "created_at" : "2014-05-09 17:12:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Wicks",
      "screen_name" : "PaulLikeMe",
      "indices" : [ 0, 11 ],
      "id_str" : "375875836",
      "id" : 375875836
    }, {
      "name" : "R\u24EAss Mounce",
      "screen_name" : "rmounce",
      "indices" : [ 12, 20 ],
      "id_str" : "222765418",
      "id" : 222765418
    }, {
      "name" : "Tom Pollard",
      "screen_name" : "tompollard",
      "indices" : [ 21, 32 ],
      "id_str" : "19282539",
      "id" : 19282539
    }, {
      "name" : "Samuel Moore",
      "screen_name" : "samoore_",
      "indices" : [ 33, 42 ],
      "id_str" : "77294800",
      "id" : 77294800
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "464805553047609344",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.526503406, -0.1313443709 ]
  },
  "id_str" : "464813167231922176",
  "in_reply_to_user_id" : 375875836,
  "text" : "@PaulLikeMe @rmounce @tompollard @samoore_ Thanks :)",
  "id" : 464813167231922176,
  "in_reply_to_status_id" : 464805553047609344,
  "created_at" : "2014-05-09 17:04:29 +0000",
  "in_reply_to_screen_name" : "PaulLikeMe",
  "in_reply_to_user_id_str" : "375875836",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 37 ],
      "url" : "https:\/\/t.co\/llhGuwF831",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/464520839539744768",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "464748914462457856",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.5266590907, -0.13090552 ]
  },
  "id_str" : "464750830043033601",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC see https:\/\/t.co\/llhGuwF831 (and srsly: the food &amp; the people were great :))",
  "id" : 464750830043033601,
  "in_reply_to_status_id" : 464748914462457856,
  "created_at" : "2014-05-09 12:56:47 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "R\u24EAss Mounce",
      "screen_name" : "rmounce",
      "indices" : [ 0, 8 ],
      "id_str" : "222765418",
      "id" : 222765418
    }, {
      "name" : "Tom Pollard",
      "screen_name" : "tompollard",
      "indices" : [ 9, 20 ],
      "id_str" : "19282539",
      "id" : 19282539
    }, {
      "name" : "Samuel Moore",
      "screen_name" : "samoore_",
      "indices" : [ 21, 30 ],
      "id_str" : "77294800",
      "id" : 77294800
    }, {
      "name" : "Paul Wicks",
      "screen_name" : "PaulLikeMe",
      "indices" : [ 98, 109 ],
      "id_str" : "375875836",
      "id" : 375875836
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "464723708628971520",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.5266590907, -0.13090552 ]
  },
  "id_str" : "464750454065602560",
  "in_reply_to_user_id" : 222765418,
  "text" : "@rmounce @tompollard @samoore_ I guess PLM produced many examples, even if it\u2019s not open sharing, @PaulLikeMe may have some.",
  "id" : 464750454065602560,
  "in_reply_to_status_id" : 464723708628971520,
  "created_at" : "2014-05-09 12:55:17 +0000",
  "in_reply_to_screen_name" : "rmounce",
  "in_reply_to_user_id_str" : "222765418",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.528687542, -0.12725139 ]
  },
  "id_str" : "464668088299163648",
  "text" : "looks like the cluster is now running fine \\o\/",
  "id" : 464668088299163648,
  "created_at" : "2014-05-09 07:28:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.528823987, -0.127021664 ]
  },
  "id_str" : "464665113560367104",
  "text" : "Email subject: \u00ABInstant winner at life\u00BB. Nearly deleted this as spam, turns out it\u2019s an openSNP user who looked at my data &amp; had good news.",
  "id" : 464665113560367104,
  "created_at" : "2014-05-09 07:16:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.5201760046, -0.1260831519 ]
  },
  "id_str" : "464529500865568769",
  "text" : "Next to the Gideons\u2019 bible: a magazine that features \u2018Love &amp; Sex: the science of long term lust\u2019 and \u2018Therapy by YouTube\u2019 on the cover.",
  "id" : 464529500865568769,
  "created_at" : "2014-05-08 22:17:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/Nezf1QHSRK",
      "expanded_url" : "http:\/\/instagram.com\/p\/nwIDBrhwp7\/",
      "display_url" : "instagram.com\/p\/nwIDBrhwp7\/"
    } ]
  },
  "geo" : { },
  "id_str" : "464526475543474176",
  "text" : "having been a member of the St. George scouting association for many years this was a nice surprise. http:\/\/t.co\/Nezf1QHSRK",
  "id" : 464526475543474176,
  "created_at" : "2014-05-08 22:05:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "464522497648787456",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.5201945873, -0.1262031852 ]
  },
  "id_str" : "464524583811678208",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon danke, du auch.",
  "id" : 464524583811678208,
  "in_reply_to_status_id" : 464522497648787456,
  "created_at" : "2014-05-08 21:57:45 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "464521065352658944",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.5202096636, -0.1262583065 ]
  },
  "id_str" : "464522323304120321",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon save and Sound ins Hotel gekommen. Morgen fr\u00FCh gibt es dann aber zusammen Kaffee. ;)",
  "id" : 464522323304120321,
  "in_reply_to_status_id" : 464521065352658944,
  "created_at" : "2014-05-08 21:48:46 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "464519705030832128",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.5219186078, -0.1276984307 ]
  },
  "id_str" : "464520839539744768",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon mit random strangern mitgehen die free candy versprechen? Na klar, bin doch PhD student.",
  "id" : 464520839539744768,
  "in_reply_to_status_id" : 464519705030832128,
  "created_at" : "2014-05-08 21:42:53 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.5263395698, -0.1335540663 ]
  },
  "id_str" : "464515208019730432",
  "text" : "TIL: random strangers will invite you to dinner if you look sufficiently lost.",
  "id" : 464515208019730432,
  "created_at" : "2014-05-08 21:20:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 52 ],
      "url" : "http:\/\/t.co\/nxagSfP6Ye",
      "expanded_url" : "http:\/\/instagram.com\/p\/nvsQmZhwv6\/",
      "display_url" : "instagram.com\/p\/nvsQmZhwv6\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.471107389, -0.486392801 ]
  },
  "id_str" : "464465367461818368",
  "text" : "venting @ Heathrow Terminal 5 http:\/\/t.co\/nxagSfP6Ye",
  "id" : 464465367461818368,
  "created_at" : "2014-05-08 18:02:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 64 ],
      "url" : "http:\/\/t.co\/WiQqnKzdHm",
      "expanded_url" : "http:\/\/instagram.com\/p\/nvXV3xBwh9\/",
      "display_url" : "instagram.com\/p\/nvXV3xBwh9\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.051144322, 8.589580607 ]
  },
  "id_str" : "464419371369390080",
  "text" : "cabin pressurized @ Irgendwo Uffm Vorfeld http:\/\/t.co\/WiQqnKzdHm",
  "id" : 464419371369390080,
  "created_at" : "2014-05-08 14:59:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 50 ],
      "url" : "http:\/\/t.co\/22t5BhCBud",
      "expanded_url" : "http:\/\/instagram.com\/p\/nvPlSHBwoG\/",
      "display_url" : "instagram.com\/p\/nvPlSHBwoG\/"
    } ]
  },
  "geo" : { },
  "id_str" : "464402305388146688",
  "text" : "Ohai, let me lick your face http:\/\/t.co\/22t5BhCBud",
  "id" : 464402305388146688,
  "created_at" : "2014-05-08 13:51:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723342467, 8.62761305 ]
  },
  "id_str" : "464363293914980352",
  "text" : "First world problems: \u00ABI guess found what\u2019s causing the crashes. By now we have too much memory.\u00BB",
  "id" : 464363293914980352,
  "created_at" : "2014-05-08 11:16:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/pDYGHQLhVk",
      "expanded_url" : "http:\/\/health.msn.co.nz\/healthnews\/8841734\/the-vibrating-pill-that-helps-you-poo",
      "display_url" : "health.msn.co.nz\/healthnews\/884\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723342467, 8.62761305 ]
  },
  "id_str" : "464345776806973440",
  "text" : "\u00ABThe vibrating pill that helps you poo\u00BB Fantastic Voyage, anyone? http:\/\/t.co\/pDYGHQLhVk",
  "id" : 464345776806973440,
  "created_at" : "2014-05-08 10:07:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "464337117469237248",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723342467, 8.62761305 ]
  },
  "id_str" : "464337553081257984",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot i\u2019ll remind you the next time _you\u2019re_ driving :P",
  "id" : 464337553081257984,
  "in_reply_to_status_id" : 464337117469237248,
  "created_at" : "2014-05-08 09:34:34 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "464326822675894273",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723342467, 8.62761305 ]
  },
  "id_str" : "464332608479170560",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot teaching \u2018if you just believe in yourself you can dash through all obstacles\u2019? :P",
  "id" : 464332608479170560,
  "in_reply_to_status_id" : 464326822675894273,
  "created_at" : "2014-05-08 09:14:55 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/TBVtuliW5I",
      "expanded_url" : "http:\/\/www.plosone.org\/article\/info%3Adoi%2F10.1371%2Fjournal.pone.0096654",
      "display_url" : "plosone.org\/article\/info%3\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723342467, 8.62761305 ]
  },
  "id_str" : "464325622614200320",
  "text" : "\u00ABthe results of the present study could not corroborate the idea that people are intuitively cooperative\u00BB http:\/\/t.co\/TBVtuliW5I",
  "id" : 464325622614200320,
  "created_at" : "2014-05-08 08:47:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dierk Haasis",
      "screen_name" : "Evo2Me",
      "indices" : [ 3, 10 ],
      "id_str" : "22910316",
      "id" : 22910316
    }, {
      "name" : "The A.V. Club",
      "screen_name" : "TheAVClub",
      "indices" : [ 83, 93 ],
      "id_str" : "16027904",
      "id" : 16027904
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/lmKHqBQ606",
      "expanded_url" : "http:\/\/www.avclub.com\/r\/203956tsd",
      "display_url" : "avclub.com\/r\/203956tsd"
    } ]
  },
  "geo" : { },
  "id_str" : "464323859391717376",
  "text" : "RT @Evo2Me: The Bechdel test is fine just the way it is http:\/\/t.co\/lmKHqBQ606 via @TheAVClub",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The A.V. Club",
        "screen_name" : "TheAVClub",
        "indices" : [ 71, 81 ],
        "id_str" : "16027904",
        "id" : 16027904
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 44, 66 ],
        "url" : "http:\/\/t.co\/lmKHqBQ606",
        "expanded_url" : "http:\/\/www.avclub.com\/r\/203956tsd",
        "display_url" : "avclub.com\/r\/203956tsd"
      } ]
    },
    "geo" : { },
    "id_str" : "464319599383543808",
    "text" : "The Bechdel test is fine just the way it is http:\/\/t.co\/lmKHqBQ606 via @TheAVClub",
    "id" : 464319599383543808,
    "created_at" : "2014-05-08 08:23:13 +0000",
    "user" : {
      "name" : "Dierk Haasis",
      "screen_name" : "Evo2Me",
      "protected" : false,
      "id_str" : "22910316",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/850012114496499712\/f7JQyj8P_normal.jpg",
      "id" : 22910316,
      "verified" : false
    }
  },
  "id" : 464323859391717376,
  "created_at" : "2014-05-08 08:40:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ali",
      "screen_name" : "zoonpolitikon",
      "indices" : [ 0, 14 ],
      "id_str" : "13040652",
      "id" : 13040652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "464314977692954624",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723342467, 8.62761305 ]
  },
  "id_str" : "464318255348592640",
  "in_reply_to_user_id" : 13040652,
  "text" : "@zoonpolitikon wie, das ist eine Beschimpfung?!",
  "id" : 464318255348592640,
  "in_reply_to_status_id" : 464314977692954624,
  "created_at" : "2014-05-08 08:17:53 +0000",
  "in_reply_to_screen_name" : "zoonpolitikon",
  "in_reply_to_user_id_str" : "13040652",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ali",
      "screen_name" : "zoonpolitikon",
      "indices" : [ 0, 14 ],
      "id_str" : "13040652",
      "id" : 13040652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "464312884647170048",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723342467, 8.62761305 ]
  },
  "id_str" : "464313969097052160",
  "in_reply_to_user_id" : 13040652,
  "text" : "@zoonpolitikon mich kostet das vermutlich keine Follower. Wer traditionell romantische Beliefs hat wird schon viel fr\u00FCher ausgestiegen sein.",
  "id" : 464313969097052160,
  "in_reply_to_status_id" : 464312884647170048,
  "created_at" : "2014-05-08 08:00:51 +0000",
  "in_reply_to_screen_name" : "zoonpolitikon",
  "in_reply_to_user_id_str" : "13040652",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/zp3NHhcSxJ",
      "expanded_url" : "http:\/\/jetzt.sueddeutsche.de\/texte\/anzeigen\/586546\/Der-Unsinn-des-einsamen-Gary",
      "display_url" : "jetzt.sueddeutsche.de\/texte\/anzeigen\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "464311470139133952",
  "text" : "\u00ABBeruhigt euch. Das Leben ist halt nicht so romantisch, wie ihr es gerne h\u00E4ttet. Es ist unendlich profan\u00BB http:\/\/t.co\/zp3NHhcSxJ",
  "id" : 464311470139133952,
  "created_at" : "2014-05-08 07:50:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "lifehacks",
      "indices" : [ 49, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/JewOpD7fKy",
      "expanded_url" : "http:\/\/www.wikihow.com\/Stop-a-Wedding",
      "display_url" : "wikihow.com\/Stop-a-Wedding"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723342467, 8.62761305 ]
  },
  "id_str" : "464309483762880512",
  "text" : "How to stop a wedding \u2013 with class &amp; dignity #lifehacks http:\/\/t.co\/JewOpD7fKy",
  "id" : 464309483762880512,
  "created_at" : "2014-05-08 07:43:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/ljOm2D11d2",
      "expanded_url" : "http:\/\/simplystatistics.org\/2014\/05\/07\/why-big-data-is-in-trouble-they-forgot-about-applied-statistics\/",
      "display_url" : "simplystatistics.org\/2014\/05\/07\/why\u2026"
    }, {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/B5riEu1tz1",
      "expanded_url" : "http:\/\/simplystatistics.org\/wp-content\/uploads\/2014\/05\/Screen-Shot-2014-05-06-at-9.06.38-PM.png",
      "display_url" : "simplystatistics.org\/wp-content\/upl\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723342467, 8.62761305 ]
  },
  "id_str" : "464307499743870976",
  "text" : "Why big data is in trouble: they forgot about applied statistics http:\/\/t.co\/ljOm2D11d2 http:\/\/t.co\/B5riEu1tz1",
  "id" : 464307499743870976,
  "created_at" : "2014-05-08 07:35:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 3, 16 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/9f95LbAoxg",
      "expanded_url" : "http:\/\/www.nature.com\/nature\/journal\/vaop\/ncurrent\/full\/nature13314.html",
      "display_url" : "nature.com\/nature\/journal\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "464305060525383681",
  "text" : "RT @PhilippBayer: This is amazing: 'A semi-synthetic organism with an expanded genetic alphabet' http:\/\/t.co\/9f95LbAoxg NYT: http:\/\/t.co\/Z0\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 79, 101 ],
        "url" : "http:\/\/t.co\/9f95LbAoxg",
        "expanded_url" : "http:\/\/www.nature.com\/nature\/journal\/vaop\/ncurrent\/full\/nature13314.html",
        "display_url" : "nature.com\/nature\/journal\u2026"
      }, {
        "indices" : [ 107, 129 ],
        "url" : "http:\/\/t.co\/Z0dtjTwfr5",
        "expanded_url" : "http:\/\/www.nytimes.com\/2014\/05\/08\/business\/researchers-report-breakthrough-in-creating-artificial-genetic-code.html?hp&_r=0",
        "display_url" : "nytimes.com\/2014\/05\/08\/bus\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "464204959966191616",
    "text" : "This is amazing: 'A semi-synthetic organism with an expanded genetic alphabet' http:\/\/t.co\/9f95LbAoxg NYT: http:\/\/t.co\/Z0dtjTwfr5",
    "id" : 464204959966191616,
    "created_at" : "2014-05-08 00:47:41 +0000",
    "user" : {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "protected" : false,
      "id_str" : "121777206",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2013711027\/IMG_1088_normal.png",
      "id" : 121777206,
      "verified" : false
    }
  },
  "id" : 464305060525383681,
  "created_at" : "2014-05-08 07:25:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/5iijCejjys",
      "expanded_url" : "http:\/\/www.quickmeme.com\/img\/d1\/d120d9338026e8756decd00f1a4d8f7ac922436b2a63412a9c4e16311e072d44.jpg",
      "display_url" : "quickmeme.com\/img\/d1\/d120d93\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "464299518662426625",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723342467, 8.62761305 ]
  },
  "id_str" : "464304507544166400",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer because lifecycle is a bit misleading in that case ;) http:\/\/t.co\/5iijCejjys",
  "id" : 464304507544166400,
  "in_reply_to_status_id" : 464299518662426625,
  "created_at" : "2014-05-08 07:23:15 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723342467, 8.62761305 ]
  },
  "id_str" : "464303827832016896",
  "text" : "\u00ABDer Hipster versetzt also die Welt mit seiner Ironie in Angst und Schrecken?\u00BB \u2013 \u00ABIch glaube das macht nur Hipster Hitler.\u00BB",
  "id" : 464303827832016896,
  "created_at" : "2014-05-08 07:20:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/MvO5yoN2zs",
      "expanded_url" : "http:\/\/mentalfloss.com\/article\/56621\/animals-chernobyl",
      "display_url" : "mentalfloss.com\/article\/56621\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723342467, 8.62761305 ]
  },
  "id_str" : "464302397960241152",
  "text" : "The Animals of Chernobyl http:\/\/t.co\/MvO5yoN2zs",
  "id" : 464302397960241152,
  "created_at" : "2014-05-08 07:14:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723214507, 8.6276226917 ]
  },
  "id_str" : "464299529861595136",
  "text" : "\u00ABDie Maschine l\u00E4uft lang genug und ist schon hei\u00DF, fast so hei\u00DF wie du!\u00BB",
  "id" : 464299529861595136,
  "created_at" : "2014-05-08 07:03:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "464293840736620544",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723342467, 8.62761305 ]
  },
  "id_str" : "464297717515419648",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer if it was Python they would just change the genetic code to make it backward incompatible. :D",
  "id" : 464297717515419648,
  "in_reply_to_status_id" : 464293840736620544,
  "created_at" : "2014-05-08 06:56:16 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "464275576228806656",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723342467, 8.62761305 ]
  },
  "id_str" : "464293546678571008",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer took me way to long to figure out why they only improved GC and not AT as well\u2026",
  "id" : 464293546678571008,
  "in_reply_to_status_id" : 464275576228806656,
  "created_at" : "2014-05-08 06:39:42 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1717951104, 8.6269265695 ]
  },
  "id_str" : "464288908067741696",
  "text" : "\u00ABWas w\u00FCrdest du machen wenn ich einen gr\u00F6\u00DFeren Penis h\u00E4tte?\u00BB \u2014 \u00ABEinen Rucksack kaufen um sein Gewicht auf beide Schultern zu verteilen!\u00BB",
  "id" : 464288908067741696,
  "created_at" : "2014-05-08 06:21:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 40 ],
      "url" : "http:\/\/t.co\/PdqbMfLxKv",
      "expanded_url" : "http:\/\/24.media.tumblr.com\/97e9a877480e866a3cf0877e7f7db4a5\/tumblr_mhuni1KyYO1r2b9p0o1_500.gif",
      "display_url" : "24.media.tumblr.com\/97e9a877480e86\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "464104511695749121",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.10208582, 8.6425177867 ]
  },
  "id_str" : "464107011412881408",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC related http:\/\/t.co\/PdqbMfLxKv ;)",
  "id" : 464107011412881408,
  "in_reply_to_status_id" : 464104511695749121,
  "created_at" : "2014-05-07 18:18:28 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 58 ],
      "url" : "http:\/\/t.co\/xcP2D5U1ro",
      "expanded_url" : "http:\/\/sd.keepcalm-o-matic.co.uk\/i\/keep-calm-and-kiss-the-cook-11.png",
      "display_url" : "sd.keepcalm-o-matic.co.uk\/i\/keep-calm-an\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "464101197692276736",
  "geo" : { },
  "id_str" : "464103150191116288",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC i\u2019ll just leave this here http:\/\/t.co\/xcP2D5U1ro",
  "id" : 464103150191116288,
  "in_reply_to_status_id" : 464101197692276736,
  "created_at" : "2014-05-07 18:03:08 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Herr Siering",
      "screen_name" : "HerrBertling",
      "indices" : [ 0, 13 ],
      "id_str" : "14115883",
      "id" : 14115883
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "464090163967438848",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1025653007, 8.6392796035 ]
  },
  "id_str" : "464090346486788096",
  "in_reply_to_user_id" : 14115883,
  "text" : "@HerrBertling kein Ding, bei unserem Timing sehen wir uns vermutlich irgendwann zuf\u00E4llig auf dem Prinzipalmarkt. :)",
  "id" : 464090346486788096,
  "in_reply_to_status_id" : 464090163967438848,
  "created_at" : "2014-05-07 17:12:15 +0000",
  "in_reply_to_screen_name" : "HerrBertling",
  "in_reply_to_user_id_str" : "14115883",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Herr Siering",
      "screen_name" : "HerrBertling",
      "indices" : [ 0, 13 ],
      "id_str" : "14115883",
      "id" : 14115883
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "464089730586787840",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.102587901, 8.6390028483 ]
  },
  "id_str" : "464089946547294208",
  "in_reply_to_user_id" : 14115883,
  "text" : "@HerrBertling h\u00E4ttest ja mal laut geben k\u00F6nnen. ;)",
  "id" : 464089946547294208,
  "in_reply_to_status_id" : 464089730586787840,
  "created_at" : "2014-05-07 17:10:40 +0000",
  "in_reply_to_screen_name" : "HerrBertling",
  "in_reply_to_user_id_str" : "14115883",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 46 ],
      "url" : "http:\/\/t.co\/u9ZKLyPxES",
      "expanded_url" : "http:\/\/instagram.com\/p\/ntBFMCBwmf\/",
      "display_url" : "instagram.com\/p\/ntBFMCBwmf\/"
    } ]
  },
  "geo" : { },
  "id_str" : "464088942338256896",
  "text" : "Gallus gallus (roasted) http:\/\/t.co\/u9ZKLyPxES",
  "id" : 464088942338256896,
  "created_at" : "2014-05-07 17:06:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.102200058, 8.6426624064 ]
  },
  "id_str" : "464079844469637120",
  "text" : "\u00ABIch will das in Br\u00FCssel auch ein Geb\u00E4ude nach mir benannt wird. Der Reda-Komplex!\u00BB \u2014 \u00ABKlingt nach ner psychological disorder, Gr\u00F6\u00DFenwahn.\u00BB",
  "id" : 464079844469637120,
  "created_at" : "2014-05-07 16:30:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1116955414, 8.6436928704 ]
  },
  "id_str" : "464073566397669377",
  "text" : "Mein S-Bahn fahren nutzt heute das Intervallhalbierungsverfahren. 2x \u00FCbers Ziel hinausgeschossen\u2026 Werde also niemals ankommen.",
  "id" : 464073566397669377,
  "created_at" : "2014-05-07 16:05:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cm",
      "indices" : [ 115, 118 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1126625137, 8.6743450569 ]
  },
  "id_str" : "464071182027722752",
  "text" : "\u00ABIn the face of an extraordinary complex problem, power needed to be pushed out of the center as far as possible.\u00BB #cm",
  "id" : 464071182027722752,
  "created_at" : "2014-05-07 15:56:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cm",
      "indices" : [ 101, 104 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723342467, 8.62761305 ]
  },
  "id_str" : "464056909952450560",
  "text" : "\u00ABHe tried the usual surgical approach to remedy this\u2013yelling at everyone to get their act together.\u00BB #cm",
  "id" : 464056909952450560,
  "created_at" : "2014-05-07 14:59:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723342467, 8.62761305 ]
  },
  "id_str" : "464043298362257408",
  "text" : "\u00ABCool, you brought the DNA library. Let\u2019s see whether there\u2019s some space in the fridge or if we will have to eat ice cream to clear some.\u00BB",
  "id" : 464043298362257408,
  "created_at" : "2014-05-07 14:05:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mm",
      "indices" : [ 55, 58 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723342467, 8.62761305 ]
  },
  "id_str" : "464034426008375296",
  "text" : "\u00ABFor Helicobacter pylori, free love is a way of life.\u00BB #mm",
  "id" : 464034426008375296,
  "created_at" : "2014-05-07 13:30:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CSH",
      "screen_name" : "CSHLaboratory",
      "indices" : [ 3, 17 ],
      "id_str" : "1235031679",
      "id" : 1235031679
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MinistryofSIllyTalks",
      "indices" : [ 112, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "464031255122571266",
  "text" : "RT @CSHLaboratory: Also: \"Nobody expects the Spanish Inquisition: motivational tools for slacker grad students\" #MinistryofSIllyTalks",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MinistryofSIllyTalks",
        "indices" : [ 93, 114 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "464031195198533632",
    "text" : "Also: \"Nobody expects the Spanish Inquisition: motivational tools for slacker grad students\" #MinistryofSIllyTalks",
    "id" : 464031195198533632,
    "created_at" : "2014-05-07 13:17:12 +0000",
    "user" : {
      "name" : "CSH",
      "screen_name" : "CSHLaboratory",
      "protected" : false,
      "id_str" : "1235031679",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3331354215\/0dc1156eaf41055aef53e3dcd8e345ce_normal.png",
      "id" : 1235031679,
      "verified" : false
    }
  },
  "id" : 464031255122571266,
  "created_at" : "2014-05-07 13:17:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/4lfH8svFVu",
      "expanded_url" : "https:\/\/theconversation.com\/what-is-the-point-of-spotting-sex-differences-if-science-cannot-explain-them-26125",
      "display_url" : "theconversation.com\/what-is-the-po\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723342467, 8.62761305 ]
  },
  "id_str" : "464027829630283777",
  "text" : "What is the point of spotting sex differences if science cannot explain\u00A0them? https:\/\/t.co\/4lfH8svFVu",
  "id" : 464027829630283777,
  "created_at" : "2014-05-07 13:03:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/8mKoGEHLBe",
      "expanded_url" : "http:\/\/37.media.tumblr.com\/tumblr_l7mgtgeBa91qc073co1_400.gif",
      "display_url" : "37.media.tumblr.com\/tumblr_l7mgtge\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723342467, 8.62761305 ]
  },
  "id_str" : "464016155980890112",
  "text" : "\u00ABWir haben noch Geld f\u00FCr B\u00FCcher, sagt mir mal was ihr gerne h\u00E4ttet.\u00BB http:\/\/t.co\/8mKoGEHLBe",
  "id" : 464016155980890112,
  "created_at" : "2014-05-07 12:17:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/TSLlYl5xl0",
      "expanded_url" : "http:\/\/cdn1.arkive.org\/media\/57\/57A98F58-1113-40C3-A159-C62E36669C5F\/Presentation.Large\/Molly-del-Teapa-La-Gloria-male.jpg",
      "display_url" : "cdn1.arkive.org\/media\/57\/57A98\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "464013599120183296",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723342467, 8.62761305 ]
  },
  "id_str" : "464014401113034752",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot mittlerweile erinnert das diese Dinger gemeint waren: http:\/\/t.co\/TSLlYl5xl0",
  "id" : 464014401113034752,
  "in_reply_to_status_id" : 464013599120183296,
  "created_at" : "2014-05-07 12:10:28 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/KfzQLjqVbh",
      "expanded_url" : "http:\/\/phylo.cs.mcgill.ca\/",
      "display_url" : "phylo.cs.mcgill.ca"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723342467, 8.62761305 ]
  },
  "id_str" : "464006777747800064",
  "text" : "Wow, never noticed the cool background jazz @ PHYLO before. http:\/\/t.co\/KfzQLjqVbh",
  "id" : 464006777747800064,
  "created_at" : "2014-05-07 11:40:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723342467, 8.62761305 ]
  },
  "id_str" : "464004095980752896",
  "text" : "Meine To-Do-Liste enth\u00E4lt einen Eintrag der schlicht \u2018poesielos\u2019 heisst. Nicht sicher ob ich betrunken war oder die Autokorrektur schuld ist",
  "id" : 464004095980752896,
  "created_at" : "2014-05-07 11:29:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "C\u24D0thal G\u24D0rvey",
      "screen_name" : "onetruecathal",
      "indices" : [ 0, 14 ],
      "id_str" : "16066596",
      "id" : 16066596
    }, {
      "name" : "The Meaning of Liff",
      "screen_name" : "ThatsLiff",
      "indices" : [ 15, 25 ],
      "id_str" : "431558375",
      "id" : 431558375
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "463941208965120000",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1102208433, 8.6832869462 ]
  },
  "id_str" : "463943705477808128",
  "in_reply_to_user_id" : 16066596,
  "text" : "@onetruecathal @ThatsLiff sounds like a rescaled version of angst. ;)",
  "id" : 463943705477808128,
  "in_reply_to_status_id" : 463941208965120000,
  "created_at" : "2014-05-07 07:29:33 +0000",
  "in_reply_to_screen_name" : "onetruecathal",
  "in_reply_to_user_id_str" : "16066596",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "463936307383640064",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0726931822, 8.4953061305 ]
  },
  "id_str" : "463937077126893568",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer i think it should have a 'i feel lucky'-button where a RNG decides whether the NO goes to the engine or into the cabin. :p",
  "id" : 463937077126893568,
  "in_reply_to_status_id" : 463936307383640064,
  "created_at" : "2014-05-07 07:03:13 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "463935342576279552",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0185384489, 8.4325424342 ]
  },
  "id_str" : "463935759125585920",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer founding myth: 'hooking the nitro only to your car always seems such a waste to me.'",
  "id" : 463935759125585920,
  "in_reply_to_status_id" : 463935342576279552,
  "created_at" : "2014-05-07 06:57:59 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "463901174823792640",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0185384489, 8.4325424342 ]
  },
  "id_str" : "463935104273113088",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer that's what you get for not having a drug button in your car :D",
  "id" : 463935104273113088,
  "in_reply_to_status_id" : 463901174823792640,
  "created_at" : "2014-05-07 06:55:23 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "C\u24D0thal G\u24D0rvey",
      "screen_name" : "onetruecathal",
      "indices" : [ 0, 14 ],
      "id_str" : "16066596",
      "id" : 16066596
    }, {
      "name" : "The Meaning of Liff",
      "screen_name" : "ThatsLiff",
      "indices" : [ 15, 25 ],
      "id_str" : "431558375",
      "id" : 431558375
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "463932919200104448",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.003384566, 8.3735734876 ]
  },
  "id_str" : "463934105970036736",
  "in_reply_to_user_id" : 16066596,
  "text" : "@onetruecathal @ThatsLiff should come up with something better than Langzeitberechnungsversagensangst though.",
  "id" : 463934105970036736,
  "in_reply_to_status_id" : 463932919200104448,
  "created_at" : "2014-05-07 06:51:25 +0000",
  "in_reply_to_screen_name" : "onetruecathal",
  "in_reply_to_user_id_str" : "16066596",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0071948421, 8.2828860189 ]
  },
  "id_str" : "463930964784058368",
  "text" : "Is there a term for the fear that your computations will crash as soon as you stop tailing the log files?",
  "id" : 463930964784058368,
  "created_at" : "2014-05-07 06:38:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 67 ],
      "url" : "http:\/\/t.co\/6Pfb0sqg7v",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=9jgleXclGvQ",
      "display_url" : "youtube.com\/watch?v=9jgleX\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009612964, 8.282973694 ]
  },
  "id_str" : "463828081971458048",
  "text" : "the flutter of fortune, the bringer of gloom http:\/\/t.co\/6Pfb0sqg7v",
  "id" : 463828081971458048,
  "created_at" : "2014-05-06 23:50:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/JqqWLeBngW",
      "expanded_url" : "http:\/\/blog.staedelmuseum.de\/erwin-wurm-im-stadel\/einmal-hund-sein-oder-wirf-dich-weg-erste-einblicke-in-die-erwin-wurm-ausstellung-im-stadel",
      "display_url" : "blog.staedelmuseum.de\/erwin-wurm-im-\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009612964, 8.282973694 ]
  },
  "id_str" : "463814986251251712",
  "text" : "\u00ABEinmal Hund sein\u00BB und dazu noch hosenlos rumstehen? Das St\u00E4del weiss wie es meine Aufmerksamkeit bekommt. http:\/\/t.co\/JqqWLeBngW",
  "id" : 463814986251251712,
  "created_at" : "2014-05-06 22:58:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/X6HtjE6KvT",
      "expanded_url" : "http:\/\/31.media.tumblr.com\/tumblr_lkhljmdf1J1qi9q4ko1_500.gif",
      "display_url" : "31.media.tumblr.com\/tumblr_lkhljmd\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009612964, 8.282973694 ]
  },
  "id_str" : "463792686466465792",
  "text" : "My passport should be somewhere on my desk. Let me just grab my fedora before I start digging for it\u2026 http:\/\/t.co\/X6HtjE6KvT",
  "id" : 463792686466465792,
  "created_at" : "2014-05-06 21:29:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "463782468777046016",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096479144, 8.2830042657 ]
  },
  "id_str" : "463782699891580928",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot ich dachte mehr an \u2018Bodo Problemb\u00E4r auf dem Piratenschiff\u2019",
  "id" : 463782699891580928,
  "in_reply_to_status_id" : 463782468777046016,
  "created_at" : "2014-05-06 20:49:46 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0104568175, 8.4554340399 ]
  },
  "id_str" : "463771891694440449",
  "text" : "Die S-Bahn ist neu, kann daher nat\u00FCrlich nur 50 km\/h fahren. Zum Gl\u00FCck l\u00E4sst mich die Sitznachbarin mit \u2018Bodo B\u00E4r auf der Ritterburg\u2019 lesen.",
  "id" : 463771891694440449,
  "created_at" : "2014-05-06 20:06:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "_quoth_",
      "screen_name" : "ibews",
      "indices" : [ 0, 6 ],
      "id_str" : "2913051689",
      "id" : 2913051689
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "463765301075935232",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0645961541, 8.609663731 ]
  },
  "id_str" : "463766285873319936",
  "in_reply_to_user_id" : 57908725,
  "text" : "@ibews more or less free food for thought. ;)",
  "id" : 463766285873319936,
  "in_reply_to_status_id" : 463765301075935232,
  "created_at" : "2014-05-06 19:44:33 +0000",
  "in_reply_to_screen_name" : "_quoth_",
  "in_reply_to_user_id_str" : "57908725",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1114359353, 8.6601099718 ]
  },
  "id_str" : "463764024006803456",
  "text" : "Academia: I'm only in it for the nice discussions over dinner.",
  "id" : 463764024006803456,
  "created_at" : "2014-05-06 19:35:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tina alt",
      "screen_name" : "tnakng",
      "indices" : [ 3, 10 ],
      "id_str" : "709415983870558208",
      "id" : 709415983870558208
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "followerpower",
      "indices" : [ 125, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/xojuaPRVEt",
      "expanded_url" : "http:\/\/www.wg-gesucht.de\/wg-zimmer-in-Wiesbaden-Wiesbaden.4412723.html",
      "display_url" : "wg-gesucht.de\/wg-zimmer-in-W\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463713511898873856",
  "text" : "RT @TnaKng: Bei einer guten Freundin wird in Wiesbaden ein Zimmer in der WG frei. 19qm 267 Euro warm. http:\/\/t.co\/xojuaPRVEt #followerpower\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "followerpower",
        "indices" : [ 113, 127 ]
      } ],
      "urls" : [ {
        "indices" : [ 90, 112 ],
        "url" : "http:\/\/t.co\/xojuaPRVEt",
        "expanded_url" : "http:\/\/www.wg-gesucht.de\/wg-zimmer-in-Wiesbaden-Wiesbaden.4412723.html",
        "display_url" : "wg-gesucht.de\/wg-zimmer-in-W\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "463426855086071808",
    "text" : "Bei einer guten Freundin wird in Wiesbaden ein Zimmer in der WG frei. 19qm 267 Euro warm. http:\/\/t.co\/xojuaPRVEt #followerpower plsrt",
    "id" : 463426855086071808,
    "created_at" : "2014-05-05 21:15:46 +0000",
    "user" : {
      "name" : "Tina",
      "screen_name" : "trotzdemda",
      "protected" : false,
      "id_str" : "339564605",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/430349867920015360\/MEsO92es_normal.png",
      "id" : 339564605,
      "verified" : false
    }
  },
  "id" : 463713511898873856,
  "created_at" : "2014-05-06 16:14:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Scheloske",
      "screen_name" : "Werkstatt",
      "indices" : [ 0, 10 ],
      "id_str" : "14350184",
      "id" : 14350184
    }, {
      "name" : "DetritusBlog",
      "screen_name" : "gedankenabfall",
      "indices" : [ 77, 92 ],
      "id_str" : "2175883684",
      "id" : 2175883684
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "463699777193250817",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1782840104, 8.6221987467 ]
  },
  "id_str" : "463703663748579328",
  "in_reply_to_user_id" : 14350184,
  "text" : "@Werkstatt ah, mit meinem Rageaccount. Passiert glaube ich auch andersrum ;) @gedankenabfall",
  "id" : 463703663748579328,
  "in_reply_to_status_id" : 463699777193250817,
  "created_at" : "2014-05-06 15:35:43 +0000",
  "in_reply_to_screen_name" : "Werkstatt",
  "in_reply_to_user_id_str" : "14350184",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/NzZifk1pvz",
      "expanded_url" : "http:\/\/bigbensreviews.com\/wp-content\/uploads\/2014\/02\/Dog-with-Diabetes.jpg",
      "display_url" : "bigbensreviews.com\/wp-content\/upl\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "463696968767012864",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1761013923, 8.6189111533 ]
  },
  "id_str" : "463697735347339264",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot the canine centipede. But I would probably end up like this: http:\/\/t.co\/NzZifk1pvz",
  "id" : 463697735347339264,
  "in_reply_to_status_id" : 463696968767012864,
  "created_at" : "2014-05-06 15:12:09 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Scheloske",
      "screen_name" : "Werkstatt",
      "indices" : [ 0, 10 ],
      "id_str" : "14350184",
      "id" : 14350184
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "463695278772850688",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723342467, 8.62761305 ]
  },
  "id_str" : "463695750124556288",
  "in_reply_to_user_id" : 14350184,
  "text" : "@Werkstatt wie hab ich das denn gemacht? ;)",
  "id" : 463695750124556288,
  "in_reply_to_status_id" : 463695278772850688,
  "created_at" : "2014-05-06 15:04:16 +0000",
  "in_reply_to_screen_name" : "Werkstatt",
  "in_reply_to_user_id_str" : "14350184",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 45 ],
      "url" : "https:\/\/t.co\/DGZEv6bVkT",
      "expanded_url" : "https:\/\/emily.st\/2014\/05\/05\/through-the-warp-zone\/",
      "display_url" : "emily.st\/2014\/05\/05\/thr\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723342467, 8.62761305 ]
  },
  "id_str" : "463690078980964352",
  "text" : "Through the Warp Zone https:\/\/t.co\/DGZEv6bVkT",
  "id" : 463690078980964352,
  "created_at" : "2014-05-06 14:41:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/b69plIuc4S",
      "expanded_url" : "http:\/\/blogs.scientificamerican.com\/food-matters\/2014\/05\/06\/cheese-microbiome\/",
      "display_url" : "blogs.scientificamerican.com\/food-matters\/2\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723342467, 8.62761305 ]
  },
  "id_str" : "463677622753697793",
  "text" : "Cheese as a model organomnomnomism to study microbial interactions http:\/\/t.co\/b69plIuc4S",
  "id" : 463677622753697793,
  "created_at" : "2014-05-06 13:52:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/Otn6GodKAQ",
      "expanded_url" : "http:\/\/0.media.collegehumor.cvcdn.com\/65\/55\/92db3fe9ad7826af78270329b23fb2c1-infinite-puppy-loop.gif",
      "display_url" : "0.media.collegehumor.cvcdn.com\/65\/55\/92db3fe9\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "463672847198851072",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723342467, 8.62761305 ]
  },
  "id_str" : "463676912536391680",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot result: \u201Ctracked my ice cream consumption, better treat myself to some ice cream for all the hard work\u201D http:\/\/t.co\/Otn6GodKAQ",
  "id" : 463676912536391680,
  "in_reply_to_status_id" : 463672847198851072,
  "created_at" : "2014-05-06 13:49:25 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/463668638583885825\/photo\/1",
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/CkUzwtxeWB",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bm9IK4VIMAATNrS.png",
      "id_str" : "463668638399344640",
      "id" : 463668638399344640,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bm9IK4VIMAATNrS.png",
      "sizes" : [ {
        "h" : 3494,
        "resize" : "fit",
        "w" : 5987
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 1195,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 397,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/CkUzwtxeWB"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723342467, 8.62761305 ]
  },
  "id_str" : "463668638583885825",
  "text" : "coffee consumption at work over the last year (~230 workdays): 634 espresso, cost: 247.26 \u20AC http:\/\/t.co\/CkUzwtxeWB",
  "id" : 463668638583885825,
  "created_at" : "2014-05-06 13:16:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 74 ],
      "url" : "http:\/\/t.co\/Xnt2btXnRl",
      "expanded_url" : "http:\/\/www.smbc-comics.com\/index.php?db=comics&id=3348",
      "display_url" : "smbc-comics.com\/index.php?db=c\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723342467, 8.62761305 ]
  },
  "id_str" : "463659614601756672",
  "text" : "oh, that\u2019s how \u2018only the good die young\u2019 was meant! http:\/\/t.co\/Xnt2btXnRl",
  "id" : 463659614601756672,
  "created_at" : "2014-05-06 12:40:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723342467, 8.62761305 ]
  },
  "id_str" : "463608889406390272",
  "text" : "\u00ABAchso, du meinst du erf\u00FCllst dein Sportpensum schon durch das Weglaufen vor der Arbeit?\u00BB",
  "id" : 463608889406390272,
  "created_at" : "2014-05-06 09:19:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0943486672, 8.6285599507 ]
  },
  "id_str" : "463599394852700160",
  "text" : "\u00ABI don\u2019t think writers are any smarter than other people. I think they may be more compelling in their stupidity, or their confusion.\u00BB",
  "id" : 463599394852700160,
  "created_at" : "2014-05-06 08:41:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "463580979546714112",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1707537842, 8.6235160398 ]
  },
  "id_str" : "463582038449471488",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer movie: yes, should work well as it\u2019s as roadmovie as it gets. ;)",
  "id" : 463582038449471488,
  "in_reply_to_status_id" : 463580979546714112,
  "created_at" : "2014-05-06 07:32:25 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "463580979546714112",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1700319239, 8.622669089 ]
  },
  "id_str" : "463581786824785921",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer yeah, thanks for the recommendation. Finished on Sunday and still have a backlog of quotes to go through :D",
  "id" : 463581786824785921,
  "in_reply_to_status_id" : 463580979546714112,
  "created_at" : "2014-05-06 07:31:25 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0943486672, 8.6285599507 ]
  },
  "id_str" : "463579468687495168",
  "text" : "\u00ABI\u2019m now so scared of having the ambition be, to be regarded well by other people. Just cause it\u2019s\u2014it landed me in a suicide ward.\u00BB",
  "id" : 463579468687495168,
  "created_at" : "2014-05-06 07:22:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emanuel Wyler",
      "screen_name" : "ewyler",
      "indices" : [ 0, 7 ],
      "id_str" : "122329006",
      "id" : 122329006
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 8, 17 ],
      "id_str" : "14861745",
      "id" : 14861745
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 18, 31 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "463576546222309376",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1028693554, 8.6497141571 ]
  },
  "id_str" : "463577152353746944",
  "in_reply_to_user_id" : 122329006,
  "text" : "@ewyler @Senficon @PhilippBayer okay, viel Erfolg! :)",
  "id" : 463577152353746944,
  "in_reply_to_status_id" : 463576546222309376,
  "created_at" : "2014-05-06 07:13:00 +0000",
  "in_reply_to_screen_name" : "ewyler",
  "in_reply_to_user_id_str" : "122329006",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0932753046, 8.6263252936 ]
  },
  "id_str" : "463572312202420224",
  "text" : "\u00ABIf anybody was fated to fuck up a suicide attempt, it was me. Which gives you some idea of my mind-set at the time.\u00BB",
  "id" : 463572312202420224,
  "created_at" : "2014-05-06 06:53:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Witten \uD83C\uDFC9 \uD83D\uDD2C",
      "screen_name" : "joshwitten",
      "indices" : [ 99, 110 ],
      "id_str" : "46743752",
      "id" : 46743752
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/8UFnJlcKYF",
      "expanded_url" : "http:\/\/www.earthtouchnews.com\/wildlife\/freaky-nature\/more-than-you-ever-wanted-to-know-about-dung-beetles#.U2VO0W_bFjw.twitter",
      "display_url" : "earthtouchnews.com\/wildlife\/freak\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0070635131, 8.2828564451 ]
  },
  "id_str" : "463563538175623168",
  "text" : "Aren\u2019t dung beetles awesome?! Now I really want to learn more about them http:\/\/t.co\/8UFnJlcKYF HT @joshwitten",
  "id" : 463563538175623168,
  "created_at" : "2014-05-06 06:18:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John S. Wilkins",
      "screen_name" : "john_s_wilkins",
      "indices" : [ 3, 18 ],
      "id_str" : "76013938",
      "id" : 76013938
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/z4eWs6K4fw",
      "expanded_url" : "http:\/\/www.skepticalraptor.com\/skepticalraptorblog.php\/false-ideology-science-deniers-research-easy\/",
      "display_url" : "skepticalraptor.com\/skepticalrapto\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463478632108007424",
  "text" : "RT @john_s_wilkins: The false ideology of science deniers\u2013research is easy http:\/\/t.co\/z4eWs6K4fw",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 55, 77 ],
        "url" : "http:\/\/t.co\/z4eWs6K4fw",
        "expanded_url" : "http:\/\/www.skepticalraptor.com\/skepticalraptorblog.php\/false-ideology-science-deniers-research-easy\/",
        "display_url" : "skepticalraptor.com\/skepticalrapto\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "463475508936577024",
    "text" : "The false ideology of science deniers\u2013research is easy http:\/\/t.co\/z4eWs6K4fw",
    "id" : 463475508936577024,
    "created_at" : "2014-05-06 00:29:06 +0000",
    "user" : {
      "name" : "John S. Wilkins",
      "screen_name" : "john_s_wilkins",
      "protected" : false,
      "id_str" : "76013938",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/852294288838807552\/FZpeLbxA_normal.jpg",
      "id" : 76013938,
      "verified" : false
    }
  },
  "id" : 463478632108007424,
  "created_at" : "2014-05-06 00:41:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 122, 144 ],
      "url" : "http:\/\/t.co\/kZHfQLtkMq",
      "expanded_url" : "http:\/\/www.plosone.org\/article\/info%3Adoi%2F10.1371%2Fjournal.pone.0095572#s2",
      "display_url" : "plosone.org\/article\/info%3\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00964131, 8.2830322267 ]
  },
  "id_str" : "463454465878941696",
  "text" : "Exposure to a Disgusting Odorant Increases Politically Conservative Views on Sex &amp; Decreases Support for Gay Marriage http:\/\/t.co\/kZHfQLtkMq",
  "id" : 463454465878941696,
  "created_at" : "2014-05-05 23:05:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/F2wtbvrTYZ",
      "expanded_url" : "http:\/\/boingboing.net\/2014\/05\/05\/dogs-playing-bluegrass-video.html",
      "display_url" : "boingboing.net\/2014\/05\/05\/dog\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00964131, 8.2830322267 ]
  },
  "id_str" : "463451606361837568",
  "text" : "while the cat may like listening to me playing guitar, this is even better: dogs playing bluegrass http:\/\/t.co\/F2wtbvrTYZ",
  "id" : 463451606361837568,
  "created_at" : "2014-05-05 22:54:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095906226, 8.2828642817 ]
  },
  "id_str" : "463446080995459072",
  "text" : "One day I will trip over the cat while playing guitar and then there will be three broken necks\u2026",
  "id" : 463446080995459072,
  "created_at" : "2014-05-05 22:32:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/m70eFW9iIh",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=E2Ug97U6ZaQ",
      "display_url" : "youtube.com\/watch?v=E2Ug97\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095865586, 8.2828393657 ]
  },
  "id_str" : "463438772773072896",
  "text" : "it\u2019s the way you are living which counts to me &amp; the way you are living is nice to see http:\/\/t.co\/m70eFW9iIh",
  "id" : 463438772773072896,
  "created_at" : "2014-05-05 22:03:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emanuel Wyler",
      "screen_name" : "ewyler",
      "indices" : [ 0, 7 ],
      "id_str" : "122329006",
      "id" : 122329006
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 8, 17 ],
      "id_str" : "14861745",
      "id" : 14861745
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 18, 31 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "463423371020353536",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095865586, 8.2828393657 ]
  },
  "id_str" : "463424454010609665",
  "in_reply_to_user_id" : 122329006,
  "text" : "@ewyler @Senficon @PhilippBayer cool, wenn du sonst noch was brauchst melde dich :)",
  "id" : 463424454010609665,
  "in_reply_to_status_id" : 463423371020353536,
  "created_at" : "2014-05-05 21:06:14 +0000",
  "in_reply_to_screen_name" : "ewyler",
  "in_reply_to_user_id_str" : "122329006",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095865586, 8.2828393657 ]
  },
  "id_str" : "463418219072876544",
  "text" : "doing interdisciplinary work: one of the best ways to fast-track your personal growth. and one of the best ways to always feel inadequate.",
  "id" : 463418219072876544,
  "created_at" : "2014-05-05 20:41:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sci Curious",
      "screen_name" : "scicurious",
      "indices" : [ 3, 14 ],
      "id_str" : "31443503",
      "id" : 31443503
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/WSYhtW0n1a",
      "expanded_url" : "https:\/\/www.sciencenews.org\/article\/how-milk-naked-mole-rat",
      "display_url" : "sciencenews.org\/article\/how-mi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463392184231010304",
  "text" : "RT @scicurious: Naked mole rats are so transclucent that you can see the milk building up in their glands! https:\/\/t.co\/WSYhtW0n1a by @susa\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Susan Milius",
        "screen_name" : "susanmilius",
        "indices" : [ 118, 130 ],
        "id_str" : "19599946",
        "id" : 19599946
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 91, 114 ],
        "url" : "https:\/\/t.co\/WSYhtW0n1a",
        "expanded_url" : "https:\/\/www.sciencenews.org\/article\/how-milk-naked-mole-rat",
        "display_url" : "sciencenews.org\/article\/how-mi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "463391824921755648",
    "text" : "Naked mole rats are so transclucent that you can see the milk building up in their glands! https:\/\/t.co\/WSYhtW0n1a by @susanmilius",
    "id" : 463391824921755648,
    "created_at" : "2014-05-05 18:56:35 +0000",
    "user" : {
      "name" : "Sci Curious",
      "screen_name" : "scicurious",
      "protected" : false,
      "id_str" : "31443503",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/905120517052620800\/uq2q-fjc_normal.jpg",
      "id" : 31443503,
      "verified" : true
    }
  },
  "id" : 463392184231010304,
  "created_at" : "2014-05-05 18:58:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0073601865, 8.2800741121 ]
  },
  "id_str" : "463378550436147200",
  "text" : "\u00ABDu wohnst \u00FCber uns oder? Deinen Metal h\u00F6rt man ab &amp; an, gef\u00E4llt mir.\u00BB\u2014\u00ABAh, du wohnst unter mir. Euch h\u00F6rt man ab &amp; an v\u00F6geln, gef\u00E4llt mir!\u00BB",
  "id" : 463378550436147200,
  "created_at" : "2014-05-05 18:03:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.169384827, 8.6223978627 ]
  },
  "id_str" : "463357446841704448",
  "text" : "\u201EMh, ich muss mal \u00FCberlegen was gute Beispiele f\u00FCr \u00DCbersprungshandlungen sind\u201C sagen und sich dabei nachdenklich durch den Bart fahren.",
  "id" : 463357446841704448,
  "created_at" : "2014-05-05 16:39:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/GJGoL15Ldm",
      "expanded_url" : "https:\/\/www.flickr.com\/photos\/maltman23\/5329280590",
      "display_url" : "flickr.com\/photos\/maltman\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17233176, 8.627618476 ]
  },
  "id_str" : "463345099905433600",
  "text" : "Someday I might give a talk on openSNP w\/o including a pic of me sleeping in the 27c3 ball pit. But not this week. https:\/\/t.co\/GJGoL15Ldm",
  "id" : 463345099905433600,
  "created_at" : "2014-05-05 15:50:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "463329778079395840",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17233176, 8.627618476 ]
  },
  "id_str" : "463330193994944512",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon immerhin, du musstest nur Spitzenkandidatin werden um nicht mehr nur \u2018die Freundin von\u2026\u2019 zu sein.",
  "id" : 463330193994944512,
  "in_reply_to_status_id" : 463329778079395840,
  "created_at" : "2014-05-05 14:51:41 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "463323599928328192",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17233176, 8.627618476 ]
  },
  "id_str" : "463324090015961088",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon schon gut. Als Ausgleich m\u00F6chte ich dann nur das du genetic privacy auf EU Ebene senkst. [VT in 5 4 3 2 1\u2026]",
  "id" : 463324090015961088,
  "in_reply_to_status_id" : 463323599928328192,
  "created_at" : "2014-05-05 14:27:25 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "463321365706473472",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17233176, 8.627618476 ]
  },
  "id_str" : "463321814794792960",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon sage aber immer brav das ich damit nichts zu tun habe und nur deine Abgeordneten-Bez\u00FCge verprassen will.",
  "id" : 463321814794792960,
  "in_reply_to_status_id" : 463321365706473472,
  "created_at" : "2014-05-05 14:18:23 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "463321365706473472",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17233176, 8.627618476 ]
  },
  "id_str" : "463321603171172352",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon davon aktiver Pirat zu sein, wegen der Einladung die ich dir abfotografiert hatte.",
  "id" : 463321603171172352,
  "in_reply_to_status_id" : 463321365706473472,
  "created_at" : "2014-05-05 14:17:32 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emanuel Wyler",
      "screen_name" : "ewyler",
      "indices" : [ 0, 7 ],
      "id_str" : "122329006",
      "id" : 122329006
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 8, 21 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 22, 31 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "463319229731987456",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17233176, 8.627618476 ]
  },
  "id_str" : "463319774513340416",
  "in_reply_to_user_id" : 122329006,
  "text" : "@ewyler @PhilippBayer @Senficon nur halt nicht zentral, annotiert und per API. Au\u00DFerdem Movitation: Offen f\u00FCr alle, anders als z.B. das PGP.",
  "id" : 463319774513340416,
  "in_reply_to_status_id" : 463319229731987456,
  "created_at" : "2014-05-05 14:10:16 +0000",
  "in_reply_to_screen_name" : "ewyler",
  "in_reply_to_user_id_str" : "122329006",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emanuel Wyler",
      "screen_name" : "ewyler",
      "indices" : [ 0, 7 ],
      "id_str" : "122329006",
      "id" : 122329006
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 8, 21 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 22, 31 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "463319229731987456",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17233176, 8.627618476 ]
  },
  "id_str" : "463319520372084736",
  "in_reply_to_user_id" : 122329006,
  "text" : "@ewyler @PhilippBayer @Senficon Datensouver\u00E4nit\u00E4t weniger. Runterladen &amp; neu ver\u00F6ffentlichen konnte man ja vorher schon.",
  "id" : 463319520372084736,
  "in_reply_to_status_id" : 463319229731987456,
  "created_at" : "2014-05-05 14:09:16 +0000",
  "in_reply_to_screen_name" : "ewyler",
  "in_reply_to_user_id_str" : "122329006",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 6, 15 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/ruKQCWmTmE",
      "expanded_url" : "http:\/\/media2.giphy.com\/media\/Qvx4qnHPL1LDa\/giphy.gif",
      "display_url" : "media2.giphy.com\/media\/Qvx4qnHP\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17233176, 8.627618476 ]
  },
  "id_str" : "463314062047477760",
  "text" : "Wegen @Senficon st\u00E4ndig in Piraten-Sippenhaft genommen werden\u2026 http:\/\/t.co\/ruKQCWmTmE",
  "id" : 463314062047477760,
  "created_at" : "2014-05-05 13:47:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    }, {
      "name" : "not best practice",
      "screen_name" : "moeffju",
      "indices" : [ 20, 28 ],
      "id_str" : "5618832",
      "id" : 5618832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "463307631570862080",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17233176, 8.627618476 ]
  },
  "id_str" : "463307730628145152",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot wenn das der @moeffju w\u00FCsste!",
  "id" : 463307730628145152,
  "in_reply_to_status_id" : 463307631570862080,
  "created_at" : "2014-05-05 13:22:25 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 42 ],
      "url" : "http:\/\/t.co\/7wqukeZWWA",
      "expanded_url" : "http:\/\/instagram.com\/p\/nnayj-hwhk\/",
      "display_url" : "instagram.com\/p\/nnayj-hwhk\/"
    } ]
  },
  "geo" : { },
  "id_str" : "463301050561490944",
  "text" : "\u00ABRohr-Ohr Zucker?!\u00BB http:\/\/t.co\/7wqukeZWWA",
  "id" : 463301050561490944,
  "created_at" : "2014-05-05 12:55:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/wp9KJTpDuL",
      "expanded_url" : "http:\/\/www.wired.com\/2014\/05\/diy-brain-stimulation\/",
      "display_url" : "wired.com\/2014\/05\/diy-br\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17233176, 8.627618476 ]
  },
  "id_str" : "463295495654604801",
  "text" : "\u00ABDIY Brain Stimulation\u00BB? I guess before \u201Cneuro-\u201D made the hip-prefixes-list it was called \u201Cthinking\u201D. http:\/\/t.co\/wp9KJTpDuL",
  "id" : 463295495654604801,
  "created_at" : "2014-05-05 12:33:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jacquelyn Gill",
      "screen_name" : "JacquelynGill",
      "indices" : [ 3, 17 ],
      "id_str" : "112475924",
      "id" : 112475924
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "463293801675890689",
  "text" : "RT @JacquelynGill: After getting accepted to her top grad program, a student noticed an increase in sexist micro-aggressions: http:\/\/t.co\/6\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 107, 129 ],
        "url" : "http:\/\/t.co\/6zScNXXFot",
        "expanded_url" : "http:\/\/wp.me\/p4llFS-79",
        "display_url" : "wp.me\/p4llFS-79"
      } ]
    },
    "geo" : { },
    "id_str" : "463278574548840448",
    "text" : "After getting accepted to her top grad program, a student noticed an increase in sexist micro-aggressions: http:\/\/t.co\/6zScNXXFot",
    "id" : 463278574548840448,
    "created_at" : "2014-05-05 11:26:34 +0000",
    "user" : {
      "name" : "Jacquelyn Gill",
      "screen_name" : "JacquelynGill",
      "protected" : false,
      "id_str" : "112475924",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/816027573343965184\/qUfIq3xY_normal.jpg",
      "id" : 112475924,
      "verified" : true
    }
  },
  "id" : 463293801675890689,
  "created_at" : "2014-05-05 12:27:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17233176, 8.627618476 ]
  },
  "id_str" : "463277382657671169",
  "text" : "\u00ABMilcheis ist mein Speed!\u00BB",
  "id" : 463277382657671169,
  "created_at" : "2014-05-05 11:21:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 71 ],
      "url" : "http:\/\/t.co\/K8W6Q3JoPP",
      "expanded_url" : "http:\/\/www.theguardian.com\/artanddesign\/2014\/may\/03\/diary-heroin-addict-photography-graham-macindoe?CMP=fb_gu",
      "display_url" : "theguardian.com\/artanddesign\/2\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17233176, 8.627618476 ]
  },
  "id_str" : "463247321346871296",
  "text" : "Coming clean: the photo diary of a heroin addict http:\/\/t.co\/K8W6Q3JoPP",
  "id" : 463247321346871296,
  "created_at" : "2014-05-05 09:22:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17233176, 8.627618476 ]
  },
  "id_str" : "463240266695335936",
  "text" : "\u00ABIch werd jetzt alle MySQL-Instanzen durch MariaDB ersetzen.\u00BB \u2013 \u00ABWerden wir jetzt alle gl\u00E4ubig? Array &amp; Pray!\u00BB",
  "id" : 463240266695335936,
  "created_at" : "2014-05-05 08:54:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/dvUpklUthK",
      "expanded_url" : "http:\/\/deepseanews.com\/2014\/05\/godzilla\/?utm_source=dlvr.it&utm_medium=twitter",
      "display_url" : "deepseanews.com\/2014\/05\/godzil\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096690125, 8.2830336162 ]
  },
  "id_str" : "463089792310603776",
  "text" : "The Ever Increasing Size of Godzilla: Implications for Sexual Selection and Urine Production http:\/\/t.co\/dvUpklUthK",
  "id" : 463089792310603776,
  "created_at" : "2014-05-04 22:56:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Silberman",
      "screen_name" : "stevesilberman",
      "indices" : [ 3, 18 ],
      "id_str" : "18655567",
      "id" : 18655567
    }, {
      "name" : "Seth Mnookin",
      "screen_name" : "sethmnookin",
      "indices" : [ 116, 128 ],
      "id_str" : "22931893",
      "id" : 22931893
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "463087622832005120",
  "text" : "RT @stevesilberman: The shocking true cause of the autism epidemic revealed. Correlation is causation, people. [via @sethmnookin] http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Seth Mnookin",
        "screen_name" : "sethmnookin",
        "indices" : [ 96, 108 ],
        "id_str" : "22931893",
        "id" : 22931893
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 110, 132 ],
        "url" : "http:\/\/t.co\/aqoJNkAuet",
        "expanded_url" : "http:\/\/goo.gl\/L9vRpD",
        "display_url" : "goo.gl\/L9vRpD"
      } ]
    },
    "geo" : { },
    "id_str" : "463082887622197249",
    "text" : "The shocking true cause of the autism epidemic revealed. Correlation is causation, people. [via @sethmnookin] http:\/\/t.co\/aqoJNkAuet",
    "id" : 463082887622197249,
    "created_at" : "2014-05-04 22:28:58 +0000",
    "user" : {
      "name" : "Steve Silberman",
      "screen_name" : "stevesilberman",
      "protected" : false,
      "id_str" : "18655567",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/801317729978449920\/1ZDKwlMv_normal.jpg",
      "id" : 18655567,
      "verified" : true
    }
  },
  "id" : 463087622832005120,
  "created_at" : "2014-05-04 22:47:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 7, 29 ],
      "url" : "http:\/\/t.co\/FVeaZiX0X4",
      "expanded_url" : "http:\/\/media.giphy.com\/media\/9VJyKZHmHfMPK\/giphy.gif",
      "display_url" : "media.giphy.com\/media\/9VJyKZHm\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "463060096122368000",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096690125, 8.2830336162 ]
  },
  "id_str" : "463061690872250369",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot http:\/\/t.co\/FVeaZiX0X4",
  "id" : 463061690872250369,
  "in_reply_to_status_id" : 463060096122368000,
  "created_at" : "2014-05-04 21:04:45 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emanuel Wyler",
      "screen_name" : "ewyler",
      "indices" : [ 0, 7 ],
      "id_str" : "122329006",
      "id" : 122329006
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 8, 21 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 22, 31 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/zHzBRrJWO6",
      "expanded_url" : "http:\/\/www.slideshare.net\/gedankenstuecke\/opensnp-qs-cologne-meetup",
      "display_url" : "slideshare.net\/gedankenstueck\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "463059054123057152",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096328867, 8.2829846733 ]
  },
  "id_str" : "463061490535526400",
  "in_reply_to_user_id" : 122329006,
  "text" : "@ewyler @PhilippBayer @Senficon also slides 14\/15 hier ;) http:\/\/t.co\/zHzBRrJWO6",
  "id" : 463061490535526400,
  "in_reply_to_status_id" : 463059054123057152,
  "created_at" : "2014-05-04 21:03:57 +0000",
  "in_reply_to_screen_name" : "ewyler",
  "in_reply_to_user_id_str" : "122329006",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emanuel Wyler",
      "screen_name" : "ewyler",
      "indices" : [ 0, 7 ],
      "id_str" : "122329006",
      "id" : 122329006
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 8, 21 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 22, 31 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "463059054123057152",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096328867, 8.2829846733 ]
  },
  "id_str" : "463060960811712515",
  "in_reply_to_user_id" : 122329006,
  "text" : "@ewyler @PhilippBayer @Senficon Frust dar\u00FCber wie schlecht personal genetics|genomics datens\u00E4tze auffindbar &amp; nutzbar waren.",
  "id" : 463060960811712515,
  "in_reply_to_status_id" : 463059054123057152,
  "created_at" : "2014-05-04 21:01:50 +0000",
  "in_reply_to_screen_name" : "ewyler",
  "in_reply_to_user_id_str" : "122329006",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "463059095516614656",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096328867, 8.2829846733 ]
  },
  "id_str" : "463059741141655552",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot I know, e.g. \u00ABwhat has happened to \"took him in her arms\u201D\u00BB, right?",
  "id" : 463059741141655552,
  "in_reply_to_status_id" : 463059095516614656,
  "created_at" : "2014-05-04 20:57:00 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/9MknVKUs1A",
      "expanded_url" : "http:\/\/www.theguardian.com\/books\/booksblog\/2014\/may\/01\/scanner-ebook-arms-anus-optical-character-recognition",
      "display_url" : "theguardian.com\/books\/booksblo\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096328867, 8.2829846733 ]
  },
  "id_str" : "463057834826297344",
  "text" : "\u00ABLittle Milly wound her anus lovingly round Mrs. Green's neck\u00BB Why you shouldn\u2019t trust OCR: http:\/\/t.co\/9MknVKUs1A",
  "id" : 463057834826297344,
  "created_at" : "2014-05-04 20:49:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christina Sommers",
      "screen_name" : "CHSommers",
      "indices" : [ 3, 13 ],
      "id_str" : "334921581",
      "id" : 334921581
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/kLyqfqMs9R",
      "expanded_url" : "http:\/\/www.freerangekids.com\/a-kid-gets-lost-on-a-field-trip-then-and-now\/",
      "display_url" : "freerangekids.com\/a-kid-gets-los\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463054912767934464",
  "text" : "RT @CHSommers: A teacher loses kid on a field trip: 20 years ago vs. today. http:\/\/t.co\/kLyqfqMs9R",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 61, 83 ],
        "url" : "http:\/\/t.co\/kLyqfqMs9R",
        "expanded_url" : "http:\/\/www.freerangekids.com\/a-kid-gets-lost-on-a-field-trip-then-and-now\/",
        "display_url" : "freerangekids.com\/a-kid-gets-los\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "462771713768685568",
    "text" : "A teacher loses kid on a field trip: 20 years ago vs. today. http:\/\/t.co\/kLyqfqMs9R",
    "id" : 462771713768685568,
    "created_at" : "2014-05-04 01:52:29 +0000",
    "user" : {
      "name" : "Christina Sommers",
      "screen_name" : "CHSommers",
      "protected" : false,
      "id_str" : "334921581",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/862683711254532098\/RIAR1_Es_normal.jpg",
      "id" : 334921581,
      "verified" : true
    }
  },
  "id" : 463054912767934464,
  "created_at" : "2014-05-04 20:37:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "463050138760794112",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096328867, 8.2829846733 ]
  },
  "id_str" : "463050948081111040",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot ein dreispitz wie nachbars lumpi?",
  "id" : 463050948081111040,
  "in_reply_to_status_id" : 463050138760794112,
  "created_at" : "2014-05-04 20:22:03 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "463036702366646272",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096328867, 8.2829846733 ]
  },
  "id_str" : "463037002561372161",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot lokale Clusterbildung. Liegt es doch am Trinkwasser?",
  "id" : 463037002561372161,
  "in_reply_to_status_id" : 463036702366646272,
  "created_at" : "2014-05-04 19:26:38 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fistingforcompliments",
      "indices" : [ 41, 63 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "463003611489128448",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096509016, 8.2830271225 ]
  },
  "id_str" : "463003893912567809",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot war das set up zu offensichtlich? #fistingforcompliments",
  "id" : 463003893912567809,
  "in_reply_to_status_id" : 463003611489128448,
  "created_at" : "2014-05-04 17:15:05 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/kindle.amazon.com\" rel=\"nofollow\"\u003EKindle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 33 ],
      "url" : "http:\/\/t.co\/KuDykQMtOp",
      "expanded_url" : "http:\/\/amzn.com\/k\/1s1iIB_LRumwYW-BxoB_xw",
      "display_url" : "amzn.com\/k\/1s1iIB_LRumw\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "462997746715480064",
  "text" : "Dedication http:\/\/t.co\/KuDykQMtOp I think if you dedicate yourself to anything, um, one facet of that is that it makes you very very ...",
  "id" : 462997746715480064,
  "created_at" : "2014-05-04 16:50:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Frau Fragmente",
      "screen_name" : "fragmente",
      "indices" : [ 0, 10 ],
      "id_str" : "7207642",
      "id" : 7207642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "462975962335166465",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0085457424, 8.2705062152 ]
  },
  "id_str" : "462983542646247424",
  "in_reply_to_user_id" : 7207642,
  "text" : "@fragmente das Buch ist auf jeden Fall sehr unterhaltsam.",
  "id" : 462983542646247424,
  "in_reply_to_status_id" : 462975962335166465,
  "created_at" : "2014-05-04 15:54:13 +0000",
  "in_reply_to_screen_name" : "fragmente",
  "in_reply_to_user_id_str" : "7207642",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0086370473, 8.2703925261 ]
  },
  "id_str" : "462972388133838848",
  "text" : "Englisches Keyboard verbessert \u2018beruflich\u2019 zu \u2018very lick\u2019. wow, much face\u2026",
  "id" : 462972388133838848,
  "created_at" : "2014-05-04 15:09:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Frau Fragmente",
      "screen_name" : "fragmente",
      "indices" : [ 0, 10 ],
      "id_str" : "7207642",
      "id" : 7207642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/lAInNA1ZQc",
      "expanded_url" : "http:\/\/www.brainpickings.org\/index.php\/2012\/03\/02\/david-foster-wallace-art-vs-tv\/",
      "display_url" : "brainpickings.org\/index.php\/2012\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "462969724285255680",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0078404276, 8.2795741316 ]
  },
  "id_str" : "462970779819593728",
  "in_reply_to_user_id" : 7207642,
  "text" : "@fragmente DFW in \u00ABAlthough Of Course You End Up Becoming Yourself: A Road Trip with David Foster Wallace.\u00BB http:\/\/t.co\/lAInNA1ZQc",
  "id" : 462970779819593728,
  "in_reply_to_status_id" : 462969724285255680,
  "created_at" : "2014-05-04 15:03:30 +0000",
  "in_reply_to_screen_name" : "fragmente",
  "in_reply_to_user_id_str" : "7207642",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.010410239, 8.2681293141 ]
  },
  "id_str" : "462957116580716545",
  "text" : "\u00ABthe difference between me &amp; a 21y\/o prostitute who is dying of AIDS, who\u2019d been doing heroin since she was 11, is a matter of accidents.\u00BB",
  "id" : 462957116580716545,
  "created_at" : "2014-05-04 14:09:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "iloveyoubut",
      "indices" : [ 82, 94 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "462946023724560384",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0103475465, 8.2682661806 ]
  },
  "id_str" : "462954212264251392",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot um die Gefahr zu bannen habe ich daraus einfach das 2. Fr\u00FChst\u00FCck gemacht.  #iloveyoubut",
  "id" : 462954212264251392,
  "in_reply_to_status_id" : 462946023724560384,
  "created_at" : "2014-05-04 13:57:40 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "afteraftersexselfie",
      "indices" : [ 114, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009530305, 8.282878705 ]
  },
  "id_str" : "462928287405457408",
  "text" : "\u00ABNach meiner letzten Recherche glaube ich auch das Prolapsing ein realistisches Outcome ist.\u00BB \u2013 \u00ABAlso gibt es ein #afteraftersexselfie?\u00BB",
  "id" : 462928287405457408,
  "created_at" : "2014-05-04 12:14:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Seemann",
      "screen_name" : "mspro",
      "indices" : [ 0, 6 ],
      "id_str" : "5751892",
      "id" : 5751892
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "462925443193389056",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009530305, 8.282878705 ]
  },
  "id_str" : "462927930507952128",
  "in_reply_to_user_id" : 5751892,
  "text" : "@mspro ich w\u00FCrde sagen das kommt ziemlich auf den \u00DCbertragungsweg an.",
  "id" : 462927930507952128,
  "in_reply_to_status_id" : 462925443193389056,
  "created_at" : "2014-05-04 12:13:14 +0000",
  "in_reply_to_screen_name" : "mspro",
  "in_reply_to_user_id_str" : "5751892",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Seemann",
      "screen_name" : "mspro",
      "indices" : [ 0, 6 ],
      "id_str" : "5751892",
      "id" : 5751892
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 35 ],
      "url" : "http:\/\/t.co\/kKy9wiB2Uq",
      "expanded_url" : "http:\/\/j.mp\/RfJWK9",
      "display_url" : "j.mp\/RfJWK9"
    } ]
  },
  "in_reply_to_status_id_str" : "462917130569383936",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009661524, 8.2830094083 ]
  },
  "id_str" : "462923684274262016",
  "in_reply_to_user_id" : 5751892,
  "text" : "@mspro siehe http:\/\/t.co\/kKy9wiB2Uq",
  "id" : 462923684274262016,
  "in_reply_to_status_id" : 462917130569383936,
  "created_at" : "2014-05-04 11:56:21 +0000",
  "in_reply_to_screen_name" : "mspro",
  "in_reply_to_user_id_str" : "5751892",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097027129, 8.2832740121 ]
  },
  "id_str" : "462913491595452416",
  "text" : "\u00ABWas wird das? Midsexselfie statt Aftersexselfie?\u00BB",
  "id" : 462913491595452416,
  "created_at" : "2014-05-04 11:15:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/qNMl3inAms",
      "expanded_url" : "http:\/\/youtu.be\/K8SF3D8CiJA",
      "display_url" : "youtu.be\/K8SF3D8CiJA"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095980708, 8.2829760946 ]
  },
  "id_str" : "462870496053583872",
  "text" : "Internet, LOL, Internet\u2026 http:\/\/t.co\/qNMl3inAms",
  "id" : 462870496053583872,
  "created_at" : "2014-05-04 08:25:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097116284, 8.2833571199 ]
  },
  "id_str" : "462869779251208193",
  "text" : "I love you but I\u2019ve chosen breakfast.",
  "id" : 462869779251208193,
  "created_at" : "2014-05-04 08:22:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/a0smpXsbhs",
      "expanded_url" : "http:\/\/whatshouldwecallgradschool.tumblr.com\/post\/84626078877",
      "display_url" : "whatshouldwecallgradschool.tumblr.com\/post\/846260788\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009598, 8.282905 ]
  },
  "id_str" : "462659085683662848",
  "text" : "Also the reason why there are still floppy disks around http:\/\/t.co\/a0smpXsbhs",
  "id" : 462659085683662848,
  "created_at" : "2014-05-03 18:24:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "laktoseintoleranz",
      "indices" : [ 107, 125 ]
    }, {
      "text" : "hipster",
      "indices" : [ 126, 134 ]
    }, {
      "text" : "yolo",
      "indices" : [ 135, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0069926193, 8.2783542985 ]
  },
  "id_str" : "462658252069941248",
  "text" : "\u00ABMagst du mit mir an den Strand gehen?\u00BB \u2014 \u00ABWenn es dir nicht peinlich ist dass ich mir in die Hose kacke.\u00BB #laktoseintoleranz #hipster #yolo",
  "id" : 462658252069941248,
  "created_at" : "2014-05-03 18:21:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096029086, 8.2829409013 ]
  },
  "id_str" : "462624158485348352",
  "text" : "\u00ABDu arbeitest den ganzen Tag mit Poly-A-Schw\u00E4nzen?! Wieso hast du mir das bislang vorenthalten?!\u00BB",
  "id" : 462624158485348352,
  "created_at" : "2014-05-03 16:06:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 44 ],
      "url" : "http:\/\/t.co\/97eorcGBYM",
      "expanded_url" : "http:\/\/feedproxy.google.com\/~r\/smbc-comics\/PvLb\/~3\/gLFer2hLOLw\/index.php",
      "display_url" : "feedproxy.google.com\/~r\/smbc-comics\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009603, 8.282941 ]
  },
  "id_str" : "462618544342306816",
  "text" : "funny cause it's true http:\/\/t.co\/97eorcGBYM",
  "id" : 462618544342306816,
  "created_at" : "2014-05-03 15:43:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/lAInNA1ZQc",
      "expanded_url" : "http:\/\/www.brainpickings.org\/index.php\/2012\/03\/02\/david-foster-wallace-art-vs-tv\/",
      "display_url" : "brainpickings.org\/index.php\/2012\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095546767, 8.2829271517 ]
  },
  "id_str" : "462585065470693376",
  "text" : "\u00ABI think one of the insidious lessons about TV is the meta-lesson that you\u2019re dumb.\u00BB http:\/\/t.co\/lAInNA1ZQc",
  "id" : 462585065470693376,
  "created_at" : "2014-05-03 13:30:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hipster",
      "indices" : [ 83, 91 ]
    }, {
      "text" : "yolo",
      "indices" : [ 92, 97 ]
    }, {
      "text" : "blogger",
      "indices" : [ 102, 110 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095872243, 8.2828839283 ]
  },
  "id_str" : "462532423495208960",
  "text" : "\u00ABIch hab dir jetzt \u00FCbrigens einen Poncho bestellt. Die Tags auf der Webseite waren #hipster #yolo und #blogger.\u00BB",
  "id" : 462532423495208960,
  "created_at" : "2014-05-03 10:01:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 46 ],
      "url" : "http:\/\/t.co\/yeoXZn2T73",
      "expanded_url" : "http:\/\/feedproxy.google.com\/~r\/smbc-comics\/PvLb\/~3\/vMDC1uije2g\/index.php",
      "display_url" : "feedproxy.google.com\/~r\/smbc-comics\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009587, 8.282884 ]
  },
  "id_str" : "462531790595690496",
  "text" : "The Labor Theory of Sex http:\/\/t.co\/yeoXZn2T73",
  "id" : 462531790595690496,
  "created_at" : "2014-05-03 09:59:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 43 ],
      "url" : "http:\/\/t.co\/nBpyU2DC6A",
      "expanded_url" : "http:\/\/chapmangamo.tumblr.com\/post\/84544940124",
      "display_url" : "chapmangamo.tumblr.com\/post\/845449401\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009585, 8.282892 ]
  },
  "id_str" : "462531512580464640",
  "text" : "The Sounds of Sirens http:\/\/t.co\/nBpyU2DC6A",
  "id" : 462531512580464640,
  "created_at" : "2014-05-03 09:58:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 59 ],
      "url" : "http:\/\/t.co\/XlFAQW1koG",
      "expanded_url" : "http:\/\/feedproxy.google.com\/~r\/NerdcoreRSS2\/~3\/ck5-CT0iuE8\/",
      "display_url" : "feedproxy.google.com\/~r\/NerdcoreRSS\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00957, 8.282946 ]
  },
  "id_str" : "462531150129664000",
  "text" : "Absurdist Pro-Gay-Protests in Russia http:\/\/t.co\/XlFAQW1koG",
  "id" : 462531150129664000,
  "created_at" : "2014-05-03 09:56:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/sV0WIPHKVw",
      "expanded_url" : "http:\/\/www.urbandictionary.com\/define.php?term=grundle",
      "display_url" : "urbandictionary.com\/define.php?ter\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.010736, 8.283205 ]
  },
  "id_str" : "462314949940092928",
  "text" : "grundle: \u00ABThe prime piece of real estate located conveniently between Scrotumburg and Anusville.\u00BB http:\/\/t.co\/sV0WIPHKVw",
  "id" : 462314949940092928,
  "created_at" : "2014-05-02 19:37:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096548478, 8.2829198875 ]
  },
  "id_str" : "462300221570289664",
  "text" : "\u00ABGlaubst du wirklich das du ein Hipster bist?\u00BB \u2014 \u00ABNein, denn ich sah schon so aus bevor es cool war.\u00BB",
  "id" : 462300221570289664,
  "created_at" : "2014-05-02 18:38:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kate Clancy",
      "screen_name" : "KateClancy",
      "indices" : [ 3, 14 ],
      "id_str" : "14729597",
      "id" : 14729597
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/1codqf3b2i",
      "expanded_url" : "http:\/\/bit.ly\/1fVZ7OQ",
      "display_url" : "bit.ly\/1fVZ7OQ"
    } ]
  },
  "geo" : { },
  "id_str" : "462257291438596096",
  "text" : "RT @KateClancy: I know James personally, and knew of his history when we hired him. This story infuriates me. http:\/\/t.co\/1codqf3b2i",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 94, 116 ],
        "url" : "http:\/\/t.co\/1codqf3b2i",
        "expanded_url" : "http:\/\/bit.ly\/1fVZ7OQ",
        "display_url" : "bit.ly\/1fVZ7OQ"
      } ]
    },
    "geo" : { },
    "id_str" : "462254601224593408",
    "text" : "I know James personally, and knew of his history when we hired him. This story infuriates me. http:\/\/t.co\/1codqf3b2i",
    "id" : 462254601224593408,
    "created_at" : "2014-05-02 15:37:39 +0000",
    "user" : {
      "name" : "Kate Clancy",
      "screen_name" : "KateClancy",
      "protected" : false,
      "id_str" : "14729597",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/827538287191527424\/BClQOCKV_normal.jpg",
      "id" : 14729597,
      "verified" : false
    }
  },
  "id" : 462257291438596096,
  "created_at" : "2014-05-02 15:48:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 6, 15 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/hM3f5pcHsg",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=ye2N_2ce3QE",
      "display_url" : "youtube.com\/watch?v=ye2N_2\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723315225, 8.627616225 ]
  },
  "id_str" : "462233532379983872",
  "text" : "Wegen @JP_Stich jetzt einen Lead Belly Nachmittag einlegen. http:\/\/t.co\/hM3f5pcHsg",
  "id" : 462233532379983872,
  "created_at" : "2014-05-02 14:13:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723315225, 8.627616225 ]
  },
  "id_str" : "462227728541188096",
  "text" : "\u00ABRevisiting \u201CIs the scientific paper a fraud?\u201D\u00BB Well, especially the ones behind paywalls\u2026",
  "id" : 462227728541188096,
  "created_at" : "2014-05-02 13:50:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "462225369094176768",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723315225, 8.627616225 ]
  },
  "id_str" : "462227430003187712",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich aye, ich weiss was du meinst. Ist halt mehr Manowar als Nanowar. :p",
  "id" : 462227430003187712,
  "in_reply_to_status_id" : 462225369094176768,
  "created_at" : "2014-05-02 13:49:41 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/L2f3vnBEZB",
      "expanded_url" : "http:\/\/www.theguardian.com\/science\/brain-flapping\/2014\/may\/02\/five-alternative-things-successful-phd-students-would-never-do?CMP=twt_gu",
      "display_url" : "theguardian.com\/science\/brain-\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723315225, 8.627616225 ]
  },
  "id_str" : "462224797913849856",
  "text" : "\u00ABSome people like to see their family, friends, partners, etc. Some people don\u2019t have PhDs.\u00BB http:\/\/t.co\/L2f3vnBEZB",
  "id" : 462224797913849856,
  "created_at" : "2014-05-02 13:39:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/wpgS4WbXN2",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=zTIlcSMoh8k",
      "display_url" : "youtube.com\/watch?v=zTIlcS\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "462221929303515136",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723315225, 8.627616225 ]
  },
  "id_str" : "462223055251845120",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich bis S\u00FCnder ohne Z\u00FCgel war ich auch noch in deinem Team, allein schon f\u00FCr eines der coolsten Blues-Cover: http:\/\/t.co\/wpgS4WbXN2 ;)",
  "id" : 462223055251845120,
  "in_reply_to_status_id" : 462221929303515136,
  "created_at" : "2014-05-02 13:32:18 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "462217267603058688",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723315225, 8.627616225 ]
  },
  "id_str" : "462217607660462080",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich Damit hatte ich fest gerechnet. Verzeiht das meinen Standpunkt zu Mittelalter-Rock? :p",
  "id" : 462217607660462080,
  "in_reply_to_status_id" : 462217267603058688,
  "created_at" : "2014-05-02 13:10:39 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/EFTSWWybeW",
      "expanded_url" : "http:\/\/www.scilogs.de\/bierologie\/von-bizarren-wespen-wie-aussagekr-ftig-sind-ergebnisse-der-verhaltensforschung\/",
      "display_url" : "scilogs.de\/bierologie\/von\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "462216147245740032",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723315225, 8.627616225 ]
  },
  "id_str" : "462216576943816704",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich ah, ich wusste ich hab dar\u00FCber auch mal gebloggt: http:\/\/t.co\/EFTSWWybeW",
  "id" : 462216576943816704,
  "in_reply_to_status_id" : 462216147245740032,
  "created_at" : "2014-05-02 13:06:34 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 55 ],
      "url" : "http:\/\/t.co\/ZPHtvO8aDb",
      "expanded_url" : "http:\/\/www.psmag.com\/magazines\/magazine-feature-story-magazines\/joe-henrich-weird-ultimatum-game-shaking-up-psychology-economics-53135\/",
      "display_url" : "psmag.com\/magazines\/maga\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723315225, 8.627616225 ]
  },
  "id_str" : "462214427815989248",
  "text" : "A nice article about us WEIRDos. http:\/\/t.co\/ZPHtvO8aDb",
  "id" : 462214427815989248,
  "created_at" : "2014-05-02 12:58:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/OdyYfh7Kfu",
      "expanded_url" : "http:\/\/www.bbc.com\/news\/magazine-27186709",
      "display_url" : "bbc.com\/news\/magazine-\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723315225, 8.627616225 ]
  },
  "id_str" : "462211851229868032",
  "text" : "\u00ABA lot of places, if you walk you feel you are doing something self-consciously. Walking becomes a radical act\u00BB http:\/\/t.co\/OdyYfh7Kfu",
  "id" : 462211851229868032,
  "created_at" : "2014-05-02 12:47:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonas",
      "screen_name" : "lsanoj",
      "indices" : [ 0, 7 ],
      "id_str" : "18918915",
      "id" : 18918915
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 8, 14 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 57 ],
      "url" : "http:\/\/t.co\/YjZEAJnfI3",
      "expanded_url" : "http:\/\/i.imgur.com\/Xx9Lbz4.jpg",
      "display_url" : "i.imgur.com\/Xx9Lbz4.jpg"
    } ]
  },
  "in_reply_to_status_id_str" : "462200819241463808",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723315225, 8.627616225 ]
  },
  "id_str" : "462201149303844865",
  "in_reply_to_user_id" : 18918915,
  "text" : "@lsanoj @Lobot repeat ad infinitum http:\/\/t.co\/YjZEAJnfI3",
  "id" : 462201149303844865,
  "in_reply_to_status_id" : 462200819241463808,
  "created_at" : "2014-05-02 12:05:15 +0000",
  "in_reply_to_screen_name" : "lsanoj",
  "in_reply_to_user_id_str" : "18918915",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 0, 10 ],
      "id_str" : "14700783",
      "id" : 14700783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "462199708262600704",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723315225, 8.627616225 ]
  },
  "id_str" : "462200182529331200",
  "in_reply_to_user_id" : 14700783,
  "text" : "@Fischblog Nimm die Ameisenigel mit rein und schon wird er distrematisch!",
  "id" : 462200182529331200,
  "in_reply_to_status_id" : 462199708262600704,
  "created_at" : "2014-05-02 12:01:25 +0000",
  "in_reply_to_screen_name" : "Fischblog",
  "in_reply_to_user_id_str" : "14700783",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 7, 29 ],
      "url" : "http:\/\/t.co\/rAT1ZEUS8k",
      "expanded_url" : "http:\/\/www.tanwater.com\/animation\/bad_squirrel_animation.gif",
      "display_url" : "tanwater.com\/animation\/bad_\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "462195916020387841",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723315225, 8.627616225 ]
  },
  "id_str" : "462196270187425792",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot http:\/\/t.co\/rAT1ZEUS8k pew pew pew!",
  "id" : 462196270187425792,
  "in_reply_to_status_id" : 462195916020387841,
  "created_at" : "2014-05-02 11:45:52 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 59 ],
      "url" : "http:\/\/t.co\/v7vF9IjZrh",
      "expanded_url" : "http:\/\/i.imgur.com\/7aIjitF.gif",
      "display_url" : "i.imgur.com\/7aIjitF.gif"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723315225, 8.627616225 ]
  },
  "id_str" : "462194997438455808",
  "text" : "terrorists are going nuts these days http:\/\/t.co\/v7vF9IjZrh",
  "id" : 462194997438455808,
  "created_at" : "2014-05-02 11:40:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/gAPd0Hg5DK",
      "expanded_url" : "http:\/\/arstechnica.com\/science\/2014\/05\/win-at-rock-paper-scissors-by-knowing-thy-opponent\/",
      "display_url" : "arstechnica.com\/science\/2014\/0\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723315225, 8.627616225 ]
  },
  "id_str" : "462184246057398272",
  "text" : "Trying to reproduce it for our post-lunch 5-player games: Scientists find a winning strategy for rock-paper-scissors http:\/\/t.co\/gAPd0Hg5DK",
  "id" : 462184246057398272,
  "created_at" : "2014-05-02 10:58:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723315225, 8.627616225 ]
  },
  "id_str" : "462174600500346880",
  "text" : "\u00ABWill you go to that career day?\u00BB \u2013 \u00ABNah, I\u2019m already sure I don\u2019t want one.\u00BB",
  "id" : 462174600500346880,
  "created_at" : "2014-05-02 10:19:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "naturalismus",
      "screen_name" : "naturalismus",
      "indices" : [ 0, 13 ],
      "id_str" : "4562569648",
      "id" : 4562569648
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "462172908383928320",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1727768104, 8.6275071614 ]
  },
  "id_str" : "462173336756572160",
  "in_reply_to_user_id" : 77216385,
  "text" : "@Naturalismus same here (plus some of the tools as well). Basically everything I didn\u2019t know I failed.",
  "id" : 462173336756572160,
  "in_reply_to_status_id" : 462172908383928320,
  "created_at" : "2014-05-02 10:14:44 +0000",
  "in_reply_to_screen_name" : "fireantprincess",
  "in_reply_to_user_id_str" : "77216385",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bigdata",
      "indices" : [ 57, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/Gn6ZUfkrHs",
      "expanded_url" : "https:\/\/docs.google.com\/forms\/d\/1kckcq_uv8dk9-W5rIdtqRwCHN4Uh209ELPUjTEZJDxc\/viewform",
      "display_url" : "docs.google.com\/forms\/d\/1kckcq\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723315225, 8.627616225 ]
  },
  "id_str" : "462171512695689216",
  "text" : "I did worse than chance would predict\u2026 \u00ABIs it Pok\u00E9mon or #bigdata technology?\u00BB https:\/\/t.co\/Gn6ZUfkrHs",
  "id" : 462171512695689216,
  "created_at" : "2014-05-02 10:07:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/5znPZVM7gH",
      "expanded_url" : "http:\/\/www.pnas.org\/content\/111\/17\/6119.full",
      "display_url" : "pnas.org\/content\/111\/17\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723315225, 8.627616225 ]
  },
  "id_str" : "462160678099615744",
  "text" : "Advocating for having a drink &amp; going for a walk: The forgotten half of scientific thinking http:\/\/t.co\/5znPZVM7gH",
  "id" : 462160678099615744,
  "created_at" : "2014-05-02 09:24:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "the Node",
      "screen_name" : "the_Node",
      "indices" : [ 3, 12 ],
      "id_str" : "118690641",
      "id" : 118690641
    }, {
      "name" : "John Runions",
      "screen_name" : "JohnRunions",
      "indices" : [ 58, 70 ],
      "id_str" : "538342587",
      "id" : 538342587
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/JohnRunions\/status\/461851989119213568\/photo\/1",
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/ONtK9BiSjx",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BmjT7-aCIAIMv8J.jpg",
      "id_str" : "461851989123407874",
      "id" : 461851989123407874,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BmjT7-aCIAIMv8J.jpg",
      "sizes" : [ {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/ONtK9BiSjx"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "462149641841422337",
  "text" : "RT @the_Node: Evolutionary tree of cakes and biscuits? RT @JohnRunions http:\/\/t.co\/ONtK9BiSjx",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "John Runions",
        "screen_name" : "JohnRunions",
        "indices" : [ 44, 56 ],
        "id_str" : "538342587",
        "id" : 538342587
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/JohnRunions\/status\/461851989119213568\/photo\/1",
        "indices" : [ 57, 79 ],
        "url" : "http:\/\/t.co\/ONtK9BiSjx",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BmjT7-aCIAIMv8J.jpg",
        "id_str" : "461851989123407874",
        "id" : 461851989123407874,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BmjT7-aCIAIMv8J.jpg",
        "sizes" : [ {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/ONtK9BiSjx"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "461853565615878144",
    "text" : "Evolutionary tree of cakes and biscuits? RT @JohnRunions http:\/\/t.co\/ONtK9BiSjx",
    "id" : 461853565615878144,
    "created_at" : "2014-05-01 13:04:05 +0000",
    "user" : {
      "name" : "the Node",
      "screen_name" : "the_Node",
      "protected" : false,
      "id_str" : "118690641",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/683971293360865281\/q444_r7x_normal.jpg",
      "id" : 118690641,
      "verified" : false
    }
  },
  "id" : 462149641841422337,
  "created_at" : "2014-05-02 08:40:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723315225, 8.627616225 ]
  },
  "id_str" : "462145751590912000",
  "text" : "\u00ABThere\u2019s only one mature way to deal with not having coffee.\u00BB \u2013 \u00ABCrying fits?\u00BB",
  "id" : 462145751590912000,
  "created_at" : "2014-05-02 08:25:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RyanJ \uD83D\uDC80\uD83E\uDD83",
      "screen_name" : "ryanj",
      "indices" : [ 3, 9 ],
      "id_str" : "14945367",
      "id" : 14945367
    }, {
      "name" : "Bridget Kromhout",
      "screen_name" : "bridgetkromhout",
      "indices" : [ 40, 56 ],
      "id_str" : "1465659204",
      "id" : 1465659204
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/bridgetkromhout\/status\/462009165347450881\/photo\/1",
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/CMhhhKsyQ5",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bmli4unCQAAsOfR.jpg",
      "id_str" : "462009163506139136",
      "id" : 462009163506139136,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bmli4unCQAAsOfR.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/CMhhhKsyQ5"
    } ],
    "hashtags" : [ {
      "text" : "DevOps",
      "indices" : [ 11, 18 ]
    } ],
    "urls" : [ {
      "indices" : [ 57, 80 ],
      "url" : "https:\/\/t.co\/tVtKER3vXH",
      "expanded_url" : "https:\/\/github.com\/bridgetkromhout\/devops-against-humanity",
      "display_url" : "github.com\/bridgetkromhou\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "462145245896253440",
  "text" : "RT @ryanj: #DevOps Against Humanity via @BridgetKromhout\nhttps:\/\/t.co\/tVtKER3vXH\nhttp:\/\/t.co\/CMhhhKsyQ5",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bridget Kromhout",
        "screen_name" : "bridgetkromhout",
        "indices" : [ 29, 45 ],
        "id_str" : "1465659204",
        "id" : 1465659204
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/bridgetkromhout\/status\/462009165347450881\/photo\/1",
        "indices" : [ 70, 92 ],
        "url" : "http:\/\/t.co\/CMhhhKsyQ5",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bmli4unCQAAsOfR.jpg",
        "id_str" : "462009163506139136",
        "id" : 462009163506139136,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bmli4unCQAAsOfR.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/CMhhhKsyQ5"
      } ],
      "hashtags" : [ {
        "text" : "DevOps",
        "indices" : [ 0, 7 ]
      } ],
      "urls" : [ {
        "indices" : [ 46, 69 ],
        "url" : "https:\/\/t.co\/tVtKER3vXH",
        "expanded_url" : "https:\/\/github.com\/bridgetkromhout\/devops-against-humanity",
        "display_url" : "github.com\/bridgetkromhou\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "462047428061847552",
    "text" : "#DevOps Against Humanity via @BridgetKromhout\nhttps:\/\/t.co\/tVtKER3vXH\nhttp:\/\/t.co\/CMhhhKsyQ5",
    "id" : 462047428061847552,
    "created_at" : "2014-05-02 01:54:25 +0000",
    "user" : {
      "name" : "RyanJ \uD83D\uDC80\uD83E\uDD83",
      "screen_name" : "ryanj",
      "protected" : false,
      "id_str" : "14945367",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/886086519408263169\/tyr9uaKu_normal.jpg",
      "id" : 14945367,
      "verified" : false
    }
  },
  "id" : 462145245896253440,
  "created_at" : "2014-05-02 08:23:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/lW5Bdq9rCU",
      "expanded_url" : "http:\/\/www.plosone.org\/article\/info%3Adoi%2F10.1371%2Fjournal.pone.0095839",
      "display_url" : "plosone.org\/article\/info%3\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00964409, 8.2829990771 ]
  },
  "id_str" : "462013355050672128",
  "text" : "Marine Litter Distribution and Density in European Seas, from the Shelves to Deep Basins http:\/\/t.co\/lW5Bdq9rCU",
  "id" : 462013355050672128,
  "created_at" : "2014-05-01 23:39:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 7, 29 ],
      "url" : "http:\/\/t.co\/ebsP1gn6jm",
      "expanded_url" : "http:\/\/whatshouldwecallgradschool.tumblr.com\/post\/84421245317\/taking-notes-during-a-seminar",
      "display_url" : "whatshouldwecallgradschool.tumblr.com\/post\/844212453\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00964409, 8.2829990771 ]
  },
  "id_str" : "462010564437635072",
  "text" : "maybe\u2026 http:\/\/t.co\/ebsP1gn6jm",
  "id" : 462010564437635072,
  "created_at" : "2014-05-01 23:27:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00964409, 8.2829990771 ]
  },
  "id_str" : "462003449903992832",
  "text" : "Sorry to those who had problems with registering\/signing into openSNP today. Just restarted the crashed processes &amp; now it works again.",
  "id" : 462003449903992832,
  "created_at" : "2014-05-01 22:59:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "renamed @sckottie",
      "screen_name" : "recology_",
      "indices" : [ 116, 126 ],
      "id_str" : "4465848374",
      "id" : 4465848374
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/Rhe87MGLNU",
      "expanded_url" : "http:\/\/rforcats.net\/",
      "display_url" : "rforcats.net"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00964409, 8.2829990771 ]
  },
  "id_str" : "462001267535925248",
  "text" : "\u00ABSince you are putting code in this box you probably don't want to sit in it\u00BB R for cats http:\/\/t.co\/Rhe87MGLNU \/HT @recology_",
  "id" : 462001267535925248,
  "created_at" : "2014-05-01 22:51:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephan Kornberger",
      "screen_name" : "Zoor",
      "indices" : [ 0, 5 ],
      "id_str" : "21319557",
      "id" : 21319557
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "461856368777908225",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1003149124, 8.2646857267 ]
  },
  "id_str" : "461856992123162624",
  "in_reply_to_user_id" : 21319557,
  "text" : "@Zoor ja :)",
  "id" : 461856992123162624,
  "in_reply_to_status_id" : 461856368777908225,
  "created_at" : "2014-05-01 13:17:42 +0000",
  "in_reply_to_screen_name" : "Zoor",
  "in_reply_to_user_id_str" : "21319557",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1002954229, 8.2648051557 ]
  },
  "id_str" : "461841075641253888",
  "text" : "Das beste am Kurpark in Wiesbaden: Man kann den ganzen Tag lang mit fremden Hunden im Dreck spielen.",
  "id" : 461841075641253888,
  "created_at" : "2014-05-01 12:14:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/3WJLsGXixI",
      "expanded_url" : "http:\/\/makeagif.com\/media\/5-01-2014\/tZBCr_.gif",
      "display_url" : "makeagif.com\/media\/5-01-201\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00964409, 8.2829990771 ]
  },
  "id_str" : "461803347008581632",
  "text" : "Apparently this is what happens to my jobs if I decide not to watch them for a couple of hours. http:\/\/t.co\/3WJLsGXixI",
  "id" : 461803347008581632,
  "created_at" : "2014-05-01 09:44:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mick Watson",
      "screen_name" : "BioMickWatson",
      "indices" : [ 3, 17 ],
      "id_str" : "228586748",
      "id" : 228586748
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/RUp1IlZ0x4",
      "expanded_url" : "http:\/\/wp.me\/p4j0DN-6e",
      "display_url" : "wp.me\/p4j0DN-6e"
    } ]
  },
  "geo" : { },
  "id_str" : "461801255049129984",
  "text" : "RT @BioMickWatson: Why it annoys me if people say academics should work hard http:\/\/t.co\/RUp1IlZ0x4",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 58, 80 ],
        "url" : "http:\/\/t.co\/RUp1IlZ0x4",
        "expanded_url" : "http:\/\/wp.me\/p4j0DN-6e",
        "display_url" : "wp.me\/p4j0DN-6e"
      } ]
    },
    "geo" : { },
    "id_str" : "460753612222627840",
    "text" : "Why it annoys me if people say academics should work hard http:\/\/t.co\/RUp1IlZ0x4",
    "id" : 460753612222627840,
    "created_at" : "2014-04-28 12:13:16 +0000",
    "user" : {
      "name" : "Mick Watson",
      "screen_name" : "BioMickWatson",
      "protected" : false,
      "id_str" : "228586748",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/870214569679093760\/YIZGIDTS_normal.jpg",
      "id" : 228586748,
      "verified" : false
    }
  },
  "id" : 461801255049129984,
  "created_at" : "2014-05-01 09:36:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonas",
      "screen_name" : "lsanoj",
      "indices" : [ 0, 7 ],
      "id_str" : "18918915",
      "id" : 18918915
    }, {
      "name" : "Tim Weber",
      "screen_name" : "scy",
      "indices" : [ 8, 12 ],
      "id_str" : "8308632",
      "id" : 8308632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 35 ],
      "url" : "http:\/\/t.co\/fKmIpd3CZj",
      "expanded_url" : "http:\/\/media0.giphy.com\/media\/MaFf5pxxXn1Xq\/200.gif",
      "display_url" : "media0.giphy.com\/media\/MaFf5pxx\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "461643386861391872",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096540638, 8.282971355 ]
  },
  "id_str" : "461644039398637569",
  "in_reply_to_user_id" : 18918915,
  "text" : "@lsanoj @scy http:\/\/t.co\/fKmIpd3CZj",
  "id" : 461644039398637569,
  "in_reply_to_status_id" : 461643386861391872,
  "created_at" : "2014-04-30 23:11:30 +0000",
  "in_reply_to_screen_name" : "lsanoj",
  "in_reply_to_user_id_str" : "18918915",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Weber",
      "screen_name" : "scy",
      "indices" : [ 0, 4 ],
      "id_str" : "8308632",
      "id" : 8308632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "461641604026347520",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096540638, 8.282971355 ]
  },
  "id_str" : "461642771947061248",
  "in_reply_to_user_id" : 8308632,
  "text" : "@scy ah, i see. lazy-me war mit 3rd party schmu immer ganz zufrieden.",
  "id" : 461642771947061248,
  "in_reply_to_status_id" : 461641604026347520,
  "created_at" : "2014-04-30 23:06:28 +0000",
  "in_reply_to_screen_name" : "scy",
  "in_reply_to_user_id_str" : "8308632",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Weber",
      "screen_name" : "scy",
      "indices" : [ 0, 4 ],
      "id_str" : "8308632",
      "id" : 8308632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "461637324791881728",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096540638, 8.282971355 ]
  },
  "id_str" : "461637995876331520",
  "in_reply_to_user_id" : 8308632,
  "text" : "@scy ja, oder halt mit DeLorean. Aber kenne deinen use case nicht.",
  "id" : 461637995876331520,
  "in_reply_to_status_id" : 461637324791881728,
  "created_at" : "2014-04-30 22:47:29 +0000",
  "in_reply_to_screen_name" : "scy",
  "in_reply_to_user_id_str" : "8308632",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Weber",
      "screen_name" : "scy",
      "indices" : [ 0, 4 ],
      "id_str" : "8308632",
      "id" : 8308632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 5, 27 ],
      "url" : "http:\/\/t.co\/s5aj2YQV6U",
      "expanded_url" : "http:\/\/delorean.readthedocs.org\/en\/latest\/quickstart.html",
      "display_url" : "delorean.readthedocs.org\/en\/latest\/quic\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "461635405281259520",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096540638, 8.282971355 ]
  },
  "id_str" : "461635786023383041",
  "in_reply_to_user_id" : 8308632,
  "text" : "@scy http:\/\/t.co\/s5aj2YQV6U",
  "id" : 461635786023383041,
  "in_reply_to_status_id" : 461635405281259520,
  "created_at" : "2014-04-30 22:38:42 +0000",
  "in_reply_to_screen_name" : "scy",
  "in_reply_to_user_id_str" : "8308632",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 42 ],
      "url" : "http:\/\/t.co\/ONt5Ucw2oM",
      "expanded_url" : "http:\/\/www.roimedia.co.za\/blog\/wp-content\/uploads\/2014\/01\/Double-deadline.gif",
      "display_url" : "roimedia.co.za\/blog\/wp-conten\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096540638, 8.282971355 ]
  },
  "id_str" : "461635683720122368",
  "text" : "double-deadline.gif http:\/\/t.co\/ONt5Ucw2oM",
  "id" : 461635683720122368,
  "created_at" : "2014-04-30 22:38:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
} ]