Grailbird.data.tweets_2009_02 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1262727811",
  "text" : "Jetzt kann ich auch verraten was Amazon geliefert hat. Neil Stephenson - \u201EIn The Beginning was the command line\u201C",
  "id" : 1262727811,
  "created_at" : "2009-02-28 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "herr_schrat",
      "screen_name" : "herr_schrat",
      "indices" : [ 4, 16 ],
      "id_str" : "16066591",
      "id" : 16066591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1262775241",
  "text" : "Der @herr_schrat ist auf dem Weg zu mir um seinen Geburtstag zu feiern. Nun soll seine Mitfahrgelegenheit mal Gas geben.",
  "id" : 1262775241,
  "created_at" : "2009-02-28 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Frank Abel",
      "screen_name" : "frankwettert",
      "indices" : [ 0, 13 ],
      "id_str" : "17215480",
      "id" : 17215480
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Bluescreen",
      "indices" : [ 50, 61 ]
    }, {
      "text" : "WindowsXP",
      "indices" : [ 62, 72 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1262827009",
  "geo" : { },
  "id_str" : "1262842848",
  "in_reply_to_user_id" : 17215480,
  "text" : "@frankwettert Was f\u00FCr ein Fehler ists denn genau? #Bluescreen #WindowsXP",
  "id" : 1262842848,
  "in_reply_to_status_id" : 1262827009,
  "created_at" : "2009-02-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "frankwettert",
  "in_reply_to_user_id_str" : "17215480",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Thomalla",
      "screen_name" : "digicamclub",
      "indices" : [ 0, 12 ],
      "id_str" : "126312409",
      "id" : 126312409
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1262161784",
  "geo" : { },
  "id_str" : "1262852085",
  "in_reply_to_user_id" : 15352789,
  "text" : "@digicamclub H\u00F6rt sich interessant an, werde ich mir merken",
  "id" : 1262852085,
  "in_reply_to_status_id" : 1262161784,
  "created_at" : "2009-02-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "marcthomalla",
  "in_reply_to_user_id_str" : "15352789",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Frank Abel",
      "screen_name" : "frankwettert",
      "indices" : [ 0, 13 ],
      "id_str" : "17215480",
      "id" : 17215480
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1262849416",
  "geo" : { },
  "id_str" : "1262854964",
  "in_reply_to_user_id" : 17215480,
  "text" : "@frankwettert Gibt es in den BIOS-Settings keinen Kompatibilit\u00E4tsmodus? Den Fehler hatte meine Freundin. Hilft ungemein :)",
  "id" : 1262854964,
  "in_reply_to_status_id" : 1262849416,
  "created_at" : "2009-02-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "frankwettert",
  "in_reply_to_user_id_str" : "17215480",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Frank Abel",
      "screen_name" : "frankwettert",
      "indices" : [ 0, 13 ],
      "id_str" : "17215480",
      "id" : 17215480
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1262856161",
  "geo" : { },
  "id_str" : "1262863991",
  "in_reply_to_user_id" : 17215480,
  "text" : "@frankwettert Ich w\u00FCrde da spontan Ubuntu empfehlen ;)",
  "id" : 1262863991,
  "in_reply_to_status_id" : 1262856161,
  "created_at" : "2009-02-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "frankwettert",
  "in_reply_to_user_id_str" : "17215480",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Frank Abel",
      "screen_name" : "frankwettert",
      "indices" : [ 0, 13 ],
      "id_str" : "17215480",
      "id" : 17215480
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1262875565",
  "geo" : { },
  "id_str" : "1262878328",
  "in_reply_to_user_id" : 17215480,
  "text" : "@frankwettert Kommt leider etwas drauf an. Wenn er alle Ger\u00E4te erkennt und Treiber hat ja. Wenn nein kann es zum Bastelkram verkommen",
  "id" : 1262878328,
  "in_reply_to_status_id" : 1262875565,
  "created_at" : "2009-02-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "frankwettert",
  "in_reply_to_user_id_str" : "17215480",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Frank Abel",
      "screen_name" : "frankwettert",
      "indices" : [ 0, 13 ],
      "id_str" : "17215480",
      "id" : 17215480
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1262875565",
  "geo" : { },
  "id_str" : "1262882728",
  "in_reply_to_user_id" : 17215480,
  "text" : "@frankwettert Was f\u00FCr ein Ger\u00E4t ist es denn? :)",
  "id" : 1262882728,
  "in_reply_to_status_id" : 1262875565,
  "created_at" : "2009-02-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "frankwettert",
  "in_reply_to_user_id_str" : "17215480",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Frank Abel",
      "screen_name" : "frankwettert",
      "indices" : [ 0, 13 ],
      "id_str" : "17215480",
      "id" : 17215480
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Laptop",
      "indices" : [ 133, 140 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1262901957",
  "geo" : { },
  "id_str" : "1262928232",
  "in_reply_to_user_id" : 17215480,
  "text" : "@frankwettert Mh bin unschl\u00FCssig.Linux muss man sich auch einarbeiten wollen, weil  von den Hintergr\u00FCnden bleibt man nicht verschont #Laptop",
  "id" : 1262928232,
  "in_reply_to_status_id" : 1262901957,
  "created_at" : "2009-02-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "frankwettert",
  "in_reply_to_user_id_str" : "17215480",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Frank Abel",
      "screen_name" : "frankwettert",
      "indices" : [ 0, 13 ],
      "id_str" : "17215480",
      "id" : 17215480
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1262909185",
  "geo" : { },
  "id_str" : "1262930536",
  "in_reply_to_user_id" : 17215480,
  "text" : "@frankwettert Aber wenn Linux w\u00FCrde ich auch Ubuntu empfehlen. Doch meine Frage bleibt: Auf was f\u00FCr einer Maschine?",
  "id" : 1262930536,
  "in_reply_to_status_id" : 1262909185,
  "created_at" : "2009-02-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "frankwettert",
  "in_reply_to_user_id_str" : "17215480",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Frank Abel",
      "screen_name" : "frankwettert",
      "indices" : [ 0, 13 ],
      "id_str" : "17215480",
      "id" : 17215480
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1262932882",
  "geo" : { },
  "id_str" : "1262936328",
  "in_reply_to_user_id" : 17215480,
  "text" : "@frankwettert Aye, dann Linux mit Ubuntu wenn du nichts ganz Windowsspezifisches brauchst :)",
  "id" : 1262936328,
  "in_reply_to_status_id" : 1262932882,
  "created_at" : "2009-02-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "frankwettert",
  "in_reply_to_user_id_str" : "17215480",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Frank Abel",
      "screen_name" : "frankwettert",
      "indices" : [ 0, 13 ],
      "id_str" : "17215480",
      "id" : 17215480
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1262941546",
  "geo" : { },
  "id_str" : "1262947258",
  "in_reply_to_user_id" : 17215480,
  "text" : "@frankwettert Vielleicht mal vorher Google befragen ob es da probleme mit Ubuntu auf dem Teil gibt. AntiVir ist \u00FCberfl\u00FCssig bei Linux",
  "id" : 1262947258,
  "in_reply_to_status_id" : 1262941546,
  "created_at" : "2009-02-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "frankwettert",
  "in_reply_to_user_id_str" : "17215480",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Frank Abel",
      "screen_name" : "frankwettert",
      "indices" : [ 0, 13 ],
      "id_str" : "17215480",
      "id" : 17215480
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1262956296",
  "geo" : { },
  "id_str" : "1262977398",
  "in_reply_to_user_id" : 17215480,
  "text" : "@frankwettert Na d\u00FCrfte das doch kein Problem sein. Dann mal fix das ISO geladen w\u00FCrd ich sagen.",
  "id" : 1262977398,
  "in_reply_to_status_id" : 1262956296,
  "created_at" : "2009-02-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "frankwettert",
  "in_reply_to_user_id_str" : "17215480",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1262999479",
  "text" : "Bl\u00F6de Frage: Wie kann ich im OS X-Terminal zum n\u00E4chsten Wort springen: Was sonst \u00FCberall mit Alt+Pfeiltaste geht?",
  "id" : 1262999479,
  "created_at" : "2009-02-28 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Frank Abel",
      "screen_name" : "frankwettert",
      "indices" : [ 0, 13 ],
      "id_str" : "17215480",
      "id" : 17215480
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1263030915",
  "geo" : { },
  "id_str" : "1263053174",
  "in_reply_to_user_id" : 17215480,
  "text" : "@frankwettert kompatibility-mode geht nicht?",
  "id" : 1263053174,
  "in_reply_to_status_id" : 1263030915,
  "created_at" : "2009-02-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "frankwettert",
  "in_reply_to_user_id_str" : "17215480",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Thomalla",
      "screen_name" : "digicamclub",
      "indices" : [ 0, 12 ],
      "id_str" : "126312409",
      "id" : 126312409
    }, {
      "name" : "#Knopf \u1D54\u1D25\u1D54",
      "screen_name" : "KnopfDE",
      "indices" : [ 13, 21 ],
      "id_str" : "888911129036169217",
      "id" : 888911129036169217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1261751948",
  "in_reply_to_user_id" : 15352789,
  "text" : "@digicamclub @knopfde Das frag ich mich auch, oder heisst das Rabatt auf Zeug?",
  "id" : 1261751948,
  "created_at" : "2009-02-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "marcthomalla",
  "in_reply_to_user_id_str" : "15352789",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1261786004",
  "text" : "Ich hab gerade mal Gravatare f\u00FCr mein Blog eingebaut. Was man aus Langeweile nicht tut.",
  "id" : 1261786004,
  "created_at" : "2009-02-28 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sweti Beltschew",
      "screen_name" : "sweti",
      "indices" : [ 0, 6 ],
      "id_str" : "18908120",
      "id" : 18908120
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1261789378",
  "geo" : { },
  "id_str" : "1261795037",
  "in_reply_to_user_id" : 18908120,
  "text" : "@sweti Daf\u00FCr w\u00E4re ich ein potentieller K\u00E4ufer.",
  "id" : 1261795037,
  "in_reply_to_status_id" : 1261789378,
  "created_at" : "2009-02-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "sweti",
  "in_reply_to_user_id_str" : "18908120",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1261809480",
  "text" : "Memo an mich: Nicht jeder nutzt Canon",
  "id" : 1261809480,
  "created_at" : "2009-02-28 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1261818975",
  "geo" : { },
  "id_str" : "1261819966",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod Ja, ein paar sogar. :)",
  "id" : 1261819966,
  "in_reply_to_status_id" : 1261818975,
  "created_at" : "2009-02-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1262051335",
  "text" : "Einkaufen bei Karstadt am Samstag == Krieg!",
  "id" : 1262051335,
  "created_at" : "2009-02-28 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1262064068",
  "text" : "Zeit f\u00FCr essen.  - http:\/\/bkite.com\/05379",
  "id" : 1262064068,
  "created_at" : "2009-02-28 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1262210504",
  "text" : "Wieder nach Hause geschafft. Ich hasse Menschenmassen die so v\u00F6llig real die Strassen versperren.",
  "id" : 1262210504,
  "created_at" : "2009-02-28 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1262685691",
  "text" : "Leider krankt Left4Dead am gleichen Problem wie Counterstrike: wenn das Team Mist ist macht es keinen Spa\u00DF.",
  "id" : 1262685691,
  "created_at" : "2009-02-28 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Houellebeck",
      "screen_name" : "houellebeck",
      "indices" : [ 0, 12 ],
      "id_str" : "107803659",
      "id" : 107803659
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1257295770",
  "text" : "@houellebeck der schl\u00E4ft auch bevorzugt in meinen Armen ;)",
  "id" : 1257295770,
  "created_at" : "2009-02-27 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1257306412",
  "text" : "Als ob die CDU auf einmal sexy w\u00FCrde wegen ihrer neuen Webseite. Deren Ideologie bleibt im letzten Jahrtausend stecken, web2.0 hin oder her",
  "id" : 1257306412,
  "created_at" : "2009-02-27 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1257309603",
  "geo" : { },
  "id_str" : "1257313782",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod Ja, das Jahrtausend stimmt schon, nur die erste H\u00E4lfte des Jahrtausends w\u00E4hrend alle anderen Parteien in der zweiten H\u00E4lfte stecken.",
  "id" : 1257313782,
  "in_reply_to_status_id" : 1257309603,
  "created_at" : "2009-02-27 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ilona S",
      "screen_name" : "mazoe28",
      "indices" : [ 0, 8 ],
      "id_str" : "18527855",
      "id" : 18527855
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1257352672",
  "geo" : { },
  "id_str" : "1257357046",
  "in_reply_to_user_id" : 18527855,
  "text" : "@Mazoe28 Nur eine Geldfrage w\u00FCrde ich sagen. Wenns geht 5D, wenn es wehtut lieber die 50 und Glas vom Restgeld kaufen.",
  "id" : 1257357046,
  "in_reply_to_status_id" : 1257352672,
  "created_at" : "2009-02-27 00:00:00 +0000",
  "in_reply_to_screen_name" : "mazoe28",
  "in_reply_to_user_id_str" : "18527855",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Houellebeck",
      "screen_name" : "houellebeck",
      "indices" : [ 0, 12 ],
      "id_str" : "107803659",
      "id" : 107803659
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1257388691",
  "text" : "@houellebeck f\u00FCr wieviel freigespielte Level gab es die denn freigeschaltet? ;)",
  "id" : 1257388691,
  "created_at" : "2009-02-27 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Houellebeck",
      "screen_name" : "houellebeck",
      "indices" : [ 0, 12 ],
      "id_str" : "107803659",
      "id" : 107803659
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1257412269",
  "text" : "@houellebeck Gibt es etwa keine Walkthroughs? :)",
  "id" : 1257412269,
  "created_at" : "2009-02-27 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1257477041",
  "text" : "Oho, der Postbote war gerade da mit einem Paket von Amazon. Wieder was zu lesen.",
  "id" : 1257477041,
  "created_at" : "2009-02-27 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1257489596",
  "geo" : { },
  "id_str" : "1257494812",
  "in_reply_to_user_id" : 8517622,
  "text" : "@lorXsion Autsch, doch nicht Europaweite Nutzung?",
  "id" : 1257494812,
  "in_reply_to_status_id" : 1257489596,
  "created_at" : "2009-02-27 00:00:00 +0000",
  "in_reply_to_screen_name" : "mitZett",
  "in_reply_to_user_id_str" : "8517622",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1257503950",
  "geo" : { },
  "id_str" : "1257505458",
  "in_reply_to_user_id" : 8517622,
  "text" : "@lorXsion Auf jedenfall gut zu wissen, bl\u00F6d nur das es einer Ausprobieren musste...",
  "id" : 1257505458,
  "in_reply_to_status_id" : 1257503950,
  "created_at" : "2009-02-27 00:00:00 +0000",
  "in_reply_to_screen_name" : "mitZett",
  "in_reply_to_user_id_str" : "8517622",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1257508814",
  "geo" : { },
  "id_str" : "1257511014",
  "in_reply_to_user_id" : 8517622,
  "text" : "@lorXsion Viel Erfolg :P",
  "id" : 1257511014,
  "in_reply_to_status_id" : 1257508814,
  "created_at" : "2009-02-27 00:00:00 +0000",
  "in_reply_to_screen_name" : "mitZett",
  "in_reply_to_user_id_str" : "8517622",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1257649866",
  "text" : "Ich glaub der Hund ist Borderliner so wie der zwischen lammfromm und totally insane wechselt.",
  "id" : 1257649866,
  "created_at" : "2009-02-27 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1257850449",
  "text" : "Mittagessen!",
  "id" : 1257850449,
  "created_at" : "2009-02-27 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1258295993",
  "text" : "Ich will heute Abend DVDs schauen. Hat jemand gute Tipps was?",
  "id" : 1258295993,
  "created_at" : "2009-02-27 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "#Knopf \u1D54\u1D25\u1D54",
      "screen_name" : "KnopfDE",
      "indices" : [ 0, 8 ],
      "id_str" : "888911129036169217",
      "id" : 888911129036169217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1258301144",
  "geo" : { },
  "id_str" : "1258309268",
  "in_reply_to_user_id" : 15482856,
  "text" : "@knopfde Ist doch ok, wenn jetzt alle Bewertungen von Nutzern entfernt wurden die das Programm gar nicht gekauft haben.",
  "id" : 1258309268,
  "in_reply_to_status_id" : 1258301144,
  "created_at" : "2009-02-27 00:00:00 +0000",
  "in_reply_to_screen_name" : "nuernbergr",
  "in_reply_to_user_id_str" : "15482856",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jam2000",
      "screen_name" : "Jam2000",
      "indices" : [ 0, 8 ],
      "id_str" : "16159002",
      "id" : 16159002
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1258310255",
  "geo" : { },
  "id_str" : "1258318078",
  "in_reply_to_user_id" : 16159002,
  "text" : "@Jam2000 Wenn ich es nicht besser w\u00FCsste h\u00E4tte ich auf den IE getippt ;)",
  "id" : 1258318078,
  "in_reply_to_status_id" : 1258310255,
  "created_at" : "2009-02-27 00:00:00 +0000",
  "in_reply_to_screen_name" : "Jam2000",
  "in_reply_to_user_id_str" : "16159002",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "raju e",
      "screen_name" : "rajue",
      "indices" : [ 0, 6 ],
      "id_str" : "289833731",
      "id" : 289833731
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1258329925",
  "text" : "@rajue Kenn ich schon. Und ist auch nicht so mein Fall gewesen muss ich sagen. Finde Chow Yun-Fat immer fehlplatziert.",
  "id" : 1258329925,
  "created_at" : "2009-02-27 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1258342979",
  "geo" : { },
  "id_str" : "1258346589",
  "in_reply_to_user_id" : 8517622,
  "text" : "@lorXsion Ich weiss ja wie das nachher aussieht wenn wir in der Videothek stehen und wieder nichts finden k\u00F6nnen. Deshalb die Tippsuche :)",
  "id" : 1258346589,
  "in_reply_to_status_id" : 1258342979,
  "created_at" : "2009-02-27 00:00:00 +0000",
  "in_reply_to_screen_name" : "mitZett",
  "in_reply_to_user_id_str" : "8517622",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0627\u0633\u0645\u0631\u0627\u0646\u064A \u0645\u0632\u064A\u0648\u0646",
      "screen_name" : "danishkirel",
      "indices" : [ 0, 12 ],
      "id_str" : "3393171664",
      "id" : 3393171664
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1258375671",
  "text" : "@danishkirel Den fand ich prima, aber leider hab ich den auch schon gesehen ;)",
  "id" : 1258375671,
  "created_at" : "2009-02-27 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Henning Sch\u00FCrig",
      "screen_name" : "hensch",
      "indices" : [ 0, 7 ],
      "id_str" : "3728881",
      "id" : 3728881
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1258372544",
  "geo" : { },
  "id_str" : "1258379227",
  "in_reply_to_user_id" : 3728881,
  "text" : "@hensch Gl\u00FCckwunsch, viel Spass mit dem Teil :)",
  "id" : 1258379227,
  "in_reply_to_status_id" : 1258372544,
  "created_at" : "2009-02-27 00:00:00 +0000",
  "in_reply_to_screen_name" : "hensch",
  "in_reply_to_user_id_str" : "3728881",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jam2000",
      "screen_name" : "Jam2000",
      "indices" : [ 0, 8 ],
      "id_str" : "16159002",
      "id" : 16159002
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1258375204",
  "geo" : { },
  "id_str" : "1258380508",
  "in_reply_to_user_id" : 16159002,
  "text" : "@Jam2000  Mh doch einfacher als gedacht. Was h\u00E4tte es auch sonst sein sollen ;)",
  "id" : 1258380508,
  "in_reply_to_status_id" : 1258375204,
  "created_at" : "2009-02-27 00:00:00 +0000",
  "in_reply_to_screen_name" : "Jam2000",
  "in_reply_to_user_id_str" : "16159002",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0627\u0633\u0645\u0631\u0627\u0646\u064A \u0645\u0632\u064A\u0648\u0646",
      "screen_name" : "danishkirel",
      "indices" : [ 0, 12 ],
      "id_str" : "3393171664",
      "id" : 3393171664
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1258409083",
  "text" : "@danishkirel Den kenn ich noch nicht, mal schauen ob der was sein k\u00F6nnte :)",
  "id" : 1258409083,
  "created_at" : "2009-02-27 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1258450011",
  "geo" : { },
  "id_str" : "1258461813",
  "in_reply_to_user_id" : 8517622,
  "text" : "@lorXsion 007 tu ich mir nach Casino Royale nicht mehr an solange da nicht der Darsteller gewechselt wird. Dark Knight & Wall-E sind bekannt",
  "id" : 1258461813,
  "in_reply_to_status_id" : 1258450011,
  "created_at" : "2009-02-27 00:00:00 +0000",
  "in_reply_to_screen_name" : "mitZett",
  "in_reply_to_user_id_str" : "8517622",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1258451953",
  "geo" : { },
  "id_str" : "1258464449",
  "in_reply_to_user_id" : 8517622,
  "text" : "@lorXsion Ich hab halt das Luxusproblem schon soviele gesehen zu haben das die Auswahl an guten Filmen im Mainstream gen Null geht.",
  "id" : 1258464449,
  "in_reply_to_status_id" : 1258451953,
  "created_at" : "2009-02-27 00:00:00 +0000",
  "in_reply_to_screen_name" : "mitZett",
  "in_reply_to_user_id_str" : "8517622",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1258470896",
  "geo" : { },
  "id_str" : "1258475507",
  "in_reply_to_user_id" : 8517622,
  "text" : "@lorXsion James Bond als Weichei ist halt nicht mehr James Bond, wie Star Wars ohne Raumschiffe & Aliens. :P",
  "id" : 1258475507,
  "in_reply_to_status_id" : 1258470896,
  "created_at" : "2009-02-27 00:00:00 +0000",
  "in_reply_to_screen_name" : "mitZett",
  "in_reply_to_user_id_str" : "8517622",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1258428003",
  "geo" : { },
  "id_str" : "1258476980",
  "in_reply_to_user_id" : 22149705,
  "text" : "@SideOneDummyRec Welcome! :)",
  "id" : 1258476980,
  "in_reply_to_status_id" : 1258428003,
  "created_at" : "2009-02-27 00:00:00 +0000",
  "in_reply_to_screen_name" : "uncle_m_music",
  "in_reply_to_user_id_str" : "22149705",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1258495715",
  "geo" : { },
  "id_str" : "1258515550",
  "in_reply_to_user_id" : 8517622,
  "text" : "@lorXsion Ja, aber das passt doch \u00FCberhaupt nicht zu Bond. Als ob Sean oder Roger sich so angestellt h\u00E4tten. Timothy Dalton vielleicht ;)",
  "id" : 1258515550,
  "in_reply_to_status_id" : 1258495715,
  "created_at" : "2009-02-27 00:00:00 +0000",
  "in_reply_to_screen_name" : "mitZett",
  "in_reply_to_user_id_str" : "8517622",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1258513108",
  "geo" : { },
  "id_str" : "1258516919",
  "in_reply_to_user_id" : 22149705,
  "text" : "@SideOneDummyRec Na dann ein erholsames Wochenende ;)",
  "id" : 1258516919,
  "in_reply_to_status_id" : 1258513108,
  "created_at" : "2009-02-27 00:00:00 +0000",
  "in_reply_to_screen_name" : "uncle_m_music",
  "in_reply_to_user_id_str" : "22149705",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1258486444",
  "geo" : { },
  "id_str" : "1258518514",
  "in_reply_to_user_id" : 8517622,
  "text" : "@lorXsion Die gro\u00DFe Standard-Antwort: Was willst du denn damit fotografieren? :P",
  "id" : 1258518514,
  "in_reply_to_status_id" : 1258486444,
  "created_at" : "2009-02-27 00:00:00 +0000",
  "in_reply_to_screen_name" : "mitZett",
  "in_reply_to_user_id_str" : "8517622",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1258539978",
  "geo" : { },
  "id_str" : "1258543022",
  "in_reply_to_user_id" : 8517622,
  "text" : "@lorXsion Ich hab selbst kein Allround da ich daf\u00FCr nicht so die Verwendung habe, nehme lieber ein zweites Objektiv mit.",
  "id" : 1258543022,
  "in_reply_to_status_id" : 1258539978,
  "created_at" : "2009-02-27 00:00:00 +0000",
  "in_reply_to_screen_name" : "mitZett",
  "in_reply_to_user_id_str" : "8517622",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1258539978",
  "geo" : { },
  "id_str" : "1258548727",
  "in_reply_to_user_id" : 8517622,
  "text" : "@lorXsion Aber f\u00FCr Parties wo dann sicher Lichtst\u00E4rke gefragt ist in Verbindung mit Weitwinkel kann ich  http:\/\/bit.ly\/19GNOI nur empfehlen.",
  "id" : 1258548727,
  "in_reply_to_status_id" : 1258539978,
  "created_at" : "2009-02-27 00:00:00 +0000",
  "in_reply_to_screen_name" : "mitZett",
  "in_reply_to_user_id_str" : "8517622",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1258801186",
  "geo" : { },
  "id_str" : "1259156234",
  "in_reply_to_user_id" : 8517622,
  "text" : "@lorXsion ich hab ein 18-55er und ein 55-200er. Nutze aber eigentlich nur die Festbrennweiten von daher kann ich dazu schlecht Tipps geben",
  "id" : 1259156234,
  "in_reply_to_status_id" : 1258801186,
  "created_at" : "2009-02-27 00:00:00 +0000",
  "in_reply_to_screen_name" : "mitZett",
  "in_reply_to_user_id_str" : "8517622",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1258801186",
  "geo" : { },
  "id_str" : "1259164515",
  "in_reply_to_user_id" : 8517622,
  "text" : "@lorXsion Aber 18-105 h\u00F6rt sich doch ganz ordentlich an, mit was f\u00FCr Blenden? Und ja das 20 mm ist eine Festbrennweite.Ist das nix f\u00FCr dich?",
  "id" : 1259164515,
  "in_reply_to_status_id" : 1258801186,
  "created_at" : "2009-02-27 00:00:00 +0000",
  "in_reply_to_screen_name" : "mitZett",
  "in_reply_to_user_id_str" : "8517622",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "The_Smoking_GNU",
      "indices" : [ 0, 16 ],
      "id_str" : "14535787",
      "id" : 14535787
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1258976320",
  "geo" : { },
  "id_str" : "1259165962",
  "in_reply_to_user_id" : 14535787,
  "text" : "@The_Smoking_GNU Wir haben uns nun f\u00FCr \u201CErster Mai - Helden der Arbeit\u201D entschieden. Der Trailer sieht witzig aus.",
  "id" : 1259165962,
  "in_reply_to_status_id" : 1258976320,
  "created_at" : "2009-02-27 00:00:00 +0000",
  "in_reply_to_screen_name" : "The_Smoking_GNU",
  "in_reply_to_user_id_str" : "14535787",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "The_Smoking_GNU",
      "indices" : [ 0, 16 ],
      "id_str" : "14535787",
      "id" : 14535787
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1258976320",
  "geo" : { },
  "id_str" : "1259168565",
  "in_reply_to_user_id" : 14535787,
  "text" : "@The_Smoking_GNU Idiocracy sieht aber auch gut aus. Ist vorgemerkt :)",
  "id" : 1259168565,
  "in_reply_to_status_id" : 1258976320,
  "created_at" : "2009-02-27 00:00:00 +0000",
  "in_reply_to_screen_name" : "The_Smoking_GNU",
  "in_reply_to_user_id_str" : "14535787",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1259185484",
  "text" : "Der bl\u00F6de Hund hat mit seinem wedelnden Schwanz den Aschenbecher vom Tisch geschleudert. Sch\u00F6n wie er sich so freut. Ich hol den Staubsauger",
  "id" : 1259185484,
  "created_at" : "2009-02-27 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1259195987",
  "geo" : { },
  "id_str" : "1259200365",
  "in_reply_to_user_id" : 8517622,
  "text" : "@lorXsion Und was ist mit dem 18-200er? Bei der Qualit\u00E4t wird man nat\u00FCrlich immer mehr Abstriche machen m\u00FCssen.",
  "id" : 1259200365,
  "in_reply_to_status_id" : 1259195987,
  "created_at" : "2009-02-27 00:00:00 +0000",
  "in_reply_to_screen_name" : "mitZett",
  "in_reply_to_user_id_str" : "8517622",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1259200001",
  "geo" : { },
  "id_str" : "1259204385",
  "in_reply_to_user_id" : 8517622,
  "text" : "@lorXsion Muss man halt mit den F\u00FC\u00DFen zoomen. ;)",
  "id" : 1259204385,
  "in_reply_to_status_id" : 1259200001,
  "created_at" : "2009-02-27 00:00:00 +0000",
  "in_reply_to_screen_name" : "mitZett",
  "in_reply_to_user_id_str" : "8517622",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Houellebeck",
      "screen_name" : "houellebeck",
      "indices" : [ 0, 12 ],
      "id_str" : "107803659",
      "id" : 107803659
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1260060037",
  "text" : "@houellebeck hat Guido Knopp Urlaub?",
  "id" : 1260060037,
  "created_at" : "2009-02-27 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Houellebeck",
      "screen_name" : "houellebeck",
      "indices" : [ 0, 12 ],
      "id_str" : "107803659",
      "id" : 107803659
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "couchsurfing",
      "indices" : [ 120, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1255590366",
  "text" : "@houellebeck Genau das tu ich gerade. So mit Laptop auf den Beinen liege ich auf dem Sofa. Oder ist das was anderes? ;) #couchsurfing",
  "id" : 1255590366,
  "created_at" : "2009-02-26 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Max von Webel",
      "screen_name" : "343max",
      "indices" : [ 0, 7 ],
      "id_str" : "2284151",
      "id" : 2284151
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1255584427",
  "geo" : { },
  "id_str" : "1255603840",
  "in_reply_to_user_id" : 2284151,
  "text" : "@343max And so this is Twitter \/ For weak and for strong \/ For rich and the poor ones \/ The world is so wrong",
  "id" : 1255603840,
  "in_reply_to_status_id" : 1255584427,
  "created_at" : "2009-02-26 00:00:00 +0000",
  "in_reply_to_screen_name" : "343max",
  "in_reply_to_user_id_str" : "2284151",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1255626675",
  "text" : "So, gute Nacht Twitter!",
  "id" : 1255626675,
  "created_at" : "2009-02-26 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1252902819",
  "text" : "Manchmal ist der Hund bekloppt, da kommt man gerade von draussen mit ihm rein und 5 Minuten sp\u00E4ter sitzt er wieder vor der T\u00FCr und jammert",
  "id" : 1252902819,
  "created_at" : "2009-02-26 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1252980198",
  "text" : "Ich muss gleich mal einkaufen sonst gibt es wieder kein Mittagessen.",
  "id" : 1252980198,
  "created_at" : "2009-02-26 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "feierabendblog",
      "screen_name" : "feierabendblog",
      "indices" : [ 0, 15 ],
      "id_str" : "17773201",
      "id" : 17773201
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1252983221",
  "geo" : { },
  "id_str" : "1252992093",
  "in_reply_to_user_id" : 17773201,
  "text" : "@feierabendblog Ein Bad in Kaffee \u00FCberstehen die auch super.",
  "id" : 1252992093,
  "in_reply_to_status_id" : 1252983221,
  "created_at" : "2009-02-26 00:00:00 +0000",
  "in_reply_to_screen_name" : "feierabendblog",
  "in_reply_to_user_id_str" : "17773201",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "panik",
      "indices" : [ 23, 29 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1253034193",
  "text" : "Aaaaaaaaaaaaaaaaaaahh! #panik",
  "id" : 1253034193,
  "created_at" : "2009-02-26 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Figueroa",
      "screen_name" : "unimatrixZxero",
      "indices" : [ 0, 15 ],
      "id_str" : "645353",
      "id" : 645353
    }, {
      "name" : "Markus",
      "screen_name" : "germanstudent",
      "indices" : [ 16, 30 ],
      "id_str" : "2493441",
      "id" : 2493441
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1253041979",
  "geo" : { },
  "id_str" : "1253084107",
  "in_reply_to_user_id" : 645353,
  "text" : "@unimatrixZxero @germanstudent Langsam sollte ich doch Wissen das meine Wanduhr eine Stunde vorgeht weil ich die Letzte Umstellung verga\u00DF.",
  "id" : 1253084107,
  "in_reply_to_status_id" : 1253041979,
  "created_at" : "2009-02-26 00:00:00 +0000",
  "in_reply_to_screen_name" : "unimatrixZxero",
  "in_reply_to_user_id_str" : "645353",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Figueroa",
      "screen_name" : "unimatrixZxero",
      "indices" : [ 0, 15 ],
      "id_str" : "645353",
      "id" : 645353
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1253111647",
  "geo" : { },
  "id_str" : "1253121057",
  "in_reply_to_user_id" : 645353,
  "text" : "@unimatrixZxero Geht ja auch eigentlich ganz gut. Bis man nur mal fix dr\u00FCberschaut und es vergisst ;)",
  "id" : 1253121057,
  "in_reply_to_status_id" : 1253111647,
  "created_at" : "2009-02-26 00:00:00 +0000",
  "in_reply_to_screen_name" : "unimatrixZxero",
  "in_reply_to_user_id_str" : "645353",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Figueroa",
      "screen_name" : "unimatrixZxero",
      "indices" : [ 0, 15 ],
      "id_str" : "645353",
      "id" : 645353
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1253123284",
  "geo" : { },
  "id_str" : "1253129288",
  "in_reply_to_user_id" : 645353,
  "text" : "@unimatrixZxero Meist kommt erst das richtige Joggen um noch p\u00FCnktlich irgendwo anzukommen und dabei erst das Gehirn-Jogging ;)",
  "id" : 1253129288,
  "in_reply_to_status_id" : 1253123284,
  "created_at" : "2009-02-26 00:00:00 +0000",
  "in_reply_to_screen_name" : "unimatrixZxero",
  "in_reply_to_user_id_str" : "645353",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1253131258",
  "text" : "Mittagessen in Minimalistisch.  http:\/\/twitpic.com\/1p9kc",
  "id" : 1253131258,
  "created_at" : "2009-02-26 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "franciele",
      "screen_name" : "kaczmarek",
      "indices" : [ 3, 13 ],
      "id_str" : "88702016",
      "id" : 88702016
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1253145710",
  "text" : "RT @kaczmarek: Wenn ich mit 78 nur HALB so cool bin wie er hier, bin ich gl\u00FCcklich (und ziemlich cool)! http:\/\/tinyurl.com\/cy27kz",
  "id" : 1253145710,
  "created_at" : "2009-02-26 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "kwerfeldein",
      "screen_name" : "kwerfeldein",
      "indices" : [ 0, 12 ],
      "id_str" : "428633",
      "id" : 428633
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1253139006",
  "geo" : { },
  "id_str" : "1253148028",
  "in_reply_to_user_id" : 428633,
  "text" : "@kwerfeldein Uh, das h\u00E4tte ich ohne Wiki auch nicht gewusst. Ist ja auch schon was sehr spezielles.",
  "id" : 1253148028,
  "in_reply_to_status_id" : 1253139006,
  "created_at" : "2009-02-26 00:00:00 +0000",
  "in_reply_to_screen_name" : "kwerfeldein",
  "in_reply_to_user_id_str" : "428633",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1253184618",
  "text" : "Oh ich darf AmazonPrime f\u00FCr einen Monat testen. Ach warum nicht? Vielleicht weil ich dann noch mehr Zeug da bestelle? Guter Einwand.",
  "id" : 1253184618,
  "created_at" : "2009-02-26 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "iPhone",
      "indices" : [ 52, 59 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1253194973",
  "geo" : { },
  "id_str" : "1253213134",
  "in_reply_to_user_id" : 8517622,
  "text" : "@lorXsion Ich finde Fieldrunners sehr unterhaltsam. #iPhone",
  "id" : 1253213134,
  "in_reply_to_status_id" : 1253194973,
  "created_at" : "2009-02-26 00:00:00 +0000",
  "in_reply_to_screen_name" : "mitZett",
  "in_reply_to_user_id_str" : "8517622",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1253243009",
  "geo" : { },
  "id_str" : "1253262568",
  "in_reply_to_user_id" : 8517622,
  "text" : "@lorXsion Sonst find ich auch \u201CFrenzic\u201D ganz gut.",
  "id" : 1253262568,
  "in_reply_to_status_id" : 1253243009,
  "created_at" : "2009-02-26 00:00:00 +0000",
  "in_reply_to_screen_name" : "mitZett",
  "in_reply_to_user_id_str" : "8517622",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joerg Roehlig",
      "screen_name" : "JoergR",
      "indices" : [ 0, 7 ],
      "id_str" : "774628164177985537",
      "id" : 774628164177985537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1253381663",
  "text" : "@JoergR sehe ich genauso :)",
  "id" : 1253381663,
  "created_at" : "2009-02-26 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1253373946",
  "geo" : { },
  "id_str" : "1253384218",
  "in_reply_to_user_id" : 8517622,
  "text" : "@lorXsion h\u00F6rt sich gut an. Viel Spa\u00DF :)",
  "id" : 1253384218,
  "in_reply_to_status_id" : 1253373946,
  "created_at" : "2009-02-26 00:00:00 +0000",
  "in_reply_to_screen_name" : "mitZett",
  "in_reply_to_user_id_str" : "8517622",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Pharyngula",
      "indices" : [ 41, 52 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1253392395",
  "text" : "http:\/\/tinyurl.com\/bxgtzz A simple truth #Pharyngula",
  "id" : 1253392395,
  "created_at" : "2009-02-26 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1253409546",
  "geo" : { },
  "id_str" : "1253412485",
  "in_reply_to_user_id" : 8517622,
  "text" : "@lorXsion Sieht unges\u00FCnder aus als meine M\u00F6hren & Paprika-Sticks ;)",
  "id" : 1253412485,
  "in_reply_to_status_id" : 1253409546,
  "created_at" : "2009-02-26 00:00:00 +0000",
  "in_reply_to_screen_name" : "mitZett",
  "in_reply_to_user_id_str" : "8517622",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1253454298",
  "geo" : { },
  "id_str" : "1253462201",
  "in_reply_to_user_id" : 8517622,
  "text" : "@LORXSION Na gut, die Knoblauchso\u00DFe wird nicht das ges\u00FCndeste gewesen sein, aber ich hab ja auch nicht den ganzen Topf davon gefuttert ;)",
  "id" : 1253462201,
  "in_reply_to_status_id" : 1253454298,
  "created_at" : "2009-02-26 00:00:00 +0000",
  "in_reply_to_screen_name" : "mitZett",
  "in_reply_to_user_id_str" : "8517622",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1253757689",
  "text" : "Mh ich m\u00FCsste mal wieder was schreiben.",
  "id" : 1253757689,
  "created_at" : "2009-02-26 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Markus",
      "screen_name" : "germanstudent",
      "indices" : [ 0, 14 ],
      "id_str" : "2493441",
      "id" : 2493441
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1253758979",
  "geo" : { },
  "id_str" : "1253769623",
  "in_reply_to_user_id" : 2493441,
  "text" : "@germanstudent Ist das nicht Standard bei Apple-Produkten? ;) Sei froh das der iPhone-Akku nicht nur ne Batterie ist ;)",
  "id" : 1253769623,
  "in_reply_to_status_id" : 1253758979,
  "created_at" : "2009-02-26 00:00:00 +0000",
  "in_reply_to_screen_name" : "germanstudent",
  "in_reply_to_user_id_str" : "2493441",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1254744023",
  "text" : "\u201CExtremismusforscher\u201D - Was es nicht alles gibt.",
  "id" : 1254744023,
  "created_at" : "2009-02-26 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1254778511",
  "text" : "Und ab zu den Pfadfindern.",
  "id" : 1254778511,
  "created_at" : "2009-02-26 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1255294722",
  "text" : "Ewig im Regen stehen um darauf zu warten das der letzte abgeholt wird ist bl\u00F6d.",
  "id" : 1255294722,
  "created_at" : "2009-02-26 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1255432364",
  "text" : "(Endlich) ein neuer W&W-Post - Neues zu Webdienst Mendeley: http:\/\/bit.ly\/SP2eq",
  "id" : 1255432364,
  "created_at" : "2009-02-26 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stefan",
      "screen_name" : "stelten",
      "indices" : [ 0, 8 ],
      "id_str" : "14082615",
      "id" : 14082615
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "muenster",
      "indices" : [ 37, 46 ]
    }, {
      "text" : "couchsurfing",
      "indices" : [ 47, 60 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1255528903",
  "geo" : { },
  "id_str" : "1255540094",
  "in_reply_to_user_id" : 14082615,
  "text" : "@stelten Ja h\u00E4tte ich woh Lust zu :) #muenster #couchsurfing",
  "id" : 1255540094,
  "in_reply_to_status_id" : 1255528903,
  "created_at" : "2009-02-26 00:00:00 +0000",
  "in_reply_to_screen_name" : "stelten",
  "in_reply_to_user_id_str" : "14082615",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ScienceBlogs",
      "screen_name" : "ScienceBlogs",
      "indices" : [ 0, 13 ],
      "id_str" : "37921458",
      "id" : 37921458
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1248695016",
  "geo" : { },
  "id_str" : "1248708205",
  "in_reply_to_user_id" : 15072786,
  "text" : "@Scienceblogs Ich weiss nicht, aber falls doch seht es als Kompliment eurer Reichweite gegen\u00FCber :)",
  "id" : 1248708205,
  "in_reply_to_status_id" : 1248695016,
  "created_at" : "2009-02-25 00:00:00 +0000",
  "in_reply_to_screen_name" : "ScienceBlogs_de",
  "in_reply_to_user_id_str" : "15072786",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "crashtron",
      "screen_name" : "crashtron",
      "indices" : [ 0, 10 ],
      "id_str" : "33913",
      "id" : 33913
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1248751737",
  "geo" : { },
  "id_str" : "1248761875",
  "in_reply_to_user_id" : 33913,
  "text" : "@crashtron Das wird dauern, die sind doch gerade erst durch ihr Update durch",
  "id" : 1248761875,
  "in_reply_to_status_id" : 1248751737,
  "created_at" : "2009-02-25 00:00:00 +0000",
  "in_reply_to_screen_name" : "crashtron",
  "in_reply_to_user_id_str" : "33913",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "crashtron",
      "screen_name" : "crashtron",
      "indices" : [ 0, 10 ],
      "id_str" : "33913",
      "id" : 33913
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1248765064",
  "geo" : { },
  "id_str" : "1248767734",
  "in_reply_to_user_id" : 33913,
  "text" : "@crashtron Dann ist die Frage wie wichtig dir Firewire ist und ob du die gr\u00F6\u00DFere Grafikkarte des Pros ben\u00F6tigst oder nicht",
  "id" : 1248767734,
  "in_reply_to_status_id" : 1248765064,
  "created_at" : "2009-02-25 00:00:00 +0000",
  "in_reply_to_screen_name" : "crashtron",
  "in_reply_to_user_id_str" : "33913",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "crashtron",
      "screen_name" : "crashtron",
      "indices" : [ 0, 10 ],
      "id_str" : "33913",
      "id" : 33913
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1248796783",
  "geo" : { },
  "id_str" : "1248813985",
  "in_reply_to_user_id" : 33913,
  "text" : "@crashtron Das White d\u00FCrfte noch Firewire haben wenn ich das recht in Erinnerung habe. Daf\u00FCr fehlt dir dann allerdings das Multitouchpad",
  "id" : 1248813985,
  "in_reply_to_status_id" : 1248796783,
  "created_at" : "2009-02-25 00:00:00 +0000",
  "in_reply_to_screen_name" : "crashtron",
  "in_reply_to_user_id_str" : "33913",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1248955952",
  "text" : "Katastrophen-Twittern wird auf Dauer auch langweilig.",
  "id" : 1248955952,
  "created_at" : "2009-02-25 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1249210279",
  "text" : "Gerade mal wieder von Hand gesp\u00FClt. Bl\u00F6de Arbeit.",
  "id" : 1249210279,
  "created_at" : "2009-02-25 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1249224850",
  "text" : "Digg ist auch ganz sch\u00F6n langsam. Da wurde der Amsterdamer Absturz erst vor 45 Minuten \u00F6ffentlich.",
  "id" : 1249224850,
  "created_at" : "2009-02-25 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "thopex",
      "screen_name" : "thopex",
      "indices" : [ 0, 7 ],
      "id_str" : "6266362",
      "id" : 6266362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1249530272",
  "geo" : { },
  "id_str" : "1249553236",
  "in_reply_to_user_id" : 6266362,
  "text" : "@thopex Gute Wahl, hab ich gerade zuende geh\u00F6rt",
  "id" : 1249553236,
  "in_reply_to_status_id" : 1249530272,
  "created_at" : "2009-02-25 00:00:00 +0000",
  "in_reply_to_screen_name" : "thopex",
  "in_reply_to_user_id_str" : "6266362",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1249827603",
  "text" : "Pizza bestellt, Mittagessen kommt also gleich.",
  "id" : 1249827603,
  "created_at" : "2009-02-25 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1249845797",
  "text" : "Was so gar nicht geht sind Webseiten mit bescheuertem Ton den man nichtmal ausschalten kann.",
  "id" : 1249845797,
  "created_at" : "2009-02-25 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "kwerfeldein",
      "screen_name" : "kwerfeldein",
      "indices" : [ 0, 12 ],
      "id_str" : "428633",
      "id" : 428633
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1250045590",
  "geo" : { },
  "id_str" : "1250057233",
  "in_reply_to_user_id" : 428633,
  "text" : "@kwerfeldein Das englischsprachige Gegenst\u00FCck zum USM? :P",
  "id" : 1250057233,
  "in_reply_to_status_id" : 1250045590,
  "created_at" : "2009-02-25 00:00:00 +0000",
  "in_reply_to_screen_name" : "kwerfeldein",
  "in_reply_to_user_id_str" : "428633",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1250390800",
  "text" : "Ich schau mir nun \u201COnce\u201D an. Bis dahin",
  "id" : 1250390800,
  "created_at" : "2009-02-25 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1250725277",
  "text" : "Once ist ein sehr geiler Film mit noch tollerem Soundtrack. Doch k\u00F6nnte ich jetzt bitte mein RAM wiederhaben vlc?",
  "id" : 1250725277,
  "created_at" : "2009-02-25 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "...",
      "screen_name" : "LIinLE",
      "indices" : [ 0, 7 ],
      "id_str" : "14399022",
      "id" : 14399022
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1250732936",
  "geo" : { },
  "id_str" : "1250743938",
  "in_reply_to_user_id" : 14399022,
  "text" : "@LIinLE War mir v\u00F6llig unbekannt bis mein Lieblingsnachbar mir heut Nachmittag die DVD mitgebracht hat.",
  "id" : 1250743938,
  "in_reply_to_status_id" : 1250732936,
  "created_at" : "2009-02-25 00:00:00 +0000",
  "in_reply_to_screen_name" : "LIinLE",
  "in_reply_to_user_id_str" : "14399022",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "...",
      "screen_name" : "LIinLE",
      "indices" : [ 0, 7 ],
      "id_str" : "14399022",
      "id" : 14399022
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1250746638",
  "geo" : { },
  "id_str" : "1250762777",
  "in_reply_to_user_id" : 14399022,
  "text" : "@LIinLE Ja scheint so, werd ich dann mal etwas popul\u00E4rer machen im Freundeskreis :)",
  "id" : 1250762777,
  "in_reply_to_status_id" : 1250746638,
  "created_at" : "2009-02-25 00:00:00 +0000",
  "in_reply_to_screen_name" : "LIinLE",
  "in_reply_to_user_id_str" : "14399022",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Benjamin Claverie",
      "screen_name" : "Skl8em",
      "indices" : [ 0, 7 ],
      "id_str" : "13823092",
      "id" : 13823092
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1250770909",
  "geo" : { },
  "id_str" : "1250778900",
  "in_reply_to_user_id" : 13823092,
  "text" : "@Skl8em Bitte mit http damit klickbar :P",
  "id" : 1250778900,
  "in_reply_to_status_id" : 1250770909,
  "created_at" : "2009-02-25 00:00:00 +0000",
  "in_reply_to_screen_name" : "Skl8em",
  "in_reply_to_user_id_str" : "13823092",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Benjamin Claverie",
      "screen_name" : "Skl8em",
      "indices" : [ 0, 7 ],
      "id_str" : "13823092",
      "id" : 13823092
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1250802410",
  "geo" : { },
  "id_str" : "1250808000",
  "in_reply_to_user_id" : 13823092,
  "text" : "@Skl8em Oh, bist wieder im Pier House oder woher kommt mir die Position bekannt vor? Dann sei es verziehen ;)",
  "id" : 1250808000,
  "in_reply_to_status_id" : 1250802410,
  "created_at" : "2009-02-25 00:00:00 +0000",
  "in_reply_to_screen_name" : "Skl8em",
  "in_reply_to_user_id_str" : "13823092",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Benjamin Claverie",
      "screen_name" : "Skl8em",
      "indices" : [ 0, 7 ],
      "id_str" : "13823092",
      "id" : 13823092
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1250818852",
  "geo" : { },
  "id_str" : "1250827757",
  "in_reply_to_user_id" : 13823092,
  "text" : "@Skl8em Das zeigt mal wieder wie schlecht Doktoranden doch verdienen. Solltet euch zusammentun und dagegen protestieren.",
  "id" : 1250827757,
  "in_reply_to_status_id" : 1250818852,
  "created_at" : "2009-02-25 00:00:00 +0000",
  "in_reply_to_screen_name" : "Skl8em",
  "in_reply_to_user_id_str" : "13823092",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0627\u0633\u0645\u0631\u0627\u0646\u064A \u0645\u0632\u064A\u0648\u0646",
      "screen_name" : "danishkirel",
      "indices" : [ 0, 12 ],
      "id_str" : "3393171664",
      "id" : 3393171664
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1250829030",
  "text" : "@danishkirel Okay dann ists vielleicht doch nicht so der Insider-Tipp sondern ich bin der einzige der es nicht kennt.",
  "id" : 1250829030,
  "created_at" : "2009-02-25 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0627\u0633\u0645\u0631\u0627\u0646\u064A \u0645\u0632\u064A\u0648\u0646",
      "screen_name" : "danishkirel",
      "indices" : [ 0, 12 ],
      "id_str" : "3393171664",
      "id" : 3393171664
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1250853478",
  "text" : "@danishkirel Mit der Begr\u00FCndung kann ich auch ganz gut Leben. :)",
  "id" : 1250853478,
  "created_at" : "2009-02-25 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Benjamin Claverie",
      "screen_name" : "Skl8em",
      "indices" : [ 0, 7 ],
      "id_str" : "13823092",
      "id" : 13823092
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1250842780",
  "geo" : { },
  "id_str" : "1250855745",
  "in_reply_to_user_id" : 13823092,
  "text" : "@Skl8em Ich w\u00FCrde sagen es ist eine Kombination aus beidem. Wobei ich sagen muss das meine Wohnung preislich ganz okay ist f\u00FCr die Lage.",
  "id" : 1250855745,
  "in_reply_to_status_id" : 1250842780,
  "created_at" : "2009-02-25 00:00:00 +0000",
  "in_reply_to_screen_name" : "Skl8em",
  "in_reply_to_user_id_str" : "13823092",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1250901530",
  "text" : "Wieso bl\u00E4hen sich kernel_task & mds eigentlich im laufenden Betrieb langsam aber sicher so unglaublich auf?",
  "id" : 1250901530,
  "created_at" : "2009-02-25 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1251021096",
  "text" : "Gerade mal wieder ein paar unn\u00FCtze Programme vom iPhone geworfen.",
  "id" : 1251021096,
  "created_at" : "2009-02-25 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0627\u0633\u0645\u0631\u0627\u0646\u064A \u0645\u0632\u064A\u0648\u0646",
      "screen_name" : "danishkirel",
      "indices" : [ 0, 12 ],
      "id_str" : "3393171664",
      "id" : 3393171664
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1251228634",
  "text" : "@danishkirel hehe, es waren nur ein paar Spiele :)",
  "id" : 1251228634,
  "created_at" : "2009-02-25 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helmuth Ringhandt",
      "screen_name" : "iKieler",
      "indices" : [ 0, 8 ],
      "id_str" : "18356871",
      "id" : 18356871
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1251156754",
  "geo" : { },
  "id_str" : "1251232690",
  "in_reply_to_user_id" : 18123358,
  "text" : "@iKieler Haupts\u00E4chlich ein paar Spiele die Langweilig geworden sind oder schon durchgespielt sind.",
  "id" : 1251232690,
  "in_reply_to_status_id" : 1251156754,
  "created_at" : "2009-02-25 00:00:00 +0000",
  "in_reply_to_screen_name" : "ringhandt",
  "in_reply_to_user_id_str" : "18123358",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Figueroa",
      "screen_name" : "unimatrixZxero",
      "indices" : [ 0, 15 ],
      "id_str" : "645353",
      "id" : 645353
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "religion",
      "indices" : [ 122, 131 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1248550524",
  "geo" : { },
  "id_str" : "1248559028",
  "in_reply_to_user_id" : 645353,
  "text" : "@unimatrixZxero ja das sehe ich genauso. Doch leider wird die Trennung von Staat&Kirche hierzulande nicht Ernst genommen. #religion",
  "id" : 1248559028,
  "in_reply_to_status_id" : 1248550524,
  "created_at" : "2009-02-25 00:00:00 +0000",
  "in_reply_to_screen_name" : "unimatrixZxero",
  "in_reply_to_user_id_str" : "645353",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ScienceBlogs",
      "screen_name" : "ScienceBlogs",
      "indices" : [ 0, 13 ],
      "id_str" : "37921458",
      "id" : 37921458
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1248656313",
  "geo" : { },
  "id_str" : "1248658110",
  "in_reply_to_user_id" : 15072786,
  "text" : "@Scienceblogs R\u00E4chen sich nun alle Esoteriker, Astrologen und Kreationisten?",
  "id" : 1248658110,
  "in_reply_to_status_id" : 1248656313,
  "created_at" : "2009-02-25 00:00:00 +0000",
  "in_reply_to_screen_name" : "ScienceBlogs_de",
  "in_reply_to_user_id_str" : "15072786",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Wired_Science",
      "indices" : [ 0, 14 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1248669178",
  "text" : "#Wired_Science Without Tears, Is There Still Sadness? http:\/\/tinyurl.com\/ankyjj #",
  "id" : 1248669178,
  "created_at" : "2009-02-25 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stefan",
      "screen_name" : "stelten",
      "indices" : [ 0, 8 ],
      "id_str" : "14082615",
      "id" : 14082615
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1244171714",
  "geo" : { },
  "id_str" : "1244177483",
  "in_reply_to_user_id" : 14082615,
  "text" : "@stelten Ganz cool. Und dank Bachelor\/Master ist das Langzeitwissen eh nicht mehr gefragt. \u201CR\u00FCckstandsfreies Lernen\u201D heisst das bei uns.",
  "id" : 1244177483,
  "in_reply_to_status_id" : 1244171714,
  "created_at" : "2009-02-24 00:00:00 +0000",
  "in_reply_to_screen_name" : "stelten",
  "in_reply_to_user_id_str" : "14082615",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stefan",
      "screen_name" : "stelten",
      "indices" : [ 0, 8 ],
      "id_str" : "14082615",
      "id" : 14082615
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1244183873",
  "geo" : { },
  "id_str" : "1244188261",
  "in_reply_to_user_id" : 14082615,
  "text" : "@stelten Das ist die Angst vor Copyright-Verletzungen bei Abbildungen. Deshalb sind bei uns auch fast alle Skripte mit Passw\u00F6rtern versehen.",
  "id" : 1244188261,
  "in_reply_to_status_id" : 1244183873,
  "created_at" : "2009-02-24 00:00:00 +0000",
  "in_reply_to_screen_name" : "stelten",
  "in_reply_to_user_id_str" : "14082615",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stefan",
      "screen_name" : "stelten",
      "indices" : [ 0, 8 ],
      "id_str" : "14082615",
      "id" : 14082615
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1244183873",
  "geo" : { },
  "id_str" : "1244189650",
  "in_reply_to_user_id" : 14082615,
  "text" : "@stelten Die Verlage haben wohl Angst das niemand mehr ihre \u00FCberteuerten Lehrb\u00FCcher kauft wenn alle Studenten die Bilder schon haben.",
  "id" : 1244189650,
  "in_reply_to_status_id" : 1244183873,
  "created_at" : "2009-02-24 00:00:00 +0000",
  "in_reply_to_screen_name" : "stelten",
  "in_reply_to_user_id_str" : "14082615",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "gmail",
      "indices" : [ 37, 43 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1244445135",
  "geo" : { },
  "id_str" : "1244486034",
  "in_reply_to_user_id" : 8517622,
  "text" : "@lorXsion Womit pusht du den Google? #gmail",
  "id" : 1244486034,
  "in_reply_to_status_id" : 1244445135,
  "created_at" : "2009-02-24 00:00:00 +0000",
  "in_reply_to_screen_name" : "mitZett",
  "in_reply_to_user_id_str" : "8517622",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1244495078",
  "geo" : { },
  "id_str" : "1244496283",
  "in_reply_to_user_id" : 8517622,
  "text" : "@lorXsion Hab ich da was \u00FCbersehen? Ich dachte Standardm\u00E4ssig pusht gMail gar nicht sondern l\u00E4sst nur in Intervallen abrufen?",
  "id" : 1244496283,
  "in_reply_to_status_id" : 1244495078,
  "created_at" : "2009-02-24 00:00:00 +0000",
  "in_reply_to_screen_name" : "mitZett",
  "in_reply_to_user_id_str" : "8517622",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1244503799",
  "geo" : { },
  "id_str" : "1244507411",
  "in_reply_to_user_id" : 8517622,
  "text" : "@lorXsion Hast du denn die \u201Calle x Minuten Mails abholen\u201D-Funktion an? Das Nicht-Push f\u00FCr arme Leute sozusagen? :)",
  "id" : 1244507411,
  "in_reply_to_status_id" : 1244503799,
  "created_at" : "2009-02-24 00:00:00 +0000",
  "in_reply_to_screen_name" : "mitZett",
  "in_reply_to_user_id_str" : "8517622",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1244512185",
  "geo" : { },
  "id_str" : "1244515711",
  "in_reply_to_user_id" : 8517622,
  "text" : "@lorXsion Ne, geht auch beides. Ich pushe nur die Kalender via Google und lasse die Mails alle 15 Minuten checken von allen Accounts.",
  "id" : 1244515711,
  "in_reply_to_status_id" : 1244512185,
  "created_at" : "2009-02-24 00:00:00 +0000",
  "in_reply_to_screen_name" : "mitZett",
  "in_reply_to_user_id_str" : "8517622",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1244521209",
  "text" : "Mal sehen ob die last.fm-Integration von blip.fm auch geht. Scheiss Web2.0 Ged\u00F6ns ;) \u266B http:\/\/blip.fm\/~2ezh8",
  "id" : 1244521209,
  "created_at" : "2009-02-24 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1244513032",
  "geo" : { },
  "id_str" : "1244534644",
  "in_reply_to_user_id" : 8517622,
  "text" : "@lorXsion F\u00FCr echtes gMail-Push gibt es bislang nur diesen Umweg, der auch nicht wirklich sch\u00F6n ist: http:\/\/bit.ly\/EECM0",
  "id" : 1244534644,
  "in_reply_to_status_id" : 1244513032,
  "created_at" : "2009-02-24 00:00:00 +0000",
  "in_reply_to_screen_name" : "mitZett",
  "in_reply_to_user_id_str" : "8517622",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1244556934",
  "text" : "Fr\u00FCher fand ich Paypal doof. Jetzt beschwere ich mich \u00FCber Anbieter die nur Kreditkarte akzeptieren aber kein Paypal. Ganz web2.0",
  "id" : 1244556934,
  "created_at" : "2009-02-24 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1244794762",
  "text" : "Powernapping rockt!",
  "id" : 1244794762,
  "created_at" : "2009-02-24 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jahwe, dein HERR",
      "screen_name" : "Jahwe",
      "indices" : [ 3, 9 ],
      "id_str" : "19589639",
      "id" : 19589639
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1244842281",
  "text" : "RT @Jahwe: Atheisten nerven. Werde jetzt einen Stein so schwer machen, dass ich ihn nicht heben kann und ihn trotzdem heben. 3\u2026 2\u2026\u00A01\u2026 [...]",
  "id" : 1244842281,
  "created_at" : "2009-02-24 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "cspannagel",
      "screen_name" : "cspannagel",
      "indices" : [ 0, 11 ],
      "id_str" : "578512158",
      "id" : 578512158
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1244889573",
  "text" : "@cspannagel \u201Cich habe ein Update gemacht\u201D umgeht das Problem auch :)",
  "id" : 1244889573,
  "created_at" : "2009-02-24 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1244850941",
  "geo" : { },
  "id_str" : "1244937663",
  "in_reply_to_user_id" : 8517622,
  "text" : "@lorXsion leider nein. Skype auf dem iPhone geht aber nicht in gut.",
  "id" : 1244937663,
  "in_reply_to_status_id" : 1244850941,
  "created_at" : "2009-02-24 00:00:00 +0000",
  "in_reply_to_screen_name" : "mitZett",
  "in_reply_to_user_id_str" : "8517622",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1244959558",
  "geo" : { },
  "id_str" : "1245143793",
  "in_reply_to_user_id" : 8517622,
  "text" : "@lorXsion Vielleicht soll Weltraum auch einfach cool sein? ;)",
  "id" : 1245143793,
  "in_reply_to_status_id" : 1244959558,
  "created_at" : "2009-02-24 00:00:00 +0000",
  "in_reply_to_screen_name" : "mitZett",
  "in_reply_to_user_id_str" : "8517622",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1245275885",
  "text" : "Ich frage mich wo mein USB-Stick schon wieder hin verschwunden ist. Das kommt davon wenn man das Ding nicht am Schl\u00FCsselbund h\u00E4ngen l\u00E4sst",
  "id" : 1245275885,
  "created_at" : "2009-02-24 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Pharyngula",
      "indices" : [ 46, 57 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1245290510",
  "text" : "Don't laugh, this is exactly like creationism #Pharyngula http:\/\/tinyurl.com\/bltulc Grandiose Comics die Myers regelm\u00E4ssig Posted.",
  "id" : 1245290510,
  "created_at" : "2009-02-24 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1245328761",
  "geo" : { },
  "id_str" : "1245338428",
  "in_reply_to_user_id" : 8517622,
  "text" : "@lorXsion Naja die MacOS-Firewall halt ;) Aber zum Stick: Prinzipiell guter Einwand, aber: Meist lagern darauf eh nur unwichtige Daten. Und:",
  "id" : 1245338428,
  "in_reply_to_status_id" : 1245328761,
  "created_at" : "2009-02-24 00:00:00 +0000",
  "in_reply_to_screen_name" : "mitZett",
  "in_reply_to_user_id_str" : "8517622",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1245328761",
  "geo" : { },
  "id_str" : "1245340527",
  "in_reply_to_user_id" : 8517622,
  "text" : "@lorXsion Alles wichtige liegt in einem gut gesichertem Truecrypt-Volume. So wie auf dem Laptop auch.",
  "id" : 1245340527,
  "in_reply_to_status_id" : 1245328761,
  "created_at" : "2009-02-24 00:00:00 +0000",
  "in_reply_to_screen_name" : "mitZett",
  "in_reply_to_user_id_str" : "8517622",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1245364088",
  "text" : "Und kommt es mir nur so vor oder ist das Internet heute ganz allgemein lahm? Bestimmt ist auch daran Google schuld!",
  "id" : 1245364088,
  "created_at" : "2009-02-24 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1246151879",
  "text" : "Wieder da von der Stammesversammlung. Bin nun zum eV-Mitglied gew\u00E4hlt worden. Vor dem Vorstand konnte ich mich nochmal dr\u00FCcken.",
  "id" : 1246151879,
  "created_at" : "2009-02-24 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1246167138",
  "text" : "Ich h\u00E4tte gerne einen Standard f\u00FCr Tags, egal ob mit Leerzeichen oder mit Komma. Nur das hin&her nervt, f\u00FChrt in beiden Versehen zu Monstern",
  "id" : 1246167138,
  "created_at" : "2009-02-24 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Die Stimme NRWs",
      "screen_name" : "DerWesten",
      "indices" : [ 129, 139 ],
      "id_str" : "795545319408881664",
      "id" : 795545319408881664
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1246217531",
  "text" : "Es ist sch\u00F6n zu sehen das es  Menschen gibt die vern\u00FCnftig sind und sich durchsetzen gegen Aberglauben:  http:\/\/bit.ly\/Ql1zE via @DerWesten",
  "id" : 1246217531,
  "created_at" : "2009-02-24 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kickban",
      "indices" : [ 0, 8 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1246849344",
  "text" : "#kickban http:\/\/tinyurl.com\/amll99",
  "id" : 1246849344,
  "created_at" : "2009-02-24 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1240352089",
  "text" : "Da steht man auf und kriegt gleich sowas zu lesen. ProLife-Demo mit Kreuzzug in M\u00FCnster  http:\/\/bit.ly\/jueMY Gibts da auch eine Gegendemo?",
  "id" : 1240352089,
  "created_at" : "2009-02-23 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0627\u0633\u0645\u0631\u0627\u0646\u064A \u0645\u0632\u064A\u0648\u0646",
      "screen_name" : "danishkirel",
      "indices" : [ 0, 12 ],
      "id_str" : "3393171664",
      "id" : 3393171664
    }, {
      "name" : "Houellebeck",
      "screen_name" : "houellebeck",
      "indices" : [ 13, 25 ],
      "id_str" : "107803659",
      "id" : 107803659
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1240503114",
  "text" : "@danishkirel @houellebeck K\u00F6nnen wir gerne veranstalten, egal ob mit oder ohne Kleiderb\u00FCgel.",
  "id" : 1240503114,
  "created_at" : "2009-02-23 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "farbwolke.de",
      "screen_name" : "farbwolke",
      "indices" : [ 0, 10 ],
      "id_str" : "14866082",
      "id" : 14866082
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1240671757",
  "geo" : { },
  "id_str" : "1240675945",
  "in_reply_to_user_id" : 14866082,
  "text" : "@farbwolke Kommt drauf an was es kostet ;)",
  "id" : 1240675945,
  "in_reply_to_status_id" : 1240671757,
  "created_at" : "2009-02-23 00:00:00 +0000",
  "in_reply_to_screen_name" : "farbwolke",
  "in_reply_to_user_id_str" : "14866082",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Markus",
      "screen_name" : "germanstudent",
      "indices" : [ 0, 14 ],
      "id_str" : "2493441",
      "id" : 2493441
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1240698708",
  "in_reply_to_user_id" : 2493441,
  "text" : "@germanstudent http:\/\/twitpic.com\/1ncx9 - Jetzt hab ich wieder genau vor Augen wieso ich Karneval so scheisse finde",
  "id" : 1240698708,
  "created_at" : "2009-02-23 00:00:00 +0000",
  "in_reply_to_screen_name" : "germanstudent",
  "in_reply_to_user_id_str" : "2493441",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1240717138",
  "geo" : { },
  "id_str" : "1240719415",
  "in_reply_to_user_id" : 8517622,
  "text" : "@lorXsion Ja, das kommt davon wenn man sich so Sauf-Feiertage wie Karneval, 1. Mai, Stephanus steinigen und wie sie nicht alle heissen macht",
  "id" : 1240719415,
  "in_reply_to_status_id" : 1240717138,
  "created_at" : "2009-02-23 00:00:00 +0000",
  "in_reply_to_screen_name" : "mitZett",
  "in_reply_to_user_id_str" : "8517622",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1241275361",
  "text" : "Mh geht twtvite gerade nicht? Also wenn ich ein Event erstellen will passiert genau nichts und ich komme wieder zur Startseite.",
  "id" : 1241275361,
  "created_at" : "2009-02-23 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1241308830",
  "text" : "Das D\u00FCmmste was ich seit langem geh\u00F6rt habe: \u201EMama, haben wir noch ein l\u00E4ngeres WLAN-Kabel?!?\u201C",
  "id" : 1241308830,
  "created_at" : "2009-02-23 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1241460745",
  "text" : "Bewerbungsfotos machen ist Mist. Ganz sicher so wenig Traumberuf wie Passbildfotograf.",
  "id" : 1241460745,
  "created_at" : "2009-02-23 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1241729681",
  "text" : "Heute ist ja schon Montag. Nun endg\u00FCltig im stereotypen Semesterferien-Studentendasein angekommen.",
  "id" : 1241729681,
  "created_at" : "2009-02-23 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1241834485",
  "geo" : { },
  "id_str" : "1241860035",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod V\u00F6llig. Muss ich mit Leben.",
  "id" : 1241860035,
  "in_reply_to_status_id" : 1241834485,
  "created_at" : "2009-02-23 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1241902025",
  "geo" : { },
  "id_str" : "1241987279",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod Ach Scham ist nicht so mein Ding.",
  "id" : 1241987279,
  "in_reply_to_status_id" : 1241902025,
  "created_at" : "2009-02-23 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1242058304",
  "text" : "Gestern Nacht kam \u201CTaxi zur H\u00F6lle\u201D auf 3sat. Eine sehr gut gemachte Doku \u00FCber Guantanamo. Online zu sehen unter:  http:\/\/bit.ly\/V4sRU",
  "id" : 1242058304,
  "created_at" : "2009-02-23 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Thomalla",
      "screen_name" : "digicamclub",
      "indices" : [ 0, 12 ],
      "id_str" : "126312409",
      "id" : 126312409
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1242103087",
  "geo" : { },
  "id_str" : "1242107308",
  "in_reply_to_user_id" : 15352789,
  "text" : "@digicamclub Ich habs mit Toodledo gemacht.",
  "id" : 1242107308,
  "in_reply_to_status_id" : 1242103087,
  "created_at" : "2009-02-23 00:00:00 +0000",
  "in_reply_to_screen_name" : "marcthomalla",
  "in_reply_to_user_id_str" : "15352789",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1242111397",
  "geo" : { },
  "id_str" : "1242115698",
  "in_reply_to_user_id" : 17904767,
  "text" : "@Causa_Motiva Gibts auch in der ZDF-Mediathek. Google hilft :)",
  "id" : 1242115698,
  "in_reply_to_status_id" : 1242111397,
  "created_at" : "2009-02-23 00:00:00 +0000",
  "in_reply_to_screen_name" : "SteterTropfen",
  "in_reply_to_user_id_str" : "17904767",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1242132731",
  "geo" : { },
  "id_str" : "1242142570",
  "in_reply_to_user_id" : 17904767,
  "text" : "@Causa_Motiva Bin ja nicht so:  http:\/\/bit.ly\/fB2l7",
  "id" : 1242142570,
  "in_reply_to_status_id" : 1242132731,
  "created_at" : "2009-02-23 00:00:00 +0000",
  "in_reply_to_screen_name" : "SteterTropfen",
  "in_reply_to_user_id_str" : "17904767",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1242156941",
  "text" : "Mittlerweile wird mir schon von der Werbung f\u00FCr \u201CGalileo Mystery\u201D schlecht. Galileo w\u00FCrde sich im Grabe drehen.",
  "id" : 1242156941,
  "created_at" : "2009-02-23 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hannes",
      "screen_name" : "ht82",
      "indices" : [ 67, 72 ],
      "id_str" : "5457652",
      "id" : 5457652
    }, {
      "name" : "Ferdinand Walch",
      "screen_name" : "xstream",
      "indices" : [ 119, 127 ],
      "id_str" : "430485726",
      "id" : 430485726
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1242252710",
  "text" : "Genau dar\u00FCber hatten wir doch bei der pl0gbar nachgedacht oder? RT @ht82 : Sehr sehr cool http:\/\/computertan.com\/ (via @xstream )",
  "id" : 1242252710,
  "created_at" : "2009-02-23 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cohenbrothers",
      "indices" : [ 76, 90 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1238091865",
  "text" : "@njeppo Ich fand Burn After Reading gegen Ende sehr schwach muss ich sagen. #cohenbrothers",
  "id" : 1238091865,
  "created_at" : "2009-02-22 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Figueroa",
      "screen_name" : "unimatrixZxero",
      "indices" : [ 0, 15 ],
      "id_str" : "645353",
      "id" : 645353
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1238122688",
  "geo" : { },
  "id_str" : "1238126556",
  "in_reply_to_user_id" : 645353,
  "text" : "@unimatrixZxero Spam in Sinne von neuen Followeren mit 0 Updates und Werbe-URLs.",
  "id" : 1238126556,
  "in_reply_to_status_id" : 1238122688,
  "created_at" : "2009-02-22 00:00:00 +0000",
  "in_reply_to_screen_name" : "unimatrixZxero",
  "in_reply_to_user_id_str" : "645353",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1238127477",
  "text" : "@njeppo Nimmt sich nicht erst ja. Trotzdem mau meiner Meinung nach.",
  "id" : 1238127477,
  "created_at" : "2009-02-22 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1238142151",
  "text" : "So jetzt wo ihr fertig seid mit dem Tatort: Gleich kommt wieder Lewis im ZDF. Guter Krimi schl\u00E4gt schlechte deutsche Produktion.",
  "id" : 1238142151,
  "created_at" : "2009-02-22 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1238144249",
  "text" : "Mein Pinguin-Travelbug befindet sich mittlerweile in New South Wales, Australia. Ob er den Sprung zum S\u00FCdpol schafft?",
  "id" : 1238144249,
  "created_at" : "2009-02-22 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Herr Rensch",
      "screen_name" : "arensch",
      "indices" : [ 0, 8 ],
      "id_str" : "14725887",
      "id" : 14725887
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1238159913",
  "geo" : { },
  "id_str" : "1238166605",
  "in_reply_to_user_id" : 14725887,
  "text" : "@arensch Na dann gibt es f\u00FCr den kleinen ja noch Hoffnung :)",
  "id" : 1238166605,
  "in_reply_to_status_id" : 1238159913,
  "created_at" : "2009-02-22 00:00:00 +0000",
  "in_reply_to_screen_name" : "arensch",
  "in_reply_to_user_id_str" : "14725887",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1236914789",
  "text" : "Verdammt in Greven ist heute Karnevals-Umzug",
  "id" : 1236914789,
  "created_at" : "2009-02-22 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1236945473",
  "text" : "Jetzt erstmal weiter Fotos bearbeiten.",
  "id" : 1236945473,
  "created_at" : "2009-02-22 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1237013148",
  "text" : "eMails backupen. Gro\u00DFartige Besch\u00E4ftigung.",
  "id" : 1237013148,
  "created_at" : "2009-02-22 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1237052283",
  "text" : "So gewinnen manche Leute schnell neuen Speicherplatz: Feststellen das man unter Windows nicht alles auf dem Desktop legen sollte...",
  "id" : 1237052283,
  "created_at" : "2009-02-22 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1237226802",
  "text" : "Langsam k\u00F6nnte mir Cyberport mal Provision f\u00FCr vermittelte Rechner bewilligen.",
  "id" : 1237226802,
  "created_at" : "2009-02-22 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1237362636",
  "text" : "Hund hat so eben Schwimmen gelernt. Sehr knuffiger Anblick",
  "id" : 1237362636,
  "created_at" : "2009-02-22 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helmuth Ringhandt",
      "screen_name" : "iKieler",
      "indices" : [ 0, 8 ],
      "id_str" : "18356871",
      "id" : 18356871
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1237371730",
  "geo" : { },
  "id_str" : "1237374431",
  "in_reply_to_user_id" : 18123358,
  "text" : "@iKieler Leider nicht, war zu sehr damit besch\u00E4ftigt zu schauen das er sich im Wasser nicht mit der Schleppleine verheddert.",
  "id" : 1237374431,
  "in_reply_to_status_id" : 1237371730,
  "created_at" : "2009-02-22 00:00:00 +0000",
  "in_reply_to_screen_name" : "ringhandt",
  "in_reply_to_user_id_str" : "18123358",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grupetto.nl",
      "screen_name" : "Grupetto",
      "indices" : [ 0, 9 ],
      "id_str" : "202685746",
      "id" : 202685746
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1237376827",
  "geo" : { },
  "id_str" : "1237379361",
  "in_reply_to_user_id" : 15182376,
  "text" : "@grupetto Schauen wir mal was die im Freibad dazu sagen wenn wir zum Schwimmunterricht kommen ;)",
  "id" : 1237379361,
  "in_reply_to_status_id" : 1237376827,
  "created_at" : "2009-02-22 00:00:00 +0000",
  "in_reply_to_screen_name" : "_catenaccio",
  "in_reply_to_user_id_str" : "15182376",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helmuth Ringhandt",
      "screen_name" : "iKieler",
      "indices" : [ 0, 8 ],
      "id_str" : "18356871",
      "id" : 18356871
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Tweetie",
      "indices" : [ 116, 124 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1237398546",
  "geo" : { },
  "id_str" : "1237401806",
  "in_reply_to_user_id" : 18123358,
  "text" : "@iKieler Ich glaube das gibt es auf dem iPhone leider gar nicht. Hatte ich mich auch schon dumm und d\u00E4mlich gesucht #Tweetie",
  "id" : 1237401806,
  "in_reply_to_status_id" : 1237398546,
  "created_at" : "2009-02-22 00:00:00 +0000",
  "in_reply_to_screen_name" : "ringhandt",
  "in_reply_to_user_id_str" : "18123358",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1237416885",
  "geo" : { },
  "id_str" : "1237420606",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod Es hat gar nichts damit zu tun. Das Grad-Zeichen existiert einfach allgemein nicht auf der Apple-Tastatur des iPhones.",
  "id" : 1237420606,
  "in_reply_to_status_id" : 1237416885,
  "created_at" : "2009-02-22 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1237963782",
  "text" : "Schaue jetzt fern. Ganz ohne \u00FCber den Inhalt zu twittern.",
  "id" : 1237963782,
  "created_at" : "2009-02-22 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "oscar",
      "indices" : [ 33, 39 ]
    }, {
      "text" : "tatort",
      "indices" : [ 40, 47 ]
    }, {
      "text" : "echo",
      "indices" : [ 48, 53 ]
    }, {
      "text" : "dsds",
      "indices" : [ 54, 59 ]
    }, {
      "text" : "gntm",
      "indices" : [ 60, 65 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1237980017",
  "geo" : { },
  "id_str" : "1237983477",
  "in_reply_to_user_id" : 8517622,
  "text" : "@lorXsion Ne, Pol der Ruhe neben #oscar #tatort #echo #dsds #gntm und wie sie nicht alle heissen :)",
  "id" : 1237983477,
  "in_reply_to_status_id" : 1237980017,
  "created_at" : "2009-02-22 00:00:00 +0000",
  "in_reply_to_screen_name" : "mitZett",
  "in_reply_to_user_id_str" : "8517622",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1238007409",
  "geo" : { },
  "id_str" : "1238009257",
  "in_reply_to_user_id" : 8517622,
  "text" : "@lorXsion Germanys Next TopModel ;)",
  "id" : 1238009257,
  "in_reply_to_status_id" : 1238007409,
  "created_at" : "2009-02-22 00:00:00 +0000",
  "in_reply_to_screen_name" : "mitZett",
  "in_reply_to_user_id_str" : "8517622",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1238018029",
  "geo" : { },
  "id_str" : "1238020588",
  "in_reply_to_user_id" : 8517622,
  "text" : "@lorXsion Offensichtlich, zumindest stolper ich ab und zu mal wieder \u00FCber das Tag.",
  "id" : 1238020588,
  "in_reply_to_status_id" : 1238018029,
  "created_at" : "2009-02-22 00:00:00 +0000",
  "in_reply_to_screen_name" : "mitZett",
  "in_reply_to_user_id_str" : "8517622",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1238090913",
  "text" : "Was ist denn heute mit den Spammern los. Twitterspam deluxe.",
  "id" : 1238090913,
  "created_at" : "2009-02-22 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1233816582",
  "text" : "Heute wird auf jedenfall mal wieder Fotografiert. Wird ja auch Zeit.",
  "id" : 1233816582,
  "created_at" : "2009-02-21 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1233935274",
  "text" : "Immobilienseiten und Stellenm\u00E4rkte sind online irgendwie immer noch unbenutzbar. Wer macht da das \u201CDesign\u201D? Niemand?",
  "id" : 1233935274,
  "created_at" : "2009-02-21 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rozana Renger",
      "screen_name" : "Rozana",
      "indices" : [ 0, 7 ],
      "id_str" : "6085542",
      "id" : 6085542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1233958333",
  "geo" : { },
  "id_str" : "1234063331",
  "in_reply_to_user_id" : 6085542,
  "text" : "@Rozana Gute Entscheidung, B\u00E4rte sind der Hit :)",
  "id" : 1234063331,
  "in_reply_to_status_id" : 1233958333,
  "created_at" : "2009-02-21 00:00:00 +0000",
  "in_reply_to_screen_name" : "Rozana",
  "in_reply_to_user_id_str" : "6085542",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1234102220",
  "text" : "Zeit das Kamerazeug zu packen.",
  "id" : 1234102220,
  "created_at" : "2009-02-21 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stefan",
      "screen_name" : "stelten",
      "indices" : [ 0, 8 ],
      "id_str" : "14082615",
      "id" : 14082615
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1234155634",
  "geo" : { },
  "id_str" : "1234161323",
  "in_reply_to_user_id" : 14082615,
  "text" : "@stelten Ich hab das neue Skype unter Windows auch schon benutzt. Ich find es um einiges schlechter weil total \u00FCberladen auf einmal.",
  "id" : 1234161323,
  "in_reply_to_status_id" : 1234155634,
  "created_at" : "2009-02-21 00:00:00 +0000",
  "in_reply_to_screen_name" : "stelten",
  "in_reply_to_user_id_str" : "14082615",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stefan",
      "screen_name" : "stelten",
      "indices" : [ 0, 8 ],
      "id_str" : "14082615",
      "id" : 14082615
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "skype",
      "indices" : [ 123, 129 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1234166502",
  "geo" : { },
  "id_str" : "1234169486",
  "in_reply_to_user_id" : 14082615,
  "text" : "@stelten Vor allem sind die Grundeinstellungen irgendwie schon fucked up. Dazu gef\u00E4llt mir das Vista-Design nicht wirklich #skype",
  "id" : 1234169486,
  "in_reply_to_status_id" : 1234166502,
  "created_at" : "2009-02-21 00:00:00 +0000",
  "in_reply_to_screen_name" : "stelten",
  "in_reply_to_user_id_str" : "14082615",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1234642089",
  "text" : "Jetzt noch einkaufen zu gehen war dumm.",
  "id" : 1234642089,
  "created_at" : "2009-02-21 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1234680520",
  "geo" : { },
  "id_str" : "1234762543",
  "in_reply_to_user_id" : 8517622,
  "text" : "@lorXsion nicht nur. Auch das Junge Volk :)",
  "id" : 1234762543,
  "in_reply_to_status_id" : 1234680520,
  "created_at" : "2009-02-21 00:00:00 +0000",
  "in_reply_to_screen_name" : "mitZett",
  "in_reply_to_user_id_str" : "8517622",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1234794326",
  "text" : "\u201EKrabbelgottesdienst\u201C?!F\u00FCr Babies&Kleinkinder.Genau das geh\u00F6rt Verboten.Wir schicken sie auch nicht zum Parteitag.  http:\/\/twitpic.com\/1m1sy",
  "id" : 1234794326,
  "created_at" : "2009-02-21 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1234805086",
  "geo" : { },
  "id_str" : "1234823926",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod solange die nicht w\u00E4hlen d\u00FCrfen ists f\u00FCr Parteien uninteressant.",
  "id" : 1234823926,
  "in_reply_to_status_id" : 1234805086,
  "created_at" : "2009-02-21 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Markus",
      "screen_name" : "germanstudent",
      "indices" : [ 0, 14 ],
      "id_str" : "2493441",
      "id" : 2493441
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1234849039",
  "geo" : { },
  "id_str" : "1234866067",
  "in_reply_to_user_id" : 2493441,
  "text" : "@germanstudent Und nein - Du kannst Twitter noch nicht Heiraten. :)",
  "id" : 1234866067,
  "in_reply_to_status_id" : 1234849039,
  "created_at" : "2009-02-21 00:00:00 +0000",
  "in_reply_to_screen_name" : "germanstudent",
  "in_reply_to_user_id_str" : "2493441",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1234893925",
  "text" : "Heut nachmittag fleissig geknippst und gerade schonmal durchgeschaut. Sehr sch\u00F6ne Fotos dabei.",
  "id" : 1234893925,
  "created_at" : "2009-02-21 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Houellebeck",
      "screen_name" : "houellebeck",
      "indices" : [ 0, 12 ],
      "id_str" : "107803659",
      "id" : 107803659
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1230105261",
  "text" : "@houellebeck das stimmt. Nur das Treibergefrickel dauert auch auf aktuellen Rechnern...",
  "id" : 1230105261,
  "created_at" : "2009-02-20 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1229954470",
  "geo" : { },
  "id_str" : "1230106504",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod Naja f\u00FCr ganz besonders nette Menschen ist ok. Oder f\u00FCr gute Bezahlung :)",
  "id" : 1230106504,
  "in_reply_to_status_id" : 1229954470,
  "created_at" : "2009-02-20 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1227752915",
  "geo" : { },
  "id_str" : "1230107395",
  "in_reply_to_user_id" : 8517622,
  "text" : "@lorXsion und schon absolut begeistert von dem Spielzeug? :)",
  "id" : 1230107395,
  "in_reply_to_status_id" : 1227752915,
  "created_at" : "2009-02-20 00:00:00 +0000",
  "in_reply_to_screen_name" : "mitZett",
  "in_reply_to_user_id_str" : "8517622",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Benjamin Claverie",
      "screen_name" : "Skl8em",
      "indices" : [ 0, 7 ],
      "id_str" : "13823092",
      "id" : 13823092
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1230154139",
  "in_reply_to_user_id" : 13823092,
  "text" : "@skl8em hatte v\u00F6llig recht, http:\/\/www.thewebsiteisdown.com\/ ist der Hammer :)",
  "id" : 1230154139,
  "created_at" : "2009-02-20 00:00:00 +0000",
  "in_reply_to_screen_name" : "Skl8em",
  "in_reply_to_user_id_str" : "13823092",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Fail",
      "indices" : [ 42, 47 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1230159184",
  "geo" : { },
  "id_str" : "1230161773",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod Ja, die Version bei YouTube auch. #Fail",
  "id" : 1230161773,
  "in_reply_to_status_id" : 1230159184,
  "created_at" : "2009-02-20 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1230212137",
  "text" : "Ich schau mir gerade mal den Uhrenkatalog von Tokyoflash in gro\u00DF an :)",
  "id" : 1230212137,
  "created_at" : "2009-02-20 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1230216899",
  "geo" : { },
  "id_str" : "1230233163",
  "in_reply_to_user_id" : 8517622,
  "text" : "@lorXsion Damit ist die Familie wohl erstmal abgeschrieben? :)",
  "id" : 1230233163,
  "in_reply_to_status_id" : 1230216899,
  "created_at" : "2009-02-20 00:00:00 +0000",
  "in_reply_to_screen_name" : "mitZett",
  "in_reply_to_user_id_str" : "8517622",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1230414828",
  "text" : "Missbrauche Python als Taschenrechner. Funktioniert aber tadellos.",
  "id" : 1230414828,
  "created_at" : "2009-02-20 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1230439444",
  "text" : "Oh man, SpOn mal wieder \u00FCber den Journalismus. Vielleicht w\u00FCrde sich Qualit\u00E4t und echter Journalismus besser machen?  http:\/\/bit.ly\/E3wod",
  "id" : 1230439444,
  "created_at" : "2009-02-20 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1230500157",
  "text" : "Angst essen Verstand auf. Was ist mit Feng-Shui und b\u00F6sen Wasseradern unter der Wohnung. Oder der Indianerfriedhof? http:\/\/bit.ly\/GByAh",
  "id" : 1230500157,
  "created_at" : "2009-02-20 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1230611031",
  "text" : "Langsam \u00FCberlege ich ob ich nicht doch mehr Gmail verwenden sollte.",
  "id" : 1230611031,
  "created_at" : "2009-02-20 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1230866748",
  "text" : "Teste gerade Busysynch",
  "id" : 1230866748,
  "created_at" : "2009-02-20 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1230868388",
  "text" : "Oh, ohne das \u201Ch\u201D am Ende. Abgleich iCal mit gCal.",
  "id" : 1230868388,
  "created_at" : "2009-02-20 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1230890975",
  "text" : "Cool, meine ganzen Kalender sind schonmal bei Google gelandet, dann gleich mal gSync ausprobieren um die Kalender aufs iPhone zu kriegen.",
  "id" : 1230890975,
  "created_at" : "2009-02-20 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Houellebeck",
      "screen_name" : "houellebeck",
      "indices" : [ 3, 15 ],
      "id_str" : "107803659",
      "id" : 107803659
    }, {
      "name" : "Stefan",
      "screen_name" : "stelten",
      "indices" : [ 71, 79 ],
      "id_str" : "14082615",
      "id" : 14082615
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 82, 98 ],
      "id_str" : "14286491",
      "id" : 14286491
    }, {
      "name" : "raiza bermudez",
      "screen_name" : "eiker",
      "indices" : [ 101, 107 ],
      "id_str" : "348748293",
      "id" : 348748293
    }, {
      "name" : "Martin Labuschin",
      "screen_name" : "Labuschin",
      "indices" : [ 110, 120 ],
      "id_str" : "1024351",
      "id" : 1024351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1230906127",
  "text" : "RT @houellebeck: ...erlaubt sich einzuladen: http:\/\/twtvite.com\/qrpspg @stelten , @gedankenstuecke , @eiker , @labuschin - please RT",
  "id" : 1230906127,
  "created_at" : "2009-02-20 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1230911020",
  "text" : "Wenn ich das MacOS-Adressbuch mit Google synchronisiere kommen die Kontaktbilder bei Google nicht an. Gibts da einen Fix?",
  "id" : 1230911020,
  "created_at" : "2009-02-20 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1230993143",
  "text" : "Cool, habe nun meine Kalender komplett OTA synchron mit gSync zwischen gCal & iPhone und zwischen Mac & gCal per busySync",
  "id" : 1230993143,
  "created_at" : "2009-02-20 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1231038755",
  "text" : "Das synchen der Kontakte ist \u00FCber Google ist leider Mist, zumindest ohne Zusatztools. Dann lieber nicht OTA sondern per iTunes.",
  "id" : 1231038755,
  "created_at" : "2009-02-20 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gunnar Lott",
      "screen_name" : "HerrKaliban",
      "indices" : [ 0, 12 ],
      "id_str" : "16945253",
      "id" : 16945253
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "letzterettung",
      "indices" : [ 75, 89 ]
    }, {
      "text" : "pennerlook",
      "indices" : [ 90, 101 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1231196166",
  "geo" : { },
  "id_str" : "1231220154",
  "in_reply_to_user_id" : 16945253,
  "text" : "@HerrKaliban Rasieren und Haare waschen, dann klappts auch mit dem Job! ;) #letzterettung #pennerlook #",
  "id" : 1231220154,
  "in_reply_to_status_id" : 1231196166,
  "created_at" : "2009-02-20 00:00:00 +0000",
  "in_reply_to_screen_name" : "HerrKaliban",
  "in_reply_to_user_id_str" : "16945253",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1230293453",
  "geo" : { },
  "id_str" : "1231555041",
  "in_reply_to_user_id" : 8517622,
  "text" : "@lorXsion vergessen worden?",
  "id" : 1231555041,
  "in_reply_to_status_id" : 1230293453,
  "created_at" : "2009-02-20 00:00:00 +0000",
  "in_reply_to_screen_name" : "mitZett",
  "in_reply_to_user_id_str" : "8517622",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1231688385",
  "geo" : { },
  "id_str" : "1231705164",
  "in_reply_to_user_id" : 8517622,
  "text" : "@lorXsion Ich w\u00FCrde ja auf vergessen tippen :)",
  "id" : 1231705164,
  "in_reply_to_status_id" : 1231688385,
  "created_at" : "2009-02-20 00:00:00 +0000",
  "in_reply_to_screen_name" : "mitZett",
  "in_reply_to_user_id_str" : "8517622",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1231728041",
  "geo" : { },
  "id_str" : "1231757565",
  "in_reply_to_user_id" : 8517622,
  "text" : "@lorXsion Schade, dann aber beim n\u00E4chsten Tweetup oder pl0gbar :)",
  "id" : 1231757565,
  "in_reply_to_status_id" : 1231728041,
  "created_at" : "2009-02-20 00:00:00 +0000",
  "in_reply_to_screen_name" : "mitZett",
  "in_reply_to_user_id_str" : "8517622",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Benjamin Claverie",
      "screen_name" : "Skl8em",
      "indices" : [ 58, 65 ],
      "id_str" : "13823092",
      "id" : 13823092
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1232129354",
  "text" : "Sehr sehr coole Uhren. Auch f\u00FCr den Tipp nochmal danke an @skl8em :) http:\/\/tinyurl.com\/c7wokd",
  "id" : 1232129354,
  "created_at" : "2009-02-20 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1229899085",
  "text" : "Ich Liebe es Support zu spielen. Vor allem frische Windowsinstallationen... http:\/\/twitpic.com\/1kzyy",
  "id" : 1229899085,
  "created_at" : "2009-02-20 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1229994858",
  "text" : "Installationen sind Mist. Werde nur noch Macs betreuen.  - http:\/\/bkite.com\/04NoA",
  "id" : 1229994858,
  "created_at" : "2009-02-20 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1226006938",
  "text" : "Wieso drehen eigentlich so viele Wissenschaftler auf ihre alten Tage v\u00F6llig am Rad?",
  "id" : 1226006938,
  "created_at" : "2009-02-19 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304F\u308D\u3068\u3089",
      "screen_name" : "chikatze",
      "indices" : [ 0, 9 ],
      "id_str" : "2911368630",
      "id" : 2911368630
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1226013478",
  "geo" : { },
  "id_str" : "1226027562",
  "in_reply_to_user_id" : 14165822,
  "text" : "@Chikatze Ganz und gar nicht. Aber viele scheinen im Alter die Grundlagen zu vergessen...",
  "id" : 1226027562,
  "in_reply_to_status_id" : 1226013478,
  "created_at" : "2009-02-19 00:00:00 +0000",
  "in_reply_to_screen_name" : "Frau_Chikatze",
  "in_reply_to_user_id_str" : "14165822",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexander Endl",
      "screen_name" : "zielpublikum",
      "indices" : [ 0, 13 ],
      "id_str" : "14711791",
      "id" : 14711791
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1226053588",
  "geo" : { },
  "id_str" : "1226134964",
  "in_reply_to_user_id" : 14711791,
  "text" : "@zielpublikum AIDS leugnen, Okkultismus, Rassismus. Alles nichts was ich als die Erleuchtung kennzeichnen w\u00FCrde.",
  "id" : 1226134964,
  "in_reply_to_status_id" : 1226053588,
  "created_at" : "2009-02-19 00:00:00 +0000",
  "in_reply_to_screen_name" : "zielpublikum",
  "in_reply_to_user_id_str" : "14711791",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1226142489",
  "text" : "Gro\u00DFer Vorteil wenn man vormittags seine Runde durch den Wald dreht: Man hat ihn f\u00FCr sich alleine und seine Ruhe",
  "id" : 1226142489,
  "created_at" : "2009-02-19 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1226207678",
  "text" : "Ich glaube ich hab meine EC-Karte gerade gel\u00F6scht. Karten-Etui zusammen mit Notizbuch mit Magnetverschluss in einer Hosentasche...",
  "id" : 1226207678,
  "created_at" : "2009-02-19 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "pl0gbar",
      "indices" : [ 53, 61 ]
    }, {
      "text" : "muenster",
      "indices" : [ 62, 71 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1226320077",
  "text" : "Die pl0gbar heute Abend ist aber Karnevalsfrei oder? #pl0gbar #muenster",
  "id" : 1226320077,
  "created_at" : "2009-02-19 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Monika Meurer",
      "screen_name" : "SoIsses",
      "indices" : [ 0, 8 ],
      "id_str" : "16408543",
      "id" : 16408543
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1226322603",
  "geo" : { },
  "id_str" : "1226324762",
  "in_reply_to_user_id" : 16408543,
  "text" : "@SoIsses Schon seit Jahren. Wenn hier der Umzug ist verstecke ich mich jedes Jahr mit Freunden im Keller und warte das es vorbei ist.",
  "id" : 1226324762,
  "in_reply_to_status_id" : 1226322603,
  "created_at" : "2009-02-19 00:00:00 +0000",
  "in_reply_to_screen_name" : "SoIsses",
  "in_reply_to_user_id_str" : "16408543",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dominik",
      "screen_name" : "p9y",
      "indices" : [ 3, 7 ],
      "id_str" : "18424055",
      "id" : 18424055
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1226347161",
  "text" : "RT @p9y: Klaus erkl\u00E4rt Tom Cruise \/ Scientology. Lustiges f\u00FCr Zwischendurch: http:\/\/tinyurl.com\/daztnf",
  "id" : 1226347161,
  "created_at" : "2009-02-19 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1226352335",
  "geo" : { },
  "id_str" : "1226397608",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod ist mir auch erst aufgefallen als ich das Buch gerade aus der Tasche gezogen habe. Werd dann gleich mal zur Bank gehen.",
  "id" : 1226397608,
  "in_reply_to_status_id" : 1226352335,
  "created_at" : "2009-02-19 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1226437724",
  "geo" : { },
  "id_str" : "1226510247",
  "in_reply_to_user_id" : 8517622,
  "text" : "@lorXsion Ich hab so ein paperblanks zum Geburtstag bekommen was ich zu den Moleskines dazu benutze. Und das hat den fiesen Magnetverschluss",
  "id" : 1226510247,
  "in_reply_to_status_id" : 1226437724,
  "created_at" : "2009-02-19 00:00:00 +0000",
  "in_reply_to_screen_name" : "mitZett",
  "in_reply_to_user_id_str" : "8517622",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1226512090",
  "text" : "Also am Bankautomaten kann ich noch Geld ziehen. Die Frage ist ob das da nur \u00FCber den Chip geht oder ob der Magnetstreifen ben\u00F6tigt wird.",
  "id" : 1226512090,
  "created_at" : "2009-02-19 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1226437724",
  "geo" : { },
  "id_str" : "1226529076",
  "in_reply_to_user_id" : 8517622,
  "text" : "@lorXsion Jau, ich bin dabei.",
  "id" : 1226529076,
  "in_reply_to_status_id" : 1226437724,
  "created_at" : "2009-02-19 00:00:00 +0000",
  "in_reply_to_screen_name" : "mitZett",
  "in_reply_to_user_id_str" : "8517622",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "The_Smoking_GNU",
      "indices" : [ 0, 16 ],
      "id_str" : "14535787",
      "id" : 14535787
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1226680186",
  "geo" : { },
  "id_str" : "1226866903",
  "in_reply_to_user_id" : 14535787,
  "text" : "@The_Smoking_GNU Danke f\u00FCr den Hinweis, dann hab ich ja Gl\u00FCck gehabt mit der Magnet-Karten-Kombination :)",
  "id" : 1226866903,
  "in_reply_to_status_id" : 1226680186,
  "created_at" : "2009-02-19 00:00:00 +0000",
  "in_reply_to_screen_name" : "The_Smoking_GNU",
  "in_reply_to_user_id_str" : "14535787",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexander Endl",
      "screen_name" : "zielpublikum",
      "indices" : [ 0, 13 ],
      "id_str" : "14711791",
      "id" : 14711791
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1226916338",
  "geo" : { },
  "id_str" : "1226921538",
  "in_reply_to_user_id" : 14711791,
  "text" : "@zielpublikum Da hast du recht, aber die F\u00E4lle zeigen schon das es wirklich durchgeknallte Typen gibt, leider unter den Erfolgreichen",
  "id" : 1226921538,
  "in_reply_to_status_id" : 1226916338,
  "created_at" : "2009-02-19 00:00:00 +0000",
  "in_reply_to_screen_name" : "zielpublikum",
  "in_reply_to_user_id_str" : "14711791",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1227224850",
  "text" : "Meine G\u00FCte ist das ein Schneegest\u00F6ber drau\u00DFen. Gut das ich nur 3 Fussminuten bis zur pl0gbar habe.",
  "id" : 1227224850,
  "created_at" : "2009-02-19 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Benjamin Claverie",
      "screen_name" : "Skl8em",
      "indices" : [ 0, 7 ],
      "id_str" : "13823092",
      "id" : 13823092
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1227248980",
  "geo" : { },
  "id_str" : "1227257283",
  "in_reply_to_user_id" : 13823092,
  "text" : "@Skl8em Ja, neben dem Borchert-Theater, Querstra\u00DFe zum Hafenweg wo das Pier House ist.",
  "id" : 1227257283,
  "in_reply_to_status_id" : 1227248980,
  "created_at" : "2009-02-19 00:00:00 +0000",
  "in_reply_to_screen_name" : "Skl8em",
  "in_reply_to_user_id_str" : "13823092",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1227567839",
  "text" : "So, jetzt mach ich mich langsam auch mal auf den Weg zur pl0gbar. Aber immer mit der Ruhe. :)",
  "id" : 1227567839,
  "created_at" : "2009-02-19 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1227621165",
  "text" : "pl0gbar - http:\/\/bkite.com\/04MaD",
  "id" : 1227621165,
  "created_at" : "2009-02-19 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1227752915",
  "geo" : { },
  "id_str" : "1227810278",
  "in_reply_to_user_id" : 8517622,
  "text" : "@lorXsion na dann viel Spa\u00DF damit. Du wirst es sicher nicht bereuen.",
  "id" : 1227810278,
  "in_reply_to_status_id" : 1227752915,
  "created_at" : "2009-02-19 00:00:00 +0000",
  "in_reply_to_screen_name" : "mitZett",
  "in_reply_to_user_id_str" : "8517622",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1222186784",
  "text" : "Ich lausche weiter der TPB-Verhandlung",
  "id" : 1222186784,
  "created_at" : "2009-02-18 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Houellebeck",
      "screen_name" : "houellebeck",
      "indices" : [ 0, 12 ],
      "id_str" : "107803659",
      "id" : 107803659
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1222225508",
  "text" : "@houellebeck Ich hab deren Newsletter nun auch abonniert damit ich morgens was zum auslachen hab.",
  "id" : 1222225508,
  "created_at" : "2009-02-18 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Houellebeck",
      "screen_name" : "houellebeck",
      "indices" : [ 0, 12 ],
      "id_str" : "107803659",
      "id" : 107803659
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1222238066",
  "text" : "@houellebeck Auf Basic machen und ein Twitter-Interview veranstalten? :D",
  "id" : 1222238066,
  "created_at" : "2009-02-18 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1222309653",
  "text" : "Sch\u00F6n zu sehen das es noch konsequente Menschen gibt. Hier die Zoologen vs. Louisiana: http:\/\/tinyurl.com\/aokawc",
  "id" : 1222309653,
  "created_at" : "2009-02-18 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Markus",
      "screen_name" : "germanstudent",
      "indices" : [ 0, 14 ],
      "id_str" : "2493441",
      "id" : 2493441
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1222311523",
  "geo" : { },
  "id_str" : "1222315565",
  "in_reply_to_user_id" : 2493441,
  "text" : "@germanstudent Fr\u00FCher stand an dem Spielplatz eine Eisenbahn. Auf der hab ich als Kind rumgetobt. Aber ist wohl nicht mehr modern genug :P",
  "id" : 1222315565,
  "in_reply_to_status_id" : 1222311523,
  "created_at" : "2009-02-18 00:00:00 +0000",
  "in_reply_to_screen_name" : "germanstudent",
  "in_reply_to_user_id_str" : "2493441",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1222495579",
  "text" : "Ich kenne da jemanden der heute Geburtstag hat und den ich nun deshalb mal besuchen werde.",
  "id" : 1222495579,
  "created_at" : "2009-02-18 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Houellebeck",
      "screen_name" : "houellebeck",
      "indices" : [ 0, 12 ],
      "id_str" : "107803659",
      "id" : 107803659
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1222669797",
  "text" : "@houellebeck Ist doch fast das Gleiche!",
  "id" : 1222669797,
  "created_at" : "2009-02-18 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1222906155",
  "text" : "Jetzt hat der Hund ein Pikachu-Stofftier zum spielen. Er wird es zerst\u00F6ren, den b\u00F6sen Konsum.",
  "id" : 1222906155,
  "created_at" : "2009-02-18 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1222964687",
  "text" : "Waldzeit!",
  "id" : 1222964687,
  "created_at" : "2009-02-18 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Markus",
      "screen_name" : "germanstudent",
      "indices" : [ 0, 14 ],
      "id_str" : "2493441",
      "id" : 2493441
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1223005601",
  "geo" : { },
  "id_str" : "1223141574",
  "in_reply_to_user_id" : 2493441,
  "text" : "@germanstudent Onkel Willy ist der coolste, ich h\u00F6re dem auch jedesmal wieder gerne zu  http:\/\/bit.ly\/yHbcg",
  "id" : 1223141574,
  "in_reply_to_status_id" : 1223005601,
  "created_at" : "2009-02-18 00:00:00 +0000",
  "in_reply_to_screen_name" : "germanstudent",
  "in_reply_to_user_id_str" : "2493441",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grupetto.nl",
      "screen_name" : "Grupetto",
      "indices" : [ 0, 9 ],
      "id_str" : "202685746",
      "id" : 202685746
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1223163776",
  "geo" : { },
  "id_str" : "1223176447",
  "in_reply_to_user_id" : 15182376,
  "text" : "@grupetto So hab ich ihn noch nie erlebt. Im Gegenteil, bislang hab ich nur mitbekommen das er sehr freundlich und nett zu den Menschen war.",
  "id" : 1223176447,
  "in_reply_to_status_id" : 1223163776,
  "created_at" : "2009-02-18 00:00:00 +0000",
  "in_reply_to_screen_name" : "_catenaccio",
  "in_reply_to_user_id_str" : "15182376",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grupetto.nl",
      "screen_name" : "Grupetto",
      "indices" : [ 0, 9 ],
      "id_str" : "202685746",
      "id" : 202685746
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1223182245",
  "geo" : { },
  "id_str" : "1223187960",
  "in_reply_to_user_id" : 15182376,
  "text" : "@grupetto Trotzdem schade wenn so jemand sich so gehen l\u00E4sst. Musikalisch hat der es meiner Meinung nach \u00FCbrigens auch wirklich drauf.",
  "id" : 1223187960,
  "in_reply_to_status_id" : 1223182245,
  "created_at" : "2009-02-18 00:00:00 +0000",
  "in_reply_to_screen_name" : "_catenaccio",
  "in_reply_to_user_id_str" : "15182376",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1223863246",
  "text" : "Los zur Sommerlagerplanung der Pfadfinder",
  "id" : 1223863246,
  "created_at" : "2009-02-18 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1224214094",
  "text" : "Themenlager zu Ninjas und Piraten hat keine Mehrheit bekommen. Seltsam.",
  "id" : 1224214094,
  "created_at" : "2009-02-18 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1224282529",
  "text" : "@njeppo Ne, wir gehen nun mit Wikingern. Ist auch ganz cool :)",
  "id" : 1224282529,
  "created_at" : "2009-02-18 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1224406892",
  "text" : "Das h\u00F6rt sich doch schonmal alles ganz gut an f\u00FCr die Lagerk\u00FCche im Sommerlager, besonders die Zwiebelsuppe: http:\/\/tinyurl.com\/cfy493",
  "id" : 1224406892,
  "created_at" : "2009-02-18 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1224600051",
  "text" : "PZ Myers vergleicht die Evolution mit einer Soap Opera. Und das ganz ordentlich. http:\/\/tinyurl.com\/az6bhe",
  "id" : 1224600051,
  "created_at" : "2009-02-18 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1219441352",
  "geo" : { },
  "id_str" : "1219920549",
  "in_reply_to_user_id" : 17904767,
  "text" : "@Causa_Motiva ja aber daf\u00FCr muss man dann nicht mehr Zahlen um Paper lesen zu d\u00FCrfen.",
  "id" : 1219920549,
  "in_reply_to_status_id" : 1219441352,
  "created_at" : "2009-02-17 00:00:00 +0000",
  "in_reply_to_screen_name" : "SteterTropfen",
  "in_reply_to_user_id_str" : "17904767",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1219935988",
  "text" : "MacOS ist bl\u00F6d. Beim Neustart behauptet es steif und fest wir h\u00E4tten es schon eine Stunde sp\u00E4ter. Trotz aktiver Timeserver",
  "id" : 1219935988,
  "created_at" : "2009-02-17 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1219980474",
  "geo" : { },
  "id_str" : "1220034663",
  "in_reply_to_user_id" : 17904767,
  "text" : "@Causa_Motiva Forscher sind doch selbst auch \u201Cdie Leser\u201D und profitieren davon. Was man an Geld spart weil man nicht mehr den Zugriff...",
  "id" : 1220034663,
  "in_reply_to_status_id" : 1219980474,
  "created_at" : "2009-02-17 00:00:00 +0000",
  "in_reply_to_screen_name" : "SteterTropfen",
  "in_reply_to_user_id_str" : "17904767",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1219980474",
  "geo" : { },
  "id_str" : "1220036726",
  "in_reply_to_user_id" : 17904767,
  "text" : "@Causa_Motiva ...kaufen muss k\u00F6nnte man ins publizieren investieren. Keine Ahnung was im Endeffekt g\u00FCnstiger ist.",
  "id" : 1220036726,
  "in_reply_to_status_id" : 1219980474,
  "created_at" : "2009-02-17 00:00:00 +0000",
  "in_reply_to_screen_name" : "SteterTropfen",
  "in_reply_to_user_id_str" : "17904767",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 0, 10 ],
      "id_str" : "14700783",
      "id" : 14700783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1220037544",
  "geo" : { },
  "id_str" : "1220072915",
  "in_reply_to_user_id" : 14700783,
  "text" : "@Fischblog Was man f\u00FCr die Wissenschaft nicht doch alles auf sich nimmt.",
  "id" : 1220072915,
  "in_reply_to_status_id" : 1220037544,
  "created_at" : "2009-02-17 00:00:00 +0000",
  "in_reply_to_screen_name" : "Fischblog",
  "in_reply_to_user_id_str" : "14700783",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 0, 10 ],
      "id_str" : "14700783",
      "id" : 14700783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1220113413",
  "geo" : { },
  "id_str" : "1220122603",
  "in_reply_to_user_id" : 14700783,
  "text" : "@Fischblog Hast dich schon irgendwo beworben?",
  "id" : 1220122603,
  "in_reply_to_status_id" : 1220113413,
  "created_at" : "2009-02-17 00:00:00 +0000",
  "in_reply_to_screen_name" : "Fischblog",
  "in_reply_to_user_id_str" : "14700783",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1220239097",
  "text" : "Nutze nun doch wieder TweetDeck, bin trotzdem mit allen Clients unzufrieden.",
  "id" : 1220239097,
  "created_at" : "2009-02-17 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "muenster",
      "indices" : [ 65, 74 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1220274807",
  "text" : "Wer kommt nun eigentlich alles zur pl0gbar am Donnerstag von den #muenster anern? :)",
  "id" : 1220274807,
  "created_at" : "2009-02-17 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1220302318",
  "text" : "Grandioser Megafaiil! http:\/\/twurl.nl\/yyjn27",
  "id" : 1220302318,
  "created_at" : "2009-02-17 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1220385497",
  "text" : "Ich werde nun Psych schauen. Mag hier noch irgend jemand die Serie?",
  "id" : 1220385497,
  "created_at" : "2009-02-17 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MakMaksan",
      "screen_name" : "MakMaksan",
      "indices" : [ 0, 10 ],
      "id_str" : "17112939",
      "id" : 17112939
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1220392694",
  "geo" : { },
  "id_str" : "1220399731",
  "in_reply_to_user_id" : 17112939,
  "text" : "@MakMaksan mit Stargate bin ich hingegen nie warm geworden.",
  "id" : 1220399731,
  "in_reply_to_status_id" : 1220392694,
  "created_at" : "2009-02-17 00:00:00 +0000",
  "in_reply_to_screen_name" : "MakMaksan",
  "in_reply_to_user_id_str" : "17112939",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Tentler",
      "screen_name" : "Viss",
      "indices" : [ 0, 5 ],
      "id_str" : "2269701",
      "id" : 2269701
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1220433772",
  "geo" : { },
  "id_str" : "1220439839",
  "in_reply_to_user_id" : 2269701,
  "text" : "@Viss my dog likes licking the trackpad of my notebook. Strange creatures.",
  "id" : 1220439839,
  "in_reply_to_status_id" : 1220433772,
  "created_at" : "2009-02-17 00:00:00 +0000",
  "in_reply_to_screen_name" : "Viss",
  "in_reply_to_user_id_str" : "2269701",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1218221683",
  "text" : "Ich mach mich mal auf den Weg zur Post um ein Paket abzuholen. Habe keine Ahnung was es sein k\u00F6nnte.",
  "id" : 1218221683,
  "created_at" : "2009-02-17 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1218441498",
  "text" : "Langsam hat der Hund den Dreh raus und l\u00E4sst V\u00F6gel und Rehe in mehr oder weniger in Ruhe.",
  "id" : 1218441498,
  "created_at" : "2009-02-17 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Houellebeck",
      "screen_name" : "houellebeck",
      "indices" : [ 0, 12 ],
      "id_str" : "107803659",
      "id" : 107803659
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1218447560",
  "text" : "@houellebeck Alles f\u00FCr jeden und nicht mehr arbeiten? Wann kommen die Roboter endlich die alles erledigen?! :)",
  "id" : 1218447560,
  "created_at" : "2009-02-17 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1218512899",
  "geo" : { },
  "id_str" : "1218531472",
  "in_reply_to_user_id" : 1151281,
  "text" : "Werde ein bisschen Left4Dead spielen",
  "id" : 1218531472,
  "in_reply_to_status_id" : 1218512899,
  "created_at" : "2009-02-17 00:00:00 +0000",
  "in_reply_to_screen_name" : "DonDahlmann",
  "in_reply_to_user_id_str" : "1151281",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1219354801",
  "text" : "K\u00F6nnte sich Open Access sich bitte mal schnell durchsetzen? Verstehe sowieso nicht wie man als Wissenschaftler dagegen sein kann.",
  "id" : 1219354801,
  "created_at" : "2009-02-17 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1214700466",
  "text" : "Moin",
  "id" : 1214700466,
  "created_at" : "2009-02-16 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Houellebeck",
      "screen_name" : "houellebeck",
      "indices" : [ 0, 12 ],
      "id_str" : "107803659",
      "id" : 107803659
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1214718504",
  "text" : "@houellebeck Und da sag noch einer wir h\u00E4tten keine durchgeknallten Extremisten auch hier in Deutschland...",
  "id" : 1214718504,
  "created_at" : "2009-02-16 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kristof Dreier",
      "screen_name" : "dasblogt",
      "indices" : [ 0, 9 ],
      "id_str" : "281703380",
      "id" : 281703380
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1214763753",
  "text" : "@dasblogt Ich hab die TuneBuds und bin damit sehr zufrieden bislang: http:\/\/tinyurl.com\/aeq6kx",
  "id" : 1214763753,
  "created_at" : "2009-02-16 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sofia",
      "screen_name" : "Sofia",
      "indices" : [ 0, 6 ],
      "id_str" : "56903",
      "id" : 56903
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1214816220",
  "in_reply_to_user_id" : 56903,
  "text" : "@Sofia twittert auf english \u00FCber die Gerichtsverhandlung von The Pirate Bay. Kann ich nur empfehlen.",
  "id" : 1214816220,
  "created_at" : "2009-02-16 00:00:00 +0000",
  "in_reply_to_screen_name" : "Sofia",
  "in_reply_to_user_id_str" : "56903",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "spectrial",
      "indices" : [ 126, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1214868899",
  "text" : "Der TBP-Stream ist leider so instabil das man der h\u00FCbschen Dame die gerade die Zusammenfassung machen will nicht folgen kann. #spectrial-de",
  "id" : 1214868899,
  "created_at" : "2009-02-16 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1214885178",
  "text" : "Ich weiss was mein Hund als n\u00E4chstes lernen wird. Wenn das nicht ideal ist f\u00FCr die Fahrradstadt M\u00FCnster: http:\/\/tinyurl.com\/cehqsb",
  "id" : 1214885178,
  "created_at" : "2009-02-16 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1214910417",
  "text" : "Hat jemand Verwendung f\u00FCr einen 10\u20AC-Gutschein f\u00FCr tolingo.de? Ich nicht wirklich.",
  "id" : 1214910417,
  "created_at" : "2009-02-16 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1215084248",
  "text" : "Zeit f\u00FCrs Mittagessen. Der Hund ist ja auch schon dabei seins herunterzuschlingen. Kauen ist f\u00FCr Anf\u00E4nger.",
  "id" : 1215084248,
  "created_at" : "2009-02-16 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Markus Bertling",
      "screen_name" : "jayzon277",
      "indices" : [ 0, 10 ],
      "id_str" : "372320321",
      "id" : 372320321
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "schluckauf",
      "indices" : [ 55, 66 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1215135163",
  "geo" : { },
  "id_str" : "1215142245",
  "in_reply_to_user_id" : 14115883,
  "text" : "@jayzon277 Luft anhalten, erschrecken, Wasser trinken? #schluckauf",
  "id" : 1215142245,
  "in_reply_to_status_id" : 1215135163,
  "created_at" : "2009-02-16 00:00:00 +0000",
  "in_reply_to_screen_name" : "HerrBertling",
  "in_reply_to_user_id_str" : "14115883",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1215399717",
  "text" : "Ich wei\u00DF. Es gibt kein schlechtes Wetter. Nur falsch angezogen. Der Matsch im Wald saugt trotzdem.",
  "id" : 1215399717,
  "created_at" : "2009-02-16 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joerg Roehlig",
      "screen_name" : "JoergR",
      "indices" : [ 0, 7 ],
      "id_str" : "774628164177985537",
      "id" : 774628164177985537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1215841832",
  "text" : "@JoergR schwer. F\u00FCr die Busaktion sind ja jede Menge gute Vorschl\u00E4ge da!",
  "id" : 1215841832,
  "created_at" : "2009-02-16 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1215880683",
  "text" : "Werde nun die Simpsons schauen und hoffen das gute Folgen kommen.",
  "id" : 1215880683,
  "created_at" : "2009-02-16 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "nSonic",
      "screen_name" : "bnSonic",
      "indices" : [ 0, 8 ],
      "id_str" : "17022259",
      "id" : 17022259
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1215877882",
  "geo" : { },
  "id_str" : "1215888326",
  "in_reply_to_user_id" : 17022259,
  "text" : "@bnSonic ich kann es nur empfehlen :)",
  "id" : 1215888326,
  "in_reply_to_status_id" : 1215877882,
  "created_at" : "2009-02-16 00:00:00 +0000",
  "in_reply_to_screen_name" : "bnSonic",
  "in_reply_to_user_id_str" : "17022259",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ThrClub",
      "screen_name" : "JustDude",
      "indices" : [ 0, 9 ],
      "id_str" : "305695940",
      "id" : 305695940
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1215966755",
  "text" : "@justdude mein Beileid! Kenn ich zu gut!",
  "id" : 1215966755,
  "created_at" : "2009-02-16 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1216048870",
  "text" : "Ich mach ich mal auf den Weg zur Leiterrunde. Die Motivation daf\u00FCr ist heute == 0.",
  "id" : 1216048870,
  "created_at" : "2009-02-16 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1216524246",
  "text" : "Das ging heute erstaunlich schnell. Und das Protokoll ist auch gerade per Mail raus. Feierabend!",
  "id" : 1216524246,
  "created_at" : "2009-02-16 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1216582811",
  "text" : "Diskussionen machen ja so viel Spass wenn der Gegen\u00FCber einfach blind auf seinem Standpunkt beharrt und keinerlei Argumente hat.",
  "id" : 1216582811,
  "created_at" : "2009-02-16 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1216609060",
  "geo" : { },
  "id_str" : "1216624439",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod Falk? Haben die nicht so Routenplaner gemacht?",
  "id" : 1216624439,
  "in_reply_to_status_id" : 1216609060,
  "created_at" : "2009-02-16 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "herr_schrat",
      "screen_name" : "herr_schrat",
      "indices" : [ 0, 12 ],
      "id_str" : "16066591",
      "id" : 16066591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1216719555",
  "geo" : { },
  "id_str" : "1216778051",
  "in_reply_to_user_id" : 16066591,
  "text" : "@herr_schrat ja auch.",
  "id" : 1216778051,
  "in_reply_to_status_id" : 1216719555,
  "created_at" : "2009-02-16 00:00:00 +0000",
  "in_reply_to_screen_name" : "herr_schrat",
  "in_reply_to_user_id_str" : "16066591",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1216807761",
  "text" : "So ich schau nun noch ein wenig fern. Mal sehen ob ich noch Twittere.",
  "id" : 1216807761,
  "created_at" : "2009-02-16 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1211985910",
  "text" : "Moin Moin zusammen.",
  "id" : 1211985910,
  "created_at" : "2009-02-15 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1212062997",
  "text" : "Ich bring dann Schatzi mal wieder weg.",
  "id" : 1212062997,
  "created_at" : "2009-02-15 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1212138179",
  "text" : "Das Atheist-Bus-Shirt ist angekommen. Coole Sache :)",
  "id" : 1212138179,
  "created_at" : "2009-02-15 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1212712688",
  "text" : "Der Left4Dead-Multiplayer macht erstaunlich viel Spass.",
  "id" : 1212712688,
  "created_at" : "2009-02-15 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1212724525",
  "text" : "Wieso, tauchen heute Trackbacks bei mir auf die vor \u00FCber 2 Jahren in Auftrag gegeben wurden?",
  "id" : 1212724525,
  "created_at" : "2009-02-15 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1212833623",
  "text" : "Ich Liebe die Kamera vom iPhone.  http:\/\/twitpic.com\/1iafa",
  "id" : 1212833623,
  "created_at" : "2009-02-15 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1213103344",
  "text" : "Jetzt doch vor den Fernseher.",
  "id" : 1213103344,
  "created_at" : "2009-02-15 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1212964614",
  "geo" : { },
  "id_str" : "1213133423",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod Jaja, Autofokus w\u00E4re cool. Oder wenigstens eine Makrofunktion...",
  "id" : 1213133423,
  "in_reply_to_status_id" : 1212964614,
  "created_at" : "2009-02-15 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gerrit Eicker",
      "screen_name" : "eicker",
      "indices" : [ 0, 7 ],
      "id_str" : "7950992",
      "id" : 7950992
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1213147033",
  "in_reply_to_user_id" : 7950992,
  "text" : "@eicker Der Spiegel hat wieder mal was \u00FCber Mikrokredite gebracht, das ist doch was f\u00FCr dich: http:\/\/tinyurl.com\/cgtwro",
  "id" : 1213147033,
  "created_at" : "2009-02-15 00:00:00 +0000",
  "in_reply_to_screen_name" : "eicker",
  "in_reply_to_user_id_str" : "7950992",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1213195116",
  "geo" : { },
  "id_str" : "1213208062",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod Ach sobald man auf \u221E ist geht es doch eigentlich :)",
  "id" : 1213208062,
  "in_reply_to_status_id" : 1213195116,
  "created_at" : "2009-02-15 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1213215817",
  "text" : "Cool, gleich kommt wieder Lewis im ZDF, ich steh total auf englische Krimis.",
  "id" : 1213215817,
  "created_at" : "2009-02-15 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kasa",
      "screen_name" : "paperama",
      "indices" : [ 4, 13 ],
      "id_str" : "6893982",
      "id" : 6893982
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "paperlove",
      "indices" : [ 91, 101 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1213225172",
  "text" : "RT: @paperama: looking at this Paper-Based Visualization article http:\/\/tinyurl.com\/cel34u #paperlove",
  "id" : 1213225172,
  "created_at" : "2009-02-15 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Der Jubilizr",
      "screen_name" : "jubilizr",
      "indices" : [ 33, 42 ],
      "id_str" : "19485705",
      "id" : 19485705
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1213240731",
  "text" : "Und mit meinem 3000 Tweet (Danke @jubilizr f\u00FCr den Hinweis) begebe ich mich nun vor den Fernseher. Bis dahin.",
  "id" : 1213240731,
  "created_at" : "2009-02-15 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1209517516",
  "text" : "Er kommt ganz nach dem Herrchen ;) http:\/\/twitpic.com\/1hdsu",
  "id" : 1209517516,
  "created_at" : "2009-02-14 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1209541580",
  "geo" : { },
  "id_str" : "1209550077",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod kein gutes Zeichen ;)",
  "id" : 1209550077,
  "in_reply_to_status_id" : 1209541580,
  "created_at" : "2009-02-14 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1209555630",
  "geo" : { },
  "id_str" : "1209558433",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod das shirt hat doch die Anleitung parat. ;)",
  "id" : 1209558433,
  "in_reply_to_status_id" : 1209555630,
  "created_at" : "2009-02-14 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1209583927",
  "geo" : { },
  "id_str" : "1209586257",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod absolut :)",
  "id" : 1209586257,
  "in_reply_to_status_id" : 1209583927,
  "created_at" : "2009-02-14 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1209588666",
  "text" : "Jetzt ist das iPhone seltsam abgest\u00FCrzt. Ich kann die Telefon-App nicht meht verlassen.",
  "id" : 1209588666,
  "created_at" : "2009-02-14 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1209746770",
  "text" : "Left4Dead gibt es an diesem Wochenende f\u00FCr den halben Preis. Gut 23 Euro.",
  "id" : 1209746770,
  "created_at" : "2009-02-14 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1209883766",
  "text" : "Memo: Heute ist Samstag, nicht Freitag. Zeitgef\u00FChl goodbye!",
  "id" : 1209883766,
  "created_at" : "2009-02-14 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "raju e",
      "screen_name" : "rajue",
      "indices" : [ 0, 6 ],
      "id_str" : "289833731",
      "id" : 289833731
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rp09",
      "indices" : [ 48, 53 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1209979590",
  "text" : "@rajue Und bist du auch bei der pre:publica? :) #rp09",
  "id" : 1209979590,
  "created_at" : "2009-02-14 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "raju e",
      "screen_name" : "rajue",
      "indices" : [ 0, 6 ],
      "id_str" : "289833731",
      "id" : 289833731
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1209997984",
  "text" : "@rajue Ja, ist auf der CeBIT. Aber dann halt erstmal zur re:publica :)",
  "id" : 1209997984,
  "created_at" : "2009-02-14 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "raju e",
      "screen_name" : "rajue",
      "indices" : [ 0, 6 ],
      "id_str" : "289833731",
      "id" : 289833731
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1210041106",
  "text" : "@rajue jau. Ich komme auch zur re:publica :)",
  "id" : 1210041106,
  "created_at" : "2009-02-14 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1210627756",
  "text" : "Sitze am Bremer Platz und warte das Schatzi endlich ankommt.",
  "id" : 1210627756,
  "created_at" : "2009-02-14 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1210667333",
  "text" : "Erst 1 Stunde Versp\u00E4tung.",
  "id" : 1210667333,
  "created_at" : "2009-02-14 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1209336585",
  "text" : "Moin moin",
  "id" : 1209336585,
  "created_at" : "2009-02-14 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1209376107",
  "text" : "Wird langsam mal Zeit wirklich aufzustehen.",
  "id" : 1209376107,
  "created_at" : "2009-02-14 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1209379903",
  "text" : "War wohl nicht die gro\u00DFe Liebe. Er hat das Pferd seiner Innereien beraubt.  http:\/\/twitpic.com\/1hcnf",
  "id" : 1209379903,
  "created_at" : "2009-02-14 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1209468281",
  "text" : "Entspannt Podcasts beim Sp\u00E4t-Fr\u00FChst\u00FCck h\u00F6ren.",
  "id" : 1209468281,
  "created_at" : "2009-02-14 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1209506584",
  "text" : "Vor 2 Tagen hatte \u00FCbrigens nicht nur Darwin Geburtstag. Auch Lincoln ist 200 geworden. Davon hab ich gar nichts geh\u00F6rt.",
  "id" : 1209506584,
  "created_at" : "2009-02-14 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1205729183",
  "text" : "Cool, der Postbote hat mir gerade meine Poster gebracht: Monkey Island und Day Of The Tentacle!",
  "id" : 1205729183,
  "created_at" : "2009-02-13 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Houellebeck",
      "screen_name" : "houellebeck",
      "indices" : [ 0, 12 ],
      "id_str" : "107803659",
      "id" : 107803659
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1205754638",
  "text" : "@houellebeck und gro\u00DF, schwer, unhandlich und nicht durchsuchbar ;) Aber meine Unterhaltungsliteratur in Buch ist nett. Fachzeug in Digital!",
  "id" : 1205754638,
  "created_at" : "2009-02-13 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1205800915",
  "text" : "http:\/\/twitpic.com\/1gd70 der Naturepodcast diese Woche hat auch ein passendes, cooles Logo bekommen :)",
  "id" : 1205800915,
  "created_at" : "2009-02-13 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Martin Labuschin",
      "screen_name" : "Labuschin",
      "indices" : [ 0, 10 ],
      "id_str" : "1024351",
      "id" : 1024351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1205839447",
  "in_reply_to_user_id" : 1024351,
  "text" : "@Labuschin Scrollen via Multitouch geht nicht, f\u00FCr mich schon ein K.O.-Kriterium.",
  "id" : 1205839447,
  "created_at" : "2009-02-13 00:00:00 +0000",
  "in_reply_to_screen_name" : "Labuschin",
  "in_reply_to_user_id_str" : "1024351",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "crashtron",
      "screen_name" : "crashtron",
      "indices" : [ 0, 10 ],
      "id_str" : "33913",
      "id" : 33913
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fitnessstudio",
      "indices" : [ 74, 88 ]
    }, {
      "text" : "muenster",
      "indices" : [ 89, 98 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1205877901",
  "geo" : { },
  "id_str" : "1205886279",
  "in_reply_to_user_id" : 33913,
  "text" : "@crashtron Nope ich hab keins ausprobiert und werde es wohl auch nicht ;) #fitnessstudio #muenster",
  "id" : 1205886279,
  "in_reply_to_status_id" : 1205877901,
  "created_at" : "2009-02-13 00:00:00 +0000",
  "in_reply_to_screen_name" : "crashtron",
  "in_reply_to_user_id_str" : "33913",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nerdquatsch",
      "indices" : [ 43, 55 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1205893514",
  "text" : "Ich freu mich schon drauf die aufzuh\u00E4ngen. #nerdquatsch http:\/\/twitpic.com\/1goke",
  "id" : 1205893514,
  "created_at" : "2009-02-13 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1206034985",
  "text" : "Ich mach mich nun auf den Weg zum Mittagessen. Meine Eltern haben geladen.",
  "id" : 1206034985,
  "created_at" : "2009-02-13 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1206107460",
  "text" : "Vollgefressen. Jetzt w\u00E4re Zeit f\u00FCr den Mittagsschlaf.",
  "id" : 1206107460,
  "created_at" : "2009-02-13 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1206139470",
  "text" : "Mal die StudiVZ-App f\u00FCr das iPhone ansehen.",
  "id" : 1206139470,
  "created_at" : "2009-02-13 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1206352387",
  "text" : "Werde mich noch ein wenig Fallout 3 widmen.",
  "id" : 1206352387,
  "created_at" : "2009-02-13 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1206531229",
  "text" : "@njeppo durch bin ich auch seit 2 Wochen. Nun erkunde ich aber noch den Rest der Wastelands :)",
  "id" : 1206531229,
  "created_at" : "2009-02-13 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1207020889",
  "text" : "Everyone knows rock music attained perfection in 1974, it's a scientifically proven fact! - Homer Simpson",
  "id" : 1207020889,
  "created_at" : "2009-02-13 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "sevenmac",
      "screen_name" : "sevenmac",
      "indices" : [ 4, 13 ],
      "id_str" : "16426577",
      "id" : 16426577
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1207036342",
  "text" : "RT: @sevenmac: Taliban nutzt das iPhone http:\/\/tinyurl.com\/b7qokk",
  "id" : 1207036342,
  "created_at" : "2009-02-13 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephan Sachs",
      "screen_name" : "fischimglas",
      "indices" : [ 0, 12 ],
      "id_str" : "15199614",
      "id" : 15199614
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1207321969",
  "geo" : { },
  "id_str" : "1207342758",
  "in_reply_to_user_id" : 15199614,
  "text" : "@fischimglas Grausim wie krumm das ist. Ob man nicht besser konnte oder ob es keinem Aufgefallen ist?",
  "id" : 1207342758,
  "in_reply_to_status_id" : 1207321969,
  "created_at" : "2009-02-13 00:00:00 +0000",
  "in_reply_to_screen_name" : "fischimglas",
  "in_reply_to_user_id_str" : "15199614",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1207354359",
  "text" : "http:\/\/tinyurl.com\/cctywm Cooles Science-Tattoo. Ich \u00FCberlege immer noch was ich stechenswert finde.",
  "id" : 1207354359,
  "created_at" : "2009-02-13 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephan Sachs",
      "screen_name" : "fischimglas",
      "indices" : [ 0, 12 ],
      "id_str" : "15199614",
      "id" : 15199614
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1207372444",
  "in_reply_to_user_id" : 15199614,
  "text" : "@fischimglas Das Format ist nicht so auff\u00E4llig finde ich.",
  "id" : 1207372444,
  "created_at" : "2009-02-13 00:00:00 +0000",
  "in_reply_to_screen_name" : "fischimglas",
  "in_reply_to_user_id_str" : "15199614",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Udo Vetter",
      "screen_name" : "udovetter",
      "indices" : [ 0, 10 ],
      "id_str" : "15998669",
      "id" : 15998669
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1207530606",
  "geo" : { },
  "id_str" : "1207545133",
  "in_reply_to_user_id" : 15998669,
  "text" : "@udovetter Peinlich wird es wenn das Pizza-Taxi zur\u00FCckruft um zu fragen ob man heute nichts essen will!",
  "id" : 1207545133,
  "in_reply_to_status_id" : 1207530606,
  "created_at" : "2009-02-13 00:00:00 +0000",
  "in_reply_to_screen_name" : "udovetter",
  "in_reply_to_user_id_str" : "15998669",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1202223466",
  "text" : "In 95% der F\u00E4lle ist der Hund der Liebste der Welt. in den anderen 5% hat man Zuschauer.",
  "id" : 1202223466,
  "created_at" : "2009-02-12 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1202231787",
  "text" : "Heute: Darwin-Overkill dank seines Geburtstags!",
  "id" : 1202231787,
  "created_at" : "2009-02-12 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1202240424",
  "geo" : { },
  "id_str" : "1202249454",
  "in_reply_to_user_id" : 14965082,
  "text" : "@epihelix Viel Spass mit der Ratte. Das ist doch das was mit am meisten Spass macht und am interessantesten ist :)",
  "id" : 1202249454,
  "in_reply_to_status_id" : 1202240424,
  "created_at" : "2009-02-12 00:00:00 +0000",
  "in_reply_to_screen_name" : "berggruen",
  "in_reply_to_user_id_str" : "14965082",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stefan",
      "screen_name" : "stelten",
      "indices" : [ 0, 8 ],
      "id_str" : "14082615",
      "id" : 14082615
    }, {
      "name" : "Martin Labuschin",
      "screen_name" : "Labuschin",
      "indices" : [ 28, 38 ],
      "id_str" : "1024351",
      "id" : 1024351
    }, {
      "name" : "Houelle",
      "screen_name" : "houllebeck",
      "indices" : [ 39, 50 ],
      "id_str" : "21393144",
      "id" : 21393144
    }, {
      "name" : "Gerrit Eicker",
      "screen_name" : "eicker",
      "indices" : [ 51, 58 ],
      "id_str" : "7950992",
      "id" : 7950992
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1202244215",
  "geo" : { },
  "id_str" : "1202252600",
  "in_reply_to_user_id" : 14082615,
  "text" : "@stelten TweetUp war super. @labuschin @houllebeck @eicker und ich waren da. Das n\u00E4chste mal w\u00E4re vielleicht mehr Vorlaufzeit besser ;)",
  "id" : 1202252600,
  "in_reply_to_status_id" : 1202244215,
  "created_at" : "2009-02-12 00:00:00 +0000",
  "in_reply_to_screen_name" : "stelten",
  "in_reply_to_user_id_str" : "14082615",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stefan",
      "screen_name" : "stelten",
      "indices" : [ 0, 8 ],
      "id_str" : "14082615",
      "id" : 14082615
    }, {
      "name" : "Houelle",
      "screen_name" : "houllebeck",
      "indices" : [ 9, 20 ],
      "id_str" : "21393144",
      "id" : 21393144
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "muenster",
      "indices" : [ 80, 89 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1202262523",
  "geo" : { },
  "id_str" : "1202279600",
  "in_reply_to_user_id" : 14082615,
  "text" : "@stelten @houllebeck wie w\u00E4re es mit sowas wie \"jeden xten Wochentag im Monat\"? #muenster",
  "id" : 1202279600,
  "in_reply_to_status_id" : 1202262523,
  "created_at" : "2009-02-12 00:00:00 +0000",
  "in_reply_to_screen_name" : "stelten",
  "in_reply_to_user_id_str" : "14082615",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stefan",
      "screen_name" : "stelten",
      "indices" : [ 0, 8 ],
      "id_str" : "14082615",
      "id" : 14082615
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "muenster",
      "indices" : [ 94, 103 ]
    }, {
      "text" : "tweetup",
      "indices" : [ 104, 112 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1202284332",
  "geo" : { },
  "id_str" : "1202300592",
  "in_reply_to_user_id" : 14082615,
  "text" : "@stelten Ahso, ich dachte an einen festen Wochentag, z.B. jeden 3ten Montag im Monat oder so. #muenster #tweetup",
  "id" : 1202300592,
  "in_reply_to_status_id" : 1202284332,
  "created_at" : "2009-02-12 00:00:00 +0000",
  "in_reply_to_screen_name" : "stelten",
  "in_reply_to_user_id_str" : "14082615",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1202320945",
  "text" : "Reading: \"Symbol6 : How We Created an iPhone Game \u00AB All Things Gogogic\" ( http:\/\/tinyurl.com\/cmka5f )",
  "id" : 1202320945,
  "created_at" : "2009-02-12 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Benjamin Claverie",
      "screen_name" : "Skl8em",
      "indices" : [ 0, 7 ],
      "id_str" : "13823092",
      "id" : 13823092
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1202316471",
  "geo" : { },
  "id_str" : "1202324298",
  "in_reply_to_user_id" : 13823092,
  "text" : "@Skl8em Das ist nat\u00FCrlich auch nicht ideal. Aber die Chance das der Xte Tag des Monats ein Dienstag ist sieht auch nicht besser aus oder?",
  "id" : 1202324298,
  "in_reply_to_status_id" : 1202316471,
  "created_at" : "2009-02-12 00:00:00 +0000",
  "in_reply_to_screen_name" : "Skl8em",
  "in_reply_to_user_id_str" : "13823092",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Martin Labuschin",
      "screen_name" : "Labuschin",
      "indices" : [ 4, 14 ],
      "id_str" : "1024351",
      "id" : 1024351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1202325994",
  "text" : "RT: @Labuschin: Hehe, super Tipps um busy auszusehen: http:\/\/tinyurl.com\/d5auag",
  "id" : 1202325994,
  "created_at" : "2009-02-12 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stefan",
      "screen_name" : "stelten",
      "indices" : [ 0, 8 ],
      "id_str" : "14082615",
      "id" : 14082615
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "muenster",
      "indices" : [ 27, 36 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1202355802",
  "geo" : { },
  "id_str" : "1202484095",
  "in_reply_to_user_id" : 14082615,
  "text" : "@stelten das sieht gut aus #muenster",
  "id" : 1202484095,
  "in_reply_to_status_id" : 1202355802,
  "created_at" : "2009-02-12 00:00:00 +0000",
  "in_reply_to_screen_name" : "stelten",
  "in_reply_to_user_id_str" : "14082615",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1202691835",
  "text" : "Oha, es gibt ein Update von Newsstand f\u00FCrs iPhone, mit Twitterunterst\u00FCtzung. Da bin ich gespannt. Lad gef\u00E4lligst schneller iPhone!",
  "id" : 1202691835,
  "created_at" : "2009-02-12 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Spreeblick",
      "indices" : [ 83, 94 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1202726262",
  "text" : "Nazi-Bands und deren Fans bei Spiegel Online und last.fm http:\/\/tinyurl.com\/byjtny #Spreeblick | Test via Newsstand",
  "id" : 1202726262,
  "created_at" : "2009-02-12 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Markus Bertling",
      "screen_name" : "jayzon277",
      "indices" : [ 0, 10 ],
      "id_str" : "372320321",
      "id" : 372320321
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1202711288",
  "geo" : { },
  "id_str" : "1202731655",
  "in_reply_to_user_id" : 14115883,
  "text" : "@jayzon277 Gro\u00DFer Nachteil ist: Es gibt keinen Sync der Feeds zu einem normalen Rechner via Newsstand. Ich lese nur via iPhone daher egal.",
  "id" : 1202731655,
  "in_reply_to_status_id" : 1202711288,
  "created_at" : "2009-02-12 00:00:00 +0000",
  "in_reply_to_screen_name" : "HerrBertling",
  "in_reply_to_user_id_str" : "14115883",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Markus Bertling",
      "screen_name" : "jayzon277",
      "indices" : [ 0, 10 ],
      "id_str" : "372320321",
      "id" : 372320321
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1202711288",
  "geo" : { },
  "id_str" : "1202733315",
  "in_reply_to_user_id" : 14115883,
  "text" : "@jayzon277 Vorteil: Die Feeds werden alle sehr gut angezeigt auf dem iPhone, sehr stabil. Nun auch delicious & Twitter-Support.",
  "id" : 1202733315,
  "in_reply_to_status_id" : 1202711288,
  "created_at" : "2009-02-12 00:00:00 +0000",
  "in_reply_to_screen_name" : "HerrBertling",
  "in_reply_to_user_id_str" : "14115883",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1202761072",
  "text" : "Delicious funktioniert auch tadellos \u00FCber Newsstand. Damit wird er zu einem immer besseren Allround-Reader.",
  "id" : 1202761072,
  "created_at" : "2009-02-12 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Markus Bertling",
      "screen_name" : "jayzon277",
      "indices" : [ 0, 10 ],
      "id_str" : "372320321",
      "id" : 372320321
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1202761096",
  "geo" : { },
  "id_str" : "1202765611",
  "in_reply_to_user_id" : 14115883,
  "text" : "@jayzon277 Au\u00DFerdem muss ich sagen dass das synchen bei NetNewsWire bei mir nur ganz ganz schlecht klappt. Da verzichte ich lieber.",
  "id" : 1202765611,
  "in_reply_to_status_id" : 1202761096,
  "created_at" : "2009-02-12 00:00:00 +0000",
  "in_reply_to_screen_name" : "HerrBertling",
  "in_reply_to_user_id_str" : "14115883",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1203028214",
  "text" : "Dinge die man auch einfach nicht tun sollte: SpOn-\u201CForen\u201D \u00F6ffnen.",
  "id" : 1203028214,
  "created_at" : "2009-02-12 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1203399281",
  "text" : "Oh ne. Das WLAN krebst hier schon wieder rum. Zum Kotzen.",
  "id" : 1203399281,
  "created_at" : "2009-02-12 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1203637955",
  "text" : "Gleich gehts dann mal los zu den Pfadfindern. Pl\u00E4ne f\u00FCr heute: Inhaltliche Arbeit. Die Kinder werden es lieben - Nicht!",
  "id" : 1203637955,
  "created_at" : "2009-02-12 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1203649598",
  "text" : "Das WDR-Zeitzeichen zu Darwins Geburtstag ist sogar ganz gut geworden: http:\/\/tinyurl.com\/dkvbgp",
  "id" : 1203649598,
  "created_at" : "2009-02-12 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stefan",
      "screen_name" : "stelten",
      "indices" : [ 0, 8 ],
      "id_str" : "14082615",
      "id" : 14082615
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1204079902",
  "geo" : { },
  "id_str" : "1204098115",
  "in_reply_to_user_id" : 14082615,
  "text" : "@stelten H\u00F6rt sich ganz spannend an. Bist du die ganze Zeit auf der CeBIT oder nur zur pre:publica?",
  "id" : 1204098115,
  "in_reply_to_status_id" : 1204079902,
  "created_at" : "2009-02-12 00:00:00 +0000",
  "in_reply_to_screen_name" : "stelten",
  "in_reply_to_user_id_str" : "14082615",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stefan",
      "screen_name" : "stelten",
      "indices" : [ 0, 8 ],
      "id_str" : "14082615",
      "id" : 14082615
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1204134093",
  "geo" : { },
  "id_str" : "1204146008",
  "in_reply_to_user_id" : 14082615,
  "text" : "@stelten Und du f\u00E4hrst zuf\u00E4llig mit dem Auto und hast noch einen Platz frei? Dann w\u00E4re das eine \u00DCberlegung wert :)",
  "id" : 1204146008,
  "in_reply_to_status_id" : 1204134093,
  "created_at" : "2009-02-12 00:00:00 +0000",
  "in_reply_to_screen_name" : "stelten",
  "in_reply_to_user_id_str" : "14082615",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1204411406",
  "text" : "Ich geh nun ins Bett!",
  "id" : 1204411406,
  "created_at" : "2009-02-12 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "alicehive_de",
      "screen_name" : "alicehive_de",
      "indices" : [ 0, 13 ],
      "id_str" : "17261685",
      "id" : 17261685
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1199809270",
  "geo" : { },
  "id_str" : "1200217546",
  "in_reply_to_user_id" : 17261685,
  "text" : "@alicehive_de eigene Meinung ok. Aber es gibt Sachverhalte da gibt es halt ein klares \"richtig\" und alles andere ist falsch",
  "id" : 1200217546,
  "in_reply_to_status_id" : 1199809270,
  "created_at" : "2009-02-11 00:00:00 +0000",
  "in_reply_to_screen_name" : "alicehive_de",
  "in_reply_to_user_id_str" : "17261685",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1200224577",
  "text" : "Das 4-Leute-Tweetup hat sich aufgel\u00F6st. War wieder sehr nett!",
  "id" : 1200224577,
  "created_at" : "2009-02-11 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "alicehive_de",
      "screen_name" : "alicehive_de",
      "indices" : [ 0, 13 ],
      "id_str" : "17261685",
      "id" : 17261685
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1200227584",
  "geo" : { },
  "id_str" : "1200242044",
  "in_reply_to_user_id" : 17261685,
  "text" : "@alicehive_de das hat nichts mit Glaube zu tun. Wissenschaft funktioniert \u00FCber Beweise. Und die sollten auch Lehrer nicht einfach leugnen",
  "id" : 1200242044,
  "in_reply_to_status_id" : 1200227584,
  "created_at" : "2009-02-11 00:00:00 +0000",
  "in_reply_to_screen_name" : "alicehive_de",
  "in_reply_to_user_id_str" : "17261685",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1200230590",
  "geo" : { },
  "id_str" : "1200245746",
  "in_reply_to_user_id" : 8517622,
  "text" : "@lorXsion Stimmt, aber manch einer muss Arbeiten und ins Bett ;)",
  "id" : 1200245746,
  "in_reply_to_status_id" : 1200230590,
  "created_at" : "2009-02-11 00:00:00 +0000",
  "in_reply_to_screen_name" : "mitZett",
  "in_reply_to_user_id_str" : "8517622",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1200610529",
  "text" : "Also ich bin mal raus f\u00FCr heute. Schlaft gut.",
  "id" : 1200610529,
  "created_at" : "2009-02-11 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1198436363",
  "text" : "Guten Morgen!",
  "id" : 1198436363,
  "created_at" : "2009-02-11 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1198479665",
  "text" : "K\u00F6nnte das Wetter mal bitte besser werden?Lange Spazierg\u00E4nge mit Hund sind nicht geil wenn man nach 5 Minuten schon durch- n\u00E4sst& froren ist",
  "id" : 1198479665,
  "created_at" : "2009-02-11 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Herr Rensch",
      "screen_name" : "arensch",
      "indices" : [ 0, 8 ],
      "id_str" : "14725887",
      "id" : 14725887
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1198561156",
  "geo" : { },
  "id_str" : "1198571668",
  "in_reply_to_user_id" : 14725887,
  "text" : "@arensch H\u00FCbsch hier ist es immer noch verhangen und sieht so aus als k\u00F6nnte es gleich wieder anfangen zu regnen.",
  "id" : 1198571668,
  "in_reply_to_status_id" : 1198561156,
  "created_at" : "2009-02-11 00:00:00 +0000",
  "in_reply_to_screen_name" : "arensch",
  "in_reply_to_user_id_str" : "14725887",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1198587494",
  "text" : "Gerade Left4Dead angespielt. Bislang nur Solo, sieht aber schon sehr lustig aus. Freu mich auf Coop-Spiel",
  "id" : 1198587494,
  "created_at" : "2009-02-11 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "muenster",
      "indices" : [ 81, 90 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1198592863",
  "text" : "Noch mal kurz drauf hingewiesen: Heute Abend 19:00 Spontan-TweetUp im Extrablatt #muenster http:\/\/twtvite.com\/qssryq",
  "id" : 1198592863,
  "created_at" : "2009-02-11 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1198635805",
  "text" : "Twitter ist wieder da? Praktisch wenn man schon SMS kriegt ob die Seite bei einem auch nicht geht. ;)",
  "id" : 1198635805,
  "created_at" : "2009-02-11 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1198685995",
  "geo" : { },
  "id_str" : "1198709722",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod Ja!",
  "id" : 1198709722,
  "in_reply_to_status_id" : 1198685995,
  "created_at" : "2009-02-11 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gerrit Eicker",
      "screen_name" : "eicker",
      "indices" : [ 0, 7 ],
      "id_str" : "7950992",
      "id" : 7950992
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1198791423",
  "geo" : { },
  "id_str" : "1198994798",
  "in_reply_to_user_id" : 7950992,
  "text" : "@Eicker Ja. Immerhin kannst du so spontan :)",
  "id" : 1198994798,
  "in_reply_to_status_id" : 1198791423,
  "created_at" : "2009-02-11 00:00:00 +0000",
  "in_reply_to_screen_name" : "eicker",
  "in_reply_to_user_id_str" : "7950992",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "kwerfeldein",
      "screen_name" : "kwerfeldein",
      "indices" : [ 0, 12 ],
      "id_str" : "428633",
      "id" : 428633
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1199163956",
  "geo" : { },
  "id_str" : "1199199345",
  "in_reply_to_user_id" : 428633,
  "text" : "@kwerfeldein Absolut zu gebrauchen daf\u00FCr wenn man mit der Brennweite an sich was anfangen kann. Die Lichtst\u00E4rke reicht auf jedenfall",
  "id" : 1199199345,
  "in_reply_to_status_id" : 1199163956,
  "created_at" : "2009-02-11 00:00:00 +0000",
  "in_reply_to_screen_name" : "kwerfeldein",
  "in_reply_to_user_id_str" : "428633",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1199302787",
  "text" : "Gerade die Ergebnisse der Matheklausur gesehen. Ebenfalls mit gutem Ergebnis bestanden. Damit ist dann sogar das Modul geschafft!",
  "id" : 1199302787,
  "created_at" : "2009-02-11 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Houellebeck",
      "screen_name" : "houellebeck",
      "indices" : [ 0, 12 ],
      "id_str" : "107803659",
      "id" : 107803659
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1199331138",
  "text" : "@houellebeck Einen Tee? ;)",
  "id" : 1199331138,
  "created_at" : "2009-02-11 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1199456919",
  "text" : "7% der Bio-Lehramtsstudenten verneinen die Evolution. Und beweisen damit das sie ihr Studienfach nicht verstanden haben....",
  "id" : 1199456919,
  "created_at" : "2009-02-11 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "alicehive_de",
      "screen_name" : "alicehive_de",
      "indices" : [ 0, 13 ],
      "id_str" : "17261685",
      "id" : 17261685
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1199469543",
  "geo" : { },
  "id_str" : "1199653070",
  "in_reply_to_user_id" : 17261685,
  "text" : "@alicehive_de in dem Fall nein. Physiker die nicht an die Gravitation glauben gibt es ja auch nicht...",
  "id" : 1199653070,
  "in_reply_to_status_id" : 1199469543,
  "created_at" : "2009-02-11 00:00:00 +0000",
  "in_reply_to_screen_name" : "alicehive_de",
  "in_reply_to_user_id_str" : "17261685",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1199674207",
  "text" : "Nun auf dem Weg zum TweetUp!",
  "id" : 1199674207,
  "created_at" : "2009-02-11 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "muenster",
      "indices" : [ 46, 55 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1199723309",
  "text" : "Bin wohl der erste. Setze mich schonmal rein! #muenster",
  "id" : 1199723309,
  "created_at" : "2009-02-11 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Martin Labuschin",
      "screen_name" : "Labuschin",
      "indices" : [ 0, 10 ],
      "id_str" : "1024351",
      "id" : 1024351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1199769149",
  "in_reply_to_user_id" : 1024351,
  "text" : "@Labuschin schau mal nach Links wer schon drin sitzt ;)",
  "id" : 1199769149,
  "created_at" : "2009-02-11 00:00:00 +0000",
  "in_reply_to_screen_name" : "Labuschin",
  "in_reply_to_user_id_str" : "1024351",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1194880445",
  "text" : "Moin moin!",
  "id" : 1194880445,
  "created_at" : "2009-02-10 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1194952626",
  "text" : "Zigarettenpause (wovon eigentlich Pause?) und dann zum Jugendamt. Die Pfadfinder wollen Geld f\u00FCr Kanus.",
  "id" : 1194952626,
  "created_at" : "2009-02-10 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1195060976",
  "text" : "Ist Twittern per SMS irgendwas neues? Das ging doch immer schon?",
  "id" : 1195060976,
  "created_at" : "2009-02-10 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Houellebeck",
      "screen_name" : "houellebeck",
      "indices" : [ 0, 12 ],
      "id_str" : "107803659",
      "id" : 107803659
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1195074827",
  "text" : "@houellebeck Ah, okay. Das hab ich dann auch zwecks iPhone nicht weiter verfolgt ;)",
  "id" : 1195074827,
  "created_at" : "2009-02-10 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1195077945",
  "text" : "Endlich finde ich mal Zeit wieder in der Nature zu lesen und nicht nur durchzubl\u00E4ttern! Vielleicht f\u00E4llt auch mal wieder ein Post ab.",
  "id" : 1195077945,
  "created_at" : "2009-02-10 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Linksicht",
      "screen_name" : "Linksicht",
      "indices" : [ 0, 10 ],
      "id_str" : "14879980",
      "id" : 14879980
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1195090901",
  "geo" : { },
  "id_str" : "1195093267",
  "in_reply_to_user_id" : 14879980,
  "text" : "@Linksicht Das Tweets per SMS senden ging immer, halt \u00FCber die ausl\u00E4ndische Nummer.",
  "id" : 1195093267,
  "in_reply_to_status_id" : 1195090901,
  "created_at" : "2009-02-10 00:00:00 +0000",
  "in_reply_to_screen_name" : "Linksicht",
  "in_reply_to_user_id_str" : "14879980",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "muenster",
      "indices" : [ 78, 87 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1195103651",
  "text" : "Morgen Abend, 19 Uhr Spontan-TweetUp M\u00FCnster im Extrablatt am Ludgerikreisel. #muenster http:\/\/twtvite.com\/qssryq",
  "id" : 1195103651,
  "created_at" : "2009-02-10 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Florian Freistetter",
      "screen_name" : "astrodicticum",
      "indices" : [ 0, 14 ],
      "id_str" : "15318271",
      "id" : 15318271
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1195115898",
  "geo" : { },
  "id_str" : "1195122388",
  "in_reply_to_user_id" : 15318271,
  "text" : "@astrodicticum Wieso kriegt ihr Astronomen hier eigentlich den ganzen Spass. Die armen lokalen Evolutionsbiologen gehen ganz leer aus ;)",
  "id" : 1195122388,
  "in_reply_to_status_id" : 1195115898,
  "created_at" : "2009-02-10 00:00:00 +0000",
  "in_reply_to_screen_name" : "astrodicticum",
  "in_reply_to_user_id_str" : "15318271",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1195126398",
  "text" : "Ich hab mir sogar den Admin-Link f\u00FCr twtvite gespeichert. Kann also falsch gesetzte Leute noch \u00E4ndern ;)",
  "id" : 1195126398,
  "created_at" : "2009-02-10 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Florian Freistetter",
      "screen_name" : "astrodicticum",
      "indices" : [ 0, 14 ],
      "id_str" : "15318271",
      "id" : 15318271
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1195127301",
  "geo" : { },
  "id_str" : "1195134897",
  "in_reply_to_user_id" : 15318271,
  "text" : "@astrodicticum Ist das nicht das Gleiche was nur unter verschiedenem Namen firmiert? ;)",
  "id" : 1195134897,
  "in_reply_to_status_id" : 1195127301,
  "created_at" : "2009-02-10 00:00:00 +0000",
  "in_reply_to_screen_name" : "astrodicticum",
  "in_reply_to_user_id_str" : "15318271",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1195247202",
  "text" : "Endlich mal wieder ein W&W-Post - Wie beeinflussen wir die Evolution: http:\/\/tinyurl.com\/cbqadc",
  "id" : 1195247202,
  "created_at" : "2009-02-10 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1195273939",
  "text" : "Anh\u00E4ngliches Baby :) http:\/\/twitpic.com\/1f0w2",
  "id" : 1195273939,
  "created_at" : "2009-02-10 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1195621899",
  "text" : "Ist das entspannt mal wieder ganz in Ruhe ein paar spannende Paper lesen k\u00F6nnen. Und auch was dar\u00FCber schreiben zu k\u00F6nnen.",
  "id" : 1195621899,
  "created_at" : "2009-02-10 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1195796557",
  "text" : "Zu lange gewartet mit dem Spaziergang.Schneeregen erwischt.Hund& ich sehen aus wie Sau.Ich war bl\u00F6d genug sauber angezogen zu sein.er nicht.",
  "id" : 1195796557,
  "created_at" : "2009-02-10 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1195811929",
  "text" : "Nun in Jogginghose rumgammeln, alle anderen Hosen sind ja mitterweile auch dreckig und\/oder nass.",
  "id" : 1195811929,
  "created_at" : "2009-02-10 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1196046590",
  "text" : "Ein bisschen mehr (aber wirklich nur ein bisschen) als 140 Zeichen von mir zum iLife09-Update: http:\/\/tinyurl.com\/d8f4dv",
  "id" : 1196046590,
  "created_at" : "2009-02-10 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Houellebeck",
      "screen_name" : "houellebeck",
      "indices" : [ 0, 12 ],
      "id_str" : "107803659",
      "id" : 107803659
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1196050454",
  "text" : "@houellebeck Na Hauptsache du schaffst es morgen zum TweetUp ;)",
  "id" : 1196050454,
  "created_at" : "2009-02-10 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stefan",
      "screen_name" : "stelten",
      "indices" : [ 0, 8 ],
      "id_str" : "14082615",
      "id" : 14082615
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1196079657",
  "geo" : { },
  "id_str" : "1196086024",
  "in_reply_to_user_id" : 14082615,
  "text" : "@stelten In der Tat: http:\/\/twtvite.com\/qssryq Haben wir aber auch heute Mittag erst er\u00F6ffnet :)",
  "id" : 1196086024,
  "in_reply_to_status_id" : 1196079657,
  "created_at" : "2009-02-10 00:00:00 +0000",
  "in_reply_to_screen_name" : "stelten",
  "in_reply_to_user_id_str" : "14082615",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stefan",
      "screen_name" : "stelten",
      "indices" : [ 0, 8 ],
      "id_str" : "14082615",
      "id" : 14082615
    }, {
      "name" : "Houellebeck",
      "screen_name" : "houellebeck",
      "indices" : [ 35, 47 ],
      "id_str" : "107803659",
      "id" : 107803659
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1196120274",
  "in_reply_to_user_id" : 14082615,
  "text" : "@stelten War ja auch ganz spontan. @houellebeck und ich wollten unser Treffen noch nachholen was beim letzten mal nicht geklappt hat.",
  "id" : 1196120274,
  "created_at" : "2009-02-10 00:00:00 +0000",
  "in_reply_to_screen_name" : "stelten",
  "in_reply_to_user_id_str" : "14082615",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TillaPe",
      "screen_name" : "TillaPe",
      "indices" : [ 0, 8 ],
      "id_str" : "14623695",
      "id" : 14623695
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1196162637",
  "geo" : { },
  "id_str" : "1196171686",
  "in_reply_to_user_id" : 14623695,
  "text" : "@TillaPe Hier. Fotos und so ;)",
  "id" : 1196171686,
  "in_reply_to_status_id" : 1196162637,
  "created_at" : "2009-02-10 00:00:00 +0000",
  "in_reply_to_screen_name" : "TillaPe",
  "in_reply_to_user_id_str" : "14623695",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TillaPe",
      "screen_name" : "TillaPe",
      "indices" : [ 0, 8 ],
      "id_str" : "14623695",
      "id" : 14623695
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1196178831",
  "geo" : { },
  "id_str" : "1196424268",
  "in_reply_to_user_id" : 14623695,
  "text" : "@TillaPe nur digital",
  "id" : 1196424268,
  "in_reply_to_status_id" : 1196178831,
  "created_at" : "2009-02-10 00:00:00 +0000",
  "in_reply_to_screen_name" : "TillaPe",
  "in_reply_to_user_id_str" : "14623695",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1196563653",
  "text" : "Abendessen und danach vor die Glotze",
  "id" : 1196563653,
  "created_at" : "2009-02-10 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Oliver Koch",
      "screen_name" : "okomuenster",
      "indices" : [ 0, 12 ],
      "id_str" : "10912532",
      "id" : 10912532
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1196566632",
  "geo" : { },
  "id_str" : "1196582670",
  "in_reply_to_user_id" : 10912532,
  "text" : "@okomuenster Gute Frage ob man den Twittertisch erkennen wird. Die Leute mit dem kleinen Vogel auf der Schulter? ;)",
  "id" : 1196582670,
  "in_reply_to_status_id" : 1196566632,
  "created_at" : "2009-02-10 00:00:00 +0000",
  "in_reply_to_screen_name" : "okomuenster",
  "in_reply_to_user_id_str" : "10912532",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1196610451",
  "text" : "Angeblich spielt Deutschland morgen. Und ich weiss nichtmal was!",
  "id" : 1196610451,
  "created_at" : "2009-02-10 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1197056728",
  "text" : "Gute Nacht!",
  "id" : 1197056728,
  "created_at" : "2009-02-10 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Florian Freistetter",
      "screen_name" : "astrodicticum",
      "indices" : [ 0, 14 ],
      "id_str" : "15318271",
      "id" : 15318271
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1192661690",
  "geo" : { },
  "id_str" : "1192670907",
  "in_reply_to_user_id" : 15318271,
  "text" : "@astrodicticum Anfeuchten reicht doch an sich um das Loch zu finden. Wird auch kleine Blasen werfen.",
  "id" : 1192670907,
  "in_reply_to_status_id" : 1192661690,
  "created_at" : "2009-02-09 00:00:00 +0000",
  "in_reply_to_screen_name" : "astrodicticum",
  "in_reply_to_user_id_str" : "15318271",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Florian Freistetter",
      "screen_name" : "astrodicticum",
      "indices" : [ 0, 14 ],
      "id_str" : "15318271",
      "id" : 15318271
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1192676015",
  "geo" : { },
  "id_str" : "1192691038",
  "in_reply_to_user_id" : 15318271,
  "text" : "@astrodicticum Sonst leichtes Papier und schauen wo es vom Luftzug bewegt wird ist das gleiche f\u00FCr in Trocken ;)",
  "id" : 1192691038,
  "in_reply_to_status_id" : 1192676015,
  "created_at" : "2009-02-09 00:00:00 +0000",
  "in_reply_to_screen_name" : "astrodicticum",
  "in_reply_to_user_id_str" : "15318271",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1192441263",
  "geo" : { },
  "id_str" : "1192700999",
  "in_reply_to_user_id" : 17904767,
  "text" : "@Causa_Motiva iPhoto ist so weit ganz nett. Bietet mir aber zu wenig Features bzw. ich w\u00FCrde darin nur ungerne 40k Fotos verwalten m\u00FCssen.",
  "id" : 1192700999,
  "in_reply_to_status_id" : 1192441263,
  "created_at" : "2009-02-09 00:00:00 +0000",
  "in_reply_to_screen_name" : "SteterTropfen",
  "in_reply_to_user_id_str" : "17904767",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Florian Freistetter",
      "screen_name" : "astrodicticum",
      "indices" : [ 0, 14 ],
      "id_str" : "15318271",
      "id" : 15318271
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1192687746",
  "geo" : { },
  "id_str" : "1192703631",
  "in_reply_to_user_id" : 15318271,
  "text" : "@astrodicticum So ein riesen \u201CG\u00E4stebett\u201D? Irgendwo an der Naht aufgegangen? Dann wirds nicht so h\u00FCbsch mit dem Flicken?",
  "id" : 1192703631,
  "in_reply_to_status_id" : 1192687746,
  "created_at" : "2009-02-09 00:00:00 +0000",
  "in_reply_to_screen_name" : "astrodicticum",
  "in_reply_to_user_id_str" : "15318271",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Florian Freistetter",
      "screen_name" : "astrodicticum",
      "indices" : [ 0, 14 ],
      "id_str" : "15318271",
      "id" : 15318271
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1192709596",
  "geo" : { },
  "id_str" : "1192731019",
  "in_reply_to_user_id" : 15318271,
  "text" : "@astrodicticum Hast du Gummib\u00E4rchen im Haus? Mit etwas Wasser erhitzt ergeben die einen super Klebstoff :)",
  "id" : 1192731019,
  "in_reply_to_status_id" : 1192709596,
  "created_at" : "2009-02-09 00:00:00 +0000",
  "in_reply_to_screen_name" : "astrodicticum",
  "in_reply_to_user_id_str" : "15318271",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Florian Freistetter",
      "screen_name" : "astrodicticum",
      "indices" : [ 0, 14 ],
      "id_str" : "15318271",
      "id" : 15318271
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1192741216",
  "geo" : { },
  "id_str" : "1192751750",
  "in_reply_to_user_id" : 15318271,
  "text" : "@astrodicticum http:\/\/www.tivi.de\/fernsehen\/12oder3\/artikel\/10838\/index.html :P",
  "id" : 1192751750,
  "in_reply_to_status_id" : 1192741216,
  "created_at" : "2009-02-09 00:00:00 +0000",
  "in_reply_to_screen_name" : "astrodicticum",
  "in_reply_to_user_id_str" : "15318271",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Florian Freistetter",
      "screen_name" : "astrodicticum",
      "indices" : [ 0, 14 ],
      "id_str" : "15318271",
      "id" : 15318271
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1192741216",
  "geo" : { },
  "id_str" : "1192777366",
  "in_reply_to_user_id" : 15318271,
  "text" : "@astrodicticum au\u00DFerdem k\u00F6nnte das Karamel aus Mars auch als Klebstoff taugen ;)",
  "id" : 1192777366,
  "in_reply_to_status_id" : 1192741216,
  "created_at" : "2009-02-09 00:00:00 +0000",
  "in_reply_to_screen_name" : "astrodicticum",
  "in_reply_to_user_id_str" : "15318271",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Florian Freistetter",
      "screen_name" : "astrodicticum",
      "indices" : [ 0, 14 ],
      "id_str" : "15318271",
      "id" : 15318271
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1193249039",
  "geo" : { },
  "id_str" : "1193358411",
  "in_reply_to_user_id" : 15318271,
  "text" : "@astrodicticum hast du den selfmade Kleber getestet? ;)",
  "id" : 1193358411,
  "in_reply_to_status_id" : 1193249039,
  "created_at" : "2009-02-09 00:00:00 +0000",
  "in_reply_to_screen_name" : "astrodicticum",
  "in_reply_to_user_id_str" : "15318271",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1193411436",
  "text" : "Nachdem er seinen Teddy komplett zerlegt hat kuschelt er nun mit dem Pferd http:\/\/twitpic.com\/1ero9",
  "id" : 1193411436,
  "created_at" : "2009-02-09 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1191347484",
  "text" : "Zeit f\u00FCr Kaffee. Den ersten Tag der Semesterferien genie\u00DFen!",
  "id" : 1191347484,
  "created_at" : "2009-02-09 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "herr_schrat",
      "screen_name" : "herr_schrat",
      "indices" : [ 0, 12 ],
      "id_str" : "16066591",
      "id" : 16066591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1191351193",
  "geo" : { },
  "id_str" : "1191443221",
  "in_reply_to_user_id" : 16066591,
  "text" : "@herr_schrat danke! Werd ich haben :)",
  "id" : 1191443221,
  "in_reply_to_status_id" : 1191351193,
  "created_at" : "2009-02-09 00:00:00 +0000",
  "in_reply_to_screen_name" : "herr_schrat",
  "in_reply_to_user_id_str" : "16066591",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kasa",
      "screen_name" : "paperama",
      "indices" : [ 0, 9 ],
      "id_str" : "6893982",
      "id" : 6893982
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1191353981",
  "geo" : { },
  "id_str" : "1191444643",
  "in_reply_to_user_id" : 16804711,
  "text" : "@paperama ich muss nicht unbedingt lange Schlafen. Dann hat man so wenig vom Tag.",
  "id" : 1191444643,
  "in_reply_to_status_id" : 1191353981,
  "created_at" : "2009-02-09 00:00:00 +0000",
  "in_reply_to_screen_name" : "kasaa",
  "in_reply_to_user_id_str" : "16804711",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1191508370",
  "text" : "Ich kenn da jemanden der gleich mal Nadel und Faden z\u00FCcken darf.  http:\/\/twitpic.com\/1eir7",
  "id" : 1191508370,
  "created_at" : "2009-02-09 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1191519579",
  "text" : "\u201CIch m\u00F6chte nicht, das meine Fotos in irgendeiner Wohnung h\u00E4ngen, ohne das ich gefragt werde!\u201D- Ich f\u00E4nds cool wenn meine h\u00E4ngen w\u00FCrden.",
  "id" : 1191519579,
  "created_at" : "2009-02-09 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1191581690",
  "text" : "Nun werd ich mal wieder etwas weiter am Client schreiben.",
  "id" : 1191581690,
  "created_at" : "2009-02-09 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "muenster",
      "indices" : [ 17, 26 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1191633121",
  "text" : "Das Wachstum von #muenster stagniert etwas oder?",
  "id" : 1191633121,
  "created_at" : "2009-02-09 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1191744131",
  "text" : "Schauen wir mal ob der Client auch senden kann :)",
  "id" : 1191744131,
  "created_at" : "2009-02-09 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1191747210",
  "text" : "Sehr sch\u00F6n. FriendsTimeline, Replies, dms & Statusupdates senden geht.",
  "id" : 1191747210,
  "created_at" : "2009-02-09 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1191776747",
  "geo" : { },
  "id_str" : "1191789884",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod Stimmt, aber kein Fehler. Weil daf\u00FCr muss man sich an Twitter wenden mit einem Link zur Programmseite. Hab ich nicht.",
  "id" : 1191789884,
  "in_reply_to_status_id" : 1191776747,
  "created_at" : "2009-02-09 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1191805958",
  "geo" : { },
  "id_str" : "1191812512",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod Doch einen mit der Basisfunktionalit\u00E4t die auch die Seite bietet, nur einen von dem Twitter nix weiss. Also psst :P",
  "id" : 1191812512,
  "in_reply_to_status_id" : 1191805958,
  "created_at" : "2009-02-09 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stefan",
      "screen_name" : "stelten",
      "indices" : [ 0, 8 ],
      "id_str" : "14082615",
      "id" : 14082615
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "muenster",
      "indices" : [ 26, 35 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1191906291",
  "geo" : { },
  "id_str" : "1191916497",
  "in_reply_to_user_id" : 14082615,
  "text" : "@stelten Ich f\u00E4nds Prima! #muenster",
  "id" : 1191916497,
  "in_reply_to_status_id" : 1191906291,
  "created_at" : "2009-02-09 00:00:00 +0000",
  "in_reply_to_screen_name" : "stelten",
  "in_reply_to_user_id_str" : "14082615",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stefan",
      "screen_name" : "stelten",
      "indices" : [ 0, 8 ],
      "id_str" : "14082615",
      "id" : 14082615
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "muenster",
      "indices" : [ 88, 97 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1191930097",
  "geo" : { },
  "id_str" : "1191944299",
  "in_reply_to_user_id" : 14082615,
  "text" : "@stelten Na dann schlag doch mal einen Termin vor. Ich hab ja nun alle Zeit der Welt :) #muenster",
  "id" : 1191944299,
  "in_reply_to_status_id" : 1191930097,
  "created_at" : "2009-02-09 00:00:00 +0000",
  "in_reply_to_screen_name" : "stelten",
  "in_reply_to_user_id_str" : "14082615",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1192254555",
  "text" : "Der 13 j\u00E4hrige, rum\u00E4nische Ex-Stra\u00DFenhund ist der alten Dame letzten Monat verstorben,Nierenversagen.Nun geht sie jeden Nachmittag allein...",
  "id" : 1192254555,
  "created_at" : "2009-02-09 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1192368499",
  "text" : "Ach, ist iLife nun heute doch endlich mal angekommen. Wurde auch mehr als Zeit.",
  "id" : 1192368499,
  "created_at" : "2009-02-09 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1192421221",
  "geo" : { },
  "id_str" : "1192432534",
  "in_reply_to_user_id" : 17904767,
  "text" : "@Causa_Motiva Werd ich machen sobald ich es ausprobiert habe. Was interessiert dich denn besonders? :)",
  "id" : 1192432534,
  "in_reply_to_status_id" : 1192421221,
  "created_at" : "2009-02-09 00:00:00 +0000",
  "in_reply_to_screen_name" : "SteterTropfen",
  "in_reply_to_user_id_str" : "17904767",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1192441263",
  "geo" : { },
  "id_str" : "1192451020",
  "in_reply_to_user_id" : 17904767,
  "text" : "@Causa_Motiva Ok, werd ich dann ausnahmsweise doch mal mit rumspielen :)",
  "id" : 1192451020,
  "in_reply_to_status_id" : 1192441263,
  "created_at" : "2009-02-09 00:00:00 +0000",
  "in_reply_to_screen_name" : "SteterTropfen",
  "in_reply_to_user_id_str" : "17904767",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1192546331",
  "text" : "iMovie macht bislang einen guten Eindruck. Die Gitarreneffekte f\u00FCr GarageBand auch. Gerade lade ich mal ein paar Fotos in iPhoto zum testen",
  "id" : 1192546331,
  "created_at" : "2009-02-09 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1192602604",
  "text" : "Bildstabilisierungsfeature von iMovie funktioniert echt super. Und das Gesichter taggen in iPhoto ist nett. Leider ist iPhoto sonst schwach",
  "id" : 1192602604,
  "created_at" : "2009-02-09 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Florian Freistetter",
      "screen_name" : "astrodicticum",
      "indices" : [ 0, 14 ],
      "id_str" : "15318271",
      "id" : 15318271
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1192636101",
  "geo" : { },
  "id_str" : "1192665718",
  "in_reply_to_user_id" : 15318271,
  "text" : "@astrodicticum Wie w\u00E4re es mit dem feuchten Fahrradschlauchtrick? ;)",
  "id" : 1192665718,
  "in_reply_to_status_id" : 1192636101,
  "created_at" : "2009-02-09 00:00:00 +0000",
  "in_reply_to_screen_name" : "astrodicticum",
  "in_reply_to_user_id_str" : "15318271",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1188572351",
  "text" : "Das war mal lange geschlafen. Versuch das Defizit der letzten beiden Wochen reinzuholen gescheitert. F\u00FChle mich nur wie ger\u00E4dert.",
  "id" : 1188572351,
  "created_at" : "2009-02-08 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "eckert annette",
      "screen_name" : "offenbahrung",
      "indices" : [ 82, 95 ],
      "id_str" : "366995566",
      "id" : 366995566
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1188589762",
  "text" : "Wieso werde ich eigentlich von so nem Quatsch wie der christlichen Propaganda von @offenbahrung gefollowt?",
  "id" : 1188589762,
  "created_at" : "2009-02-08 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1188593226",
  "text" : "Mit ohne H nat\u00FCrlich.",
  "id" : 1188593226,
  "created_at" : "2009-02-08 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1188607929",
  "geo" : { },
  "id_str" : "1188609856",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod vermutlich zweiteres ;)",
  "id" : 1188609856,
  "in_reply_to_status_id" : 1188607929,
  "created_at" : "2009-02-08 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1188618081",
  "geo" : { },
  "id_str" : "1188626764",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod Wobei kombinieren die das nicht? Wird man auf dem Scheiterhaufen nicht automatisch bekehrt?",
  "id" : 1188626764,
  "in_reply_to_status_id" : 1188618081,
  "created_at" : "2009-02-08 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1188702553",
  "text" : "Neuer Blogpost - Filmabend mit Be Kind Rewind & Bis zum Ellenbogen: http:\/\/tinyurl.com\/dddpaa",
  "id" : 1188702553,
  "created_at" : "2009-02-08 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1188771565",
  "text" : "Genug mit der Twitter-API in Python rumgespielt. Nun erstmal Fr\u00FChst\u00FCck\/Mittagessen.",
  "id" : 1188771565,
  "created_at" : "2009-02-08 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Houellebeck",
      "screen_name" : "houellebeck",
      "indices" : [ 0, 12 ],
      "id_str" : "107803659",
      "id" : 107803659
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1188834071",
  "text" : "@houellebeck Also in Greven scheint noch die Sonne ;)",
  "id" : 1188834071,
  "created_at" : "2009-02-08 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Houellebeck",
      "screen_name" : "houellebeck",
      "indices" : [ 0, 12 ],
      "id_str" : "107803659",
      "id" : 107803659
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1188862828",
  "text" : "@houellebeck Keine Angst, bin schon geb\u00FCrtiger M\u00FCnsteraner. Hab nur meine Kindheit in Greven verbracht wo auch meine Eltern noch wohnen. :)",
  "id" : 1188862828,
  "created_at" : "2009-02-08 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1188952920",
  "text" : "Ich bastel weiter meinen Kommandozeilen-Client f\u00FCr Twitter",
  "id" : 1188952920,
  "created_at" : "2009-02-08 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0627\u0633\u0645\u0631\u0627\u0646\u064A \u0645\u0632\u064A\u0648\u0646",
      "screen_name" : "danishkirel",
      "indices" : [ 0, 12 ],
      "id_str" : "3393171664",
      "id" : 3393171664
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1189173102",
  "text" : "@danishkirel ich m\u00F6chte gern selber schreiben um in \u00DCbung zu bleiben :)",
  "id" : 1189173102,
  "created_at" : "2009-02-08 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "patschnass",
      "indices" : [ 75, 86 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1189320153",
  "text" : "Verdammt! Was f\u00E4ngt es in Greven ausgerechnet jetzt an zu schneien wie Sau #patschnass",
  "id" : 1189320153,
  "created_at" : "2009-02-08 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1189475995",
  "text" : "Wie cool w\u00E4re es denn wenn Twitter endlich mal wirklich gelesene Tweets kennen w\u00FCrde :(",
  "id" : 1189475995,
  "created_at" : "2009-02-08 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1189480349",
  "text" : "Gutes Liedermachertum \u266B http:\/\/blip.fm\/~22m9o",
  "id" : 1189480349,
  "created_at" : "2009-02-08 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0627\u0633\u0645\u0631\u0627\u0646\u064A \u0645\u0632\u064A\u0648\u0646",
      "screen_name" : "danishkirel",
      "indices" : [ 0, 12 ],
      "id_str" : "3393171664",
      "id" : 3393171664
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1189563165",
  "text" : "@danishkirel Das ist ja das Problem des Grundkonzepts. Tweets die ich bereits einmal an den User ausgeliefert habe k\u00F6nnten als gelesen z\u00E4hln",
  "id" : 1189563165,
  "created_at" : "2009-02-08 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0627\u0633\u0645\u0631\u0627\u0646\u064A \u0645\u0632\u064A\u0648\u0646",
      "screen_name" : "danishkirel",
      "indices" : [ 0, 12 ],
      "id_str" : "3393171664",
      "id" : 3393171664
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1189594325",
  "text" : "@danishkirel Ein R\u00FCckkanal w\u00E4re halt nicht schlecht. Sonst funktioniert das \"gelesen\" ja nur innerhalb einer App per Zeit oder Tweet-ID",
  "id" : 1189594325,
  "created_at" : "2009-02-08 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1189615377",
  "text" : "Das hier wird nur ein kleiner Test. Nicht st\u00F6ren lassen",
  "id" : 1189615377,
  "created_at" : "2009-02-08 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "herr_schrat",
      "screen_name" : "herr_schrat",
      "indices" : [ 0, 12 ],
      "id_str" : "16066591",
      "id" : 16066591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1189617418",
  "geo" : { },
  "id_str" : "1189619182",
  "in_reply_to_user_id" : 16066591,
  "text" : "@herr_schrat Japs tu ich :)",
  "id" : 1189619182,
  "in_reply_to_status_id" : 1189617418,
  "created_at" : "2009-02-08 00:00:00 +0000",
  "in_reply_to_screen_name" : "herr_schrat",
  "in_reply_to_user_id_str" : "16066591",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "herr_schrat",
      "screen_name" : "herr_schrat",
      "indices" : [ 0, 12 ],
      "id_str" : "16066591",
      "id" : 16066591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1189620339",
  "geo" : { },
  "id_str" : "1189634211",
  "in_reply_to_user_id" : 16066591,
  "text" : "@herr_schrat Naja das Updaten hab ich noch nicht, bislang arbeite ich am Abfragen der neuen Tweets :)",
  "id" : 1189634211,
  "in_reply_to_status_id" : 1189620339,
  "created_at" : "2009-02-08 00:00:00 +0000",
  "in_reply_to_screen_name" : "herr_schrat",
  "in_reply_to_user_id_str" : "16066591",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0627\u0633\u0645\u0631\u0627\u0646\u064A \u0645\u0632\u064A\u0648\u0646",
      "screen_name" : "danishkirel",
      "indices" : [ 0, 12 ],
      "id_str" : "3393171664",
      "id" : 3393171664
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1189643337",
  "text" : "@danishkirel Naja es w\u00FCrde den Traffic verdoppeln oder nicht? Alles was hingeht kommt zur\u00FCck. :)",
  "id" : 1189643337,
  "created_at" : "2009-02-08 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1189691658",
  "text" : "So, also die Friendstimeline habe ich nun schonmal geparst bekommen. Und er zeigt nur im Programm ungelesene an.",
  "id" : 1189691658,
  "created_at" : "2009-02-08 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1186821075",
  "text" : "Nun kommt der Reboot. Bislang sieht auch das noch gut aus.",
  "id" : 1186821075,
  "created_at" : "2009-02-07 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1186845011",
  "text" : "Wunderbar, das frisch aufgespielte Ubuntu funktioniert einwandfrei.",
  "id" : 1186845011,
  "created_at" : "2009-02-07 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Herr Rensch",
      "screen_name" : "arensch",
      "indices" : [ 0, 8 ],
      "id_str" : "14725887",
      "id" : 14725887
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1186827159",
  "geo" : { },
  "id_str" : "1186846494",
  "in_reply_to_user_id" : 14725887,
  "text" : "@arensch Zahlst du noch fleissig? ;)",
  "id" : 1186846494,
  "in_reply_to_status_id" : 1186827159,
  "created_at" : "2009-02-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "arensch",
  "in_reply_to_user_id_str" : "14725887",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Herr Rensch",
      "screen_name" : "arensch",
      "indices" : [ 0, 8 ],
      "id_str" : "14725887",
      "id" : 14725887
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1186856179",
  "geo" : { },
  "id_str" : "1186871470",
  "in_reply_to_user_id" : 14725887,
  "text" : "@arensch Aaah, es ging noch um die Fussball-Sache. Dachte du h\u00E4ttest zum Kirchenbash geantwortet. TwitterFox zeigt ja nicht worauf ge@ wurde",
  "id" : 1186871470,
  "in_reply_to_status_id" : 1186856179,
  "created_at" : "2009-02-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "arensch",
  "in_reply_to_user_id_str" : "14725887",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1186873117",
  "text" : "Gleich wird \u201CBe Kind, Rewind\u201D und \u201CBis zum Ellenbogen\u201D geschaut.",
  "id" : 1186873117,
  "created_at" : "2009-02-07 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1186879450",
  "text" : "Und jetzt noch mal das Thinkpad versch\u00F6nert ;) http:\/\/twitpic.com\/1dijz",
  "id" : 1186879450,
  "created_at" : "2009-02-07 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Herr Rensch",
      "screen_name" : "arensch",
      "indices" : [ 0, 8 ],
      "id_str" : "14725887",
      "id" : 14725887
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1186881645",
  "geo" : { },
  "id_str" : "1186892686",
  "in_reply_to_user_id" : 14725887,
  "text" : "@arensch Du hast aber nicht Twitter vollgespammt mit jedem Spielzug. :)",
  "id" : 1186892686,
  "in_reply_to_status_id" : 1186881645,
  "created_at" : "2009-02-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "arensch",
  "in_reply_to_user_id_str" : "14725887",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1186884838",
  "geo" : { },
  "id_str" : "1186894531",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod Mir sind Menschen die Fehler machen und eingestehen k\u00F6nnen lieber als jene die einfach behaupten sie k\u00F6nnten keine machen...",
  "id" : 1186894531,
  "in_reply_to_status_id" : 1186884838,
  "created_at" : "2009-02-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1186983218",
  "text" : "Cool, es gibt ja Python-Libs f\u00FCr die Twitter-API. Damit werde ich morgen mal rumspielen.",
  "id" : 1186983218,
  "created_at" : "2009-02-07 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1185596587",
  "text" : "Guten Morgen *g\u00E4hn*",
  "id" : 1185596587,
  "created_at" : "2009-02-07 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1185623920",
  "text" : "Was fur eine unmenschliche Uhrzeit um am Wochenende schon aufzustehen.",
  "id" : 1185623920,
  "created_at" : "2009-02-07 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1185659940",
  "text" : "Kontaktliegen mit Charly zum wach werden.",
  "id" : 1185659940,
  "created_at" : "2009-02-07 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1185871831",
  "text" : "Mathe war ebenfalls Super. Nun FERIEN!!",
  "id" : 1185871831,
  "created_at" : "2009-02-07 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "herr_schrat",
      "screen_name" : "herr_schrat",
      "indices" : [ 0, 12 ],
      "id_str" : "16066591",
      "id" : 16066591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1185884085",
  "geo" : { },
  "id_str" : "1185905972",
  "in_reply_to_user_id" : 16066591,
  "text" : "@herr_schrat danke! Wei\u00DFt schon wann du kommst? :)",
  "id" : 1185905972,
  "in_reply_to_status_id" : 1185884085,
  "created_at" : "2009-02-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "herr_schrat",
  "in_reply_to_user_id_str" : "16066591",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Rosa",
      "screen_name" : "ritman77",
      "indices" : [ 0, 9 ],
      "id_str" : "800891891759710208",
      "id" : 800891891759710208
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1185917354",
  "geo" : { },
  "id_str" : "1185942326",
  "in_reply_to_user_id" : 14331140,
  "text" : "@ritman77 bei GEZ-Schreiben: Ignorieren.",
  "id" : 1185942326,
  "in_reply_to_status_id" : 1185917354,
  "created_at" : "2009-02-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "martinneuhof",
  "in_reply_to_user_id_str" : "14331140",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "herr_schrat",
      "screen_name" : "herr_schrat",
      "indices" : [ 0, 12 ],
      "id_str" : "16066591",
      "id" : 16066591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1185909318",
  "geo" : { },
  "id_str" : "1185942943",
  "in_reply_to_user_id" : 16066591,
  "text" : "@herr_schrat das ist ja Bl\u00F6d. Und wie schaut es mit Bahntickets aus?",
  "id" : 1185942943,
  "in_reply_to_status_id" : 1185909318,
  "created_at" : "2009-02-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "herr_schrat",
  "in_reply_to_user_id_str" : "16066591",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Rosa",
      "screen_name" : "ritman77",
      "indices" : [ 0, 9 ],
      "id_str" : "800891891759710208",
      "id" : 800891891759710208
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1185962578",
  "geo" : { },
  "id_str" : "1185967669",
  "in_reply_to_user_id" : 14331140,
  "text" : "@ritman77 Hier!",
  "id" : 1185967669,
  "in_reply_to_status_id" : 1185962578,
  "created_at" : "2009-02-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "martinneuhof",
  "in_reply_to_user_id_str" : "14331140",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Rosa",
      "screen_name" : "ritman77",
      "indices" : [ 0, 9 ],
      "id_str" : "800891891759710208",
      "id" : 800891891759710208
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1185968105",
  "geo" : { },
  "id_str" : "1185976763",
  "in_reply_to_user_id" : 14331140,
  "text" : "@ritman77 Gar nichts. T\u00FCr auf. Der \u201Cnette Herr\u201D hat sich vorgestellt. Danach T\u00FCr zu.",
  "id" : 1185976763,
  "in_reply_to_status_id" : 1185968105,
  "created_at" : "2009-02-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "martinneuhof",
  "in_reply_to_user_id_str" : "14331140",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Rosa",
      "screen_name" : "ritman77",
      "indices" : [ 0, 9 ],
      "id_str" : "800891891759710208",
      "id" : 800891891759710208
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1185968105",
  "geo" : { },
  "id_str" : "1185980703",
  "in_reply_to_user_id" : 14331140,
  "text" : "@ritman77 Du musst auf die Briefe nicht antworten (nach 3 Versuchen stellen sie das erstmal ein) und Dr\u00FCcker an der T\u00FCr haben keine Rechte.",
  "id" : 1185980703,
  "in_reply_to_status_id" : 1185968105,
  "created_at" : "2009-02-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "martinneuhof",
  "in_reply_to_user_id_str" : "14331140",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1186042823",
  "text" : "Je kleiner der Hund, desto weniger Ahnung haben die Halter von adequater Hundeerziehung bzw. normalem Sozialverhalten. Schrecklich",
  "id" : 1186042823,
  "created_at" : "2009-02-07 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1186104596",
  "text" : "Ich finde es sehr begr\u00FC\u00DFenswert wenn den Katholiken nun die Mitglieder reihenweise austreten. Nichts trifft das Pack h\u00E4rter.",
  "id" : 1186104596,
  "created_at" : "2009-02-07 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1186129932",
  "geo" : { },
  "id_str" : "1186136521",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod Klar, aber jetzt steigt die Aussteigerrate gerade an.",
  "id" : 1186136521,
  "in_reply_to_status_id" : 1186129932,
  "created_at" : "2009-02-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1186281158",
  "text" : "Ist das angenehm mal so gar nicht lernen zu m\u00FCssen!",
  "id" : 1186281158,
  "created_at" : "2009-02-07 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Markus",
      "screen_name" : "germanstudent",
      "indices" : [ 0, 14 ],
      "id_str" : "2493441",
      "id" : 2493441
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1186282745",
  "geo" : { },
  "id_str" : "1186291183",
  "in_reply_to_user_id" : 2493441,
  "text" : "@germanstudent Enschede? ;)",
  "id" : 1186291183,
  "in_reply_to_status_id" : 1186282745,
  "created_at" : "2009-02-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "germanstudent",
  "in_reply_to_user_id_str" : "2493441",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Markus",
      "screen_name" : "germanstudent",
      "indices" : [ 0, 14 ],
      "id_str" : "2493441",
      "id" : 2493441
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1186294482",
  "geo" : { },
  "id_str" : "1186308899",
  "in_reply_to_user_id" : 2493441,
  "text" : "@germanstudent Daf\u00FCr ist der Wochenmarkt da um einiges cooler als in M\u00FCnster :)",
  "id" : 1186308899,
  "in_reply_to_status_id" : 1186294482,
  "created_at" : "2009-02-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "germanstudent",
  "in_reply_to_user_id_str" : "2493441",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Markus",
      "screen_name" : "germanstudent",
      "indices" : [ 0, 14 ],
      "id_str" : "2493441",
      "id" : 2493441
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1186298014",
  "geo" : { },
  "id_str" : "1186312619",
  "in_reply_to_user_id" : 2493441,
  "text" : "@germanstudent Und kommt man mit dem Studententicket nicht bis in den Ruhrpott? ;)",
  "id" : 1186312619,
  "in_reply_to_status_id" : 1186298014,
  "created_at" : "2009-02-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "germanstudent",
  "in_reply_to_user_id_str" : "2493441",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1186437264",
  "text" : "Werd nun mal versuchen Ubuntu auf dem alten Thinkpad neu aufzuspielen. Die Windoof-Partition kann ja nun weg",
  "id" : 1186437264,
  "created_at" : "2009-02-07 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Markus",
      "screen_name" : "germanstudent",
      "indices" : [ 0, 14 ],
      "id_str" : "2493441",
      "id" : 2493441
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1186461883",
  "in_reply_to_user_id" : 2493441,
  "text" : "@germanstudent Ach M\u00FCll, wie romantisch!",
  "id" : 1186461883,
  "created_at" : "2009-02-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "germanstudent",
  "in_reply_to_user_id_str" : "2493441",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1186485658",
  "text" : "Ich mach Twitter jetzt mal lieber aus. Die Fussball-Nazis sind ja nicht zum aushalten.",
  "id" : 1186485658,
  "created_at" : "2009-02-07 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1186571604",
  "text" : "8.04 ist installiert, das Upgrade auf 8.10 l\u00E4uft gerade.",
  "id" : 1186571604,
  "created_at" : "2009-02-07 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1186629527",
  "text" : "Bislang sieht auf dem Weg zur 8.10 in der Konsole alles gut aus. Bitte weiter so.",
  "id" : 1186629527,
  "created_at" : "2009-02-07 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Markus",
      "screen_name" : "germanstudent",
      "indices" : [ 0, 14 ],
      "id_str" : "2493441",
      "id" : 2493441
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1186690809",
  "geo" : { },
  "id_str" : "1186712877",
  "in_reply_to_user_id" : 2493441,
  "text" : "@germanstudent Ich mach mir daf\u00FCr gerade ein belegtes Baguette im Backofen warm :)",
  "id" : 1186712877,
  "in_reply_to_status_id" : 1186690809,
  "created_at" : "2009-02-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "germanstudent",
  "in_reply_to_user_id_str" : "2493441",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1186747894",
  "text" : "A-Team ftw!",
  "id" : 1186747894,
  "created_at" : "2009-02-07 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "idioten",
      "indices" : [ 132, 140 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1186777823",
  "geo" : { },
  "id_str" : "1186801709",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod Es ist unglaublich wie Menschen so ein System nur unterst\u00FCtzen k\u00F6nnen, sei es schon nicht moralisch sondern nur mit Geld... #idioten",
  "id" : 1186801709,
  "in_reply_to_status_id" : 1186777823,
  "created_at" : "2009-02-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jan Vanvinkenroye",
      "screen_name" : "jvanvinkenroye",
      "indices" : [ 0, 15 ],
      "id_str" : "4247301",
      "id" : 4247301
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1182856232",
  "geo" : { },
  "id_str" : "1182866625",
  "in_reply_to_user_id" : 4247301,
  "text" : "@jvanvinkenroye Von der Geschwindigkeit her passt das. Der Stealth-Modus klappt nur im dunklen. ;)",
  "id" : 1182866625,
  "in_reply_to_status_id" : 1182856232,
  "created_at" : "2009-02-06 00:00:00 +0000",
  "in_reply_to_screen_name" : "jvanvinkenroye",
  "in_reply_to_user_id_str" : "4247301",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1182867503",
  "text" : "Oh, ich seh gerade. Wenn man das \u00DF per Email an Twitpic sendet ist es weg.",
  "id" : 1182867503,
  "created_at" : "2009-02-06 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1182906385",
  "text" : "Mittagessen und danach dann mal Mathe lernen. Auf den Lorbeeren ausruhen ist nicht.",
  "id" : 1182906385,
  "created_at" : "2009-02-06 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1183036878",
  "text" : "So viel ist Mathe auch gar nicht.  http:\/\/twitpic.com\/1cqyw",
  "id" : 1183036878,
  "created_at" : "2009-02-06 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "netzpolitik",
      "screen_name" : "netzpolitik",
      "indices" : [ 4, 16 ],
      "id_str" : "9655032",
      "id" : 9655032
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1183169565",
  "text" : "RT: @netzpolitik: Widerstand ist zwecklos? Ganz im Gegenteil! Die Deutsche Bahn AG gibt auf!  http:\/\/bit.ly\/281Fvs",
  "id" : 1183169565,
  "created_at" : "2009-02-06 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1183202168",
  "geo" : { },
  "id_str" : "1183221688",
  "in_reply_to_user_id" : 8517622,
  "text" : "@lorXsion http:\/\/twitpic.com\/1cqyw Hab meine ganzen Uni-Sachen in Moleskines \u201Cgespeichert\u201D. Gro\u00DF\/Klein,LinieBlanko\/Karo, Normal\/Reporter :)",
  "id" : 1183221688,
  "in_reply_to_status_id" : 1183202168,
  "created_at" : "2009-02-06 00:00:00 +0000",
  "in_reply_to_screen_name" : "mitZett",
  "in_reply_to_user_id_str" : "8517622",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1183276690",
  "text" : "So 1 1\/2 B\u00FCcher habe ich schon durch.",
  "id" : 1183276690,
  "created_at" : "2009-02-06 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1183290709",
  "geo" : { },
  "id_str" : "1183306524",
  "in_reply_to_user_id" : 8517622,
  "text" : "@lorXsion Bleibt trotzdem noch genug zu tun :)",
  "id" : 1183306524,
  "in_reply_to_status_id" : 1183290709,
  "created_at" : "2009-02-06 00:00:00 +0000",
  "in_reply_to_screen_name" : "mitZett",
  "in_reply_to_user_id_str" : "8517622",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Milissa",
      "screen_name" : "pasqualle",
      "indices" : [ 0, 10 ],
      "id_str" : "2531726499",
      "id" : 2531726499
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1183455470",
  "text" : "@pasQualle Gibt es \u00FCberhaupt Gr\u00FCnde MatLab zu verwenden? :D",
  "id" : 1183455470,
  "created_at" : "2009-02-06 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1183473171",
  "text" : "Ich hab das Gef\u00FChl Apple hat iLife direkt aus Cupertino in einem Kanu auf den Weg geschickt...",
  "id" : 1183473171,
  "created_at" : "2009-02-06 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1183642690",
  "geo" : { },
  "id_str" : "1183673618",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod Angeblich sollte es schon vorgestern angekommen sein...",
  "id" : 1183673618,
  "in_reply_to_status_id" : 1183642690,
  "created_at" : "2009-02-06 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1183734840",
  "geo" : { },
  "id_str" : "1183774150",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod Japs. Und der Postbote war auch jeden Tag da. Allerdings ohne Software. :D",
  "id" : 1183774150,
  "in_reply_to_status_id" : 1183734840,
  "created_at" : "2009-02-06 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1183801638",
  "geo" : { },
  "id_str" : "1183834334",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod Zumindest f\u00FCr dich oder? ;)",
  "id" : 1183834334,
  "in_reply_to_status_id" : 1183801638,
  "created_at" : "2009-02-06 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1183836715",
  "text" : "Gerade erstmal mit dem Apple-Skript einen Wecker gebastelt der die lauteste Musik meiner iTunes-Lib abspielt. Sonst verschlaf ich morgen.",
  "id" : 1183836715,
  "created_at" : "2009-02-06 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "herr_schrat",
      "screen_name" : "herr_schrat",
      "indices" : [ 0, 12 ],
      "id_str" : "16066591",
      "id" : 16066591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1183839149",
  "geo" : { },
  "id_str" : "1183856857",
  "in_reply_to_user_id" : 16066591,
  "text" : "@herr_schrat Ich w\u00E4re nicht der erste der die Matheklausur aufgrund der b\u00F6sen Uhrzeit verschl\u00E4ft. Mir sind solche pers\u00F6nlich bekannt.",
  "id" : 1183856857,
  "in_reply_to_status_id" : 1183839149,
  "created_at" : "2009-02-06 00:00:00 +0000",
  "in_reply_to_screen_name" : "herr_schrat",
  "in_reply_to_user_id_str" : "16066591",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1183867342",
  "geo" : { },
  "id_str" : "1183870749",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod Ich freu mich schon ewig auf das neue Garageband, bin gespannt auf die Lern-Features.",
  "id" : 1183870749,
  "in_reply_to_status_id" : 1183867342,
  "created_at" : "2009-02-06 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "herr_schrat",
      "screen_name" : "herr_schrat",
      "indices" : [ 0, 12 ],
      "id_str" : "16066591",
      "id" : 16066591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1183859778",
  "geo" : { },
  "id_str" : "1183872925",
  "in_reply_to_user_id" : 16066591,
  "text" : "@herr_schrat In der letzten Matheklausur bekam ich mittendrin seine SMS mit \u201CHab total verpennt, lohnts wenn ich noch komme?\u201D",
  "id" : 1183872925,
  "in_reply_to_status_id" : 1183859778,
  "created_at" : "2009-02-06 00:00:00 +0000",
  "in_reply_to_screen_name" : "herr_schrat",
  "in_reply_to_user_id_str" : "16066591",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1183884713",
  "text" : "http:\/\/twitpic.com\/1cvcw - 2 1\/2 fertig. ~1 fehlt damit noch.",
  "id" : 1183884713,
  "created_at" : "2009-02-06 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "herr_schrat",
      "screen_name" : "herr_schrat",
      "indices" : [ 0, 12 ],
      "id_str" : "16066591",
      "id" : 16066591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1183877484",
  "geo" : { },
  "id_str" : "1183886077",
  "in_reply_to_user_id" : 16066591,
  "text" : "@herr_schrat Kommt drauf an welchen Dozenten man hat und welchen Rechner man benutzen darf ;)",
  "id" : 1183886077,
  "in_reply_to_status_id" : 1183877484,
  "created_at" : "2009-02-06 00:00:00 +0000",
  "in_reply_to_screen_name" : "herr_schrat",
  "in_reply_to_user_id_str" : "16066591",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1183881081",
  "geo" : { },
  "id_str" : "1183888044",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod Ich brauh das auch nicht, bin einfach nur neugierig :)",
  "id" : 1183888044,
  "in_reply_to_status_id" : 1183881081,
  "created_at" : "2009-02-06 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1183944740",
  "text" : "Nun kann ich auch mit dem iPhone ins Uni-Netz. Netter Service der Uni die passenden Profile zum Download anzubieten.",
  "id" : 1183944740,
  "created_at" : "2009-02-06 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1184582239",
  "text" : "Noch nicht ganz durch mit Mathe. Bl\u00F6d",
  "id" : 1184582239,
  "created_at" : "2009-02-06 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1184598854",
  "geo" : { },
  "id_str" : "1184609552",
  "in_reply_to_user_id" : 14965082,
  "text" : "@epihelix 10 ist doch okay, zumindest im Vergleich zu 8 :)",
  "id" : 1184609552,
  "in_reply_to_status_id" : 1184598854,
  "created_at" : "2009-02-06 00:00:00 +0000",
  "in_reply_to_screen_name" : "berggruen",
  "in_reply_to_user_id_str" : "14965082",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1184625350",
  "geo" : { },
  "id_str" : "1184646732",
  "in_reply_to_user_id" : 14965082,
  "text" : "@epihelix Daf\u00FCr werd ich keine Zeit haben :)",
  "id" : 1184646732,
  "in_reply_to_status_id" : 1184625350,
  "created_at" : "2009-02-06 00:00:00 +0000",
  "in_reply_to_screen_name" : "berggruen",
  "in_reply_to_user_id_str" : "14965082",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1184715204",
  "text" : "So, jetzt muss genug gelernt sein. Wenigstens noch 6 Stunden Schlaf kriegen. Gute Nacht!",
  "id" : 1184715204,
  "created_at" : "2009-02-06 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1182699684",
  "text" : "Guten Morgen  zusammen.",
  "id" : 1182699684,
  "created_at" : "2009-02-06 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1182750175",
  "text" : "Mittlerweile traut der Hund sich ins Bad w\u00E4hrend ich in der Wanne sitze. Merkt das Baden gar nicht b\u00F6se ist.",
  "id" : 1182750175,
  "created_at" : "2009-02-06 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1182853820",
  "text" : "http:\/\/twitpic.com\/1cq0j - So macht es draussen Spa",
  "id" : 1182853820,
  "created_at" : "2009-02-06 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Henrik M. Simensen",
      "screen_name" : "Henrikms",
      "indices" : [ 0, 9 ],
      "id_str" : "228005950",
      "id" : 228005950
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1179173517",
  "text" : "@henrikMS Man kann doch die Twitter-Updates als Facebook-Statusupdates einpflegen lassen.",
  "id" : 1179173517,
  "created_at" : "2009-02-05 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Henrik M. Simensen",
      "screen_name" : "Henrikms",
      "indices" : [ 0, 9 ],
      "id_str" : "228005950",
      "id" : 228005950
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1179179765",
  "text" : "@henrikMS Schau mal hier, ist einfach eine Facebook-App: http:\/\/tinyurl.com\/2zj72h",
  "id" : 1179179765,
  "created_at" : "2009-02-05 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1179232853",
  "text" : "Um 14 Uhr steht die Klausur an. Ist doch viel humaner als die Mathematiker die mich Samstag morgen um 8 sehen wollen.",
  "id" : 1179232853,
  "created_at" : "2009-02-05 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Houellebeck",
      "screen_name" : "houellebeck",
      "indices" : [ 0, 12 ],
      "id_str" : "107803659",
      "id" : 107803659
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1179376783",
  "text" : "@houellebeck Oder kann es einfach mit zusammengesetzten Worten umgehen? ;)",
  "id" : 1179376783,
  "created_at" : "2009-02-05 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1179494806",
  "geo" : { },
  "id_str" : "1179498444",
  "in_reply_to_user_id" : 8517622,
  "text" : "@lorXsion also bislang hab ich nie mehr als 300-500 mb durchgebracht. Nutze aber auch viel das WLAN.",
  "id" : 1179498444,
  "in_reply_to_status_id" : 1179494806,
  "created_at" : "2009-02-05 00:00:00 +0000",
  "in_reply_to_screen_name" : "mitZett",
  "in_reply_to_user_id_str" : "8517622",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1179558836",
  "geo" : { },
  "id_str" : "1179702294",
  "in_reply_to_user_id" : 8517622,
  "text" : "@lorXsion da hab ich die Konditionen nicht im Kopf. Hab ja einen alten Complete-Tarif.",
  "id" : 1179702294,
  "in_reply_to_status_id" : 1179558836,
  "created_at" : "2009-02-05 00:00:00 +0000",
  "in_reply_to_screen_name" : "mitZett",
  "in_reply_to_user_id_str" : "8517622",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1179708046",
  "geo" : { },
  "id_str" : "1179855448",
  "in_reply_to_user_id" : 8517622,
  "text" : "@lorXsion ich glaube wir beide haben auch ganz andere Anforderungen. Mir reichen 100 Freiminuten voll und ganz. Datenflat ist mir wichtiger.",
  "id" : 1179855448,
  "in_reply_to_status_id" : 1179708046,
  "created_at" : "2009-02-05 00:00:00 +0000",
  "in_reply_to_screen_name" : "mitZett",
  "in_reply_to_user_id_str" : "8517622",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fail",
      "indices" : [ 98, 103 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1179868228",
  "text" : "Super, Apple schickt mir Werbung f\u00FCr iLife09. Darauf warte ich ja auch erst seit ein paar Wochen. #fail",
  "id" : 1179868228,
  "created_at" : "2009-02-05 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1179897750",
  "in_reply_to_user_id" : 8517622,
  "text" : "@lorXsion Ok, also ich hab von der Drosselung nach 300 mb bislang noch nichts bemerkt. Und 500 Minuten reichen bei mir ja ein halbes Jahr ;)",
  "id" : 1179897750,
  "created_at" : "2009-02-05 00:00:00 +0000",
  "in_reply_to_screen_name" : "mitZett",
  "in_reply_to_user_id_str" : "8517622",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Markus Bertling",
      "screen_name" : "jayzon277",
      "indices" : [ 0, 10 ],
      "id_str" : "372320321",
      "id" : 372320321
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1179925586",
  "in_reply_to_user_id" : 14115883,
  "text" : "@jayzon277 @lorXsion Och da komme ich schon dr\u00FCber. Aber ich kann nicht sagen das man die Drosselung auf dem Ger\u00E4t merkt.",
  "id" : 1179925586,
  "created_at" : "2009-02-05 00:00:00 +0000",
  "in_reply_to_screen_name" : "HerrBertling",
  "in_reply_to_user_id_str" : "14115883",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1179985268",
  "in_reply_to_user_id" : 8517622,
  "text" : "@lorXsion So weit ich weiss wird dann auf ISDN-Geschwindigkeit gedrosselt. Was aber im Endeffekt f\u00FCr alle normalen Anwendungen nich auff\u00E4llt",
  "id" : 1179985268,
  "created_at" : "2009-02-05 00:00:00 +0000",
  "in_reply_to_screen_name" : "mitZett",
  "in_reply_to_user_id_str" : "8517622",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1179986627",
  "text" : "Oha, ab 18 Uhr gibt es die Ergebnisse der Klausur im Netz. Ich bin gespannt",
  "id" : 1179986627,
  "created_at" : "2009-02-05 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1179998905",
  "in_reply_to_user_id" : 8517622,
  "text" : "@lorXsion Ja, aber die Physiker lassen die Multiply-Choice-Klausuren auf Lottoscheinen machen die sie maschinell auswerten lassen.",
  "id" : 1179998905,
  "created_at" : "2009-02-05 00:00:00 +0000",
  "in_reply_to_screen_name" : "mitZett",
  "in_reply_to_user_id_str" : "8517622",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1180009331",
  "in_reply_to_user_id" : 8517622,
  "text" : "@lorXsion Ich bin allgemein nicht so Fan von Multiply Choice. Zu 95% nur auswendiggelerntes Ankreuzen. Uusammenh\u00E4nge werden nicht abgefragt.",
  "id" : 1180009331,
  "created_at" : "2009-02-05 00:00:00 +0000",
  "in_reply_to_screen_name" : "mitZett",
  "in_reply_to_user_id_str" : "8517622",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Houellebeck",
      "screen_name" : "houellebeck",
      "indices" : [ 0, 12 ],
      "id_str" : "107803659",
      "id" : 107803659
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1180022798",
  "text" : "@houellebeck Helge Schneider find ich total anstregend",
  "id" : 1180022798,
  "created_at" : "2009-02-05 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1180063042",
  "text" : "Yeah! Die Ergebnisse gibt es nun schon. Das Lernen hat sich gelohnt: 19\/20",
  "id" : 1180063042,
  "created_at" : "2009-02-05 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Houellebeck",
      "screen_name" : "houellebeck",
      "indices" : [ 0, 12 ],
      "id_str" : "107803659",
      "id" : 107803659
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1180088880",
  "text" : "@houellebeck Danke!",
  "id" : 1180088880,
  "created_at" : "2009-02-05 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1180097017",
  "in_reply_to_user_id" : 8517622,
  "text" : "@lorXsion Das dauert ja noch ein bisschen. Aber dann machen wir das Twitter-Bachelor-Treffen :)",
  "id" : 1180097017,
  "created_at" : "2009-02-05 00:00:00 +0000",
  "in_reply_to_screen_name" : "mitZett",
  "in_reply_to_user_id_str" : "8517622",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1180104599",
  "in_reply_to_user_id" : 8517622,
  "text" : "@lorXsion Ich w\u00FCrde sagen ja :)",
  "id" : 1180104599,
  "created_at" : "2009-02-05 00:00:00 +0000",
  "in_reply_to_screen_name" : "mitZett",
  "in_reply_to_user_id_str" : "8517622",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "thopex",
      "screen_name" : "thopex",
      "indices" : [ 0, 7 ],
      "id_str" : "6266362",
      "id" : 6266362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1180113153",
  "in_reply_to_user_id" : 6266362,
  "text" : "@thopex Auch dir vielen Dank! :)",
  "id" : 1180113153,
  "created_at" : "2009-02-05 00:00:00 +0000",
  "in_reply_to_screen_name" : "thopex",
  "in_reply_to_user_id_str" : "6266362",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1180114330",
  "text" : "Das Physikergebnis beruhigt mich zumindest ganz stark f\u00FCr die Mathe-Klausur am Samstag-Morgen :)",
  "id" : 1180114330,
  "created_at" : "2009-02-05 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1180122914",
  "in_reply_to_user_id" : 8517622,
  "text" : "@lorXsion Aber wir k\u00F6nnten schonmal wieder ein normales Twitter-Dinner planen finde ich. War sehr nett beim letzten mal.",
  "id" : 1180122914,
  "created_at" : "2009-02-05 00:00:00 +0000",
  "in_reply_to_screen_name" : "mitZett",
  "in_reply_to_user_id_str" : "8517622",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1180202614",
  "text" : "Jetzt mal eine Runde mit dem Hundi raus.",
  "id" : 1180202614,
  "created_at" : "2009-02-05 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Henning Sch\u00FCrig",
      "screen_name" : "hensch",
      "indices" : [ 0, 7 ],
      "id_str" : "3728881",
      "id" : 3728881
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1180266448",
  "geo" : { },
  "id_str" : "1180282478",
  "in_reply_to_user_id" : 3728881,
  "text" : "@hensch Meine Freundin hat eins, das SL500. Ist ein nettes Teil.",
  "id" : 1180282478,
  "in_reply_to_status_id" : 1180266448,
  "created_at" : "2009-02-05 00:00:00 +0000",
  "in_reply_to_screen_name" : "hensch",
  "in_reply_to_user_id_str" : "3728881",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1180401561",
  "text" : "Verdammt, schon wieder eine Colaflasche im Eisschrank vergessen!",
  "id" : 1180401561,
  "created_at" : "2009-02-05 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Markus",
      "screen_name" : "germanstudent",
      "indices" : [ 0, 14 ],
      "id_str" : "2493441",
      "id" : 2493441
    }, {
      "name" : "larsreineke",
      "screen_name" : "spitblog",
      "indices" : [ 47, 56 ],
      "id_str" : "19142360",
      "id" : 19142360
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1180413486",
  "geo" : { },
  "id_str" : "1180423464",
  "in_reply_to_user_id" : 2493441,
  "text" : "@germanstudent Gibt es doch schau mal hier was @spitblog gemacht hat, erf\u00FCllt genau was du willst: http:\/\/tinyurl.com\/b5hd7f",
  "id" : 1180423464,
  "in_reply_to_status_id" : 1180413486,
  "created_at" : "2009-02-05 00:00:00 +0000",
  "in_reply_to_screen_name" : "germanstudent",
  "in_reply_to_user_id_str" : "2493441",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Henning Sch\u00FCrig",
      "screen_name" : "hensch",
      "indices" : [ 0, 7 ],
      "id_str" : "3728881",
      "id" : 3728881
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1180664021",
  "geo" : { },
  "id_str" : "1180938303",
  "in_reply_to_user_id" : 3728881,
  "text" : "@hensch trackpoint und Trackpad haben sie.",
  "id" : 1180938303,
  "in_reply_to_status_id" : 1180664021,
  "created_at" : "2009-02-05 00:00:00 +0000",
  "in_reply_to_screen_name" : "hensch",
  "in_reply_to_user_id_str" : "3728881",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Henning Sch\u00FCrig",
      "screen_name" : "hensch",
      "indices" : [ 0, 7 ],
      "id_str" : "3728881",
      "id" : 3728881
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1180664021",
  "geo" : { },
  "id_str" : "1180982607",
  "in_reply_to_user_id" : 3728881,
  "text" : "@hensch Vermutlich heisst UltraNav nix anderes als \"Trackpoint + Trackpad\"",
  "id" : 1180982607,
  "in_reply_to_status_id" : 1180664021,
  "created_at" : "2009-02-05 00:00:00 +0000",
  "in_reply_to_screen_name" : "hensch",
  "in_reply_to_user_id_str" : "3728881",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MakMaksan",
      "screen_name" : "MakMaksan",
      "indices" : [ 0, 10 ],
      "id_str" : "17112939",
      "id" : 17112939
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1181202947",
  "geo" : { },
  "id_str" : "1181209258",
  "in_reply_to_user_id" : 17112939,
  "text" : "@MakMaksan mit Jailbreak ja. Sonst nein.",
  "id" : 1181209258,
  "in_reply_to_status_id" : 1181202947,
  "created_at" : "2009-02-05 00:00:00 +0000",
  "in_reply_to_screen_name" : "MakMaksan",
  "in_reply_to_user_id_str" : "17112939",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MakMaksan",
      "screen_name" : "MakMaksan",
      "indices" : [ 0, 10 ],
      "id_str" : "17112939",
      "id" : 17112939
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1181224966",
  "geo" : { },
  "id_str" : "1181268548",
  "in_reply_to_user_id" : 17112939,
  "text" : "@MakMaksan wenn du aber noch einen alten iPhone-Tarif hast dann kannst du mit einer zweiten SIM ein Modem betreiben :)",
  "id" : 1181268548,
  "in_reply_to_status_id" : 1181224966,
  "created_at" : "2009-02-05 00:00:00 +0000",
  "in_reply_to_screen_name" : "MakMaksan",
  "in_reply_to_user_id_str" : "17112939",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MakMaksan",
      "screen_name" : "MakMaksan",
      "indices" : [ 0, 10 ],
      "id_str" : "17112939",
      "id" : 17112939
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1181278402",
  "geo" : { },
  "id_str" : "1181296054",
  "in_reply_to_user_id" : 17112939,
  "text" : "@MakMaksan dann scheidet das leider ja auch aus. :)",
  "id" : 1181296054,
  "in_reply_to_status_id" : 1181278402,
  "created_at" : "2009-02-05 00:00:00 +0000",
  "in_reply_to_screen_name" : "MakMaksan",
  "in_reply_to_user_id_str" : "17112939",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1176905994",
  "text" : "http:\/\/twitpic.com\/1bsct - Wenn man QuadCamera hat und sein iPhone wegwirft.",
  "id" : 1176905994,
  "created_at" : "2009-02-04 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1176933211",
  "text" : "Grandios beim Fressen! http:\/\/twitpic.com\/1bshw",
  "id" : 1176933211,
  "created_at" : "2009-02-04 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1177183902",
  "text" : "So, MobileMacs h\u00F6ren und dabei noch ein bisschen Standardphysik",
  "id" : 1177183902,
  "created_at" : "2009-02-04 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "raju e",
      "screen_name" : "rajue",
      "indices" : [ 0, 6 ],
      "id_str" : "289833731",
      "id" : 289833731
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1177212480",
  "text" : "@rajue Super, das ist doch genau das was man braucht :)",
  "id" : 1177212480,
  "created_at" : "2009-02-04 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1177231684",
  "text" : "Hab den Bonus von Tipp24 vom Samstag in einen Lottoschein gesetzt. Was soll ich mir auch 1,25\u20AC auszahlen lassen. Heute 3 Richtige..",
  "id" : 1177231684,
  "created_at" : "2009-02-04 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "J\u00F6rg Friedrich",
      "screen_name" : "JoergFr",
      "indices" : [ 0, 8 ],
      "id_str" : "14508163",
      "id" : 14508163
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1177242511",
  "in_reply_to_user_id" : 14508163,
  "text" : "@JoergFr Weil sie das ge\u00FCbt haben? :)",
  "id" : 1177242511,
  "created_at" : "2009-02-04 00:00:00 +0000",
  "in_reply_to_screen_name" : "JoergFr",
  "in_reply_to_user_id_str" : "14508163",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1177247288",
  "text" : "Eigentlich f\u00FChle ich mich mittlerweile gut vorbereitet. Das ist mir ja noch nie passiert!",
  "id" : 1177247288,
  "created_at" : "2009-02-04 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1177294549",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod Ist doch nicht schlimm wenn du ganzen Logins auf deinem Mac hast in 1Password",
  "id" : 1177294549,
  "created_at" : "2009-02-04 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1177369742",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod Oh bl\u00F6d, aber wieso hast du es nicht f\u00FCr den Mac? Das gab es doch ewig f\u00FCr umsonst. Und es ist grandios!",
  "id" : 1177369742,
  "created_at" : "2009-02-04 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1177384524",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod So kurz vor & nach Weihnachten gab es freie Lizenzen. Die Integration in FF\/Safari f\u00FCr automatische Logins spart viel Zeit.",
  "id" : 1177384524,
  "created_at" : "2009-02-04 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1177437502",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod Ich hab es zu der Zeit geschafft sogar ohne Mac mir so eine Lizenz zu sichern ;)",
  "id" : 1177437502,
  "created_at" : "2009-02-04 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "herr_schrat",
      "screen_name" : "herr_schrat",
      "indices" : [ 0, 12 ],
      "id_str" : "16066591",
      "id" : 16066591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1177584980",
  "in_reply_to_user_id" : 16066591,
  "text" : "@herr_schrat H\u00F6rt sich gut an :)",
  "id" : 1177584980,
  "created_at" : "2009-02-04 00:00:00 +0000",
  "in_reply_to_screen_name" : "herr_schrat",
  "in_reply_to_user_id_str" : "16066591",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "J\u00F6rg Friedrich",
      "screen_name" : "JoergFr",
      "indices" : [ 0, 8 ],
      "id_str" : "14508163",
      "id" : 14508163
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1177599246",
  "in_reply_to_user_id" : 14508163,
  "text" : "@JoergFr Vermutlich \u00FCben das die Leute beim Fris\u00F6r aber mehrmals t\u00E4glich. \u00DCbung macht den Meister :)",
  "id" : 1177599246,
  "created_at" : "2009-02-04 00:00:00 +0000",
  "in_reply_to_screen_name" : "JoergFr",
  "in_reply_to_user_id_str" : "14508163",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "herr_schrat",
      "screen_name" : "herr_schrat",
      "indices" : [ 0, 12 ],
      "id_str" : "16066591",
      "id" : 16066591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1177603718",
  "in_reply_to_user_id" : 16066591,
  "text" : "@herr_schrat Ob das wohl was wird.",
  "id" : 1177603718,
  "created_at" : "2009-02-04 00:00:00 +0000",
  "in_reply_to_screen_name" : "herr_schrat",
  "in_reply_to_user_id_str" : "16066591",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "klausur",
      "indices" : [ 89, 97 ]
    }, {
      "text" : "physik",
      "indices" : [ 98, 105 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1177617190",
  "text" : "So, Serienproduktionen m\u00FCssen warten. Ich geh nun ins Bett. Morgen muss ich ja fit sein. #klausur #physik",
  "id" : 1177617190,
  "created_at" : "2009-02-04 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "herr_schrat",
      "screen_name" : "herr_schrat",
      "indices" : [ 0, 12 ],
      "id_str" : "16066591",
      "id" : 16066591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1177626325",
  "in_reply_to_user_id" : 16066591,
  "text" : "@herr_schrat Aye mach ich. Gute Nacht!",
  "id" : 1177626325,
  "created_at" : "2009-02-04 00:00:00 +0000",
  "in_reply_to_screen_name" : "herr_schrat",
  "in_reply_to_user_id_str" : "16066591",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1175605670",
  "text" : "Moin moin zur letzten Mathevorlesung",
  "id" : 1175605670,
  "created_at" : "2009-02-04 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexander Endl",
      "screen_name" : "zielpublikum",
      "indices" : [ 0, 13 ],
      "id_str" : "14711791",
      "id" : 14711791
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1175758146",
  "geo" : { },
  "id_str" : "1175768647",
  "in_reply_to_user_id" : 14711791,
  "text" : "@zielpublikum gab es so einen Fall schon mal?",
  "id" : 1175768647,
  "in_reply_to_status_id" : 1175758146,
  "created_at" : "2009-02-04 00:00:00 +0000",
  "in_reply_to_screen_name" : "zielpublikum",
  "in_reply_to_user_id_str" : "14711791",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "herr_schrat",
      "screen_name" : "herr_schrat",
      "indices" : [ 0, 12 ],
      "id_str" : "16066591",
      "id" : 16066591
    }, {
      "name" : "Alexander Endl",
      "screen_name" : "zielpublikum",
      "indices" : [ 38, 51 ],
      "id_str" : "14711791",
      "id" : 14711791
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1172439685",
  "geo" : { },
  "id_str" : "1175773831",
  "in_reply_to_user_id" : 16066591,
  "text" : "@herr_schrat ich leite unsere Frage ( @zielpublikum ) mal an den Fachmann f\u00FCr Glaubensfragen: Kann der Papst zur\u00FCcktreten?",
  "id" : 1175773831,
  "in_reply_to_status_id" : 1172439685,
  "created_at" : "2009-02-04 00:00:00 +0000",
  "in_reply_to_screen_name" : "herr_schrat",
  "in_reply_to_user_id_str" : "16066591",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexander Endl",
      "screen_name" : "zielpublikum",
      "indices" : [ 0, 13 ],
      "id_str" : "14711791",
      "id" : 14711791
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1175776714",
  "geo" : { },
  "id_str" : "1175810245",
  "in_reply_to_user_id" : 14711791,
  "text" : "@zielpublikum Jetzt haben wir die Antwort gleich 2mal, sogar mit Wiki-Link. Das beantwortet die Frage nach der Unfehlbarkeit nur nicht.",
  "id" : 1175810245,
  "in_reply_to_status_id" : 1175776714,
  "created_at" : "2009-02-04 00:00:00 +0000",
  "in_reply_to_screen_name" : "zielpublikum",
  "in_reply_to_user_id_str" : "14711791",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "herr_schrat",
      "screen_name" : "herr_schrat",
      "indices" : [ 0, 12 ],
      "id_str" : "16066591",
      "id" : 16066591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1175777556",
  "geo" : { },
  "id_str" : "1175811106",
  "in_reply_to_user_id" : 16066591,
  "text" : "@herr_schrat H\u00F6rt sich so nach Untertitel f\u00FCr Fernsehen an \"Herr Schrat, Experte f\u00FCr Glaubensfragen\", zusammen mit Michi, Experte f\u00FCr Islam.",
  "id" : 1175811106,
  "in_reply_to_status_id" : 1175777556,
  "created_at" : "2009-02-04 00:00:00 +0000",
  "in_reply_to_screen_name" : "herr_schrat",
  "in_reply_to_user_id_str" : "16066591",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1175878048",
  "text" : "Bettler von den Maltesern an der Haust\u00FCr abwimmeln ist ja so gar nicht mein Fall...",
  "id" : 1175878048,
  "created_at" : "2009-02-04 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "herr_schrat",
      "screen_name" : "herr_schrat",
      "indices" : [ 0, 12 ],
      "id_str" : "16066591",
      "id" : 16066591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1175885809",
  "geo" : { },
  "id_str" : "1175888677",
  "in_reply_to_user_id" : 16066591,
  "text" : "@herr_schrat Ich seh schon einen Videopodcast vor mir ;)",
  "id" : 1175888677,
  "in_reply_to_status_id" : 1175885809,
  "created_at" : "2009-02-04 00:00:00 +0000",
  "in_reply_to_screen_name" : "herr_schrat",
  "in_reply_to_user_id_str" : "16066591",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1175893507",
  "text" : "Oh man, in der Matheklausur d\u00FCrfen wir Taschenrechner unserer Wahl verwenden. Auch die komplett programmierbaren Grafikrechner.",
  "id" : 1175893507,
  "created_at" : "2009-02-04 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "herr_schrat",
      "screen_name" : "herr_schrat",
      "indices" : [ 0, 12 ],
      "id_str" : "16066591",
      "id" : 16066591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1175891336",
  "geo" : { },
  "id_str" : "1175894268",
  "in_reply_to_user_id" : 16066591,
  "text" : "@herr_schrat Ich dachte du kommst am Samstag vorbei? :)",
  "id" : 1175894268,
  "in_reply_to_status_id" : 1175891336,
  "created_at" : "2009-02-04 00:00:00 +0000",
  "in_reply_to_screen_name" : "herr_schrat",
  "in_reply_to_user_id_str" : "16066591",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1176021550",
  "text" : "Sehr entspannt zum lernen. \u266B http:\/\/blip.fm\/~1za1d",
  "id" : 1176021550,
  "created_at" : "2009-02-04 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1176109102",
  "text" : "Seit Tagen nix anderes im Kopf. Grausam. Und dann in der Klausur auch noch ganz ohne Taschenrechner.  http:\/\/twitpic.com\/1borw",
  "id" : 1176109102,
  "created_at" : "2009-02-04 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Herr Rensch",
      "screen_name" : "arensch",
      "indices" : [ 0, 8 ],
      "id_str" : "14725887",
      "id" : 14725887
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1176131627",
  "geo" : { },
  "id_str" : "1176167293",
  "in_reply_to_user_id" : 14725887,
  "text" : "@arensch Ne, wir haben ne multiple choice-Klausur. Auf dem Lottoschein den wir abgeben sieht man den Rechenweg nicht. Nur die L\u00F6sung.",
  "id" : 1176167293,
  "in_reply_to_status_id" : 1176131627,
  "created_at" : "2009-02-04 00:00:00 +0000",
  "in_reply_to_screen_name" : "arensch",
  "in_reply_to_user_id_str" : "14725887",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Herr Rensch",
      "screen_name" : "arensch",
      "indices" : [ 0, 8 ],
      "id_str" : "14725887",
      "id" : 14725887
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1176131627",
  "geo" : { },
  "id_str" : "1176168706",
  "in_reply_to_user_id" : 14725887,
  "text" : "@arensch Da ist der Weg v\u00F6llig egal, wenn das Ergebnis nicht stimmt gibts keine Punkte. Fertig aus.",
  "id" : 1176168706,
  "in_reply_to_status_id" : 1176131627,
  "created_at" : "2009-02-04 00:00:00 +0000",
  "in_reply_to_screen_name" : "arensch",
  "in_reply_to_user_id_str" : "14725887",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "keinspass",
      "indices" : [ 85, 95 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1176337649",
  "text" : "Schon mal versucht einem Hund Augentropfen gegen seine Bindehautentz\u00FCndung zu geben? #keinspass",
  "id" : 1176337649,
  "created_at" : "2009-02-04 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Martin Labuschin",
      "screen_name" : "Labuschin",
      "indices" : [ 0, 10 ],
      "id_str" : "1024351",
      "id" : 1024351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1176397627",
  "geo" : { },
  "id_str" : "1176399021",
  "in_reply_to_user_id" : 1024351,
  "text" : "@Labuschin Gl\u00FCckwunsch :)",
  "id" : 1176399021,
  "in_reply_to_status_id" : 1176397627,
  "created_at" : "2009-02-04 00:00:00 +0000",
  "in_reply_to_screen_name" : "Labuschin",
  "in_reply_to_user_id_str" : "1024351",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Henning Sch\u00FCrig",
      "screen_name" : "hensch",
      "indices" : [ 0, 7 ],
      "id_str" : "3728881",
      "id" : 3728881
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1176662763",
  "geo" : { },
  "id_str" : "1176688483",
  "in_reply_to_user_id" : 3728881,
  "text" : "@hensch Ja die werden rar. Aber wieso soll es unbedingt 4:3 sein? Hat das besondere Vorteile f\u00FCr dich?",
  "id" : 1176688483,
  "in_reply_to_status_id" : 1176662763,
  "created_at" : "2009-02-04 00:00:00 +0000",
  "in_reply_to_screen_name" : "hensch",
  "in_reply_to_user_id_str" : "3728881",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Henning Sch\u00FCrig",
      "screen_name" : "hensch",
      "indices" : [ 0, 7 ],
      "id_str" : "3728881",
      "id" : 3728881
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1176726480",
  "geo" : { },
  "id_str" : "1176757488",
  "in_reply_to_user_id" : 3728881,
  "text" : "@hensch Ist ja auch nicht wirklich 16:9 ;) Aber na gut. Ich seh auch keinen Nachteil drin, bei der Fotobearbeitung ehr im Gegenteil.",
  "id" : 1176757488,
  "in_reply_to_status_id" : 1176726480,
  "created_at" : "2009-02-04 00:00:00 +0000",
  "in_reply_to_screen_name" : "hensch",
  "in_reply_to_user_id_str" : "3728881",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1172437297",
  "text" : "Gerade was gutes getan und an Creative Commons gespendet. Und nun weiter mit Physik",
  "id" : 1172437297,
  "created_at" : "2009-02-03 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "herr_schrat",
      "screen_name" : "herr_schrat",
      "indices" : [ 0, 12 ],
      "id_str" : "16066591",
      "id" : 16066591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1172439685",
  "geo" : { },
  "id_str" : "1172442656",
  "in_reply_to_user_id" : 16066591,
  "text" : "@herr_schrat Aye. Auch bei Bestellungen im Store gehen 50% direkt als Spende ab.",
  "id" : 1172442656,
  "in_reply_to_status_id" : 1172439685,
  "created_at" : "2009-02-03 00:00:00 +0000",
  "in_reply_to_screen_name" : "herr_schrat",
  "in_reply_to_user_id_str" : "16066591",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Milissa",
      "screen_name" : "pasqualle",
      "indices" : [ 0, 10 ],
      "id_str" : "2531726499",
      "id" : 2531726499
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1172461186",
  "text" : "@pasQualle Pi*Daumen halt ;)",
  "id" : 1172461186,
  "created_at" : "2009-02-03 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1172513786",
  "text" : "Schon lange nicht mehr so dumm abgestellt: Versucht was zu Fangen. Dabei prall gef\u00FCllten Kaffeefilter umgeworfen. K\u00FCche schwimmt im Pulver.",
  "id" : 1172513786,
  "created_at" : "2009-02-03 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Benjamin Claverie",
      "screen_name" : "Skl8em",
      "indices" : [ 63, 70 ],
      "id_str" : "13823092",
      "id" : 13823092
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1172513047",
  "geo" : { },
  "id_str" : "1172520941",
  "in_reply_to_user_id" : 13823092,
  "text" : "Und meine bis gerade war die Hose noch wei\u00DF. Nun Kaffee-Braun. @Skl8em sei vorsichtig beim Kaffee machen :)",
  "id" : 1172520941,
  "in_reply_to_status_id" : 1172513047,
  "created_at" : "2009-02-03 00:00:00 +0000",
  "in_reply_to_screen_name" : "Skl8em",
  "in_reply_to_user_id_str" : "13823092",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephan Sachs",
      "screen_name" : "fischimglas",
      "indices" : [ 0, 12 ],
      "id_str" : "15199614",
      "id" : 15199614
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1172656742",
  "geo" : { },
  "id_str" : "1172662331",
  "in_reply_to_user_id" : 15199614,
  "text" : "@fischimglas Wieso nicht den Kalender der eingebaut ist? Der kann sich dann auch per Ton und Nachricht melden wenn die Erinnerung f\u00E4llig ist",
  "id" : 1172662331,
  "in_reply_to_status_id" : 1172656742,
  "created_at" : "2009-02-03 00:00:00 +0000",
  "in_reply_to_screen_name" : "fischimglas",
  "in_reply_to_user_id_str" : "15199614",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephan Sachs",
      "screen_name" : "fischimglas",
      "indices" : [ 0, 12 ],
      "id_str" : "15199614",
      "id" : 15199614
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1172672112",
  "geo" : { },
  "id_str" : "1172678633",
  "in_reply_to_user_id" : 15199614,
  "text" : "@fischimglas Aber du kannst doch einstellen das er dich erinnern soll per Ton & Nachricht. Dann brauchst du nicht in den Kalender schauen.",
  "id" : 1172678633,
  "in_reply_to_status_id" : 1172672112,
  "created_at" : "2009-02-03 00:00:00 +0000",
  "in_reply_to_screen_name" : "fischimglas",
  "in_reply_to_user_id_str" : "15199614",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephan Sachs",
      "screen_name" : "fischimglas",
      "indices" : [ 0, 12 ],
      "id_str" : "15199614",
      "id" : 15199614
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1172682775",
  "geo" : { },
  "id_str" : "1172684425",
  "in_reply_to_user_id" : 15199614,
  "text" : "@fischimglas So mach ich es zumindest. Weil extra Apps muss man auch jeden Tag starten um die Erinnerung zu sehen. Nicht so komfortabel.",
  "id" : 1172684425,
  "in_reply_to_status_id" : 1172682775,
  "created_at" : "2009-02-03 00:00:00 +0000",
  "in_reply_to_screen_name" : "fischimglas",
  "in_reply_to_user_id_str" : "15199614",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1172817438",
  "text" : "Hab alle \u00DCbungsaufgaben gleich ein zweites Mal durch.",
  "id" : 1172817438,
  "created_at" : "2009-02-03 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1172880958",
  "text" : "Und im Wald http:\/\/twitpic.com\/1b89x",
  "id" : 1172880958,
  "created_at" : "2009-02-03 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "netzpolitik",
      "screen_name" : "netzpolitik",
      "indices" : [ 3, 15 ],
      "id_str" : "9655032",
      "id" : 9655032
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1173050836",
  "geo" : { },
  "id_str" : "1173062913",
  "in_reply_to_user_id" : 26703,
  "text" : "RT @netzpolitik Brauche HIlfe: Deutsche Bahn AG schickt Abmahnung wegen Verrat von Betriebs- und Gesch\u00E4ftsgeheimnissen. http:\/\/bit.ly\/yKBM",
  "id" : 1173062913,
  "in_reply_to_status_id" : 1173050836,
  "created_at" : "2009-02-03 00:00:00 +0000",
  "in_reply_to_screen_name" : "thomaswanhoff",
  "in_reply_to_user_id_str" : "26703",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephan Sachs",
      "screen_name" : "fischimglas",
      "indices" : [ 0, 12 ],
      "id_str" : "15199614",
      "id" : 15199614
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1173523925",
  "geo" : { },
  "id_str" : "1173542844",
  "in_reply_to_user_id" : 15199614,
  "text" : "@fischimglas Das f\u00FCgt automatisch zu jedem Geburtstag die Erinnerung hinzu? Das w\u00FCrde mich auch interessieren :)",
  "id" : 1173542844,
  "in_reply_to_status_id" : 1173523925,
  "created_at" : "2009-02-03 00:00:00 +0000",
  "in_reply_to_screen_name" : "fischimglas",
  "in_reply_to_user_id_str" : "15199614",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephan Sachs",
      "screen_name" : "fischimglas",
      "indices" : [ 0, 12 ],
      "id_str" : "15199614",
      "id" : 15199614
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1173571965",
  "geo" : { },
  "id_str" : "1173576288",
  "in_reply_to_user_id" : 15199614,
  "text" : "@fischimglas Super! Danke f\u00FCr den Link :)",
  "id" : 1173576288,
  "in_reply_to_status_id" : 1173571965,
  "created_at" : "2009-02-03 00:00:00 +0000",
  "in_reply_to_screen_name" : "fischimglas",
  "in_reply_to_user_id_str" : "15199614",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephan Sachs",
      "screen_name" : "fischimglas",
      "indices" : [ 0, 12 ],
      "id_str" : "15199614",
      "id" : 15199614
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1173571965",
  "geo" : { },
  "id_str" : "1173581351",
  "in_reply_to_user_id" : 15199614,
  "text" : "@fischimglas Aber auch traurig das iCal das nicht von Haus aus kann. Outlook macht das Problemlos ;)",
  "id" : 1173581351,
  "in_reply_to_status_id" : 1173571965,
  "created_at" : "2009-02-03 00:00:00 +0000",
  "in_reply_to_screen_name" : "fischimglas",
  "in_reply_to_user_id_str" : "15199614",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexander Endl",
      "screen_name" : "zielpublikum",
      "indices" : [ 0, 13 ],
      "id_str" : "14711791",
      "id" : 14711791
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1173567256",
  "geo" : { },
  "id_str" : "1173583120",
  "in_reply_to_user_id" : 14711791,
  "text" : "@zielpublikum Und wie ist das \u00FCberhaupt? Kann der zur\u00FCcktreten oder ist das nicht auch so eine \u201Cbis der Tod euch scheide\u201D-Geschichte?",
  "id" : 1173583120,
  "in_reply_to_status_id" : 1173567256,
  "created_at" : "2009-02-03 00:00:00 +0000",
  "in_reply_to_screen_name" : "zielpublikum",
  "in_reply_to_user_id_str" : "14711791",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephan Sachs",
      "screen_name" : "fischimglas",
      "indices" : [ 0, 12 ],
      "id_str" : "15199614",
      "id" : 15199614
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1173643396",
  "geo" : { },
  "id_str" : "1173657441",
  "in_reply_to_user_id" : 15199614,
  "text" : "@fischimglas Das macht es nicht besser oder? ;)",
  "id" : 1173657441,
  "in_reply_to_status_id" : 1173643396,
  "created_at" : "2009-02-03 00:00:00 +0000",
  "in_reply_to_screen_name" : "fischimglas",
  "in_reply_to_user_id_str" : "15199614",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1174243124",
  "text" : "Nun vor dem Fernseher entspannen mit Hund im Arm. Morgen mal wieder zur Uni.",
  "id" : 1174243124,
  "created_at" : "2009-02-03 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1170067873",
  "text" : "Gerade das erste Mal den Abspann von Fallout 3 gesehen. Es war sch\u00F6n. Habe leider nur nicht alles gesehen. Das Kapitol schau ich mir noch an",
  "id" : 1170067873,
  "created_at" : "2009-02-02 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ilona S",
      "screen_name" : "mazoe28",
      "indices" : [ 0, 8 ],
      "id_str" : "18527855",
      "id" : 18527855
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1170073694",
  "geo" : { },
  "id_str" : "1170081654",
  "in_reply_to_user_id" : 18527855,
  "text" : "@Mazoe28 Ich bin frisch geswitcht und sehr gl\u00FCcklich mit der Entscheidung.",
  "id" : 1170081654,
  "in_reply_to_status_id" : 1170073694,
  "created_at" : "2009-02-02 00:00:00 +0000",
  "in_reply_to_screen_name" : "mazoe28",
  "in_reply_to_user_id_str" : "18527855",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "raju e",
      "screen_name" : "rajue",
      "indices" : [ 0, 6 ],
      "id_str" : "289833731",
      "id" : 289833731
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1170111074",
  "text" : "@rajue Ich dachte da flitzen nur noch deutsche C-Promis dr\u00FCber? ;)",
  "id" : 1170111074,
  "created_at" : "2009-02-02 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ilona S",
      "screen_name" : "mazoe28",
      "indices" : [ 0, 8 ],
      "id_str" : "18527855",
      "id" : 18527855
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1170118649",
  "geo" : { },
  "id_str" : "1170123938",
  "in_reply_to_user_id" : 18527855,
  "text" : "@Mazoe28 Jau. Auspacken & Benutzen w\u00FCrd ich sagen. Nur f\u00FCr speziellere Anforderungen muss man mal eben Googlen :)",
  "id" : 1170123938,
  "in_reply_to_status_id" : 1170118649,
  "created_at" : "2009-02-02 00:00:00 +0000",
  "in_reply_to_screen_name" : "mazoe28",
  "in_reply_to_user_id_str" : "18527855",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marcus",
      "screen_name" : "maggi72",
      "indices" : [ 0, 8 ],
      "id_str" : "16603086",
      "id" : 16603086
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1170152254",
  "geo" : { },
  "id_str" : "1170174971",
  "in_reply_to_user_id" : 16603086,
  "text" : "@maggi72 Und dabei war es schon immer Langsam. Und das ist das traurige daran. Das sollte nochmal von 0 an programmiert werden.",
  "id" : 1170174971,
  "in_reply_to_status_id" : 1170152254,
  "created_at" : "2009-02-02 00:00:00 +0000",
  "in_reply_to_screen_name" : "maggi72",
  "in_reply_to_user_id_str" : "16603086",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marcus",
      "screen_name" : "maggi72",
      "indices" : [ 0, 8 ],
      "id_str" : "16603086",
      "id" : 16603086
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1170442939",
  "geo" : { },
  "id_str" : "1170492160",
  "in_reply_to_user_id" : 16603086,
  "text" : "@maggi72 Vor allem ist das Aufrufen der Apps sogar auf dem MBP unglaublich langsam. Das ist ein Witz",
  "id" : 1170492160,
  "in_reply_to_status_id" : 1170442939,
  "created_at" : "2009-02-02 00:00:00 +0000",
  "in_reply_to_screen_name" : "maggi72",
  "in_reply_to_user_id_str" : "16603086",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1170498974",
  "text" : "Zeit f\u00FCrs Abendessen w\u00FCrd ich sagen.",
  "id" : 1170498974,
  "created_at" : "2009-02-02 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rozana Renger",
      "screen_name" : "Rozana",
      "indices" : [ 0, 7 ],
      "id_str" : "6085542",
      "id" : 6085542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1170531178",
  "geo" : { },
  "id_str" : "1170550829",
  "in_reply_to_user_id" : 6085542,
  "text" : "@Rozana Sehr h\u00FCbsch :)",
  "id" : 1170550829,
  "in_reply_to_status_id" : 1170531178,
  "created_at" : "2009-02-02 00:00:00 +0000",
  "in_reply_to_screen_name" : "Rozana",
  "in_reply_to_user_id_str" : "6085542",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1170589829",
  "text" : "Heute so viel Physik n die Birne gehauen und Aufgaben durchgerechnet das ich erstmal voll bin. Pause f\u00FCr heute.",
  "id" : 1170589829,
  "created_at" : "2009-02-02 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Team Mendeley",
      "screen_name" : "mendeley_com",
      "indices" : [ 14, 27 ],
      "id_str" : "15803034",
      "id" : 15803034
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1167966834",
  "geo" : { },
  "id_str" : "1170594624",
  "in_reply_to_user_id" : 15803034,
  "text" : "Gro\u00DFes Lob an @mendeley_com Man ist auch selber Schuld wenn die Antworten auf Support-Tickets im Spam verschwinden. Keep going! :)",
  "id" : 1170594624,
  "in_reply_to_status_id" : 1167966834,
  "created_at" : "2009-02-02 00:00:00 +0000",
  "in_reply_to_screen_name" : "mendeley_com",
  "in_reply_to_user_id_str" : "15803034",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1170641834",
  "text" : "Belegtes Baguette ist im Ofen. Juhu!",
  "id" : 1170641834,
  "created_at" : "2009-02-02 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "herr_schrat",
      "screen_name" : "herr_schrat",
      "indices" : [ 0, 12 ],
      "id_str" : "16066591",
      "id" : 16066591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1170752241",
  "geo" : { },
  "id_str" : "1170768230",
  "in_reply_to_user_id" : 16066591,
  "text" : "@herr_schrat Frohen Feierabend :)",
  "id" : 1170768230,
  "in_reply_to_status_id" : 1170752241,
  "created_at" : "2009-02-02 00:00:00 +0000",
  "in_reply_to_screen_name" : "herr_schrat",
  "in_reply_to_user_id_str" : "16066591",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dennis N\u00F6lte",
      "screen_name" : "noelte",
      "indices" : [ 0, 7 ],
      "id_str" : "2870342342",
      "id" : 2870342342
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1170965715",
  "text" : "@noelte Das Problem kenn ich. Kommt man sich bl\u00F6d vor nachher und nimmt sich vor h\u00E4ufiger zu putzen :)",
  "id" : 1170965715,
  "created_at" : "2009-02-02 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dennis N\u00F6lte",
      "screen_name" : "noelte",
      "indices" : [ 0, 7 ],
      "id_str" : "2870342342",
      "id" : 2870342342
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1170986057",
  "text" : "@noelte Das kommt halt so mit der Zeig w\u00FCrd ich sagen. Bei mir patscht auch niemand drauf rum, aber irgendwie zieht das LCD den Dreck an.",
  "id" : 1170986057,
  "created_at" : "2009-02-02 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dennis N\u00F6lte",
      "screen_name" : "noelte",
      "indices" : [ 0, 7 ],
      "id_str" : "2870342342",
      "id" : 2870342342
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1170992464",
  "text" : "@noelte und du sabberst sicher nicht? ;)",
  "id" : 1170992464,
  "created_at" : "2009-02-02 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1171085861",
  "text" : "Nein. Das Foto steht nicht auf dem Kopf. http:\/\/twitpic.com\/1az6h",
  "id" : 1171085861,
  "created_at" : "2009-02-02 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1169260248",
  "text" : "Moin",
  "id" : 1169260248,
  "created_at" : "2009-02-02 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1169305902",
  "text" : "Ein paar Altklausuren schreiben.",
  "id" : 1169305902,
  "created_at" : "2009-02-02 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "G1",
      "screen_name" : "tmobile_g1",
      "indices" : [ 0, 11 ],
      "id_str" : "55062387",
      "id" : 55062387
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "G1",
      "indices" : [ 67, 70 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1169273285",
  "geo" : { },
  "id_str" : "1169321840",
  "in_reply_to_user_id" : 16360825,
  "text" : "@tmobile_g1 Weil ich will das Google jederzeit weiss wo ich bin ;) #G1",
  "id" : 1169321840,
  "in_reply_to_status_id" : 1169273285,
  "created_at" : "2009-02-02 00:00:00 +0000",
  "in_reply_to_screen_name" : "tmobile_trend",
  "in_reply_to_user_id_str" : "16360825",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1169379542",
  "text" : "http:\/\/www.geeksugar.com\/739376 USB-Flashdrive in einer Kassette: Jugenderinnerungen in 2.0 :)",
  "id" : 1169379542,
  "created_at" : "2009-02-02 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1169407273",
  "text" : "Also ich bleib bei meinem altem Complete-Tarif. Ich nutze ja die 100 Freiminuten nichtmal komplett aus.",
  "id" : 1169407273,
  "created_at" : "2009-02-02 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marcus",
      "screen_name" : "maggi72",
      "indices" : [ 0, 8 ],
      "id_str" : "16603086",
      "id" : 16603086
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1169427643",
  "geo" : { },
  "id_str" : "1169434017",
  "in_reply_to_user_id" : 16603086,
  "text" : "@maggi72 vor allem wenn man so sch\u00F6n per MultiSIM die Datenflatrate mitnutzen kann :)",
  "id" : 1169434017,
  "in_reply_to_status_id" : 1169427643,
  "created_at" : "2009-02-02 00:00:00 +0000",
  "in_reply_to_screen_name" : "maggi72",
  "in_reply_to_user_id_str" : "16603086",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marcus",
      "screen_name" : "maggi72",
      "indices" : [ 0, 8 ],
      "id_str" : "16603086",
      "id" : 16603086
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1169458929",
  "geo" : { },
  "id_str" : "1169501178",
  "in_reply_to_user_id" : 16603086,
  "text" : "@maggi72 vermutlich verl\u00E4ngern sie den Vertrag einfach zu alten Konditionen weil sie es verpeilen ;)",
  "id" : 1169501178,
  "in_reply_to_status_id" : 1169458929,
  "created_at" : "2009-02-02 00:00:00 +0000",
  "in_reply_to_screen_name" : "maggi72",
  "in_reply_to_user_id_str" : "16603086",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1169559610",
  "text" : "OMG, die Raptoren sind ausgebrochen. Oder der Hund hatte seinen Spa\u00DF. You guess! http:\/\/twitpic.com\/1apgx",
  "id" : 1169559610,
  "created_at" : "2009-02-02 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TillaPe",
      "screen_name" : "TillaPe",
      "indices" : [ 0, 8 ],
      "id_str" : "14623695",
      "id" : 14623695
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "g1",
      "indices" : [ 67, 70 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1169629531",
  "geo" : { },
  "id_str" : "1169631441",
  "in_reply_to_user_id" : 14623695,
  "text" : "@TillaPe W\u00E4re ein Telefon mit W\u00E4hlscheibe dann nicht angebrachter? #g1 ;)",
  "id" : 1169631441,
  "in_reply_to_status_id" : 1169629531,
  "created_at" : "2009-02-02 00:00:00 +0000",
  "in_reply_to_screen_name" : "TillaPe",
  "in_reply_to_user_id_str" : "14623695",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TillaPe",
      "screen_name" : "TillaPe",
      "indices" : [ 0, 8 ],
      "id_str" : "14623695",
      "id" : 14623695
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1169632636",
  "geo" : { },
  "id_str" : "1169643264",
  "in_reply_to_user_id" : 14623695,
  "text" : "@TillaPe Daf\u00FCr gibt es glaub ich schon iPhone-Apps die genau das emulieren. Kommt nat\u00FCrlich nicht an die echte W\u00E4hlscheibe ran :)",
  "id" : 1169643264,
  "in_reply_to_status_id" : 1169632636,
  "created_at" : "2009-02-02 00:00:00 +0000",
  "in_reply_to_screen_name" : "TillaPe",
  "in_reply_to_user_id_str" : "14623695",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1169753693",
  "text" : "Die Menschen hinter Creative Commons sind auch einfach nur Zucker.",
  "id" : 1169753693,
  "created_at" : "2009-02-02 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1169760579",
  "text" : "Playmobil wird heute 35 Jahre alt. Ich muss gestehen ich fand Lego immer viel cooler. Konnte man doch viel mehr mit basteln.",
  "id" : 1169760579,
  "created_at" : "2009-02-02 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1169827868",
  "text" : "http:\/\/twitpic.com\/1arhi - Mal was ganz anderes!",
  "id" : 1169827868,
  "created_at" : "2009-02-02 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1169852323",
  "text" : "V\u00F6lliges Ignorieren der Gr\u00F6\u00DFenverh\u00E4ltnisse! http:\/\/twitpic.com\/1arn4",
  "id" : 1169852323,
  "created_at" : "2009-02-02 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1166578236",
  "text" : "Ahja, guten Morgen und so!",
  "id" : 1166578236,
  "created_at" : "2009-02-01 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1166627244",
  "text" : "Gleich geht es mal wieder zum Bandfotos schiessen.",
  "id" : 1166627244,
  "created_at" : "2009-02-01 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1166638208",
  "text" : "H\u00F6re gerade das 2007er Programm von Volker Pispers, immer wieder gut.",
  "id" : 1166638208,
  "created_at" : "2009-02-01 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1166755634",
  "text" : "Hatte ich wegen der Stadtwerke gemeckert? Samstag Nachmittag war der Postbote da. Mit der Jahresabrechnung. Es gibt eine R\u00FCckzahlung.",
  "id" : 1166755634,
  "created_at" : "2009-02-01 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "herr_schrat",
      "screen_name" : "herr_schrat",
      "indices" : [ 0, 12 ],
      "id_str" : "16066591",
      "id" : 16066591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1166778332",
  "geo" : { },
  "id_str" : "1166781931",
  "in_reply_to_user_id" : 16066591,
  "text" : "@herr_schrat vermutlich eine Mischung aus beidem ;)",
  "id" : 1166781931,
  "in_reply_to_status_id" : 1166778332,
  "created_at" : "2009-02-01 00:00:00 +0000",
  "in_reply_to_screen_name" : "herr_schrat",
  "in_reply_to_user_id_str" : "16066591",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1166837812",
  "text" : "B\u00E4h ist das Kalt, wenn man den Ausl\u00F6ser nicht mehr ertasten kann.",
  "id" : 1166837812,
  "created_at" : "2009-02-01 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "herr_schrat",
      "screen_name" : "herr_schrat",
      "indices" : [ 0, 12 ],
      "id_str" : "16066591",
      "id" : 16066591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1166788598",
  "geo" : { },
  "id_str" : "1166838363",
  "in_reply_to_user_id" : 16066591,
  "text" : "@herr_schrat gern geschehen.",
  "id" : 1166838363,
  "in_reply_to_status_id" : 1166788598,
  "created_at" : "2009-02-01 00:00:00 +0000",
  "in_reply_to_screen_name" : "herr_schrat",
  "in_reply_to_user_id_str" : "16066591",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "eldersign",
      "screen_name" : "eldersign",
      "indices" : [ 0, 10 ],
      "id_str" : "14209202",
      "id" : 14209202
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1166834095",
  "geo" : { },
  "id_str" : "1166839859",
  "in_reply_to_user_id" : 14209202,
  "text" : "@eldersign Anfang 08 die Abschl\u00E4ge erh\u00F6ht. Nun zur\u00FCck auf das Niveau von 07. :)",
  "id" : 1166839859,
  "in_reply_to_status_id" : 1166834095,
  "created_at" : "2009-02-01 00:00:00 +0000",
  "in_reply_to_screen_name" : "eldersign",
  "in_reply_to_user_id_str" : "14209202",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joerg Roehlig",
      "screen_name" : "JoergR",
      "indices" : [ 0, 7 ],
      "id_str" : "774628164177985537",
      "id" : 774628164177985537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1166841552",
  "text" : "@JoergR H\u00F6rt sich gut an. K\u00F6nnte ich gebrauchen :)",
  "id" : 1166841552,
  "created_at" : "2009-02-01 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1166858676",
  "text" : "Ich bin begeistert wie schnell auf dem MacBook die Fotos in Lightroom importiert werden. Bei dem Thinkpad konnte man ewig warten.",
  "id" : 1166858676,
  "created_at" : "2009-02-01 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1166868989",
  "text" : "Kein Wunder das einem die Finger abfrieren!  http:\/\/twitpic.com\/1a5dp",
  "id" : 1166868989,
  "created_at" : "2009-02-01 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1166909602",
  "geo" : { },
  "id_str" : "1166923184",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod Japs, zumindest dem Jetzt-Zustand. Zu den Vorhersagen kann ich wenig sagen. Interessieren mich auch nicht. Seh ja wie es ist ;)",
  "id" : 1166923184,
  "in_reply_to_status_id" : 1166909602,
  "created_at" : "2009-02-01 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1166962097",
  "text" : "Ganz so falsch war Yahoo dann nicht! http:\/\/twitpic.com\/1a5z5",
  "id" : 1166962097,
  "created_at" : "2009-02-01 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1167209102",
  "text" : "Bin selbst nicht so ganz zufrieden mit den Fotos von heute Mittag...",
  "id" : 1167209102,
  "created_at" : "2009-02-01 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1167236166",
  "text" : "Puh, Zeit endlich mal was zu essen w\u00FCrd ich sagen.",
  "id" : 1167236166,
  "created_at" : "2009-02-01 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1167270350",
  "text" : "Also dieser Sport-Content hier interessiert mich ja so gar nicht um ganz genau zu sein.",
  "id" : 1167270350,
  "created_at" : "2009-02-01 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "herr_schrat",
      "screen_name" : "herr_schrat",
      "indices" : [ 0, 12 ],
      "id_str" : "16066591",
      "id" : 16066591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1167319329",
  "geo" : { },
  "id_str" : "1167326758",
  "in_reply_to_user_id" : 16066591,
  "text" : "@herr_schrat Cool, wie hast es geschafft?",
  "id" : 1167326758,
  "in_reply_to_status_id" : 1167319329,
  "created_at" : "2009-02-01 00:00:00 +0000",
  "in_reply_to_screen_name" : "herr_schrat",
  "in_reply_to_user_id_str" : "16066591",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Markus",
      "screen_name" : "germanstudent",
      "indices" : [ 0, 14 ],
      "id_str" : "2493441",
      "id" : 2493441
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1167339767",
  "geo" : { },
  "id_str" : "1167342898",
  "in_reply_to_user_id" : 2493441,
  "text" : "@germanstudent Ist das nicht Grundvoraussetzung f\u00FCr den Job?",
  "id" : 1167342898,
  "in_reply_to_status_id" : 1167339767,
  "created_at" : "2009-02-01 00:00:00 +0000",
  "in_reply_to_screen_name" : "germanstudent",
  "in_reply_to_user_id_str" : "2493441",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Team Mendeley",
      "screen_name" : "mendeley_com",
      "indices" : [ 0, 13 ],
      "id_str" : "15803034",
      "id" : 15803034
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1167352727",
  "geo" : { },
  "id_str" : "1167367069",
  "in_reply_to_user_id" : 15803034,
  "text" : "@mendeley_com I'm still waiting for a reply to my support-ticket. Has been some weeks now :)",
  "id" : 1167367069,
  "in_reply_to_status_id" : 1167352727,
  "created_at" : "2009-02-01 00:00:00 +0000",
  "in_reply_to_screen_name" : "mendeley_com",
  "in_reply_to_user_id_str" : "15803034",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1167449975",
  "text" : "Nach Island Geld zu \u00FCberweisen scheint mir zur Zeit ein Ding der Unm\u00F6glichkeit.",
  "id" : 1167449975,
  "created_at" : "2009-02-01 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1167451654",
  "geo" : { },
  "id_str" : "1167462672",
  "in_reply_to_user_id" : 8517622,
  "text" : "@lorXsion Das war auch meine erste Frage :)",
  "id" : 1167462672,
  "in_reply_to_status_id" : 1167451654,
  "created_at" : "2009-02-01 00:00:00 +0000",
  "in_reply_to_screen_name" : "mitZett",
  "in_reply_to_user_id_str" : "8517622",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1167454722",
  "geo" : { },
  "id_str" : "1167466999",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod Um den armen Leuten da zu helfen :)",
  "id" : 1167466999,
  "in_reply_to_status_id" : 1167454722,
  "created_at" : "2009-02-01 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1167467388",
  "geo" : { },
  "id_str" : "1167473016",
  "in_reply_to_user_id" : 8517622,
  "text" : "@lorXsion Keine Angst, streich das k hinter deiner Summe dann passt meine Zielmenge. Muss doch noch das Geld aus der Nachzahlung verteilen.",
  "id" : 1167473016,
  "in_reply_to_status_id" : 1167467388,
  "created_at" : "2009-02-01 00:00:00 +0000",
  "in_reply_to_screen_name" : "mitZett",
  "in_reply_to_user_id_str" : "8517622",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1167491817",
  "geo" : { },
  "id_str" : "1167739318",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod nein, aber meine ehemalige Mitbewohnerin soll ihren Anteil der R\u00FCckzahlung kriegen.",
  "id" : 1167739318,
  "in_reply_to_status_id" : 1167491817,
  "created_at" : "2009-02-01 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1167815700",
  "text" : "Und wenn man glaubt schlechter gehts nicht mehr, kommt Planetopia daher...",
  "id" : 1167815700,
  "created_at" : "2009-02-01 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
} ]