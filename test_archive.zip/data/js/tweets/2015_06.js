Grailbird.data.tweets_2015_06 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17220066841147, 8.627644816299302 ]
  },
  "id_str" : "615842984467263489",
  "text" : "One of the first German words people learn in this work environment: \u2018Kuschelbed\u00FCrftig\u2019.",
  "id" : 615842984467263489,
  "created_at" : "2015-06-30 11:23:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "615834039535206401",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.2022662829111, 8.580762058673677 ]
  },
  "id_str" : "615836822741102592",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot kannst du direkt noch mal Korpusanalyse \u00FCben. Wie praktisch.",
  "id" : 615836822741102592,
  "in_reply_to_status_id" : 615834039535206401,
  "created_at" : "2015-06-30 10:58:34 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/iXzBFmbWmr",
      "expanded_url" : "http:\/\/all-geo.org\/highlyallochthonous\/wp-content\/uploads\/2010\/07\/slide1.png",
      "display_url" : "all-geo.org\/highlyallochth\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17246168403513, 8.627539988378652 ]
  },
  "id_str" : "615812442749145088",
  "text" : "Are people using those mind-numbing outline slides because Powerpoint offers them or is this taught somewhere? http:\/\/t.co\/iXzBFmbWmr",
  "id" : 615812442749145088,
  "created_at" : "2015-06-30 09:21:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17223309663801, 8.627609244940878 ]
  },
  "id_str" : "615796297409257472",
  "text" : "Mh, a room just across the Old Jameson Distillery. Maybe for me BOSC will be \u2018booze open source conference\u2019.",
  "id" : 615796297409257472,
  "created_at" : "2015-06-30 08:17:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mick Watson",
      "screen_name" : "BioMickWatson",
      "indices" : [ 43, 57 ],
      "id_str" : "228586748",
      "id" : 228586748
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 91 ],
      "url" : "https:\/\/t.co\/KZUgyyBUBt",
      "expanded_url" : "https:\/\/twitter.com\/guardianscience\/status\/615768634892251136",
      "display_url" : "twitter.com\/guardianscienc\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17223199658589, 8.627610490561056 ]
  },
  "id_str" : "615792041163915264",
  "text" : "Step 0: Learn why it\u2019s called \u2018science\u2019 RT @BioMickWatson: Do a PCA\nhttps:\/\/t.co\/KZUgyyBUBt",
  "id" : 615792041163915264,
  "created_at" : "2015-06-30 08:00:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/65BInWHvhb",
      "expanded_url" : "http:\/\/bactra.org\/weblog\/1111.html",
      "display_url" : "bactra.org\/weblog\/1111.ht\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17222113967377, 8.627615858092584 ]
  },
  "id_str" : "615770656169291776",
  "text" : "\u00ABVeers wildly between baby stats. and advanced probability theory, without explaining either.\u00BB p-values, again http:\/\/t.co\/65BInWHvhb",
  "id" : 615770656169291776,
  "created_at" : "2015-06-30 06:35:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 73 ],
      "url" : "http:\/\/t.co\/Zw1gXMWkLO",
      "expanded_url" : "http:\/\/www.nytimes.com\/2015\/06\/28\/magazine\/i-dont-believe-in-god-but-i-believe-in-lithium.html",
      "display_url" : "nytimes.com\/2015\/06\/28\/mag\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11408294882884, 8.753322920852039 ]
  },
  "id_str" : "615657162879184896",
  "text" : "\u2018I Don\u2019t Believe in God, but I Believe in Lithium\u2019 http:\/\/t.co\/Zw1gXMWkLO",
  "id" : 615657162879184896,
  "created_at" : "2015-06-29 23:04:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Science Web",
      "screen_name" : "TheScienceWeb",
      "indices" : [ 3, 17 ],
      "id_str" : "2315551122",
      "id" : 2315551122
    }, {
      "name" : "Yoav Gilad",
      "screen_name" : "Y_Gilad",
      "indices" : [ 21, 29 ],
      "id_str" : "2802558480",
      "id" : 2802558480
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/TheScienceWeb\/status\/615519914363850752\/photo\/1",
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/FU8khv6dkn",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CIrEGYuWoAAQn8V.jpg",
      "id_str" : "615519913084624896",
      "id" : 615519913084624896,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CIrEGYuWoAAQn8V.jpg",
      "sizes" : [ {
        "h" : 387,
        "resize" : "fit",
        "w" : 400
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 387,
        "resize" : "fit",
        "w" : 400
      }, {
        "h" : 387,
        "resize" : "fit",
        "w" : 400
      }, {
        "h" : 387,
        "resize" : "fit",
        "w" : 400
      } ],
      "display_url" : "pic.twitter.com\/FU8khv6dkn"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "615576244516712448",
  "text" : "RT @TheScienceWeb: . @Y_Gilad maybe this is appropriate http:\/\/t.co\/FU8khv6dkn",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Yoav Gilad",
        "screen_name" : "Y_Gilad",
        "indices" : [ 2, 10 ],
        "id_str" : "2802558480",
        "id" : 2802558480
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/TheScienceWeb\/status\/615519914363850752\/photo\/1",
        "indices" : [ 37, 59 ],
        "url" : "http:\/\/t.co\/FU8khv6dkn",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CIrEGYuWoAAQn8V.jpg",
        "id_str" : "615519913084624896",
        "id" : 615519913084624896,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CIrEGYuWoAAQn8V.jpg",
        "sizes" : [ {
          "h" : 387,
          "resize" : "fit",
          "w" : 400
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 387,
          "resize" : "fit",
          "w" : 400
        }, {
          "h" : 387,
          "resize" : "fit",
          "w" : 400
        }, {
          "h" : 387,
          "resize" : "fit",
          "w" : 400
        } ],
        "display_url" : "pic.twitter.com\/FU8khv6dkn"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "614578793882062848",
    "geo" : { },
    "id_str" : "615519914363850752",
    "in_reply_to_user_id" : 2802558480,
    "text" : ". @Y_Gilad maybe this is appropriate http:\/\/t.co\/FU8khv6dkn",
    "id" : 615519914363850752,
    "in_reply_to_status_id" : 614578793882062848,
    "created_at" : "2015-06-29 13:59:18 +0000",
    "in_reply_to_screen_name" : "Y_Gilad",
    "in_reply_to_user_id_str" : "2802558480",
    "user" : {
      "name" : "The Science Web",
      "screen_name" : "TheScienceWeb",
      "protected" : false,
      "id_str" : "2315551122",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/428172546672824320\/1lZmC7lz_normal.jpeg",
      "id" : 2315551122,
      "verified" : false
    }
  },
  "id" : 615576244516712448,
  "created_at" : "2015-06-29 17:43:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "S. Shelly Jang",
      "screen_name" : "shellyjang",
      "indices" : [ 0, 11 ],
      "id_str" : "19054513",
      "id" : 19054513
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "615534158899576833",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17220258536844, 8.627647737893877 ]
  },
  "id_str" : "615547149921550336",
  "in_reply_to_user_id" : 19054513,
  "text" : "@shellyjang perfect, you should have new mail. :)",
  "id" : 615547149921550336,
  "in_reply_to_status_id" : 615534158899576833,
  "created_at" : "2015-06-29 15:47:31 +0000",
  "in_reply_to_screen_name" : "shellyjang",
  "in_reply_to_user_id_str" : "19054513",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BOSC2015",
      "indices" : [ 34, 43 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17218098298954, 8.627666394092733 ]
  },
  "id_str" : "615540747022893056",
  "text" : "Poster 1\/2 \u2611\uFE0F Now for the one for #BOSC2015\u2026",
  "id" : 615540747022893056,
  "created_at" : "2015-06-29 15:22:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sebastian Greiner",
      "screen_name" : "Seb666",
      "indices" : [ 0, 7 ],
      "id_str" : "2365333778",
      "id" : 2365333778
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "615534159260479488",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17224457650428, 8.627609355802239 ]
  },
  "id_str" : "615539090155569154",
  "in_reply_to_user_id" : 2365333778,
  "text" : "@Seb666 ja, so richtig sinnvoll ist das alles nicht. Und ich vermisse Vinyl ;)",
  "id" : 615539090155569154,
  "in_reply_to_status_id" : 615534159260479488,
  "created_at" : "2015-06-29 15:15:29 +0000",
  "in_reply_to_screen_name" : "Seb666",
  "in_reply_to_user_id_str" : "2365333778",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sebastian Greiner",
      "screen_name" : "Seb666",
      "indices" : [ 0, 7 ],
      "id_str" : "2365333778",
      "id" : 2365333778
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "615533351378755585",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17226823644407, 8.627586040871629 ]
  },
  "id_str" : "615533523672371201",
  "in_reply_to_user_id" : 2365333778,
  "text" : "@Seb666 ah, das kleine sieht mehr nach MiniDisk aus! (was es ja auch gibt \uD83D\uDCBD)",
  "id" : 615533523672371201,
  "in_reply_to_status_id" : 615533351378755585,
  "created_at" : "2015-06-29 14:53:22 +0000",
  "in_reply_to_screen_name" : "Seb666",
  "in_reply_to_user_id_str" : "2365333778",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 34 ],
      "url" : "https:\/\/t.co\/8GUjBp7Es3",
      "expanded_url" : "https:\/\/instagram.com\/p\/4hFsushwk2\/",
      "display_url" : "instagram.com\/p\/4hFsushwk2\/"
    } ]
  },
  "geo" : { },
  "id_str" : "615532634303799297",
  "text" : "ad nauseam https:\/\/t.co\/8GUjBp7Es3",
  "id" : 615532634303799297,
  "created_at" : "2015-06-29 14:49:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "S. Shelly Jang",
      "screen_name" : "shellyjang",
      "indices" : [ 0, 11 ],
      "id_str" : "19054513",
      "id" : 19054513
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "615532179745955842",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17222553481981, 8.62763182774273 ]
  },
  "id_str" : "615532423464550400",
  "in_reply_to_user_id" : 19054513,
  "text" : "@shellyjang already started drafting an email because it doesn\u2019t fit 140chars. :-)",
  "id" : 615532423464550400,
  "in_reply_to_status_id" : 615532179745955842,
  "created_at" : "2015-06-29 14:49:00 +0000",
  "in_reply_to_screen_name" : "shellyjang",
  "in_reply_to_user_id_str" : "19054513",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "renamed @sckottie",
      "screen_name" : "recology_",
      "indices" : [ 3, 13 ],
      "id_str" : "4465848374",
      "id" : 4465848374
    }, {
      "name" : "Science Magazine",
      "screen_name" : "sciencemagazine",
      "indices" : [ 50, 66 ],
      "id_str" : "32372834",
      "id" : 32372834
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/raaidXpexW",
      "expanded_url" : "https:\/\/twitter.com\/brembs\/status\/615524923742752768",
      "display_url" : "twitter.com\/brembs\/status\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "615530674305548288",
  "text" : "RT @recology_: plz do not submit anything ever to @sciencemagazine while Anderson is at the helm  https:\/\/t.co\/raaidXpexW",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Science Magazine",
        "screen_name" : "sciencemagazine",
        "indices" : [ 35, 51 ],
        "id_str" : "32372834",
        "id" : 32372834
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 83, 106 ],
        "url" : "https:\/\/t.co\/raaidXpexW",
        "expanded_url" : "https:\/\/twitter.com\/brembs\/status\/615524923742752768",
        "display_url" : "twitter.com\/brembs\/status\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "615527265565286400",
    "text" : "plz do not submit anything ever to @sciencemagazine while Anderson is at the helm  https:\/\/t.co\/raaidXpexW",
    "id" : 615527265565286400,
    "created_at" : "2015-06-29 14:28:30 +0000",
    "user" : {
      "name" : "scott",
      "screen_name" : "sckottie",
      "protected" : false,
      "id_str" : "103004948",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/806575041135726593\/tnm7p6Zp_normal.jpg",
      "id" : 103004948,
      "verified" : false
    }
  },
  "id" : 615530674305548288,
  "created_at" : "2015-06-29 14:42:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sebastian Greiner",
      "screen_name" : "Seb666",
      "indices" : [ 0, 7 ],
      "id_str" : "2365333778",
      "id" : 2365333778
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "615520798019846144",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17225370846811, 8.6276171970532 ]
  },
  "id_str" : "615522082487713792",
  "in_reply_to_user_id" : 2365333778,
  "text" : "@Seb666 das ist ja super, und dieses \uD83D\uDCC0(DVD) taucht dann wie auf?",
  "id" : 615522082487713792,
  "in_reply_to_status_id" : 615520798019846144,
  "created_at" : "2015-06-29 14:07:54 +0000",
  "in_reply_to_screen_name" : "Seb666",
  "in_reply_to_user_id_str" : "2365333778",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sebastian Greiner",
      "screen_name" : "Seb666",
      "indices" : [ 0, 7 ],
      "id_str" : "2365333778",
      "id" : 2365333778
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "615520693715927040",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17220348118673, 8.627654006103612 ]
  },
  "id_str" : "615521742770057216",
  "in_reply_to_user_id" : 2365333778,
  "text" : "@Seb666 please enter \uD83D\uDCBE 4\/15 to continue reading the tweet.",
  "id" : 615521742770057216,
  "in_reply_to_status_id" : 615520693715927040,
  "created_at" : "2015-06-29 14:06:33 +0000",
  "in_reply_to_screen_name" : "Seb666",
  "in_reply_to_user_id_str" : "2365333778",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sebastian Greiner",
      "screen_name" : "Seb666",
      "indices" : [ 0, 7 ],
      "id_str" : "2365333778",
      "id" : 2365333778
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "615520136750080000",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17223946229542, 8.627613463162175 ]
  },
  "id_str" : "615520320984891392",
  "in_reply_to_user_id" : 2365333778,
  "text" : "@Seb666 kannst sie dazu noch zusammentapen und einen gro\u00DFen draus machen \uD83D\uDD28",
  "id" : 615520320984891392,
  "in_reply_to_status_id" : 615520136750080000,
  "created_at" : "2015-06-29 14:00:54 +0000",
  "in_reply_to_screen_name" : "Seb666",
  "in_reply_to_user_id_str" : "2365333778",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sebastian Greiner",
      "screen_name" : "Seb666",
      "indices" : [ 0, 7 ],
      "id_str" : "2365333778",
      "id" : 2365333778
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "615519057480171520",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17220744102539, 8.627636628773846 ]
  },
  "id_str" : "615519781735768064",
  "in_reply_to_user_id" : 2365333778,
  "text" : "@Seb666 da ist noch so eine Kiste auf der R\u00FCckbank \uD83D\uDE34",
  "id" : 615519781735768064,
  "in_reply_to_status_id" : 615519057480171520,
  "created_at" : "2015-06-29 13:58:46 +0000",
  "in_reply_to_screen_name" : "Seb666",
  "in_reply_to_user_id_str" : "2365333778",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/0QOgAcfKKH",
      "expanded_url" : "http:\/\/scottsworlds.blogspot.com.au\/2015\/06\/what-personality-features-do-heroes-and.html",
      "display_url" : "scottsworlds.blogspot.com.au\/2015\/06\/what-p\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17219801705389, 8.627645315516773 ]
  },
  "id_str" : "615517730947600384",
  "text" : "In which our psychopath learns that he might be a hero (or vice versa) http:\/\/t.co\/0QOgAcfKKH",
  "id" : 615517730947600384,
  "created_at" : "2015-06-29 13:50:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "S. Shelly Jang",
      "screen_name" : "shellyjang",
      "indices" : [ 84, 95 ],
      "id_str" : "19054513",
      "id" : 19054513
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17223087756407, 8.627636133875246 ]
  },
  "id_str" : "615503352496017408",
  "text" : "Not getting any work done as I\u2019m preoccupied doing comparative memomics. (Thanks to @shellyjang for helping out with this!)",
  "id" : 615503352496017408,
  "created_at" : "2015-06-29 12:53:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 0, 9 ],
      "id_str" : "14245811",
      "id" : 14245811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "615493038438088704",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17225009462146, 8.627630142889712 ]
  },
  "id_str" : "615493505171988480",
  "in_reply_to_user_id" : 14245811,
  "text" : "@wilbanks wonder whether it\u2019s the cultural divide, because over here everyone is already super-freaked out over these things. ;-)",
  "id" : 615493505171988480,
  "in_reply_to_status_id" : 615493038438088704,
  "created_at" : "2015-06-29 12:14:21 +0000",
  "in_reply_to_screen_name" : "wilbanks",
  "in_reply_to_user_id_str" : "14245811",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 0, 9 ],
      "id_str" : "14245811",
      "id" : 14245811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "615489731049164800",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722446856217, 8.627605522628835 ]
  },
  "id_str" : "615492023450238976",
  "in_reply_to_user_id" : 14245811,
  "text" : "@wilbanks interesting, though somewhat \u2018news at 11\u2019, isn\u2019t it?",
  "id" : 615492023450238976,
  "in_reply_to_status_id" : 615489731049164800,
  "created_at" : "2015-06-29 12:08:28 +0000",
  "in_reply_to_screen_name" : "wilbanks",
  "in_reply_to_user_id_str" : "14245811",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 3, 12 ],
      "id_str" : "14245811",
      "id" : 14245811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "615491834542968832",
  "text" : "RT @wilbanks: Data as an acquisition asset. Massive implications for wearables and health, especially if there\u2019s a crash... http:\/\/t.co\/41K\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 110, 132 ],
        "url" : "http:\/\/t.co\/41K25ZAQTP",
        "expanded_url" : "http:\/\/www.nytimes.com\/2015\/06\/29\/technology\/when-a-company-goes-up-for-sale-in-many-cases-so-does-your-personal-data.html?action=click&pgtype=Homepage&version=Moth-Visible&module=inside-nyt-region&region=inside-nyt-region&WT.nav=inside-nyt-region",
        "display_url" : "nytimes.com\/2015\/06\/29\/tec\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "615489731049164800",
    "text" : "Data as an acquisition asset. Massive implications for wearables and health, especially if there\u2019s a crash... http:\/\/t.co\/41K25ZAQTP",
    "id" : 615489731049164800,
    "created_at" : "2015-06-29 11:59:21 +0000",
    "user" : {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "protected" : false,
      "id_str" : "14245811",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/925696899566440448\/BUTdp410_normal.jpg",
      "id" : 14245811,
      "verified" : false
    }
  },
  "id" : 615491834542968832,
  "created_at" : "2015-06-29 12:07:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 87 ],
      "url" : "https:\/\/t.co\/WiBgmn8CXR",
      "expanded_url" : "https:\/\/giphy.com\/gifs\/cheezburger-cat-funny-kitties-afSphlf3r9PEY",
      "display_url" : "giphy.com\/gifs\/cheezburg\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "615451477201567745",
  "text" : "\u00ABAll\u2019s fair in love, war and in front of the espresso machine!\u00BB https:\/\/t.co\/WiBgmn8CXR",
  "id" : 615451477201567745,
  "created_at" : "2015-06-29 09:27:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alicia Oshlack",
      "screen_name" : "AliciaOshlack",
      "indices" : [ 3, 17 ],
      "id_str" : "1547838528",
      "id" : 1547838528
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "615450690077466624",
  "text" : "RT @AliciaOshlack: What would be a suitable absolute minimum proportion of female speakers at genomics\/bioinformatics conferences? http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 112, 134 ],
        "url" : "http:\/\/t.co\/gIqR8GbB6R",
        "expanded_url" : "http:\/\/www.acgt.me\/blog\/2015\/6\/28\/what-would-be-a-suitable-value-for-the-absolute-minimum-proportion-of-female-speakers-at-genomicsbioinformatics-conferences",
        "display_url" : "acgt.me\/blog\/2015\/6\/28\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "615417388897447936",
    "text" : "What would be a suitable absolute minimum proportion of female speakers at genomics\/bioinformatics conferences? http:\/\/t.co\/gIqR8GbB6R",
    "id" : 615417388897447936,
    "created_at" : "2015-06-29 07:11:54 +0000",
    "user" : {
      "name" : "Alicia Oshlack",
      "screen_name" : "AliciaOshlack",
      "protected" : false,
      "id_str" : "1547838528",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000048282091\/9d197d1a49966509cb4c9f9cc0fa43c0_normal.jpeg",
      "id" : 1547838528,
      "verified" : false
    }
  },
  "id" : 615450690077466624,
  "created_at" : "2015-06-29 09:24:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723092993545, 8.627559929895702 ]
  },
  "id_str" : "615429246442471425",
  "text" : "Is there a consensus about using emoji in reviews? E.g. If you reject, at least include some fun pictures? \uD83C\uDF0B",
  "id" : 615429246442471425,
  "created_at" : "2015-06-29 07:59:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "S. Shelly Jang",
      "screen_name" : "shellyjang",
      "indices" : [ 0, 11 ],
      "id_str" : "19054513",
      "id" : 19054513
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "615252112570609664",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11408298532552, 8.753317317804042 ]
  },
  "id_str" : "615252453198577664",
  "in_reply_to_user_id" : 19054513,
  "text" : "@shellyjang Always think positive. Though every passing day makes it more unlikely to catch up. ;)",
  "id" : 615252453198577664,
  "in_reply_to_status_id" : 615252112570609664,
  "created_at" : "2015-06-28 20:16:30 +0000",
  "in_reply_to_screen_name" : "shellyjang",
  "in_reply_to_user_id_str" : "19054513",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "S. Shelly Jang",
      "screen_name" : "shellyjang",
      "indices" : [ 0, 11 ],
      "id_str" : "19054513",
      "id" : 19054513
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "615249533543428096",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11408303444266, 8.753317623923676 ]
  },
  "id_str" : "615249904999473152",
  "in_reply_to_user_id" : 19054513,
  "text" : "@shellyjang thanks. I won\u2019t blame grad school though. It made me appreciate that I\u2019m so far working with ~50% missing data for 2015. ;-)",
  "id" : 615249904999473152,
  "in_reply_to_status_id" : 615249533543428096,
  "created_at" : "2015-06-28 20:06:22 +0000",
  "in_reply_to_screen_name" : "shellyjang",
  "in_reply_to_user_id_str" : "19054513",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "S. Shelly Jang",
      "screen_name" : "shellyjang",
      "indices" : [ 0, 11 ],
      "id_str" : "19054513",
      "id" : 19054513
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "615248614680457216",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11408379416326, 8.753315162927109 ]
  },
  "id_str" : "615248949813886976",
  "in_reply_to_user_id" : 19054513,
  "text" : "@shellyjang nope, unfortunately not. I meant \uD83D\uDCC9 all the way.",
  "id" : 615248949813886976,
  "in_reply_to_status_id" : 615248614680457216,
  "created_at" : "2015-06-28 20:02:35 +0000",
  "in_reply_to_screen_name" : "shellyjang",
  "in_reply_to_user_id_str" : "19054513",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "S. Shelly Jang",
      "screen_name" : "shellyjang",
      "indices" : [ 0, 11 ],
      "id_str" : "19054513",
      "id" : 19054513
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "615243990393204736",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11408302983037, 8.753317640398318 ]
  },
  "id_str" : "615245315428511744",
  "in_reply_to_user_id" : 19054513,
  "text" : "@shellyjang sorry, should be 1gram and not 1mer given the context ;)",
  "id" : 615245315428511744,
  "in_reply_to_status_id" : 615243990393204736,
  "created_at" : "2015-06-28 19:48:08 +0000",
  "in_reply_to_screen_name" : "shellyjang",
  "in_reply_to_user_id_str" : "19054513",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "S. Shelly Jang",
      "screen_name" : "shellyjang",
      "indices" : [ 0, 11 ],
      "id_str" : "19054513",
      "id" : 19054513
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "615243990393204736",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11407020305623, 8.753363585763754 ]
  },
  "id_str" : "615244725528985600",
  "in_reply_to_user_id" : 19054513,
  "text" : "@shellyjang for the happier trends: let\u2019s just say that the #1 largest decrease going from 14-&gt;15 is actually \u201Cin love\u201D (1mer in German).",
  "id" : 615244725528985600,
  "in_reply_to_status_id" : 615243990393204736,
  "created_at" : "2015-06-28 19:45:47 +0000",
  "in_reply_to_screen_name" : "shellyjang",
  "in_reply_to_user_id_str" : "19054513",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "S. Shelly Jang",
      "screen_name" : "shellyjang",
      "indices" : [ 0, 11 ],
      "id_str" : "19054513",
      "id" : 19054513
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "615243990393204736",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11407020305623, 8.753363585763754 ]
  },
  "id_str" : "615244291129114624",
  "in_reply_to_user_id" : 19054513,
  "text" : "@shellyjang yeah, the difference from going 1st to 2nd year grad school. ;-)",
  "id" : 615244291129114624,
  "in_reply_to_status_id" : 615243990393204736,
  "created_at" : "2015-06-28 19:44:04 +0000",
  "in_reply_to_screen_name" : "shellyjang",
  "in_reply_to_user_id_str" : "19054513",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "615163323563249664",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11391833300392, 8.753625516817419 ]
  },
  "id_str" : "615168042180472833",
  "in_reply_to_user_id" : 14286491,
  "text" : "Comparing data from 2013 past-me to 2014 past-me: Word w\/ highest decrease in usage is \u2019glad\u2019. The highest increase is \u2019crashed\u2019. Go figure\u2026",
  "id" : 615168042180472833,
  "in_reply_to_status_id" : 615163323563249664,
  "created_at" : "2015-06-28 14:41:05 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "S. Shelly Jang",
      "screen_name" : "shellyjang",
      "indices" : [ 136, 147 ],
      "id_str" : "19054513",
      "id" : 19054513
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11411898376266, 8.753231045607984 ]
  },
  "id_str" : "615163323563249664",
  "text" : "Comparing overrep. 2grams btwn 2 chat corpora. In C1: \u201Cassuming that\u201D &amp; \u201Cconditional that\u201D. In C2: \u201Cvery nice\u201D &amp; \u201Cnot perfect\u201D \/@shellyjang",
  "id" : 615163323563249664,
  "created_at" : "2015-06-28 14:22:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sebastian Greiner",
      "screen_name" : "Seb666",
      "indices" : [ 0, 7 ],
      "id_str" : "2365333778",
      "id" : 2365333778
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "615093043507634176",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11408162520255, 8.753320879613506 ]
  },
  "id_str" : "615093680098181120",
  "in_reply_to_user_id" : 2365333778,
  "text" : "@Seb666 so h\u00FCbsch :)",
  "id" : 615093680098181120,
  "in_reply_to_status_id" : 615093043507634176,
  "created_at" : "2015-06-28 09:45:35 +0000",
  "in_reply_to_screen_name" : "Seb666",
  "in_reply_to_user_id_str" : "2365333778",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Brechler",
      "screen_name" : "plaetzchen",
      "indices" : [ 0, 11 ],
      "id_str" : "14305613",
      "id" : 14305613
    }, {
      "name" : "Birgit Rydlewski",
      "screen_name" : "B_Rydlewski",
      "indices" : [ 12, 24 ],
      "id_str" : "952073058",
      "id" : 952073058
    }, {
      "name" : "P\u00F6nig",
      "screen_name" : "OldHolgi_PP",
      "indices" : [ 25, 37 ],
      "id_str" : "88326034",
      "id" : 88326034
    }, {
      "name" : "Torsten Sommer",
      "screen_name" : "tosopiratas",
      "indices" : [ 38, 50 ],
      "id_str" : "99694646",
      "id" : 99694646
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "615086010007949312",
  "geo" : { },
  "id_str" : "615086983040356352",
  "in_reply_to_user_id" : 14305613,
  "text" : "@plaetzchen @B_Rydlewski @OldHolgi_PP @tosopiratas immerhin keine Nackten im Kalender. Aber die Freiheit f\u00FChrt das Volk mit Piratenflagge.",
  "id" : 615086983040356352,
  "in_reply_to_status_id" : 615086010007949312,
  "created_at" : "2015-06-28 09:18:59 +0000",
  "in_reply_to_screen_name" : "plaetzchen",
  "in_reply_to_user_id_str" : "14305613",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Birgit Rydlewski",
      "screen_name" : "B_Rydlewski",
      "indices" : [ 0, 12 ],
      "id_str" : "952073058",
      "id" : 952073058
    }, {
      "name" : "P\u00F6nig",
      "screen_name" : "OldHolgi_PP",
      "indices" : [ 13, 25 ],
      "id_str" : "88326034",
      "id" : 88326034
    }, {
      "name" : "Torsten Sommer",
      "screen_name" : "tosopiratas",
      "indices" : [ 26, 38 ],
      "id_str" : "99694646",
      "id" : 99694646
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 68 ],
      "url" : "https:\/\/t.co\/5PBJPGPMG0",
      "expanded_url" : "https:\/\/twitter.com\/Senficon\/status\/614504408848723968",
      "display_url" : "twitter.com\/Senficon\/statu\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "615073158052380672",
  "geo" : { },
  "id_str" : "615085555324452864",
  "in_reply_to_user_id" : 952073058,
  "text" : "@B_Rydlewski @OldHolgi_PP @tosopiratas siehe https:\/\/t.co\/5PBJPGPMG0 ;)",
  "id" : 615085555324452864,
  "in_reply_to_status_id" : 615073158052380672,
  "created_at" : "2015-06-28 09:13:18 +0000",
  "in_reply_to_screen_name" : "B_Rydlewski",
  "in_reply_to_user_id_str" : "952073058",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Dierk Haasis",
      "screen_name" : "Evo2Me",
      "indices" : [ 14, 21 ],
      "id_str" : "22910316",
      "id" : 22910316
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "614835004967813120",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11408176410829, 8.753323467074761 ]
  },
  "id_str" : "614835255481114624",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @Evo2Me sounds more like the Philipp I knew ;)",
  "id" : 614835255481114624,
  "in_reply_to_status_id" : 614835004967813120,
  "created_at" : "2015-06-27 16:38:42 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Dierk Haasis",
      "screen_name" : "Evo2Me",
      "indices" : [ 14, 21 ],
      "id_str" : "22910316",
      "id" : 22910316
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "614834170771210240",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11408185289041, 8.753325120812981 ]
  },
  "id_str" : "614834733231525888",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @Evo2Me What happened that you\u2019re willing to run 5k? :D",
  "id" : 614834733231525888,
  "in_reply_to_status_id" : 614834170771210240,
  "created_at" : "2015-06-27 16:36:38 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "614834066806939648",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11408157837742, 8.753320572372905 ]
  },
  "id_str" : "614834541983866881",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer yeah, now I only need to find a print-shop that doesn\u2019t use Linux :D",
  "id" : 614834541983866881,
  "in_reply_to_status_id" : 614834066806939648,
  "created_at" : "2015-06-27 16:35:52 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "614425987854503936",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11408157837742, 8.753320572372905 ]
  },
  "id_str" : "614833808244871168",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer lol, now printed the poster from my Mac: No weirdo lines show up. Arrows are large enough as well.",
  "id" : 614833808244871168,
  "in_reply_to_status_id" : 614425987854503936,
  "created_at" : "2015-06-27 16:32:57 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "614831533745131520",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11408168148441, 8.753322487187218 ]
  },
  "id_str" : "614833161802018816",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer try smoking!",
  "id" : 614833161802018816,
  "in_reply_to_status_id" : 614831533745131520,
  "created_at" : "2015-06-27 16:30:23 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "614798302295519232",
  "geo" : { },
  "id_str" : "614810698816860160",
  "in_reply_to_user_id" : 845091326,
  "text" : "@randogp i hope you will do some in Basel as well!",
  "id" : 614810698816860160,
  "in_reply_to_status_id" : 614798302295519232,
  "created_at" : "2015-06-27 15:01:07 +0000",
  "in_reply_to_screen_name" : "gianpaolo_rando",
  "in_reply_to_user_id_str" : "845091326",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Beer DeCoded",
      "screen_name" : "beerdecoded",
      "indices" : [ 25, 37 ],
      "id_str" : "3295237359",
      "id" : 3295237359
    }, {
      "name" : "Kickstarter",
      "screen_name" : "kickstarter",
      "indices" : [ 49, 61 ],
      "id_str" : "16186995",
      "id" : 16186995
    }, {
      "name" : "LemanMake",
      "screen_name" : "LemanMake",
      "indices" : [ 100, 110 ],
      "id_str" : "2527771676",
      "id" : 2527771676
    }, {
      "name" : "Hackuarium",
      "screen_name" : "hackuarium",
      "indices" : [ 111, 122 ],
      "id_str" : "2418603105",
      "id" : 2418603105
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "614810611520815104",
  "text" : "RT @randogp: Celebrating @beerdecoded successful @kickstarter campaign with cryogenic beer icecream @LemanMake @hackuarium http:\/\/t.co\/60PU\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Beer DeCoded",
        "screen_name" : "beerdecoded",
        "indices" : [ 12, 24 ],
        "id_str" : "3295237359",
        "id" : 3295237359
      }, {
        "name" : "Kickstarter",
        "screen_name" : "kickstarter",
        "indices" : [ 36, 48 ],
        "id_str" : "16186995",
        "id" : 16186995
      }, {
        "name" : "LemanMake",
        "screen_name" : "LemanMake",
        "indices" : [ 87, 97 ],
        "id_str" : "2527771676",
        "id" : 2527771676
      }, {
        "name" : "Hackuarium",
        "screen_name" : "hackuarium",
        "indices" : [ 98, 109 ],
        "id_str" : "2418603105",
        "id" : 2418603105
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/randogp\/status\/614798302295519232\/photo\/1",
        "indices" : [ 110, 132 ],
        "url" : "http:\/\/t.co\/60PUl5Upwq",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CIgzyMjUkAAxNwK.jpg",
        "id_str" : "614798286591922176",
        "id" : 614798286591922176,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CIgzyMjUkAAxNwK.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/60PUl5Upwq"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "614798302295519232",
    "text" : "Celebrating @beerdecoded successful @kickstarter campaign with cryogenic beer icecream @LemanMake @hackuarium http:\/\/t.co\/60PUl5Upwq",
    "id" : 614798302295519232,
    "created_at" : "2015-06-27 14:11:52 +0000",
    "user" : {
      "name" : "Gianpaolo Rando",
      "screen_name" : "gianpaolo_rando",
      "protected" : false,
      "id_str" : "845091326",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/809121428738113536\/RRd0IpGg_normal.jpg",
      "id" : 845091326,
      "verified" : false
    }
  },
  "id" : 614810611520815104,
  "created_at" : "2015-06-27 15:00:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 67 ],
      "url" : "http:\/\/t.co\/gU9VVdBmxk",
      "expanded_url" : "http:\/\/sweza.com\/a6.html",
      "display_url" : "sweza.com\/a6.html"
    } ]
  },
  "geo" : { },
  "id_str" : "614773416391012353",
  "text" : "Part of the \u2018Hamster Hipster Handy\u2019 exhibit: http:\/\/t.co\/gU9VVdBmxk",
  "id" : 614773416391012353,
  "created_at" : "2015-06-27 12:32:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 51 ],
      "url" : "https:\/\/t.co\/Th4rLGBW0L",
      "expanded_url" : "https:\/\/instagram.com\/p\/4bptejhwo2\/",
      "display_url" : "instagram.com\/p\/4bptejhwo2\/"
    } ]
  },
  "geo" : { },
  "id_str" : "614767399636746240",
  "text" : "the age of blogging is over https:\/\/t.co\/Th4rLGBW0L",
  "id" : 614767399636746240,
  "created_at" : "2015-06-27 12:09:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RoterFranz",
      "screen_name" : "RoterFranz",
      "indices" : [ 0, 11 ],
      "id_str" : "3177839572",
      "id" : 3177839572
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "614734767666409472",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11408138695577, 8.753316802816345 ]
  },
  "id_str" : "614742812018536448",
  "in_reply_to_user_id" : 3177839572,
  "text" : "@RoterFranz i could imagine scenarios where they survive. But still natural selection could never act on it, drift at best.",
  "id" : 614742812018536448,
  "in_reply_to_status_id" : 614734767666409472,
  "created_at" : "2015-06-27 10:31:22 +0000",
  "in_reply_to_screen_name" : "RoterFranz",
  "in_reply_to_user_id_str" : "3177839572",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RoterFranz",
      "screen_name" : "RoterFranz",
      "indices" : [ 0, 11 ],
      "id_str" : "3177839572",
      "id" : 3177839572
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "614733265694552064",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1140002018266, 8.752910915232906 ]
  },
  "id_str" : "614734436849029120",
  "in_reply_to_user_id" : 3177839572,
  "text" : "@RoterFranz yeah, always amazing if evo-psychos didn\u2019t even listen to evolutionary biology 101.",
  "id" : 614734436849029120,
  "in_reply_to_status_id" : 614733265694552064,
  "created_at" : "2015-06-27 09:58:05 +0000",
  "in_reply_to_screen_name" : "RoterFranz",
  "in_reply_to_user_id_str" : "3177839572",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "614733120756183040",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11408126051172, 8.75331398005951 ]
  },
  "id_str" : "614733676371410944",
  "in_reply_to_user_id" : 14286491,
  "text" : "Just reading this makes me wish for a swift death, and my to-be-born offspring will totally benefit from me acting on it\u2026",
  "id" : 614733676371410944,
  "in_reply_to_status_id" : 614733120756183040,
  "created_at" : "2015-06-27 09:55:04 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11408126051172, 8.75331398005951 ]
  },
  "id_str" : "614733120756183040",
  "text" : "\u00ABStephen Porges has hypothesized that freeze is a stress response that facilitates a painless death.\u00BB Evolutionary Psych nonsense today\u2026",
  "id" : 614733120756183040,
  "created_at" : "2015-06-27 09:52:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Ryan",
      "screen_name" : "mikeryan",
      "indices" : [ 3, 12 ],
      "id_str" : "20790079",
      "id" : 20790079
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "614565931998707712",
  "text" : "RT @mikeryan: Today feels like a West Wing episode from season two.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "614536646197923840",
    "text" : "Today feels like a West Wing episode from season two.",
    "id" : 614536646197923840,
    "created_at" : "2015-06-26 20:52:08 +0000",
    "user" : {
      "name" : "Mike Ryan",
      "screen_name" : "mikeryan",
      "protected" : false,
      "id_str" : "20790079",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539883009357254656\/lOs9SVTI_normal.jpeg",
      "id" : 20790079,
      "verified" : true
    }
  },
  "id" : 614565931998707712,
  "created_at" : "2015-06-26 22:48:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 74 ],
      "url" : "http:\/\/t.co\/dQIsex0qUW",
      "expanded_url" : "http:\/\/www.newyorker.com\/news\/daily-comment\/god-and-marriage-equality?mbid=rss",
      "display_url" : "newyorker.com\/news\/daily-com\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "614563282960154628",
  "text" : "\u00ABGod may reign, but He (or She) doesn\u2019t legislate.\u00BB http:\/\/t.co\/dQIsex0qUW",
  "id" : 614563282960154628,
  "created_at" : "2015-06-26 22:37:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "614504408848723968",
  "geo" : { },
  "id_str" : "614504715108417536",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon man nennt mich auch den Mark Zuckerberg der Panoramafreiheit!",
  "id" : 614504715108417536,
  "in_reply_to_status_id" : 614504408848723968,
  "created_at" : "2015-06-26 18:45:15 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11408201740338, 8.753312203950095 ]
  },
  "id_str" : "614482569556533249",
  "text" : "\u00ABKeine Sorge! Ich schweige wie ein Grab.\u00BB\u2014\u00ABDu w\u00E4rest der perfekte V-Mann. Na gut, du bist nicht rechtsradikal, aber sonst\u2026\u00BB",
  "id" : 614482569556533249,
  "created_at" : "2015-06-26 17:17:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Greg Lipper",
      "screen_name" : "theglipper",
      "indices" : [ 3, 14 ],
      "id_str" : "100421516",
      "id" : 100421516
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/theglipper\/status\/614449130048487424\/photo\/1",
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/4F6yTcIW3H",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CIb2OiRWcAE1bws.png",
      "id_str" : "614449128760832001",
      "id" : 614449128760832001,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CIb2OiRWcAE1bws.png",
      "sizes" : [ {
        "h" : 990,
        "resize" : "fit",
        "w" : 2026
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 990,
        "resize" : "fit",
        "w" : 2026
      }, {
        "h" : 586,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 332,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/4F6yTcIW3H"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/Hdq8BLa0L9",
      "expanded_url" : "http:\/\/www.theonion.com\/article\/scalia-thomas-roberts-alito-suddenly-realize-they--32972",
      "display_url" : "theonion.com\/article\/scalia\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "614469222203269120",
  "text" : "RT @theglipper: The Onion looking even more prescient, btw: http:\/\/t.co\/Hdq8BLa0L9 http:\/\/t.co\/4F6yTcIW3H",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/theglipper\/status\/614449130048487424\/photo\/1",
        "indices" : [ 67, 89 ],
        "url" : "http:\/\/t.co\/4F6yTcIW3H",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CIb2OiRWcAE1bws.png",
        "id_str" : "614449128760832001",
        "id" : 614449128760832001,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CIb2OiRWcAE1bws.png",
        "sizes" : [ {
          "h" : 990,
          "resize" : "fit",
          "w" : 2026
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 990,
          "resize" : "fit",
          "w" : 2026
        }, {
          "h" : 586,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 332,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/4F6yTcIW3H"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 44, 66 ],
        "url" : "http:\/\/t.co\/Hdq8BLa0L9",
        "expanded_url" : "http:\/\/www.theonion.com\/article\/scalia-thomas-roberts-alito-suddenly-realize-they--32972",
        "display_url" : "theonion.com\/article\/scalia\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "614449130048487424",
    "text" : "The Onion looking even more prescient, btw: http:\/\/t.co\/Hdq8BLa0L9 http:\/\/t.co\/4F6yTcIW3H",
    "id" : 614449130048487424,
    "created_at" : "2015-06-26 15:04:23 +0000",
    "user" : {
      "name" : "Greg Lipper",
      "screen_name" : "theglipper",
      "protected" : false,
      "id_str" : "100421516",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/434753947367395328\/HXxiU1US_normal.jpeg",
      "id" : 100421516,
      "verified" : false
    }
  },
  "id" : 614469222203269120,
  "created_at" : "2015-06-26 16:24:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Larry Madill",
      "screen_name" : "larrymadill",
      "indices" : [ 3, 15 ],
      "id_str" : "16696109",
      "id" : 16696109
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/larrymadill\/status\/614438378767912960\/photo\/1",
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/YUqPfQ5I7Y",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CIbscvcVAAApHZX.jpg",
      "id_str" : "614438377698426880",
      "id" : 614438377698426880,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CIbscvcVAAApHZX.jpg",
      "sizes" : [ {
        "h" : 356,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 356,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 356,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 356,
        "resize" : "fit",
        "w" : 500
      } ],
      "display_url" : "pic.twitter.com\/YUqPfQ5I7Y"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "614439555224207360",
  "text" : "RT @larrymadill: And now we go live to Republicans who still oppose gay marriage http:\/\/t.co\/YUqPfQ5I7Y",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/larrymadill\/status\/614438378767912960\/photo\/1",
        "indices" : [ 64, 86 ],
        "url" : "http:\/\/t.co\/YUqPfQ5I7Y",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CIbscvcVAAApHZX.jpg",
        "id_str" : "614438377698426880",
        "id" : 614438377698426880,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CIbscvcVAAApHZX.jpg",
        "sizes" : [ {
          "h" : 356,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 356,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 356,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 356,
          "resize" : "fit",
          "w" : 500
        } ],
        "display_url" : "pic.twitter.com\/YUqPfQ5I7Y"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "614438378767912960",
    "text" : "And now we go live to Republicans who still oppose gay marriage http:\/\/t.co\/YUqPfQ5I7Y",
    "id" : 614438378767912960,
    "created_at" : "2015-06-26 14:21:39 +0000",
    "user" : {
      "name" : "Larry Madill",
      "screen_name" : "larrymadill",
      "protected" : false,
      "id_str" : "16696109",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/461676223941185536\/inEwjT2t_normal.jpeg",
      "id" : 16696109,
      "verified" : false
    }
  },
  "id" : 614439555224207360,
  "created_at" : "2015-06-26 14:26:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donat  Agosti",
      "screen_name" : "myrmoteras",
      "indices" : [ 3, 14 ],
      "id_str" : "43707210",
      "id" : 43707210
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "openaccess",
      "indices" : [ 44, 55 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "614438213411819520",
  "text" : "RT @myrmoteras: Interested in Biodiversity, #openaccess and publishing? Informatics? Join BI-workshop in Lima, Peru Oct 25-31, 2015  http:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "openaccess",
        "indices" : [ 28, 39 ]
      } ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/vdYYUGA7ZV",
        "expanded_url" : "http:\/\/cebioperu.org\/educacion\/cursos-talleres\/biodiversity-informatics\/",
        "display_url" : "cebioperu.org\/educacion\/curs\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "614436939886927872",
    "text" : "Interested in Biodiversity, #openaccess and publishing? Informatics? Join BI-workshop in Lima, Peru Oct 25-31, 2015  http:\/\/t.co\/vdYYUGA7ZV",
    "id" : 614436939886927872,
    "created_at" : "2015-06-26 14:15:56 +0000",
    "user" : {
      "name" : "Donat  Agosti",
      "screen_name" : "myrmoteras",
      "protected" : false,
      "id_str" : "43707210",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3301096099\/e86f4f0b4cce2f44c55ebb4bb060f70d_normal.jpeg",
      "id" : 43707210,
      "verified" : false
    }
  },
  "id" : 614438213411819520,
  "created_at" : "2015-06-26 14:21:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mem_somerville",
      "screen_name" : "mem_somerville",
      "indices" : [ 3, 18 ],
      "id_str" : "15201021",
      "id" : 15201021
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SCOTUS",
      "indices" : [ 24, 31 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "614434027563520000",
  "text" : "RT @mem_somerville: And #SCOTUS just broke the internet. Yay!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SCOTUS",
        "indices" : [ 4, 11 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "614434000170557441",
    "text" : "And #SCOTUS just broke the internet. Yay!",
    "id" : 614434000170557441,
    "created_at" : "2015-06-26 14:04:15 +0000",
    "user" : {
      "name" : "mem_somerville",
      "screen_name" : "mem_somerville",
      "protected" : false,
      "id_str" : "15201021",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/929049262591115264\/ZIPrsQlr_normal.jpg",
      "id" : 15201021,
      "verified" : false
    }
  },
  "id" : 614434027563520000,
  "created_at" : "2015-06-26 14:04:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Carter",
      "screen_name" : "joecarter",
      "indices" : [ 3, 13 ],
      "id_str" : "2724291",
      "id" : 2724291
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "614427774556749824",
  "text" : "RT @joecarter: A trigger warning for Kant's Critiques. Parents, talk to your kids before letting them read old German philosophers. http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/joecarter\/status\/614176052756262913\/photo\/1",
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/7xPA0L8GLn",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CIX9ZmFWgAAfH5U.jpg",
        "id_str" : "614175540367491072",
        "id" : 614175540367491072,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CIX9ZmFWgAAfH5U.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 320,
          "resize" : "fit",
          "w" : 480
        }, {
          "h" : 320,
          "resize" : "fit",
          "w" : 480
        }, {
          "h" : 320,
          "resize" : "fit",
          "w" : 480
        }, {
          "h" : 320,
          "resize" : "fit",
          "w" : 480
        } ],
        "display_url" : "pic.twitter.com\/7xPA0L8GLn"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "614176052756262913",
    "text" : "A trigger warning for Kant's Critiques. Parents, talk to your kids before letting them read old German philosophers. http:\/\/t.co\/7xPA0L8GLn",
    "id" : 614176052756262913,
    "created_at" : "2015-06-25 20:59:16 +0000",
    "user" : {
      "name" : "Joe Carter",
      "screen_name" : "joecarter",
      "protected" : false,
      "id_str" : "2724291",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/782131102056124416\/XdXzB7kc_normal.jpg",
      "id" : 2724291,
      "verified" : false
    }
  },
  "id" : 614427774556749824,
  "created_at" : "2015-06-26 13:39:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "614425987854503936",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17223423407197, 8.627614085249116 ]
  },
  "id_str" : "614426092212985856",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer well, we see how well the PDF thingy works ;)",
  "id" : 614426092212985856,
  "in_reply_to_status_id" : 614425987854503936,
  "created_at" : "2015-06-26 13:32:50 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "614425532604747776",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17223423407197, 8.627614085249116 ]
  },
  "id_str" : "614425659503472640",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer now gotta hope my printing guy doesn\u2019t use evince? Do you have experience dealing with freaky svgs?",
  "id" : 614425659503472640,
  "in_reply_to_status_id" : 614425532604747776,
  "created_at" : "2015-06-26 13:31:07 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "614425316686213120",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17222015800995, 8.62761180015552 ]
  },
  "id_str" : "614425472663949312",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer connecting arrows work fine though.",
  "id" : 614425472663949312,
  "in_reply_to_status_id" : 614425316686213120,
  "created_at" : "2015-06-26 13:30:22 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "614425316686213120",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17222015800995, 8.62761180015552 ]
  },
  "id_str" : "614425431543009280",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer super weird, turn up on the printout as well when printing from those tools, but only there o_O",
  "id" : 614425431543009280,
  "in_reply_to_status_id" : 614425316686213120,
  "created_at" : "2015-06-26 13:30:13 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17222015800995, 8.62761180015552 ]
  },
  "id_str" : "614425105687552000",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer strange, now saw which lines you mean. Those only show up under evince\/doc viewer on Ubuntu for me o_O",
  "id" : 614425105687552000,
  "created_at" : "2015-06-26 13:28:55 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert",
      "screen_name" : "kventil",
      "indices" : [ 0, 8 ],
      "id_str" : "7431192",
      "id" : 7431192
    }, {
      "name" : "Jonas",
      "screen_name" : "lsanoj",
      "indices" : [ 31, 38 ],
      "id_str" : "18918915",
      "id" : 18918915
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "614408497531351040",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17224831929926, 8.62756958355422 ]
  },
  "id_str" : "614408700548284416",
  "in_reply_to_user_id" : 7431192,
  "text" : "@kventil Super, ist notiert :) @lsanoj voll reingelaufen in die Falle! ;)",
  "id" : 614408700548284416,
  "in_reply_to_status_id" : 614408497531351040,
  "created_at" : "2015-06-26 12:23:44 +0000",
  "in_reply_to_screen_name" : "kventil",
  "in_reply_to_user_id_str" : "7431192",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert",
      "screen_name" : "kventil",
      "indices" : [ 0, 8 ],
      "id_str" : "7431192",
      "id" : 7431192
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "614408229041385472",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17224831929926, 8.62756958355422 ]
  },
  "id_str" : "614408425552912384",
  "in_reply_to_user_id" : 7431192,
  "text" : "@kventil sieht laut Kalender noch frei aus. :)",
  "id" : 614408425552912384,
  "in_reply_to_status_id" : 614408229041385472,
  "created_at" : "2015-06-26 12:22:38 +0000",
  "in_reply_to_screen_name" : "kventil",
  "in_reply_to_user_id_str" : "7431192",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert",
      "screen_name" : "kventil",
      "indices" : [ 0, 8 ],
      "id_str" : "7431192",
      "id" : 7431192
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "614407502298484736",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17229124443925, 8.627563789303435 ]
  },
  "id_str" : "614408027899363328",
  "in_reply_to_user_id" : 7431192,
  "text" : "@kventil ich glaube da bin ich im Urlaub. :-) Bin vom 08.-17. Juli &amp; 08.-17. August nicht in der Gegend.",
  "id" : 614408027899363328,
  "in_reply_to_status_id" : 614407502298484736,
  "created_at" : "2015-06-26 12:21:03 +0000",
  "in_reply_to_screen_name" : "kventil",
  "in_reply_to_user_id_str" : "7431192",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722166821816, 8.627603573309917 ]
  },
  "id_str" : "614375538866683904",
  "text" : "Algorithmic superiority: gmail thinks a German text is Irish and asks whether I\u2019d like a translation into English.",
  "id" : 614375538866683904,
  "created_at" : "2015-06-26 10:11:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17218117001561, 8.627654279610933 ]
  },
  "id_str" : "614364051888566272",
  "text" : "\u00ABTo me \u2018worst case\u2019 sounds like we\u2019re already expecting a distribution of bad things to happen.\u00BB\u2013\u00ABWe\u2019re doing de novo assembly, so we are!\u00BB",
  "id" : 614364051888566272,
  "created_at" : "2015-06-26 09:26:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17221006231269, 8.62762466875201 ]
  },
  "id_str" : "614337152059613184",
  "text" : "Preparing for the Penfield mood organ, so we can all dial a 382 and hear but don\u2019t feel the emptiness.",
  "id" : 614337152059613184,
  "created_at" : "2015-06-26 07:39:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julian Savulescu",
      "screen_name" : "juliansavulescu",
      "indices" : [ 3, 19 ],
      "id_str" : "115478596",
      "id" : 115478596
    }, {
      "name" : "Brian D. Earp",
      "screen_name" : "briandavidearp",
      "indices" : [ 107, 122 ],
      "id_str" : "330743859",
      "id" : 330743859
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "614336715122208772",
  "text" : "RT @juliansavulescu: Addicted to love: what is love addiction and when should it be treated  my paper with @briandavidearp (&amp; others) https\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Brian D. Earp",
        "screen_name" : "briandavidearp",
        "indices" : [ 86, 101 ],
        "id_str" : "330743859",
        "id" : 330743859
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/VQJZxmE0MF",
        "expanded_url" : "https:\/\/www.academia.edu\/13270828\/Addicted_to_Love_What_is_love_addiction_and_when_should_it_be_treated",
        "display_url" : "academia.edu\/13270828\/Addic\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "614314375898394624",
    "text" : "Addicted to love: what is love addiction and when should it be treated  my paper with @briandavidearp (&amp; others) https:\/\/t.co\/VQJZxmE0MF",
    "id" : 614314375898394624,
    "created_at" : "2015-06-26 06:08:55 +0000",
    "user" : {
      "name" : "Julian Savulescu",
      "screen_name" : "juliansavulescu",
      "protected" : false,
      "id_str" : "115478596",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/704156548\/rg_savulescu_wideweb__470x317_0_normal.jpg",
      "id" : 115478596,
      "verified" : true
    }
  },
  "id" : 614336715122208772,
  "created_at" : "2015-06-26 07:37:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/9GGBo5IEXW",
      "expanded_url" : "http:\/\/99percentinvisible.org\/episode\/children-of-the-magenta-automation-paradox-pt-1\/",
      "display_url" : "99percentinvisible.org\/episode\/childr\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17220196825355, 8.627660177540664 ]
  },
  "id_str" : "614332533103144961",
  "text" : "Thinking of my next flight\u2019s pilots  wondering \u00ABWhat\u2019s it doing now?\u00BB makes me look forward to it even more. http:\/\/t.co\/9GGBo5IEXW",
  "id" : 614332533103144961,
  "created_at" : "2015-06-26 07:21:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Loman",
      "screen_name" : "pathogenomenick",
      "indices" : [ 0, 16 ],
      "id_str" : "85906238",
      "id" : 85906238
    }, {
      "name" : "David Coil",
      "screen_name" : "davidacoil",
      "indices" : [ 17, 28 ],
      "id_str" : "155439838",
      "id" : 155439838
    }, {
      "name" : "David \u2603\uFE0FBaltrus \uD83C\uDF85\uD83C\uDF85\uD83C\uDF85\uD83C\uDF85\uD83C\uDF85\uD83C\uDF85\uD83C\uDF85\uD83C\uDF85\uD83C\uDF85\uD83C\uDF85\uD83C\uDF85\uD83C\uDF85\uD83C\uDF85\uD83C\uDF85\uD83C\uDF85",
      "screen_name" : "surt_lab",
      "indices" : [ 29, 38 ],
      "id_str" : "155230346",
      "id" : 155230346
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "614184199592001536",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11407579038946, 8.753187777800367 ]
  },
  "id_str" : "614184699985022976",
  "in_reply_to_user_id" : 85906238,
  "text" : "@pathogenomenick @davidacoil @surt_lab surely it's time to start \u2018(crappy) fungal genome announcements\u2019 then?",
  "id" : 614184699985022976,
  "in_reply_to_status_id" : 614184199592001536,
  "created_at" : "2015-06-25 21:33:38 +0000",
  "in_reply_to_screen_name" : "pathogenomenick",
  "in_reply_to_user_id_str" : "85906238",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Loman",
      "screen_name" : "pathogenomenick",
      "indices" : [ 0, 16 ],
      "id_str" : "85906238",
      "id" : 85906238
    }, {
      "name" : "David Coil",
      "screen_name" : "davidacoil",
      "indices" : [ 17, 28 ],
      "id_str" : "155439838",
      "id" : 155439838
    }, {
      "name" : "David \u2603\uFE0FBaltrus \uD83C\uDF85\uD83C\uDF85\uD83C\uDF85\uD83C\uDF85\uD83C\uDF85\uD83C\uDF85\uD83C\uDF85\uD83C\uDF85\uD83C\uDF85\uD83C\uDF85\uD83C\uDF85\uD83C\uDF85\uD83C\uDF85\uD83C\uDF85\uD83C\uDF85",
      "screen_name" : "surt_lab",
      "indices" : [ 29, 38 ],
      "id_str" : "155230346",
      "id" : 155230346
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "614173132283318273",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11408249873807, 8.753334305151549 ]
  },
  "id_str" : "614184088073826306",
  "in_reply_to_user_id" : 85906238,
  "text" : "@pathogenomenick @davidacoil @surt_lab same here, also fungal.",
  "id" : 614184088073826306,
  "in_reply_to_status_id" : 614173132283318273,
  "created_at" : "2015-06-25 21:31:12 +0000",
  "in_reply_to_screen_name" : "pathogenomenick",
  "in_reply_to_user_id_str" : "85906238",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Effy Vayena",
      "screen_name" : "EffyVayena",
      "indices" : [ 3, 14 ],
      "id_str" : "397518511",
      "id" : 397518511
    }, {
      "name" : "Outward",
      "screen_name" : "SlateOutward",
      "indices" : [ 124, 137 ],
      "id_str" : "1691501288",
      "id" : 1691501288
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/FQe8S2vAt2",
      "expanded_url" : "http:\/\/www.slate.com\/blogs\/outward\/2015\/06\/25\/in_the_scotus_same_sex_marriage_case_a_dignity_rationale_could_be_dangerous.html?wpsrc=sh_all_mob_tw_top",
      "display_url" : "slate.com\/blogs\/outward\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "614183917948653568",
  "text" : "RT @EffyVayena: Let's hope SCOTUS doesn't go with the \"dignity\" rationale for same-sex marriage: http:\/\/t.co\/FQe8S2vAt2 via @SlateOutward",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Outward",
        "screen_name" : "SlateOutward",
        "indices" : [ 108, 121 ],
        "id_str" : "1691501288",
        "id" : 1691501288
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 81, 103 ],
        "url" : "http:\/\/t.co\/FQe8S2vAt2",
        "expanded_url" : "http:\/\/www.slate.com\/blogs\/outward\/2015\/06\/25\/in_the_scotus_same_sex_marriage_case_a_dignity_rationale_could_be_dangerous.html?wpsrc=sh_all_mob_tw_top",
        "display_url" : "slate.com\/blogs\/outward\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "614182901542977536",
    "text" : "Let's hope SCOTUS doesn't go with the \"dignity\" rationale for same-sex marriage: http:\/\/t.co\/FQe8S2vAt2 via @SlateOutward",
    "id" : 614182901542977536,
    "created_at" : "2015-06-25 21:26:29 +0000",
    "user" : {
      "name" : "Effy Vayena",
      "screen_name" : "EffyVayena",
      "protected" : false,
      "id_str" : "397518511",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/837580905615085568\/EBU1zR7D_normal.jpg",
      "id" : 397518511,
      "verified" : false
    }
  },
  "id" : 614183917948653568,
  "created_at" : "2015-06-25 21:30:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 5, 28 ],
      "url" : "https:\/\/t.co\/eJqTpCCgET",
      "expanded_url" : "https:\/\/instagram.com\/p\/4XW5XQBwpf\/",
      "display_url" : "instagram.com\/p\/4XW5XQBwpf\/"
    } ]
  },
  "geo" : { },
  "id_str" : "614163077903331329",
  "text" : "Home https:\/\/t.co\/eJqTpCCgET",
  "id" : 614163077903331329,
  "created_at" : "2015-06-25 20:07:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Schawinski",
      "screen_name" : "kevinschawinski",
      "indices" : [ 0, 16 ],
      "id_str" : "242844365",
      "id" : 242844365
    }, {
      "name" : "Fake Unicode \u2199",
      "screen_name" : "FakeUnicode",
      "indices" : [ 17, 29 ],
      "id_str" : "2183231114",
      "id" : 2183231114
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "614157217080569856",
  "geo" : { },
  "id_str" : "614157613505363968",
  "in_reply_to_user_id" : 242844365,
  "text" : "@kevinschawinski @FakeUnicode I hadn\u2019t, thanks :)",
  "id" : 614157613505363968,
  "in_reply_to_status_id" : 614157217080569856,
  "created_at" : "2015-06-25 19:46:00 +0000",
  "in_reply_to_screen_name" : "kevinschawinski",
  "in_reply_to_user_id_str" : "242844365",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/qkVDmhdssS",
      "expanded_url" : "http:\/\/www.theallusionist.org\/allusionist\/emoji",
      "display_url" : "theallusionist.org\/allusionist\/em\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "614157028374786048",
  "text" : "The finer points of emoji communication: \u00ABCome on, Unicode consortium. Where\u2019s the penis tree emoji?\u00BB \uD83C\uDF4C\uD83C\uDF32\uD83C\uDF3D\uD83C\uDF34\uD83C\uDF46 http:\/\/t.co\/qkVDmhdssS",
  "id" : 614157028374786048,
  "created_at" : "2015-06-25 19:43:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "beau",
      "screen_name" : "beaugunderson",
      "indices" : [ 3, 17 ],
      "id_str" : "5746882",
      "id" : 5746882
    }, {
      "name" : "Double Union",
      "screen_name" : "DoubleUnionSF",
      "indices" : [ 50, 64 ],
      "id_str" : "1547329232",
      "id" : 1547329232
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "614129067810549760",
  "text" : "RT @beaugunderson: i \uD83D\uDC96 this awesome reminder from @DoubleUnionSF that using an organization's logo to fundraise without asking them is \uD83D\uDC4E ht\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Double Union",
        "screen_name" : "DoubleUnionSF",
        "indices" : [ 31, 45 ],
        "id_str" : "1547329232",
        "id" : 1547329232
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/iLrmKvCBS8",
        "expanded_url" : "http:\/\/doubleunion.tumblr.com\/post\/122430930934\/consent-branding-and-fundraising-101-for-tech",
        "display_url" : "doubleunion.tumblr.com\/post\/122430930\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "614124166518718464",
    "text" : "i \uD83D\uDC96 this awesome reminder from @DoubleUnionSF that using an organization's logo to fundraise without asking them is \uD83D\uDC4E http:\/\/t.co\/iLrmKvCBS8",
    "id" : 614124166518718464,
    "created_at" : "2015-06-25 17:33:05 +0000",
    "user" : {
      "name" : "beau",
      "screen_name" : "beaugunderson",
      "protected" : false,
      "id_str" : "5746882",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/913840034016399360\/pU3IIxqf_normal.jpg",
      "id" : 5746882,
      "verified" : false
    }
  },
  "id" : 614129067810549760,
  "created_at" : "2015-06-25 17:52:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "614125498013196288",
  "text" : "So well prepared for this lecture, I\u2019ll probably explain the awkward algorithm instead of the forward-backward algorithm.",
  "id" : 614125498013196288,
  "created_at" : "2015-06-25 17:38:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/e6j748R6NV",
      "expanded_url" : "http:\/\/www.buzzfeed.com\/jessh24\/the-perfect-guy-and-his-open-relationship",
      "display_url" : "buzzfeed.com\/jessh24\/the-pe\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17225602857214, 8.627604194242448 ]
  },
  "id_str" : "614115586705113088",
  "text" : "\u00ABI arrived at two truths: To many people, monogamy is natural; to many people, monogamy is unnatural.\u00BB http:\/\/t.co\/e6j748R6NV",
  "id" : 614115586705113088,
  "created_at" : "2015-06-25 16:59:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Mittelman",
      "screen_name" : "evolvability",
      "indices" : [ 3, 16 ],
      "id_str" : "199737585",
      "id" : 199737585
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 75 ],
      "url" : "https:\/\/t.co\/OKVWZPoDYS",
      "expanded_url" : "https:\/\/twitter.com\/whatdnatest\/status\/614047255880830976",
      "display_url" : "twitter.com\/whatdnatest\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "614087658789339137",
  "text" : "RT @evolvability: They probably share ~20k genes... https:\/\/t.co\/OKVWZPoDYS",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 34, 57 ],
        "url" : "https:\/\/t.co\/OKVWZPoDYS",
        "expanded_url" : "https:\/\/twitter.com\/whatdnatest\/status\/614047255880830976",
        "display_url" : "twitter.com\/whatdnatest\/st\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "614050344041975808",
    "text" : "They probably share ~20k genes... https:\/\/t.co\/OKVWZPoDYS",
    "id" : 614050344041975808,
    "created_at" : "2015-06-25 12:39:45 +0000",
    "user" : {
      "name" : "David Mittelman",
      "screen_name" : "evolvability",
      "protected" : false,
      "id_str" : "199737585",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/739855763472977920\/R4QX4Zjf_normal.jpg",
      "id" : 199737585,
      "verified" : false
    }
  },
  "id" : 614087658789339137,
  "created_at" : "2015-06-25 15:08:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Mittelman",
      "screen_name" : "evolvability",
      "indices" : [ 0, 13 ],
      "id_str" : "199737585",
      "id" : 199737585
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "614050344041975808",
  "geo" : { },
  "id_str" : "614087650081906688",
  "in_reply_to_user_id" : 199737585,
  "text" : "@evolvability in the 90s we even would have guessed ~100k.",
  "id" : 614087650081906688,
  "in_reply_to_status_id" : 614050344041975808,
  "created_at" : "2015-06-25 15:07:59 +0000",
  "in_reply_to_screen_name" : "evolvability",
  "in_reply_to_user_id_str" : "199737585",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Torsten Seemann",
      "screen_name" : "torstenseemann",
      "indices" : [ 0, 15 ],
      "id_str" : "42558652",
      "id" : 42558652
    }, {
      "name" : "Jason McDermott",
      "screen_name" : "BioDataGanache",
      "indices" : [ 16, 31 ],
      "id_str" : "1040758742",
      "id" : 1040758742
    }, {
      "name" : "Tatjana Scheffler",
      "screen_name" : "tschfflr",
      "indices" : [ 32, 41 ],
      "id_str" : "313810815",
      "id" : 313810815
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "614030557119295488",
  "geo" : { },
  "id_str" : "614031180288102400",
  "in_reply_to_user_id" : 42558652,
  "text" : "@torstenseemann @BioDataGanache @tschfflr might be, I didn\u2019t check. :)",
  "id" : 614031180288102400,
  "in_reply_to_status_id" : 614030557119295488,
  "created_at" : "2015-06-25 11:23:36 +0000",
  "in_reply_to_screen_name" : "torstenseemann",
  "in_reply_to_user_id_str" : "42558652",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason McDermott",
      "screen_name" : "BioDataGanache",
      "indices" : [ 0, 15 ],
      "id_str" : "1040758742",
      "id" : 1040758742
    }, {
      "name" : "Tatjana Scheffler",
      "screen_name" : "tschfflr",
      "indices" : [ 16, 25 ],
      "id_str" : "313810815",
      "id" : 313810815
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "613961698223988736",
  "geo" : { },
  "id_str" : "614008493297823744",
  "in_reply_to_user_id" : 1040758742,
  "text" : "@BioDataGanache @tschfflr works fine, but solubility isn\u2019t that great ;)",
  "id" : 614008493297823744,
  "in_reply_to_status_id" : 613961698223988736,
  "created_at" : "2015-06-25 09:53:27 +0000",
  "in_reply_to_screen_name" : "BioDataGanache",
  "in_reply_to_user_id_str" : "1040758742",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "613971469022982144",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1724481117909, 8.627565565321893 ]
  },
  "id_str" : "613971591106531329",
  "in_reply_to_user_id" : 14286491,
  "text" : "\u00ABArguments against the vernacular Bible are eerily similar to modern bioethical arguments against return of results from genetic research.\u00BB",
  "id" : 613971591106531329,
  "in_reply_to_status_id" : 613971469022982144,
  "created_at" : "2015-06-25 07:26:49 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Madeleine Price Ball",
      "screen_name" : "madprime",
      "indices" : [ 62, 71 ],
      "id_str" : "71557700",
      "id" : 71557700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/xKJ5SU4lPQ",
      "expanded_url" : "http:\/\/papers.ssrn.com\/sol3\/papers.cfm?abstract_id=2219522",
      "display_url" : "papers.ssrn.com\/sol3\/papers.cf\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1724481117909, 8.627565565321893 ]
  },
  "id_str" : "613971469022982144",
  "text" : "The First Amendment Right to Speak about the Human Genome \/HT @madprime http:\/\/t.co\/xKJ5SU4lPQ",
  "id" : 613971469022982144,
  "created_at" : "2015-06-25 07:26:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tatjana Scheffler",
      "screen_name" : "tschfflr",
      "indices" : [ 0, 9 ],
      "id_str" : "313810815",
      "id" : 313810815
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "613959156899389440",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17225468196412, 8.627592334900985 ]
  },
  "id_str" : "613963546825764864",
  "in_reply_to_user_id" : 313810815,
  "text" : "@tschfflr thanks. :)",
  "id" : 613963546825764864,
  "in_reply_to_status_id" : 613959156899389440,
  "created_at" : "2015-06-25 06:54:51 +0000",
  "in_reply_to_screen_name" : "tschfflr",
  "in_reply_to_user_id_str" : "313810815",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason McDermott",
      "screen_name" : "BioDataGanache",
      "indices" : [ 0, 15 ],
      "id_str" : "1040758742",
      "id" : 1040758742
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "613961354739851264",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17221462700396, 8.627623280216726 ]
  },
  "id_str" : "613961569714765824",
  "in_reply_to_user_id" : 1040758742,
  "text" : "@BioDataGanache thx, i mainly wondered about properties while dissolving.",
  "id" : 613961569714765824,
  "in_reply_to_status_id" : 613961354739851264,
  "created_at" : "2015-06-25 06:46:59 +0000",
  "in_reply_to_screen_name" : "BioDataGanache",
  "in_reply_to_user_id_str" : "1040758742",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722075869336, 8.627631233659804 ]
  },
  "id_str" : "613958234605514752",
  "text" : "Not that I\u2019m super desperate or anything but: does confectioner\u2019s sugar work fine for sweetening coffee as well?",
  "id" : 613958234605514752,
  "created_at" : "2015-06-25 06:33:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Chin",
      "screen_name" : "infoecho",
      "indices" : [ 0, 9 ],
      "id_str" : "29575969",
      "id" : 29575969
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/pu3nESOs0f",
      "expanded_url" : "https:\/\/thescienceweb.wordpress.com\/2015\/03\/31\/bacteria-will-pay-you-to-sequence-them-by-2016-analysis-reveals\/",
      "display_url" : "thescienceweb.wordpress.com\/2015\/03\/31\/bac\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "613934878837485568",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17218723526554, 8.627666377789245 ]
  },
  "id_str" : "613953481767055360",
  "in_reply_to_user_id" : 29575969,
  "text" : "@infoecho if Bacteria will hit a negative number in 2016, maybe the same is true for humans in 3 years? https:\/\/t.co\/pu3nESOs0f ;)",
  "id" : 613953481767055360,
  "in_reply_to_status_id" : 613934878837485568,
  "created_at" : "2015-06-25 06:14:51 +0000",
  "in_reply_to_screen_name" : "infoecho",
  "in_reply_to_user_id_str" : "29575969",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "613833092416045057",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11408262396773, 8.753336670377507 ]
  },
  "id_str" : "613833871994523648",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer apparently not :)",
  "id" : 613833871994523648,
  "in_reply_to_status_id" : 613833092416045057,
  "created_at" : "2015-06-24 22:19:34 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 80, 93 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/zgUfMH3k6S",
      "expanded_url" : "http:\/\/feedproxy.google.com\/~r\/plosone\/PLoSONE\/~3\/VMS6VnXsj0w\/info%3Adoi%2F10.1371%2Fjournal.pone.0130069",
      "display_url" : "feedproxy.google.com\/~r\/plosone\/PLo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "613825670477664257",
  "text" : "Mixing Languages during Learning? Testing the One Subject\u2014One Language Rule \/cc @PhilippBayer  http:\/\/t.co\/zgUfMH3k6S",
  "id" : 613825670477664257,
  "created_at" : "2015-06-24 21:46:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "613824273979973642",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1140828392407, 8.7533339635376 ]
  },
  "id_str" : "613824895647117312",
  "in_reply_to_user_id" : 14286491,
  "text" : "\u00ABWomen who were exposed to disgusting images before erotic content showed significantly less sexual arousal\u00BB well done, science!",
  "id" : 613824895647117312,
  "in_reply_to_status_id" : 613824273979973642,
  "created_at" : "2015-06-24 21:43:54 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/Oh0SyZmPgD",
      "expanded_url" : "http:\/\/feedproxy.google.com\/~r\/plosone\/PLoSONE\/~3\/4LoYFS9JpTY\/info%3Adoi%2F10.1371%2Fjournal.pone.0118151",
      "display_url" : "feedproxy.google.com\/~r\/plosone\/PLo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "613824273979973642",
  "text" : "Disgust versus Lust: Exploring the Interactions of Disgust and Fear with Sexual Arousal in Women http:\/\/t.co\/Oh0SyZmPgD",
  "id" : 613824273979973642,
  "created_at" : "2015-06-24 21:41:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Mittelman",
      "screen_name" : "evolvability",
      "indices" : [ 0, 13 ],
      "id_str" : "199737585",
      "id" : 199737585
    }, {
      "name" : "Mick Watson",
      "screen_name" : "BioMickWatson",
      "indices" : [ 14, 28 ],
      "id_str" : "228586748",
      "id" : 228586748
    }, {
      "name" : "Michael Eisen",
      "screen_name" : "mbeisen",
      "indices" : [ 29, 37 ],
      "id_str" : "19843630",
      "id" : 19843630
    }, {
      "name" : "Daniel MacArthur",
      "screen_name" : "dgmacarthur",
      "indices" : [ 38, 50 ],
      "id_str" : "16629477",
      "id" : 16629477
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "613803266367844352",
  "geo" : { },
  "id_str" : "613804279183343616",
  "in_reply_to_user_id" : 199737585,
  "text" : "@evolvability @BioMickWatson @mbeisen @dgmacarthur well played, thought along lines of \u2018Proust was a Neuroscientist,Rumsfeld was an Omicist\u2019",
  "id" : 613804279183343616,
  "in_reply_to_status_id" : 613803266367844352,
  "created_at" : "2015-06-24 20:21:58 +0000",
  "in_reply_to_screen_name" : "evolvability",
  "in_reply_to_user_id_str" : "199737585",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mick Watson",
      "screen_name" : "BioMickWatson",
      "indices" : [ 0, 14 ],
      "id_str" : "228586748",
      "id" : 228586748
    }, {
      "name" : "David Mittelman",
      "screen_name" : "evolvability",
      "indices" : [ 15, 28 ],
      "id_str" : "199737585",
      "id" : 199737585
    }, {
      "name" : "Michael Eisen",
      "screen_name" : "mbeisen",
      "indices" : [ 29, 37 ],
      "id_str" : "19843630",
      "id" : 19843630
    }, {
      "name" : "Daniel MacArthur",
      "screen_name" : "dgmacarthur",
      "indices" : [ 38, 50 ],
      "id_str" : "16629477",
      "id" : 16629477
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "613793644139646976",
  "geo" : { },
  "id_str" : "613801593360785408",
  "in_reply_to_user_id" : 228586748,
  "text" : "@BioMickWatson @evolvability @mbeisen @dgmacarthur unknow-omics?",
  "id" : 613801593360785408,
  "in_reply_to_status_id" : 613793644139646976,
  "created_at" : "2015-06-24 20:11:18 +0000",
  "in_reply_to_screen_name" : "BioMickWatson",
  "in_reply_to_user_id_str" : "228586748",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Yoder \uD83D\uDD96\uD83C\uDFFB",
      "screen_name" : "JBYoder",
      "indices" : [ 0, 8 ],
      "id_str" : "19984919",
      "id" : 19984919
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "613743342556295168",
  "geo" : { },
  "id_str" : "613754730838401024",
  "in_reply_to_user_id" : 19984919,
  "text" : "@JBYoder thanks so much for writing them!",
  "id" : 613754730838401024,
  "in_reply_to_status_id" : 613743342556295168,
  "created_at" : "2015-06-24 17:05:05 +0000",
  "in_reply_to_screen_name" : "JBYoder",
  "in_reply_to_user_id_str" : "19984919",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Yoder \uD83D\uDD96\uD83C\uDFFB",
      "screen_name" : "JBYoder",
      "indices" : [ 3, 11 ],
      "id_str" : "19984919",
      "id" : 19984919
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/JBYoder\/status\/613742669550870528\/photo\/1",
      "indices" : [ 51, 73 ],
      "url" : "http:\/\/t.co\/d4iCbXz7zE",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CIRztI4UwAAGxAU.jpg",
      "id_str" : "613742668544262144",
      "id" : 613742668544262144,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CIRztI4UwAAGxAU.jpg",
      "sizes" : [ {
        "h" : 360,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 360,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 360,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 360,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/d4iCbXz7zE"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 50 ],
      "url" : "http:\/\/t.co\/yroqX9jVOz",
      "expanded_url" : "http:\/\/denimandtweed.jbyoder.org\/2015\/06\/queer-as-spock\/",
      "display_url" : "denimandtweed.jbyoder.org\/2015\/06\/queer-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "613754473241018369",
  "text" : "RT @JBYoder: Queer as Spock http:\/\/t.co\/yroqX9jVOz http:\/\/t.co\/d4iCbXz7zE",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/JBYoder\/status\/613742669550870528\/photo\/1",
        "indices" : [ 38, 60 ],
        "url" : "http:\/\/t.co\/d4iCbXz7zE",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CIRztI4UwAAGxAU.jpg",
        "id_str" : "613742668544262144",
        "id" : 613742668544262144,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CIRztI4UwAAGxAU.jpg",
        "sizes" : [ {
          "h" : 360,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 360,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 360,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 360,
          "resize" : "fit",
          "w" : 640
        } ],
        "display_url" : "pic.twitter.com\/d4iCbXz7zE"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 15, 37 ],
        "url" : "http:\/\/t.co\/yroqX9jVOz",
        "expanded_url" : "http:\/\/denimandtweed.jbyoder.org\/2015\/06\/queer-as-spock\/",
        "display_url" : "denimandtweed.jbyoder.org\/2015\/06\/queer-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "613742669550870528",
    "text" : "Queer as Spock http:\/\/t.co\/yroqX9jVOz http:\/\/t.co\/d4iCbXz7zE",
    "id" : 613742669550870528,
    "created_at" : "2015-06-24 16:17:09 +0000",
    "user" : {
      "name" : "Jeremy Yoder \uD83D\uDD96\uD83C\uDFFB",
      "screen_name" : "JBYoder",
      "protected" : false,
      "id_str" : "19984919",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/870850169759072256\/r0kxCgGs_normal.jpg",
      "id" : 19984919,
      "verified" : true
    }
  },
  "id" : 613754473241018369,
  "created_at" : "2015-06-24 17:04:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Quartz",
      "screen_name" : "qz",
      "indices" : [ 3, 6 ],
      "id_str" : "573918122",
      "id" : 573918122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/zby45qk8SG",
      "expanded_url" : "http:\/\/qz.com\/434614",
      "display_url" : "qz.com\/434614"
    } ]
  },
  "geo" : { },
  "id_str" : "613716481206026241",
  "text" : "RT @qz: Why some people can get away with so little sleep http:\/\/t.co\/zby45qk8SG",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 50, 72 ],
        "url" : "http:\/\/t.co\/zby45qk8SG",
        "expanded_url" : "http:\/\/qz.com\/434614",
        "display_url" : "qz.com\/434614"
      } ]
    },
    "geo" : { },
    "id_str" : "613693586484277248",
    "text" : "Why some people can get away with so little sleep http:\/\/t.co\/zby45qk8SG",
    "id" : 613693586484277248,
    "created_at" : "2015-06-24 13:02:07 +0000",
    "user" : {
      "name" : "Quartz",
      "screen_name" : "qz",
      "protected" : false,
      "id_str" : "573918122",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615280495958495232\/nX0-Mypb_normal.png",
      "id" : 573918122,
      "verified" : true
    }
  },
  "id" : 613716481206026241,
  "created_at" : "2015-06-24 14:33:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 64 ],
      "url" : "http:\/\/t.co\/VusF1dCMmL",
      "expanded_url" : "http:\/\/existentialcomics.com\/comic\/86",
      "display_url" : "existentialcomics.com\/comic\/86"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17223679208401, 8.627624194203747 ]
  },
  "id_str" : "613710918820732928",
  "text" : "business plans are a social construction! http:\/\/t.co\/VusF1dCMmL",
  "id" : 613710918820732928,
  "created_at" : "2015-06-24 14:10:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "saveFoP",
      "indices" : [ 97, 105 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/2SGCmqbLkt",
      "expanded_url" : "https:\/\/twitter.com\/heald_j\/status\/613660361741455360",
      "display_url" : "twitter.com\/heald_j\/status\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "613698728281640960",
  "text" : "On Freedom of Panorama: \u00ABThe french can unify nonsense all they want, but it is still nonsense.\u00BB #saveFoP https:\/\/t.co\/2SGCmqbLkt",
  "id" : 613698728281640960,
  "created_at" : "2015-06-24 13:22:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Lillie",
      "screen_name" : "BenLillie",
      "indices" : [ 3, 13 ],
      "id_str" : "15949242",
      "id" : 15949242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "613695065710571520",
  "text" : "RT @BenLillie: The Beaks of Wrath. \nThe Finchfather. \nSaving Private Wallace.\nApocalypse Gradually over Geologic Time. https:\/\/t.co\/pC55sTL\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 104, 127 ],
        "url" : "https:\/\/t.co\/pC55sTLHyC",
        "expanded_url" : "https:\/\/twitter.com\/carlzimmer\/status\/613688273530155008",
        "display_url" : "twitter.com\/carlzimmer\/sta\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "613691764873019392",
    "text" : "The Beaks of Wrath. \nThe Finchfather. \nSaving Private Wallace.\nApocalypse Gradually over Geologic Time. https:\/\/t.co\/pC55sTLHyC",
    "id" : 613691764873019392,
    "created_at" : "2015-06-24 12:54:53 +0000",
    "user" : {
      "name" : "Ben Lillie",
      "screen_name" : "BenLillie",
      "protected" : false,
      "id_str" : "15949242",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/438743857908695040\/SkeP0H-u_normal.jpeg",
      "id" : 15949242,
      "verified" : false
    }
  },
  "id" : 613695065710571520,
  "created_at" : "2015-06-24 13:08:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722448137074, 8.627577402581213 ]
  },
  "id_str" : "613668745823821826",
  "text" : "Workstation A tells me I\u2019m not in the sudoers file. sshing from A into B and from there back into A: I\u2019m in the sudoers file. Magic! \uD83C\uDFA9\uD83C\uDF89",
  "id" : 613668745823821826,
  "created_at" : "2015-06-24 11:23:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "The_Smoking_GNU",
      "indices" : [ 0, 16 ],
      "id_str" : "14535787",
      "id" : 14535787
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "613661278670848000",
  "geo" : { },
  "id_str" : "613664830613012480",
  "in_reply_to_user_id" : 14535787,
  "text" : "@The_Smoking_GNU jetzt will ich Kuchen mit Nutella essen :3",
  "id" : 613664830613012480,
  "in_reply_to_status_id" : 613661278670848000,
  "created_at" : "2015-06-24 11:07:51 +0000",
  "in_reply_to_screen_name" : "The_Smoking_GNU",
  "in_reply_to_user_id_str" : "14535787",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Neil Saunders",
      "screen_name" : "neilfws",
      "indices" : [ 3, 11 ],
      "id_str" : "14162706",
      "id" : 14162706
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/YzzVpLeKI5",
      "expanded_url" : "http:\/\/googlecloudplatform.blogspot.com\/2015\/06\/Google-Genomics-and-Broad-Institute-Team-Up-to-Tackle-Genomic-Data.html",
      "display_url" : "googlecloudplatform.blogspot.com\/2015\/06\/Google\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "613654319666208768",
  "text" : "RT @neilfws: Google Genomics and Broad Institute Team Up to Tackle Genomic Data http:\/\/t.co\/YzzVpLeKI5",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 67, 89 ],
        "url" : "http:\/\/t.co\/YzzVpLeKI5",
        "expanded_url" : "http:\/\/googlecloudplatform.blogspot.com\/2015\/06\/Google-Genomics-and-Broad-Institute-Team-Up-to-Tackle-Genomic-Data.html",
        "display_url" : "googlecloudplatform.blogspot.com\/2015\/06\/Google\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "613646981525737472",
    "text" : "Google Genomics and Broad Institute Team Up to Tackle Genomic Data http:\/\/t.co\/YzzVpLeKI5",
    "id" : 613646981525737472,
    "created_at" : "2015-06-24 09:56:56 +0000",
    "user" : {
      "name" : "Neil Saunders",
      "screen_name" : "neilfws",
      "protected" : false,
      "id_str" : "14162706",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/835449341384876032\/G_TEkp8j_normal.jpg",
      "id" : 14162706,
      "verified" : false
    }
  },
  "id" : 613654319666208768,
  "created_at" : "2015-06-24 10:26:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kriszta Berkes",
      "screen_name" : "KrisztaB",
      "indices" : [ 3, 12 ],
      "id_str" : "922402893411561472",
      "id" : 922402893411561472
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 55 ],
      "url" : "https:\/\/t.co\/uox85aBmPj",
      "expanded_url" : "https:\/\/twitter.com\/musicbyscottb\/status\/613318725446598656",
      "display_url" : "twitter.com\/musicbyscottb\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "613653497033170944",
  "text" : "RT @Krisztab: Mycorrhiza dating https:\/\/t.co\/uox85aBmPj",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 18, 41 ],
        "url" : "https:\/\/t.co\/uox85aBmPj",
        "expanded_url" : "https:\/\/twitter.com\/musicbyscottb\/status\/613318725446598656",
        "display_url" : "twitter.com\/musicbyscottb\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "613635848089825280",
    "text" : "Mycorrhiza dating https:\/\/t.co\/uox85aBmPj",
    "id" : 613635848089825280,
    "created_at" : "2015-06-24 09:12:41 +0000",
    "user" : {
      "name" : "Kriszta Kezia V",
      "screen_name" : "kri_keziush",
      "protected" : false,
      "id_str" : "19334473",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/836703338775343104\/tM-WE4G6_normal.jpg",
      "id" : 19334473,
      "verified" : false
    }
  },
  "id" : 613653497033170944,
  "created_at" : "2015-06-24 10:22:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 73 ],
      "url" : "http:\/\/t.co\/BnZ4yGZ9Kt",
      "expanded_url" : "http:\/\/www.fungitobewith.org\/",
      "display_url" : "fungitobewith.org"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17221882186203, 8.627605960577293 ]
  },
  "id_str" : "613627655456464896",
  "text" : "how many puns on fungi can you put on one website? http:\/\/t.co\/BnZ4yGZ9Kt",
  "id" : 613627655456464896,
  "created_at" : "2015-06-24 08:40:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PacBio",
      "screen_name" : "PacBio",
      "indices" : [ 13, 20 ],
      "id_str" : "39694489",
      "id" : 39694489
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/613621503528181760\/photo\/1",
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/Nx81tC6G24",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CIQFgV0WUAA5zPW.png",
      "id_str" : "613621502399893504",
      "id" : 613621502399893504,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CIQFgV0WUAA5zPW.png",
      "sizes" : [ {
        "h" : 3302,
        "resize" : "fit",
        "w" : 3802
      }, {
        "h" : 1779,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 591,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1042,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/Nx81tC6G24"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17221942419453, 8.62761190493712 ]
  },
  "id_str" : "613621503528181760",
  "text" : "plotting the @PacBio read length distribution of multiple SMRTs at the same time looks so nice. http:\/\/t.co\/Nx81tC6G24",
  "id" : 613621503528181760,
  "created_at" : "2015-06-24 08:15:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "euan ashley",
      "screen_name" : "euanashley",
      "indices" : [ 3, 14 ],
      "id_str" : "149706579",
      "id" : 149706579
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "genome",
      "indices" : [ 31, 38 ]
    } ],
    "urls" : [ {
      "indices" : [ 57, 79 ],
      "url" : "http:\/\/t.co\/uMsuNi9Dk7",
      "expanded_url" : "http:\/\/news.ucsc.edu\/2015\/06\/genome-anniversary.html",
      "display_url" : "news.ucsc.edu\/2015\/06\/genome\u2026"
    }, {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/uMsuNi9Dk7",
      "expanded_url" : "http:\/\/news.ucsc.edu\/2015\/06\/genome-anniversary.html",
      "display_url" : "news.ucsc.edu\/2015\/06\/genome\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "613613758565511168",
  "text" : "RT @euanashley: Great story on #genome assembly number 1\nhttp:\/\/t.co\/uMsuNi9Dk7 http:\/\/t.co\/uMsuNi9Dk7",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "genome",
        "indices" : [ 15, 22 ]
      } ],
      "urls" : [ {
        "indices" : [ 41, 63 ],
        "url" : "http:\/\/t.co\/uMsuNi9Dk7",
        "expanded_url" : "http:\/\/news.ucsc.edu\/2015\/06\/genome-anniversary.html",
        "display_url" : "news.ucsc.edu\/2015\/06\/genome\u2026"
      }, {
        "indices" : [ 64, 86 ],
        "url" : "http:\/\/t.co\/uMsuNi9Dk7",
        "expanded_url" : "http:\/\/news.ucsc.edu\/2015\/06\/genome-anniversary.html",
        "display_url" : "news.ucsc.edu\/2015\/06\/genome\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "613603149924933632",
    "text" : "Great story on #genome assembly number 1\nhttp:\/\/t.co\/uMsuNi9Dk7 http:\/\/t.co\/uMsuNi9Dk7",
    "id" : 613603149924933632,
    "created_at" : "2015-06-24 07:02:45 +0000",
    "user" : {
      "name" : "euan ashley",
      "screen_name" : "euanashley",
      "protected" : false,
      "id_str" : "149706579",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/791909695736819712\/p6F_9FOZ_normal.jpg",
      "id" : 149706579,
      "verified" : false
    }
  },
  "id" : 613613758565511168,
  "created_at" : "2015-06-24 07:44:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 57 ],
      "url" : "http:\/\/t.co\/A6SYMYF1mn",
      "expanded_url" : "http:\/\/38.media.tumblr.com\/tumblr_lod7if8MFD1qe0eclo1_r7_500.gif",
      "display_url" : "38.media.tumblr.com\/tumblr_lod7if8\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17219164073519, 8.627633109904423 ]
  },
  "id_str" : "613611478365700096",
  "text" : "what\u2019s the LD50 of caffeine again? http:\/\/t.co\/A6SYMYF1mn",
  "id" : 613611478365700096,
  "created_at" : "2015-06-24 07:35:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "613488800984121345",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11408214900965, 8.753333977156167 ]
  },
  "id_str" : "613489307379220481",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer who would have guessed, especially back then. Must have been around the time that Watson\u2019s genome was in print.",
  "id" : 613489307379220481,
  "in_reply_to_status_id" : 613488800984121345,
  "created_at" : "2015-06-23 23:30:23 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "613488495533903873",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11408214900965, 8.753333977156167 ]
  },
  "id_str" : "613488658415529984",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer only took like what, 8 years, to get an answer to our question! \\o\/",
  "id" : 613488658415529984,
  "in_reply_to_status_id" : 613488495533903873,
  "created_at" : "2015-06-23 23:27:48 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 84 ],
      "url" : "https:\/\/t.co\/kYDu77MzpT",
      "expanded_url" : "https:\/\/mrpsmythopedia.wikispaces.com\/file\/view\/sisyphus640px22.gif\/515236176\/sisyphus640px22.gif",
      "display_url" : "mrpsmythopedia.wikispaces.com\/file\/view\/sisy\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11408231003123, 8.75333824969841 ]
  },
  "id_str" : "613483126153703424",
  "text" : "the todo items that won\u2019t die and just get rescheduled, aka: https:\/\/t.co\/kYDu77MzpT",
  "id" : 613483126153703424,
  "created_at" : "2015-06-23 23:05:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "613468839460929536",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11408160845204, 8.753331152013319 ]
  },
  "id_str" : "613476414080319488",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer remember how we wondered about this back in our undergrad course on sequencing? :D",
  "id" : 613476414080319488,
  "in_reply_to_status_id" : 613468839460929536,
  "created_at" : "2015-06-23 22:39:09 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bozhidar Bozhanov",
      "screen_name" : "bozhobg",
      "indices" : [ 3, 11 ],
      "id_str" : "51876257",
      "id" : 51876257
    }, {
      "name" : "Rayna",
      "screen_name" : "MaliciaRogue",
      "indices" : [ 112, 125 ],
      "id_str" : "189118361",
      "id" : 189118361
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/mxoqsrnJqy",
      "expanded_url" : "http:\/\/www.theallium.com\/policy\/taylor-swift-announces-she-will-no-longer-review-for-nature\/",
      "display_url" : "theallium.com\/policy\/taylor-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "613378401185984512",
  "text" : "RT @bozhobg: rofl: \"Taylor Swift Announces She Will No Longer Review For Nature\" :D http:\/\/t.co\/mxoqsrnJqy \/via @MaliciaRogue",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Rayna",
        "screen_name" : "MaliciaRogue",
        "indices" : [ 99, 112 ],
        "id_str" : "189118361",
        "id" : 189118361
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 71, 93 ],
        "url" : "http:\/\/t.co\/mxoqsrnJqy",
        "expanded_url" : "http:\/\/www.theallium.com\/policy\/taylor-swift-announces-she-will-no-longer-review-for-nature\/",
        "display_url" : "theallium.com\/policy\/taylor-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "613367280295149568",
    "text" : "rofl: \"Taylor Swift Announces She Will No Longer Review For Nature\" :D http:\/\/t.co\/mxoqsrnJqy \/via @MaliciaRogue",
    "id" : 613367280295149568,
    "created_at" : "2015-06-23 15:25:30 +0000",
    "user" : {
      "name" : "Bozhidar Bozhanov",
      "screen_name" : "bozhobg",
      "protected" : false,
      "id_str" : "51876257",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/716514525705412609\/fBYY-isO_normal.jpg",
      "id" : 51876257,
      "verified" : false
    }
  },
  "id" : 613378401185984512,
  "created_at" : "2015-06-23 16:09:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Blin",
      "screen_name" : "kaiblin",
      "indices" : [ 0, 8 ],
      "id_str" : "124202458",
      "id" : 124202458
    }, {
      "name" : "Torsten Seemann",
      "screen_name" : "torstenseemann",
      "indices" : [ 9, 24 ],
      "id_str" : "42558652",
      "id" : 42558652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "613273827490033664",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17219649271015, 8.6276659198139 ]
  },
  "id_str" : "613274371453530112",
  "in_reply_to_user_id" : 124202458,
  "text" : "@kaiblin @torstenseemann even that's mostly guesswork and black magic from my experience. ;)",
  "id" : 613274371453530112,
  "in_reply_to_status_id" : 613273827490033664,
  "created_at" : "2015-06-23 09:16:18 +0000",
  "in_reply_to_screen_name" : "kaiblin",
  "in_reply_to_user_id_str" : "124202458",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Beer DeCoded",
      "screen_name" : "beerdecoded",
      "indices" : [ 0, 12 ],
      "id_str" : "3295237359",
      "id" : 3295237359
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "613037784144683010",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17218472292301, 8.627668427937659 ]
  },
  "id_str" : "613274152456323072",
  "in_reply_to_user_id" : 3295237359,
  "text" : "@beerdecoded @randogp congrats!",
  "id" : 613274152456323072,
  "in_reply_to_status_id" : 613037784144683010,
  "created_at" : "2015-06-23 09:15:26 +0000",
  "in_reply_to_screen_name" : "beerdecoded",
  "in_reply_to_user_id_str" : "3295237359",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "613263119666819074",
  "geo" : { },
  "id_str" : "613263438131929088",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich now I really want to go to prison!",
  "id" : 613263438131929088,
  "in_reply_to_status_id" : 613263119666819074,
  "created_at" : "2015-06-23 08:32:52 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/3nj2X8RLAz",
      "expanded_url" : "https:\/\/twitter.com\/EffyVayena\/status\/613255222438268928",
      "display_url" : "twitter.com\/EffyVayena\/sta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "613256644433190912",
  "text" : "Why I'll claim being a human rights activist if they ever put us in jail for openSNP. https:\/\/t.co\/3nj2X8RLAz",
  "id" : 613256644433190912,
  "created_at" : "2015-06-23 08:05:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17217971294751, 8.627618462611348 ]
  },
  "id_str" : "613253135042220032",
  "text" : "I wish my reviewers had signed their reviews, so I could directly thank them for the useful comments.",
  "id" : 613253135042220032,
  "created_at" : "2015-06-23 07:51:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kelly Hills",
      "screen_name" : "rocza",
      "indices" : [ 3, 9 ],
      "id_str" : "14075844",
      "id" : 14075844
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 86 ],
      "url" : "https:\/\/t.co\/rTdU0aM1w3",
      "expanded_url" : "https:\/\/pando.com\/2015\/06\/22\/we-got-geeks\/0f5e37dd20647915deca221f540649016f6f3612\/",
      "display_url" : "pando.com\/2015\/06\/22\/we-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "613123014050381824",
  "text" : "RT @rocza: Inside Google's ugly war against the homeless in LA https:\/\/t.co\/rTdU0aM1w3 \"Don't be evil\" is easy when you opt to self-define \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 52, 75 ],
        "url" : "https:\/\/t.co\/rTdU0aM1w3",
        "expanded_url" : "https:\/\/pando.com\/2015\/06\/22\/we-got-geeks\/0f5e37dd20647915deca221f540649016f6f3612\/",
        "display_url" : "pando.com\/2015\/06\/22\/we-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "613085264169336832",
    "text" : "Inside Google's ugly war against the homeless in LA https:\/\/t.co\/rTdU0aM1w3 \"Don't be evil\" is easy when you opt to self-define evil.",
    "id" : 613085264169336832,
    "created_at" : "2015-06-22 20:44:52 +0000",
    "user" : {
      "name" : "Kelly Hills",
      "screen_name" : "rocza",
      "protected" : false,
      "id_str" : "14075844",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/788549856528859136\/dco0kme__normal.jpg",
      "id" : 14075844,
      "verified" : false
    }
  },
  "id" : 613123014050381824,
  "created_at" : "2015-06-22 23:14:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 3, 12 ],
      "id_str" : "14245811",
      "id" : 14245811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/DrVj5CI7mR",
      "expanded_url" : "https:\/\/twitter.com\/NitaFarahany\/status\/613055123636551680",
      "display_url" : "twitter.com\/NitaFarahany\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "613114266355408896",
  "text" : "RT @wilbanks: Woooooooow. $2.25M award under first genetic non-discrimination act verdict. Strong. https:\/\/t.co\/DrVj5CI7mR",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 85, 108 ],
        "url" : "https:\/\/t.co\/DrVj5CI7mR",
        "expanded_url" : "https:\/\/twitter.com\/NitaFarahany\/status\/613055123636551680",
        "display_url" : "twitter.com\/NitaFarahany\/s\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "613058211181162496",
    "text" : "Woooooooow. $2.25M award under first genetic non-discrimination act verdict. Strong. https:\/\/t.co\/DrVj5CI7mR",
    "id" : 613058211181162496,
    "created_at" : "2015-06-22 18:57:22 +0000",
    "user" : {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "protected" : false,
      "id_str" : "14245811",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/925696899566440448\/BUTdp410_normal.jpg",
      "id" : 14245811,
      "verified" : false
    }
  },
  "id" : 613114266355408896,
  "created_at" : "2015-06-22 22:40:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 77 ],
      "url" : "https:\/\/t.co\/58kj7nog8z",
      "expanded_url" : "https:\/\/www.kickstarter.com\/projects\/347021647\/badass-feminist-coloring-book",
      "display_url" : "kickstarter.com\/projects\/34702\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11408251763101, 8.753326157810708 ]
  },
  "id_str" : "613113594495025152",
  "text" : "Now on Kickstarter: The Badass Feminist Coloring Book https:\/\/t.co\/58kj7nog8z",
  "id" : 613113594495025152,
  "created_at" : "2015-06-22 22:37:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DNAdigest.org",
      "screen_name" : "DNADigest",
      "indices" : [ 3, 13 ],
      "id_str" : "334912047",
      "id" : 334912047
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DataSharing",
      "indices" : [ 106, 118 ]
    }, {
      "text" : "BestPractices",
      "indices" : [ 119, 133 ]
    } ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/nhXELnX9tn",
      "expanded_url" : "http:\/\/buff.ly\/1cPEiZz",
      "display_url" : "buff.ly\/1cPEiZz"
    } ]
  },
  "geo" : { },
  "id_str" : "612955623622320128",
  "text" : "RT @DNADigest: Global Alliance for Genomics and Health marks two years of progress http:\/\/t.co\/nhXELnX9tn #DataSharing #BestPractices #Huma\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "DataSharing",
        "indices" : [ 91, 103 ]
      }, {
        "text" : "BestPractices",
        "indices" : [ 104, 118 ]
      }, {
        "text" : "HumanHealth",
        "indices" : [ 119, 131 ]
      } ],
      "urls" : [ {
        "indices" : [ 68, 90 ],
        "url" : "http:\/\/t.co\/nhXELnX9tn",
        "expanded_url" : "http:\/\/buff.ly\/1cPEiZz",
        "display_url" : "buff.ly\/1cPEiZz"
      } ]
    },
    "geo" : { },
    "id_str" : "612940402216300546",
    "text" : "Global Alliance for Genomics and Health marks two years of progress http:\/\/t.co\/nhXELnX9tn #DataSharing #BestPractices #HumanHealth",
    "id" : 612940402216300546,
    "created_at" : "2015-06-22 11:09:14 +0000",
    "user" : {
      "name" : "DNAdigest.org",
      "screen_name" : "DNADigest",
      "protected" : false,
      "id_str" : "334912047",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/430707142232772608\/Vmx-V5fY_normal.png",
      "id" : 334912047,
      "verified" : false
    }
  },
  "id" : 612955623622320128,
  "created_at" : "2015-06-22 12:09:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17247388205756, 8.627556544962083 ]
  },
  "id_str" : "612940847525535745",
  "text" : "\u00ABApparently promiscuous moonlighting proteins are a thing now.\u00BB \u2013 \u00ABMake it \u2018protein bag\u2019 and you have a perfect description of my lifestyle\u00BB",
  "id" : 612940847525535745,
  "created_at" : "2015-06-22 11:11:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "612913713180483584",
  "geo" : { },
  "id_str" : "612926011018211328",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot \uD83D\uDC36\u2665\uFE0F\uD83D\uDD2C\uD83D\uDC53",
  "id" : 612926011018211328,
  "in_reply_to_status_id" : 612913713180483584,
  "created_at" : "2015-06-22 10:12:03 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Beth \uD83D\uDC3A",
      "screen_name" : "PhdGeek",
      "indices" : [ 0, 8 ],
      "id_str" : "27841081",
      "id" : 27841081
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "612904474026352640",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17221194436313, 8.627571254574592 ]
  },
  "id_str" : "612905279668244480",
  "in_reply_to_user_id" : 27841081,
  "text" : "@PhdGeek looking forward to read more about the progress :) (and one day I\u2019ll also make time for all that\u2026 ;-))",
  "id" : 612905279668244480,
  "in_reply_to_status_id" : 612904474026352640,
  "created_at" : "2015-06-22 08:49:40 +0000",
  "in_reply_to_screen_name" : "PhdGeek",
  "in_reply_to_user_id_str" : "27841081",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Beth \uD83D\uDC3A",
      "screen_name" : "PhdGeek",
      "indices" : [ 0, 8 ],
      "id_str" : "27841081",
      "id" : 27841081
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "612901910752960512",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17224468438644, 8.62757194202195 ]
  },
  "id_str" : "612904151513743360",
  "in_reply_to_user_id" : 27841081,
  "text" : "@PhdGeek very cool! Totally missed that until now, all the best for your efforts!",
  "id" : 612904151513743360,
  "in_reply_to_status_id" : 612901910752960512,
  "created_at" : "2015-06-22 08:45:11 +0000",
  "in_reply_to_screen_name" : "PhdGeek",
  "in_reply_to_user_id_str" : "27841081",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "612886721513041920",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17225361692467, 8.62756969085102 ]
  },
  "id_str" : "612888152433401856",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich angekommen, vielen Dank! :)",
  "id" : 612888152433401856,
  "in_reply_to_status_id" : 612886721513041920,
  "created_at" : "2015-06-22 07:41:37 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "612886721513041920",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17225361692467, 8.62756969085102 ]
  },
  "id_str" : "612886880129011712",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich yay, danke :)",
  "id" : 612886880129011712,
  "in_reply_to_status_id" : 612886721513041920,
  "created_at" : "2015-06-22 07:36:33 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17225361692467, 8.62756969085102 ]
  },
  "id_str" : "612886847417647104",
  "text" : "\u00ABAnd this here is our scientist. He knows everything.\u00BB \u2013 \u00ABWait a second, let me get my lab coat to look the part!\u00BB",
  "id" : 612886847417647104,
  "created_at" : "2015-06-22 07:36:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "612883793272291328",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17224573247937, 8.627606433781386 ]
  },
  "id_str" : "612884085929844736",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich apropos veraltet: Du wolltest mir noch ein P&amp;P PDF mailen iirc? ;)",
  "id" : 612884085929844736,
  "in_reply_to_status_id" : 612883793272291328,
  "created_at" : "2015-06-22 07:25:27 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mina.",
      "screen_name" : "lasersushi",
      "indices" : [ 3, 14 ],
      "id_str" : "22057279",
      "id" : 22057279
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "612883057163546624",
  "text" : "RT @lasersushi: \"I'm talking about direct threats. [And if you can't see them] well congratulations on your white penis.\" https:\/\/t.co\/nxEd\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 106, 129 ],
        "url" : "https:\/\/t.co\/nxEdG5W5Kk",
        "expanded_url" : "https:\/\/www.youtube.com\/watch?v=PuNIwYsz7PI",
        "display_url" : "youtube.com\/watch?v=PuNIwY\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "612875669773676544",
    "text" : "\"I'm talking about direct threats. [And if you can't see them] well congratulations on your white penis.\" https:\/\/t.co\/nxEdG5W5Kk",
    "id" : 612875669773676544,
    "created_at" : "2015-06-22 06:52:01 +0000",
    "user" : {
      "name" : "Mina.",
      "screen_name" : "lasersushi",
      "protected" : false,
      "id_str" : "22057279",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/925407301242163202\/q2g9VgzA_normal.jpg",
      "id" : 22057279,
      "verified" : true
    }
  },
  "id" : 612883057163546624,
  "created_at" : "2015-06-22 07:21:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Noah Fierer",
      "screen_name" : "NoahFierer",
      "indices" : [ 3, 14 ],
      "id_str" : "472272881",
      "id" : 472272881
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "612878733813358592",
  "text" : "RT @NoahFierer: This should shake things up. Are gut microbiome studies just quantifying differences in stool consistency? http:\/\/t.co\/Fj7r\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 107, 129 ],
        "url" : "http:\/\/t.co\/Fj7rTVfHGI",
        "expanded_url" : "http:\/\/gut.bmj.com\/content\/early\/2015\/06\/11\/gutjnl-2015-309618.long",
        "display_url" : "gut.bmj.com\/content\/early\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "610913376185651200",
    "text" : "This should shake things up. Are gut microbiome studies just quantifying differences in stool consistency? http:\/\/t.co\/Fj7rTVfHGI",
    "id" : 610913376185651200,
    "created_at" : "2015-06-16 20:54:33 +0000",
    "user" : {
      "name" : "Noah Fierer",
      "screen_name" : "NoahFierer",
      "protected" : false,
      "id_str" : "472272881",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/507997974429855744\/d5czUwBI_normal.jpeg",
      "id" : 472272881,
      "verified" : false
    }
  },
  "id" : 612878733813358592,
  "created_at" : "2015-06-22 07:04:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OpenCon",
      "screen_name" : "open_con",
      "indices" : [ 3, 12 ],
      "id_str" : "2452073258",
      "id" : 2452073258
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/VFWzv59BtA",
      "expanded_url" : "http:\/\/www.scopeofscience.com\/2014\/11\/best-conference-ever\/",
      "display_url" : "scopeofscience.com\/2014\/11\/best-c\u2026"
    }, {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/Dc4zP4pNPU",
      "expanded_url" : "http:\/\/bit.ly\/AttendOpenCon",
      "display_url" : "bit.ly\/AttendOpenCon"
    } ]
  },
  "geo" : { },
  "id_str" : "612870854196752385",
  "text" : "RT @open_con: Apply for what 2014 attendees called the \u201Cbest conference ever\u201D - http:\/\/t.co\/VFWzv59BtA. http:\/\/t.co\/Dc4zP4pNPU http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/open_con\/status\/612666555264970756\/photo\/1",
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/W9b7dS70pn",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CHdZpsJWoAAgapV.png",
        "id_str" : "610054847291891712",
        "id" : 610054847291891712,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHdZpsJWoAAgapV.png",
        "sizes" : [ {
          "h" : 540,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 383,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 540,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 540,
          "resize" : "fit",
          "w" : 960
        } ],
        "display_url" : "pic.twitter.com\/W9b7dS70pn"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 66, 88 ],
        "url" : "http:\/\/t.co\/VFWzv59BtA",
        "expanded_url" : "http:\/\/www.scopeofscience.com\/2014\/11\/best-conference-ever\/",
        "display_url" : "scopeofscience.com\/2014\/11\/best-c\u2026"
      }, {
        "indices" : [ 90, 112 ],
        "url" : "http:\/\/t.co\/Dc4zP4pNPU",
        "expanded_url" : "http:\/\/bit.ly\/AttendOpenCon",
        "display_url" : "bit.ly\/AttendOpenCon"
      } ]
    },
    "geo" : { },
    "id_str" : "612666555264970756",
    "text" : "Apply for what 2014 attendees called the \u201Cbest conference ever\u201D - http:\/\/t.co\/VFWzv59BtA. http:\/\/t.co\/Dc4zP4pNPU http:\/\/t.co\/W9b7dS70pn",
    "id" : 612666555264970756,
    "created_at" : "2015-06-21 17:01:04 +0000",
    "user" : {
      "name" : "OpenCon",
      "screen_name" : "open_con",
      "protected" : false,
      "id_str" : "2452073258",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/843937071534424064\/e-PdQw9V_normal.jpg",
      "id" : 2452073258,
      "verified" : false
    }
  },
  "id" : 612870854196752385,
  "created_at" : "2015-06-22 06:32:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "cAMP \u00D6ther",
      "screen_name" : "CampOther",
      "indices" : [ 0, 10 ],
      "id_str" : "258870463",
      "id" : 258870463
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "612740549569675265",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1140700102281, 8.753389031026146 ]
  },
  "id_str" : "612740895398608897",
  "in_reply_to_user_id" : 258870463,
  "text" : "@CampOther of course, painting with a rather broad brush here\u2026 Leads to funny situations when going from DE -&gt; US and you take @ face value.",
  "id" : 612740895398608897,
  "in_reply_to_status_id" : 612740549569675265,
  "created_at" : "2015-06-21 21:56:28 +0000",
  "in_reply_to_screen_name" : "CampOther",
  "in_reply_to_user_id_str" : "258870463",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "cAMP \u00D6ther",
      "screen_name" : "CampOther",
      "indices" : [ 0, 10 ],
      "id_str" : "258870463",
      "id" : 258870463
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "612739582384144384",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11406991839986, 8.753388596005536 ]
  },
  "id_str" : "612740335907827712",
  "in_reply_to_user_id" : 258870463,
  "text" : "@CampOther ack, I think people tend to signal \u00B1honestly. So (un)friendlyness is detected rather straight away. ;-)",
  "id" : 612740335907827712,
  "in_reply_to_status_id" : 612739582384144384,
  "created_at" : "2015-06-21 21:54:14 +0000",
  "in_reply_to_screen_name" : "CampOther",
  "in_reply_to_user_id_str" : "258870463",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "cAMP \u00D6ther",
      "screen_name" : "CampOther",
      "indices" : [ 0, 10 ],
      "id_str" : "258870463",
      "id" : 258870463
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "612738834812395520",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11406991880671, 8.753388597932865 ]
  },
  "id_str" : "612739310387904512",
  "in_reply_to_user_id" : 258870463,
  "text" : "@CampOther nah, j\/k. From what I\u2019ve heard from visitors (and in my exp. from going abroad) ppl in germany tend2b genuinely friendly in comp.",
  "id" : 612739310387904512,
  "in_reply_to_status_id" : 612738834812395520,
  "created_at" : "2015-06-21 21:50:10 +0000",
  "in_reply_to_screen_name" : "CampOther",
  "in_reply_to_user_id_str" : "258870463",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "cAMP \u00D6ther",
      "screen_name" : "CampOther",
      "indices" : [ 0, 10 ],
      "id_str" : "258870463",
      "id" : 258870463
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "612737549635747841",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1140708776215, 8.753393140154706 ]
  },
  "id_str" : "612738419538702336",
  "in_reply_to_user_id" : 258870463,
  "text" : "@CampOther stickers that basically force you to smile, very german. ;)",
  "id" : 612738419538702336,
  "in_reply_to_status_id" : 612737549635747841,
  "created_at" : "2015-06-21 21:46:38 +0000",
  "in_reply_to_screen_name" : "CampOther",
  "in_reply_to_user_id_str" : "258870463",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jordipujolnadal",
      "screen_name" : "jordipujolnadal",
      "indices" : [ 3, 19 ],
      "id_str" : "14197646",
      "id" : 14197646
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 77 ],
      "url" : "http:\/\/t.co\/2BTuRybjme",
      "expanded_url" : "http:\/\/ow.ly\/OAiQS",
      "display_url" : "ow.ly\/OAiQS"
    } ]
  },
  "geo" : { },
  "id_str" : "612732420928983042",
  "text" : "RT @jordipujolnadal: 'Life with Bob Dylan, 1989-2006': http:\/\/t.co\/2BTuRybjme This is what music journalism should be. Thanks, @uncutmagazi\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Uncut Magazine",
        "screen_name" : "uncutmagazine",
        "indices" : [ 106, 120 ],
        "id_str" : "24733314",
        "id" : 24733314
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 34, 56 ],
        "url" : "http:\/\/t.co\/2BTuRybjme",
        "expanded_url" : "http:\/\/ow.ly\/OAiQS",
        "display_url" : "ow.ly\/OAiQS"
      } ]
    },
    "geo" : { },
    "id_str" : "612710606437793792",
    "text" : "'Life with Bob Dylan, 1989-2006': http:\/\/t.co\/2BTuRybjme This is what music journalism should be. Thanks, @uncutmagazine",
    "id" : 612710606437793792,
    "created_at" : "2015-06-21 19:56:06 +0000",
    "user" : {
      "name" : "jordipujolnadal",
      "screen_name" : "jordipujolnadal",
      "protected" : false,
      "id_str" : "14197646",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/53091632\/peitroltwitter_normal.jpg",
      "id" : 14197646,
      "verified" : false
    }
  },
  "id" : 612732420928983042,
  "created_at" : "2015-06-21 21:22:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ennomane",
      "screen_name" : "ennomane",
      "indices" : [ 0, 9 ],
      "id_str" : "850704103814705152",
      "id" : 850704103814705152
    }, {
      "name" : "J\u00FCrgen Geuter",
      "screen_name" : "tante",
      "indices" : [ 10, 16 ],
      "id_str" : "14179278",
      "id" : 14179278
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "612713466076495873",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11407161912607, 8.753396652906305 ]
  },
  "id_str" : "612714416056999937",
  "in_reply_to_user_id" : 16034275,
  "text" : "@ennomane @tante \uD83D\uDE4C",
  "id" : 612714416056999937,
  "in_reply_to_status_id" : 612713466076495873,
  "created_at" : "2015-06-21 20:11:15 +0000",
  "in_reply_to_screen_name" : "ennopark",
  "in_reply_to_user_id_str" : "16034275",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lauren Cowley",
      "screen_name" : "LaurenCowley4",
      "indices" : [ 90, 104 ],
      "id_str" : "1137135674",
      "id" : 1137135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/076eF4F8o7",
      "expanded_url" : "http:\/\/bitsandbugs.org\/2015\/06\/21\/sequencing-ebola-in-the-field-a-tale-of-nanopores-mosquitos-and-whatsapp\/",
      "display_url" : "bitsandbugs.org\/2015\/06\/21\/seq\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1140714430596, 8.753395818821438 ]
  },
  "id_str" : "612713701062365184",
  "text" : "Praying mantises &amp; no electricity \u2013 great post about sequencing Ebola in the field by @LaurenCowley4 http:\/\/t.co\/076eF4F8o7",
  "id" : 612713701062365184,
  "created_at" : "2015-06-21 20:08:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "J\u00FCrgen Geuter",
      "screen_name" : "tante",
      "indices" : [ 0, 6 ],
      "id_str" : "14179278",
      "id" : 14179278
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "612711781987975169",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1140708222007, 8.753392877608084 ]
  },
  "id_str" : "612712165473173504",
  "in_reply_to_user_id" : 14179278,
  "text" : "@tante jetzt bin ich ein bisschen beruhigt weil die sample size sich verdoppelt hat. (not alone any longer!)",
  "id" : 612712165473173504,
  "in_reply_to_status_id" : 612711781987975169,
  "created_at" : "2015-06-21 20:02:18 +0000",
  "in_reply_to_screen_name" : "tante",
  "in_reply_to_user_id_str" : "14179278",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "J\u00FCrgen Geuter",
      "screen_name" : "tante",
      "indices" : [ 0, 6 ],
      "id_str" : "14179278",
      "id" : 14179278
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "612710812411654144",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11407172410992, 8.753397150249397 ]
  },
  "id_str" : "612711302243450880",
  "in_reply_to_user_id" : 14179278,
  "text" : "@tante mein Hirn parst das hashtag jedes mal wieder zu \u201Cdie idioten kommen\u201D, was mich immer wieder aufs neue verwirrt\u2026",
  "id" : 612711302243450880,
  "in_reply_to_status_id" : 612710812411654144,
  "created_at" : "2015-06-21 19:58:52 +0000",
  "in_reply_to_screen_name" : "tante",
  "in_reply_to_user_id_str" : "14179278",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/mSVsMspUfO",
      "expanded_url" : "http:\/\/spinweaveandcut.com\/unflattening\/",
      "display_url" : "spinweaveandcut.com\/unflattening\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11407068750793, 8.753392239523988 ]
  },
  "id_str" : "612705730110595072",
  "text" : "upping the ante: doing your dissertation as a graphic novel, published by HUP\u2026 http:\/\/t.co\/mSVsMspUfO",
  "id" : 612705730110595072,
  "created_at" : "2015-06-21 19:36:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/FMnV9xvLiL",
      "expanded_url" : "http:\/\/loonylabs.org\/2015\/06\/20\/children-with-good-memories-are-better-liars\/",
      "display_url" : "loonylabs.org\/2015\/06\/20\/chi\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11407076252154, 8.753392594888213 ]
  },
  "id_str" : "612702854055362560",
  "text" : "a good working memory has been linked to being a good liar. Cpt. Obvious et al. 2015 http:\/\/t.co\/FMnV9xvLiL",
  "id" : 612702854055362560,
  "created_at" : "2015-06-21 19:25:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    }, {
      "name" : "Sebastian Greiner",
      "screen_name" : "Seb666",
      "indices" : [ 10, 17 ],
      "id_str" : "2365333778",
      "id" : 2365333778
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 18, 24 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "612680589586644993",
  "geo" : { },
  "id_str" : "612681741652873216",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich @Seb666 @Lobot die Edition f\u00FCr besonders girly Girls sollte dann aber XXX hei\u00DFen.",
  "id" : 612681741652873216,
  "in_reply_to_status_id" : 612680589586644993,
  "created_at" : "2015-06-21 18:01:24 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sebastian Greiner",
      "screen_name" : "Seb666",
      "indices" : [ 0, 7 ],
      "id_str" : "2365333778",
      "id" : 2365333778
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 8, 14 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "612679039090823168",
  "geo" : { },
  "id_str" : "612679590000128000",
  "in_reply_to_user_id" : 2365333778,
  "text" : "@Seb666 @Lobot umso besser, das Portfolio diversifizieren! ;)",
  "id" : 612679590000128000,
  "in_reply_to_status_id" : 612679039090823168,
  "created_at" : "2015-06-21 17:52:51 +0000",
  "in_reply_to_screen_name" : "Seb666",
  "in_reply_to_user_id_str" : "2365333778",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/612678835771940864\/photo\/1",
      "indices" : [ 6, 28 ],
      "url" : "http:\/\/t.co\/CSxMVdhh9j",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CICsJzRWEAA1RzF.jpg",
      "id_str" : "612678833704144896",
      "id" : 612678833704144896,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CICsJzRWEAA1RzF.jpg",
      "sizes" : [ {
        "h" : 680,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/CSxMVdhh9j"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "612678835771940864",
  "text" : "Okay\u2026 http:\/\/t.co\/CSxMVdhh9j",
  "id" : 612678835771940864,
  "created_at" : "2015-06-21 17:49:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    }, {
      "name" : "Sebastian Greiner",
      "screen_name" : "Seb666",
      "indices" : [ 80, 87 ],
      "id_str" : "2365333778",
      "id" : 2365333778
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "612676999866392576",
  "geo" : { },
  "id_str" : "612678291393249280",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot well, that\u2019s one service I could offer to make money to pay for openSNP \/@Seb666",
  "id" : 612678291393249280,
  "in_reply_to_status_id" : 612676999866392576,
  "created_at" : "2015-06-21 17:47:42 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 7, 30 ],
      "url" : "https:\/\/t.co\/Nx4oLylZBI",
      "expanded_url" : "https:\/\/instagram.com\/p\/4MpqRdBwuh\/",
      "display_url" : "instagram.com\/p\/4MpqRdBwuh\/"
    } ]
  },
  "geo" : { },
  "id_str" : "612656227143806976",
  "text" : "Golden https:\/\/t.co\/Nx4oLylZBI",
  "id" : 612656227143806976,
  "created_at" : "2015-06-21 16:20:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "612642282060296193",
  "text" : "\u00ABI guess my car &amp; I are pretty similar in that way: we work reasonably well when allowed to move but when forced to stay things go awry.\u00BB",
  "id" : 612642282060296193,
  "created_at" : "2015-06-21 15:24:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Martin Pittenauer",
      "screen_name" : "map",
      "indices" : [ 0, 4 ],
      "id_str" : "6256252",
      "id" : 6256252
    }, {
      "name" : "Michael Seemann",
      "screen_name" : "mspro",
      "indices" : [ 5, 11 ],
      "id_str" : "5751892",
      "id" : 5751892
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "612571655546781696",
  "geo" : { },
  "id_str" : "612572326589276160",
  "in_reply_to_user_id" : 6256252,
  "text" : "@map @mspro no one talked of actually making a device. Just about doing a kickstarter! \u263A\uFE0F",
  "id" : 612572326589276160,
  "in_reply_to_status_id" : 612571655546781696,
  "created_at" : "2015-06-21 10:46:38 +0000",
  "in_reply_to_screen_name" : "map",
  "in_reply_to_user_id_str" : "6256252",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "612571926742106113",
  "text" : "I should offer courses on data transformation: \u00ABHow to accidentally turn &lt;1 MB of chat logs into big data that make your MacBook Air crash.\u00BB",
  "id" : 612571926742106113,
  "created_at" : "2015-06-21 10:45:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "612391465726124032",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11406983104974, 8.753388182199046 ]
  },
  "id_str" : "612391739912011776",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich hat etwas gedauert bis ich das gegooglet hatte \uD83D\uDC22\uD83C\uDDEE\uD83C\uDDF9",
  "id" : 612391739912011776,
  "in_reply_to_status_id" : 612391465726124032,
  "created_at" : "2015-06-20 22:49:03 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "612386073361154048",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1140696007572, 8.753387091227584 ]
  },
  "id_str" : "612386388193988610",
  "in_reply_to_user_id" : 14286491,
  "text" : "The german subtitles on the other hand solved the issue by clumsily using first \u201Carmoured animal\u201D and then \u201Cturtles\u201D\u2026 #\uD83D\uDC22",
  "id" : 612386388193988610,
  "in_reply_to_status_id" : 612386073361154048,
  "created_at" : "2015-06-20 22:27:47 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11406973154439, 8.753387710817405 ]
  },
  "id_str" : "612386073361154048",
  "text" : "TIL how the dub of Blade Runner solved the issue of German having only a single word describing turtles &amp; tortoises: w\/ the Italian word 4 \uD83D\uDC22",
  "id" : 612386073361154048,
  "created_at" : "2015-06-20 22:26:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sebastian Greiner",
      "screen_name" : "Seb666",
      "indices" : [ 0, 7 ],
      "id_str" : "2365333778",
      "id" : 2365333778
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 50 ],
      "url" : "https:\/\/t.co\/o4bpAyiQCA",
      "expanded_url" : "https:\/\/twitter.com\/glyn_dk\/status\/609093783913918464",
      "display_url" : "twitter.com\/glyn_dk\/status\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "612350202196959232",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11406973154439, 8.753387710817405 ]
  },
  "id_str" : "612384811039215617",
  "in_reply_to_user_id" : 2365333778,
  "text" : "@Seb666 could be anything! https:\/\/t.co\/o4bpAyiQCA ;)",
  "id" : 612384811039215617,
  "in_reply_to_status_id" : 612350202196959232,
  "created_at" : "2015-06-20 22:21:31 +0000",
  "in_reply_to_screen_name" : "Seb666",
  "in_reply_to_user_id_str" : "2365333778",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "612351728789389312",
  "text" : "\u00ABAdmit it, you\u2019d rather be the JF Sebastian than the Eldon Tyrell of open source genetics. The naive genius!\u00BB",
  "id" : 612351728789389312,
  "created_at" : "2015-06-20 20:10:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Roman Mars",
      "screen_name" : "romanmars",
      "indices" : [ 87, 97 ],
      "id_str" : "8198012",
      "id" : 8198012
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/3qU7yuEkEZ",
      "expanded_url" : "https:\/\/twitter.com\/tenderlove\/status\/612118213132972032",
      "display_url" : "twitter.com\/tenderlove\/sta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "612318607431892992",
  "text" : "Also: why the 'it's time to do something'-ringtone already made some partners angry at @romanmars [or so I hear\u2026] https:\/\/t.co\/3qU7yuEkEZ",
  "id" : 612318607431892992,
  "created_at" : "2015-06-20 17:58:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11086058263467, 8.754945437219863 ]
  },
  "id_str" : "612314569915150336",
  "text" : "All set for tonight\u2019s Voight-Kampff. If I retake it often enough I\u2019ll end up being a type II error eventually. \uD83D\uDC22",
  "id" : 612314569915150336,
  "created_at" : "2015-06-20 17:42:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andreas Herten",
      "screen_name" : "AndiH",
      "indices" : [ 0, 6 ],
      "id_str" : "4586881",
      "id" : 4586881
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "612215955700236288",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11407018157013, 8.75338984279832 ]
  },
  "id_str" : "612219227144065024",
  "in_reply_to_user_id" : 4586881,
  "text" : "@AndiH na in dem Fall nimm das was du auch gerne nutzt ;-)",
  "id" : 612219227144065024,
  "in_reply_to_status_id" : 612215955700236288,
  "created_at" : "2015-06-20 11:23:32 +0000",
  "in_reply_to_screen_name" : "AndiH",
  "in_reply_to_user_id_str" : "4586881",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andreas Herten",
      "screen_name" : "AndiH",
      "indices" : [ 0, 6 ],
      "id_str" : "4586881",
      "id" : 4586881
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "612215350453739520",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11407031965346, 8.753390496875713 ]
  },
  "id_str" : "612215704717291520",
  "in_reply_to_user_id" : 4586881,
  "text" : "@AndiH ich bin mit dem fitbit charge hr ganz zufrieden. (kann aber auch vendor lock-in stockholm sein, hab dort daten von 3+ jahren).",
  "id" : 612215704717291520,
  "in_reply_to_status_id" : 612215350453739520,
  "created_at" : "2015-06-20 11:09:33 +0000",
  "in_reply_to_screen_name" : "AndiH",
  "in_reply_to_user_id_str" : "4586881",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andreas Herten",
      "screen_name" : "AndiH",
      "indices" : [ 0, 6 ],
      "id_str" : "4586881",
      "id" : 4586881
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "612214344462532608",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11407001019145, 8.753389030857358 ]
  },
  "id_str" : "612214669424631808",
  "in_reply_to_user_id" : 4586881,
  "text" : "@AndiH Ich hab noch eines der ersten Up rumliegen, das mit dem Klinkenanschluss. Und rumliegen ist das richtige Wort, hab\u2019s nur f\u00FCr API-Dev.",
  "id" : 612214669424631808,
  "in_reply_to_status_id" : 612214344462532608,
  "created_at" : "2015-06-20 11:05:26 +0000",
  "in_reply_to_screen_name" : "AndiH",
  "in_reply_to_user_id_str" : "4586881",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/612213871055642624\/photo\/1",
      "indices" : [ 55, 77 ],
      "url" : "http:\/\/t.co\/30dsRidMog",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CH8FRVHWcAAGTfu.png",
      "id_str" : "612213869629566976",
      "id" : 612213869629566976,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CH8FRVHWcAAGTfu.png",
      "sizes" : [ {
        "h" : 410,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 718,
        "resize" : "fit",
        "w" : 1190
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 718,
        "resize" : "fit",
        "w" : 1190
      }, {
        "h" : 718,
        "resize" : "fit",
        "w" : 1190
      } ],
      "display_url" : "pic.twitter.com\/30dsRidMog"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11406979459336, 8.753388024368782 ]
  },
  "id_str" : "612213871055642624",
  "text" : "Yay, got the first data points out of the Jawbone API. http:\/\/t.co\/30dsRidMog",
  "id" : 612213871055642624,
  "created_at" : "2015-06-20 11:02:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "612050511156674560",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1140697648402, 8.753387895369992 ]
  },
  "id_str" : "612202512557416448",
  "in_reply_to_user_id" : 14286491,
  "text" : "Wondering since yesterday whether one could train HMMs on those emoji co-occurrences and use them for classifying chat-partner\/device combos",
  "id" : 612202512557416448,
  "in_reply_to_status_id" : 612050511156674560,
  "created_at" : "2015-06-20 10:17:07 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Science Web",
      "screen_name" : "TheScienceWeb",
      "indices" : [ 3, 17 ],
      "id_str" : "2315551122",
      "id" : 2315551122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/ABnmy4z8cB",
      "expanded_url" : "http:\/\/wp.me\/p4ik2k-50",
      "display_url" : "wp.me\/p4ik2k-50"
    } ]
  },
  "geo" : { },
  "id_str" : "612188130972696576",
  "text" : "RT @TheScienceWeb: Old privileged idiots defend Tim Hunt and call for sexism to be brought back http:\/\/t.co\/ABnmy4z8cB",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 77, 99 ],
        "url" : "http:\/\/t.co\/ABnmy4z8cB",
        "expanded_url" : "http:\/\/wp.me\/p4ik2k-50",
        "display_url" : "wp.me\/p4ik2k-50"
      } ]
    },
    "geo" : { },
    "id_str" : "612181555142885376",
    "text" : "Old privileged idiots defend Tim Hunt and call for sexism to be brought back http:\/\/t.co\/ABnmy4z8cB",
    "id" : 612181555142885376,
    "created_at" : "2015-06-20 08:53:51 +0000",
    "user" : {
      "name" : "The Science Web",
      "screen_name" : "TheScienceWeb",
      "protected" : false,
      "id_str" : "2315551122",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/428172546672824320\/1lZmC7lz_normal.jpeg",
      "id" : 2315551122,
      "verified" : false
    }
  },
  "id" : 612188130972696576,
  "created_at" : "2015-06-20 09:19:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/612050511156674560\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/7z2DCwR42I",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CH5wsh_W8AE1wEe.png",
      "id_str" : "612050509709635585",
      "id" : 612050509709635585,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CH5wsh_W8AE1wEe.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 582,
        "resize" : "fit",
        "w" : 825
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 582,
        "resize" : "fit",
        "w" : 825
      }, {
        "h" : 582,
        "resize" : "fit",
        "w" : 825
      } ],
      "display_url" : "pic.twitter.com\/7z2DCwR42I"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/j4cnL5TYwD",
      "expanded_url" : "http:\/\/blog.mailchimp.com\/mailchimps-most-popular-subject-line-emojis\/",
      "display_url" : "blog.mailchimp.com\/mailchimps-mos\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11406995584417, 8.753389149785786 ]
  },
  "id_str" : "612050511156674560",
  "text" : "Being unable to get the chat data into R, I went the co-occurrences network route, following http:\/\/t.co\/j4cnL5TYwD http:\/\/t.co\/7z2DCwR42I",
  "id" : 612050511156674560,
  "created_at" : "2015-06-20 00:13:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert",
      "screen_name" : "kventil",
      "indices" : [ 0, 8 ],
      "id_str" : "7431192",
      "id" : 7431192
    }, {
      "name" : "malech maltz",
      "screen_name" : "malech",
      "indices" : [ 9, 16 ],
      "id_str" : "784085846391713793",
      "id" : 784085846391713793
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "612008054821924868",
  "geo" : { },
  "id_str" : "612008775218790400",
  "in_reply_to_user_id" : 7431192,
  "text" : "@kventil @malech au\u00DFerdem muss die Sonne schon extrem tief stehen damit ich f\u00FCr sowas nicht mehr \u00FCber meinen Schatten spring ;)",
  "id" : 612008775218790400,
  "in_reply_to_status_id" : 612008054821924868,
  "created_at" : "2015-06-19 21:27:17 +0000",
  "in_reply_to_screen_name" : "kventil",
  "in_reply_to_user_id_str" : "7431192",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert",
      "screen_name" : "kventil",
      "indices" : [ 0, 8 ],
      "id_str" : "7431192",
      "id" : 7431192
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "612004473280557058",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11406986949532, 8.753390175729276 ]
  },
  "id_str" : "612004561348333568",
  "in_reply_to_user_id" : 7431192,
  "text" : "@kventil na klar, im chaosradio haben wir das ja nur angeschnitten :)",
  "id" : 612004561348333568,
  "in_reply_to_status_id" : 612004473280557058,
  "created_at" : "2015-06-19 21:10:32 +0000",
  "in_reply_to_screen_name" : "kventil",
  "in_reply_to_user_id_str" : "7431192",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert",
      "screen_name" : "kventil",
      "indices" : [ 0, 8 ],
      "id_str" : "7431192",
      "id" : 7431192
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "612004389696442368",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11406986949532, 8.753390175729276 ]
  },
  "id_str" : "612004489541849092",
  "in_reply_to_user_id" : 7431192,
  "text" : "@kventil \uD83D\uDC4Dso soll es sein :)",
  "id" : 612004489541849092,
  "in_reply_to_status_id" : 612004389696442368,
  "created_at" : "2015-06-19 21:10:15 +0000",
  "in_reply_to_screen_name" : "kventil",
  "in_reply_to_user_id_str" : "7431192",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert",
      "screen_name" : "kventil",
      "indices" : [ 0, 8 ],
      "id_str" : "7431192",
      "id" : 7431192
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 39 ],
      "url" : "https:\/\/t.co\/vUTpWZr4yJ",
      "expanded_url" : "https:\/\/opensnp.org\/genotypes\/new",
      "display_url" : "opensnp.org\/genotypes\/new"
    } ]
  },
  "in_reply_to_status_id_str" : "612003395797405696",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11406986949532, 8.753390175729276 ]
  },
  "id_str" : "612004183244447744",
  "in_reply_to_user_id" : 7431192,
  "text" : "@kventil *hust* https:\/\/t.co\/vUTpWZr4yJ *hust*",
  "id" : 612004183244447744,
  "in_reply_to_status_id" : 612003395797405696,
  "created_at" : "2015-06-19 21:09:02 +0000",
  "in_reply_to_screen_name" : "kventil",
  "in_reply_to_user_id_str" : "7431192",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kit Stubbs, Ph.D.",
      "screen_name" : "vortacist",
      "indices" : [ 3, 13 ],
      "id_str" : "347340056",
      "id" : 347340056
    }, {
      "name" : "Kit Stubbs, Ph.D.",
      "screen_name" : "vortacist",
      "indices" : [ 15, 25 ],
      "id_str" : "347340056",
      "id" : 347340056
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "611985759734788096",
  "text" : "RT @vortacist: @vortacist (Although not everyone, in fact, likes to cuddle, so make sure you have enthusastic consent first!)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Kit Stubbs, Ph.D.",
        "screen_name" : "vortacist",
        "indices" : [ 0, 10 ],
        "id_str" : "347340056",
        "id" : 347340056
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "611984413057007617",
    "geo" : { },
    "id_str" : "611984553423585284",
    "in_reply_to_user_id" : 347340056,
    "text" : "@vortacist (Although not everyone, in fact, likes to cuddle, so make sure you have enthusastic consent first!)",
    "id" : 611984553423585284,
    "in_reply_to_status_id" : 611984413057007617,
    "created_at" : "2015-06-19 19:51:02 +0000",
    "in_reply_to_screen_name" : "vortacist",
    "in_reply_to_user_id_str" : "347340056",
    "user" : {
      "name" : "Kit Stubbs, Ph.D.",
      "screen_name" : "vortacist",
      "protected" : false,
      "id_str" : "347340056",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/819220259148177408\/UYT71cyh_normal.jpg",
      "id" : 347340056,
      "verified" : false
    }
  },
  "id" : 611985759734788096,
  "created_at" : "2015-06-19 19:55:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kit Stubbs, Ph.D.",
      "screen_name" : "vortacist",
      "indices" : [ 3, 13 ],
      "id_str" : "347340056",
      "id" : 347340056
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/vortacist\/status\/611984413057007617\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/PXkRubkq1O",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CH40lLMW8AAwT-X.png",
      "id_str" : "611984412633395200",
      "id" : 611984412633395200,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CH40lLMW8AAwT-X.png",
      "sizes" : [ {
        "h" : 107,
        "resize" : "fit",
        "w" : 796
      }, {
        "h" : 107,
        "resize" : "crop",
        "w" : 107
      }, {
        "h" : 91,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 107,
        "resize" : "fit",
        "w" : 796
      }, {
        "h" : 107,
        "resize" : "fit",
        "w" : 796
      } ],
      "display_url" : "pic.twitter.com\/PXkRubkq1O"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "611985749127397376",
  "text" : "RT @vortacist: Best Google autocomplete ever. (\"gender is a social construct but\" ... \"everyone likes to cuddle\") http:\/\/t.co\/PXkRubkq1O",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/vortacist\/status\/611984413057007617\/photo\/1",
        "indices" : [ 99, 121 ],
        "url" : "http:\/\/t.co\/PXkRubkq1O",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CH40lLMW8AAwT-X.png",
        "id_str" : "611984412633395200",
        "id" : 611984412633395200,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CH40lLMW8AAwT-X.png",
        "sizes" : [ {
          "h" : 107,
          "resize" : "fit",
          "w" : 796
        }, {
          "h" : 107,
          "resize" : "crop",
          "w" : 107
        }, {
          "h" : 91,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 107,
          "resize" : "fit",
          "w" : 796
        }, {
          "h" : 107,
          "resize" : "fit",
          "w" : 796
        } ],
        "display_url" : "pic.twitter.com\/PXkRubkq1O"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "611984413057007617",
    "text" : "Best Google autocomplete ever. (\"gender is a social construct but\" ... \"everyone likes to cuddle\") http:\/\/t.co\/PXkRubkq1O",
    "id" : 611984413057007617,
    "created_at" : "2015-06-19 19:50:28 +0000",
    "user" : {
      "name" : "Kit Stubbs, Ph.D.",
      "screen_name" : "vortacist",
      "protected" : false,
      "id_str" : "347340056",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/819220259148177408\/UYT71cyh_normal.jpg",
      "id" : 347340056,
      "verified" : false
    }
  },
  "id" : 611985749127397376,
  "created_at" : "2015-06-19 19:55:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ga4gh",
      "indices" : [ 45, 51 ]
    } ],
    "urls" : [ {
      "indices" : [ 52, 74 ],
      "url" : "http:\/\/t.co\/lklY84XckU",
      "expanded_url" : "http:\/\/cdn.makeagif.com\/media\/6-19-2015\/XA1LqN.gif",
      "display_url" : "cdn.makeagif.com\/media\/6-19-201\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11407021292211, 8.753389975467543 ]
  },
  "id_str" : "611978592701050880",
  "text" : "openSNP is now member of the Global Alliance #ga4gh http:\/\/t.co\/lklY84XckU",
  "id" : 611978592701050880,
  "created_at" : "2015-06-19 19:27:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Guo",
      "screen_name" : "pgbovine",
      "indices" : [ 3, 12 ],
      "id_str" : "17773446",
      "id" : 17773446
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/LdGnVsm8Nx",
      "expanded_url" : "http:\/\/pgbovine.net\/cmdline-bs-example.htm",
      "display_url" : "pgbovine.net\/cmdline-bs-exa\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "611966859982831616",
  "text" : "RT @pgbovine: yes, i lead a glamorous life. \"An example of command-line bullshittery in computer science research\" http:\/\/t.co\/LdGnVsm8Nx",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 101, 123 ],
        "url" : "http:\/\/t.co\/LdGnVsm8Nx",
        "expanded_url" : "http:\/\/pgbovine.net\/cmdline-bs-example.htm",
        "display_url" : "pgbovine.net\/cmdline-bs-exa\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "611957023995899905",
    "text" : "yes, i lead a glamorous life. \"An example of command-line bullshittery in computer science research\" http:\/\/t.co\/LdGnVsm8Nx",
    "id" : 611957023995899905,
    "created_at" : "2015-06-19 18:01:38 +0000",
    "user" : {
      "name" : "Philip Guo",
      "screen_name" : "pgbovine",
      "protected" : false,
      "id_str" : "17773446",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/661230489357967360\/HB3vsn3O_normal.jpg",
      "id" : 17773446,
      "verified" : true
    }
  },
  "id" : 611966859982831616,
  "created_at" : "2015-06-19 18:40:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dvzrv",
      "screen_name" : "dvzrv",
      "indices" : [ 0, 6 ],
      "id_str" : "30868098",
      "id" : 30868098
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "611940008522444801",
  "geo" : { },
  "id_str" : "611940278245662720",
  "in_reply_to_user_id" : 30868098,
  "text" : "@dvzrv thanks! :)",
  "id" : 611940278245662720,
  "in_reply_to_status_id" : 611940008522444801,
  "created_at" : "2015-06-19 16:55:06 +0000",
  "in_reply_to_screen_name" : "dvzrv",
  "in_reply_to_user_id_str" : "30868098",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "friendly neighborhood dogmom",
      "screen_name" : "duckinator",
      "indices" : [ 3, 14 ],
      "id_str" : "28650670",
      "id" : 28650670
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/6sWmOtHLTm",
      "expanded_url" : "https:\/\/github.com\/opal\/opal\/issues\/941#issuecomment-113231996",
      "display_url" : "github.com\/opal\/opal\/issu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "611935854983028736",
  "text" : "RT @duckinator: THIS THIS THIS THIS THIS THIS THIS THIS THIS THIS THIS THIS THIS THIS THIS THIS THIS THIS: https:\/\/t.co\/6sWmOtHLTm http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/duckinator\/status\/611644090409598976\/photo\/1",
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/K2782DyjHX",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CHz-8tuWgAA126a.png",
        "id_str" : "611643968435159040",
        "id" : 611643968435159040,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHz-8tuWgAA126a.png",
        "sizes" : [ {
          "h" : 593,
          "resize" : "fit",
          "w" : 1020
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 395,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 593,
          "resize" : "fit",
          "w" : 1020
        }, {
          "h" : 593,
          "resize" : "fit",
          "w" : 1020
        } ],
        "display_url" : "pic.twitter.com\/K2782DyjHX"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 91, 114 ],
        "url" : "https:\/\/t.co\/6sWmOtHLTm",
        "expanded_url" : "https:\/\/github.com\/opal\/opal\/issues\/941#issuecomment-113231996",
        "display_url" : "github.com\/opal\/opal\/issu\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "611644090409598976",
    "text" : "THIS THIS THIS THIS THIS THIS THIS THIS THIS THIS THIS THIS THIS THIS THIS THIS THIS THIS: https:\/\/t.co\/6sWmOtHLTm http:\/\/t.co\/K2782DyjHX",
    "id" : 611644090409598976,
    "created_at" : "2015-06-18 21:18:09 +0000",
    "user" : {
      "name" : "friendly neighborhood dogmom",
      "screen_name" : "duckinator",
      "protected" : false,
      "id_str" : "28650670",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/930786452614582272\/iYPupCxU_normal.jpg",
      "id" : 28650670,
      "verified" : false
    }
  },
  "id" : 611935854983028736,
  "created_at" : "2015-06-19 16:37:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17222497065197, 8.627619924937038 ]
  },
  "id_str" : "611921828496441344",
  "text" : "\u00ABRight now, it would take you about 24min to drive to Offenbach am Main\u00BB Funny, used to say \u2018\u2026to drive home\u2019, seems my phone is confused too",
  "id" : 611921828496441344,
  "created_at" : "2015-06-19 15:41:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dvzrv",
      "screen_name" : "dvzrv",
      "indices" : [ 0, 6 ],
      "id_str" : "30868098",
      "id" : 30868098
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "611913827844800512",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17221833152302, 8.627605161045622 ]
  },
  "id_str" : "611914184947838976",
  "in_reply_to_user_id" : 30868098,
  "text" : "@dvzrv link? :D",
  "id" : 611914184947838976,
  "in_reply_to_status_id" : 611913827844800512,
  "created_at" : "2015-06-19 15:11:25 +0000",
  "in_reply_to_screen_name" : "dvzrv",
  "in_reply_to_user_id_str" : "30868098",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marcos Besteiro",
      "screen_name" : "MarcosBL",
      "indices" : [ 3, 12 ],
      "id_str" : "9276642",
      "id" : 9276642
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/MarcosBL\/status\/611616749696516096\/photo\/1",
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/9mF8wnyXUv",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CHzmMWZWoAA8CTJ.jpg",
      "id_str" : "611616749260283904",
      "id" : 611616749260283904,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHzmMWZWoAA8CTJ.jpg",
      "sizes" : [ {
        "h" : 3264,
        "resize" : "fit",
        "w" : 2448
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      } ],
      "display_url" : "pic.twitter.com\/9mF8wnyXUv"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "611911592922476545",
  "text" : "RT @MarcosBL: Five key phases of Software Development http:\/\/t.co\/9mF8wnyXUv",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/marcosbl.com\/post\/\" rel=\"nofollow\"\u003EMarcosBL's Poster\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/MarcosBL\/status\/611616749696516096\/photo\/1",
        "indices" : [ 40, 62 ],
        "url" : "http:\/\/t.co\/9mF8wnyXUv",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CHzmMWZWoAA8CTJ.jpg",
        "id_str" : "611616749260283904",
        "id" : 611616749260283904,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHzmMWZWoAA8CTJ.jpg",
        "sizes" : [ {
          "h" : 3264,
          "resize" : "fit",
          "w" : 2448
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 900
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 510
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1536
        } ],
        "display_url" : "pic.twitter.com\/9mF8wnyXUv"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "611616749696516096",
    "text" : "Five key phases of Software Development http:\/\/t.co\/9mF8wnyXUv",
    "id" : 611616749696516096,
    "created_at" : "2015-06-18 19:29:31 +0000",
    "user" : {
      "name" : "Marcos Besteiro",
      "screen_name" : "MarcosBL",
      "protected" : false,
      "id_str" : "9276642",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/713815278933639169\/d_OAymUc_normal.jpg",
      "id" : 9276642,
      "verified" : false
    }
  },
  "id" : 611911592922476545,
  "created_at" : "2015-06-19 15:01:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "drunksci",
      "indices" : [ 0, 9 ]
    } ],
    "urls" : [ {
      "indices" : [ 10, 32 ],
      "url" : "http:\/\/t.co\/IeoQQcmk3w",
      "expanded_url" : "http:\/\/whatshouldwecallgradschool.tumblr.com\/post\/121918134278",
      "display_url" : "whatshouldwecallgradschool.tumblr.com\/post\/121918134\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "611901955129126914",
  "text" : "#drunksci http:\/\/t.co\/IeoQQcmk3w",
  "id" : 611901955129126914,
  "created_at" : "2015-06-19 14:22:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "611451769596563457",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17224997121129, 8.627596925120969 ]
  },
  "id_str" : "611893290145837056",
  "in_reply_to_user_id" : 14286491,
  "text" : "\u00ABWow, you recognize so many of the women on this poster. Well, I guess that\u2019s what you get for reading a shitload of books!\u00BB yep, works out.",
  "id" : 611893290145837056,
  "in_reply_to_status_id" : 611451769596563457,
  "created_at" : "2015-06-19 13:48:23 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "himbeerkomplott",
      "screen_name" : "raspberryperson",
      "indices" : [ 0, 16 ],
      "id_str" : "2841131495",
      "id" : 2841131495
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "611885732429492224",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17224997121129, 8.627596925120969 ]
  },
  "id_str" : "611891896202432513",
  "in_reply_to_user_id" : 2841131495,
  "text" : "@raspberryperson will have to look into it later. Failed to bring my A\/C adapter to the office today and the notebooks battery\u2019s dead :D",
  "id" : 611891896202432513,
  "in_reply_to_status_id" : 611885732429492224,
  "created_at" : "2015-06-19 13:42:51 +0000",
  "in_reply_to_screen_name" : "raspberryperson",
  "in_reply_to_user_id_str" : "2841131495",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "himbeerkomplott",
      "screen_name" : "raspberryperson",
      "indices" : [ 0, 16 ],
      "id_str" : "2841131495",
      "id" : 2841131495
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "611861743514611712",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17224691023797, 8.627615604875148 ]
  },
  "id_str" : "611867550507499520",
  "in_reply_to_user_id" : 2841131495,
  "text" : "@raspberryperson problem stays for me, guess a combination of locale + whatever is the reason.",
  "id" : 611867550507499520,
  "in_reply_to_status_id" : 611861743514611712,
  "created_at" : "2015-06-19 12:06:06 +0000",
  "in_reply_to_screen_name" : "raspberryperson",
  "in_reply_to_user_id_str" : "2841131495",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "himbeerkomplott",
      "screen_name" : "raspberryperson",
      "indices" : [ 0, 16 ],
      "id_str" : "2841131495",
      "id" : 2841131495
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "611861743514611712",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17220247456436, 8.627626928383934 ]
  },
  "id_str" : "611865672210063360",
  "in_reply_to_user_id" : 2841131495,
  "text" : "@raspberryperson will give it a try then. DL for 3.2.1 is running :)",
  "id" : 611865672210063360,
  "in_reply_to_status_id" : 611861743514611712,
  "created_at" : "2015-06-19 11:58:38 +0000",
  "in_reply_to_screen_name" : "raspberryperson",
  "in_reply_to_user_id_str" : "2841131495",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "himbeerkomplott",
      "screen_name" : "raspberryperson",
      "indices" : [ 0, 16 ],
      "id_str" : "2841131495",
      "id" : 2841131495
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "611854648333467648",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722446963762, 8.62758175040392 ]
  },
  "id_str" : "611856783037046784",
  "in_reply_to_user_id" : 2841131495,
  "text" : "@raspberryperson mh, doesn\u2019t seem to work on my end as well. But I\u2019m on 3.1.1 iirc.",
  "id" : 611856783037046784,
  "in_reply_to_status_id" : 611854648333467648,
  "created_at" : "2015-06-19 11:23:19 +0000",
  "in_reply_to_screen_name" : "raspberryperson",
  "in_reply_to_user_id_str" : "2841131495",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GigaScience",
      "screen_name" : "GigaScience",
      "indices" : [ 3, 15 ],
      "id_str" : "208988759",
      "id" : 208988759
    }, {
      "name" : "Steve Wheeler",
      "screen_name" : "timbuckteeth",
      "indices" : [ 18, 31 ],
      "id_str" : "11435832",
      "id" : 11435832
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ReCon_15",
      "indices" : [ 113, 122 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "611854547447873536",
  "text" : "RT @GigaScience: .@timbuckteeth: I showed my 18yo son a floppy disk...he said wow, you 3D printed the save icon! #ReCon_15 http:\/\/t.co\/ZSAC\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Steve Wheeler",
        "screen_name" : "timbuckteeth",
        "indices" : [ 1, 14 ],
        "id_str" : "11435832",
        "id" : 11435832
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/GigaScience\/status\/611854467386994688\/photo\/1",
        "indices" : [ 106, 128 ],
        "url" : "http:\/\/t.co\/ZSACVDFceQ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CH2-Y9hWoAACa76.jpg",
        "id_str" : "611854460432850944",
        "id" : 611854460432850944,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CH2-Y9hWoAACa76.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/ZSACVDFceQ"
      } ],
      "hashtags" : [ {
        "text" : "ReCon_15",
        "indices" : [ 96, 105 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "611854467386994688",
    "text" : ".@timbuckteeth: I showed my 18yo son a floppy disk...he said wow, you 3D printed the save icon! #ReCon_15 http:\/\/t.co\/ZSACVDFceQ",
    "id" : 611854467386994688,
    "created_at" : "2015-06-19 11:14:07 +0000",
    "user" : {
      "name" : "GigaScience",
      "screen_name" : "GigaScience",
      "protected" : false,
      "id_str" : "208988759",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1404305552\/profile-photo-GigaScience-96x96_normal.jpg",
      "id" : 208988759,
      "verified" : false
    }
  },
  "id" : 611854547447873536,
  "created_at" : "2015-06-19 11:14:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "611821640540901376",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17223379811917, 8.627603278078434 ]
  },
  "id_str" : "611826299418624000",
  "in_reply_to_user_id" : 14286491,
  "text" : "As we\u2019re on it: is there some way to get R\/ggplot2 to show emoji?",
  "id" : 611826299418624000,
  "in_reply_to_status_id" : 611821640540901376,
  "created_at" : "2015-06-19 09:22:11 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17220365955053, 8.627614304190198 ]
  },
  "id_str" : "611821640540901376",
  "text" : "Trying to process text full of emoji. Makes the mix of 0\/1 indexed bioinformatics formats look sane.",
  "id" : 611821640540901376,
  "created_at" : "2015-06-19 09:03:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17218346624207, 8.627622568145826 ]
  },
  "id_str" : "611795404850655232",
  "text" : "Updating a poster last used in 2012: removing the last references to deCODEme, adding a 0 to the # of data sets on openSNP.",
  "id" : 611795404850655232,
  "created_at" : "2015-06-19 07:19:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/XroYbrmE09",
      "expanded_url" : "https:\/\/biomickwatson.wordpress.com\/2015\/06\/18\/101-bioinformatics-facts\/",
      "display_url" : "biomickwatson.wordpress.com\/2015\/06\/18\/101\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17218346624207, 8.627622568145826 ]
  },
  "id_str" : "611794884282990592",
  "text" : "\u00AB63% of Bioinformaticists were Biologists to start with, but they realized that the cold room is really COLD.\u00BB https:\/\/t.co\/XroYbrmE09",
  "id" : 611794884282990592,
  "created_at" : "2015-06-19 07:17:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/aKglmWR5hg",
      "expanded_url" : "http:\/\/stackoverflow.com\/questions\/5438474\/plotting-a-sequence-logo-using-ggplot2",
      "display_url" : "stackoverflow.com\/questions\/5438\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1140706114877, 8.753392646308695 ]
  },
  "id_str" : "611686913737670656",
  "text" : "\u00ABI think this is an abomination of a plot, and hope there isn't a way in ggplot2 to do it!\u00BB http:\/\/t.co\/aKglmWR5hg",
  "id" : 611686913737670656,
  "created_at" : "2015-06-19 00:08:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "S. Shelly Jang",
      "screen_name" : "shellyjang",
      "indices" : [ 0, 11 ],
      "id_str" : "19054513",
      "id" : 19054513
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "611677035270832128",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11407104899417, 8.753394703072175 ]
  },
  "id_str" : "611677127692419072",
  "in_reply_to_user_id" : 19054513,
  "text" : "@shellyjang great, thanks! :-)",
  "id" : 611677127692419072,
  "in_reply_to_status_id" : 611677035270832128,
  "created_at" : "2015-06-18 23:29:26 +0000",
  "in_reply_to_screen_name" : "shellyjang",
  "in_reply_to_user_id_str" : "19054513",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "S. Shelly Jang",
      "screen_name" : "shellyjang",
      "indices" : [ 0, 11 ],
      "id_str" : "19054513",
      "id" : 19054513
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/mHn0aPIcKR",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/389508570557210625",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11406988602752, 8.753389237949994 ]
  },
  "id_str" : "611676286193389568",
  "in_reply_to_user_id" : 19054513,
  "text" : "@shellyjang do you have some place to read about your work on your chat logs? :-) looked into mine too a while back: https:\/\/t.co\/mHn0aPIcKR",
  "id" : 611676286193389568,
  "created_at" : "2015-06-18 23:26:05 +0000",
  "in_reply_to_screen_name" : "shellyjang",
  "in_reply_to_user_id_str" : "19054513",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 62 ],
      "url" : "http:\/\/t.co\/BzypbsiGYA",
      "expanded_url" : "http:\/\/stackoverflow.com\/questions\/10705062\/behind-the-scenes-core-data-dates-stored-with-31-year-offset",
      "display_url" : "stackoverflow.com\/questions\/1070\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1140697959231, 8.753388815552485 ]
  },
  "id_str" : "611671730969559040",
  "text" : "ok, sqlite, happy we talked about this\u2026 http:\/\/t.co\/BzypbsiGYA",
  "id" : 611671730969559040,
  "created_at" : "2015-06-18 23:07:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11407003900515, 8.75338996219911 ]
  },
  "id_str" : "611648903235141632",
  "text" : "\u00ABWeird, it\u2019s like all these TSA regulations and security things at the airports are just made up and don\u2019t work at all!\u00BB",
  "id" : 611648903235141632,
  "created_at" : "2015-06-18 21:37:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/ii9qVSFSxz",
      "expanded_url" : "https:\/\/github.com\/opal\/opal\/issues\/941#issuecomment-113269835",
      "display_url" : "github.com\/opal\/opal\/issu\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11407027879449, 8.753391095523812 ]
  },
  "id_str" : "611636198503804928",
  "text" : "\u00ABOpal has no opinions since it's a project.\u00BB yeah, because OSS projects aren\u2019t a social enterprise at all\u2026 m( https:\/\/t.co\/ii9qVSFSxz",
  "id" : 611636198503804928,
  "created_at" : "2015-06-18 20:46:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 73 ],
      "url" : "https:\/\/t.co\/SKmwgSCJHi",
      "expanded_url" : "https:\/\/twitter.com\/edyong209\/status\/611631680806371328",
      "display_url" : "twitter.com\/edyong209\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "611632835489845248",
  "text" : "Still a better dieting story than the paleo diet! https:\/\/t.co\/SKmwgSCJHi",
  "id" : 611632835489845248,
  "created_at" : "2015-06-18 20:33:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ewan Birney",
      "screen_name" : "ewanbirney",
      "indices" : [ 0, 11 ],
      "id_str" : "183548902",
      "id" : 183548902
    }, {
      "name" : "Fiona Nielsen",
      "screen_name" : "glyn_dk",
      "indices" : [ 12, 20 ],
      "id_str" : "32340834",
      "id" : 32340834
    }, {
      "name" : "23andMe",
      "screen_name" : "23andMe",
      "indices" : [ 21, 29 ],
      "id_str" : "14738561",
      "id" : 14738561
    }, {
      "name" : "openSNP team",
      "screen_name" : "openSNPorg",
      "indices" : [ 67, 78 ],
      "id_str" : "380205172",
      "id" : 380205172
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "611625223268487168",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1140673962585, 8.753377531933609 ]
  },
  "id_str" : "611625447806345217",
  "in_reply_to_user_id" : 183548902,
  "text" : "@ewanbirney @glyn_dk @23andMe we actually like to think of this as @openSNPorg in near-future. ;-)",
  "id" : 611625447806345217,
  "in_reply_to_status_id" : 611625223268487168,
  "created_at" : "2015-06-18 20:04:04 +0000",
  "in_reply_to_screen_name" : "ewanbirney",
  "in_reply_to_user_id_str" : "183548902",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "23andMe",
      "screen_name" : "23andMe",
      "indices" : [ 44, 52 ],
      "id_str" : "14738561",
      "id" : 14738561
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "PowerOf1Million",
      "indices" : [ 27, 43 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "611623072391667712",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11406991336422, 8.753388593603308 ]
  },
  "id_str" : "611623715193901059",
  "in_reply_to_user_id" : 14286491,
  "text" : "Anyway: congratulations to #PowerOf1Million @23andMe. Now let\u2019s imagine the power that already 1\/10th of the data could have if it was open.",
  "id" : 611623715193901059,
  "in_reply_to_status_id" : 611623072391667712,
  "created_at" : "2015-06-18 19:57:11 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "23andMe",
      "screen_name" : "23andMe",
      "indices" : [ 4, 12 ],
      "id_str" : "14738561",
      "id" : 14738561
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "PowerOf1Million",
      "indices" : [ 124, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11407009777832, 8.753389426507125 ]
  },
  "id_str" : "611623072391667712",
  "text" : "So, @23andMe reached 1 mio. customers now and apparently I\u2019m #90,773. I wouldn\u2019t have guessed being such an early customer. #PowerOf1Million",
  "id" : 611623072391667712,
  "created_at" : "2015-06-18 19:54:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul-Olivier Dehaye",
      "screen_name" : "podehaye",
      "indices" : [ 0, 9 ],
      "id_str" : "2219841242",
      "id" : 2219841242
    }, {
      "name" : "Lukas Biewald",
      "screen_name" : "l2k",
      "indices" : [ 10, 14 ],
      "id_str" : "13920962",
      "id" : 13920962
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "611611682520104960",
  "geo" : { },
  "id_str" : "611615852476133376",
  "in_reply_to_user_id" : 2219841242,
  "text" : "@podehaye @l2k oh, very cool. Let\u2019s keep fingers crossed that we meet in Brussels then. And I\u2019ll probably be in Basel before opencon.",
  "id" : 611615852476133376,
  "in_reply_to_status_id" : 611611682520104960,
  "created_at" : "2015-06-18 19:25:57 +0000",
  "in_reply_to_screen_name" : "podehaye",
  "in_reply_to_user_id_str" : "2219841242",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul-Olivier Dehaye",
      "screen_name" : "podehaye",
      "indices" : [ 0, 9 ],
      "id_str" : "2219841242",
      "id" : 2219841242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "611600740356853762",
  "geo" : { },
  "id_str" : "611601133493207040",
  "in_reply_to_user_id" : 2219841242,
  "text" : "@podehaye wow, looks like it\u2019s worth having a closer look into. Thanks! Btw: did you decide on applying for opencon? :-)",
  "id" : 611601133493207040,
  "in_reply_to_status_id" : 611600740356853762,
  "created_at" : "2015-06-18 18:27:27 +0000",
  "in_reply_to_screen_name" : "podehaye",
  "in_reply_to_user_id_str" : "2219841242",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fiona Nielsen",
      "screen_name" : "glyn_dk",
      "indices" : [ 0, 8 ],
      "id_str" : "32340834",
      "id" : 32340834
    }, {
      "name" : "Chris Intagliata",
      "screen_name" : "cintagliata",
      "indices" : [ 9, 21 ],
      "id_str" : "15237501",
      "id" : 15237501
    }, {
      "name" : "Science Friday",
      "screen_name" : "scifri",
      "indices" : [ 22, 29 ],
      "id_str" : "16817883",
      "id" : 16817883
    }, {
      "name" : "The Adaptors",
      "screen_name" : "TheAdaptors",
      "indices" : [ 30, 42 ],
      "id_str" : "2778827209",
      "id" : 2778827209
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "611599861323067393",
  "geo" : { },
  "id_str" : "611600590515388416",
  "in_reply_to_user_id" : 32340834,
  "text" : "@glyn_dk @cintagliata @scifri @TheAdaptors awesome, thanks a lot! Always happy to hear about lichens :)",
  "id" : 611600590515388416,
  "in_reply_to_status_id" : 611599861323067393,
  "created_at" : "2015-06-18 18:25:18 +0000",
  "in_reply_to_screen_name" : "glyn_dk",
  "in_reply_to_user_id_str" : "32340834",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Pashman",
      "screen_name" : "TheSporkful",
      "indices" : [ 17, 29 ],
      "id_str" : "93926107",
      "id" : 93926107
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "611599641629425665",
  "text" : "Listening to the @TheSporkful episode on ice cream while out for a run. Not sure if it\u2019s torture or extra motivating.",
  "id" : 611599641629425665,
  "created_at" : "2015-06-18 18:21:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 0, 10 ],
      "id_str" : "14700783",
      "id" : 14700783
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 11, 17 ],
      "id_str" : "1492631",
      "id" : 1492631
    }, {
      "name" : "Beer DeCoded",
      "screen_name" : "beerdecoded",
      "indices" : [ 18, 30 ],
      "id_str" : "3295237359",
      "id" : 3295237359
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 31, 44 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "611578291397505024",
  "geo" : { },
  "id_str" : "611578418459738113",
  "in_reply_to_user_id" : 14700783,
  "text" : "@Fischblog @Lobot @beerdecoded @PhilippBayer might have gone overboard with the drinking, so sobering up took some time :p",
  "id" : 611578418459738113,
  "in_reply_to_status_id" : 611578291397505024,
  "created_at" : "2015-06-18 16:57:12 +0000",
  "in_reply_to_screen_name" : "Fischblog",
  "in_reply_to_user_id_str" : "14700783",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Keith Bradnam",
      "screen_name" : "kbradnam",
      "indices" : [ 0, 9 ],
      "id_str" : "17061155",
      "id" : 17061155
    }, {
      "name" : "Mick Watson",
      "screen_name" : "BioMickWatson",
      "indices" : [ 10, 24 ],
      "id_str" : "228586748",
      "id" : 228586748
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "611522628071768064",
  "geo" : { },
  "id_str" : "611577656623153152",
  "in_reply_to_user_id" : 17061155,
  "text" : "@kbradnam @BioMickWatson please let\u2019s do this. I always wanted to write a \u2018101 nonsensical rules\u2019 article!",
  "id" : 611577656623153152,
  "in_reply_to_status_id" : 611522628071768064,
  "created_at" : "2015-06-18 16:54:10 +0000",
  "in_reply_to_screen_name" : "kbradnam",
  "in_reply_to_user_id_str" : "17061155",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "rickoLus",
      "screen_name" : "iamrickoLus",
      "indices" : [ 3, 15 ],
      "id_str" : "15701226",
      "id" : 15701226
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "611576235823599616",
  "text" : "RT @iamrickoLus: Fuck guns, buy a guitar instead",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "611575947674804225",
    "text" : "Fuck guns, buy a guitar instead",
    "id" : 611575947674804225,
    "created_at" : "2015-06-18 16:47:23 +0000",
    "user" : {
      "name" : "rickoLus",
      "screen_name" : "iamrickoLus",
      "protected" : false,
      "id_str" : "15701226",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/925039175992307712\/3MojGgkp_normal.jpg",
      "id" : 15701226,
      "verified" : false
    }
  },
  "id" : 611576235823599616,
  "created_at" : "2015-06-18 16:48:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    }, {
      "name" : "Beer DeCoded",
      "screen_name" : "beerdecoded",
      "indices" : [ 7, 19 ],
      "id_str" : "3295237359",
      "id" : 3295237359
    }, {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 27, 37 ],
      "id_str" : "14700783",
      "id" : 14700783
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 72, 85 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "611573158819315712",
  "geo" : { },
  "id_str" : "611575908915380225",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot @beerdecoded I fear @Fischblog might drop dead when he sees that @PhilippBayer and I published a new blogpost ;)",
  "id" : 611575908915380225,
  "in_reply_to_status_id" : 611573158819315712,
  "created_at" : "2015-06-18 16:47:13 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Beer DeCoded",
      "screen_name" : "beerdecoded",
      "indices" : [ 0, 12 ],
      "id_str" : "3295237359",
      "id" : 3295237359
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 49 ],
      "url" : "http:\/\/t.co\/MsCGHCoDxY",
      "expanded_url" : "http:\/\/www.scilogs.de\/bierologie\/beersdecoded-welches-bier-ist-mit-welchem-verwandt\/",
      "display_url" : "scilogs.de\/bierologie\/bee\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "611553940493205506",
  "geo" : { },
  "id_str" : "611559100879650817",
  "in_reply_to_user_id" : 3295237359,
  "text" : "@beerdecoded see also here http:\/\/t.co\/MsCGHCoDxY :)",
  "id" : 611559100879650817,
  "in_reply_to_status_id" : 611553940493205506,
  "created_at" : "2015-06-18 15:40:26 +0000",
  "in_reply_to_screen_name" : "beerdecoded",
  "in_reply_to_user_id_str" : "3295237359",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "openSNP team",
      "screen_name" : "openSNPorg",
      "indices" : [ 3, 14 ],
      "id_str" : "380205172",
      "id" : 380205172
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "611543080941035521",
  "text" : "RT @openSNPorg: We like phylogenetic trees, citizen science, &amp; beer. So we can\u2019t help but recommend having a look into BeerDeCoded: https:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 120, 143 ],
        "url" : "https:\/\/t.co\/9Vc1wXV3k7",
        "expanded_url" : "https:\/\/www.kickstarter.com\/projects\/489252126\/beerdecoded-the-1000-beer-genomes",
        "display_url" : "kickstarter.com\/projects\/48925\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "611542728694988800",
    "text" : "We like phylogenetic trees, citizen science, &amp; beer. So we can\u2019t help but recommend having a look into BeerDeCoded: https:\/\/t.co\/9Vc1wXV3k7",
    "id" : 611542728694988800,
    "created_at" : "2015-06-18 14:35:23 +0000",
    "user" : {
      "name" : "openSNP team",
      "screen_name" : "openSNPorg",
      "protected" : false,
      "id_str" : "380205172",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/735374825187909632\/wJEJW1zW_normal.jpg",
      "id" : 380205172,
      "verified" : false
    }
  },
  "id" : 611543080941035521,
  "created_at" : "2015-06-18 14:36:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mrgunn",
      "screen_name" : "mrgunn",
      "indices" : [ 0, 7 ],
      "id_str" : "15237935",
      "id" : 15237935
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "611541922063101954",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17223324745419, 8.627616738013408 ]
  },
  "id_str" : "611542998195830785",
  "in_reply_to_user_id" : 15237935,
  "text" : "@mrgunn I blame Kary Mullis for being an inspiration to that ;)",
  "id" : 611542998195830785,
  "in_reply_to_status_id" : 611541922063101954,
  "created_at" : "2015-06-18 14:36:27 +0000",
  "in_reply_to_screen_name" : "mrgunn",
  "in_reply_to_user_id_str" : "15237935",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 14, 20 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "611536971773644800",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17226302055589, 8.627583374835362 ]
  },
  "id_str" : "611538419840360448",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @Lobot if I ever get a Nobel I\u2019ll invest all the prize money into this!",
  "id" : 611538419840360448,
  "in_reply_to_status_id" : 611536971773644800,
  "created_at" : "2015-06-18 14:18:15 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/Nar4X3mkC2",
      "expanded_url" : "http:\/\/big.assets.huffingtonpost.com\/drumming.gif",
      "display_url" : "big.assets.huffingtonpost.com\/drumming.gif"
    } ]
  },
  "in_reply_to_status_id_str" : "611532351441633280",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17225748655368, 8.6275665145717 ]
  },
  "id_str" : "611533700124254208",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer btw. welcome back, you have a huge email backlog to work through http:\/\/t.co\/Nar4X3mkC2 :D",
  "id" : 611533700124254208,
  "in_reply_to_status_id" : 611532351441633280,
  "created_at" : "2015-06-18 13:59:30 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 14, 20 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 62 ],
      "url" : "http:\/\/t.co\/XgeXs7PHbP",
      "expanded_url" : "http:\/\/i.imgur.com\/sYP3Lhr.gif",
      "display_url" : "i.imgur.com\/sYP3Lhr.gif"
    } ]
  },
  "in_reply_to_status_id_str" : "611532351441633280",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17225748655368, 8.6275665145717 ]
  },
  "id_str" : "611533287174086657",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @Lobot still would prefer http:\/\/t.co\/XgeXs7PHbP",
  "id" : 611533287174086657,
  "in_reply_to_status_id" : 611532351441633280,
  "created_at" : "2015-06-18 13:57:52 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "611529390825033728",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17225305425754, 8.627604985314969 ]
  },
  "id_str" : "611532647181983744",
  "in_reply_to_user_id" : 14286491,
  "text" : "But having roomies saying \u00ABI\u2019d be so sad if he was detained. I\u2019m the one who\u2019s in charge of getting locked up in this household\u00BB is fun too.",
  "id" : 611532647181983744,
  "in_reply_to_status_id" : 611529390825033728,
  "created_at" : "2015-06-18 13:55:19 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 39 ],
      "url" : "http:\/\/t.co\/CtwNEDAn1k",
      "expanded_url" : "http:\/\/photos.capturemyvermont.com\/photos\/NtT1rOOcTHKhedOUrfzQYw\/showcase.jpg",
      "display_url" : "photos.capturemyvermont.com\/photos\/NtT1rOO\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "611530679327789057",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17225748655368, 8.6275665145717 ]
  },
  "id_str" : "611531470096699393",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot to create http:\/\/t.co\/CtwNEDAn1k",
  "id" : 611531470096699393,
  "in_reply_to_status_id" : 611530679327789057,
  "created_at" : "2015-06-18 13:50:38 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "611530142037471232",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17225305425754, 8.627604985314969 ]
  },
  "id_str" : "611530539707797504",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot using non-water-resistant paint? ;)",
  "id" : 611530539707797504,
  "in_reply_to_status_id" : 611530142037471232,
  "created_at" : "2015-06-18 13:46:57 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 64 ],
      "url" : "http:\/\/t.co\/rmwSIlOZTl",
      "expanded_url" : "http:\/\/boingboing.net\/2015\/06\/17\/owner-of-relentless-gay-ya.html",
      "display_url" : "boingboing.net\/2015\/06\/17\/own\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722316250741, 8.627613198356437 ]
  },
  "id_str" : "611529390825033728",
  "text" : "damn, I wish my yard was relentlessly gay http:\/\/t.co\/rmwSIlOZTl",
  "id" : 611529390825033728,
  "created_at" : "2015-06-18 13:42:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Loman",
      "screen_name" : "pathogenomenick",
      "indices" : [ 3, 19 ],
      "id_str" : "85906238",
      "id" : 85906238
    }, {
      "name" : "David W. Cleary",
      "screen_name" : "Bacterioskeptic",
      "indices" : [ 34, 50 ],
      "id_str" : "131921069",
      "id" : 131921069
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/pathogenomenick\/status\/611527122553802752\/photo\/1",
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/x6sT9b5RPY",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CHyUrVmUAAI35Yy.jpg",
      "id_str" : "611527121668669442",
      "id" : 611527121668669442,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHyUrVmUAAI35Yy.jpg",
      "sizes" : [ {
        "h" : 456,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 805,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1374,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 2480,
        "resize" : "fit",
        "w" : 3696
      } ],
      "display_url" : "pic.twitter.com\/x6sT9b5RPY"
    } ],
    "hashtags" : [ {
      "text" : "IDRNgenomics",
      "indices" : [ 76, 89 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "611527337146994688",
  "text" : "RT @pathogenomenick: No thanks to @Bacterioskeptic for this little number:  #IDRNgenomics http:\/\/t.co\/x6sT9b5RPY",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "David W. Cleary",
        "screen_name" : "Bacterioskeptic",
        "indices" : [ 13, 29 ],
        "id_str" : "131921069",
        "id" : 131921069
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/pathogenomenick\/status\/611527122553802752\/photo\/1",
        "indices" : [ 69, 91 ],
        "url" : "http:\/\/t.co\/x6sT9b5RPY",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CHyUrVmUAAI35Yy.jpg",
        "id_str" : "611527121668669442",
        "id" : 611527121668669442,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHyUrVmUAAI35Yy.jpg",
        "sizes" : [ {
          "h" : 456,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 805,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1374,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 2480,
          "resize" : "fit",
          "w" : 3696
        } ],
        "display_url" : "pic.twitter.com\/x6sT9b5RPY"
      } ],
      "hashtags" : [ {
        "text" : "IDRNgenomics",
        "indices" : [ 55, 68 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "611527122553802752",
    "text" : "No thanks to @Bacterioskeptic for this little number:  #IDRNgenomics http:\/\/t.co\/x6sT9b5RPY",
    "id" : 611527122553802752,
    "created_at" : "2015-06-18 13:33:22 +0000",
    "user" : {
      "name" : "Nick Loman",
      "screen_name" : "pathogenomenick",
      "protected" : false,
      "id_str" : "85906238",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/654948428951195648\/i5lt2BWa_normal.jpg",
      "id" : 85906238,
      "verified" : false
    }
  },
  "id" : 611527337146994688,
  "created_at" : "2015-06-18 13:34:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Atlas Obscura",
      "screen_name" : "atlasobscura",
      "indices" : [ 3, 16 ],
      "id_str" : "57047586",
      "id" : 57047586
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/cohQvaBb79",
      "expanded_url" : "http:\/\/www.atlasobscura.com\/articles\/i-made-a-linguistics-professor-listen-to-a-blink-182-song-and-analyze-the-accent",
      "display_url" : "atlasobscura.com\/articles\/i-mad\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "611526113412689921",
  "text" : "RT @atlasobscura: Linguists analyzed the strange, whiny pop punk accent of the '90s and it's fascinating http:\/\/t.co\/cohQvaBb79 http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/atlasobscura\/status\/611520918448271360\/photo\/1",
        "indices" : [ 110, 132 ],
        "url" : "http:\/\/t.co\/EgqtFEJsgq",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CHyO9VoWsAAzv41.jpg",
        "id_str" : "611520833845112832",
        "id" : 611520833845112832,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHyO9VoWsAAzv41.jpg",
        "sizes" : [ {
          "h" : 680,
          "resize" : "fit",
          "w" : 611
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 690
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 690
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 690
        } ],
        "display_url" : "pic.twitter.com\/EgqtFEJsgq"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 87, 109 ],
        "url" : "http:\/\/t.co\/cohQvaBb79",
        "expanded_url" : "http:\/\/www.atlasobscura.com\/articles\/i-made-a-linguistics-professor-listen-to-a-blink-182-song-and-analyze-the-accent",
        "display_url" : "atlasobscura.com\/articles\/i-mad\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "611520918448271360",
    "text" : "Linguists analyzed the strange, whiny pop punk accent of the '90s and it's fascinating http:\/\/t.co\/cohQvaBb79 http:\/\/t.co\/EgqtFEJsgq",
    "id" : 611520918448271360,
    "created_at" : "2015-06-18 13:08:43 +0000",
    "user" : {
      "name" : "Atlas Obscura",
      "screen_name" : "atlasobscura",
      "protected" : false,
      "id_str" : "57047586",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/861608340899729410\/J8SxzXcX_normal.jpg",
      "id" : 57047586,
      "verified" : true
    }
  },
  "id" : 611526113412689921,
  "created_at" : "2015-06-18 13:29:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Madeleine Price Ball",
      "screen_name" : "madprime",
      "indices" : [ 3, 12 ],
      "id_str" : "71557700",
      "id" : 71557700
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 14, 30 ],
      "id_str" : "14286491",
      "id" : 14286491
    }, {
      "name" : "beau",
      "screen_name" : "beaugunderson",
      "indices" : [ 31, 45 ],
      "id_str" : "5746882",
      "id" : 5746882
    }, {
      "name" : "Chris Ball",
      "screen_name" : "cjbprime",
      "indices" : [ 46, 55 ],
      "id_str" : "41779829",
      "id" : 41779829
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "611523559521914880",
  "text" : "RT @madprime: @gedankenstuecke @beaugunderson @cjbprime memories fuzzy &amp; distant past; suspect word was more \"same sex\" w\/ less marriage eq\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 0, 16 ],
        "id_str" : "14286491",
        "id" : 14286491
      }, {
        "name" : "beau",
        "screen_name" : "beaugunderson",
        "indices" : [ 17, 31 ],
        "id_str" : "5746882",
        "id" : 5746882
      }, {
        "name" : "Chris Ball",
        "screen_name" : "cjbprime",
        "indices" : [ 32, 41 ],
        "id_str" : "41779829",
        "id" : 41779829
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "611518528852787200",
    "geo" : { },
    "id_str" : "611520309376753664",
    "in_reply_to_user_id" : 71557700,
    "text" : "@gedankenstuecke @beaugunderson @cjbprime memories fuzzy &amp; distant past; suspect word was more \"same sex\" w\/ less marriage equality 10y ago",
    "id" : 611520309376753664,
    "in_reply_to_status_id" : 611518528852787200,
    "created_at" : "2015-06-18 13:06:17 +0000",
    "in_reply_to_screen_name" : "madprime",
    "in_reply_to_user_id_str" : "71557700",
    "user" : {
      "name" : "Madeleine Price Ball",
      "screen_name" : "madprime",
      "protected" : false,
      "id_str" : "71557700",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/515539302931910656\/9N7oFHFZ_normal.png",
      "id" : 71557700,
      "verified" : false
    }
  },
  "id" : 611523559521914880,
  "created_at" : "2015-06-18 13:19:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17224679556752, 8.62760005361982 ]
  },
  "id_str" : "611523435869700096",
  "text" : "\u00ABLook, they are doing a TV interview in the lab over there!\u201D \u2013 \u00ABHow do you know?\u00BB \u2013 \u00ABEveryone\u2019s wearing lab coats all of a sudden.\u00BB",
  "id" : 611523435869700096,
  "created_at" : "2015-06-18 13:18:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Madeleine Price Ball",
      "screen_name" : "madprime",
      "indices" : [ 0, 9 ],
      "id_str" : "71557700",
      "id" : 71557700
    }, {
      "name" : "beau",
      "screen_name" : "beaugunderson",
      "indices" : [ 10, 24 ],
      "id_str" : "5746882",
      "id" : 5746882
    }, {
      "name" : "Chris Ball",
      "screen_name" : "cjbprime",
      "indices" : [ 25, 34 ],
      "id_str" : "41779829",
      "id" : 41779829
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "611518528852787200",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17224679556752, 8.62760005361982 ]
  },
  "id_str" : "611522701837107200",
  "in_reply_to_user_id" : 71557700,
  "text" : "@madprime @beaugunderson @cjbprime &amp; \u201Cpartner\u201D brings the benefit that you can describe a \u201Cparliament of partners\u201D, which has a nice ring ;)",
  "id" : 611522701837107200,
  "in_reply_to_status_id" : 611518528852787200,
  "created_at" : "2015-06-18 13:15:48 +0000",
  "in_reply_to_screen_name" : "madprime",
  "in_reply_to_user_id_str" : "71557700",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Madeleine Price Ball",
      "screen_name" : "madprime",
      "indices" : [ 0, 9 ],
      "id_str" : "71557700",
      "id" : 71557700
    }, {
      "name" : "beau",
      "screen_name" : "beaugunderson",
      "indices" : [ 10, 24 ],
      "id_str" : "5746882",
      "id" : 5746882
    }, {
      "name" : "Chris Ball",
      "screen_name" : "cjbprime",
      "indices" : [ 25, 34 ],
      "id_str" : "41779829",
      "id" : 41779829
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "611520309376753664",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17223169563765, 8.627585115228472 ]
  },
  "id_str" : "611520604966154240",
  "in_reply_to_user_id" : 71557700,
  "text" : "@madprime @beaugunderson @cjbprime yes, to me it already feels pretty neutral. :-) While the german equivalents are still gendered.",
  "id" : 611520604966154240,
  "in_reply_to_status_id" : 611520309376753664,
  "created_at" : "2015-06-18 13:07:28 +0000",
  "in_reply_to_screen_name" : "madprime",
  "in_reply_to_user_id_str" : "71557700",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Madeleine Price Ball",
      "screen_name" : "madprime",
      "indices" : [ 0, 9 ],
      "id_str" : "71557700",
      "id" : 71557700
    }, {
      "name" : "beau",
      "screen_name" : "beaugunderson",
      "indices" : [ 10, 24 ],
      "id_str" : "5746882",
      "id" : 5746882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "611516434909409280",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722088694769, 8.627622420079629 ]
  },
  "id_str" : "611517830102679552",
  "in_reply_to_user_id" : 71557700,
  "text" : "@madprime @beaugunderson good points too! Now wondering whether there are good gender-neutral equivalents for spouse\/partner in German.",
  "id" : 611517830102679552,
  "in_reply_to_status_id" : 611516434909409280,
  "created_at" : "2015-06-18 12:56:26 +0000",
  "in_reply_to_screen_name" : "madprime",
  "in_reply_to_user_id_str" : "71557700",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Madeleine Price Ball",
      "screen_name" : "madprime",
      "indices" : [ 3, 12 ],
      "id_str" : "71557700",
      "id" : 71557700
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 14, 30 ],
      "id_str" : "14286491",
      "id" : 14286491
    }, {
      "name" : "beau",
      "screen_name" : "beaugunderson",
      "indices" : [ 31, 45 ],
      "id_str" : "5746882",
      "id" : 5746882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "611517140362002432",
  "text" : "RT @madprime: @gedankenstuecke @beaugunderson I also like \"spouse\" instead of \"husband\" or \"wife\", \"parent\" instead of mother\/mom\/mum\/fathe\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 0, 16 ],
        "id_str" : "14286491",
        "id" : 14286491
      }, {
        "name" : "beau",
        "screen_name" : "beaugunderson",
        "indices" : [ 17, 31 ],
        "id_str" : "5746882",
        "id" : 5746882
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "611424423669813249",
    "geo" : { },
    "id_str" : "611516434909409280",
    "in_reply_to_user_id" : 14286491,
    "text" : "@gedankenstuecke @beaugunderson I also like \"spouse\" instead of \"husband\" or \"wife\", \"parent\" instead of mother\/mom\/mum\/father\/dad",
    "id" : 611516434909409280,
    "in_reply_to_status_id" : 611424423669813249,
    "created_at" : "2015-06-18 12:50:54 +0000",
    "in_reply_to_screen_name" : "gedankenstuecke",
    "in_reply_to_user_id_str" : "14286491",
    "user" : {
      "name" : "Madeleine Price Ball",
      "screen_name" : "madprime",
      "protected" : false,
      "id_str" : "71557700",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/515539302931910656\/9N7oFHFZ_normal.png",
      "id" : 71557700,
      "verified" : false
    }
  },
  "id" : 611517140362002432,
  "created_at" : "2015-06-18 12:53:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gideon Lichfield",
      "screen_name" : "glichfield",
      "indices" : [ 3, 14 ],
      "id_str" : "17285007",
      "id" : 17285007
    }, {
      "name" : "Akshat Rathi",
      "screen_name" : "AkshatRathi",
      "indices" : [ 16, 28 ],
      "id_str" : "13766492",
      "id" : 13766492
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/zBT1jx1YVc",
      "expanded_url" : "http:\/\/qz.com\/430415",
      "display_url" : "qz.com\/430415"
    } ]
  },
  "geo" : { },
  "id_str" : "611507424793595905",
  "text" : "RT @glichfield: @akshatrathi spent a year sleeping just 4.5 hours in every 24. Here's how he did it http:\/\/t.co\/zBT1jx1YVc",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Akshat Rathi",
        "screen_name" : "AkshatRathi",
        "indices" : [ 0, 12 ],
        "id_str" : "13766492",
        "id" : 13766492
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 84, 106 ],
        "url" : "http:\/\/t.co\/zBT1jx1YVc",
        "expanded_url" : "http:\/\/qz.com\/430415",
        "display_url" : "qz.com\/430415"
      } ]
    },
    "geo" : { },
    "id_str" : "611504636680347648",
    "in_reply_to_user_id" : 13766492,
    "text" : "@akshatrathi spent a year sleeping just 4.5 hours in every 24. Here's how he did it http:\/\/t.co\/zBT1jx1YVc",
    "id" : 611504636680347648,
    "created_at" : "2015-06-18 12:04:01 +0000",
    "in_reply_to_screen_name" : "AkshatRathi",
    "in_reply_to_user_id_str" : "13766492",
    "user" : {
      "name" : "Gideon Lichfield",
      "screen_name" : "glichfield",
      "protected" : false,
      "id_str" : "17285007",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/931888038669582339\/vnYrjrdz_normal.jpg",
      "id" : 17285007,
      "verified" : true
    }
  },
  "id" : 611507424793595905,
  "created_at" : "2015-06-18 12:15:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Taylor",
      "screen_name" : "DrJohnLTaylor",
      "indices" : [ 3, 17 ],
      "id_str" : "92386305",
      "id" : 92386305
    }, {
      "name" : "John Tasioulas",
      "screen_name" : "JTasioulas",
      "indices" : [ 89, 100 ],
      "id_str" : "707463510",
      "id" : 707463510
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/IN4kP0FMdj",
      "expanded_url" : "https:\/\/twitter.com\/JTasioulas\/status\/611158184816967680",
      "display_url" : "twitter.com\/JTasioulas\/sta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "611500367046680577",
  "text" : "RT @DrJohnLTaylor: 'One best learns philosophy by doing it' &lt; YES\n(James Griffin) via @JTasioulas  https:\/\/t.co\/IN4kP0FMdj",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "John Tasioulas",
        "screen_name" : "JTasioulas",
        "indices" : [ 70, 81 ],
        "id_str" : "707463510",
        "id" : 707463510
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 83, 106 ],
        "url" : "https:\/\/t.co\/IN4kP0FMdj",
        "expanded_url" : "https:\/\/twitter.com\/JTasioulas\/status\/611158184816967680",
        "display_url" : "twitter.com\/JTasioulas\/sta\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "611256198608887809",
    "text" : "'One best learns philosophy by doing it' &lt; YES\n(James Griffin) via @JTasioulas  https:\/\/t.co\/IN4kP0FMdj",
    "id" : 611256198608887809,
    "created_at" : "2015-06-17 19:36:48 +0000",
    "user" : {
      "name" : "John Taylor",
      "screen_name" : "DrJohnLTaylor",
      "protected" : false,
      "id_str" : "92386305",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/783262920352395264\/6eAzIJSt_normal.jpg",
      "id" : 92386305,
      "verified" : false
    }
  },
  "id" : 611500367046680577,
  "created_at" : "2015-06-18 11:47:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Torsten Seemann",
      "screen_name" : "torstenseemann",
      "indices" : [ 0, 15 ],
      "id_str" : "42558652",
      "id" : 42558652
    }, {
      "name" : "Mick Watson",
      "screen_name" : "BioMickWatson",
      "indices" : [ 16, 30 ],
      "id_str" : "228586748",
      "id" : 228586748
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "611495017622863872",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17224221929429, 8.627600118393715 ]
  },
  "id_str" : "611495493106057216",
  "in_reply_to_user_id" : 42558652,
  "text" : "@torstenseemann @BioMickWatson I think you wanted to say \u201Cis inversely correlated to the JIF\u2026\u201D ;-)",
  "id" : 611495493106057216,
  "in_reply_to_status_id" : 611495017622863872,
  "created_at" : "2015-06-18 11:27:41 +0000",
  "in_reply_to_screen_name" : "torstenseemann",
  "in_reply_to_user_id_str" : "42558652",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mick Watson",
      "screen_name" : "BioMickWatson",
      "indices" : [ 0, 14 ],
      "id_str" : "228586748",
      "id" : 228586748
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/SYZiqAbKj1",
      "expanded_url" : "http:\/\/shawnhymel.com\/portfolio\/413\/",
      "display_url" : "shawnhymel.com\/portfolio\/413\/"
    } ]
  },
  "in_reply_to_status_id_str" : "611450136267497472",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17249028003573, 8.627540445632347 ]
  },
  "id_str" : "611464640082640896",
  "in_reply_to_user_id" : 228586748,
  "text" : "@BioMickWatson Hidden Markov Models were initially developed to find Waldo http:\/\/t.co\/SYZiqAbKj1",
  "id" : 611464640082640896,
  "in_reply_to_status_id" : 611450136267497472,
  "created_at" : "2015-06-18 09:25:05 +0000",
  "in_reply_to_screen_name" : "BioMickWatson",
  "in_reply_to_user_id_str" : "228586748",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ian Goodhead",
      "screen_name" : "IanGoodhead",
      "indices" : [ 0, 12 ],
      "id_str" : "223669139",
      "id" : 223669139
    }, {
      "name" : "Mick Watson",
      "screen_name" : "BioMickWatson",
      "indices" : [ 13, 27 ],
      "id_str" : "228586748",
      "id" : 228586748
    }, {
      "name" : "PacBio",
      "screen_name" : "PacBio",
      "indices" : [ 32, 39 ],
      "id_str" : "39694489",
      "id" : 39694489
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "611453825304653824",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17246282488093, 8.627573074004466 ]
  },
  "id_str" : "611457650564464640",
  "in_reply_to_user_id" : 223669139,
  "text" : "@IanGoodhead @BioMickWatson The @PacBio machines are so large because inside\u2019s an Illumina machine + a bioinformatician running assemblies.",
  "id" : 611457650564464640,
  "in_reply_to_status_id" : 611453825304653824,
  "created_at" : "2015-06-18 08:57:18 +0000",
  "in_reply_to_screen_name" : "IanGoodhead",
  "in_reply_to_user_id_str" : "223669139",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mick Watson",
      "screen_name" : "BioMickWatson",
      "indices" : [ 3, 17 ],
      "id_str" : "228586748",
      "id" : 228586748
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/rcFbXeINbI",
      "expanded_url" : "https:\/\/biomickwatson.wordpress.com\/2015\/06\/18\/101-bioinformatics-facts\/",
      "display_url" : "biomickwatson.wordpress.com\/2015\/06\/18\/101\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "611457039508852736",
  "text" : "RT @BioMickWatson: I am trying to crowd-source 101 fun bioinformatics facts. Please contribute! https:\/\/t.co\/rcFbXeINbI",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 77, 100 ],
        "url" : "https:\/\/t.co\/rcFbXeINbI",
        "expanded_url" : "https:\/\/biomickwatson.wordpress.com\/2015\/06\/18\/101-bioinformatics-facts\/",
        "display_url" : "biomickwatson.wordpress.com\/2015\/06\/18\/101\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "611450136267497472",
    "text" : "I am trying to crowd-source 101 fun bioinformatics facts. Please contribute! https:\/\/t.co\/rcFbXeINbI",
    "id" : 611450136267497472,
    "created_at" : "2015-06-18 08:27:27 +0000",
    "user" : {
      "name" : "Mick Watson",
      "screen_name" : "BioMickWatson",
      "protected" : false,
      "id_str" : "228586748",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/870214569679093760\/YIZGIDTS_normal.jpg",
      "id" : 228586748,
      "verified" : false
    }
  },
  "id" : 611457039508852736,
  "created_at" : "2015-06-18 08:54:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/611451769596563457\/photo\/1",
      "indices" : [ 23, 45 ],
      "url" : "http:\/\/t.co\/zPfgzU9c96",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CHxQJQ-WgAAXsn6.jpg",
      "id_str" : "611451769521078272",
      "id" : 611451769521078272,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHxQJQ-WgAAXsn6.jpg",
      "sizes" : [ {
        "h" : 1086,
        "resize" : "fit",
        "w" : 815
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      }, {
        "h" : 1086,
        "resize" : "fit",
        "w" : 815
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1086,
        "resize" : "fit",
        "w" : 815
      } ],
      "display_url" : "pic.twitter.com\/zPfgzU9c96"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "611451769596563457",
  "text" : "Feminist Propaganda +1 http:\/\/t.co\/zPfgzU9c96",
  "id" : 611451769596563457,
  "created_at" : "2015-06-18 08:33:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 74, 87 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/PykNn6mD74",
      "expanded_url" : "http:\/\/journals.plos.org\/plosone\/article?id=10.1371\/journal.pone.0128254",
      "display_url" : "journals.plos.org\/plosone\/articl\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "611434467144691712",
  "text" : "Languages with More Non-Native Speakers Tend to Have Fewer Word Forms \/cc @PhilippBayer  http:\/\/t.co\/PykNn6mD74",
  "id" : 611434467144691712,
  "created_at" : "2015-06-18 07:25:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "beau",
      "screen_name" : "beaugunderson",
      "indices" : [ 0, 14 ],
      "id_str" : "5746882",
      "id" : 5746882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "611355919188824064",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17225520914884, 8.627586023882627 ]
  },
  "id_str" : "611424423669813249",
  "in_reply_to_user_id" : 5746882,
  "text" : "@beaugunderson what about \u201Cpartner\u201D as replacement for \u201Cgirlfriend\u201D?",
  "id" : 611424423669813249,
  "in_reply_to_status_id" : 611355919188824064,
  "created_at" : "2015-06-18 06:45:16 +0000",
  "in_reply_to_screen_name" : "beaugunderson",
  "in_reply_to_user_id_str" : "5746882",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "beau",
      "screen_name" : "beaugunderson",
      "indices" : [ 3, 17 ],
      "id_str" : "5746882",
      "id" : 5746882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "611424287740821504",
  "text" : "RT @beaugunderson: i wrote about my own journey to use more inclusive language, it's called \"things i've stopped saying\": https:\/\/t.co\/1MrP\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 103, 126 ],
        "url" : "https:\/\/t.co\/1MrPB7UfPy",
        "expanded_url" : "https:\/\/medium.com\/@beaugunderson\/things-i-ve-stopped-saying-fa7dea0bf317",
        "display_url" : "medium.com\/@beaugunderson\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "611355919188824064",
    "text" : "i wrote about my own journey to use more inclusive language, it's called \"things i've stopped saying\": https:\/\/t.co\/1MrPB7UfPy",
    "id" : 611355919188824064,
    "created_at" : "2015-06-18 02:13:04 +0000",
    "user" : {
      "name" : "beau",
      "screen_name" : "beaugunderson",
      "protected" : false,
      "id_str" : "5746882",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/913840034016399360\/pU3IIxqf_normal.jpg",
      "id" : 5746882,
      "verified" : false
    }
  },
  "id" : 611424287740821504,
  "created_at" : "2015-06-18 06:44:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ToxX",
      "screen_name" : "ToxXInFlames",
      "indices" : [ 0, 13 ],
      "id_str" : "1421360166",
      "id" : 1421360166
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "611296507195736064",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11407147249258, 8.75339049755272 ]
  },
  "id_str" : "611297017973878785",
  "in_reply_to_user_id" : 1421360166,
  "text" : "@ToxXInFlames back-on-the-envelope-calc w\/ my calendar: this year I was in the office for ~2\/3 of all workdays so far. -&gt; 4.4 coffee\/day.",
  "id" : 611297017973878785,
  "in_reply_to_status_id" : 611296507195736064,
  "created_at" : "2015-06-17 22:19:01 +0000",
  "in_reply_to_screen_name" : "ToxXInFlames",
  "in_reply_to_user_id_str" : "1421360166",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ToxX",
      "screen_name" : "ToxXInFlames",
      "indices" : [ 0, 13 ],
      "id_str" : "1421360166",
      "id" : 1421360166
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "611294212714287104",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11407137816177, 8.753391157512732 ]
  },
  "id_str" : "611294930489712642",
  "in_reply_to_user_id" : 1421360166,
  "text" : "@ToxXInFlames think the actual daily number is higher, due to lots of days not spent in office.",
  "id" : 611294930489712642,
  "in_reply_to_status_id" : 611294212714287104,
  "created_at" : "2015-06-17 22:10:43 +0000",
  "in_reply_to_screen_name" : "ToxXInFlames",
  "in_reply_to_user_id_str" : "1421360166",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrick Rauscher",
      "screen_name" : "prauscher",
      "indices" : [ 0, 10 ],
      "id_str" : "74155696",
      "id" : 74155696
    }, {
      "name" : "Jonas",
      "screen_name" : "lsanoj",
      "indices" : [ 11, 18 ],
      "id_str" : "18918915",
      "id" : 18918915
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "611283187759742977",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11407184964779, 8.753390964018047 ]
  },
  "id_str" : "611283276335067138",
  "in_reply_to_user_id" : 74155696,
  "text" : "@prauscher @lsanoj so gerade noch mal die Pfadfinder-Ehre gerettet, eh? :D",
  "id" : 611283276335067138,
  "in_reply_to_status_id" : 611283187759742977,
  "created_at" : "2015-06-17 21:24:24 +0000",
  "in_reply_to_screen_name" : "prauscher",
  "in_reply_to_user_id_str" : "74155696",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrick Rauscher",
      "screen_name" : "prauscher",
      "indices" : [ 0, 10 ],
      "id_str" : "74155696",
      "id" : 74155696
    }, {
      "name" : "Jonas",
      "screen_name" : "lsanoj",
      "indices" : [ 11, 18 ],
      "id_str" : "18918915",
      "id" : 18918915
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "611282628117950464",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11407184964779, 8.753390964018047 ]
  },
  "id_str" : "611282843977838593",
  "in_reply_to_user_id" : 74155696,
  "text" : "@prauscher @lsanoj gas-trangias?! du bist ja pervers!",
  "id" : 611282843977838593,
  "in_reply_to_status_id" : 611282628117950464,
  "created_at" : "2015-06-17 21:22:41 +0000",
  "in_reply_to_screen_name" : "prauscher",
  "in_reply_to_user_id_str" : "74155696",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Austin Richardson",
      "screen_name" : "heyaudy",
      "indices" : [ 0, 8 ],
      "id_str" : "14534523",
      "id" : 14534523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "611176070373605376",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17221659167075, 8.627595105392505 ]
  },
  "id_str" : "611176222563901440",
  "in_reply_to_user_id" : 14534523,
  "text" : "@heyaudy yeah, I am! :)",
  "id" : 611176222563901440,
  "in_reply_to_status_id" : 611176070373605376,
  "created_at" : "2015-06-17 14:19:01 +0000",
  "in_reply_to_screen_name" : "heyaudy",
  "in_reply_to_user_id_str" : "14534523",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Austin Richardson",
      "screen_name" : "heyaudy",
      "indices" : [ 0, 8 ],
      "id_str" : "14534523",
      "id" : 14534523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "611169645790384128",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17233593438849, 8.627532249424563 ]
  },
  "id_str" : "611175721571106816",
  "in_reply_to_user_id" : 14534523,
  "text" : "@heyaudy nope, see comment :)",
  "id" : 611175721571106816,
  "in_reply_to_status_id" : 611169645790384128,
  "created_at" : "2015-06-17 14:17:01 +0000",
  "in_reply_to_screen_name" : "heyaudy",
  "in_reply_to_user_id_str" : "14534523",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Austin Richardson",
      "screen_name" : "heyaudy",
      "indices" : [ 0, 8 ],
      "id_str" : "14534523",
      "id" : 14534523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "611168357572825088",
  "geo" : { },
  "id_str" : "611168567560638465",
  "in_reply_to_user_id" : 14534523,
  "text" : "@heyaudy yes!",
  "id" : 611168567560638465,
  "in_reply_to_status_id" : 611168357572825088,
  "created_at" : "2015-06-17 13:48:36 +0000",
  "in_reply_to_screen_name" : "heyaudy",
  "in_reply_to_user_id_str" : "14534523",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/611165205683421184\/photo\/1",
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/FMJbqTDp1z",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CHtLg_gWIAE80s2.png",
      "id_str" : "611165204613832705",
      "id" : 611165204613832705,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHtLg_gWIAE80s2.png",
      "sizes" : [ {
        "h" : 750,
        "resize" : "fit",
        "w" : 951
      }, {
        "h" : 750,
        "resize" : "fit",
        "w" : 951
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 750,
        "resize" : "fit",
        "w" : 951
      }, {
        "h" : 536,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/FMJbqTDp1z"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17217221102666, 8.627656207273224 ]
  },
  "id_str" : "611165205683421184",
  "text" : "It was hard work, but I made it to #1 of the intra-office coffee drinking competition! http:\/\/t.co\/FMJbqTDp1z",
  "id" : 611165205683421184,
  "created_at" : "2015-06-17 13:35:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shit Academics Say",
      "screen_name" : "AcademicsSay",
      "indices" : [ 3, 16 ],
      "id_str" : "1891806212",
      "id" : 1891806212
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/AcademicsSay\/status\/611160661121306625\/photo\/1",
      "indices" : [ 18, 40 ],
      "url" : "http:\/\/t.co\/gwqMeflc0x",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CHtHYQPVAAEpMmc.jpg",
      "id_str" : "611160656440524801",
      "id" : 611160656440524801,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHtHYQPVAAEpMmc.jpg",
      "sizes" : [ {
        "h" : 516,
        "resize" : "fit",
        "w" : 918
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 382,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 516,
        "resize" : "fit",
        "w" : 918
      }, {
        "h" : 516,
        "resize" : "fit",
        "w" : 918
      } ],
      "display_url" : "pic.twitter.com\/gwqMeflc0x"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "611161107735166976",
  "text" : "RT @AcademicsSay: http:\/\/t.co\/gwqMeflc0x",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/AcademicsSay\/status\/611160661121306625\/photo\/1",
        "indices" : [ 0, 22 ],
        "url" : "http:\/\/t.co\/gwqMeflc0x",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CHtHYQPVAAEpMmc.jpg",
        "id_str" : "611160656440524801",
        "id" : 611160656440524801,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHtHYQPVAAEpMmc.jpg",
        "sizes" : [ {
          "h" : 516,
          "resize" : "fit",
          "w" : 918
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 382,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 516,
          "resize" : "fit",
          "w" : 918
        }, {
          "h" : 516,
          "resize" : "fit",
          "w" : 918
        } ],
        "display_url" : "pic.twitter.com\/gwqMeflc0x"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "611160661121306625",
    "text" : "http:\/\/t.co\/gwqMeflc0x",
    "id" : 611160661121306625,
    "created_at" : "2015-06-17 13:17:11 +0000",
    "user" : {
      "name" : "Shit Academics Say",
      "screen_name" : "AcademicsSay",
      "protected" : false,
      "id_str" : "1891806212",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/748151916836716546\/Ldn_dhiC_normal.jpg",
      "id" : 1891806212,
      "verified" : false
    }
  },
  "id" : 611161107735166976,
  "created_at" : "2015-06-17 13:18:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karl Urban",
      "screen_name" : "pikarl",
      "indices" : [ 0, 7 ],
      "id_str" : "12514272",
      "id" : 12514272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "611157721317048321",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17216518069106, 8.627654650693303 ]
  },
  "id_str" : "611157774689542144",
  "in_reply_to_user_id" : 12514272,
  "text" : "@pikarl okay, dann viel Spass beim lesen :)",
  "id" : 611157774689542144,
  "in_reply_to_status_id" : 611157721317048321,
  "created_at" : "2015-06-17 13:05:42 +0000",
  "in_reply_to_screen_name" : "pikarl",
  "in_reply_to_user_id_str" : "12514272",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karl Urban",
      "screen_name" : "pikarl",
      "indices" : [ 0, 7 ],
      "id_str" : "12514272",
      "id" : 12514272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "611154778958241792",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17216518069106, 8.627654650693303 ]
  },
  "id_str" : "611157459894464514",
  "in_reply_to_user_id" : 12514272,
  "text" : "@pikarl Adresse? :)",
  "id" : 611157459894464514,
  "in_reply_to_status_id" : 611154778958241792,
  "created_at" : "2015-06-17 13:04:27 +0000",
  "in_reply_to_screen_name" : "pikarl",
  "in_reply_to_user_id_str" : "12514272",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 34 ],
      "url" : "https:\/\/t.co\/NQyMBNitjg",
      "expanded_url" : "https:\/\/instagram.com\/p\/4B_rwjBwjY\/",
      "display_url" : "instagram.com\/p\/4B_rwjBwjY\/"
    } ]
  },
  "geo" : { },
  "id_str" : "611156544399523840",
  "text" : "Not Amused https:\/\/t.co\/NQyMBNitjg",
  "id" : 611156544399523840,
  "created_at" : "2015-06-17 13:00:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Austin Richardson",
      "screen_name" : "heyaudy",
      "indices" : [ 0, 8 ],
      "id_str" : "14534523",
      "id" : 14534523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 32 ],
      "url" : "https:\/\/t.co\/TsvQ0sLXlT",
      "expanded_url" : "https:\/\/gist.github.com\/gedankenstuecke\/f237566c2a154e1795b5",
      "display_url" : "gist.github.com\/gedankenstueck\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "611147210215006208",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17220338780062, 8.6276295413289 ]
  },
  "id_str" : "611155561707610113",
  "in_reply_to_user_id" : 14534523,
  "text" : "@heyaudy https:\/\/t.co\/TsvQ0sLXlT",
  "id" : 611155561707610113,
  "in_reply_to_status_id" : 611147210215006208,
  "created_at" : "2015-06-17 12:56:55 +0000",
  "in_reply_to_screen_name" : "heyaudy",
  "in_reply_to_user_id_str" : "14534523",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ciyer",
      "screen_name" : "ciyer",
      "indices" : [ 0, 6 ],
      "id_str" : "14533425",
      "id" : 14533425
    }, {
      "name" : "Paul-Olivier Dehaye",
      "screen_name" : "podehaye",
      "indices" : [ 7, 16 ],
      "id_str" : "2219841242",
      "id" : 2219841242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "611141295130677248",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17218888842541, 8.627622923728682 ]
  },
  "id_str" : "611142632820109312",
  "in_reply_to_user_id" : 14533425,
  "text" : "@ciyer @podehaye remains the same. Now I\u2019ll just hack around it. exporting the command into a bash-script which I will then call from bash\u2026",
  "id" : 611142632820109312,
  "in_reply_to_status_id" : 611141295130677248,
  "created_at" : "2015-06-17 12:05:32 +0000",
  "in_reply_to_screen_name" : "ciyer",
  "in_reply_to_user_id_str" : "14533425",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ciyer",
      "screen_name" : "ciyer",
      "indices" : [ 0, 6 ],
      "id_str" : "14533425",
      "id" : 14533425
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "611140088035196929",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17222715251862, 8.62759073018508 ]
  },
  "id_str" : "611140289516957696",
  "in_reply_to_user_id" : 14533425,
  "text" : "@ciyer nope, doing it in one go. But this worked for going from 23andMe to BED files. So assumed it should for merging data as well.",
  "id" : 611140289516957696,
  "in_reply_to_status_id" : 611140088035196929,
  "created_at" : "2015-06-17 11:56:14 +0000",
  "in_reply_to_screen_name" : "ciyer",
  "in_reply_to_user_id_str" : "14533425",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Open Culture",
      "screen_name" : "openculture",
      "indices" : [ 3, 15 ],
      "id_str" : "19826509",
      "id" : 19826509
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/lBDuyl1Xk9",
      "expanded_url" : "http:\/\/goo.gl\/U38G6H",
      "display_url" : "goo.gl\/U38G6H"
    } ]
  },
  "geo" : { },
  "id_str" : "611134984452239360",
  "text" : "RT @openculture: \"Blade Runner\" Recut with the Sci-Fi Masterpiece\u2019s Unused Original Footage. Check it out. http:\/\/t.co\/lBDuyl1Xk9 http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/openculture\/status\/610843214388400128\/photo\/1",
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/tVw4j1Dl1y",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CHommbUWoAAQzIZ.jpg",
        "id_str" : "610843141072134144",
        "id" : 610843141072134144,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHommbUWoAAQzIZ.jpg",
        "sizes" : [ {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 383,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/tVw4j1Dl1y"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 90, 112 ],
        "url" : "http:\/\/t.co\/lBDuyl1Xk9",
        "expanded_url" : "http:\/\/goo.gl\/U38G6H",
        "display_url" : "goo.gl\/U38G6H"
      } ]
    },
    "geo" : { },
    "id_str" : "610843214388400128",
    "text" : "\"Blade Runner\" Recut with the Sci-Fi Masterpiece\u2019s Unused Original Footage. Check it out. http:\/\/t.co\/lBDuyl1Xk9 http:\/\/t.co\/tVw4j1Dl1y",
    "id" : 610843214388400128,
    "created_at" : "2015-06-16 16:15:45 +0000",
    "user" : {
      "name" : "Open Culture",
      "screen_name" : "openculture",
      "protected" : false,
      "id_str" : "19826509",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/851645340830715904\/jrs1gcNM_normal.jpg",
      "id" : 19826509,
      "verified" : false
    }
  },
  "id" : 611134984452239360,
  "created_at" : "2015-06-17 11:35:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul-Olivier Dehaye",
      "screen_name" : "podehaye",
      "indices" : [ 0, 9 ],
      "id_str" : "2219841242",
      "id" : 2219841242
    }, {
      "name" : "ciyer",
      "screen_name" : "ciyer",
      "indices" : [ 10, 16 ],
      "id_str" : "14533425",
      "id" : 14533425
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "611127655342211073",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17219971978654, 8.6276413418062 ]
  },
  "id_str" : "611127827686158337",
  "in_reply_to_user_id" : 2219841242,
  "text" : "@podehaye @ciyer yes, version same, plinks starts but crashes for file not found. called from same path as directly on shell",
  "id" : 611127827686158337,
  "in_reply_to_status_id" : 611127655342211073,
  "created_at" : "2015-06-17 11:06:42 +0000",
  "in_reply_to_screen_name" : "podehaye",
  "in_reply_to_user_id_str" : "2219841242",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul-Olivier Dehaye",
      "screen_name" : "podehaye",
      "indices" : [ 0, 9 ],
      "id_str" : "2219841242",
      "id" : 2219841242
    }, {
      "name" : "ciyer",
      "screen_name" : "ciyer",
      "indices" : [ 10, 16 ],
      "id_str" : "14533425",
      "id" : 14533425
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "611126701377064961",
  "geo" : { },
  "id_str" : "611126912245702658",
  "in_reply_to_user_id" : 2219841242,
  "text" : "@podehaye @ciyer calling \u201C.\/plink \u2026\u201D, working on making the PCA reproducible ;)",
  "id" : 611126912245702658,
  "in_reply_to_status_id" : 611126701377064961,
  "created_at" : "2015-06-17 11:03:04 +0000",
  "in_reply_to_screen_name" : "podehaye",
  "in_reply_to_user_id_str" : "2219841242",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "J\u00FCrgen Geuter",
      "screen_name" : "tante",
      "indices" : [ 0, 6 ],
      "id_str" : "14179278",
      "id" : 14179278
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "611125860066848768",
  "geo" : { },
  "id_str" : "611126344420864000",
  "in_reply_to_user_id" : 14179278,
  "text" : "@tante I know\u2026 one day I will port everything to 3\u2026",
  "id" : 611126344420864000,
  "in_reply_to_status_id" : 611125860066848768,
  "created_at" : "2015-06-17 11:00:49 +0000",
  "in_reply_to_screen_name" : "tante",
  "in_reply_to_user_id_str" : "14179278",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "J\u00FCrgen Geuter",
      "screen_name" : "tante",
      "indices" : [ 0, 6 ],
      "id_str" : "14179278",
      "id" : 14179278
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "611125395472187394",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17221911116228, 8.62762302852897 ]
  },
  "id_str" : "611125487964934144",
  "in_reply_to_user_id" : 14179278,
  "text" : "@tante 2.7.8 (don\u2019t judge me!)",
  "id" : 611125487964934144,
  "in_reply_to_status_id" : 611125395472187394,
  "created_at" : "2015-06-17 10:57:25 +0000",
  "in_reply_to_screen_name" : "tante",
  "in_reply_to_user_id_str" : "14179278",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "J\u00FCrgen Geuter",
      "screen_name" : "tante",
      "indices" : [ 0, 6 ],
      "id_str" : "14179278",
      "id" : 14179278
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "611125205579235329",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17221911116228, 8.62762302852897 ]
  },
  "id_str" : "611125332092002304",
  "in_reply_to_user_id" : 14179278,
  "text" : "@tante thanks, will give that a try. :)",
  "id" : 611125332092002304,
  "in_reply_to_status_id" : 611125205579235329,
  "created_at" : "2015-06-17 10:56:47 +0000",
  "in_reply_to_screen_name" : "tante",
  "in_reply_to_user_id_str" : "14179278",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "J\u00FCrgen Geuter",
      "screen_name" : "tante",
      "indices" : [ 0, 6 ],
      "id_str" : "14179278",
      "id" : 14179278
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "611124715999109121",
  "geo" : { },
  "id_str" : "611124875357499392",
  "in_reply_to_user_id" : 14179278,
  "text" : "@tante nope. Just giving he cmd basically.",
  "id" : 611124875357499392,
  "in_reply_to_status_id" : 611124715999109121,
  "created_at" : "2015-06-17 10:54:59 +0000",
  "in_reply_to_screen_name" : "tante",
  "in_reply_to_user_id_str" : "14179278",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "J\u00FCrgen Geuter",
      "screen_name" : "tante",
      "indices" : [ 0, 6 ],
      "id_str" : "14179278",
      "id" : 14179278
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "611123905806401536",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17221911116228, 8.62762302852897 ]
  },
  "id_str" : "611124119250321408",
  "in_reply_to_user_id" : 14179278,
  "text" : "@tante the binary I\u2019m calling crashes w\/ \u201CFailed to open input\u2026\u201D yadayada, but input is there, works if called from same dir on shell.",
  "id" : 611124119250321408,
  "in_reply_to_status_id" : 611123905806401536,
  "created_at" : "2015-06-17 10:51:58 +0000",
  "in_reply_to_screen_name" : "tante",
  "in_reply_to_user_id_str" : "14179278",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17221911116228, 8.62762302852897 ]
  },
  "id_str" : "611123625182236672",
  "text" : "Ok, Pythonistas: what am I doing wrong if a command works fine on the shell but not if run in Python w\/ subprocess.call(\u2026,shell=True)?",
  "id" : 611123625182236672,
  "created_at" : "2015-06-17 10:50:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 54 ],
      "url" : "http:\/\/t.co\/QzygwOTXDU",
      "expanded_url" : "http:\/\/asofterworld.com\/index.php?id=644",
      "display_url" : "asofterworld.com\/index.php?id=6\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17222848345419, 8.62761000804167 ]
  },
  "id_str" : "611054134129725440",
  "text" : "why commuting by car is awesome http:\/\/t.co\/QzygwOTXDU",
  "id" : 611054134129725440,
  "created_at" : "2015-06-17 06:13:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Colorlines.com",
      "screen_name" : "Colorlines",
      "indices" : [ 3, 14 ],
      "id_str" : "22986148",
      "id" : 22986148
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/v6uvZ8bibK",
      "expanded_url" : "http:\/\/ow.ly\/Oot0M",
      "display_url" : "ow.ly\/Oot0M"
    } ]
  },
  "geo" : { },
  "id_str" : "610958326986317824",
  "text" : "RT @Colorlines: Only 74 Black Women Hold PhDs in Physics. This Young Woman Is Raising Money to Make it 75 http:\/\/t.co\/v6uvZ8bibK http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Colorlines\/status\/610829542580727808\/photo\/1",
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/t1JFZJbvzn",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CHoaO2YUAAA5aS4.jpg",
        "id_str" : "610829541880102912",
        "id" : 610829541880102912,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHoaO2YUAAA5aS4.jpg",
        "sizes" : [ {
          "h" : 420,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 420,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 420,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 420,
          "resize" : "fit",
          "w" : 640
        } ],
        "display_url" : "pic.twitter.com\/t1JFZJbvzn"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 90, 112 ],
        "url" : "http:\/\/t.co\/v6uvZ8bibK",
        "expanded_url" : "http:\/\/ow.ly\/Oot0M",
        "display_url" : "ow.ly\/Oot0M"
      } ]
    },
    "geo" : { },
    "id_str" : "610829542580727808",
    "text" : "Only 74 Black Women Hold PhDs in Physics. This Young Woman Is Raising Money to Make it 75 http:\/\/t.co\/v6uvZ8bibK http:\/\/t.co\/t1JFZJbvzn",
    "id" : 610829542580727808,
    "created_at" : "2015-06-16 15:21:26 +0000",
    "user" : {
      "name" : "Colorlines.com",
      "screen_name" : "Colorlines",
      "protected" : false,
      "id_str" : "22986148",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1766448192\/image1326986001_normal.png",
      "id" : 22986148,
      "verified" : false
    }
  },
  "id" : 610958326986317824,
  "created_at" : "2015-06-16 23:53:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul-Olivier Dehaye",
      "screen_name" : "podehaye",
      "indices" : [ 0, 9 ],
      "id_str" : "2219841242",
      "id" : 2219841242
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 10, 23 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "ciyer",
      "screen_name" : "ciyer",
      "indices" : [ 24, 30 ],
      "id_str" : "14533425",
      "id" : 14533425
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/610940566394806273\/photo\/1",
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/x948qA409f",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CHp_NPUWIAAvaoq.png",
      "id_str" : "610940564889018368",
      "id" : 610940564889018368,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHp_NPUWIAAvaoq.png",
      "sizes" : [ {
        "h" : 773,
        "resize" : "fit",
        "w" : 1398
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 773,
        "resize" : "fit",
        "w" : 1398
      }, {
        "h" : 376,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 664,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/x948qA409f"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "610939615701282816",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11407197481079, 8.753389429386546 ]
  },
  "id_str" : "610940566394806273",
  "in_reply_to_user_id" : 2219841242,
  "text" : "@podehaye @PhilippBayer @ciyer yes. and one last one: The X marks where my data set is hidden. ;-) http:\/\/t.co\/x948qA409f",
  "id" : 610940566394806273,
  "in_reply_to_status_id" : 610939615701282816,
  "created_at" : "2015-06-16 22:42:36 +0000",
  "in_reply_to_screen_name" : "podehaye",
  "in_reply_to_user_id_str" : "2219841242",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul-Olivier Dehaye",
      "screen_name" : "podehaye",
      "indices" : [ 0, 9 ],
      "id_str" : "2219841242",
      "id" : 2219841242
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 10, 23 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "ciyer",
      "screen_name" : "ciyer",
      "indices" : [ 24, 30 ],
      "id_str" : "14533425",
      "id" : 14533425
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/610936244479098880\/photo\/1",
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/0Mf7lfP2da",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CHp7RrgWsAAC7fi.png",
      "id_str" : "610936243128545280",
      "id" : 610936243128545280,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHp7RrgWsAAC7fi.png",
      "sizes" : [ {
        "h" : 773,
        "resize" : "fit",
        "w" : 1398
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 773,
        "resize" : "fit",
        "w" : 1398
      }, {
        "h" : 376,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 664,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/0Mf7lfP2da"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "610895861711671299",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11407213466512, 8.753390236022652 ]
  },
  "id_str" : "610936244479098880",
  "in_reply_to_user_id" : 2219841242,
  "text" : "@podehaye @PhilippBayer @ciyer found the data set, spot the red dot? ;) http:\/\/t.co\/0Mf7lfP2da",
  "id" : 610936244479098880,
  "in_reply_to_status_id" : 610895861711671299,
  "created_at" : "2015-06-16 22:25:25 +0000",
  "in_reply_to_screen_name" : "podehaye",
  "in_reply_to_user_id_str" : "2219841242",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 84, 97 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "ciyer",
      "screen_name" : "ciyer",
      "indices" : [ 98, 104 ],
      "id_str" : "14533425",
      "id" : 14533425
    }, {
      "name" : "Paul-Olivier Dehaye",
      "screen_name" : "podehaye",
      "indices" : [ 105, 114 ],
      "id_str" : "2219841242",
      "id" : 2219841242
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/610934173889642497\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/JWIodXn5zd",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CHp5ZFzWwAAkUqg.png",
      "id_str" : "610934171423391744",
      "id" : 610934171423391744,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHp5ZFzWwAAkUqg.png",
      "sizes" : [ {
        "h" : 773,
        "resize" : "fit",
        "w" : 1398
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 773,
        "resize" : "fit",
        "w" : 1398
      }, {
        "h" : 376,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 664,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/JWIodXn5zd"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 83 ],
      "url" : "https:\/\/t.co\/o8V8MLezPg",
      "expanded_url" : "https:\/\/www.sanger.ac.uk\/resources\/downloads\/human\/hapmap3.html",
      "display_url" : "sanger.ac.uk\/resources\/down\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "610893904674553856",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11407188695235, 8.753388986047213 ]
  },
  "id_str" : "610934173889642497",
  "in_reply_to_user_id" : 14286491,
  "text" : "PCA now w\/ HapMap populations given. Translations for pops: https:\/\/t.co\/o8V8MLezPg @PhilippBayer @ciyer @podehaye http:\/\/t.co\/JWIodXn5zd",
  "id" : 610934173889642497,
  "in_reply_to_status_id" : 610893904674553856,
  "created_at" : "2015-06-16 22:17:12 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul-Olivier Dehaye",
      "screen_name" : "podehaye",
      "indices" : [ 0, 9 ],
      "id_str" : "2219841242",
      "id" : 2219841242
    }, {
      "name" : "ciyer",
      "screen_name" : "ciyer",
      "indices" : [ 10, 16 ],
      "id_str" : "14533425",
      "id" : 14533425
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 57, 70 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "610916042286702594",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11407185273307, 8.753388813374666 ]
  },
  "id_str" : "610930177108017152",
  "in_reply_to_user_id" : 2219841242,
  "text" : "@podehaye @ciyer I wouldn\u2019t exactly bet on it, but maybe @PhilippBayer can enlighten us, I think he already did some work on that.",
  "id" : 610930177108017152,
  "in_reply_to_status_id" : 610916042286702594,
  "created_at" : "2015-06-16 22:01:19 +0000",
  "in_reply_to_screen_name" : "podehaye",
  "in_reply_to_user_id_str" : "2219841242",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul-Olivier Dehaye",
      "screen_name" : "podehaye",
      "indices" : [ 0, 9 ],
      "id_str" : "2219841242",
      "id" : 2219841242
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 99, 112 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "ciyer",
      "screen_name" : "ciyer",
      "indices" : [ 113, 119 ],
      "id_str" : "14533425",
      "id" : 14533425
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/EOqTCKGoK5",
      "expanded_url" : "http:\/\/make.opendata.ch\/wiki\/project:opensnp",
      "display_url" : "make.opendata.ch\/wiki\/project:o\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "610896184001978369",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11407203738137, 8.753389745122014 ]
  },
  "id_str" : "610896509324791809",
  "in_reply_to_user_id" : 2219841242,
  "text" : "@podehaye puh, remind me tomorrow, this will take a while. or you try doing http:\/\/t.co\/EOqTCKGoK5 @PhilippBayer @ciyer",
  "id" : 610896509324791809,
  "in_reply_to_status_id" : 610896184001978369,
  "created_at" : "2015-06-16 19:47:32 +0000",
  "in_reply_to_screen_name" : "podehaye",
  "in_reply_to_user_id_str" : "2219841242",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul-Olivier Dehaye",
      "screen_name" : "podehaye",
      "indices" : [ 0, 9 ],
      "id_str" : "2219841242",
      "id" : 2219841242
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 81, 94 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "ciyer",
      "screen_name" : "ciyer",
      "indices" : [ 95, 101 ],
      "id_str" : "14533425",
      "id" : 14533425
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "610895861711671299",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11407270612867, 8.7533931196676 ]
  },
  "id_str" : "610896025092427776",
  "in_reply_to_user_id" : 2219841242,
  "text" : "@podehaye couldn\u2019t tell you right away, lost the IDs somewhere in the process ;) @PhilippBayer @ciyer",
  "id" : 610896025092427776,
  "in_reply_to_status_id" : 610895861711671299,
  "created_at" : "2015-06-16 19:45:36 +0000",
  "in_reply_to_screen_name" : "podehaye",
  "in_reply_to_user_id_str" : "2219841242",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul-Olivier Dehaye",
      "screen_name" : "podehaye",
      "indices" : [ 0, 9 ],
      "id_str" : "2219841242",
      "id" : 2219841242
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 64, 77 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "ciyer",
      "screen_name" : "ciyer",
      "indices" : [ 78, 84 ],
      "id_str" : "14533425",
      "id" : 14533425
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "610895585156071426",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11407270612867, 8.7533931196676 ]
  },
  "id_str" : "610895823639961602",
  "in_reply_to_user_id" : 2219841242,
  "text" : "@podehaye sure, which kind of raw file would you need? The BED? @PhilippBayer @ciyer",
  "id" : 610895823639961602,
  "in_reply_to_status_id" : 610895585156071426,
  "created_at" : "2015-06-16 19:44:48 +0000",
  "in_reply_to_screen_name" : "podehaye",
  "in_reply_to_user_id_str" : "2219841242",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 85, 98 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "ciyer",
      "screen_name" : "ciyer",
      "indices" : [ 99, 105 ],
      "id_str" : "14533425",
      "id" : 14533425
    }, {
      "name" : "Paul-Olivier Dehaye",
      "screen_name" : "podehaye",
      "indices" : [ 106, 115 ],
      "id_str" : "2219841242",
      "id" : 2219841242
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/610893904674553856\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/JGAwuRGcPq",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CHpUxE0VAAA9ReD.png",
      "id_str" : "610893901545668608",
      "id" : 610893901545668608,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHpUxE0VAAA9ReD.png",
      "sizes" : [ {
        "h" : 773,
        "resize" : "fit",
        "w" : 1398
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 773,
        "resize" : "fit",
        "w" : 1398
      }, {
        "h" : 376,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 664,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/JGAwuRGcPq"
    } ],
    "hashtags" : [ {
      "text" : "makeopendata",
      "indices" : [ 67, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 44, 66 ],
      "url" : "http:\/\/t.co\/VgcT2wNdXu",
      "expanded_url" : "http:\/\/www.biomedcentral.com\/1471-2156\/10\/39",
      "display_url" : "biomedcentral.com\/1471-2156\/10\/39"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11407194401797, 8.75338927474841 ]
  },
  "id_str" : "610893904674553856",
  "text" : "PCA on openSNP + HapMap using the AIMs from http:\/\/t.co\/VgcT2wNdXu #makeopendata \/cc @PhilippBayer @ciyer @podehaye http:\/\/t.co\/JGAwuRGcPq",
  "id" : 610893904674553856,
  "created_at" : "2015-06-16 19:37:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul-Olivier Dehaye",
      "screen_name" : "podehaye",
      "indices" : [ 3, 12 ],
      "id_str" : "2219841242",
      "id" : 2219841242
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 14, 30 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/t9BqOkFgOy",
      "expanded_url" : "http:\/\/www.segerman.org\/autologlyphs.html",
      "display_url" : "segerman.org\/autologlyphs.h\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "610887160116432896",
  "text" : "RT @podehaye: @gedankenstuecke Only if you are drawing Penrose tiling autologlyphs (PostScript for the win!) http:\/\/t.co\/t9BqOkFgOy",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 0, 16 ],
        "id_str" : "14286491",
        "id" : 14286491
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 95, 117 ],
        "url" : "http:\/\/t.co\/t9BqOkFgOy",
        "expanded_url" : "http:\/\/www.segerman.org\/autologlyphs.html",
        "display_url" : "segerman.org\/autologlyphs.h\u2026"
      } ]
    },
    "in_reply_to_status_id_str" : "610884067186356224",
    "geo" : { },
    "id_str" : "610886882340270081",
    "in_reply_to_user_id" : 14286491,
    "text" : "@gedankenstuecke Only if you are drawing Penrose tiling autologlyphs (PostScript for the win!) http:\/\/t.co\/t9BqOkFgOy",
    "id" : 610886882340270081,
    "in_reply_to_status_id" : 610884067186356224,
    "created_at" : "2015-06-16 19:09:17 +0000",
    "in_reply_to_screen_name" : "gedankenstuecke",
    "in_reply_to_user_id_str" : "14286491",
    "user" : {
      "name" : "Paul-Olivier Dehaye",
      "screen_name" : "podehaye",
      "protected" : false,
      "id_str" : "2219841242",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/840965162349797376\/7hdkcm04_normal.jpg",
      "id" : 2219841242,
      "verified" : false
    }
  },
  "id" : 610887160116432896,
  "created_at" : "2015-06-16 19:10:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul-Olivier Dehaye",
      "screen_name" : "podehaye",
      "indices" : [ 0, 9 ],
      "id_str" : "2219841242",
      "id" : 2219841242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "610886882340270081",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11407182052575, 8.753388652081052 ]
  },
  "id_str" : "610887148833775618",
  "in_reply_to_user_id" : 2219841242,
  "text" : "@podehaye wow, the torus &amp; the sphere are awesome!",
  "id" : 610887148833775618,
  "in_reply_to_status_id" : 610886882340270081,
  "created_at" : "2015-06-16 19:10:20 +0000",
  "in_reply_to_screen_name" : "podehaye",
  "in_reply_to_user_id_str" : "2219841242",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11407179931529, 8.753388545769464 ]
  },
  "id_str" : "610884067186356224",
  "text" : "Is there extra nerd-credibility in editing vector graphics in vim?",
  "id" : 610884067186356224,
  "created_at" : "2015-06-16 18:58:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pawel Szczesny",
      "screen_name" : "freesci",
      "indices" : [ 0, 8 ],
      "id_str" : "14163008",
      "id" : 14163008
    }, {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 9, 18 ],
      "id_str" : "14245811",
      "id" : 14245811
    }, {
      "name" : "\uD83D\uDCABKelsey Merkley \uD83D\uDCAB",
      "screen_name" : "bella_velo",
      "indices" : [ 19, 30 ],
      "id_str" : "6745972",
      "id" : 6745972
    }, {
      "name" : "Roderic Page",
      "screen_name" : "rdmpage",
      "indices" : [ 31, 39 ],
      "id_str" : "14568034",
      "id" : 14568034
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/G236XIUGld",
      "expanded_url" : "http:\/\/media.giphy.com\/media\/7BB1UpQKNleM0\/giphy.gif",
      "display_url" : "media.giphy.com\/media\/7BB1UpQK\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "610867573392076802",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11407213466863, 8.753390236026583 ]
  },
  "id_str" : "610868912868171776",
  "in_reply_to_user_id" : 14163008,
  "text" : "@freesci @wilbanks @bella_velo @rdmpage yes, but merging data sets already feels like http:\/\/t.co\/G236XIUGld gets worse if incomp. licenses.",
  "id" : 610868912868171776,
  "in_reply_to_status_id" : 610867573392076802,
  "created_at" : "2015-06-16 17:57:52 +0000",
  "in_reply_to_screen_name" : "freesci",
  "in_reply_to_user_id_str" : "14163008",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 0, 9 ],
      "id_str" : "14245811",
      "id" : 14245811
    }, {
      "name" : "\uD83D\uDCABKelsey Merkley \uD83D\uDCAB",
      "screen_name" : "bella_velo",
      "indices" : [ 10, 21 ],
      "id_str" : "6745972",
      "id" : 6745972
    }, {
      "name" : "Pawel Szczesny",
      "screen_name" : "freesci",
      "indices" : [ 22, 30 ],
      "id_str" : "14163008",
      "id" : 14163008
    }, {
      "name" : "Roderic Page",
      "screen_name" : "rdmpage",
      "indices" : [ 31, 39 ],
      "id_str" : "14568034",
      "id" : 14568034
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "610866689132130305",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11407194501378, 8.753389279364532 ]
  },
  "id_str" : "610867120340135936",
  "in_reply_to_user_id" : 14245811,
  "text" : "@wilbanks @bella_velo @freesci @rdmpage ack, virtually all the good that open data creates only works if can be remixed\/merged openly.",
  "id" : 610867120340135936,
  "in_reply_to_status_id" : 610866689132130305,
  "created_at" : "2015-06-16 17:50:45 +0000",
  "in_reply_to_screen_name" : "wilbanks",
  "in_reply_to_user_id_str" : "14245811",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pawel Szczesny",
      "screen_name" : "freesci",
      "indices" : [ 0, 8 ],
      "id_str" : "14163008",
      "id" : 14163008
    }, {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 9, 18 ],
      "id_str" : "14245811",
      "id" : 14245811
    }, {
      "name" : "Roderic Page",
      "screen_name" : "rdmpage",
      "indices" : [ 19, 27 ],
      "id_str" : "14568034",
      "id" : 14568034
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/8BPcB2uUmT",
      "expanded_url" : "https:\/\/media3.giphy.com\/media\/1BfSdlbTDkl20\/200.gif",
      "display_url" : "media3.giphy.com\/media\/1BfSdlbT\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "610863107402014720",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11407170214043, 8.753388030286908 ]
  },
  "id_str" : "610865016997343232",
  "in_reply_to_user_id" : 14163008,
  "text" : "@freesci @wilbanks @rdmpage boils down to \u201Cif it\u2019s data, make it CC0, otherwise https:\/\/t.co\/8BPcB2uUmT will happen\u201D, doesn\u2019t it?",
  "id" : 610865016997343232,
  "in_reply_to_status_id" : 610863107402014720,
  "created_at" : "2015-06-16 17:42:24 +0000",
  "in_reply_to_screen_name" : "freesci",
  "in_reply_to_user_id_str" : "14163008",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OpenCon",
      "screen_name" : "open_con",
      "indices" : [ 3, 12 ],
      "id_str" : "2452073258",
      "id" : 2452073258
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OpenCon",
      "indices" : [ 36, 44 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/dwNwHVVHCr",
      "expanded_url" : "http:\/\/bit.ly\/AppsOpen",
      "display_url" : "bit.ly\/AppsOpen"
    } ]
  },
  "geo" : { },
  "id_str" : "610862458899693568",
  "text" : "RT @open_con: Not long to apply for #OpenCon! Those accepted will receive full travel scholarships! http:\/\/t.co\/dwNwHVVHCr http:\/\/t.co\/Pu7L\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/open_con\/status\/610825844488077312\/photo\/1",
        "indices" : [ 109, 131 ],
        "url" : "http:\/\/t.co\/Pu7L47d8U7",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CHoW2jxXAAAUuBh.png",
        "id_str" : "610825826033139712",
        "id" : 610825826033139712,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHoW2jxXAAAUuBh.png",
        "sizes" : [ {
          "h" : 540,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 383,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 540,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 540,
          "resize" : "fit",
          "w" : 960
        } ],
        "display_url" : "pic.twitter.com\/Pu7L47d8U7"
      } ],
      "hashtags" : [ {
        "text" : "OpenCon",
        "indices" : [ 22, 30 ]
      } ],
      "urls" : [ {
        "indices" : [ 86, 108 ],
        "url" : "http:\/\/t.co\/dwNwHVVHCr",
        "expanded_url" : "http:\/\/bit.ly\/AppsOpen",
        "display_url" : "bit.ly\/AppsOpen"
      } ]
    },
    "geo" : { },
    "id_str" : "610825844488077312",
    "text" : "Not long to apply for #OpenCon! Those accepted will receive full travel scholarships! http:\/\/t.co\/dwNwHVVHCr http:\/\/t.co\/Pu7L47d8U7",
    "id" : 610825844488077312,
    "created_at" : "2015-06-16 15:06:44 +0000",
    "user" : {
      "name" : "OpenCon",
      "screen_name" : "open_con",
      "protected" : false,
      "id_str" : "2452073258",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/843937071534424064\/e-PdQw9V_normal.jpg",
      "id" : 2452073258,
      "verified" : false
    }
  },
  "id" : 610862458899693568,
  "created_at" : "2015-06-16 17:32:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul-Olivier Dehaye",
      "screen_name" : "podehaye",
      "indices" : [ 0, 9 ],
      "id_str" : "2219841242",
      "id" : 2219841242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "610775699364954113",
  "geo" : { },
  "id_str" : "610775836229242880",
  "in_reply_to_user_id" : 2219841242,
  "text" : "@podehaye just wanted to be sure, because it was kind of unclear in my explanations as well :)",
  "id" : 610775836229242880,
  "in_reply_to_status_id" : 610775699364954113,
  "created_at" : "2015-06-16 11:48:01 +0000",
  "in_reply_to_screen_name" : "podehaye",
  "in_reply_to_user_id_str" : "2219841242",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul-Olivier Dehaye",
      "screen_name" : "podehaye",
      "indices" : [ 0, 9 ],
      "id_str" : "2219841242",
      "id" : 2219841242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "610772400876220416",
  "geo" : { },
  "id_str" : "610773185378807808",
  "in_reply_to_user_id" : 2219841242,
  "text" : "@podehaye the other issue is which strand you read, this is less of a problem, because doing reverse complement gives you \u2018correct\u2019 one.",
  "id" : 610773185378807808,
  "in_reply_to_status_id" : 610772400876220416,
  "created_at" : "2015-06-16 11:37:29 +0000",
  "in_reply_to_screen_name" : "podehaye",
  "in_reply_to_user_id_str" : "2219841242",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul-Olivier Dehaye",
      "screen_name" : "podehaye",
      "indices" : [ 0, 9 ],
      "id_str" : "2219841242",
      "id" : 2219841242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "610772400876220416",
  "geo" : { },
  "id_str" : "610772893715296256",
  "in_reply_to_user_id" : 2219841242,
  "text" : "@podehaye so basically doing single cell seq. on sperm\/eggs would solve phasing issue. ;)",
  "id" : 610772893715296256,
  "in_reply_to_status_id" : 610772400876220416,
  "created_at" : "2015-06-16 11:36:20 +0000",
  "in_reply_to_screen_name" : "podehaye",
  "in_reply_to_user_id_str" : "2219841242",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul-Olivier Dehaye",
      "screen_name" : "podehaye",
      "indices" : [ 0, 9 ],
      "id_str" : "2219841242",
      "id" : 2219841242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "610772400876220416",
  "geo" : { },
  "id_str" : "610772598373416960",
  "in_reply_to_user_id" : 2219841242,
  "text" : "@podehaye also: don\u2019t confuse strands and the 2nd copy of chromosome. Phasing is concerned with making sure it\u2019s from same chromosome.",
  "id" : 610772598373416960,
  "in_reply_to_status_id" : 610772400876220416,
  "created_at" : "2015-06-16 11:35:09 +0000",
  "in_reply_to_screen_name" : "podehaye",
  "in_reply_to_user_id_str" : "2219841242",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul-Olivier Dehaye",
      "screen_name" : "podehaye",
      "indices" : [ 0, 9 ],
      "id_str" : "2219841242",
      "id" : 2219841242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "610771928668876800",
  "geo" : { },
  "id_str" : "610772218348482562",
  "in_reply_to_user_id" : 2219841242,
  "text" : "@podehaye \u2026problematic in itself.",
  "id" : 610772218348482562,
  "in_reply_to_status_id" : 610771928668876800,
  "created_at" : "2015-06-16 11:33:39 +0000",
  "in_reply_to_screen_name" : "podehaye",
  "in_reply_to_user_id_str" : "2219841242",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul-Olivier Dehaye",
      "screen_name" : "podehaye",
      "indices" : [ 0, 9 ],
      "id_str" : "2219841242",
      "id" : 2219841242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "610771928668876800",
  "geo" : { },
  "id_str" : "610772171019952128",
  "in_reply_to_user_id" : 2219841242,
  "text" : "@podehaye without tearing things up? Yes. And even if you separate them: you could only do it for a single cell. Which works, but is\u2026",
  "id" : 610772171019952128,
  "in_reply_to_status_id" : 610771928668876800,
  "created_at" : "2015-06-16 11:33:27 +0000",
  "in_reply_to_screen_name" : "podehaye",
  "in_reply_to_user_id_str" : "2219841242",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul-Olivier Dehaye",
      "screen_name" : "podehaye",
      "indices" : [ 0, 9 ],
      "id_str" : "2219841242",
      "id" : 2219841242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "610768394200195072",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17246844453368, 8.627557204524079 ]
  },
  "id_str" : "610769144930299904",
  "in_reply_to_user_id" : 2219841242,
  "text" : "@podehaye you \u201Ecut up\u201C the double-stranded DNA. But even if unzipping first: You would still end up w\/ 2 different copies in diploid sample",
  "id" : 610769144930299904,
  "in_reply_to_status_id" : 610768394200195072,
  "created_at" : "2015-06-16 11:21:26 +0000",
  "in_reply_to_screen_name" : "podehaye",
  "in_reply_to_user_id_str" : "2219841242",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul-Olivier Dehaye",
      "screen_name" : "podehaye",
      "indices" : [ 0, 9 ],
      "id_str" : "2219841242",
      "id" : 2219841242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "610761586475696128",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17225838753463, 8.62763625784181 ]
  },
  "id_str" : "610764949506408448",
  "in_reply_to_user_id" : 2219841242,
  "text" : "@podehaye happy to explain via email if you want a longer version. :)",
  "id" : 610764949506408448,
  "in_reply_to_status_id" : 610761586475696128,
  "created_at" : "2015-06-16 11:04:46 +0000",
  "in_reply_to_screen_name" : "podehaye",
  "in_reply_to_user_id_str" : "2219841242",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul-Olivier Dehaye",
      "screen_name" : "podehaye",
      "indices" : [ 0, 9 ],
      "id_str" : "2219841242",
      "id" : 2219841242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "610761586475696128",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17225838753463, 8.62763625784181 ]
  },
  "id_str" : "610764882376564736",
  "in_reply_to_user_id" : 2219841242,
  "text" : "@podehaye I wouldn\u2019t say impossible, but really hard to do. Shotgun sequencing basically only allows phasing within read length.",
  "id" : 610764882376564736,
  "in_reply_to_status_id" : 610761586475696128,
  "created_at" : "2015-06-16 11:04:30 +0000",
  "in_reply_to_screen_name" : "podehaye",
  "in_reply_to_user_id_str" : "2219841242",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 86 ],
      "url" : "https:\/\/t.co\/97GTnere9U",
      "expanded_url" : "https:\/\/media0.giphy.com\/media\/EldfH1VJdbrwY\/200.gif",
      "display_url" : "media0.giphy.com\/media\/EldfH1VJ\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "610751916042268672",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17226747235244, 8.62758788892176 ]
  },
  "id_str" : "610752645842771968",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot sind wir nicht alle nur Sternenstaub der nicht w\u00FCrfelt? https:\/\/t.co\/97GTnere9U",
  "id" : 610752645842771968,
  "in_reply_to_status_id" : 610751916042268672,
  "created_at" : "2015-06-16 10:15:52 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/EUYAqbSHxq",
      "expanded_url" : "http:\/\/s1128.photobucket.com\/user\/pythongifer\/media\/PalinGettingStonedLOB.gif.html",
      "display_url" : "s1128.photobucket.com\/user\/pythongif\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "610749646462451712",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17218305082419, 8.62762418301153 ]
  },
  "id_str" : "610750766467432448",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot nicht vergessen vorher die Chakren mit den passenden Steinen anzuregen. http:\/\/t.co\/EUYAqbSHxq",
  "id" : 610750766467432448,
  "in_reply_to_status_id" : 610749646462451712,
  "created_at" : "2015-06-16 10:08:24 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "610745059491860480",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172276005437, 8.627624698382096 ]
  },
  "id_str" : "610749358745747456",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot was passiert wenn man mit Nullpunktenergie t\u00E4towiert!",
  "id" : 610749358745747456,
  "in_reply_to_status_id" : 610745059491860480,
  "created_at" : "2015-06-16 10:02:48 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Torsten Seemann",
      "screen_name" : "torstenseemann",
      "indices" : [ 3, 18 ],
      "id_str" : "42558652",
      "id" : 42558652
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Bioinformatics",
      "indices" : [ 113, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "610749156995518465",
  "text" : "RT @torstenseemann: \"Long read sequencing: the good, the bad, and the really cool\" - my slides from today's WEHI #Bioinformatics Seminar ht\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Bioinformatics",
        "indices" : [ 93, 108 ]
      } ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/WI0S3mThJT",
        "expanded_url" : "http:\/\/www.slideshare.net\/torstenseemann\/long-read-sequencing-wehi-bioinformatics-seminar-tue-16-june-2015",
        "display_url" : "slideshare.net\/torstenseemann\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "610683051786407936",
    "text" : "\"Long read sequencing: the good, the bad, and the really cool\" - my slides from today's WEHI #Bioinformatics Seminar http:\/\/t.co\/WI0S3mThJT",
    "id" : 610683051786407936,
    "created_at" : "2015-06-16 05:39:20 +0000",
    "user" : {
      "name" : "Torsten Seemann",
      "screen_name" : "torstenseemann",
      "protected" : false,
      "id_str" : "42558652",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/720526185361510400\/dA-svJxC_normal.jpg",
      "id" : 42558652,
      "verified" : false
    }
  },
  "id" : 610749156995518465,
  "created_at" : "2015-06-16 10:02:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 3, 12 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "geoblockling",
      "indices" : [ 38, 51 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "610743453509656576",
  "text" : "RT @Senficon: We won crucial votes on #geoblockling &amp; libraries, lost on Freedom of Panorama &amp; audiovisual quotation. Overall good #copyrig\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "geoblockling",
        "indices" : [ 24, 37 ]
      }, {
        "text" : "copyright",
        "indices" : [ 125, 135 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "610741673950334976",
    "text" : "We won crucial votes on #geoblockling &amp; libraries, lost on Freedom of Panorama &amp; audiovisual quotation. Overall good #copyright report.",
    "id" : 610741673950334976,
    "created_at" : "2015-06-16 09:32:16 +0000",
    "user" : {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "protected" : false,
      "id_str" : "14861745",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/637016870638350336\/QrtPmoul_normal.jpg",
      "id" : 14861745,
      "verified" : true
    }
  },
  "id" : 610743453509656576,
  "created_at" : "2015-06-16 09:39:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "610740673088749568",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17245108710794, 8.627558799850977 ]
  },
  "id_str" : "610741089897705472",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon well done :)",
  "id" : 610741089897705472,
  "in_reply_to_status_id" : 610740673088749568,
  "created_at" : "2015-06-16 09:29:57 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Science Web",
      "screen_name" : "TheScienceWeb",
      "indices" : [ 3, 17 ],
      "id_str" : "2315551122",
      "id" : 2315551122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/V0R2tgWw96",
      "expanded_url" : "http:\/\/wp.me\/p4ik2k-4X",
      "display_url" : "wp.me\/p4ik2k-4X"
    } ]
  },
  "geo" : { },
  "id_str" : "610732308497334272",
  "text" : "RT @TheScienceWeb: Scientist wants to sack everyone who is not good at Math http:\/\/t.co\/V0R2tgWw96",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 57, 79 ],
        "url" : "http:\/\/t.co\/V0R2tgWw96",
        "expanded_url" : "http:\/\/wp.me\/p4ik2k-4X",
        "display_url" : "wp.me\/p4ik2k-4X"
      } ]
    },
    "geo" : { },
    "id_str" : "610729809459683328",
    "text" : "Scientist wants to sack everyone who is not good at Math http:\/\/t.co\/V0R2tgWw96",
    "id" : 610729809459683328,
    "created_at" : "2015-06-16 08:45:08 +0000",
    "user" : {
      "name" : "The Science Web",
      "screen_name" : "TheScienceWeb",
      "protected" : false,
      "id_str" : "2315551122",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/428172546672824320\/1lZmC7lz_normal.jpeg",
      "id" : 2315551122,
      "verified" : false
    }
  },
  "id" : 610732308497334272,
  "created_at" : "2015-06-16 08:55:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/THXBoV9wGt",
      "expanded_url" : "http:\/\/arstechnica.com\/science\/2015\/06\/genetic-risk-of-psychiatric-illness-linked-to-creativity\/",
      "display_url" : "arstechnica.com\/science\/2015\/0\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17219400338094, 8.627611583769959 ]
  },
  "id_str" : "610724362044506112",
  "text" : "0.24% explained variance for the link psychatric illness &lt;-&gt; creativity? Curse of large numbers anyone? http:\/\/t.co\/THXBoV9wGt",
  "id" : 610724362044506112,
  "created_at" : "2015-06-16 08:23:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Brechler",
      "screen_name" : "plaetzchen",
      "indices" : [ 0, 11 ],
      "id_str" : "14305613",
      "id" : 14305613
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "610715927169114113",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17220378902879, 8.627620510885674 ]
  },
  "id_str" : "610716601634172928",
  "in_reply_to_user_id" : 14305613,
  "text" : "@plaetzchen gut das ich keinen Hund hab, sonst w\u00E4re der Hitlervergleich genauso naheliegend.",
  "id" : 610716601634172928,
  "in_reply_to_status_id" : 610715927169114113,
  "created_at" : "2015-06-16 07:52:39 +0000",
  "in_reply_to_screen_name" : "plaetzchen",
  "in_reply_to_user_id_str" : "14305613",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "610714732811669504",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17220378902879, 8.627620510885674 ]
  },
  "id_str" : "610715099507085312",
  "in_reply_to_user_id" : 14286491,
  "text" : "Could this please stop the Facebook\/Zuckerberg comparisons?",
  "id" : 610715099507085312,
  "in_reply_to_status_id" : 610714732811669504,
  "created_at" : "2015-06-16 07:46:40 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Open Data Institute",
      "screen_name" : "ODIHQ",
      "indices" : [ 69, 75 ],
      "id_str" : "534255106",
      "id" : 534255106
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/fjNhCPQu2L",
      "expanded_url" : "http:\/\/awards.theodi.org\/2015-shortlist\/",
      "display_url" : "awards.theodi.org\/2015-shortlist\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17220388015059, 8.627620438750615 ]
  },
  "id_str" : "610714732811669504",
  "text" : "I\u2019m shortlisted for the \u2018Open Data Individual Champion Award\u2019 by the @ODIHQ http:\/\/t.co\/fjNhCPQu2L",
  "id" : 610714732811669504,
  "created_at" : "2015-06-16 07:45:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/610547246963277826\/photo\/1",
      "indices" : [ 50, 72 ],
      "url" : "http:\/\/t.co\/gztWdErdcl",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CHkZfHOWIAAu64H.jpg",
      "id_str" : "610547246791270400",
      "id" : 610547246791270400,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHkZfHOWIAAu64H.jpg",
      "sizes" : [ {
        "h" : 863,
        "resize" : "fit",
        "w" : 735
      }, {
        "h" : 863,
        "resize" : "fit",
        "w" : 735
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 863,
        "resize" : "fit",
        "w" : 735
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 579
      } ],
      "display_url" : "pic.twitter.com\/gztWdErdcl"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "610547246963277826",
  "text" : "Category: weird and kinda useless product images. http:\/\/t.co\/gztWdErdcl",
  "id" : 610547246963277826,
  "created_at" : "2015-06-15 20:39:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Effy Vayena",
      "screen_name" : "EffyVayena",
      "indices" : [ 3, 14 ],
      "id_str" : "397518511",
      "id" : 397518511
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "iagree",
      "indices" : [ 120, 127 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/r1zMIulbZB",
      "expanded_url" : "http:\/\/gu.com\/p\/48v7k\/stw",
      "display_url" : "gu.com\/p\/48v7k\/stw"
    } ]
  },
  "geo" : { },
  "id_str" : "610423866494701568",
  "text" : "RT @EffyVayena: Brilliant: I read all the small print on the internet and it made me want to die http:\/\/t.co\/r1zMIulbZB #iagree",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "iagree",
        "indices" : [ 104, 111 ]
      } ],
      "urls" : [ {
        "indices" : [ 81, 103 ],
        "url" : "http:\/\/t.co\/r1zMIulbZB",
        "expanded_url" : "http:\/\/gu.com\/p\/48v7k\/stw",
        "display_url" : "gu.com\/p\/48v7k\/stw"
      } ]
    },
    "geo" : { },
    "id_str" : "610422562238144512",
    "text" : "Brilliant: I read all the small print on the internet and it made me want to die http:\/\/t.co\/r1zMIulbZB #iagree",
    "id" : 610422562238144512,
    "created_at" : "2015-06-15 12:24:14 +0000",
    "user" : {
      "name" : "Effy Vayena",
      "screen_name" : "EffyVayena",
      "protected" : false,
      "id_str" : "397518511",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/837580905615085568\/EBU1zR7D_normal.jpg",
      "id" : 397518511,
      "verified" : false
    }
  },
  "id" : 610423866494701568,
  "created_at" : "2015-06-15 12:29:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17217277409102, 8.627654222764617 ]
  },
  "id_str" : "610335890611785728",
  "text" : "\u00ABIt will come to pass by violence &amp; upheaval, by flame &amp; by fury, for no change comes calmly over the world\u00BB re-read. Canticle for Leibowitz",
  "id" : 610335890611785728,
  "created_at" : "2015-06-15 06:39:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/610332672850849793\/photo\/1",
      "indices" : [ 20, 42 ],
      "url" : "http:\/\/t.co\/JuNl1OaHht",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CHhWVKMWoAASB0F.jpg",
      "id_str" : "610332671022112768",
      "id" : 610332671022112768,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHhWVKMWoAASB0F.jpg",
      "sizes" : [ {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 3264,
        "resize" : "fit",
        "w" : 2448
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      } ],
      "display_url" : "pic.twitter.com\/JuNl1OaHht"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "610332672850849793",
  "text" : "It\u2019s just temporary http:\/\/t.co\/JuNl1OaHht",
  "id" : 610332672850849793,
  "created_at" : "2015-06-15 06:27:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Loman",
      "screen_name" : "pathogenomenick",
      "indices" : [ 3, 19 ],
      "id_str" : "85906238",
      "id" : 85906238
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/sdkzS5udlM",
      "expanded_url" : "http:\/\/wp.me\/pXK0q-3Xb",
      "display_url" : "wp.me\/pXK0q-3Xb"
    } ]
  },
  "geo" : { },
  "id_str" : "610172419697942528",
  "text" : "RT @pathogenomenick: Where Does the Genetic Code Come From? An Interview with Dr. Charles Carter, Part I. http:\/\/t.co\/sdkzS5udlM via @finch\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The Finch and Pea",
        "screen_name" : "finchandpea",
        "indices" : [ 112, 124 ],
        "id_str" : "156920978",
        "id" : 156920978
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 85, 107 ],
        "url" : "http:\/\/t.co\/sdkzS5udlM",
        "expanded_url" : "http:\/\/wp.me\/pXK0q-3Xb",
        "display_url" : "wp.me\/pXK0q-3Xb"
      } ]
    },
    "geo" : { },
    "id_str" : "610169992752050176",
    "text" : "Where Does the Genetic Code Come From? An Interview with Dr. Charles Carter, Part I. http:\/\/t.co\/sdkzS5udlM via @finchandpea",
    "id" : 610169992752050176,
    "created_at" : "2015-06-14 19:40:37 +0000",
    "user" : {
      "name" : "Nick Loman",
      "screen_name" : "pathogenomenick",
      "protected" : false,
      "id_str" : "85906238",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/654948428951195648\/i5lt2BWa_normal.jpg",
      "id" : 85906238,
      "verified" : false
    }
  },
  "id" : 610172419697942528,
  "created_at" : "2015-06-14 19:50:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Eisen",
      "screen_name" : "mbeisen",
      "indices" : [ 3, 11 ],
      "id_str" : "19843630",
      "id" : 19843630
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TimHunt",
      "indices" : [ 56, 64 ]
    } ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/9kn7BsmsaY",
      "expanded_url" : "http:\/\/www.michaeleisen.org\/blog\/?p=1728",
      "display_url" : "michaeleisen.org\/blog\/?p=1728"
    } ]
  },
  "geo" : { },
  "id_str" : "610167810560557057",
  "text" : "RT @mbeisen: Sympathy for The Devil? My thoughts on the #TimHunt \"witch hunt\". http:\/\/t.co\/9kn7BsmsaY",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "TimHunt",
        "indices" : [ 43, 51 ]
      } ],
      "urls" : [ {
        "indices" : [ 66, 88 ],
        "url" : "http:\/\/t.co\/9kn7BsmsaY",
        "expanded_url" : "http:\/\/www.michaeleisen.org\/blog\/?p=1728",
        "display_url" : "michaeleisen.org\/blog\/?p=1728"
      } ]
    },
    "geo" : { },
    "id_str" : "610161228556546048",
    "text" : "Sympathy for The Devil? My thoughts on the #TimHunt \"witch hunt\". http:\/\/t.co\/9kn7BsmsaY",
    "id" : 610161228556546048,
    "created_at" : "2015-06-14 19:05:47 +0000",
    "user" : {
      "name" : "Michael Eisen",
      "screen_name" : "mbeisen",
      "protected" : false,
      "id_str" : "19843630",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/893602583478239236\/Gkp75Fa5_normal.jpg",
      "id" : 19843630,
      "verified" : true
    }
  },
  "id" : 610167810560557057,
  "created_at" : "2015-06-14 19:31:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/610166123544322048\/photo\/1",
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/XoCAKtO37O",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CHe-2zXWIAAAOsr.jpg",
      "id_str" : "610166123242332160",
      "id" : 610166123242332160,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHe-2zXWIAAAOsr.jpg",
      "sizes" : [ {
        "h" : 508,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 893,
        "resize" : "fit",
        "w" : 1196
      }, {
        "h" : 893,
        "resize" : "fit",
        "w" : 1196
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 893,
        "resize" : "fit",
        "w" : 1196
      } ],
      "display_url" : "pic.twitter.com\/XoCAKtO37O"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "610166123544322048",
  "text" : "Somehow I'm inclined to trust my Aria scale more than the scales you can find in the CORPUS Museum in Leiden. http:\/\/t.co\/XoCAKtO37O",
  "id" : 610166123544322048,
  "created_at" : "2015-06-14 19:25:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/ltfL0f0Yw2",
      "expanded_url" : "https:\/\/instagram.com\/p\/36VP0DBwh2\/",
      "display_url" : "instagram.com\/p\/36VP0DBwh2\/"
    } ]
  },
  "geo" : { },
  "id_str" : "610078063213346816",
  "text" : "Unfortunately changed so many things re:my lifestyle since last microbiome sample that even\u2026 https:\/\/t.co\/ltfL0f0Yw2",
  "id" : 610078063213346816,
  "created_at" : "2015-06-14 13:35:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Brechler",
      "screen_name" : "plaetzchen",
      "indices" : [ 0, 11 ],
      "id_str" : "14305613",
      "id" : 14305613
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "610072527868702721",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11408004215792, 8.753315860443301 ]
  },
  "id_str" : "610073381015302144",
  "in_reply_to_user_id" : 14305613,
  "text" : "@plaetzchen schade, dann das n\u00E4chste mal wenn ich mal wieder im Osten bin ;)",
  "id" : 610073381015302144,
  "in_reply_to_status_id" : 610072527868702721,
  "created_at" : "2015-06-14 13:16:43 +0000",
  "in_reply_to_screen_name" : "plaetzchen",
  "in_reply_to_user_id_str" : "14305613",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Brechler",
      "screen_name" : "plaetzchen",
      "indices" : [ 0, 11 ],
      "id_str" : "14305613",
      "id" : 14305613
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "610071245976137729",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1140798724679, 8.753315800984877 ]
  },
  "id_str" : "610072451037425664",
  "in_reply_to_user_id" : 14305613,
  "text" : "@plaetzchen kommst auf nen Bier r\u00FCber? ;)",
  "id" : 610072451037425664,
  "in_reply_to_status_id" : 610071245976137729,
  "created_at" : "2015-06-14 13:13:01 +0000",
  "in_reply_to_screen_name" : "plaetzchen",
  "in_reply_to_user_id_str" : "14305613",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ToxX",
      "screen_name" : "ToxXInFlames",
      "indices" : [ 0, 13 ],
      "id_str" : "1421360166",
      "id" : 1421360166
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "610059059065155584",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11407970111047, 8.7533157409953 ]
  },
  "id_str" : "610063602322669568",
  "in_reply_to_user_id" : 1421360166,
  "text" : "@ToxXInFlames I know, back in the days I even did research work in a sleep lab for a while.",
  "id" : 610063602322669568,
  "in_reply_to_status_id" : 610059059065155584,
  "created_at" : "2015-06-14 12:37:51 +0000",
  "in_reply_to_screen_name" : "ToxXInFlames",
  "in_reply_to_user_id_str" : "1421360166",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 56 ],
      "url" : "https:\/\/t.co\/CTvd3XFaLK",
      "expanded_url" : "https:\/\/instagram.com\/p\/36H-4bBwpu\/",
      "display_url" : "instagram.com\/p\/36H-4bBwpu\/"
    } ]
  },
  "geo" : { },
  "id_str" : "610048893728878594",
  "text" : "Crowd at the Dragon Boat Regatta https:\/\/t.co\/CTvd3XFaLK",
  "id" : 610048893728878594,
  "created_at" : "2015-06-14 11:39:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uD83D\uDCABKelsey Merkley \uD83D\uDCAB",
      "screen_name" : "bella_velo",
      "indices" : [ 3, 14 ],
      "id_str" : "6745972",
      "id" : 6745972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/pUkgUf05BS",
      "expanded_url" : "http:\/\/www.theglobeandmail.com\/globe-debate\/mountain-climbing-is-the-height-of-empty-egotism\/article24939711\/",
      "display_url" : "theglobeandmail.com\/globe-debate\/m\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "609995324854272001",
  "text" : "RT @bella_velo: Is mountain climbing the height of empty egotism or why I don't date climbers http:\/\/t.co\/pUkgUf05BS",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 78, 100 ],
        "url" : "http:\/\/t.co\/pUkgUf05BS",
        "expanded_url" : "http:\/\/www.theglobeandmail.com\/globe-debate\/mountain-climbing-is-the-height-of-empty-egotism\/article24939711\/",
        "display_url" : "theglobeandmail.com\/globe-debate\/m\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "609994123710480384",
    "text" : "Is mountain climbing the height of empty egotism or why I don't date climbers http:\/\/t.co\/pUkgUf05BS",
    "id" : 609994123710480384,
    "created_at" : "2015-06-14 08:01:46 +0000",
    "user" : {
      "name" : "\uD83D\uDCABKelsey Merkley \uD83D\uDCAB",
      "screen_name" : "bella_velo",
      "protected" : false,
      "id_str" : "6745972",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/875913994929934336\/1aiBO2bG_normal.jpg",
      "id" : 6745972,
      "verified" : false
    }
  },
  "id" : 609995324854272001,
  "created_at" : "2015-06-14 08:06:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Jacobs",
      "screen_name" : "djacobs",
      "indices" : [ 3, 11 ],
      "id_str" : "774842",
      "id" : 774842
    }, {
      "name" : "Paul Ford",
      "screen_name" : "ftrain",
      "indices" : [ 29, 36 ],
      "id_str" : "6981492",
      "id" : 6981492
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/djacobs\/status\/609886557311471616\/photo\/1",
      "indices" : [ 37, 59 ],
      "url" : "http:\/\/t.co\/H9Ao2v7iE4",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CHbAlbMUEAEG4f4.jpg",
      "id_str" : "609886548742377473",
      "id" : 609886548742377473,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHbAlbMUEAEG4f4.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/H9Ao2v7iE4"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "609987318586413056",
  "text" : "RT @djacobs: Nice paragraph, @ftrain http:\/\/t.co\/H9Ao2v7iE4",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Paul Ford",
        "screen_name" : "ftrain",
        "indices" : [ 16, 23 ],
        "id_str" : "6981492",
        "id" : 6981492
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/djacobs\/status\/609886557311471616\/photo\/1",
        "indices" : [ 24, 46 ],
        "url" : "http:\/\/t.co\/H9Ao2v7iE4",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CHbAlbMUEAEG4f4.jpg",
        "id_str" : "609886548742377473",
        "id" : 609886548742377473,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHbAlbMUEAEG4f4.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 510
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/H9Ao2v7iE4"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "609886557311471616",
    "text" : "Nice paragraph, @ftrain http:\/\/t.co\/H9Ao2v7iE4",
    "id" : 609886557311471616,
    "created_at" : "2015-06-14 00:54:21 +0000",
    "user" : {
      "name" : "David Jacobs",
      "screen_name" : "djacobs",
      "protected" : false,
      "id_str" : "774842",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/917356501303480325\/IlDLTS7__normal.jpg",
      "id" : 774842,
      "verified" : false
    }
  },
  "id" : 609987318586413056,
  "created_at" : "2015-06-14 07:34:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ed Yong",
      "screen_name" : "edyong209",
      "indices" : [ 3, 13 ],
      "id_str" : "19767193",
      "id" : 19767193
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "609987124063043584",
  "text" : "RT @edyong209: What terrifying dystopia have we created in which people say things and then sometimes face consequences for the things that\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "609811088889135104",
    "text" : "What terrifying dystopia have we created in which people say things and then sometimes face consequences for the things that they say?",
    "id" : 609811088889135104,
    "created_at" : "2015-06-13 19:54:27 +0000",
    "user" : {
      "name" : "Ed Yong",
      "screen_name" : "edyong209",
      "protected" : false,
      "id_str" : "19767193",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/926063794912153600\/962ygzzx_normal.jpg",
      "id" : 19767193,
      "verified" : true
    }
  },
  "id" : 609987124063043584,
  "created_at" : "2015-06-14 07:33:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 29, 38 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11407991602884, 8.753315844331437 ]
  },
  "id_str" : "609882777446653953",
  "text" : "discovering things thanks to @eramirez is still my #1 reason for using spotify. today: the new OMAM is out.",
  "id" : 609882777446653953,
  "created_at" : "2015-06-14 00:39:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/78xez878IT",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=-zVCYdrw-1o&feature=youtu.be",
      "display_url" : "youtube.com\/watch?v=-zVCYd\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11408012598115, 8.753315945431448 ]
  },
  "id_str" : "609866288924635136",
  "text" : "narcolepsy, a condition that causes him to suddenly fall asleep, when he\u2019s trying to do other things. https:\/\/t.co\/78xez878IT",
  "id" : 609866288924635136,
  "created_at" : "2015-06-13 23:33:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "609844245680234496",
  "text" : "\u00ABHaben diese Menschen denn keine\u2026wie hei\u00DFt das noch mal wenn man sich f\u00FCr sich selbst fremdsch\u00E4mt?\u00BB",
  "id" : 609844245680234496,
  "created_at" : "2015-06-13 22:06:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "609642331088769024",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11407950497878, 8.753315669952343 ]
  },
  "id_str" : "609642531907878912",
  "in_reply_to_user_id" : 14286491,
  "text" : "and yes: i mainly implemented it because i really enjoy the image of lighting a beacon.",
  "id" : 609642531907878912,
  "in_reply_to_status_id" : 609642331088769024,
  "created_at" : "2015-06-13 08:44:40 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ga4gh",
      "indices" : [ 63, 69 ]
    } ],
    "urls" : [ {
      "indices" : [ 39, 62 ],
      "url" : "https:\/\/t.co\/7qJWfEZXdM",
      "expanded_url" : "https:\/\/opensnp.org\/beacon\/rest\/responses?pos=53786615&chrom=16&allele=A",
      "display_url" : "opensnp.org\/beacon\/rest\/re\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11407950497878, 8.753315669952343 ]
  },
  "id_str" : "609642331088769024",
  "text" : "So, openSNP is now also a beacon. e.g. https:\/\/t.co\/7qJWfEZXdM #ga4gh",
  "id" : 609642331088769024,
  "created_at" : "2015-06-13 08:43:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sebastian Greiner",
      "screen_name" : "Seb666",
      "indices" : [ 0, 7 ],
      "id_str" : "2365333778",
      "id" : 2365333778
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "609410084473597952",
  "geo" : { },
  "id_str" : "609423288398389248",
  "in_reply_to_user_id" : 2365333778,
  "text" : "@Seb666 neeein!",
  "id" : 609423288398389248,
  "in_reply_to_status_id" : 609410084473597952,
  "created_at" : "2015-06-12 18:13:29 +0000",
  "in_reply_to_screen_name" : "Seb666",
  "in_reply_to_user_id_str" : "2365333778",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/609372260575649792\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/agJrAGkW2C",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CHTs12qWEAAbXcz.png",
      "id_str" : "609372259552202752",
      "id" : 609372259552202752,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHTs12qWEAAbXcz.png",
      "sizes" : [ {
        "h" : 773,
        "resize" : "fit",
        "w" : 1398
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 773,
        "resize" : "fit",
        "w" : 1398
      }, {
        "h" : 376,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 664,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/agJrAGkW2C"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "609342709522919425",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17223407664804, 8.62761110526389 ]
  },
  "id_str" : "609372260575649792",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer stays the same when filtering. Guess CEU is just dwarfed in the complete set and thus gets kinda lost? http:\/\/t.co\/agJrAGkW2C",
  "id" : 609372260575649792,
  "in_reply_to_status_id" : 609342709522919425,
  "created_at" : "2015-06-12 14:50:43 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/609369245730873345\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/e0WjSoCEWv",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CHTqGXUWsAASWiK.png",
      "id_str" : "609369244661362688",
      "id" : 609369244661362688,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHTqGXUWsAASWiK.png",
      "sizes" : [ {
        "h" : 773,
        "resize" : "fit",
        "w" : 1398
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 773,
        "resize" : "fit",
        "w" : 1398
      }, {
        "h" : 376,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 664,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/e0WjSoCEWv"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "609342709522919425",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17217412435411, 8.627670835622697 ]
  },
  "id_str" : "609369245730873345",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer only CEU + openSNP, but w\/o filtering for completeness. currently rerunning w\/ 0.8 SNP presence cutoff http:\/\/t.co\/e0WjSoCEWv",
  "id" : 609369245730873345,
  "in_reply_to_status_id" : 609342709522919425,
  "created_at" : "2015-06-12 14:38:44 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DNAdigest.org",
      "screen_name" : "DNADigest",
      "indices" : [ 3, 13 ],
      "id_str" : "334912047",
      "id" : 334912047
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "openness",
      "indices" : [ 34, 43 ]
    }, {
      "text" : "OpenData",
      "indices" : [ 99, 108 ]
    }, {
      "text" : "OpenScience",
      "indices" : [ 109, 121 ]
    }, {
      "text" : "OpenSource",
      "indices" : [ 122, 133 ]
    } ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/Ek5BhHq2Lx",
      "expanded_url" : "http:\/\/buff.ly\/1AY3MzM",
      "display_url" : "buff.ly\/1AY3MzM"
    } ]
  },
  "geo" : { },
  "id_str" : "609356798269767680",
  "text" : "RT @DNADigest: Why we need to put #openness at the heart of the Digital Age http:\/\/t.co\/Ek5BhHq2Lx #OpenData #OpenScience #OpenSource #Digi\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "openness",
        "indices" : [ 19, 28 ]
      }, {
        "text" : "OpenData",
        "indices" : [ 84, 93 ]
      }, {
        "text" : "OpenScience",
        "indices" : [ 94, 106 ]
      }, {
        "text" : "OpenSource",
        "indices" : [ 107, 118 ]
      }, {
        "text" : "DigitalAge",
        "indices" : [ 119, 130 ]
      } ],
      "urls" : [ {
        "indices" : [ 61, 83 ],
        "url" : "http:\/\/t.co\/Ek5BhHq2Lx",
        "expanded_url" : "http:\/\/buff.ly\/1AY3MzM",
        "display_url" : "buff.ly\/1AY3MzM"
      } ]
    },
    "geo" : { },
    "id_str" : "609355807872917504",
    "text" : "Why we need to put #openness at the heart of the Digital Age http:\/\/t.co\/Ek5BhHq2Lx #OpenData #OpenScience #OpenSource #DigitalAge",
    "id" : 609355807872917504,
    "created_at" : "2015-06-12 13:45:20 +0000",
    "user" : {
      "name" : "DNAdigest.org",
      "screen_name" : "DNADigest",
      "protected" : false,
      "id_str" : "334912047",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/430707142232772608\/Vmx-V5fY_normal.png",
      "id" : 334912047,
      "verified" : false
    }
  },
  "id" : 609356798269767680,
  "created_at" : "2015-06-12 13:49:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17215855786449, 8.627658412746902 ]
  },
  "id_str" : "609348127406034944",
  "text" : "Maybe I should have re-read my own abstract before starting to work on this poster. Back to square one\u2026",
  "id" : 609348127406034944,
  "created_at" : "2015-06-12 13:14:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Torsten Seemann",
      "screen_name" : "torstenseemann",
      "indices" : [ 0, 15 ],
      "id_str" : "42558652",
      "id" : 42558652
    }, {
      "name" : "Mick Watson",
      "screen_name" : "BioMickWatson",
      "indices" : [ 16, 30 ],
      "id_str" : "228586748",
      "id" : 228586748
    }, {
      "name" : "\u24EA Rik Smith-Unna \uD83C\uDDF0\uD83C\uDDEA",
      "screen_name" : "blahah404",
      "indices" : [ 31, 41 ],
      "id_str" : "99173786",
      "id" : 99173786
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "609345817950851073",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17225172176496, 8.627582608982612 ]
  },
  "id_str" : "609346647835975680",
  "in_reply_to_user_id" : 42558652,
  "text" : "@torstenseemann @BioMickWatson @blahah404 well, for perl it\u2019s cpan and then typing \u201CY\u201D or pressing enter a thousand times before it crashes.",
  "id" : 609346647835975680,
  "in_reply_to_status_id" : 609345817950851073,
  "created_at" : "2015-06-12 13:08:56 +0000",
  "in_reply_to_screen_name" : "torstenseemann",
  "in_reply_to_user_id_str" : "42558652",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "609342709522919425",
  "geo" : { },
  "id_str" : "609343109990887425",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer ack, wonder whether it's a strand\/version-problem somewhere. Feel free to try yourself at some time. Saw the link to the wiki?",
  "id" : 609343109990887425,
  "in_reply_to_status_id" : 609342709522919425,
  "created_at" : "2015-06-12 12:54:53 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/609341549630107649\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/WZjifRqZKY",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CHTQ6P2WwAAHNTo.png",
      "id_str" : "609341548707364864",
      "id" : 609341548707364864,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHTQ6P2WwAAHNTo.png",
      "sizes" : [ {
        "h" : 773,
        "resize" : "fit",
        "w" : 1398
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 773,
        "resize" : "fit",
        "w" : 1398
      }, {
        "h" : 376,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 664,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/WZjifRqZKY"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "609340735297597440",
  "geo" : { },
  "id_str" : "609341549630107649",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer will try. Also: w\/ -m 0 you see that some hapmap inds clus w\/ our high dens cloud if turn down alpha ;) http:\/\/t.co\/WZjifRqZKY",
  "id" : 609341549630107649,
  "in_reply_to_status_id" : 609340735297597440,
  "created_at" : "2015-06-12 12:48:41 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "609339891881758720",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17217901721672, 8.62763264504874 ]
  },
  "id_str" : "609340080851918848",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer yeah, so the last plot I sent was w\/ -m 0, so no outlier detection. But can do w\/o -m and instead use -s.",
  "id" : 609340080851918848,
  "in_reply_to_status_id" : 609339891881758720,
  "created_at" : "2015-06-12 12:42:50 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "609339375164518400",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17217901721672, 8.62763264504874 ]
  },
  "id_str" : "609339562406641664",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer w\/ or w\/o -m 0? (too lazy to look up what -s actually does :D)",
  "id" : 609339562406641664,
  "in_reply_to_status_id" : 609339375164518400,
  "created_at" : "2015-06-12 12:40:47 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 39 ],
      "url" : "http:\/\/t.co\/8QAFzhHw1Z",
      "expanded_url" : "http:\/\/stream1.gifsoup.com\/view7\/3290492\/vocal-cords-o.gif",
      "display_url" : "stream1.gifsoup.com\/view7\/3290492\/\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "609336272495185920",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17216140115678, 8.627644044885049 ]
  },
  "id_str" : "609337608657891328",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot more like http:\/\/t.co\/8QAFzhHw1Z",
  "id" : 609337608657891328,
  "in_reply_to_status_id" : 609336272495185920,
  "created_at" : "2015-06-12 12:33:01 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17230795380695, 8.627550600739598 ]
  },
  "id_str" : "609333251157676032",
  "text" : "Lovely, in 10 days I\u2019ll know whether my travel plans for July will need a serious overhaul.",
  "id" : 609333251157676032,
  "created_at" : "2015-06-12 12:15:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/609323704074543104\/photo\/1",
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/3erElma4SI",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CHTArfcXAAAiq7B.png",
      "id_str" : "609323703009214464",
      "id" : 609323703009214464,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHTArfcXAAAiq7B.png",
      "sizes" : [ {
        "h" : 773,
        "resize" : "fit",
        "w" : 1398
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 773,
        "resize" : "fit",
        "w" : 1398
      }, {
        "h" : 376,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 664,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/3erElma4SI"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "609311422867243009",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17220630937199, 8.627634726847287 ]
  },
  "id_str" : "609323704074543104",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer outlier-detection kicked those data sets out, amongst others all Yoruba ind. w\/o removal: http:\/\/t.co\/3erElma4SI",
  "id" : 609323704074543104,
  "in_reply_to_status_id" : 609311422867243009,
  "created_at" : "2015-06-12 11:37:46 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "609311422867243009",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17225398613846, 8.627590089550798 ]
  },
  "id_str" : "609320826819772416",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer smartpca kicked out 90 ppl from hapmap, atm not sure why though.",
  "id" : 609320826819772416,
  "in_reply_to_status_id" : 609311422867243009,
  "created_at" : "2015-06-12 11:26:20 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul-Olivier Dehaye",
      "screen_name" : "podehaye",
      "indices" : [ 3, 12 ],
      "id_str" : "2219841242",
      "id" : 2219841242
    }, {
      "name" : "Melissa Gymrek",
      "screen_name" : "mgymrek",
      "indices" : [ 72, 80 ],
      "id_str" : "48306404",
      "id" : 48306404
    }, {
      "name" : "Yaniv (((Erlich)))",
      "screen_name" : "erlichya",
      "indices" : [ 83, 92 ],
      "id_str" : "495517322",
      "id" : 495517322
    }, {
      "name" : "David Golumbia",
      "screen_name" : "dgolumbia",
      "indices" : [ 124, 134 ],
      "id_str" : "14304930",
      "id" : 14304930
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/JIweGqJWoj",
      "expanded_url" : "https:\/\/github.com\/pdehaye\/genomic_surname_inference",
      "display_url" : "github.com\/pdehaye\/genomi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "609319869423702016",
  "text" : "RT @podehaye: Find the last name from a genome! My scripts to replicate @mgymrek + @erlichya attack https:\/\/t.co\/JIweGqJWoj @dgolumbia @ged\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Melissa Gymrek",
        "screen_name" : "mgymrek",
        "indices" : [ 58, 66 ],
        "id_str" : "48306404",
        "id" : 48306404
      }, {
        "name" : "Yaniv (((Erlich)))",
        "screen_name" : "erlichya",
        "indices" : [ 69, 78 ],
        "id_str" : "495517322",
        "id" : 495517322
      }, {
        "name" : "David Golumbia",
        "screen_name" : "dgolumbia",
        "indices" : [ 110, 120 ],
        "id_str" : "14304930",
        "id" : 14304930
      }, {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 121, 137 ],
        "id_str" : "14286491",
        "id" : 14286491
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 86, 109 ],
        "url" : "https:\/\/t.co\/JIweGqJWoj",
        "expanded_url" : "https:\/\/github.com\/pdehaye\/genomic_surname_inference",
        "display_url" : "github.com\/pdehaye\/genomi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "609305058690400256",
    "text" : "Find the last name from a genome! My scripts to replicate @mgymrek + @erlichya attack https:\/\/t.co\/JIweGqJWoj @dgolumbia @gedankenstuecke",
    "id" : 609305058690400256,
    "created_at" : "2015-06-12 10:23:40 +0000",
    "user" : {
      "name" : "Paul-Olivier Dehaye",
      "screen_name" : "podehaye",
      "protected" : false,
      "id_str" : "2219841242",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/840965162349797376\/7hdkcm04_normal.jpg",
      "id" : 2219841242,
      "verified" : false
    }
  },
  "id" : 609319869423702016,
  "created_at" : "2015-06-12 11:22:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "609310180661161984",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17229298265492, 8.627542486665638 ]
  },
  "id_str" : "609317169340514305",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer yeah, I know. That\u2019s what puzzles me. According to log files all 270 hapmap individuals passed the QC\/filters.",
  "id" : 609317169340514305,
  "in_reply_to_status_id" : 609310180661161984,
  "created_at" : "2015-06-12 11:11:48 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 51 ],
      "url" : "https:\/\/t.co\/xv1CYXMABl",
      "expanded_url" : "https:\/\/instagram.com\/p\/30tjasBwtb\/",
      "display_url" : "instagram.com\/p\/30tjasBwtb\/"
    } ]
  },
  "geo" : { },
  "id_str" : "609287087263752192",
  "text" : "Getting closer to the brain https:\/\/t.co\/xv1CYXMABl",
  "id" : 609287087263752192,
  "created_at" : "2015-06-12 09:12:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 67, 80 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/609281520839340032\/photo\/1",
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/9LmaMtHEft",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CHSaUGuW8AAmFBM.png",
      "id_str" : "609281519794974720",
      "id" : 609281519794974720,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHSaUGuW8AAmFBM.png",
      "sizes" : [ {
        "h" : 726,
        "resize" : "fit",
        "w" : 704
      }, {
        "h" : 726,
        "resize" : "fit",
        "w" : 704
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 659
      }, {
        "h" : 726,
        "resize" : "fit",
        "w" : 704
      } ],
      "display_url" : "pic.twitter.com\/9LmaMtHEft"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17230645149495, 8.627514519564828 ]
  },
  "id_str" : "609281520839340032",
  "text" : "Kind of sure that I did something wrong when running this PCA. \/cc @PhilippBayer http:\/\/t.co\/9LmaMtHEft",
  "id" : 609281520839340032,
  "created_at" : "2015-06-12 08:50:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/RIOd5xxZrl",
      "expanded_url" : "http:\/\/www.sporkful.com\/beyond-pot-brownies-with-radiolabs-jad-abumrad\/",
      "display_url" : "sporkful.com\/beyond-pot-bro\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "609249113276858368",
  "text" : "\u00ABI went into thinking \u2018I better get these guys high\u2019, I overachieved a bit I think.\u00BB http:\/\/t.co\/RIOd5xxZrl",
  "id" : 609249113276858368,
  "created_at" : "2015-06-12 06:41:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "609230373487296512",
  "geo" : { },
  "id_str" : "609245480279740416",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch just trying to please. ;)",
  "id" : 609245480279740416,
  "in_reply_to_status_id" : 609230373487296512,
  "created_at" : "2015-06-12 06:26:56 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Song Exploder",
      "screen_name" : "SongExploder",
      "indices" : [ 17, 30 ],
      "id_str" : "2249590315",
      "id" : 2249590315
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 122, 144 ],
      "url" : "http:\/\/t.co\/s9tuLjyW6t",
      "expanded_url" : "http:\/\/99percentinvisible.org\/episode\/all-in-your-head\/",
      "display_url" : "99percentinvisible.org\/episode\/all-in\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.49980717815551, 7.488631494908501 ]
  },
  "id_str" : "609226940793364480",
  "text" : "Already knew the @SongExploder episode featured in the last 99pi. Still listened through &amp; cried just like first time http:\/\/t.co\/s9tuLjyW6t",
  "id" : 609226940793364480,
  "created_at" : "2015-06-12 05:13:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Seth D. Michaels \uD83C\uDF32",
      "screen_name" : "sethdmichaels",
      "indices" : [ 3, 17 ],
      "id_str" : "14477723",
      "id" : 14477723
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "609121274640625664",
  "text" : "RT @sethdmichaels: extremely optimistic NYT illustration has a guy in a driverless car reading a print-edition newspaper http:\/\/t.co\/H4qxSA\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/sethdmichaels\/status\/609092371695955970\/photo\/1",
        "indices" : [ 102, 124 ],
        "url" : "http:\/\/t.co\/H4qxSACRhx",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CHPuMA0UgAA_eBa.jpg",
        "id_str" : "609092264770437120",
        "id" : 609092264770437120,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHPuMA0UgAA_eBa.jpg",
        "sizes" : [ {
          "h" : 680,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/H4qxSACRhx"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "609092371695955970",
    "text" : "extremely optimistic NYT illustration has a guy in a driverless car reading a print-edition newspaper http:\/\/t.co\/H4qxSACRhx",
    "id" : 609092371695955970,
    "created_at" : "2015-06-11 20:18:32 +0000",
    "user" : {
      "name" : "Seth D. Michaels \uD83C\uDF32",
      "screen_name" : "sethdmichaels",
      "protected" : false,
      "id_str" : "14477723",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/903222754555682817\/lQGK7dXj_normal.jpg",
      "id" : 14477723,
      "verified" : true
    }
  },
  "id" : 609121274640625664,
  "created_at" : "2015-06-11 22:13:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "609116846718103552",
  "geo" : { },
  "id_str" : "609117689693532160",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer lots of people now publish stuff but aren\u2019t aware that we have the paper out now.",
  "id" : 609117689693532160,
  "in_reply_to_status_id" : 609116846718103552,
  "created_at" : "2015-06-11 21:59:08 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "609116846718103552",
  "geo" : { },
  "id_str" : "609117597003583490",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer v1 didn\u2019t cite us, that\u2019s the main diff to v2, saw it just in time to nudge to our paper. drawback of the 2-year peer review",
  "id" : 609117597003583490,
  "in_reply_to_status_id" : 609116846718103552,
  "created_at" : "2015-06-11 21:58:46 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul-Olivier Dehaye",
      "screen_name" : "podehaye",
      "indices" : [ 0, 9 ],
      "id_str" : "2219841242",
      "id" : 2219841242
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 10, 23 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 69 ],
      "url" : "https:\/\/t.co\/LYL8Y4Dyhy",
      "expanded_url" : "https:\/\/groups.google.com\/forum\/#!forum\/snpr-development",
      "display_url" : "groups.google.com\/forum\/#!forum\/\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "609110043355717633",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.49980433775378, 7.488626532927446 ]
  },
  "id_str" : "609110226843910144",
  "in_reply_to_user_id" : 2219841242,
  "text" : "@podehaye @PhilippBayer you can sign up here: https:\/\/t.co\/LYL8Y4Dyhy :)",
  "id" : 609110226843910144,
  "in_reply_to_status_id" : 609110043355717633,
  "created_at" : "2015-06-11 21:29:29 +0000",
  "in_reply_to_screen_name" : "podehaye",
  "in_reply_to_user_id_str" : "2219841242",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul-Olivier Dehaye",
      "screen_name" : "podehaye",
      "indices" : [ 0, 9 ],
      "id_str" : "2219841242",
      "id" : 2219841242
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 30, 43 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "609106625190875138",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.49981347973743, 7.488615133664836 ]
  },
  "id_str" : "609106872881295362",
  "in_reply_to_user_id" : 2219841242,
  "text" : "@podehaye that\u2019s interesting. @PhilippBayer just emailed some tips for making better use of 1000genomes. Are you on the openSNP-ML?",
  "id" : 609106872881295362,
  "in_reply_to_status_id" : 609106625190875138,
  "created_at" : "2015-06-11 21:16:09 +0000",
  "in_reply_to_screen_name" : "podehaye",
  "in_reply_to_user_id_str" : "2219841242",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Schawinski",
      "screen_name" : "kevinschawinski",
      "indices" : [ 0, 16 ],
      "id_str" : "242844365",
      "id" : 242844365
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "609096451487092737",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.49980330914909, 7.48862854237895 ]
  },
  "id_str" : "609096606596648962",
  "in_reply_to_user_id" : 242844365,
  "text" : "@kevinschawinski just making sure it\u2019s not only Jonah Lehrer ;)",
  "id" : 609096606596648962,
  "in_reply_to_status_id" : 609096451487092737,
  "created_at" : "2015-06-11 20:35:22 +0000",
  "in_reply_to_screen_name" : "kevinschawinski",
  "in_reply_to_user_id_str" : "242844365",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SFist",
      "screen_name" : "SFist",
      "indices" : [ 3, 9 ],
      "id_str" : "14093707",
      "id" : 14093707
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/SFist\/status\/609085619982065664\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/vtA5Vcv5nR",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CHPoJAMUIAAxb7v.jpg",
      "id_str" : "609085615993266176",
      "id" : 609085615993266176,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHPoJAMUIAAxb7v.jpg",
      "sizes" : [ {
        "h" : 389,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 389,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 389,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 389,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/vtA5Vcv5nR"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/Wo0pA8Q6qv",
      "expanded_url" : "http:\/\/sfist.com\/2015\/06\/11\/the_onion_suggests_san_francisco_sh.php",
      "display_url" : "sfist.com\/2015\/06\/11\/the\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "609096389159739394",
  "text" : "RT @SFist: The Onion suggest San Francisco should just move out of San Francisco already. http:\/\/t.co\/Wo0pA8Q6qv http:\/\/t.co\/vtA5Vcv5nR",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SFist\/status\/609085619982065664\/photo\/1",
        "indices" : [ 102, 124 ],
        "url" : "http:\/\/t.co\/vtA5Vcv5nR",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CHPoJAMUIAAxb7v.jpg",
        "id_str" : "609085615993266176",
        "id" : 609085615993266176,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHPoJAMUIAAxb7v.jpg",
        "sizes" : [ {
          "h" : 389,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 389,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 389,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 389,
          "resize" : "fit",
          "w" : 640
        } ],
        "display_url" : "pic.twitter.com\/vtA5Vcv5nR"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 79, 101 ],
        "url" : "http:\/\/t.co\/Wo0pA8Q6qv",
        "expanded_url" : "http:\/\/sfist.com\/2015\/06\/11\/the_onion_suggests_san_francisco_sh.php",
        "display_url" : "sfist.com\/2015\/06\/11\/the\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "609085619982065664",
    "text" : "The Onion suggest San Francisco should just move out of San Francisco already. http:\/\/t.co\/Wo0pA8Q6qv http:\/\/t.co\/vtA5Vcv5nR",
    "id" : 609085619982065664,
    "created_at" : "2015-06-11 19:51:42 +0000",
    "user" : {
      "name" : "SFist",
      "screen_name" : "SFist",
      "protected" : false,
      "id_str" : "14093707",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/879728351719546881\/xGc8kr9t_normal.jpg",
      "id" : 14093707,
      "verified" : true
    }
  },
  "id" : 609096389159739394,
  "created_at" : "2015-06-11 20:34:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Schawinski",
      "screen_name" : "kevinschawinski",
      "indices" : [ 0, 16 ],
      "id_str" : "242844365",
      "id" : 242844365
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "609096052717842432",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.49980523370439, 7.48862785581098 ]
  },
  "id_str" : "609096255789252609",
  "in_reply_to_user_id" : 242844365,
  "text" : "@kevinschawinski to whom are they talking about it?",
  "id" : 609096255789252609,
  "in_reply_to_status_id" : 609096052717842432,
  "created_at" : "2015-06-11 20:33:58 +0000",
  "in_reply_to_screen_name" : "kevinschawinski",
  "in_reply_to_user_id_str" : "242844365",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fiona Nielsen",
      "screen_name" : "glyn_dk",
      "indices" : [ 3, 11 ],
      "id_str" : "32340834",
      "id" : 32340834
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 50, 66 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/glyn_dk\/status\/609093783913918464\/photo\/1",
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/nDwOyl873B",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CHPvjtoWgAEvg1T.jpg",
      "id_str" : "609093771448451073",
      "id" : 609093771448451073,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHPvjtoWgAEvg1T.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 576
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 383
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 576
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 576
      } ],
      "display_url" : "pic.twitter.com\/nDwOyl873B"
    } ],
    "hashtags" : [ {
      "text" : "bioinformatics",
      "indices" : [ 22, 37 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "609094092736335872",
  "text" : "RT @glyn_dk: Advanced #bioinformatics pipeline by @gedankenstuecke @ Corpus http:\/\/t.co\/nDwOyl873B",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 37, 53 ],
        "id_str" : "14286491",
        "id" : 14286491
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/glyn_dk\/status\/609093783913918464\/photo\/1",
        "indices" : [ 63, 85 ],
        "url" : "http:\/\/t.co\/nDwOyl873B",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CHPvjtoWgAEvg1T.jpg",
        "id_str" : "609093771448451073",
        "id" : 609093771448451073,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHPvjtoWgAEvg1T.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 576
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 383
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 576
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 576
        } ],
        "display_url" : "pic.twitter.com\/nDwOyl873B"
      } ],
      "hashtags" : [ {
        "text" : "bioinformatics",
        "indices" : [ 9, 24 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "609093783913918464",
    "text" : "Advanced #bioinformatics pipeline by @gedankenstuecke @ Corpus http:\/\/t.co\/nDwOyl873B",
    "id" : 609093783913918464,
    "created_at" : "2015-06-11 20:24:09 +0000",
    "user" : {
      "name" : "Fiona Nielsen",
      "screen_name" : "glyn_dk",
      "protected" : false,
      "id_str" : "32340834",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3409523398\/35ae8a97e778ebb56089e9a9b58ab9b1_normal.png",
      "id" : 32340834,
      "verified" : false
    }
  },
  "id" : 609094092736335872,
  "created_at" : "2015-06-11 20:25:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fiona Nielsen",
      "screen_name" : "glyn_dk",
      "indices" : [ 0, 8 ],
      "id_str" : "32340834",
      "id" : 32340834
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GA4GH",
      "indices" : [ 70, 76 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "609093783913918464",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.49980624175987, 7.488629274659208 ]
  },
  "id_str" : "609094054018711552",
  "in_reply_to_user_id" : 32340834,
  "text" : "@glyn_dk this is what I shall show my supervisor when he asks how the #GA4GH meeting went. :-)",
  "id" : 609094054018711552,
  "in_reply_to_status_id" : 609093783913918464,
  "created_at" : "2015-06-11 20:25:13 +0000",
  "in_reply_to_screen_name" : "glyn_dk",
  "in_reply_to_user_id_str" : "32340834",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 3, 12 ],
      "id_str" : "14245811",
      "id" : 14245811
    }, {
      "name" : "Sage Bionetworks",
      "screen_name" : "Sagebio",
      "indices" : [ 84, 92 ],
      "id_str" : "130579391",
      "id" : 130579391
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/HEVlnslnsC",
      "expanded_url" : "http:\/\/www.nature.com\/nbt\/journal\/v33\/n6\/full\/nbt.3266.html",
      "display_url" : "nature.com\/nbt\/journal\/v3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "609088772358172673",
  "text" : "RT @wilbanks: The coming era of human phenotyping. Editorial in NatBiotech features @Sagebio mPower study. http:\/\/t.co\/HEVlnslnsC",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Sage Bionetworks",
        "screen_name" : "Sagebio",
        "indices" : [ 70, 78 ],
        "id_str" : "130579391",
        "id" : 130579391
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 93, 115 ],
        "url" : "http:\/\/t.co\/HEVlnslnsC",
        "expanded_url" : "http:\/\/www.nature.com\/nbt\/journal\/v33\/n6\/full\/nbt.3266.html",
        "display_url" : "nature.com\/nbt\/journal\/v3\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "609087211825442816",
    "text" : "The coming era of human phenotyping. Editorial in NatBiotech features @Sagebio mPower study. http:\/\/t.co\/HEVlnslnsC",
    "id" : 609087211825442816,
    "created_at" : "2015-06-11 19:58:02 +0000",
    "user" : {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "protected" : false,
      "id_str" : "14245811",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/925696899566440448\/BUTdp410_normal.jpg",
      "id" : 14245811,
      "verified" : false
    }
  },
  "id" : 609088772358172673,
  "created_at" : "2015-06-11 20:04:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 92, 101 ],
      "id_str" : "14245811",
      "id" : 14245811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "609087463689175040",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.49980558948542, 7.488614440757839 ]
  },
  "id_str" : "609088368236986368",
  "in_reply_to_user_id" : 14286491,
  "text" : "But I\u2019m happy with the headline that feels Casablanca (mistranslation)-inspired. After all, @wilbanks and I will always have Paris!",
  "id" : 609088368236986368,
  "in_reply_to_status_id" : 609087463689175040,
  "created_at" : "2015-06-11 20:02:37 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/VzznxifNgI",
      "expanded_url" : "https:\/\/twitter.com\/brembs\/status\/609040899822227456",
      "display_url" : "twitter.com\/brembs\/status\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "609087463689175040",
  "text" : "In which I'm once again trying to say that openSNP isn't Facebook-ish [interview in german, sry] https:\/\/t.co\/VzznxifNgI",
  "id" : 609087463689175040,
  "created_at" : "2015-06-11 19:59:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bj\u00F6rn Brembs",
      "screen_name" : "brembs",
      "indices" : [ 0, 7 ],
      "id_str" : "47876842",
      "id" : 47876842
    }, {
      "name" : "Laborjournal",
      "screen_name" : "Lab_Journal",
      "indices" : [ 8, 20 ],
      "id_str" : "1060480867",
      "id" : 1060480867
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "609040899822227456",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.4998069546798, 7.488604807170048 ]
  },
  "id_str" : "609087095316074496",
  "in_reply_to_user_id" : 47876842,
  "text" : "@brembs @Lab_Journal thanks, I hadn\u2019t seen that it\u2019s out :-)",
  "id" : 609087095316074496,
  "in_reply_to_status_id" : 609040899822227456,
  "created_at" : "2015-06-11 19:57:34 +0000",
  "in_reply_to_screen_name" : "brembs",
  "in_reply_to_user_id_str" : "47876842",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul-Olivier Dehaye",
      "screen_name" : "podehaye",
      "indices" : [ 0, 9 ],
      "id_str" : "2219841242",
      "id" : 2219841242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "609078072864833536",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.49983315523045, 7.488675855303223 ]
  },
  "id_str" : "609082813569204224",
  "in_reply_to_user_id" : 2219841242,
  "text" : "@podehaye nice! Really interested in what your results will be. Didn\u2019t find time to look into the data you mentioned so far :(",
  "id" : 609082813569204224,
  "in_reply_to_status_id" : 609078072864833536,
  "created_at" : "2015-06-11 19:40:33 +0000",
  "in_reply_to_screen_name" : "podehaye",
  "in_reply_to_user_id_str" : "2219841242",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 38 ],
      "url" : "https:\/\/t.co\/yLml6T8z0a",
      "expanded_url" : "https:\/\/instagram.com\/p\/3zO1RPBwqt\/",
      "display_url" : "instagram.com\/p\/3zO1RPBwqt\/"
    } ]
  },
  "geo" : { },
  "id_str" : "609078793995739136",
  "text" : "Nifty Nephrons https:\/\/t.co\/yLml6T8z0a",
  "id" : 609078793995739136,
  "created_at" : "2015-06-11 19:24:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 76 ],
      "url" : "https:\/\/t.co\/KW7JEsgeD9",
      "expanded_url" : "https:\/\/instagram.com\/p\/3zIh5dhwtr\/",
      "display_url" : "instagram.com\/p\/3zIh5dhwtr\/"
    } ]
  },
  "geo" : { },
  "id_str" : "609064934345961472",
  "text" : "The transhumanists cyborg dream: liver screening 2.0 https:\/\/t.co\/KW7JEsgeD9",
  "id" : 609064934345961472,
  "created_at" : "2015-06-11 18:29:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ga4gh",
      "indices" : [ 92, 98 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "609020214080983041",
  "text" : "Goodbye Leiden. I had a blast and look forward to my next visit. And thanks for hosting the #ga4gh",
  "id" : 609020214080983041,
  "created_at" : "2015-06-11 15:31:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "608998336348233728",
  "text" : "\u00ABLadies and gentleman, welcome to the uterus!\u00BB must be a hell of a job to announce this every 30 minutes.",
  "id" : 608998336348233728,
  "created_at" : "2015-06-11 14:04:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ed Yong",
      "screen_name" : "edyong209",
      "indices" : [ 3, 13 ],
      "id_str" : "19767193",
      "id" : 19767193
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/eOpnqB7t1Q",
      "expanded_url" : "http:\/\/io9.com\/its-raining-lampreys-in-fairbanks-alaska-1710475481",
      "display_url" : "io9.com\/its-raining-la\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "608978441497681920",
  "text" : "RT @edyong209: If I could choose a word to precede \u201Clampreys\u201D, \u201Craining\u201D would be near the bottom of the list http:\/\/t.co\/eOpnqB7t1Q",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 95, 117 ],
        "url" : "http:\/\/t.co\/eOpnqB7t1Q",
        "expanded_url" : "http:\/\/io9.com\/its-raining-lampreys-in-fairbanks-alaska-1710475481",
        "display_url" : "io9.com\/its-raining-la\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "608978251948650496",
    "text" : "If I could choose a word to precede \u201Clampreys\u201D, \u201Craining\u201D would be near the bottom of the list http:\/\/t.co\/eOpnqB7t1Q",
    "id" : 608978251948650496,
    "created_at" : "2015-06-11 12:45:04 +0000",
    "user" : {
      "name" : "Ed Yong",
      "screen_name" : "edyong209",
      "protected" : false,
      "id_str" : "19767193",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/926063794912153600\/962ygzzx_normal.jpg",
      "id" : 19767193,
      "verified" : true
    }
  },
  "id" : 608978441497681920,
  "created_at" : "2015-06-11 12:45:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 57 ],
      "url" : "http:\/\/t.co\/PloQXZhppC",
      "expanded_url" : "http:\/\/boingboing.net\/2015\/06\/10\/watch-gravity-illusions-on-st.html?utm_source=feedburner&utm_medium=feed&utm_campaign=Feed%3A+boingboing%2FiBag+%28Boing+Boing%29",
      "display_url" : "boingboing.net\/2015\/06\/10\/wat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "608975644744011776",
  "text" : "memo for the next time i'm in SF.  http:\/\/t.co\/PloQXZhppC",
  "id" : 608975644744011776,
  "created_at" : "2015-06-11 12:34:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "608972546596335616",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.10164717999998, 4.423704769999998 ]
  },
  "id_str" : "608974109284950016",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot the finest horse I've ever seen!",
  "id" : 608974109284950016,
  "in_reply_to_status_id" : 608972546596335616,
  "created_at" : "2015-06-11 12:28:36 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/gB7j6aXOA3",
      "expanded_url" : "https:\/\/instagram.com\/p\/3yfISuhwlN\/",
      "display_url" : "instagram.com\/p\/3yfISuhwlN\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.15699662, 4.485544727 ]
  },
  "id_str" : "608973894813405184",
  "text" : "Where the promotion ceremonies of Leiden happen. @ Academiegebouw Universiteit Leiden https:\/\/t.co\/gB7j6aXOA3",
  "id" : 608973894813405184,
  "created_at" : "2015-06-11 12:27:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 7, 29 ],
      "url" : "http:\/\/t.co\/gE4JgU8SHM",
      "expanded_url" : "http:\/\/33.media.tumblr.com\/tumblr_m1lp900UHq1rso7exo1_500.gif",
      "display_url" : "33.media.tumblr.com\/tumblr_m1lp900\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "608970760170954753",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.10164717999998, 4.423704769999998 ]
  },
  "id_str" : "608971721840947200",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot http:\/\/t.co\/gE4JgU8SHM",
  "id" : 608971721840947200,
  "in_reply_to_status_id" : 608970760170954753,
  "created_at" : "2015-06-11 12:19:07 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/W4ZNsuwlZl",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/608948621669740544",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "608969226565627904",
  "text" : "Even managed to get the tests to pass. Now I can call myself code ninja rockstar programmer, right? https:\/\/t.co\/W4ZNsuwlZl",
  "id" : 608969226565627904,
  "created_at" : "2015-06-11 12:09:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kriszta Berkes",
      "screen_name" : "KrisztaB",
      "indices" : [ 0, 9 ],
      "id_str" : "922402893411561472",
      "id" : 922402893411561472
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "608958259018526720",
  "geo" : { },
  "id_str" : "608958605119877120",
  "in_reply_to_user_id" : 19334473,
  "text" : "@Krisztab still training for that. ;)",
  "id" : 608958605119877120,
  "in_reply_to_status_id" : 608958259018526720,
  "created_at" : "2015-06-11 11:27:00 +0000",
  "in_reply_to_screen_name" : "kri_keziush",
  "in_reply_to_user_id_str" : "19334473",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kriszta Berkes",
      "screen_name" : "KrisztaB",
      "indices" : [ 3, 12 ],
      "id_str" : "922402893411561472",
      "id" : 922402893411561472
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 14, 30 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 54 ],
      "url" : "https:\/\/t.co\/VUMbSRIby2",
      "expanded_url" : "https:\/\/pbs.twimg.com\/media\/CHLJSOlUIAE3EF2.jpg:large",
      "display_url" : "pbs.twimg.com\/media\/CHLJSOlU\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "608958360176726016",
  "text" : "RT @Krisztab: @gedankenstuecke https:\/\/t.co\/VUMbSRIby2",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 0, 16 ],
        "id_str" : "14286491",
        "id" : 14286491
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 17, 40 ],
        "url" : "https:\/\/t.co\/VUMbSRIby2",
        "expanded_url" : "https:\/\/pbs.twimg.com\/media\/CHLJSOlUIAE3EF2.jpg:large",
        "display_url" : "pbs.twimg.com\/media\/CHLJSOlU\u2026"
      } ]
    },
    "in_reply_to_status_id_str" : "608697452443660288",
    "geo" : { },
    "id_str" : "608958259018526720",
    "in_reply_to_user_id" : 14286491,
    "text" : "@gedankenstuecke https:\/\/t.co\/VUMbSRIby2",
    "id" : 608958259018526720,
    "in_reply_to_status_id" : 608697452443660288,
    "created_at" : "2015-06-11 11:25:37 +0000",
    "in_reply_to_screen_name" : "gedankenstuecke",
    "in_reply_to_user_id_str" : "14286491",
    "user" : {
      "name" : "Kriszta Kezia V",
      "screen_name" : "kri_keziush",
      "protected" : false,
      "id_str" : "19334473",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/836703338775343104\/tM-WE4G6_normal.jpg",
      "id" : 19334473,
      "verified" : false
    }
  },
  "id" : 608958360176726016,
  "created_at" : "2015-06-11 11:26:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 58 ],
      "url" : "https:\/\/t.co\/DuwsRp2QLC",
      "expanded_url" : "https:\/\/instagram.com\/p\/3yW6XBhwog\/",
      "display_url" : "instagram.com\/p\/3yW6XBhwog\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.157593146, 4.487654399 ]
  },
  "id_str" : "608955823348428800",
  "text" : "deconsecrated @ Pieterskerk Leiden https:\/\/t.co\/DuwsRp2QLC",
  "id" : 608955823348428800,
  "created_at" : "2015-06-11 11:15:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/irItl0Js4j",
      "expanded_url" : "http:\/\/media.247sports.com\/Uploads\/Assets\/166\/952\/2952166.jpg",
      "display_url" : "media.247sports.com\/Uploads\/Assets\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "608948436898037760",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.17066523139299, 4.453758801574793 ]
  },
  "id_str" : "608948621669740544",
  "in_reply_to_user_id" : 14286491,
  "text" : "@helgerausch I even tried to write a test for it, but you know how it is: http:\/\/t.co\/irItl0Js4j",
  "id" : 608948621669740544,
  "in_reply_to_status_id" : 608948436898037760,
  "created_at" : "2015-06-11 10:47:19 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 6, 18 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ga4gh",
      "indices" : [ 67, 73 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/IuXZ639gkQ",
      "expanded_url" : "https:\/\/github.com\/gedankenstuecke\/snpr\/tree\/beacon",
      "display_url" : "github.com\/gedankenstueck\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.17066523139299, 4.453758801574793 ]
  },
  "id_str" : "608948436898037760",
  "text" : "Okay, @helgerausch will probably cry, but I tried to implement the #ga4gh Beacon into openSNP https:\/\/t.co\/IuXZ639gkQ",
  "id" : 608948436898037760,
  "created_at" : "2015-06-11 10:46:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arikia\uD83D\uDCAB",
      "screen_name" : "arikia",
      "indices" : [ 0, 7 ],
      "id_str" : "71654283",
      "id" : 71654283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "608913797630320640",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.1706604134362, 4.453774588673395 ]
  },
  "id_str" : "608914007693602816",
  "in_reply_to_user_id" : 71654283,
  "text" : "@arikia have plenty of first-hand experience with the phenomenon but totally wasn\u2019t ware that it\u2019s a thing!",
  "id" : 608914007693602816,
  "in_reply_to_status_id" : 608913797630320640,
  "created_at" : "2015-06-11 08:29:47 +0000",
  "in_reply_to_screen_name" : "arikia",
  "in_reply_to_user_id_str" : "71654283",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert Krause",
      "screen_name" : "euleule",
      "indices" : [ 0, 8 ],
      "id_str" : "563152502",
      "id" : 563152502
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 31 ],
      "url" : "http:\/\/t.co\/g6x2UV4GaB",
      "expanded_url" : "http:\/\/i.imgur.com\/8eQqot7.gif",
      "display_url" : "i.imgur.com\/8eQqot7.gif"
    } ]
  },
  "in_reply_to_status_id_str" : "608911410479947777",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.17066147261598, 4.453761139972145 ]
  },
  "id_str" : "608911872377663488",
  "in_reply_to_user_id" : 563152502,
  "text" : "@euleule http:\/\/t.co\/g6x2UV4GaB",
  "id" : 608911872377663488,
  "in_reply_to_status_id" : 608911410479947777,
  "created_at" : "2015-06-11 08:21:18 +0000",
  "in_reply_to_screen_name" : "euleule",
  "in_reply_to_user_id_str" : "563152502",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arikia\uD83D\uDCAB",
      "screen_name" : "arikia",
      "indices" : [ 46, 53 ],
      "id_str" : "71654283",
      "id" : 71654283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/9kEs6Qj2ux",
      "expanded_url" : "https:\/\/www.beaconreader.com\/arikia-millikan\/czeching-in-from-prague?just_logged_in=true",
      "display_url" : "beaconreader.com\/arikia-millika\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "608902090975490048",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.17066577865217, 4.453774352844212 ]
  },
  "id_str" : "608902416449310720",
  "in_reply_to_user_id" : 14286491,
  "text" : "omg, thanks for introducing me to REM rebound @arikia. can\u2019t believe I never heard that before! https:\/\/t.co\/9kEs6Qj2ux",
  "id" : 608902416449310720,
  "in_reply_to_status_id" : 608902090975490048,
  "created_at" : "2015-06-11 07:43:43 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "608902090975490048",
  "text" : "\u00AByour brain makes up for the lack of REM sleep by cramming all the dreams you\u2019d been deprived of for days into a burst of grotesque chaos\u00BB",
  "id" : 608902090975490048,
  "created_at" : "2015-06-11 07:42:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dil\u00E2ra",
      "screen_name" : "DilaraGurcu",
      "indices" : [ 3, 15 ],
      "id_str" : "155175677",
      "id" : 155175677
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/DilaraGurcu\/status\/608598400272113664\/photo\/1",
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/obbeMI7rW4",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CHItAfWUgAA7vYR.jpg",
      "id_str" : "608598386086805504",
      "id" : 608598386086805504,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHItAfWUgAA7vYR.jpg",
      "sizes" : [ {
        "h" : 822,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 822,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 529
      }, {
        "h" : 822,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/obbeMI7rW4"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/DilaraGurcu\/status\/608598400272113664\/photo\/1",
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/obbeMI7rW4",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CHItAfVU0AEsfhK.jpg",
      "id_str" : "608598386082631681",
      "id" : 608598386082631681,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHItAfVU0AEsfhK.jpg",
      "sizes" : [ {
        "h" : 849,
        "resize" : "fit",
        "w" : 637
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 849,
        "resize" : "fit",
        "w" : 637
      }, {
        "h" : 849,
        "resize" : "fit",
        "w" : 637
      } ],
      "display_url" : "pic.twitter.com\/obbeMI7rW4"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/DilaraGurcu\/status\/608598400272113664\/photo\/1",
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/obbeMI7rW4",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CHItAfYVIAARS2-.jpg",
      "id_str" : "608598386095235072",
      "id" : 608598386095235072,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHItAfYVIAARS2-.jpg",
      "sizes" : [ {
        "h" : 841,
        "resize" : "fit",
        "w" : 636
      }, {
        "h" : 841,
        "resize" : "fit",
        "w" : 636
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 514
      }, {
        "h" : 841,
        "resize" : "fit",
        "w" : 636
      } ],
      "display_url" : "pic.twitter.com\/obbeMI7rW4"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/DilaraGurcu\/status\/608598400272113664\/photo\/1",
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/obbeMI7rW4",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CHItAh_UUAMO3ne.jpg",
      "id_str" : "608598386795630595",
      "id" : 608598386795630595,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHItAh_UUAMO3ne.jpg",
      "sizes" : [ {
        "h" : 798,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 798,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 545
      }, {
        "h" : 798,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/obbeMI7rW4"
    } ],
    "hashtags" : [ {
      "text" : "distractinglysexy",
      "indices" : [ 17, 35 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "608901484479148032",
  "text" : "RT @DilaraGurcu: #distractinglysexy women scientists all around the world are preventing men to do science \uD83D\uDE31 http:\/\/t.co\/obbeMI7rW4",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/DilaraGurcu\/status\/608598400272113664\/photo\/1",
        "indices" : [ 92, 114 ],
        "url" : "http:\/\/t.co\/obbeMI7rW4",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CHItAfWUgAA7vYR.jpg",
        "id_str" : "608598386086805504",
        "id" : 608598386086805504,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHItAfWUgAA7vYR.jpg",
        "sizes" : [ {
          "h" : 822,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 822,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 529
        }, {
          "h" : 822,
          "resize" : "fit",
          "w" : 640
        } ],
        "display_url" : "pic.twitter.com\/obbeMI7rW4"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/DilaraGurcu\/status\/608598400272113664\/photo\/1",
        "indices" : [ 92, 114 ],
        "url" : "http:\/\/t.co\/obbeMI7rW4",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CHItAfVU0AEsfhK.jpg",
        "id_str" : "608598386082631681",
        "id" : 608598386082631681,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHItAfVU0AEsfhK.jpg",
        "sizes" : [ {
          "h" : 849,
          "resize" : "fit",
          "w" : 637
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 510
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 849,
          "resize" : "fit",
          "w" : 637
        }, {
          "h" : 849,
          "resize" : "fit",
          "w" : 637
        } ],
        "display_url" : "pic.twitter.com\/obbeMI7rW4"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/DilaraGurcu\/status\/608598400272113664\/photo\/1",
        "indices" : [ 92, 114 ],
        "url" : "http:\/\/t.co\/obbeMI7rW4",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CHItAfYVIAARS2-.jpg",
        "id_str" : "608598386095235072",
        "id" : 608598386095235072,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHItAfYVIAARS2-.jpg",
        "sizes" : [ {
          "h" : 841,
          "resize" : "fit",
          "w" : 636
        }, {
          "h" : 841,
          "resize" : "fit",
          "w" : 636
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 514
        }, {
          "h" : 841,
          "resize" : "fit",
          "w" : 636
        } ],
        "display_url" : "pic.twitter.com\/obbeMI7rW4"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/DilaraGurcu\/status\/608598400272113664\/photo\/1",
        "indices" : [ 92, 114 ],
        "url" : "http:\/\/t.co\/obbeMI7rW4",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CHItAh_UUAMO3ne.jpg",
        "id_str" : "608598386795630595",
        "id" : 608598386795630595,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHItAh_UUAMO3ne.jpg",
        "sizes" : [ {
          "h" : 798,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 798,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 545
        }, {
          "h" : 798,
          "resize" : "fit",
          "w" : 640
        } ],
        "display_url" : "pic.twitter.com\/obbeMI7rW4"
      } ],
      "hashtags" : [ {
        "text" : "distractinglysexy",
        "indices" : [ 0, 18 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "608598400272113664",
    "text" : "#distractinglysexy women scientists all around the world are preventing men to do science \uD83D\uDE31 http:\/\/t.co\/obbeMI7rW4",
    "id" : 608598400272113664,
    "created_at" : "2015-06-10 11:35:40 +0000",
    "user" : {
      "name" : "dil\u00E2ra",
      "screen_name" : "DilaraGurcu",
      "protected" : false,
      "id_str" : "155175677",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/915156397511364608\/_RrdhuWY_normal.jpg",
      "id" : 155175677,
      "verified" : true
    }
  },
  "id" : 608901484479148032,
  "created_at" : "2015-06-11 07:40:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ga4gh",
      "indices" : [ 64, 70 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.17066392155981, 4.453774977840429 ]
  },
  "id_str" : "608899274395516928",
  "text" : "After we\u2019ve heard and talked so much about lack of diversity in #ga4gh: What about calling the participants GWASPs?",
  "id" : 608899274395516928,
  "created_at" : "2015-06-11 07:31:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Croucher",
      "screen_name" : "walkingrandomly",
      "indices" : [ 3, 19 ],
      "id_str" : "92746008",
      "id" : 92746008
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 77 ],
      "url" : "https:\/\/t.co\/7b0T5OHWvV",
      "expanded_url" : "https:\/\/gist.github.com\/fmeyer\/289467",
      "display_url" : "gist.github.com\/fmeyer\/289467"
    } ]
  },
  "geo" : { },
  "id_str" : "608892216724086784",
  "text" : "RT @walkingrandomly: Evolution of a Python Programmer https:\/\/t.co\/7b0T5OHWvV",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 33, 56 ],
        "url" : "https:\/\/t.co\/7b0T5OHWvV",
        "expanded_url" : "https:\/\/gist.github.com\/fmeyer\/289467",
        "display_url" : "gist.github.com\/fmeyer\/289467"
      } ]
    },
    "geo" : { },
    "id_str" : "608887654105624576",
    "text" : "Evolution of a Python Programmer https:\/\/t.co\/7b0T5OHWvV",
    "id" : 608887654105624576,
    "created_at" : "2015-06-11 06:45:03 +0000",
    "user" : {
      "name" : "Mike Croucher",
      "screen_name" : "walkingrandomly",
      "protected" : false,
      "id_str" : "92746008",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/928007729473564673\/tIyEHpge_normal.jpg",
      "id" : 92746008,
      "verified" : false
    }
  },
  "id" : 608892216724086784,
  "created_at" : "2015-06-11 07:03:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Phipps",
      "screen_name" : "lousylinguist",
      "indices" : [ 3, 17 ],
      "id_str" : "48459936",
      "id" : 48459936
    }, {
      "name" : "Vyv Evans",
      "screen_name" : "VyvEvans",
      "indices" : [ 90, 99 ],
      "id_str" : "2980898566",
      "id" : 2980898566
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/WRVJ0PmUAn",
      "expanded_url" : "http:\/\/thelousylinguist.blogspot.com\/2015\/06\/the-language-myth-book-review.html",
      "display_url" : "thelousylinguist.blogspot.com\/2015\/06\/the-la\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "608873016123109376",
  "text" : "RT @lousylinguist: My review of Vyv Evans' \"The Language Myth\" http:\/\/t.co\/WRVJ0PmUAn fyi @VyvEvans",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Vyv Evans",
        "screen_name" : "VyvEvans",
        "indices" : [ 71, 80 ],
        "id_str" : "2980898566",
        "id" : 2980898566
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 44, 66 ],
        "url" : "http:\/\/t.co\/WRVJ0PmUAn",
        "expanded_url" : "http:\/\/thelousylinguist.blogspot.com\/2015\/06\/the-language-myth-book-review.html",
        "display_url" : "thelousylinguist.blogspot.com\/2015\/06\/the-la\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "608810128721211392",
    "text" : "My review of Vyv Evans' \"The Language Myth\" http:\/\/t.co\/WRVJ0PmUAn fyi @VyvEvans",
    "id" : 608810128721211392,
    "created_at" : "2015-06-11 01:37:00 +0000",
    "user" : {
      "name" : "Christopher Phipps",
      "screen_name" : "lousylinguist",
      "protected" : false,
      "id_str" : "48459936",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/844677818059542528\/8TlFZR2D_normal.jpg",
      "id" : 48459936,
      "verified" : false
    }
  },
  "id" : 608873016123109376,
  "created_at" : "2015-06-11 05:46:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 41 ],
      "url" : "https:\/\/t.co\/UzKkP1ySvh",
      "expanded_url" : "https:\/\/instagram.com\/p\/3xKFQTBwlg\/",
      "display_url" : "instagram.com\/p\/3xKFQTBwlg\/"
    } ]
  },
  "geo" : { },
  "id_str" : "608786873322975233",
  "text" : "Am I being late?! https:\/\/t.co\/UzKkP1ySvh",
  "id" : 608786873322975233,
  "created_at" : "2015-06-11 00:04:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 45 ],
      "url" : "http:\/\/t.co\/5SE4CHDex3",
      "expanded_url" : "http:\/\/gawker.com\/barclays-banker-gives-interns-10-reasons-to-say-fuck-th-1708844001",
      "display_url" : "gawker.com\/barclays-banke\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "608786217551994880",
  "text" : "Isn't Barclays lovely? http:\/\/t.co\/5SE4CHDex3",
  "id" : 608786217551994880,
  "created_at" : "2015-06-11 00:01:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "608747478519808000",
  "text" : "\u00ABI thought this evening would be less emotional, after discussing ENCODE and Dawkins yesterday. And now we\u2019re back to World War 2\u2026\u00BB",
  "id" : 608747478519808000,
  "created_at" : "2015-06-10 21:28:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "608701917196333056",
  "geo" : { },
  "id_str" : "608702745944690688",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer still waiting for nanopore, but looking forward to it!",
  "id" : 608702745944690688,
  "in_reply_to_status_id" : 608701917196333056,
  "created_at" : "2015-06-10 18:30:18 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "608699094769520641",
  "geo" : { },
  "id_str" : "608699260863918080",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer ah, ok. Otherwise could have compared notes about our lessons learnt.",
  "id" : 608699260863918080,
  "in_reply_to_status_id" : 608699094769520641,
  "created_at" : "2015-06-10 18:16:27 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "608664321141436416",
  "geo" : { },
  "id_str" : "608698642099240960",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer you\u2019re also having PacBio data by now? :)",
  "id" : 608698642099240960,
  "in_reply_to_status_id" : 608664321141436416,
  "created_at" : "2015-06-10 18:14:00 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/608697452443660288\/photo\/1",
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/GpZJ08doYx",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CHKHGv_UkAAF8-R.jpg",
      "id_str" : "608697449679458304",
      "id" : 608697449679458304,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHKHGv_UkAAF8-R.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 583,
        "resize" : "fit",
        "w" : 750
      }, {
        "h" : 529,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 583,
        "resize" : "fit",
        "w" : 750
      }, {
        "h" : 583,
        "resize" : "fit",
        "w" : 750
      } ],
      "display_url" : "pic.twitter.com\/GpZJ08doYx"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "608697452443660288",
  "text" : "Running in the intertidal zone gives you funny GPS tracks. http:\/\/t.co\/GpZJ08doYx",
  "id" : 608697452443660288,
  "created_at" : "2015-06-10 18:09:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 39 ],
      "url" : "https:\/\/t.co\/a4qQmGijP3",
      "expanded_url" : "https:\/\/instagram.com\/p\/3wgx95Bwng\/",
      "display_url" : "instagram.com\/p\/3wgx95Bwng\/"
    } ]
  },
  "geo" : { },
  "id_str" : "608696051630006272",
  "text" : "Back to the Sea https:\/\/t.co\/a4qQmGijP3",
  "id" : 608696051630006272,
  "created_at" : "2015-06-10 18:03:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 34 ],
      "url" : "https:\/\/t.co\/wiPCUNKYb4",
      "expanded_url" : "https:\/\/instagram.com\/p\/3wfBC_BwkP\/",
      "display_url" : "instagram.com\/p\/3wfBC_BwkP\/"
    } ]
  },
  "geo" : { },
  "id_str" : "608692171076739072",
  "text" : "St. George https:\/\/t.co\/wiPCUNKYb4",
  "id" : 608692171076739072,
  "created_at" : "2015-06-10 17:48:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "608649912239181824",
  "geo" : { },
  "id_str" : "608650279991537664",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot oder Christina, die Chirurgin.",
  "id" : 608650279991537664,
  "in_reply_to_status_id" : 608649912239181824,
  "created_at" : "2015-06-10 15:01:49 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "608647277675212800",
  "geo" : { },
  "id_str" : "608649220401283073",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot das ist f\u00FCr Britta.",
  "id" : 608649220401283073,
  "in_reply_to_status_id" : 608647277675212800,
  "created_at" : "2015-06-10 14:57:36 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "608644845775810560",
  "geo" : { },
  "id_str" : "608646069661147136",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot dann h\u00E4tte zumindest Laura denn LKW fahren k\u00F6nnen? (Und Wilhelmine singt YMCA)",
  "id" : 608646069661147136,
  "in_reply_to_status_id" : 608644845775810560,
  "created_at" : "2015-06-10 14:45:05 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "608642754906861568",
  "geo" : { },
  "id_str" : "608644575847153665",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot mehr Paula f\u00E4hrt Panzer.",
  "id" : 608644575847153665,
  "in_reply_to_status_id" : 608642754906861568,
  "created_at" : "2015-06-10 14:39:09 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "608642471879430144",
  "geo" : { },
  "id_str" : "608642672224514049",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot wie gerne ich Henrik w\u00E4re.",
  "id" : 608642672224514049,
  "in_reply_to_status_id" : 608642471879430144,
  "created_at" : "2015-06-10 14:31:35 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "608638862873784320",
  "geo" : { },
  "id_str" : "608639673318174721",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot +\/-, nur etwas abgeranzter.",
  "id" : 608639673318174721,
  "in_reply_to_status_id" : 608638862873784320,
  "created_at" : "2015-06-10 14:19:40 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "608638108163256320",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.17066822498144, 4.453769854541842 ]
  },
  "id_str" : "608638462598766592",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot vor",
  "id" : 608638462598766592,
  "in_reply_to_status_id" : 608638108163256320,
  "created_at" : "2015-06-10 14:14:52 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "608630324365545472",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.17067883600821, 4.453777824443756 ]
  },
  "id_str" : "608637783297638400",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot lange stand direkt gegen\u00FCber ein Bagger der meinen Namen tr\u00E4gt.",
  "id" : 608637783297638400,
  "in_reply_to_status_id" : 608630324365545472,
  "created_at" : "2015-06-10 14:12:10 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ga4gh",
      "indices" : [ 133, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "608603874765754368",
  "text" : "\u00ABMain innovation in Genome sequencing seems to be adding zeroes: 1000Genomes, UK10K, 100K Genomes project, Million Veteran Program\u2026\u00BB #ga4gh",
  "id" : 608603874765754368,
  "created_at" : "2015-06-10 11:57:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "608602611646885888",
  "text" : "\u00ABIt\u2019s called Big O notation because that\u2019s the sound you make when you figure out the runtime of your algorithm.\u00BB",
  "id" : 608602611646885888,
  "created_at" : "2015-06-10 11:52:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul-Olivier Dehaye",
      "screen_name" : "podehaye",
      "indices" : [ 0, 9 ],
      "id_str" : "2219841242",
      "id" : 2219841242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "608585930908270593",
  "geo" : { },
  "id_str" : "608586690899402752",
  "in_reply_to_user_id" : 2219841242,
  "text" : "@podehaye ack, my point was pro-policy, but maybe taking it slow is at least partially beneficial?",
  "id" : 608586690899402752,
  "in_reply_to_status_id" : 608585930908270593,
  "created_at" : "2015-06-10 10:49:08 +0000",
  "in_reply_to_screen_name" : "podehaye",
  "in_reply_to_user_id_str" : "2219841242",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul-Olivier Dehaye",
      "screen_name" : "podehaye",
      "indices" : [ 0, 9 ],
      "id_str" : "2219841242",
      "id" : 2219841242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "608581935460429824",
  "geo" : { },
  "id_str" : "608582603571081217",
  "in_reply_to_user_id" : 2219841242,
  "text" : "@podehaye agreed. I\u2019m not sure how to solve this problem (or even whether it should be solved\/is a problem).",
  "id" : 608582603571081217,
  "in_reply_to_status_id" : 608581935460429824,
  "created_at" : "2015-06-10 10:32:54 +0000",
  "in_reply_to_screen_name" : "podehaye",
  "in_reply_to_user_id_str" : "2219841242",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/608580287371571200\/photo\/1",
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/F8WgTCZNrm",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CHIci_-W0AA6hhg.jpg",
      "id_str" : "608580287262543872",
      "id" : 608580287262543872,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHIci_-W0AA6hhg.jpg",
      "sizes" : [ {
        "h" : 680,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 1307,
        "resize" : "fit",
        "w" : 1307
      }, {
        "h" : 1307,
        "resize" : "fit",
        "w" : 1307
      } ],
      "display_url" : "pic.twitter.com\/F8WgTCZNrm"
    } ],
    "hashtags" : [ {
      "text" : "ga4gh",
      "indices" : [ 71, 77 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.170666, 4.453778 ]
  },
  "id_str" : "608580287371571200",
  "text" : "Part of my notes from the ontology workshop that took place yesterday. #ga4gh http:\/\/t.co\/F8WgTCZNrm",
  "id" : 608580287371571200,
  "created_at" : "2015-06-10 10:23:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ga4gh",
      "indices" : [ 112, 118 ]
    }, {
      "text" : "annotation",
      "indices" : [ 119, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "608579086668193792",
  "text" : "Surprising to me: In some cases NLP for data extraction works better than forcing MDs to enter discrete values. #ga4gh #annotation",
  "id" : 608579086668193792,
  "created_at" : "2015-06-10 10:18:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GA4GH",
      "indices" : [ 33, 39 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "608576431371730944",
  "text" : "\u00ABThere\u2019s an epidemic of -omics.\u00BB #GA4GH",
  "id" : 608576431371730944,
  "created_at" : "2015-06-10 10:08:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul-Olivier Dehaye",
      "screen_name" : "podehaye",
      "indices" : [ 0, 9 ],
      "id_str" : "2219841242",
      "id" : 2219841242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "608574740706504704",
  "geo" : { },
  "id_str" : "608575210418270208",
  "in_reply_to_user_id" : 2219841242,
  "text" : "@podehaye yes, think the problem here is how much out of sync the pace of changes is between tech &amp; policy.",
  "id" : 608575210418270208,
  "in_reply_to_status_id" : 608574740706504704,
  "created_at" : "2015-06-10 10:03:31 +0000",
  "in_reply_to_screen_name" : "podehaye",
  "in_reply_to_user_id_str" : "2219841242",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "simine vazire",
      "screen_name" : "siminevazire",
      "indices" : [ 3, 16 ],
      "id_str" : "836548849",
      "id" : 836548849
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/siminevazire\/status\/608271431265357825\/photo\/1",
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/x6iB1yYqcj",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CHEDmuiUQAAfnXa.jpg",
      "id_str" : "608271388533604352",
      "id" : 608271388533604352,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHEDmuiUQAAfnXa.jpg",
      "sizes" : [ {
        "h" : 680,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/x6iB1yYqcj"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/eFhwooBHAt",
      "expanded_url" : "http:\/\/sometimesimwrong.typepad.com\/wrong\/2015\/06\/why-p-048-should-be-rare-and-why-this-feels-counterintuitive.html",
      "display_url" : "sometimesimwrong.typepad.com\/wrong\/2015\/06\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "608574742908563456",
  "text" : "RT @siminevazire: new blog post: why p = .048 should be rare, the 'for dummies' version http:\/\/t.co\/eFhwooBHAt http:\/\/t.co\/x6iB1yYqcj",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/siminevazire\/status\/608271431265357825\/photo\/1",
        "indices" : [ 93, 115 ],
        "url" : "http:\/\/t.co\/x6iB1yYqcj",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CHEDmuiUQAAfnXa.jpg",
        "id_str" : "608271388533604352",
        "id" : 608271388533604352,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHEDmuiUQAAfnXa.jpg",
        "sizes" : [ {
          "h" : 680,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/x6iB1yYqcj"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 70, 92 ],
        "url" : "http:\/\/t.co\/eFhwooBHAt",
        "expanded_url" : "http:\/\/sometimesimwrong.typepad.com\/wrong\/2015\/06\/why-p-048-should-be-rare-and-why-this-feels-counterintuitive.html",
        "display_url" : "sometimesimwrong.typepad.com\/wrong\/2015\/06\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "608271431265357825",
    "text" : "new blog post: why p = .048 should be rare, the 'for dummies' version http:\/\/t.co\/eFhwooBHAt http:\/\/t.co\/x6iB1yYqcj",
    "id" : 608271431265357825,
    "created_at" : "2015-06-09 13:56:25 +0000",
    "user" : {
      "name" : "simine vazire",
      "screen_name" : "siminevazire",
      "protected" : false,
      "id_str" : "836548849",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/592128718656516097\/3tBnCOCs_normal.jpg",
      "id" : 836548849,
      "verified" : false
    }
  },
  "id" : 608574742908563456,
  "created_at" : "2015-06-10 10:01:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul-Olivier Dehaye",
      "screen_name" : "podehaye",
      "indices" : [ 0, 9 ],
      "id_str" : "2219841242",
      "id" : 2219841242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "608566210939228160",
  "geo" : { },
  "id_str" : "608574107169529856",
  "in_reply_to_user_id" : 2219841242,
  "text" : "@podehaye yes, the point was that the timing is bad if you try to create a unified privacy- &amp; consent-framework right now.",
  "id" : 608574107169529856,
  "in_reply_to_status_id" : 608566210939228160,
  "created_at" : "2015-06-10 09:59:08 +0000",
  "in_reply_to_screen_name" : "podehaye",
  "in_reply_to_user_id_str" : "2219841242",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul-Olivier Dehaye",
      "screen_name" : "podehaye",
      "indices" : [ 3, 12 ],
      "id_str" : "2219841242",
      "id" : 2219841242
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 14, 30 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "608566358448680960",
  "text" : "RT @podehaye: @gedankenstuecke Also known as an opportunity",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 0, 16 ],
        "id_str" : "14286491",
        "id" : 14286491
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "608566062607704064",
    "geo" : { },
    "id_str" : "608566210939228160",
    "in_reply_to_user_id" : 14286491,
    "text" : "@gedankenstuecke Also known as an opportunity",
    "id" : 608566210939228160,
    "in_reply_to_status_id" : 608566062607704064,
    "created_at" : "2015-06-10 09:27:45 +0000",
    "in_reply_to_screen_name" : "gedankenstuecke",
    "in_reply_to_user_id_str" : "14286491",
    "user" : {
      "name" : "Paul-Olivier Dehaye",
      "screen_name" : "podehaye",
      "protected" : false,
      "id_str" : "2219841242",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/840965162349797376\/7hdkcm04_normal.jpg",
      "id" : 2219841242,
      "verified" : false
    }
  },
  "id" : 608566358448680960,
  "created_at" : "2015-06-10 09:28:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ga4gh",
      "indices" : [ 96, 102 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "608566062607704064",
  "text" : "A spectre is haunting Europe\u2019s genomics researchers \u2014 the spectre of EU data protection reform. #ga4gh",
  "id" : 608566062607704064,
  "created_at" : "2015-06-10 09:27:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DNAdigest.org",
      "screen_name" : "DNADigest",
      "indices" : [ 3, 13 ],
      "id_str" : "334912047",
      "id" : 334912047
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GA4GH",
      "indices" : [ 33, 39 ]
    } ],
    "urls" : [ {
      "indices" : [ 55, 77 ],
      "url" : "http:\/\/t.co\/0uibFDjIWq",
      "expanded_url" : "http:\/\/genomicsandhealth.org\/work-products-demonstration-projects\/consent-policy",
      "display_url" : "genomicsandhealth.org\/work-products-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "608564735781548033",
  "text" : "RT @DNADigest: Consent policy by #GA4GH working group: http:\/\/t.co\/0uibFDjIWq please contribute with your comments and experience",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GA4GH",
        "indices" : [ 18, 24 ]
      } ],
      "urls" : [ {
        "indices" : [ 40, 62 ],
        "url" : "http:\/\/t.co\/0uibFDjIWq",
        "expanded_url" : "http:\/\/genomicsandhealth.org\/work-products-demonstration-projects\/consent-policy",
        "display_url" : "genomicsandhealth.org\/work-products-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "608564424887169025",
    "text" : "Consent policy by #GA4GH working group: http:\/\/t.co\/0uibFDjIWq please contribute with your comments and experience",
    "id" : 608564424887169025,
    "created_at" : "2015-06-10 09:20:40 +0000",
    "user" : {
      "name" : "DNAdigest.org",
      "screen_name" : "DNADigest",
      "protected" : false,
      "id_str" : "334912047",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/430707142232772608\/Vmx-V5fY_normal.png",
      "id" : 334912047,
      "verified" : false
    }
  },
  "id" : 608564735781548033,
  "created_at" : "2015-06-10 09:21:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ga4gh",
      "indices" : [ 67, 73 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "608542927489527808",
  "text" : "\u00ABBritain has as much data as France, we just haven\u2019t told anyone.\u00BB #ga4gh",
  "id" : 608542927489527808,
  "created_at" : "2015-06-10 07:55:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.17065486595688, 4.453741665503362 ]
  },
  "id_str" : "608517796306235392",
  "text" : "\u00ABTalking about the 80% functional claim by ENCODE &amp; Richard Dawkins in one evening?! You really tried hard getting into a bar room fight!\u00BB",
  "id" : 608517796306235392,
  "created_at" : "2015-06-10 06:15:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 74 ],
      "url" : "https:\/\/t.co\/n7aqmrsq9h",
      "expanded_url" : "https:\/\/instagram.com\/p\/3vOw4nBwrD\/",
      "display_url" : "instagram.com\/p\/3vOw4nBwrD\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.15699662, 4.485544727 ]
  },
  "id_str" : "608515692762136576",
  "text" : "at the botanical gardens @ Hortus botanicus Leiden https:\/\/t.co\/n7aqmrsq9h",
  "id" : 608515692762136576,
  "created_at" : "2015-06-10 06:07:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 39 ],
      "url" : "https:\/\/t.co\/HFyYMUM93S",
      "expanded_url" : "https:\/\/instagram.com\/p\/3uZgzJBwlb\/",
      "display_url" : "instagram.com\/p\/3uZgzJBwlb\/"
    } ]
  },
  "geo" : { },
  "id_str" : "608398593226117120",
  "text" : "student housing https:\/\/t.co\/HFyYMUM93S",
  "id" : 608398593226117120,
  "created_at" : "2015-06-09 22:21:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "608390239518883840",
  "geo" : { },
  "id_str" : "608390776473681920",
  "in_reply_to_user_id" : 14286491,
  "text" : "Unfortunately the last isn\u2019t true any longer. Today students also pay 21% VAT.",
  "id" : 608390776473681920,
  "in_reply_to_status_id" : 608390239518883840,
  "created_at" : "2015-06-09 21:50:39 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "608390239518883840",
  "text" : "TIL: back then Leiden did 3 things to draw in students:. Got good professors, built a botanical garden, made beer tax-free for students.",
  "id" : 608390239518883840,
  "created_at" : "2015-06-09 21:48:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ga4gh",
      "indices" : [ 133, 139 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "608286722166767616",
  "geo" : { },
  "id_str" : "608287468274728961",
  "in_reply_to_user_id" : 14286491,
  "text" : "And I couldn\u2019t agree more: building universally useful tools requires diverse input, otherwise it is unlikely to be truly universal. #ga4gh",
  "id" : 608287468274728961,
  "in_reply_to_status_id" : 608286722166767616,
  "created_at" : "2015-06-09 15:00:08 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ga4gh",
      "indices" : [ 27, 33 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "608286722166767616",
  "text" : "On western centrism of the #ga4gh so far: \u00ABI can\u2019t believe I\u2019m going to quote Donald Rumsfeld, but there is the issue of unknown unknowns\u2026\u00BB",
  "id" : 608286722166767616,
  "created_at" : "2015-06-09 14:57:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "608285302499770369",
  "geo" : { },
  "id_str" : "608286014201860096",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich full ack \uD83D\uDC0D",
  "id" : 608286014201860096,
  "in_reply_to_status_id" : 608285302499770369,
  "created_at" : "2015-06-09 14:54:21 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "608284455132884992",
  "geo" : { },
  "id_str" : "608284854145445888",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich ich war froh \u00FCberhaupt ein Bild der Szene gefunden zu haben. :)",
  "id" : 608284854145445888,
  "in_reply_to_status_id" : 608284455132884992,
  "created_at" : "2015-06-09 14:49:45 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kees van Bochove",
      "screen_name" : "keesvanbochove",
      "indices" : [ 0, 15 ],
      "id_str" : "24461482",
      "id" : 24461482
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 48 ],
      "url" : "http:\/\/t.co\/G0MfaiGeXr",
      "expanded_url" : "http:\/\/vignette2.wikia.nocookie.net\/indianajones\/images\/9\/97\/Templeofdoom.jpg\/revision\/latest?cb=20070707205318",
      "display_url" : "vignette2.wikia.nocookie.net\/indianajones\/i\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "608279566193467392",
  "geo" : { },
  "id_str" : "608281261279473665",
  "in_reply_to_user_id" : 24461482,
  "text" : "@keesvanbochove yes, c.f. http:\/\/t.co\/G0MfaiGeXr ;)",
  "id" : 608281261279473665,
  "in_reply_to_status_id" : 608279566193467392,
  "created_at" : "2015-06-09 14:35:28 +0000",
  "in_reply_to_screen_name" : "keesvanbochove",
  "in_reply_to_user_id_str" : "24461482",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 46 ],
      "url" : "http:\/\/t.co\/G0MfaiGeXr",
      "expanded_url" : "http:\/\/vignette2.wikia.nocookie.net\/indianajones\/images\/9\/97\/Templeofdoom.jpg\/revision\/latest?cb=20070707205318",
      "display_url" : "vignette2.wikia.nocookie.net\/indianajones\/i\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "608278160124342272",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.17012241154273, 4.453968949790509 ]
  },
  "id_str" : "608281133428654080",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich reminds me of http:\/\/t.co\/G0MfaiGeXr",
  "id" : 608281133428654080,
  "in_reply_to_status_id" : 608278160124342272,
  "created_at" : "2015-06-09 14:34:58 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/608277703658209280\/photo\/1",
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/EicjL7W0Ag",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CHEJE2sUIAAs_fo.jpg",
      "id_str" : "608277403677237248",
      "id" : 608277403677237248,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHEJE2sUIAAs_fo.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 2448,
        "resize" : "fit",
        "w" : 3264
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/EicjL7W0Ag"
    } ],
    "hashtags" : [ {
      "text" : "ga4gh",
      "indices" : [ 96, 102 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "608277703658209280",
  "text" : "Looks a bit like the caption should read \u2018the elders of the Global Alliance next to their idol\u2019 #ga4gh http:\/\/t.co\/EicjL7W0Ag",
  "id" : 608277703658209280,
  "created_at" : "2015-06-09 14:21:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Stekhoven",
      "screen_name" : "DanStekhoven",
      "indices" : [ 0, 13 ],
      "id_str" : "3114555473",
      "id" : 3114555473
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "608256782931267585",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.1723991795693, 4.461857000270747 ]
  },
  "id_str" : "608257134736867328",
  "in_reply_to_user_id" : 3114555473,
  "text" : "@DanStekhoven should have said so at 8 this morning. ;)",
  "id" : 608257134736867328,
  "in_reply_to_status_id" : 608256782931267585,
  "created_at" : "2015-06-09 12:59:36 +0000",
  "in_reply_to_screen_name" : "DanStekhoven",
  "in_reply_to_user_id_str" : "3114555473",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DNAdigest.org",
      "screen_name" : "DNADigest",
      "indices" : [ 3, 13 ],
      "id_str" : "334912047",
      "id" : 334912047
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/DNADigest\/status\/608247535652769793\/photo\/1",
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/lRzjreZF9D",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CHDt6LvWwAA_qTF.jpg",
      "id_str" : "608247533534625792",
      "id" : 608247533534625792,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHDt6LvWwAA_qTF.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/lRzjreZF9D"
    } ],
    "hashtags" : [ {
      "text" : "GA4GH",
      "indices" : [ 72, 78 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "608248315063504896",
  "text" : "RT @DNADigest: The new biologist knows how to label with ontologies :-) #GA4GH http:\/\/t.co\/lRzjreZF9D",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/DNADigest\/status\/608247535652769793\/photo\/1",
        "indices" : [ 64, 86 ],
        "url" : "http:\/\/t.co\/lRzjreZF9D",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CHDt6LvWwAA_qTF.jpg",
        "id_str" : "608247533534625792",
        "id" : 608247533534625792,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHDt6LvWwAA_qTF.jpg",
        "sizes" : [ {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 383,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/lRzjreZF9D"
      } ],
      "hashtags" : [ {
        "text" : "GA4GH",
        "indices" : [ 57, 63 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "608247535652769793",
    "text" : "The new biologist knows how to label with ontologies :-) #GA4GH http:\/\/t.co\/lRzjreZF9D",
    "id" : 608247535652769793,
    "created_at" : "2015-06-09 12:21:27 +0000",
    "user" : {
      "name" : "DNAdigest.org",
      "screen_name" : "DNADigest",
      "protected" : false,
      "id_str" : "334912047",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/430707142232772608\/Vmx-V5fY_normal.png",
      "id" : 334912047,
      "verified" : false
    }
  },
  "id" : 608248315063504896,
  "created_at" : "2015-06-09 12:24:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "meta",
      "indices" : [ 87, 92 ]
    }, {
      "text" : "ga4gh",
      "indices" : [ 93, 99 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.16791644545771, 4.459170787859279 ]
  },
  "id_str" : "608248294972772352",
  "text" : "\u00ABComments? Questions? Things you wish you could tweet but your internet doesn\u2019t work?\u00BB #meta #ga4gh",
  "id" : 608248294972772352,
  "created_at" : "2015-06-09 12:24:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ga4gh",
      "indices" : [ 73, 79 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "608211814636253184",
  "text" : "Recommendations on security: use a library and read the spec (surprise!) #ga4gh",
  "id" : 608211814636253184,
  "created_at" : "2015-06-09 09:59:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul-Olivier Dehaye",
      "screen_name" : "podehaye",
      "indices" : [ 0, 9 ],
      "id_str" : "2219841242",
      "id" : 2219841242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "608209353867448320",
  "geo" : { },
  "id_str" : "608211323554566144",
  "in_reply_to_user_id" : 2219841242,
  "text" : "@podehaye I\u2019ll try to look into it tonight. Sounds interesting!",
  "id" : 608211323554566144,
  "in_reply_to_status_id" : 608209353867448320,
  "created_at" : "2015-06-09 09:57:34 +0000",
  "in_reply_to_screen_name" : "podehaye",
  "in_reply_to_user_id_str" : "2219841242",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "C\u24D0meronNeylon",
      "screen_name" : "CameronNeylon",
      "indices" : [ 3, 17 ],
      "id_str" : "12984852",
      "id" : 12984852
    }, {
      "name" : "Adam Eyre-Walker",
      "screen_name" : "AdamEyreWalker",
      "indices" : [ 32, 47 ],
      "id_str" : "632538212",
      "id" : 632538212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "608206471571099648",
  "text" : "RT @CameronNeylon: Article from @AdamEyreWalker with Isabelle Cook &amp; Sam Grange should give \"concentrate funding\" agenda some pause: https:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Adam Eyre-Walker",
        "screen_name" : "AdamEyreWalker",
        "indices" : [ 13, 28 ],
        "id_str" : "632538212",
        "id" : 632538212
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 141 ],
        "url" : "https:\/\/t.co\/bjBUuafu9p",
        "expanded_url" : "https:\/\/peerj.com\/articles\/989\/",
        "display_url" : "peerj.com\/articles\/989\/"
      } ]
    },
    "geo" : { },
    "id_str" : "608205562153734145",
    "text" : "Article from @AdamEyreWalker with Isabelle Cook &amp; Sam Grange should give \"concentrate funding\" agenda some pause: https:\/\/t.co\/bjBUuafu9p",
    "id" : 608205562153734145,
    "created_at" : "2015-06-09 09:34:40 +0000",
    "user" : {
      "name" : "C\u24D0meronNeylon",
      "screen_name" : "CameronNeylon",
      "protected" : false,
      "id_str" : "12984852",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1766127492\/image1326973990_normal.png",
      "id" : 12984852,
      "verified" : false
    }
  },
  "id" : 608206471571099648,
  "created_at" : "2015-06-09 09:38:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DNAdigest.org",
      "screen_name" : "DNADigest",
      "indices" : [ 3, 13 ],
      "id_str" : "334912047",
      "id" : 334912047
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/DNADigest\/status\/608203163880026113\/photo\/1",
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/9axG5PrZbV",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CHDFi0lXEAAa54Q.jpg",
      "id_str" : "608203151716585472",
      "id" : 608203151716585472,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHDFi0lXEAAa54Q.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/9axG5PrZbV"
    } ],
    "hashtags" : [ {
      "text" : "GA4GH",
      "indices" : [ 105, 111 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "608204437920849920",
  "text" : "RT @DNADigest: Dixie Baker: There is no one individual responsible for security, everyone is responsible #GA4GH http:\/\/t.co\/9axG5PrZbV",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/DNADigest\/status\/608203163880026113\/photo\/1",
        "indices" : [ 97, 119 ],
        "url" : "http:\/\/t.co\/9axG5PrZbV",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CHDFi0lXEAAa54Q.jpg",
        "id_str" : "608203151716585472",
        "id" : 608203151716585472,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHDFi0lXEAAa54Q.jpg",
        "sizes" : [ {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 383,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/9axG5PrZbV"
      } ],
      "hashtags" : [ {
        "text" : "GA4GH",
        "indices" : [ 90, 96 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "608203163880026113",
    "text" : "Dixie Baker: There is no one individual responsible for security, everyone is responsible #GA4GH http:\/\/t.co\/9axG5PrZbV",
    "id" : 608203163880026113,
    "created_at" : "2015-06-09 09:25:08 +0000",
    "user" : {
      "name" : "DNAdigest.org",
      "screen_name" : "DNADigest",
      "protected" : false,
      "id_str" : "334912047",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/430707142232772608\/Vmx-V5fY_normal.png",
      "id" : 334912047,
      "verified" : false
    }
  },
  "id" : 608204437920849920,
  "created_at" : "2015-06-09 09:30:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul-Olivier Dehaye",
      "screen_name" : "podehaye",
      "indices" : [ 0, 9 ],
      "id_str" : "2219841242",
      "id" : 2219841242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "608203945874456576",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.17066488334468, 4.453754227434492 ]
  },
  "id_str" : "608204386515472384",
  "in_reply_to_user_id" : 2219841242,
  "text" : "@podehaye still, 29% diff due to strand flips sounds like a lot to me. could you try to see how much % ID increases by taking into account?",
  "id" : 608204386515472384,
  "in_reply_to_status_id" : 608203945874456576,
  "created_at" : "2015-06-09 09:30:00 +0000",
  "in_reply_to_screen_name" : "podehaye",
  "in_reply_to_user_id_str" : "2219841242",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul-Olivier Dehaye",
      "screen_name" : "podehaye",
      "indices" : [ 0, 9 ],
      "id_str" : "2219841242",
      "id" : 2219841242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "608203056216473600",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.17066718177942, 4.453774254897315 ]
  },
  "id_str" : "608203671093018624",
  "in_reply_to_user_id" : 2219841242,
  "text" : "@podehaye did you test for switching positions (making sure that AG==GA) and for strand flips (AG~TC)?",
  "id" : 608203671093018624,
  "in_reply_to_status_id" : 608203056216473600,
  "created_at" : "2015-06-09 09:27:09 +0000",
  "in_reply_to_screen_name" : "podehaye",
  "in_reply_to_user_id_str" : "2219841242",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul-Olivier Dehaye",
      "screen_name" : "podehaye",
      "indices" : [ 0, 9 ],
      "id_str" : "2219841242",
      "id" : 2219841242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "608202248787783680",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.17066694908571, 4.453754832220767 ]
  },
  "id_str" : "608202645380210688",
  "in_reply_to_user_id" : 2219841242,
  "text" : "@podehaye ok, so is this 70% matching SNPs (rs-id same) or matching genotypes (same variant-calls for same rs-ids?)",
  "id" : 608202645380210688,
  "in_reply_to_status_id" : 608202248787783680,
  "created_at" : "2015-06-09 09:23:05 +0000",
  "in_reply_to_screen_name" : "podehaye",
  "in_reply_to_user_id_str" : "2219841242",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GA4GH",
      "indices" : [ 0, 6 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.17066694908571, 4.453754832220767 ]
  },
  "id_str" : "608202436281552897",
  "text" : "#GA4GH relies on trust in confidentiality, integrity, availability &amp; privacy.",
  "id" : 608202436281552897,
  "created_at" : "2015-06-09 09:22:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul-Olivier Dehaye",
      "screen_name" : "podehaye",
      "indices" : [ 0, 9 ],
      "id_str" : "2219841242",
      "id" : 2219841242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "608197158911766528",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.17066859488466, 4.453772889960388 ]
  },
  "id_str" : "608201408391876608",
  "in_reply_to_user_id" : 2219841242,
  "text" : "@podehaye do you have some more context? Is this merging stuff in plink?",
  "id" : 608201408391876608,
  "in_reply_to_status_id" : 608197158911766528,
  "created_at" : "2015-06-09 09:18:10 +0000",
  "in_reply_to_screen_name" : "podehaye",
  "in_reply_to_user_id_str" : "2219841242",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ga4gh",
      "indices" : [ 98, 104 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/BBSXsMDxlf",
      "expanded_url" : "https:\/\/instagram.com\/p\/3s9QmHhwnv\/",
      "display_url" : "instagram.com\/p\/3s9QmHhwnv\/"
    } ]
  },
  "geo" : { },
  "id_str" : "608195725130919936",
  "text" : "Seen my fair share of conference venues, but this is definitely one of the more extravagant ones. #ga4gh https:\/\/t.co\/BBSXsMDxlf",
  "id" : 608195725130919936,
  "created_at" : "2015-06-09 08:55:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/r3DB5yNc7Y",
      "expanded_url" : "https:\/\/liorpachter.wordpress.com\/2015\/06\/09\/i-was-wrong\/",
      "display_url" : "liorpachter.wordpress.com\/2015\/06\/09\/i-w\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.17066843320109, 4.453771008641016 ]
  },
  "id_str" : "608191494382624768",
  "text" : "\u00ABSaying \u201CI was wrong\u201D is important for science and essential for scientists. Without it people lose trust in both.\u00BB https:\/\/t.co\/r3DB5yNc7Y",
  "id" : 608191494382624768,
  "created_at" : "2015-06-09 08:38:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Stekhoven",
      "screen_name" : "DanStekhoven",
      "indices" : [ 3, 16 ],
      "id_str" : "3114555473",
      "id" : 3114555473
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/DanStekhoven\/status\/608189172088762368\/photo\/1",
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/RKbGJsxPRm",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CHC40rPWgAE0_5C.jpg",
      "id_str" : "608189164794839041",
      "id" : 608189164794839041,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHC40rPWgAE0_5C.jpg",
      "sizes" : [ {
        "h" : 611,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 406,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 611,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 611,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/RKbGJsxPRm"
    } ],
    "hashtags" : [ {
      "text" : "GA4GH",
      "indices" : [ 71, 77 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/5csgJ5Fmed",
      "expanded_url" : "http:\/\/monarchinitiative.org",
      "display_url" : "monarchinitiative.org"
    } ]
  },
  "geo" : { },
  "id_str" : "608190133188337665",
  "text" : "RT @DanStekhoven: Nicole Washington pitches G2P (genotype 2 phenotype) #GA4GH http:\/\/t.co\/5csgJ5Fmed http:\/\/t.co\/RKbGJsxPRm",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/DanStekhoven\/status\/608189172088762368\/photo\/1",
        "indices" : [ 83, 105 ],
        "url" : "http:\/\/t.co\/RKbGJsxPRm",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CHC40rPWgAE0_5C.jpg",
        "id_str" : "608189164794839041",
        "id" : 608189164794839041,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHC40rPWgAE0_5C.jpg",
        "sizes" : [ {
          "h" : 611,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 406,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 611,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 611,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/RKbGJsxPRm"
      } ],
      "hashtags" : [ {
        "text" : "GA4GH",
        "indices" : [ 53, 59 ]
      } ],
      "urls" : [ {
        "indices" : [ 60, 82 ],
        "url" : "http:\/\/t.co\/5csgJ5Fmed",
        "expanded_url" : "http:\/\/monarchinitiative.org",
        "display_url" : "monarchinitiative.org"
      } ]
    },
    "geo" : { },
    "id_str" : "608189172088762368",
    "text" : "Nicole Washington pitches G2P (genotype 2 phenotype) #GA4GH http:\/\/t.co\/5csgJ5Fmed http:\/\/t.co\/RKbGJsxPRm",
    "id" : 608189172088762368,
    "created_at" : "2015-06-09 08:29:32 +0000",
    "user" : {
      "name" : "Daniel Stekhoven",
      "screen_name" : "DanStekhoven",
      "protected" : false,
      "id_str" : "3114555473",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/909706199557386240\/8Ld8MD-w_normal.jpg",
      "id" : 3114555473,
      "verified" : false
    }
  },
  "id" : 608190133188337665,
  "created_at" : "2015-06-09 08:33:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DNAdigest.org",
      "screen_name" : "DNADigest",
      "indices" : [ 3, 13 ],
      "id_str" : "334912047",
      "id" : 334912047
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/DNADigest\/status\/608187211834654720\/photo\/1",
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/Qc0W3X5Px8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CHC3A1eVAAA6W26.jpg",
      "id_str" : "608187174677184512",
      "id" : 608187174677184512,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHC3A1eVAAA6W26.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/Qc0W3X5Px8"
    } ],
    "hashtags" : [ {
      "text" : "GA4GH",
      "indices" : [ 65, 71 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "608187905056612352",
  "text" : "RT @DNADigest: The NCBI \"pyramid scheme\" for data access\/sharing #GA4GH http:\/\/t.co\/Qc0W3X5Px8",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/DNADigest\/status\/608187211834654720\/photo\/1",
        "indices" : [ 57, 79 ],
        "url" : "http:\/\/t.co\/Qc0W3X5Px8",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CHC3A1eVAAA6W26.jpg",
        "id_str" : "608187174677184512",
        "id" : 608187174677184512,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHC3A1eVAAA6W26.jpg",
        "sizes" : [ {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 383,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/Qc0W3X5Px8"
      } ],
      "hashtags" : [ {
        "text" : "GA4GH",
        "indices" : [ 50, 56 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "608187211834654720",
    "text" : "The NCBI \"pyramid scheme\" for data access\/sharing #GA4GH http:\/\/t.co\/Qc0W3X5Px8",
    "id" : 608187211834654720,
    "created_at" : "2015-06-09 08:21:45 +0000",
    "user" : {
      "name" : "DNAdigest.org",
      "screen_name" : "DNADigest",
      "protected" : false,
      "id_str" : "334912047",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/430707142232772608\/Vmx-V5fY_normal.png",
      "id" : 334912047,
      "verified" : false
    }
  },
  "id" : 608187905056612352,
  "created_at" : "2015-06-09 08:24:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GA4GH",
      "indices" : [ 114, 120 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.17066829588844, 4.453766965605385 ]
  },
  "id_str" : "608187567218008065",
  "text" : "catch-22: how to know to which studies you should request data access to, w\/o knowing if they have relevant data? #GA4GH",
  "id" : 608187567218008065,
  "created_at" : "2015-06-09 08:23:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GA4GH",
      "indices" : [ 69, 75 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "608172397896810496",
  "text" : "300 people in the data working group, 1000 commits on GitHub so far. #GA4GH",
  "id" : 608172397896810496,
  "created_at" : "2015-06-09 07:22:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.18118155243118, 4.471431533925842 ]
  },
  "id_str" : "608040722063880192",
  "text" : "Has anyone recommendations for good literature on graph alignments?",
  "id" : 608040722063880192,
  "created_at" : "2015-06-08 22:39:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/dyBMDc9mY0",
      "expanded_url" : "http:\/\/www.michaeleisen.org\/blog\/?p=1718",
      "display_url" : "michaeleisen.org\/blog\/?p=1718"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.18114577128134, 4.471648858971501 ]
  },
  "id_str" : "608036453239681026",
  "text" : "post pub review: \u00ABSo long as we personalize our scientific achievements, attacks on them are going to feel personal.\u00BB http:\/\/t.co\/dyBMDc9mY0",
  "id" : 608036453239681026,
  "created_at" : "2015-06-08 22:22:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 7, 29 ],
      "url" : "http:\/\/t.co\/OTa08Dbk63",
      "expanded_url" : "http:\/\/media.giphy.com\/media\/Bk1tJSiem5hEk\/giphy.gif",
      "display_url" : "media.giphy.com\/media\/Bk1tJSie\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "608030455187795968",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.18117889639208, 4.471692231185082 ]
  },
  "id_str" : "608032149342724096",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot http:\/\/t.co\/OTa08Dbk63",
  "id" : 608032149342724096,
  "in_reply_to_status_id" : 608030455187795968,
  "created_at" : "2015-06-08 22:05:35 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joshua New",
      "screen_name" : "Josh_A_New",
      "indices" : [ 0, 11 ],
      "id_str" : "2797974333",
      "id" : 2797974333
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "608026780524548096",
  "geo" : { },
  "id_str" : "608027233601658881",
  "in_reply_to_user_id" : 2797974333,
  "text" : "@Josh_A_New I\u2019m more than happy with getting around it this time ;-)",
  "id" : 608027233601658881,
  "in_reply_to_status_id" : 608026780524548096,
  "created_at" : "2015-06-08 21:46:03 +0000",
  "in_reply_to_screen_name" : "Josh_A_New",
  "in_reply_to_user_id_str" : "2797974333",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 3, 12 ],
      "id_str" : "14245811",
      "id" : 14245811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "608022524165767169",
  "text" : "RT @wilbanks: Study surveyed more than 7000 people in 75 countries. 59% want raw genome data back even if no interpretation. https:\/\/t.co\/g\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 111, 134 ],
        "url" : "https:\/\/t.co\/gkaMlESrOG",
        "expanded_url" : "https:\/\/twitter.com\/KristinClift\/status\/607947401333112832",
        "display_url" : "twitter.com\/KristinClift\/s\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "607950083745677313",
    "text" : "Study surveyed more than 7000 people in 75 countries. 59% want raw genome data back even if no interpretation. https:\/\/t.co\/gkaMlESrOG",
    "id" : 607950083745677313,
    "created_at" : "2015-06-08 16:39:29 +0000",
    "user" : {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "protected" : false,
      "id_str" : "14245811",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/925696899566440448\/BUTdp410_normal.jpg",
      "id" : 14245811,
      "verified" : false
    }
  },
  "id" : 608022524165767169,
  "created_at" : "2015-06-08 21:27:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 34 ],
      "url" : "https:\/\/t.co\/GpZXiC3IJr",
      "expanded_url" : "https:\/\/www.google.com\/search?q=non-vowel",
      "display_url" : "google.com\/search?q=non-v\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "608014207200710657",
  "text" : "Non-vowels https:\/\/t.co\/GpZXiC3IJr",
  "id" : 608014207200710657,
  "created_at" : "2015-06-08 20:54:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "607981087852249089",
  "geo" : { },
  "id_str" : "607989464640679936",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot better fuck the police!",
  "id" : 607989464640679936,
  "in_reply_to_status_id" : 607981087852249089,
  "created_at" : "2015-06-08 19:15:58 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "607979491324006400",
  "geo" : { },
  "id_str" : "607980103243603968",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot that was the best part of it! So much fun with a sexy Icelandic police man!",
  "id" : 607980103243603968,
  "in_reply_to_status_id" : 607979491324006400,
  "created_at" : "2015-06-08 18:38:46 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "607958184519704576",
  "geo" : { },
  "id_str" : "607971953689956353",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot staying there worked so fine last time and totally didn\u2019t result in an emergency car rental. ;)",
  "id" : 607971953689956353,
  "in_reply_to_status_id" : 607958184519704576,
  "created_at" : "2015-06-08 18:06:23 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 57 ],
      "url" : "http:\/\/t.co\/9dD8cSiGsH",
      "expanded_url" : "http:\/\/www.datainnovation.org\/2015\/06\/5-qs-for-bastian-greshake-co-founder-of-opensnp\/",
      "display_url" : "datainnovation.org\/2015\/06\/5-qs-f\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "607970802940657664",
  "text" : "No Zuckerberg comparison for once! http:\/\/t.co\/9dD8cSiGsH",
  "id" : 607970802940657664,
  "created_at" : "2015-06-08 18:01:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Data Innovation",
      "screen_name" : "DataInnovation",
      "indices" : [ 3, 18 ],
      "id_str" : "390284285",
      "id" : 390284285
    }, {
      "name" : "openSNP team",
      "screen_name" : "openSNPorg",
      "indices" : [ 70, 81 ],
      "id_str" : "380205172",
      "id" : 380205172
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 82, 98 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/mEXLQZcwVd",
      "expanded_url" : "http:\/\/www.datainnovation.org\/2015\/06\/5-qs-for-bastian-greshake-co-founder-of-opensnp\/",
      "display_url" : "datainnovation.org\/2015\/06\/5-qs-f\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "607970388665073664",
  "text" : "RT @DataInnovation: 5 Q\u2019s for Bastian Greshake, Co-Founder of openSNP @openSNPorg @gedankenstuecke \nhttp:\/\/t.co\/mEXLQZcwVd",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "openSNP team",
        "screen_name" : "openSNPorg",
        "indices" : [ 50, 61 ],
        "id_str" : "380205172",
        "id" : 380205172
      }, {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 62, 78 ],
        "id_str" : "14286491",
        "id" : 14286491
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 80, 102 ],
        "url" : "http:\/\/t.co\/mEXLQZcwVd",
        "expanded_url" : "http:\/\/www.datainnovation.org\/2015\/06\/5-qs-for-bastian-greshake-co-founder-of-opensnp\/",
        "display_url" : "datainnovation.org\/2015\/06\/5-qs-f\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "607960318057193472",
    "text" : "5 Q\u2019s for Bastian Greshake, Co-Founder of openSNP @openSNPorg @gedankenstuecke \nhttp:\/\/t.co\/mEXLQZcwVd",
    "id" : 607960318057193472,
    "created_at" : "2015-06-08 17:20:09 +0000",
    "user" : {
      "name" : "Data Innovation",
      "screen_name" : "DataInnovation",
      "protected" : false,
      "id_str" : "390284285",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/875738210298724352\/RMfdq34p_normal.jpg",
      "id" : 390284285,
      "verified" : true
    }
  },
  "id" : 607970388665073664,
  "created_at" : "2015-06-08 18:00:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BenneHolwerda",
      "screen_name" : "BenneHolwerda",
      "indices" : [ 0, 14 ],
      "id_str" : "15362595",
      "id" : 15362595
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "607949912307867648",
  "geo" : { },
  "id_str" : "607958675739832320",
  "in_reply_to_user_id" : 15362595,
  "text" : "@BenneHolwerda I\u2019ll be at the conference until Thursday. Thursday afternoon would work for me. :)",
  "id" : 607958675739832320,
  "in_reply_to_status_id" : 607949912307867648,
  "created_at" : "2015-06-08 17:13:38 +0000",
  "in_reply_to_screen_name" : "BenneHolwerda",
  "in_reply_to_user_id_str" : "15362595",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Monika",
      "screen_name" : "GreenSkyOverMe",
      "indices" : [ 0, 15 ],
      "id_str" : "345356127",
      "id" : 345356127
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "607948846325465089",
  "geo" : { },
  "id_str" : "607949671328321536",
  "in_reply_to_user_id" : 345356127,
  "text" : "@GreenSkyOverMe kommt ein bisschen drauf in\/aus welchem Land es geht\/kommt. ;)",
  "id" : 607949671328321536,
  "in_reply_to_status_id" : 607948846325465089,
  "created_at" : "2015-06-08 16:37:51 +0000",
  "in_reply_to_screen_name" : "GreenSkyOverMe",
  "in_reply_to_user_id_str" : "345356127",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ToxX",
      "screen_name" : "ToxXInFlames",
      "indices" : [ 0, 13 ],
      "id_str" : "1421360166",
      "id" : 1421360166
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "607929628494315521",
  "geo" : { },
  "id_str" : "607931063541899264",
  "in_reply_to_user_id" : 1421360166,
  "text" : "@ToxXInFlames ack, should have packed a HDD. ;)",
  "id" : 607931063541899264,
  "in_reply_to_status_id" : 607929628494315521,
  "created_at" : "2015-06-08 15:23:55 +0000",
  "in_reply_to_screen_name" : "ToxXInFlames",
  "in_reply_to_user_id_str" : "1421360166",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fiona Nielsen",
      "screen_name" : "glyn_dk",
      "indices" : [ 0, 8 ],
      "id_str" : "32340834",
      "id" : 32340834
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "607912428593156096",
  "geo" : { },
  "id_str" : "607914837105102848",
  "in_reply_to_user_id" : 32340834,
  "text" : "@glyn_dk perfect, looking forward to it :)",
  "id" : 607914837105102848,
  "in_reply_to_status_id" : 607912428593156096,
  "created_at" : "2015-06-08 14:19:26 +0000",
  "in_reply_to_screen_name" : "glyn_dk",
  "in_reply_to_user_id_str" : "32340834",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "607903524597415936",
  "text" : "Big data: before leaving I started a file transfer, downloading files from Leiden to Frankfurt. Will still download when I arrive tonight.",
  "id" : 607903524597415936,
  "created_at" : "2015-06-08 13:34:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Schawinski",
      "screen_name" : "kevinschawinski",
      "indices" : [ 0, 16 ],
      "id_str" : "242844365",
      "id" : 242844365
    }, {
      "name" : "BenneHolwerda",
      "screen_name" : "BenneHolwerda",
      "indices" : [ 17, 31 ],
      "id_str" : "15362595",
      "id" : 15362595
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "607900084676784128",
  "geo" : { },
  "id_str" : "607901401960849408",
  "in_reply_to_user_id" : 242844365,
  "text" : "@kevinschawinski @BenneHolwerda thanks for the introduction! :)",
  "id" : 607901401960849408,
  "in_reply_to_status_id" : 607900084676784128,
  "created_at" : "2015-06-08 13:26:03 +0000",
  "in_reply_to_screen_name" : "kevinschawinski",
  "in_reply_to_user_id_str" : "242844365",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fiona Nielsen",
      "screen_name" : "glyn_dk",
      "indices" : [ 98, 106 ],
      "id_str" : "32340834",
      "id" : 32340834
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GA4GH",
      "indices" : [ 37, 43 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "607899986286813185",
  "text" : "Off to Leiden for the plenary of the #GA4GH. ETA 8pm-ish. Someone around for dinner at that time? @glyn_dk",
  "id" : 607899986286813185,
  "created_at" : "2015-06-08 13:20:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephan Urbach",
      "screen_name" : "herrurbach",
      "indices" : [ 0, 11 ],
      "id_str" : "28090494",
      "id" : 28090494
    }, {
      "name" : "Oliver Tacke",
      "screen_name" : "otacke",
      "indices" : [ 34, 41 ],
      "id_str" : "34880281",
      "id" : 34880281
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "607849256385310720",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17227786475485, 8.627555476233816 ]
  },
  "id_str" : "607849336173658112",
  "in_reply_to_user_id" : 28090494,
  "text" : "@herrurbach und das auch nur dank @otacke iirc :-)",
  "id" : 607849336173658112,
  "in_reply_to_status_id" : 607849256385310720,
  "created_at" : "2015-06-08 09:59:09 +0000",
  "in_reply_to_screen_name" : "herrurbach",
  "in_reply_to_user_id_str" : "28090494",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephan Urbach",
      "screen_name" : "herrurbach",
      "indices" : [ 0, 11 ],
      "id_str" : "28090494",
      "id" : 28090494
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "om10",
      "indices" : [ 31, 36 ]
    }, {
      "text" : "om12",
      "indices" : [ 60, 65 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "607844698586095616",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17227786475485, 8.627555476233816 ]
  },
  "id_str" : "607849207999905792",
  "in_reply_to_user_id" : 28090494,
  "text" : "@herrurbach Und der Reader der #om10 kam glaube ich auf der #om12? :D",
  "id" : 607849207999905792,
  "in_reply_to_status_id" : 607844698586095616,
  "created_at" : "2015-06-08 09:58:39 +0000",
  "in_reply_to_screen_name" : "herrurbach",
  "in_reply_to_user_id_str" : "28090494",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ali",
      "screen_name" : "zoonpolitikon",
      "indices" : [ 0, 14 ],
      "id_str" : "13040652",
      "id" : 13040652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "607829717639503872",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17228465201202, 8.627543366854349 ]
  },
  "id_str" : "607843755991945217",
  "in_reply_to_user_id" : 13040652,
  "text" : "@zoonpolitikon that\u2019s indeed what I started with now\u2026",
  "id" : 607843755991945217,
  "in_reply_to_status_id" : 607829717639503872,
  "created_at" : "2015-06-08 09:36:59 +0000",
  "in_reply_to_screen_name" : "zoonpolitikon",
  "in_reply_to_user_id_str" : "13040652",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Barbara Prainsack",
      "screen_name" : "BPrainsack",
      "indices" : [ 3, 14 ],
      "id_str" : "201632630",
      "id" : 201632630
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/zSBVF0wSvw",
      "expanded_url" : "http:\/\/on.tcrn.ch\/l\/dH7V",
      "display_url" : "on.tcrn.ch\/l\/dH7V"
    } ]
  },
  "geo" : { },
  "id_str" : "607842356679831552",
  "text" : "RT @BPrainsack: The Online Privacy Lie Is Unraveling: users are NOT happy to trade privacy for discounts: http:\/\/t.co\/zSBVF0wSvw via @chris\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Christine Aicardi",
        "screen_name" : "ChrisAicardi",
        "indices" : [ 117, 130 ],
        "id_str" : "398822851",
        "id" : 398822851
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 90, 112 ],
        "url" : "http:\/\/t.co\/zSBVF0wSvw",
        "expanded_url" : "http:\/\/on.tcrn.ch\/l\/dH7V",
        "display_url" : "on.tcrn.ch\/l\/dH7V"
      } ]
    },
    "geo" : { },
    "id_str" : "607841214428250112",
    "text" : "The Online Privacy Lie Is Unraveling: users are NOT happy to trade privacy for discounts: http:\/\/t.co\/zSBVF0wSvw via @chrisaicardi",
    "id" : 607841214428250112,
    "created_at" : "2015-06-08 09:26:53 +0000",
    "user" : {
      "name" : "Barbara Prainsack",
      "screen_name" : "BPrainsack",
      "protected" : false,
      "id_str" : "201632630",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/927171665917890561\/w5htgqHc_normal.jpg",
      "id" : 201632630,
      "verified" : false
    }
  },
  "id" : 607842356679831552,
  "created_at" : "2015-06-08 09:31:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/607842022393847808\/photo\/1",
      "indices" : [ 7, 29 ],
      "url" : "http:\/\/t.co\/49ygLas08H",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CG99GO8W8AAgEHW.jpg",
      "id_str" : "607842020762251264",
      "id" : 607842020762251264,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CG99GO8W8AAgEHW.jpg",
      "sizes" : [ {
        "h" : 680,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 2448,
        "resize" : "fit",
        "w" : 2448
      } ],
      "display_url" : "pic.twitter.com\/49ygLas08H"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "607839413847126016",
  "geo" : { },
  "id_str" : "607842022393847808",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot http:\/\/t.co\/49ygLas08H",
  "id" : 607842022393847808,
  "in_reply_to_status_id" : 607839413847126016,
  "created_at" : "2015-06-08 09:30:05 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 59 ],
      "url" : "http:\/\/t.co\/O6f1w1K4dZ",
      "expanded_url" : "http:\/\/www.fredhutch.org\/en\/news\/center-news\/2015\/04\/lessons-about-vaginal-microbiome.html",
      "display_url" : "fredhutch.org\/en\/news\/center\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17228120787057, 8.627534496611055 ]
  },
  "id_str" : "607833422900416512",
  "text" : "lessons about the vaginal microbiome http:\/\/t.co\/O6f1w1K4dZ",
  "id" : 607833422900416512,
  "created_at" : "2015-06-08 08:55:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17227688791001, 8.627522000776786 ]
  },
  "id_str" : "607829418757758976",
  "text" : "it\u2019s been 10 minutes and i\u2019m already so fed up with Inkscape that I want to draw that damn poster by hand.",
  "id" : 607829418757758976,
  "created_at" : "2015-06-08 08:40:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "607822218912006144",
  "geo" : { },
  "id_str" : "607823318234894336",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich watch for the odd one out!\uD83D\uDC3C\uD83D\uDC3C\uD83D\uDC3C\uD83D\uDC3C\uD83D\uDC3C\uD83D\uDC28\uD83D\uDC3C\uD83D\uDC3C\uD83D\uDC3C\uD83D\uDC3C",
  "id" : 607823318234894336,
  "in_reply_to_status_id" : 607822218912006144,
  "created_at" : "2015-06-08 08:15:46 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "607821757387534336",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17227266161537, 8.627524629864862 ]
  },
  "id_str" : "607821923423252480",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich fang lieber noch mal von vorne an!",
  "id" : 607821923423252480,
  "in_reply_to_status_id" : 607821757387534336,
  "created_at" : "2015-06-08 08:10:13 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 72 ],
      "url" : "http:\/\/t.co\/XoKPF2uyVc",
      "expanded_url" : "http:\/\/i.imgur.com\/gwlKLLU.gif",
      "display_url" : "i.imgur.com\/gwlKLLU.gif"
    } ]
  },
  "in_reply_to_status_id_str" : "607819558460784640",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17230114786331, 8.62750613862836 ]
  },
  "id_str" : "607819899411566592",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich there\u2019s even a perfect feedback loop :D http:\/\/t.co\/XoKPF2uyVc",
  "id" : 607819899411566592,
  "in_reply_to_status_id" : 607819558460784640,
  "created_at" : "2015-06-08 08:02:11 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 32 ],
      "url" : "http:\/\/t.co\/FxFPAcGfde",
      "expanded_url" : "http:\/\/i.imgur.com\/xOBuS.gif",
      "display_url" : "i.imgur.com\/xOBuS.gif"
    } ]
  },
  "in_reply_to_status_id_str" : "607818096678694912",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17226454927606, 8.627597265445912 ]
  },
  "id_str" : "607819055710486528",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich http:\/\/t.co\/FxFPAcGfde",
  "id" : 607819055710486528,
  "in_reply_to_status_id" : 607818096678694912,
  "created_at" : "2015-06-08 07:58:50 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/4NL6U6dh9G",
      "expanded_url" : "http:\/\/www.vice.com\/en_us\/read\/ten-days-of-silence-taught-me-how-to-be-alive-500",
      "display_url" : "vice.com\/en_us\/read\/ten\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17224690559276, 8.627579603239283 ]
  },
  "id_str" : "607813498446430208",
  "text" : "\u00ABI've managed to access a section of my brain which neurosurgeons may or may not call \"free drugs.\u201D\u00BB More \u201Cmay not\u201D http:\/\/t.co\/4NL6U6dh9G",
  "id" : 607813498446430208,
  "created_at" : "2015-06-08 07:36:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 4, 26 ],
      "url" : "http:\/\/t.co\/XD4vVlGVq1",
      "expanded_url" : "http:\/\/xkcd.com\/1535\/",
      "display_url" : "xkcd.com\/1535\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722264741011, 8.62755467290997 ]
  },
  "id_str" : "607798194194542592",
  "text" : "ack http:\/\/t.co\/XD4vVlGVq1",
  "id" : 607798194194542592,
  "created_at" : "2015-06-08 06:35:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17239145003009, 8.627507344096284 ]
  },
  "id_str" : "607796216613715968",
  "text" : "\u00ABHow was Zurich?\u00BB \u2013 \u00ABFun, and this time no one had moved out by the time I came back.\u00BB \u2013 \u00ABIt\u2019s the little things, eh?\u00BB",
  "id" : 607796216613715968,
  "created_at" : "2015-06-08 06:28:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nazeefa",
      "screen_name" : "NazeefaFatima",
      "indices" : [ 0, 14 ],
      "id_str" : "37054704",
      "id" : 37054704
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "607795371448889344",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17231868387005, 8.627528219933488 ]
  },
  "id_str" : "607795453841784832",
  "in_reply_to_user_id" : 37054704,
  "text" : "@NazeefaFatima nah, unfortunately not.",
  "id" : 607795453841784832,
  "in_reply_to_status_id" : 607795371448889344,
  "created_at" : "2015-06-08 06:25:03 +0000",
  "in_reply_to_screen_name" : "NazeefaFatima",
  "in_reply_to_user_id_str" : "37054704",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John",
      "screen_name" : "top_philosopher",
      "indices" : [ 3, 19 ],
      "id_str" : "4023623273",
      "id" : 4023623273
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "607794955986337792",
  "text" : "RT @top_philosopher: There should be a twitter account that adds \"...in rats\" to all studies that are reported on w\/o disclosing that it wa\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "607749789472694272",
    "text" : "There should be a twitter account that adds \"...in rats\" to all studies that are reported on w\/o disclosing that it was a mouse\/rat model.",
    "id" : 607749789472694272,
    "created_at" : "2015-06-08 03:23:35 +0000",
    "user" : {
      "name" : "Alan Levinovitz \uD83D\uDC79",
      "screen_name" : "AlanLevinovitz",
      "protected" : false,
      "id_str" : "1247549077",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/729143936422383617\/j_6SjyUO_normal.jpg",
      "id" : 1247549077,
      "verified" : true
    }
  },
  "id" : 607794955986337792,
  "created_at" : "2015-06-08 06:23:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nazeefa",
      "screen_name" : "NazeefaFatima",
      "indices" : [ 0, 14 ],
      "id_str" : "37054704",
      "id" : 37054704
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "607794565932818432",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17230998431322, 8.627506247434784 ]
  },
  "id_str" : "607794702906228736",
  "in_reply_to_user_id" : 37054704,
  "text" : "@NazeefaFatima yes, the main reason I have been lobbying for screens alongside the whiteboards in the lobby. ;-)",
  "id" : 607794702906228736,
  "in_reply_to_status_id" : 607794565932818432,
  "created_at" : "2015-06-08 06:22:04 +0000",
  "in_reply_to_screen_name" : "NazeefaFatima",
  "in_reply_to_user_id_str" : "37054704",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nazeefa",
      "screen_name" : "NazeefaFatima",
      "indices" : [ 0, 14 ],
      "id_str" : "37054704",
      "id" : 37054704
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "607793883309871104",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17227806754614, 8.627538035264788 ]
  },
  "id_str" : "607794105813495809",
  "in_reply_to_user_id" : 37054704,
  "text" : "@NazeefaFatima that\u2019s because the printer failed at scaling from A3-&gt;A4, top\/bottom miss couple of mms ;-)",
  "id" : 607794105813495809,
  "in_reply_to_status_id" : 607793883309871104,
  "created_at" : "2015-06-08 06:19:41 +0000",
  "in_reply_to_screen_name" : "NazeefaFatima",
  "in_reply_to_user_id_str" : "37054704",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/607792285359710208\/photo\/1",
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/yBup1DIoSi",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CG9P3I4WcAAXpS6.jpg",
      "id_str" : "607792283413540864",
      "id" : 607792283413540864,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CG9P3I4WcAAXpS6.jpg",
      "sizes" : [ {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 2448,
        "resize" : "fit",
        "w" : 3264
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/yBup1DIoSi"
    } ],
    "hashtags" : [ {
      "text" : "opencon",
      "indices" : [ 16, 24 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "607792285359710208",
  "text" : "Making sure the #opencon propaganda is right next to the other public service announcements. http:\/\/t.co\/yBup1DIoSi",
  "id" : 607792285359710208,
  "created_at" : "2015-06-08 06:12:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Greenspan",
      "screen_name" : "samlistens",
      "indices" : [ 0, 11 ],
      "id_str" : "31125463",
      "id" : 31125463
    }, {
      "name" : "Song Exploder",
      "screen_name" : "SongExploder",
      "indices" : [ 12, 25 ],
      "id_str" : "2249590315",
      "id" : 2249590315
    }, {
      "name" : "Radiotopia",
      "screen_name" : "radiotopiafm",
      "indices" : [ 26, 39 ],
      "id_str" : "1028732222",
      "id" : 1028732222
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 63 ],
      "url" : "https:\/\/t.co\/n0YzP2I7AV",
      "expanded_url" : "https:\/\/media0.giphy.com\/media\/ayMCeG4mbMhq\/200.gif",
      "display_url" : "media0.giphy.com\/media\/ayMCeG4m\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "607699413717237760",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11407917407405, 8.753321637849293 ]
  },
  "id_str" : "607701305302384642",
  "in_reply_to_user_id" : 31125463,
  "text" : "@samlistens @SongExploder @radiotopiafm https:\/\/t.co\/n0YzP2I7AV",
  "id" : 607701305302384642,
  "in_reply_to_status_id" : 607699413717237760,
  "created_at" : "2015-06-08 00:10:56 +0000",
  "in_reply_to_screen_name" : "samlistens",
  "in_reply_to_user_id_str" : "31125463",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11408530306437, 8.75332197262225 ]
  },
  "id_str" : "607686621983571968",
  "text" : "\u00ABYou only say that to sound clever!\u00BB \u2013 \u00ABI know, you should try it.\u00BB Good advice.",
  "id" : 607686621983571968,
  "created_at" : "2015-06-07 23:12:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rae Knowler",
      "screen_name" : "RaeKnowler",
      "indices" : [ 3, 14 ],
      "id_str" : "1244114060",
      "id" : 1244114060
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "makeopendata",
      "indices" : [ 36, 49 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/wYFQTMwBVn",
      "expanded_url" : "http:\/\/raeknowler.com\/ord-hackdays",
      "display_url" : "raeknowler.com\/ord-hackdays"
    } ]
  },
  "geo" : { },
  "id_str" : "607649802881495040",
  "text" : "RT @RaeKnowler: I blogged about the #makeopendata Open Research Data Hackdays and our Open Data Multisearch project: http:\/\/t.co\/wYFQTMwBVn",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "makeopendata",
        "indices" : [ 20, 33 ]
      } ],
      "urls" : [ {
        "indices" : [ 101, 123 ],
        "url" : "http:\/\/t.co\/wYFQTMwBVn",
        "expanded_url" : "http:\/\/raeknowler.com\/ord-hackdays",
        "display_url" : "raeknowler.com\/ord-hackdays"
      } ]
    },
    "geo" : { },
    "id_str" : "607606818412634114",
    "text" : "I blogged about the #makeopendata Open Research Data Hackdays and our Open Data Multisearch project: http:\/\/t.co\/wYFQTMwBVn",
    "id" : 607606818412634114,
    "created_at" : "2015-06-07 17:55:28 +0000",
    "user" : {
      "name" : "Rae Knowler",
      "screen_name" : "RaeKnowler",
      "protected" : false,
      "id_str" : "1244114060",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/897886763435294720\/nvIG3s3i_normal.jpg",
      "id" : 1244114060,
      "verified" : false
    }
  },
  "id" : 607649802881495040,
  "created_at" : "2015-06-07 20:46:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Opendata.ch",
      "screen_name" : "OpendataCH",
      "indices" : [ 45, 56 ],
      "id_str" : "362585949",
      "id" : 362585949
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "makeopendata",
      "indices" : [ 58, 71 ]
    } ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/kYIXDM6B32",
      "expanded_url" : "https:\/\/instagram.com\/p\/3onMoMBwr6\/",
      "display_url" : "instagram.com\/p\/3onMoMBwr6\/"
    } ]
  },
  "geo" : { },
  "id_str" : "607584261709918209",
  "text" : "\u00ABI'm awesome at making up new words.\u00BB thanks @opendataCH, #makeopendata was fun! https:\/\/t.co\/kYIXDM6B32",
  "id" : 607584261709918209,
  "created_at" : "2015-06-07 16:25:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/CuT0Kojf44",
      "expanded_url" : "https:\/\/github.com\/gedankenstuecke\/opensnp-fun\/blob\/master\/convert-1k-vcf-to-ped.py",
      "display_url" : "github.com\/gedankenstueck\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "607315281904574465",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35900805678615, 8.59546203796242 ]
  },
  "id_str" : "607322599518007296",
  "in_reply_to_user_id" : 14286491,
  "text" : "Well, why solve it in a sensible way when you can always hack together some crap\u2026 https:\/\/t.co\/CuT0Kojf44",
  "id" : 607322599518007296,
  "in_reply_to_status_id" : 607315281904574465,
  "created_at" : "2015-06-06 23:06:05 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35910845513121, 8.595402493386311 ]
  },
  "id_str" : "607315281904574465",
  "text" : "Is there an easy way to convert all of 1k genome vcfs to ped? Or do I always have to give region + populations w\/ vcf2ped.pl?",
  "id" : 607315281904574465,
  "created_at" : "2015-06-06 22:37:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/607312014319484928\/photo\/1",
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/dDcGZPqlIP",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CG2bDp4WcAAir0s.png",
      "id_str" : "607312011849003008",
      "id" : 607312011849003008,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CG2bDp4WcAAir0s.png",
      "sizes" : [ {
        "h" : 726,
        "resize" : "fit",
        "w" : 704
      }, {
        "h" : 726,
        "resize" : "fit",
        "w" : 704
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 659
      }, {
        "h" : 726,
        "resize" : "fit",
        "w" : 704
      } ],
      "display_url" : "pic.twitter.com\/dDcGZPqlIP"
    } ],
    "hashtags" : [ {
      "text" : "makeopendata",
      "indices" : [ 79, 92 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35906705864542, 8.59531128392233 ]
  },
  "id_str" : "607312014319484928",
  "text" : "Correctly removing the SNPs with high LD doesn\u2019t change the PCA plot too much\u2026 #makeopendata http:\/\/t.co\/dDcGZPqlIP",
  "id" : 607312014319484928,
  "created_at" : "2015-06-06 22:24:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "beau",
      "screen_name" : "beaugunderson",
      "indices" : [ 3, 17 ],
      "id_str" : "5746882",
      "id" : 5746882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "607304251900104704",
  "text" : "RT @beaugunderson: anyone have a temp or non-temp room in san francisco for a female roommate with an awesome cat? (asking for a good frien\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "607302688317935617",
    "text" : "anyone have a temp or non-temp room in san francisco for a female roommate with an awesome cat? (asking for a good friend)",
    "id" : 607302688317935617,
    "created_at" : "2015-06-06 21:46:58 +0000",
    "user" : {
      "name" : "beau",
      "screen_name" : "beaugunderson",
      "protected" : false,
      "id_str" : "5746882",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/913840034016399360\/pU3IIxqf_normal.jpg",
      "id" : 5746882,
      "verified" : false
    }
  },
  "id" : 607304251900104704,
  "created_at" : "2015-06-06 21:53:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrick Pedrioli",
      "screen_name" : "p4tp3d",
      "indices" : [ 0, 7 ],
      "id_str" : "2278267597",
      "id" : 2278267597
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/uXqGecoyJp",
      "expanded_url" : "http:\/\/make.opendata.ch\/wiki\/project:opensnp#to-do",
      "display_url" : "make.opendata.ch\/wiki\/project:o\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "607300495032623104",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35901136028335, 8.595368486035005 ]
  },
  "id_str" : "607304075819020289",
  "in_reply_to_user_id" : 2278267597,
  "text" : "@p4tp3d there are still some things left to do. Like always when doing research ;-) http:\/\/t.co\/uXqGecoyJp",
  "id" : 607304075819020289,
  "in_reply_to_status_id" : 607300495032623104,
  "created_at" : "2015-06-06 21:52:29 +0000",
  "in_reply_to_screen_name" : "p4tp3d",
  "in_reply_to_user_id_str" : "2278267597",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul-Olivier Dehaye",
      "screen_name" : "podehaye",
      "indices" : [ 0, 9 ],
      "id_str" : "2219841242",
      "id" : 2219841242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "607298167130832896",
  "geo" : { },
  "id_str" : "607299733011501056",
  "in_reply_to_user_id" : 2219841242,
  "text" : "@podehaye I did send my application already. Maybe the opencon can improve how I think of Brussels. ;)",
  "id" : 607299733011501056,
  "in_reply_to_status_id" : 607298167130832896,
  "created_at" : "2015-06-06 21:35:14 +0000",
  "in_reply_to_screen_name" : "podehaye",
  "in_reply_to_user_id_str" : "2219841242",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrick Pedrioli",
      "screen_name" : "p4tp3d",
      "indices" : [ 0, 7 ],
      "id_str" : "2278267597",
      "id" : 2278267597
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/607167640369569792\/photo\/1",
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/DDBR8WB2Tp",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CG0Xv_bW8AA7mCe.png",
      "id_str" : "607167638012358656",
      "id" : 607167638012358656,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CG0Xv_bW8AA7mCe.png",
      "sizes" : [ {
        "h" : 703,
        "resize" : "fit",
        "w" : 1033
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 463,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 703,
        "resize" : "fit",
        "w" : 1033
      }, {
        "h" : 703,
        "resize" : "fit",
        "w" : 1033
      } ],
      "display_url" : "pic.twitter.com\/DDBR8WB2Tp"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "607297954056138752",
  "geo" : { },
  "id_str" : "607299512797937664",
  "in_reply_to_user_id" : 2278267597,
  "text" : "@p4tp3d here\u2019s the one for eye color phenotype (uncleaned, so each group quite small) http:\/\/t.co\/DDBR8WB2Tp",
  "id" : 607299512797937664,
  "in_reply_to_status_id" : 607297954056138752,
  "created_at" : "2015-06-06 21:34:21 +0000",
  "in_reply_to_screen_name" : "p4tp3d",
  "in_reply_to_user_id_str" : "2278267597",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/L7IZPlBdiz",
      "expanded_url" : "https:\/\/instagram.com\/p\/3mWvLUBwml\/",
      "display_url" : "instagram.com\/p\/3mWvLUBwml\/"
    } ]
  },
  "geo" : { },
  "id_str" : "607266589474451456",
  "text" : "\u00ABForstgruppe\u00BB, should put that one on the door of the tree reconstructionists. https:\/\/t.co\/L7IZPlBdiz",
  "id" : 607266589474451456,
  "created_at" : "2015-06-06 19:23:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "607225385802022912",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.38403470665897, 8.532554685002752 ]
  },
  "id_str" : "607226705531408384",
  "in_reply_to_user_id" : 845091326,
  "text" : "@randogp great, maybe dm me your email and we can schedule a time? :-)",
  "id" : 607226705531408384,
  "in_reply_to_status_id" : 607225385802022912,
  "created_at" : "2015-06-06 16:45:02 +0000",
  "in_reply_to_screen_name" : "gianpaolo_rando",
  "in_reply_to_user_id_str" : "845091326",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "makeopendata",
      "indices" : [ 36, 49 ]
    }, {
      "text" : "opencon",
      "indices" : [ 72, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/ro9VND0vpr",
      "expanded_url" : "http:\/\/opencon2015.org\/attend",
      "display_url" : "opencon2015.org\/attend"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.38395160949644, 8.532676090516587 ]
  },
  "id_str" : "607226273958469632",
  "text" : "For those who haven\u2019t had enough of #makeopendata: Applications for the #opencon are open until 22nd of June http:\/\/t.co\/ro9VND0vpr",
  "id" : 607226273958469632,
  "created_at" : "2015-06-06 16:43:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luc Henry",
      "screen_name" : "heluc",
      "indices" : [ 0, 6 ],
      "id_str" : "850645992",
      "id" : 850645992
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/607225171804487681\/photo\/1",
      "indices" : [ 57, 79 ],
      "url" : "http:\/\/t.co\/LXSoPjveML",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CG1MEn1U8AAJLj0.jpg",
      "id_str" : "607225167060725760",
      "id" : 607225167060725760,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CG1MEn1U8AAJLj0.jpg",
      "sizes" : [ {
        "h" : 680,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2448,
        "resize" : "fit",
        "w" : 2448
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/LXSoPjveML"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "607223372301385728",
  "geo" : { },
  "id_str" : "607225171804487681",
  "in_reply_to_user_id" : 850645992,
  "text" : "@heluc I really dig the tree representation. ;) @randogp http:\/\/t.co\/LXSoPjveML",
  "id" : 607225171804487681,
  "in_reply_to_status_id" : 607223372301385728,
  "created_at" : "2015-06-06 16:38:57 +0000",
  "in_reply_to_screen_name" : "heluc",
  "in_reply_to_user_id_str" : "850645992",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "607224509993611264",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.3838404404716, 8.532451027708085 ]
  },
  "id_str" : "607224756241235968",
  "in_reply_to_user_id" : 845091326,
  "text" : "@randogp not yet, haven\u2019t really been there before. And will also only be there for a conference. But maybe after the conf I\u2019ll know some!",
  "id" : 607224756241235968,
  "in_reply_to_status_id" : 607224509993611264,
  "created_at" : "2015-06-06 16:37:18 +0000",
  "in_reply_to_screen_name" : "gianpaolo_rando",
  "in_reply_to_user_id_str" : "845091326",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ciyer",
      "screen_name" : "ciyer",
      "indices" : [ 111, 117 ],
      "id_str" : "14533425",
      "id" : 14533425
    }, {
      "name" : "Paul-Olivier Dehaye",
      "screen_name" : "podehaye",
      "indices" : [ 118, 127 ],
      "id_str" : "2219841242",
      "id" : 2219841242
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "makeopendata",
      "indices" : [ 4, 17 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/EOqTCKGoK5",
      "expanded_url" : "http:\/\/make.opendata.ch\/wiki\/project:opensnp",
      "display_url" : "make.opendata.ch\/wiki\/project:o\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.38386765401635, 8.532575630292053 ]
  },
  "id_str" : "607223582494572544",
  "text" : "The #makeopendata wiki page for the openSNP team is now a bit more complete w\/ a how-to http:\/\/t.co\/EOqTCKGoK5 @ciyer @podehaye",
  "id" : 607223582494572544,
  "created_at" : "2015-06-06 16:32:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "607216980358078465",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.38399831502861, 8.532744769740345 ]
  },
  "id_str" : "607218519030165504",
  "in_reply_to_user_id" : 845091326,
  "text" : "@randogp unfortunately I won\u2019t. Will leave Zurich tomorrow, heading for Leiden. Maybe via skype or email?",
  "id" : 607218519030165504,
  "in_reply_to_status_id" : 607216980358078465,
  "created_at" : "2015-06-06 16:12:31 +0000",
  "in_reply_to_screen_name" : "gianpaolo_rando",
  "in_reply_to_user_id_str" : "845091326",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "607152237194809344",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.38398575154968, 8.532654152530451 ]
  },
  "id_str" : "607215776915783680",
  "in_reply_to_user_id" : 845091326,
  "text" : "@randogp btw. would love to chat about beerdecoded if you have time at some point. :-)",
  "id" : 607215776915783680,
  "in_reply_to_status_id" : 607152237194809344,
  "created_at" : "2015-06-06 16:01:37 +0000",
  "in_reply_to_screen_name" : "gianpaolo_rando",
  "in_reply_to_user_id_str" : "845091326",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 3, 12 ],
      "id_str" : "14245811",
      "id" : 14245811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/bqvQIEknBs",
      "expanded_url" : "https:\/\/github.com\/Sage-Bionetworks\/PCC-Toolkit",
      "display_url" : "github.com\/Sage-Bionetwor\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "607213341589667840",
  "text" : "RT @wilbanks: PCC toolkit now live on github. If you want to contribute or build out this is the place. https:\/\/t.co\/bqvQIEknBs thanks @Bri\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Brian M Bot",
        "screen_name" : "BrianMBot",
        "indices" : [ 121, 131 ],
        "id_str" : "504127665",
        "id" : 504127665
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 90, 113 ],
        "url" : "https:\/\/t.co\/bqvQIEknBs",
        "expanded_url" : "https:\/\/github.com\/Sage-Bionetworks\/PCC-Toolkit",
        "display_url" : "github.com\/Sage-Bionetwor\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "607206269913600000",
    "text" : "PCC toolkit now live on github. If you want to contribute or build out this is the place. https:\/\/t.co\/bqvQIEknBs thanks @BrianMBot",
    "id" : 607206269913600000,
    "created_at" : "2015-06-06 15:23:50 +0000",
    "user" : {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "protected" : false,
      "id_str" : "14245811",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/925696899566440448\/BUTdp410_normal.jpg",
      "id" : 14245811,
      "verified" : false
    }
  },
  "id" : 607213341589667840,
  "created_at" : "2015-06-06 15:51:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u24EA Rik Smith-Unna \uD83C\uDDF0\uD83C\uDDEA",
      "screen_name" : "blahah404",
      "indices" : [ 3, 13 ],
      "id_str" : "99173786",
      "id" : 99173786
    }, {
      "name" : "Shaun Jackman",
      "screen_name" : "sjackman",
      "indices" : [ 47, 56 ],
      "id_str" : "8779352",
      "id" : 8779352
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 46 ],
      "url" : "https:\/\/t.co\/tGgyMz0YIM",
      "expanded_url" : "https:\/\/github.com\/Homebrew\/homebrew-science",
      "display_url" : "github.com\/Homebrew\/homeb\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "607212526820950017",
  "text" : "RT @blahah404: Over at https:\/\/t.co\/tGgyMz0YIM @sjackman is doing the bioinformatics community an incredible service. We should all help ou\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Shaun Jackman",
        "screen_name" : "sjackman",
        "indices" : [ 32, 41 ],
        "id_str" : "8779352",
        "id" : 8779352
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 8, 31 ],
        "url" : "https:\/\/t.co\/tGgyMz0YIM",
        "expanded_url" : "https:\/\/github.com\/Homebrew\/homebrew-science",
        "display_url" : "github.com\/Homebrew\/homeb\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "606585725761548288",
    "text" : "Over at https:\/\/t.co\/tGgyMz0YIM @sjackman is doing the bioinformatics community an incredible service. We should all help out a bit more.",
    "id" : 606585725761548288,
    "created_at" : "2015-06-04 22:18:01 +0000",
    "user" : {
      "name" : "\u24EA Rik Smith-Unna \uD83C\uDDF0\uD83C\uDDEA",
      "screen_name" : "blahah404",
      "protected" : false,
      "id_str" : "99173786",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/712249526577438720\/-dRs3Gg9_normal.jpg",
      "id" : 99173786,
      "verified" : false
    }
  },
  "id" : 607212526820950017,
  "created_at" : "2015-06-06 15:48:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "607212135647559681",
  "text" : "\u00ABHow do you manage to do this besides your PhD?\u00BB \u2014 \u00ABThe idea is: will code for food, will speak about openSNP for travel opportunities.\u00BB",
  "id" : 607212135647559681,
  "created_at" : "2015-06-06 15:47:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 45 ],
      "url" : "https:\/\/t.co\/ci6D0Pw0jt",
      "expanded_url" : "https:\/\/instagram.com\/p\/3l8QWYBwm1\/",
      "display_url" : "instagram.com\/p\/3l8QWYBwm1\/"
    } ]
  },
  "geo" : { },
  "id_str" : "607208356256858112",
  "text" : "Spitkits and Guitars. https:\/\/t.co\/ci6D0Pw0jt",
  "id" : 607208356256858112,
  "created_at" : "2015-06-06 15:32:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Turner",
      "screen_name" : "genetics_blog",
      "indices" : [ 3, 17 ],
      "id_str" : "923639552874557440",
      "id" : 923639552874557440
    }, {
      "name" : "Claus Wilke",
      "screen_name" : "ClausWilke",
      "indices" : [ 104, 115 ],
      "id_str" : "1679260675",
      "id" : 1679260675
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/genetics_blog\/status\/607185411786604544\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/K62PTnZsrG",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CG0n6jYWgAAbbq-.png",
      "id_str" : "607185411648159744",
      "id" : 607185411648159744,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CG0n6jYWgAAbbq-.png",
      "sizes" : [ {
        "h" : 480,
        "resize" : "fit",
        "w" : 672
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 672
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 672
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 672
      } ],
      "display_url" : "pic.twitter.com\/K62PTnZsrG"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/vl1W1IsbG7",
      "expanded_url" : "http:\/\/cran.r-project.org\/web\/packages\/cowplot\/vignettes\/introduction.html",
      "display_url" : "cran.r-project.org\/web\/packages\/c\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "607185564618641409",
  "text" : "RT @genetics_blog: Finally, labeled multi-panel ggplot2 figures made easy http:\/\/t.co\/vl1W1IsbG7 thanks @ClausWilke http:\/\/t.co\/K62PTnZsrG",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Claus Wilke",
        "screen_name" : "ClausWilke",
        "indices" : [ 85, 96 ],
        "id_str" : "1679260675",
        "id" : 1679260675
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/genetics_blog\/status\/607185411786604544\/photo\/1",
        "indices" : [ 97, 119 ],
        "url" : "http:\/\/t.co\/K62PTnZsrG",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CG0n6jYWgAAbbq-.png",
        "id_str" : "607185411648159744",
        "id" : 607185411648159744,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CG0n6jYWgAAbbq-.png",
        "sizes" : [ {
          "h" : 480,
          "resize" : "fit",
          "w" : 672
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 672
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 672
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 672
        } ],
        "display_url" : "pic.twitter.com\/K62PTnZsrG"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 55, 77 ],
        "url" : "http:\/\/t.co\/vl1W1IsbG7",
        "expanded_url" : "http:\/\/cran.r-project.org\/web\/packages\/cowplot\/vignettes\/introduction.html",
        "display_url" : "cran.r-project.org\/web\/packages\/c\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "607185411786604544",
    "text" : "Finally, labeled multi-panel ggplot2 figures made easy http:\/\/t.co\/vl1W1IsbG7 thanks @ClausWilke http:\/\/t.co\/K62PTnZsrG",
    "id" : 607185411786604544,
    "created_at" : "2015-06-06 14:00:57 +0000",
    "user" : {
      "name" : "Stephen Turner",
      "screen_name" : "strnr",
      "protected" : false,
      "id_str" : "20444825",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/660439762856230913\/ARYE5YB6_normal.jpg",
      "id" : 20444825,
      "verified" : false
    }
  },
  "id" : 607185564618641409,
  "created_at" : "2015-06-06 14:01:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/607167640369569792\/photo\/1",
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/DDBR8WB2Tp",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CG0Xv_bW8AA7mCe.png",
      "id_str" : "607167638012358656",
      "id" : 607167638012358656,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CG0Xv_bW8AA7mCe.png",
      "sizes" : [ {
        "h" : 703,
        "resize" : "fit",
        "w" : 1033
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 463,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 703,
        "resize" : "fit",
        "w" : 1033
      }, {
        "h" : 703,
        "resize" : "fit",
        "w" : 1033
      } ],
      "display_url" : "pic.twitter.com\/DDBR8WB2Tp"
    } ],
    "hashtags" : [ {
      "text" : "makeopendata",
      "indices" : [ 68, 81 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.37641219771194, 8.547687864695515 ]
  },
  "id_str" : "607167640369569792",
  "text" : "How the PCA looks like if you color it by raw user-given eye color. #makeopendata http:\/\/t.co\/DDBR8WB2Tp",
  "id" : 607167640369569792,
  "created_at" : "2015-06-06 12:50:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ciyer",
      "screen_name" : "ciyer",
      "indices" : [ 9, 15 ],
      "id_str" : "14533425",
      "id" : 14533425
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "607152237194809344",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.37643726894181, 8.5476985554427 ]
  },
  "id_str" : "607152598106415104",
  "in_reply_to_user_id" : 845091326,
  "text" : "@randogp @ciyer yes, we have the phenotype data, but won\u2019t be able to recolor in the next 5 minutes before presenting ;-)",
  "id" : 607152598106415104,
  "in_reply_to_status_id" : 607152237194809344,
  "created_at" : "2015-06-06 11:50:34 +0000",
  "in_reply_to_screen_name" : "gianpaolo_rando",
  "in_reply_to_user_id_str" : "845091326",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Schawinski",
      "screen_name" : "kevinschawinski",
      "indices" : [ 0, 16 ],
      "id_str" : "242844365",
      "id" : 242844365
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "607151810697150464",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.37643726894181, 8.5476985554427 ]
  },
  "id_str" : "607151876715515904",
  "in_reply_to_user_id" : 242844365,
  "text" : "@kevinschawinski 2nd one is already running :-)",
  "id" : 607151876715515904,
  "in_reply_to_status_id" : 607151810697150464,
  "created_at" : "2015-06-06 11:47:42 +0000",
  "in_reply_to_screen_name" : "kevinschawinski",
  "in_reply_to_user_id_str" : "242844365",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Schawinski",
      "screen_name" : "kevinschawinski",
      "indices" : [ 0, 16 ],
      "id_str" : "242844365",
      "id" : 242844365
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "607149860186374144",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.3764108533797, 8.547687641973654 ]
  },
  "id_str" : "607151287298363392",
  "in_reply_to_user_id" : 242844365,
  "text" : "@kevinschawinski thanks for dropping by, fun as always!",
  "id" : 607151287298363392,
  "in_reply_to_status_id" : 607149860186374144,
  "created_at" : "2015-06-06 11:45:21 +0000",
  "in_reply_to_screen_name" : "kevinschawinski",
  "in_reply_to_user_id_str" : "242844365",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ciyer",
      "screen_name" : "ciyer",
      "indices" : [ 78, 84 ],
      "id_str" : "14533425",
      "id" : 14533425
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/607149980214824960\/photo\/1",
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/5Tc1Am9a74",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CG0HsAPXEAAhY2k.png",
      "id_str" : "607149977324949504",
      "id" : 607149977324949504,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CG0HsAPXEAAhY2k.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 773,
        "resize" : "fit",
        "w" : 715
      }, {
        "h" : 773,
        "resize" : "fit",
        "w" : 715
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 629
      }, {
        "h" : 773,
        "resize" : "fit",
        "w" : 715
      } ],
      "display_url" : "pic.twitter.com\/5Tc1Am9a74"
    } ],
    "hashtags" : [ {
      "text" : "makeopendata",
      "indices" : [ 60, 73 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.37617170973832, 8.54724166463551 ]
  },
  "id_str" : "607149980214824960",
  "text" : "The results for the first PCA based on openSNP data are in! #makeopendata \/cc @ciyer http:\/\/t.co\/5Tc1Am9a74",
  "id" : 607149980214824960,
  "created_at" : "2015-06-06 11:40:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BOSC",
      "screen_name" : "OBF_BOSC",
      "indices" : [ 0, 9 ],
      "id_str" : "583180584",
      "id" : 583180584
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "607141984659193856",
  "geo" : { },
  "id_str" : "607142637120974848",
  "in_reply_to_user_id" : 583180584,
  "text" : "@OBF_BOSC thanks! :)",
  "id" : 607142637120974848,
  "in_reply_to_status_id" : 607141984659193856,
  "created_at" : "2015-06-06 11:10:59 +0000",
  "in_reply_to_screen_name" : "OBF_BOSC",
  "in_reply_to_user_id_str" : "583180584",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul-Olivier Dehaye",
      "screen_name" : "podehaye",
      "indices" : [ 0, 9 ],
      "id_str" : "2219841242",
      "id" : 2219841242
    }, {
      "name" : "ciyer",
      "screen_name" : "ciyer",
      "indices" : [ 10, 16 ],
      "id_str" : "14533425",
      "id" : 14533425
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "607126188046327808",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.37636185329581, 8.547574370279026 ]
  },
  "id_str" : "607138238281752576",
  "in_reply_to_user_id" : 2219841242,
  "text" : "@podehaye @ciyer yes, we also figured out too late :D",
  "id" : 607138238281752576,
  "in_reply_to_status_id" : 607126188046327808,
  "created_at" : "2015-06-06 10:53:30 +0000",
  "in_reply_to_screen_name" : "podehaye",
  "in_reply_to_user_id_str" : "2219841242",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ciyer",
      "screen_name" : "ciyer",
      "indices" : [ 0, 6 ],
      "id_str" : "14533425",
      "id" : 14533425
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "607104899944468480",
  "geo" : { },
  "id_str" : "607111244596842497",
  "in_reply_to_user_id" : 14533425,
  "text" : "@ciyer okay, removed 2245 SNPs which have been flagged as tri-allelic, which caused the crashes. Now merging again. Let\u2019s see. :-)",
  "id" : 607111244596842497,
  "in_reply_to_status_id" : 607104899944468480,
  "created_at" : "2015-06-06 09:06:14 +0000",
  "in_reply_to_screen_name" : "ciyer",
  "in_reply_to_user_id_str" : "14533425",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BOSC",
      "screen_name" : "OBF_BOSC",
      "indices" : [ 0, 9 ],
      "id_str" : "583180584",
      "id" : 583180584
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "606774349039865857",
  "geo" : { },
  "id_str" : "607108131861209088",
  "in_reply_to_user_id" : 583180584,
  "text" : "@OBF_BOSC the DB is down again. :-)",
  "id" : 607108131861209088,
  "in_reply_to_status_id" : 606774349039865857,
  "created_at" : "2015-06-06 08:53:52 +0000",
  "in_reply_to_screen_name" : "OBF_BOSC",
  "in_reply_to_user_id_str" : "583180584",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ciyer",
      "screen_name" : "ciyer",
      "indices" : [ 0, 6 ],
      "id_str" : "14533425",
      "id" : 14533425
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "607104899944468480",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.37624508526677, 8.547289404571499 ]
  },
  "id_str" : "607105148389867520",
  "in_reply_to_user_id" : 14533425,
  "text" : "@ciyer removing those broken ones is currently running. Will keep you posted on whether it works.",
  "id" : 607105148389867520,
  "in_reply_to_status_id" : 607104899944468480,
  "created_at" : "2015-06-06 08:42:01 +0000",
  "in_reply_to_screen_name" : "ciyer",
  "in_reply_to_user_id_str" : "14533425",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ciyer",
      "screen_name" : "ciyer",
      "indices" : [ 0, 6 ],
      "id_str" : "14533425",
      "id" : 14533425
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "607104899944468480",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.37624540318149, 8.547291784193435 ]
  },
  "id_str" : "607105091569643520",
  "in_reply_to_user_id" : 14533425,
  "text" : "@ciyer my workflow so far: convert each 23andMe to BED -&gt; try to merge -&gt; get a list of all broken SNPS -&gt; remove those from BED files. ;-)",
  "id" : 607105091569643520,
  "in_reply_to_status_id" : 607104899944468480,
  "created_at" : "2015-06-06 08:41:47 +0000",
  "in_reply_to_screen_name" : "ciyer",
  "in_reply_to_user_id_str" : "14533425",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Schawinski",
      "screen_name" : "kevinschawinski",
      "indices" : [ 5, 21 ],
      "id_str" : "242844365",
      "id" : 242844365
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "makeopendata",
      "indices" : [ 123, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/3ZWxp2Mrzq",
      "expanded_url" : "https:\/\/media2.giphy.com\/media\/GbzIMCw41eUBa\/200.gif",
      "display_url" : "media2.giphy.com\/media\/GbzIMCw4\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.37624979256727, 8.54732463916421 ]
  },
  "id_str" : "607102223684902912",
  "text" : "When @kevinschawinski talks about joining the human cognitive surplus to machine learning I think: https:\/\/t.co\/3ZWxp2Mrzq #makeopendata",
  "id" : 607102223684902912,
  "created_at" : "2015-06-06 08:30:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ciyer",
      "screen_name" : "ciyer",
      "indices" : [ 0, 6 ],
      "id_str" : "14533425",
      "id" : 14533425
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "607096968444301312",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.37625480719858, 8.547409874391954 ]
  },
  "id_str" : "607097366659911680",
  "in_reply_to_user_id" : 14533425,
  "text" : "@ciyer one problem: our SNPs are from different human genome builds, so position\/chromosomes differ. Have to fix\/remove those as well.",
  "id" : 607097366659911680,
  "in_reply_to_status_id" : 607096968444301312,
  "created_at" : "2015-06-06 08:11:06 +0000",
  "in_reply_to_screen_name" : "ciyer",
  "in_reply_to_user_id_str" : "14533425",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Schawinski",
      "screen_name" : "kevinschawinski",
      "indices" : [ 22, 38 ],
      "id_str" : "242844365",
      "id" : 242844365
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "makeopendata",
      "indices" : [ 42, 55 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.37625480719858, 8.547409874391954 ]
  },
  "id_str" : "607096739275939840",
  "text" : "Nearly-in time to see @kevinschawinski at #makeopendata",
  "id" : 607096739275939840,
  "created_at" : "2015-06-06 08:08:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ciyer",
      "screen_name" : "ciyer",
      "indices" : [ 0, 6 ],
      "id_str" : "14533425",
      "id" : 14533425
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "607088901421989888",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.37625480719858, 8.547409874391954 ]
  },
  "id_str" : "607096647445790721",
  "in_reply_to_user_id" : 14533425,
  "text" : "@ciyer see my pull request. :)",
  "id" : 607096647445790721,
  "in_reply_to_status_id" : 607088901421989888,
  "created_at" : "2015-06-06 08:08:14 +0000",
  "in_reply_to_screen_name" : "ciyer",
  "in_reply_to_user_id_str" : "14533425",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul-Olivier Dehaye",
      "screen_name" : "podehaye",
      "indices" : [ 3, 12 ],
      "id_str" : "2219841242",
      "id" : 2219841242
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "makeopendata",
      "indices" : [ 14, 27 ]
    } ],
    "urls" : [ {
      "indices" : [ 59, 82 ],
      "url" : "https:\/\/t.co\/5nU3ibV1vh",
      "expanded_url" : "https:\/\/github.com\/pdehaye\/ZH_hackdays_openSNP_GWAS",
      "display_url" : "github.com\/pdehaye\/ZH_hac\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "607061938732941312",
  "text" : "RT @podehaye: #makeopendata repo for doing GWAS on openSNP https:\/\/t.co\/5nU3ibV1vh",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "makeopendata",
        "indices" : [ 0, 13 ]
      } ],
      "urls" : [ {
        "indices" : [ 45, 68 ],
        "url" : "https:\/\/t.co\/5nU3ibV1vh",
        "expanded_url" : "https:\/\/github.com\/pdehaye\/ZH_hackdays_openSNP_GWAS",
        "display_url" : "github.com\/pdehaye\/ZH_hac\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "606982981908090880",
    "text" : "#makeopendata repo for doing GWAS on openSNP https:\/\/t.co\/5nU3ibV1vh",
    "id" : 606982981908090880,
    "created_at" : "2015-06-06 00:36:34 +0000",
    "user" : {
      "name" : "Paul-Olivier Dehaye",
      "screen_name" : "podehaye",
      "protected" : false,
      "id_str" : "2219841242",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/840965162349797376\/7hdkcm04_normal.jpg",
      "id" : 2219841242,
      "verified" : false
    }
  },
  "id" : 607061938732941312,
  "created_at" : "2015-06-06 05:50:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/606948718399660032\/photo\/1",
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/c5fzp1ZT5E",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CGxQpCMWgAAqNnf.png",
      "id_str" : "606948715681710080",
      "id" : 606948715681710080,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CGxQpCMWgAAqNnf.png",
      "sizes" : [ {
        "h" : 40,
        "resize" : "crop",
        "w" : 40
      }, {
        "h" : 33,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 40,
        "resize" : "fit",
        "w" : 831
      }, {
        "h" : 40,
        "resize" : "fit",
        "w" : 831
      }, {
        "h" : 40,
        "resize" : "fit",
        "w" : 831
      } ],
      "display_url" : "pic.twitter.com\/c5fzp1ZT5E"
    } ],
    "hashtags" : [ {
      "text" : "makeopendata",
      "indices" : [ 56, 69 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.06353836744595, 7.088479247691369 ]
  },
  "id_str" : "606948718399660032",
  "text" : "PLINK is so easy to use, it barely needs documentation. #makeopendata http:\/\/t.co\/c5fzp1ZT5E",
  "id" : 606948718399660032,
  "created_at" : "2015-06-05 22:20:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul-Olivier Dehaye",
      "screen_name" : "podehaye",
      "indices" : [ 0, 9 ],
      "id_str" : "2219841242",
      "id" : 2219841242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "606946789908971520",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.06353879383934, 7.088479156414902 ]
  },
  "id_str" : "606947006586757121",
  "in_reply_to_user_id" : 2219841242,
  "text" : "@podehaye haven\u2019t looked into correlation with self-reported chromosomal sex. Numbers are what PLINK reports. Currently merging those.",
  "id" : 606947006586757121,
  "in_reply_to_status_id" : 606946789908971520,
  "created_at" : "2015-06-05 22:13:37 +0000",
  "in_reply_to_screen_name" : "podehaye",
  "in_reply_to_user_id_str" : "2219841242",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.06353879383934, 7.088479156414902 ]
  },
  "id_str" : "606945793556271104",
  "text" : "Chromosomal sex split on 1423 23andMe data sets found on openSNP: 578 XX, 845 XY.",
  "id" : 606945793556271104,
  "created_at" : "2015-06-05 22:08:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "606931914411393024",
  "text" : "\u00ABIs he making you work?!\u00BB \u2013 \u00ABActually, no, it\u2019s just that I like work. You know how it is.\u00BB \u2013 \u00ABI know, I married someone who\u2019s like that!\u00BB",
  "id" : 606931914411393024,
  "created_at" : "2015-06-05 21:13:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Schawinski",
      "screen_name" : "kevinschawinski",
      "indices" : [ 0, 16 ],
      "id_str" : "242844365",
      "id" : 242844365
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "606911896588009474",
  "geo" : { },
  "id_str" : "606912260385210368",
  "in_reply_to_user_id" : 242844365,
  "text" : "@kevinschawinski that sounds much better already. :-)",
  "id" : 606912260385210368,
  "in_reply_to_status_id" : 606911896588009474,
  "created_at" : "2015-06-05 19:55:33 +0000",
  "in_reply_to_screen_name" : "kevinschawinski",
  "in_reply_to_user_id_str" : "242844365",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Schawinski",
      "screen_name" : "kevinschawinski",
      "indices" : [ 0, 16 ],
      "id_str" : "242844365",
      "id" : 242844365
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "606911170503688193",
  "geo" : { },
  "id_str" : "606911626315485184",
  "in_reply_to_user_id" : 242844365,
  "text" : "@kevinschawinski Oh, cmon, I\u2019m not in Zurich that often. ;-)",
  "id" : 606911626315485184,
  "in_reply_to_status_id" : 606911170503688193,
  "created_at" : "2015-06-05 19:53:02 +0000",
  "in_reply_to_screen_name" : "kevinschawinski",
  "in_reply_to_user_id_str" : "242844365",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Schawinski",
      "screen_name" : "kevinschawinski",
      "indices" : [ 0, 16 ],
      "id_str" : "242844365",
      "id" : 242844365
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "606910708845027328",
  "geo" : { },
  "id_str" : "606911009681510400",
  "in_reply_to_user_id" : 242844365,
  "text" : "@kevinschawinski I think being there at maybe 09:30 should work out for me. Will you be there all day\/be there for beer afterwards?",
  "id" : 606911009681510400,
  "in_reply_to_status_id" : 606910708845027328,
  "created_at" : "2015-06-05 19:50:35 +0000",
  "in_reply_to_screen_name" : "kevinschawinski",
  "in_reply_to_user_id_str" : "242844365",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Schawinski",
      "screen_name" : "kevinschawinski",
      "indices" : [ 0, 16 ],
      "id_str" : "242844365",
      "id" : 242844365
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "606910651701837825",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.06364931251617, 7.089074245357568 ]
  },
  "id_str" : "606910747659116544",
  "in_reply_to_user_id" : 242844365,
  "text" : "@kevinschawinski so you\u2019re saying I don\u2019t need to be there? :P",
  "id" : 606910747659116544,
  "in_reply_to_status_id" : 606910651701837825,
  "created_at" : "2015-06-05 19:49:32 +0000",
  "in_reply_to_screen_name" : "kevinschawinski",
  "in_reply_to_user_id_str" : "242844365",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Schawinski",
      "screen_name" : "kevinschawinski",
      "indices" : [ 0, 16 ],
      "id_str" : "242844365",
      "id" : 242844365
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "606910353017053187",
  "geo" : { },
  "id_str" : "606910500472029184",
  "in_reply_to_user_id" : 242844365,
  "text" : "@kevinschawinski yes, when\u2019s your talk again? Aka: do I need to be there at 9 sharp?",
  "id" : 606910500472029184,
  "in_reply_to_status_id" : 606910353017053187,
  "created_at" : "2015-06-05 19:48:33 +0000",
  "in_reply_to_screen_name" : "kevinschawinski",
  "in_reply_to_user_id_str" : "242844365",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ciyer",
      "screen_name" : "ciyer",
      "indices" : [ 41, 47 ],
      "id_str" : "14533425",
      "id" : 14533425
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "makeopendata",
      "indices" : [ 49, 62 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/3nDcmFBlNa",
      "expanded_url" : "https:\/\/github.com\/ciyer\/opensnp-fun",
      "display_url" : "github.com\/ciyer\/opensnp-\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "606867492435292161",
  "geo" : { },
  "id_str" : "606910115229396993",
  "in_reply_to_user_id" : 14533425,
  "text" : "Looking forward to work more on this! RT @ciyer: #makeopendata Repo for doing PCA on openSNP \nhttps:\/\/t.co\/3nDcmFBlNa",
  "id" : 606910115229396993,
  "in_reply_to_status_id" : 606867492435292161,
  "created_at" : "2015-06-05 19:47:01 +0000",
  "in_reply_to_screen_name" : "ciyer",
  "in_reply_to_user_id_str" : "14533425",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul-Olivier Dehaye",
      "screen_name" : "podehaye",
      "indices" : [ 0, 9 ],
      "id_str" : "2219841242",
      "id" : 2219841242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "606901581133455360",
  "geo" : { },
  "id_str" : "606909620200816640",
  "in_reply_to_user_id" : 2219841242,
  "text" : "@podehaye great, will do. Thanks :)",
  "id" : 606909620200816640,
  "in_reply_to_status_id" : 606901581133455360,
  "created_at" : "2015-06-05 19:45:03 +0000",
  "in_reply_to_screen_name" : "podehaye",
  "in_reply_to_user_id_str" : "2219841242",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul-Olivier Dehaye",
      "screen_name" : "podehaye",
      "indices" : [ 0, 9 ],
      "id_str" : "2219841242",
      "id" : 2219841242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "606889778617962497",
  "geo" : { },
  "id_str" : "606901145710297088",
  "in_reply_to_user_id" : 2219841242,
  "text" : "@podehaye thx. Don\u2019t need a place for tonight. But tomorrow would be great!",
  "id" : 606901145710297088,
  "in_reply_to_status_id" : 606889778617962497,
  "created_at" : "2015-06-05 19:11:23 +0000",
  "in_reply_to_screen_name" : "podehaye",
  "in_reply_to_user_id_str" : "2219841242",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Oleg Lavrovsky",
      "screen_name" : "loleg",
      "indices" : [ 3, 9 ],
      "id_str" : "5429882",
      "id" : 5429882
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/loleg\/status\/606779436038541312\/photo\/1",
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/nKLgHe0x5C",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CGu2rTOW8AAG3-o.jpg",
      "id_str" : "606779429822590976",
      "id" : 606779429822590976,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CGu2rTOW8AAG3-o.jpg",
      "sizes" : [ {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/nKLgHe0x5C"
    } ],
    "hashtags" : [ {
      "text" : "makeopendata",
      "indices" : [ 54, 67 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "606781429461217280",
  "text" : "RT @loleg: Beer data disected in situ at the Lausanne #makeopendata http:\/\/t.co\/nKLgHe0x5C",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/loleg\/status\/606779436038541312\/photo\/1",
        "indices" : [ 57, 79 ],
        "url" : "http:\/\/t.co\/nKLgHe0x5C",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CGu2rTOW8AAG3-o.jpg",
        "id_str" : "606779429822590976",
        "id" : 606779429822590976,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CGu2rTOW8AAG3-o.jpg",
        "sizes" : [ {
          "h" : 680,
          "resize" : "fit",
          "w" : 510
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        } ],
        "display_url" : "pic.twitter.com\/nKLgHe0x5C"
      } ],
      "hashtags" : [ {
        "text" : "makeopendata",
        "indices" : [ 43, 56 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "606779436038541312",
    "text" : "Beer data disected in situ at the Lausanne #makeopendata http:\/\/t.co\/nKLgHe0x5C",
    "id" : 606779436038541312,
    "created_at" : "2015-06-05 11:07:45 +0000",
    "user" : {
      "name" : "Oleg Lavrovsky",
      "screen_name" : "loleg",
      "protected" : false,
      "id_str" : "5429882",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/843805445986893824\/zBNormYJ_normal.jpg",
      "id" : 5429882,
      "verified" : false
    }
  },
  "id" : 606781429461217280,
  "created_at" : "2015-06-05 11:15:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Opendata.ch",
      "screen_name" : "OpendataCH",
      "indices" : [ 3, 14 ],
      "id_str" : "362585949",
      "id" : 362585949
    }, {
      "name" : "ETH Z\u00FCrich",
      "screen_name" : "ETH",
      "indices" : [ 65, 69 ],
      "id_str" : "202806809",
      "id" : 202806809
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/OpendataCH\/status\/606758340492992512\/photo\/1",
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/rhB7Ba2Nxa",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CGujfsZWcAAJVa4.jpg",
      "id_str" : "606758339700224000",
      "id" : 606758339700224000,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CGujfsZWcAAJVa4.jpg",
      "sizes" : [ {
        "h" : 578,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 578,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 578,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 384,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/rhB7Ba2Nxa"
    } ],
    "hashtags" : [ {
      "text" : "makeopendata",
      "indices" : [ 34, 47 ]
    }, {
      "text" : "zurich",
      "indices" : [ 70, 77 ]
    }, {
      "text" : "opendata",
      "indices" : [ 78, 87 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "606781301341995008",
  "text" : "RT @OpendataCH: Full house at the #makeopendata research hackday @ETH #zurich #opendata http:\/\/t.co\/rhB7Ba2Nxa",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "ETH Z\u00FCrich",
        "screen_name" : "ETH",
        "indices" : [ 49, 53 ],
        "id_str" : "202806809",
        "id" : 202806809
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/OpendataCH\/status\/606758340492992512\/photo\/1",
        "indices" : [ 72, 94 ],
        "url" : "http:\/\/t.co\/rhB7Ba2Nxa",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CGujfsZWcAAJVa4.jpg",
        "id_str" : "606758339700224000",
        "id" : 606758339700224000,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CGujfsZWcAAJVa4.jpg",
        "sizes" : [ {
          "h" : 578,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 578,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 578,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 384,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/rhB7Ba2Nxa"
      } ],
      "hashtags" : [ {
        "text" : "makeopendata",
        "indices" : [ 18, 31 ]
      }, {
        "text" : "zurich",
        "indices" : [ 54, 61 ]
      }, {
        "text" : "opendata",
        "indices" : [ 62, 71 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "606758340492992512",
    "text" : "Full house at the #makeopendata research hackday @ETH #zurich #opendata http:\/\/t.co\/rhB7Ba2Nxa",
    "id" : 606758340492992512,
    "created_at" : "2015-06-05 09:43:56 +0000",
    "user" : {
      "name" : "Opendata.ch",
      "screen_name" : "OpendataCH",
      "protected" : false,
      "id_str" : "362585949",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2275597832\/rkcs2zdz9h3c8jfw7lbo_normal.png",
      "id" : 362585949,
      "verified" : false
    }
  },
  "id" : 606781301341995008,
  "created_at" : "2015-06-05 11:15:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/606733986782674944\/photo\/1",
      "indices" : [ 46, 68 ],
      "url" : "http:\/\/t.co\/6DCThu4XMe",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CGuNV_WVAAAqv8P.jpg",
      "id_str" : "606733983733317632",
      "id" : 606733983733317632,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CGuNV_WVAAAqv8P.jpg",
      "sizes" : [ {
        "h" : 680,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2448,
        "resize" : "fit",
        "w" : 2448
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/6DCThu4XMe"
    } ],
    "hashtags" : [ {
      "text" : "makeopendata",
      "indices" : [ 32, 45 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "606733986782674944",
  "text" : "Mass Spectrometry for Children. #makeopendata http:\/\/t.co\/6DCThu4XMe",
  "id" : 606733986782674944,
  "created_at" : "2015-06-05 08:07:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ali",
      "screen_name" : "zoonpolitikon",
      "indices" : [ 0, 14 ],
      "id_str" : "13040652",
      "id" : 13040652
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 21, 30 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "606730780899999744",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.37644136595929, 8.547652786209085 ]
  },
  "id_str" : "606733747464077313",
  "in_reply_to_user_id" : 13040652,
  "text" : "@zoonpolitikon maybe @Senficon can forward it?",
  "id" : 606733747464077313,
  "in_reply_to_status_id" : 606730780899999744,
  "created_at" : "2015-06-05 08:06:12 +0000",
  "in_reply_to_screen_name" : "zoonpolitikon",
  "in_reply_to_user_id_str" : "13040652",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Senficon\/status\/606398111913807872\/photo\/1",
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/4Pb72tq3av",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CGpb3lTWQAAGmhB.png",
      "id_str" : "606398110298947584",
      "id" : 606398110298947584,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CGpb3lTWQAAGmhB.png",
      "sizes" : [ {
        "h" : 574,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 574,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 488,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 574,
        "resize" : "fit",
        "w" : 800
      } ],
      "display_url" : "pic.twitter.com\/4Pb72tq3av"
    } ],
    "hashtags" : [ {
      "text" : "copywrongs",
      "indices" : [ 8, 19 ]
    }, {
      "text" : "makeopendata",
      "indices" : [ 63, 76 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/Tt3BqVXbc9",
      "expanded_url" : "http:\/\/copywrongs.eu\/",
      "display_url" : "copywrongs.eu"
    } ]
  },
  "geo" : { },
  "id_str" : "606729792763887616",
  "text" : "I think #copywrongs might also be of interest for some here at #makeopendata: http:\/\/t.co\/Tt3BqVXbc9 http:\/\/t.co\/4Pb72tq3av",
  "id" : 606729792763887616,
  "created_at" : "2015-06-05 07:50:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hannes Gassert",
      "screen_name" : "hannesgassert",
      "indices" : [ 0, 14 ],
      "id_str" : "163961205",
      "id" : 163961205
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "606728194356559872",
  "geo" : { },
  "id_str" : "606728368378290176",
  "in_reply_to_user_id" : 163961205,
  "text" : "@hannesgassert thx :)",
  "id" : 606728368378290176,
  "in_reply_to_status_id" : 606728194356559872,
  "created_at" : "2015-06-05 07:44:50 +0000",
  "in_reply_to_screen_name" : "hannesgassert",
  "in_reply_to_user_id_str" : "163961205",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hannes Gassert",
      "screen_name" : "hannesgassert",
      "indices" : [ 0, 14 ],
      "id_str" : "163961205",
      "id" : 163961205
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "606071880416698368",
  "geo" : { },
  "id_str" : "606728066900094977",
  "in_reply_to_user_id" : 163961205,
  "text" : "@hannesgassert btw: is there a hashtag for the event? ;)",
  "id" : 606728066900094977,
  "in_reply_to_status_id" : 606071880416698368,
  "created_at" : "2015-06-05 07:43:38 +0000",
  "in_reply_to_screen_name" : "hannesgassert",
  "in_reply_to_user_id_str" : "163961205",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ToxX",
      "screen_name" : "ToxXInFlames",
      "indices" : [ 0, 13 ],
      "id_str" : "1421360166",
      "id" : 1421360166
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "606554522068992001",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.06299906712035, 7.108755272677437 ]
  },
  "id_str" : "606555159284453377",
  "in_reply_to_user_id" : 1421360166,
  "text" : "@ToxXInFlames well 28c3 has been a while. It still feels as improvised as then, but the actual level of improv has risen I guess.",
  "id" : 606555159284453377,
  "in_reply_to_status_id" : 606554522068992001,
  "created_at" : "2015-06-04 20:16:33 +0000",
  "in_reply_to_screen_name" : "ToxXInFlames",
  "in_reply_to_user_id_str" : "1421360166",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ToxX",
      "screen_name" : "ToxXInFlames",
      "indices" : [ 0, 13 ],
      "id_str" : "1421360166",
      "id" : 1421360166
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "606552483561771009",
  "geo" : { },
  "id_str" : "606553663541116928",
  "in_reply_to_user_id" : 1421360166,
  "text" : "@ToxXInFlames because otherwise you\u2019d know that the description is rather fitting. ;)",
  "id" : 606553663541116928,
  "in_reply_to_status_id" : 606552483561771009,
  "created_at" : "2015-06-04 20:10:37 +0000",
  "in_reply_to_screen_name" : "ToxXInFlames",
  "in_reply_to_user_id_str" : "1421360166",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ToxX",
      "screen_name" : "ToxXInFlames",
      "indices" : [ 0, 13 ],
      "id_str" : "1421360166",
      "id" : 1421360166
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "606550602881994752",
  "geo" : { },
  "id_str" : "606551290630402052",
  "in_reply_to_user_id" : 1421360166,
  "text" : "@ToxXInFlames you already did see me give a talk, didn\u2019t you? ;)",
  "id" : 606551290630402052,
  "in_reply_to_status_id" : 606550602881994752,
  "created_at" : "2015-06-04 20:01:11 +0000",
  "in_reply_to_screen_name" : "ToxXInFlames",
  "in_reply_to_user_id_str" : "1421360166",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "606547457351106561",
  "text" : "\u00ABSo you have no idea where &amp; when you will give the talk tomorrow and neither about the topic and for how long? You\u2019re living the dream!\u00BB",
  "id" : 606547457351106561,
  "created_at" : "2015-06-04 19:45:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Spear",
      "screen_name" : "mikesgene",
      "indices" : [ 3, 13 ],
      "id_str" : "13395272",
      "id" : 13395272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "606479933590933505",
  "text" : "RT @mikesgene: One tonne of smartphones can produce 324 times more gold than one tonne of ore from a traditional mine. http:\/\/t.co\/mzss2wll\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "recycle",
        "indices" : [ 127, 135 ]
      } ],
      "urls" : [ {
        "indices" : [ 104, 126 ],
        "url" : "http:\/\/t.co\/mzss2wll9e",
        "expanded_url" : "http:\/\/ow.ly\/NShEC",
        "display_url" : "ow.ly\/NShEC"
      } ]
    },
    "geo" : { },
    "id_str" : "606477806768410625",
    "text" : "One tonne of smartphones can produce 324 times more gold than one tonne of ore from a traditional mine. http:\/\/t.co\/mzss2wll9e #recycle",
    "id" : 606477806768410625,
    "created_at" : "2015-06-04 15:09:11 +0000",
    "user" : {
      "name" : "Mike Spear",
      "screen_name" : "mikesgene",
      "protected" : false,
      "id_str" : "13395272",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/543069730249011200\/xHhZnJGZ_normal.jpeg",
      "id" : 13395272,
      "verified" : false
    }
  },
  "id" : 606479933590933505,
  "created_at" : "2015-06-04 15:17:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Keith Bradnam",
      "screen_name" : "kbradnam",
      "indices" : [ 3, 12 ],
      "id_str" : "17061155",
      "id" : 17061155
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/PaQW9vpxMz",
      "expanded_url" : "http:\/\/www.bbc.co.uk\/news\/magazine-32993891",
      "display_url" : "bbc.co.uk\/news\/magazine-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "606467375031009280",
  "text" : "RT @kbradnam: An uplifting tale of strangers coming together to save someone: 'When 100 people lift a bus' http:\/\/t.co\/PaQW9vpxMz",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 93, 115 ],
        "url" : "http:\/\/t.co\/PaQW9vpxMz",
        "expanded_url" : "http:\/\/www.bbc.co.uk\/news\/magazine-32993891",
        "display_url" : "bbc.co.uk\/news\/magazine-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "606465311915667457",
    "text" : "An uplifting tale of strangers coming together to save someone: 'When 100 people lift a bus' http:\/\/t.co\/PaQW9vpxMz",
    "id" : 606465311915667457,
    "created_at" : "2015-06-04 14:19:32 +0000",
    "user" : {
      "name" : "Keith Bradnam",
      "screen_name" : "kbradnam",
      "protected" : false,
      "id_str" : "17061155",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/583756306919489538\/D2fFCYq4_normal.jpg",
      "id" : 17061155,
      "verified" : false
    }
  },
  "id" : 606467375031009280,
  "created_at" : "2015-06-04 14:27:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dierk Haasis",
      "screen_name" : "Evo2Me",
      "indices" : [ 0, 7 ],
      "id_str" : "22910316",
      "id" : 22910316
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "606460397869105154",
  "geo" : { },
  "id_str" : "606466254048792576",
  "in_reply_to_user_id" : 22910316,
  "text" : "@Evo2Me opening the roof will just fry my brain ;)",
  "id" : 606466254048792576,
  "in_reply_to_status_id" : 606460397869105154,
  "created_at" : "2015-06-04 14:23:17 +0000",
  "in_reply_to_screen_name" : "Evo2Me",
  "in_reply_to_user_id_str" : "22910316",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul-Olivier Dehaye",
      "screen_name" : "podehaye",
      "indices" : [ 0, 9 ],
      "id_str" : "2219841242",
      "id" : 2219841242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "606460993884065792",
  "geo" : { },
  "id_str" : "606466208658030594",
  "in_reply_to_user_id" : 2219841242,
  "text" : "@podehaye me too. Never participated in one so far. :)",
  "id" : 606466208658030594,
  "in_reply_to_status_id" : 606460993884065792,
  "created_at" : "2015-06-04 14:23:06 +0000",
  "in_reply_to_screen_name" : "podehaye",
  "in_reply_to_user_id_str" : "2219841242",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "606460073150435328",
  "text" : "32 \u00B0C. Perfect conditions to spend 5+ h in a car w\/o AC.",
  "id" : 606460073150435328,
  "created_at" : "2015-06-04 13:58:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Beth \uD83D\uDC3A",
      "screen_name" : "PhdGeek",
      "indices" : [ 0, 8 ],
      "id_str" : "27841081",
      "id" : 27841081
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "606446638069121024",
  "geo" : { },
  "id_str" : "606451759410774016",
  "in_reply_to_user_id" : 27841081,
  "text" : "@PhdGeek thanks for the reminder. Similar here!",
  "id" : 606451759410774016,
  "in_reply_to_status_id" : 606446638069121024,
  "created_at" : "2015-06-04 13:25:41 +0000",
  "in_reply_to_screen_name" : "PhdGeek",
  "in_reply_to_user_id_str" : "27841081",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BOSC",
      "screen_name" : "OBF_BOSC",
      "indices" : [ 3, 12 ],
      "id_str" : "583180584",
      "id" : 583180584
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BOSC2015",
      "indices" : [ 72, 81 ]
    }, {
      "text" : "ISMBECCB",
      "indices" : [ 86, 95 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "606446020633849856",
  "text" : "RT @OBF_BOSC: Tomorrow (Friday 5th) is your last change to register for #BOSC2015 and #ISMBECCB in Dublin at the discounted rate: https:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BOSC2015",
        "indices" : [ 58, 67 ]
      }, {
        "text" : "ISMBECCB",
        "indices" : [ 72, 81 ]
      } ],
      "urls" : [ {
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/aQUrEODOEC",
        "expanded_url" : "https:\/\/www.iscb.org\/ismbeccb2015-registration#registrationfee",
        "display_url" : "iscb.org\/ismbeccb2015-r\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "606444412315541504",
    "text" : "Tomorrow (Friday 5th) is your last change to register for #BOSC2015 and #ISMBECCB in Dublin at the discounted rate: https:\/\/t.co\/aQUrEODOEC",
    "id" : 606444412315541504,
    "created_at" : "2015-06-04 12:56:29 +0000",
    "user" : {
      "name" : "BOSC",
      "screen_name" : "OBF_BOSC",
      "protected" : false,
      "id_str" : "583180584",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2227105401\/BOSC-logo-square_normal.jpg",
      "id" : 583180584,
      "verified" : false
    }
  },
  "id" : 606446020633849856,
  "created_at" : "2015-06-04 13:02:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc RobinsonRechavi",
      "screen_name" : "marc_rr",
      "indices" : [ 3, 11 ],
      "id_str" : "454724555",
      "id" : 454724555
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/JaByaCXATN",
      "expanded_url" : "https:\/\/liorpachter.wordpress.com\/2015\/05\/26\/pachters-p-value-prize\/#comment-4438",
      "display_url" : "liorpachter.wordpress.com\/2015\/05\/26\/pac\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "606402217218871296",
  "text" : "RT @marc_rr: 2\/3 \"computational culture should become a job requirement for Nature\/Science editors and reviewers\u201D https:\/\/t.co\/JaByaCXATN",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 101, 124 ],
        "url" : "https:\/\/t.co\/JaByaCXATN",
        "expanded_url" : "https:\/\/liorpachter.wordpress.com\/2015\/05\/26\/pachters-p-value-prize\/#comment-4438",
        "display_url" : "liorpachter.wordpress.com\/2015\/05\/26\/pac\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "606366595636551680",
    "text" : "2\/3 \"computational culture should become a job requirement for Nature\/Science editors and reviewers\u201D https:\/\/t.co\/JaByaCXATN",
    "id" : 606366595636551680,
    "created_at" : "2015-06-04 07:47:16 +0000",
    "user" : {
      "name" : "Marc RobinsonRechavi",
      "screen_name" : "marc_rr",
      "protected" : false,
      "id_str" : "454724555",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1751744306\/mrr_caricature_normal.jpg",
      "id" : 454724555,
      "verified" : false
    }
  },
  "id" : 606402217218871296,
  "created_at" : "2015-06-04 10:08:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexis Verger",
      "screen_name" : "Alexis_Verger",
      "indices" : [ 3, 17 ],
      "id_str" : "526226529",
      "id" : 526226529
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Alexis_Verger\/status\/606393976246181888\/photo\/1",
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/UnPU6DU3O1",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CGpYG5JXIAAJvD3.png",
      "id_str" : "606393975277297664",
      "id" : 606393975277297664,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CGpYG5JXIAAJvD3.png",
      "sizes" : [ {
        "h" : 76,
        "resize" : "fit",
        "w" : 784
      }, {
        "h" : 76,
        "resize" : "fit",
        "w" : 784
      }, {
        "h" : 76,
        "resize" : "crop",
        "w" : 76
      }, {
        "h" : 76,
        "resize" : "fit",
        "w" : 784
      }, {
        "h" : 66,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/UnPU6DU3O1"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/zLDAd3GOdA",
      "expanded_url" : "http:\/\/www.sciencedirect.com\/science\/article\/pii\/S002228360093729X",
      "display_url" : "sciencedirect.com\/science\/articl\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "606397959639564288",
  "text" : "RT @Alexis_Verger: Codon, exon, intron, operon, duon and ....... moron http:\/\/t.co\/zLDAd3GOdA http:\/\/t.co\/UnPU6DU3O1",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Alexis_Verger\/status\/606393976246181888\/photo\/1",
        "indices" : [ 75, 97 ],
        "url" : "http:\/\/t.co\/UnPU6DU3O1",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CGpYG5JXIAAJvD3.png",
        "id_str" : "606393975277297664",
        "id" : 606393975277297664,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CGpYG5JXIAAJvD3.png",
        "sizes" : [ {
          "h" : 76,
          "resize" : "fit",
          "w" : 784
        }, {
          "h" : 76,
          "resize" : "fit",
          "w" : 784
        }, {
          "h" : 76,
          "resize" : "crop",
          "w" : 76
        }, {
          "h" : 76,
          "resize" : "fit",
          "w" : 784
        }, {
          "h" : 66,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/UnPU6DU3O1"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 52, 74 ],
        "url" : "http:\/\/t.co\/zLDAd3GOdA",
        "expanded_url" : "http:\/\/www.sciencedirect.com\/science\/article\/pii\/S002228360093729X",
        "display_url" : "sciencedirect.com\/science\/articl\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "606393976246181888",
    "text" : "Codon, exon, intron, operon, duon and ....... moron http:\/\/t.co\/zLDAd3GOdA http:\/\/t.co\/UnPU6DU3O1",
    "id" : 606393976246181888,
    "created_at" : "2015-06-04 09:36:04 +0000",
    "user" : {
      "name" : "Alexis Verger",
      "screen_name" : "Alexis_Verger",
      "protected" : false,
      "id_str" : "526226529",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/835124540644687872\/cGunCLz9_normal.jpg",
      "id" : 526226529,
      "verified" : false
    }
  },
  "id" : 606397959639564288,
  "created_at" : "2015-06-04 09:51:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathan Eisen, Guardian of Microbial Diversity \uD83D\uDCA5\uD83D\uDD06",
      "screen_name" : "phylogenomics",
      "indices" : [ 62, 76 ],
      "id_str" : "15154811",
      "id" : 15154811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "606378310885621760",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11433657263416, 8.753729006283686 ]
  },
  "id_str" : "606378768148611072",
  "in_reply_to_user_id" : 14286491,
  "text" : "But seriously, the \u00ABthe stylistic genome (\u201Cstylome\u201D)\u00BB? I hope @phylogenomics took notice\u2026",
  "id" : 606378768148611072,
  "in_reply_to_status_id" : 606378310885621760,
  "created_at" : "2015-06-04 08:35:38 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/CtYvxnbPNU",
      "expanded_url" : "http:\/\/journals.plos.org\/plosone\/article?id=10.1371\/journal.pone.0126470",
      "display_url" : "journals.plos.org\/plosone\/articl\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.114375, 8.753666 ]
  },
  "id_str" : "606378310885621760",
  "text" : "Text Mining the Topology of Social Networks Extracted from Literature (i.e. Harry Potter) http:\/\/t.co\/CtYvxnbPNU",
  "id" : 606378310885621760,
  "created_at" : "2015-06-04 08:33:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Schawinski",
      "screen_name" : "kevinschawinski",
      "indices" : [ 0, 16 ],
      "id_str" : "242844365",
      "id" : 242844365
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 78 ],
      "url" : "https:\/\/t.co\/mkkgKBeCec",
      "expanded_url" : "https:\/\/40.media.tumblr.com\/19a05b27166cd2ef4128db96020bf432\/tumblr_na6qxntlc51somw7ho3_500.png",
      "display_url" : "40.media.tumblr.com\/19a05b27166cd2\u2026"
    }, {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/UAX42Ys3CY",
      "expanded_url" : "http:\/\/www.rcfp.org\/browse-media-law-resources\/news\/abc-ordered-hand-over-unedited-head-drilling-tapes",
      "display_url" : "rcfp.org\/browse-media-l\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "606373138302136320",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1139758200181, 8.75340652550978 ]
  },
  "id_str" : "606374338405797888",
  "in_reply_to_user_id" : 242844365,
  "text" : "@kevinschawinski speed holes to make you think faster! https:\/\/t.co\/mkkgKBeCec(not as far fetched actually: http:\/\/t.co\/UAX42Ys3CY)",
  "id" : 606374338405797888,
  "in_reply_to_status_id" : 606373138302136320,
  "created_at" : "2015-06-04 08:18:02 +0000",
  "in_reply_to_screen_name" : "kevinschawinski",
  "in_reply_to_user_id_str" : "242844365",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Schawinski",
      "screen_name" : "kevinschawinski",
      "indices" : [ 0, 16 ],
      "id_str" : "242844365",
      "id" : 242844365
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/mP3IByYkr0",
      "expanded_url" : "http:\/\/i.telegraph.co.uk\/multimedia\/archive\/02108\/operating620_2108553b.jpg",
      "display_url" : "i.telegraph.co.uk\/multimedia\/arc\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "606372218952642560",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11405389483859, 8.753175709999507 ]
  },
  "id_str" : "606372999890145281",
  "in_reply_to_user_id" : 242844365,
  "text" : "@kevinschawinski this i somehow doubt, but it seems the victorian operating theatre is making a 2.0 comeback. ;) http:\/\/t.co\/mP3IByYkr0",
  "id" : 606372999890145281,
  "in_reply_to_status_id" : 606372218952642560,
  "created_at" : "2015-06-04 08:12:43 +0000",
  "in_reply_to_screen_name" : "kevinschawinski",
  "in_reply_to_user_id_str" : "242844365",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/uSrKylBpbA",
      "expanded_url" : "http:\/\/boingboing.net\/2015\/06\/03\/man-plays-beatles-song-yeste.html?utm_source=feedburner&utm_medium=feed&utm_campaign=Feed%3A+boingboing%2FiBag+%28Boing+Boing%29",
      "display_url" : "boingboing.net\/2015\/06\/03\/man\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "606371421015687168",
  "text" : "Taping your brain surgery seems to be the next big thing. http:\/\/t.co\/uSrKylBpbA",
  "id" : 606371421015687168,
  "created_at" : "2015-06-04 08:06:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 39 ],
      "url" : "https:\/\/t.co\/5X6omDsTkN",
      "expanded_url" : "https:\/\/ambikamath.wordpress.com\/2015\/06\/03\/dont-ask-alice\/",
      "display_url" : "ambikamath.wordpress.com\/2015\/06\/03\/don\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11407558022398, 8.753322628667012 ]
  },
  "id_str" : "606367723401187328",
  "text" : "Don\u2019t Ask Alice https:\/\/t.co\/5X6omDsTkN",
  "id" : 606367723401187328,
  "created_at" : "2015-06-04 07:51:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brad Voytek",
      "screen_name" : "bradleyvoytek",
      "indices" : [ 3, 17 ],
      "id_str" : "162535413",
      "id" : 162535413
    }, {
      "name" : "The Pete Holmes Show",
      "screen_name" : "PeteHolmesShow",
      "indices" : [ 95, 110 ],
      "id_str" : "544912959",
      "id" : 544912959
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/qISsAUFj6m",
      "expanded_url" : "http:\/\/bit.ly\/1Fvqevs",
      "display_url" : "bit.ly\/1Fvqevs"
    } ]
  },
  "geo" : { },
  "id_str" : "606355372539027456",
  "text" : "RT @bradleyvoytek: Sherlock Holmes sucks at deduction. Love the show but this really bugs me. (@PeteHolmesShow) http:\/\/t.co\/qISsAUFj6m http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The Pete Holmes Show",
        "screen_name" : "PeteHolmesShow",
        "indices" : [ 76, 91 ],
        "id_str" : "544912959",
        "id" : 544912959
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/bradleyvoytek\/status\/606280951027494912\/photo\/1",
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/LhqT27ZYPO",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CGnxT_IUIAAnelp.jpg",
        "id_str" : "606280950524157952",
        "id" : 606280950524157952,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CGnxT_IUIAAnelp.jpg",
        "sizes" : [ {
          "h" : 1470,
          "resize" : "fit",
          "w" : 1598
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 626,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1104,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 1470,
          "resize" : "fit",
          "w" : 1598
        } ],
        "display_url" : "pic.twitter.com\/LhqT27ZYPO"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 93, 115 ],
        "url" : "http:\/\/t.co\/qISsAUFj6m",
        "expanded_url" : "http:\/\/bit.ly\/1Fvqevs",
        "display_url" : "bit.ly\/1Fvqevs"
      } ]
    },
    "geo" : { },
    "id_str" : "606280951027494912",
    "text" : "Sherlock Holmes sucks at deduction. Love the show but this really bugs me. (@PeteHolmesShow) http:\/\/t.co\/qISsAUFj6m http:\/\/t.co\/LhqT27ZYPO",
    "id" : 606280951027494912,
    "created_at" : "2015-06-04 02:06:57 +0000",
    "user" : {
      "name" : "Brad Voytek",
      "screen_name" : "bradleyvoytek",
      "protected" : false,
      "id_str" : "162535413",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/688408740651909124\/mz2GSnS0_normal.jpg",
      "id" : 162535413,
      "verified" : true
    }
  },
  "id" : 606355372539027456,
  "created_at" : "2015-06-04 07:02:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jacob Bernstein",
      "screen_name" : "BernsteinJacob",
      "indices" : [ 3, 18 ],
      "id_str" : "462424772",
      "id" : 462424772
    }, {
      "name" : "choire",
      "screen_name" : "Choire",
      "indices" : [ 65, 72 ],
      "id_str" : "8525402",
      "id" : 8525402
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "606225441683304448",
  "text" : "RT @BernsteinJacob: anyone who has ever quit smoking should read @Choire Sicha's NYT piece on quitting smoking. Simply perfect. http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "choire",
        "screen_name" : "Choire",
        "indices" : [ 45, 52 ],
        "id_str" : "8525402",
        "id" : 8525402
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 108, 130 ],
        "url" : "http:\/\/t.co\/t8XVPYN1Ms",
        "expanded_url" : "http:\/\/tinyurl.com\/om5vme8",
        "display_url" : "tinyurl.com\/om5vme8"
      } ]
    },
    "geo" : { },
    "id_str" : "606206632645816321",
    "text" : "anyone who has ever quit smoking should read @Choire Sicha's NYT piece on quitting smoking. Simply perfect. http:\/\/t.co\/t8XVPYN1Ms",
    "id" : 606206632645816321,
    "created_at" : "2015-06-03 21:11:38 +0000",
    "user" : {
      "name" : "Jacob Bernstein",
      "screen_name" : "BernsteinJacob",
      "protected" : false,
      "id_str" : "462424772",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/763469450989408257\/Ik3hwb3w_normal.jpg",
      "id" : 462424772,
      "verified" : true
    }
  },
  "id" : 606225441683304448,
  "created_at" : "2015-06-03 22:26:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 3, 12 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Senficon\/status\/606150932217384960\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/XyhFuGsxsi",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CGl7Dq8XIAAl-65.png",
      "id_str" : "606150927855329280",
      "id" : 606150927855329280,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CGl7Dq8XIAAl-65.png",
      "sizes" : [ {
        "h" : 574,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 574,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 488,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 574,
        "resize" : "fit",
        "w" : 800
      } ],
      "display_url" : "pic.twitter.com\/XyhFuGsxsi"
    } ],
    "hashtags" : [ {
      "text" : "copyright",
      "indices" : [ 26, 36 ]
    }, {
      "text" : "copywrongs",
      "indices" : [ 81, 92 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/ebc7MKMp2B",
      "expanded_url" : "http:\/\/copywrongs.eu",
      "display_url" : "copywrongs.eu"
    } ]
  },
  "geo" : { },
  "id_str" : "606157152609288192",
  "text" : "RT @Senficon: Help reform #copyright! Universal users\u2019 rights for the entire EU! #copywrongs http:\/\/t.co\/ebc7MKMp2B http:\/\/t.co\/XyhFuGsxsi",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Senficon\/status\/606150932217384960\/photo\/1",
        "indices" : [ 102, 124 ],
        "url" : "http:\/\/t.co\/XyhFuGsxsi",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CGl7Dq8XIAAl-65.png",
        "id_str" : "606150927855329280",
        "id" : 606150927855329280,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CGl7Dq8XIAAl-65.png",
        "sizes" : [ {
          "h" : 574,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 574,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 488,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 574,
          "resize" : "fit",
          "w" : 800
        } ],
        "display_url" : "pic.twitter.com\/XyhFuGsxsi"
      } ],
      "hashtags" : [ {
        "text" : "copyright",
        "indices" : [ 12, 22 ]
      }, {
        "text" : "copywrongs",
        "indices" : [ 67, 78 ]
      } ],
      "urls" : [ {
        "indices" : [ 79, 101 ],
        "url" : "http:\/\/t.co\/ebc7MKMp2B",
        "expanded_url" : "http:\/\/copywrongs.eu",
        "display_url" : "copywrongs.eu"
      } ]
    },
    "geo" : { },
    "id_str" : "606150932217384960",
    "text" : "Help reform #copyright! Universal users\u2019 rights for the entire EU! #copywrongs http:\/\/t.co\/ebc7MKMp2B http:\/\/t.co\/XyhFuGsxsi",
    "id" : 606150932217384960,
    "created_at" : "2015-06-03 17:30:18 +0000",
    "user" : {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "protected" : false,
      "id_str" : "14861745",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/637016870638350336\/QrtPmoul_normal.jpg",
      "id" : 14861745,
      "verified" : true
    }
  },
  "id" : 606157152609288192,
  "created_at" : "2015-06-03 17:55:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/606156593101729793\/photo\/1",
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/hWw1iVLtfq",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CGmANU4XIAAhMBp.png",
      "id_str" : "606156591289802752",
      "id" : 606156591289802752,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CGmANU4XIAAhMBp.png",
      "sizes" : [ {
        "h" : 1334,
        "resize" : "fit",
        "w" : 750
      }, {
        "h" : 1334,
        "resize" : "fit",
        "w" : 750
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 382
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 675
      } ],
      "display_url" : "pic.twitter.com\/hWw1iVLtfq"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "606156593101729793",
  "text" : "Probably just a GPS artifact, but I\u2019ll assume I managed to get my pace to &lt; 5 min\/km over 9 km distance. http:\/\/t.co\/hWw1iVLtfq",
  "id" : 606156593101729793,
  "created_at" : "2015-06-03 17:52:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "S\u00E9bastien Boisvert",
      "screen_name" : "sebhtml",
      "indices" : [ 3, 11 ],
      "id_str" : "94569565",
      "id" : 94569565
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bioinformatics",
      "indices" : [ 121, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/9ZJu3mHoY0",
      "expanded_url" : "http:\/\/www.oliverelliott.org\/article\/bioinformatics\/tut_genomebrowser\/",
      "display_url" : "oliverelliott.org\/article\/bioinf\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "606138404691189760",
  "text" : "RT @sebhtml: \"installing the damn thing is like trying to solve a Rubik's cube in a knife fight\" http:\/\/t.co\/9ZJu3mHoY0  #bioinformatics",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "bioinformatics",
        "indices" : [ 108, 123 ]
      } ],
      "urls" : [ {
        "indices" : [ 84, 106 ],
        "url" : "http:\/\/t.co\/9ZJu3mHoY0",
        "expanded_url" : "http:\/\/www.oliverelliott.org\/article\/bioinformatics\/tut_genomebrowser\/",
        "display_url" : "oliverelliott.org\/article\/bioinf\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "606133518658322432",
    "text" : "\"installing the damn thing is like trying to solve a Rubik's cube in a knife fight\" http:\/\/t.co\/9ZJu3mHoY0  #bioinformatics",
    "id" : 606133518658322432,
    "created_at" : "2015-06-03 16:21:06 +0000",
    "user" : {
      "name" : "S\u00E9bastien Boisvert",
      "screen_name" : "sebhtml",
      "protected" : false,
      "id_str" : "94569565",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/636584264214032384\/_1lxGaad_normal.jpg",
      "id" : 94569565,
      "verified" : false
    }
  },
  "id" : 606138404691189760,
  "created_at" : "2015-06-03 16:40:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Casey Bergman",
      "screen_name" : "caseybergman",
      "indices" : [ 0, 13 ],
      "id_str" : "320210499",
      "id" : 320210499
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "606121641391849472",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17224825503924, 8.62762945693627 ]
  },
  "id_str" : "606122621630074880",
  "in_reply_to_user_id" : 320210499,
  "text" : "@caseybergman do you mean asking about mult. testing or doing mult. testing? ;)",
  "id" : 606122621630074880,
  "in_reply_to_status_id" : 606121641391849472,
  "created_at" : "2015-06-03 15:37:48 +0000",
  "in_reply_to_screen_name" : "caseybergman",
  "in_reply_to_user_id_str" : "320210499",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "606100825086296064",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17233448107743, 8.62779719755857 ]
  },
  "id_str" : "606107456733908993",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich don\u2019t fix what ain\u2019t broken?",
  "id" : 606107456733908993,
  "in_reply_to_status_id" : 606100825086296064,
  "created_at" : "2015-06-03 14:37:33 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Public Emily",
      "screen_name" : "birdlord",
      "indices" : [ 3, 12 ],
      "id_str" : "26518795",
      "id" : 26518795
    }, {
      "name" : "Joey Comeau",
      "screen_name" : "joeycomeau",
      "indices" : [ 37, 48 ],
      "id_str" : "8858632",
      "id" : 8858632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/4AcwJX8zyn",
      "expanded_url" : "https:\/\/twitter.com\/nedroid\/status\/606083047637680128",
      "display_url" : "twitter.com\/nedroid\/status\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "606085164641484800",
  "text" : "RT @birdlord: inevitable result when @joeycomeau and I get our ASW tattoos https:\/\/t.co\/4AcwJX8zyn",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Joey Comeau",
        "screen_name" : "joeycomeau",
        "indices" : [ 23, 34 ],
        "id_str" : "8858632",
        "id" : 8858632
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 61, 84 ],
        "url" : "https:\/\/t.co\/4AcwJX8zyn",
        "expanded_url" : "https:\/\/twitter.com\/nedroid\/status\/606083047637680128",
        "display_url" : "twitter.com\/nedroid\/status\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "606084534975754240",
    "text" : "inevitable result when @joeycomeau and I get our ASW tattoos https:\/\/t.co\/4AcwJX8zyn",
    "id" : 606084534975754240,
    "created_at" : "2015-06-03 13:06:28 +0000",
    "user" : {
      "name" : "Public Emily",
      "screen_name" : "birdlord",
      "protected" : false,
      "id_str" : "26518795",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/660841199603990528\/I0c-0-48_normal.jpg",
      "id" : 26518795,
      "verified" : false
    }
  },
  "id" : 606085164641484800,
  "created_at" : "2015-06-03 13:08:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dierk Haasis",
      "screen_name" : "Evo2Me",
      "indices" : [ 0, 7 ],
      "id_str" : "22910316",
      "id" : 22910316
    }, {
      "name" : "ali",
      "screen_name" : "zoonpolitikon",
      "indices" : [ 8, 22 ],
      "id_str" : "13040652",
      "id" : 13040652
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 23, 32 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "606079809698021376",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17217986040637, 8.627696526998726 ]
  },
  "id_str" : "606080415561076736",
  "in_reply_to_user_id" : 22910316,
  "text" : "@Evo2Me @zoonpolitikon @Senficon well trolled! If I was to carry Bayes\u2019 essay I\u2019d be homeless I fear.",
  "id" : 606080415561076736,
  "in_reply_to_status_id" : 606079809698021376,
  "created_at" : "2015-06-03 12:50:06 +0000",
  "in_reply_to_screen_name" : "Evo2Me",
  "in_reply_to_user_id_str" : "22910316",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ali",
      "screen_name" : "zoonpolitikon",
      "indices" : [ 0, 14 ],
      "id_str" : "13040652",
      "id" : 13040652
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 23, 32 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "606078855921692674",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17229900179087, 8.627589974046948 ]
  },
  "id_str" : "606079677845913601",
  "in_reply_to_user_id" : 13040652,
  "text" : "@zoonpolitikon I guess @Senficon would prefer to see me carrying The Genetical Theory of Natural Selection by R.A. Fisher :D",
  "id" : 606079677845913601,
  "in_reply_to_status_id" : 606078855921692674,
  "created_at" : "2015-06-03 12:47:10 +0000",
  "in_reply_to_screen_name" : "zoonpolitikon",
  "in_reply_to_user_id_str" : "13040652",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Pickrell",
      "screen_name" : "joe_pickrell",
      "indices" : [ 0, 13 ],
      "id_str" : "314758565",
      "id" : 314758565
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "606078939870711808",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17229900179087, 8.627589974046948 ]
  },
  "id_str" : "606079335531954176",
  "in_reply_to_user_id" : 314758565,
  "text" : "@joe_pickrell what a lovely idea. I\u2019ll try to adopt it. :-)",
  "id" : 606079335531954176,
  "in_reply_to_status_id" : 606078939870711808,
  "created_at" : "2015-06-03 12:45:48 +0000",
  "in_reply_to_screen_name" : "joe_pickrell",
  "in_reply_to_user_id_str" : "314758565",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Pickrell",
      "screen_name" : "joe_pickrell",
      "indices" : [ 3, 16 ],
      "id_str" : "314758565",
      "id" : 314758565
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 18, 34 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/IUpK84znUQ",
      "expanded_url" : "https:\/\/joepickrell.wordpress.com\/2014\/10\/22\/the-burden-of-the-multiple-testing-burden\/",
      "display_url" : "joepickrell.wordpress.com\/2014\/10\/22\/the\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "606079284558610432",
  "text" : "RT @joe_pickrell: @gedankenstuecke still waiting for the \"multiple testing party\" to catch on. no luck just yet :( https:\/\/t.co\/IUpK84znUQ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 0, 16 ],
        "id_str" : "14286491",
        "id" : 14286491
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 97, 120 ],
        "url" : "https:\/\/t.co\/IUpK84znUQ",
        "expanded_url" : "https:\/\/joepickrell.wordpress.com\/2014\/10\/22\/the-burden-of-the-multiple-testing-burden\/",
        "display_url" : "joepickrell.wordpress.com\/2014\/10\/22\/the\u2026"
      } ]
    },
    "in_reply_to_status_id_str" : "606042352587800576",
    "geo" : { },
    "id_str" : "606078939870711808",
    "in_reply_to_user_id" : 14286491,
    "text" : "@gedankenstuecke still waiting for the \"multiple testing party\" to catch on. no luck just yet :( https:\/\/t.co\/IUpK84znUQ",
    "id" : 606078939870711808,
    "in_reply_to_status_id" : 606042352587800576,
    "created_at" : "2015-06-03 12:44:14 +0000",
    "in_reply_to_screen_name" : "gedankenstuecke",
    "in_reply_to_user_id_str" : "14286491",
    "user" : {
      "name" : "Joe Pickrell",
      "screen_name" : "joe_pickrell",
      "protected" : false,
      "id_str" : "314758565",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/923000443105611776\/g88uZpgr_normal.jpg",
      "id" : 314758565,
      "verified" : false
    }
  },
  "id" : 606079284558610432,
  "created_at" : "2015-06-03 12:45:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    }, {
      "name" : "ali",
      "screen_name" : "zoonpolitikon",
      "indices" : [ 10, 24 ],
      "id_str" : "13040652",
      "id" : 13040652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "606076592331362305",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17219678164867, 8.627645103099496 ]
  },
  "id_str" : "606077308726870016",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon @zoonpolitikon that\u2019s a shame. Would love to give a talk wearing habit. :D",
  "id" : 606077308726870016,
  "in_reply_to_status_id" : 606076592331362305,
  "created_at" : "2015-06-03 12:37:45 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ali",
      "screen_name" : "zoonpolitikon",
      "indices" : [ 0, 14 ],
      "id_str" : "13040652",
      "id" : 13040652
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 23, 32 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "606075854347767808",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722766290783, 8.62752146637333 ]
  },
  "id_str" : "606075958743990275",
  "in_reply_to_user_id" : 13040652,
  "text" : "@zoonpolitikon I think @Senficon might still have one of those around? :D",
  "id" : 606075958743990275,
  "in_reply_to_status_id" : 606075854347767808,
  "created_at" : "2015-06-03 12:32:23 +0000",
  "in_reply_to_screen_name" : "zoonpolitikon",
  "in_reply_to_user_id_str" : "13040652",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ali",
      "screen_name" : "zoonpolitikon",
      "indices" : [ 0, 14 ],
      "id_str" : "13040652",
      "id" : 13040652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/CKk4PyP52d",
      "expanded_url" : "https:\/\/www.larp-fashion.co.uk\/media\/image\/gruener-habit-mit-gugel-sr-104053_1.jpg",
      "display_url" : "larp-fashion.co.uk\/media\/image\/gr\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "606073778020433920",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722766290783, 8.62752146637333 ]
  },
  "id_str" : "606075573870280704",
  "in_reply_to_user_id" : 13040652,
  "text" : "@zoonpolitikon one of those hoodies, so I can be the high priest of open-source genetics? https:\/\/t.co\/CKk4PyP52d",
  "id" : 606075573870280704,
  "in_reply_to_status_id" : 606073778020433920,
  "created_at" : "2015-06-03 12:30:51 +0000",
  "in_reply_to_screen_name" : "zoonpolitikon",
  "in_reply_to_user_id_str" : "13040652",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Effy Vayena",
      "screen_name" : "EffyVayena",
      "indices" : [ 0, 11 ],
      "id_str" : "397518511",
      "id" : 397518511
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "606073531735146496",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17223558993873, 8.627540669510104 ]
  },
  "id_str" : "606073759066411008",
  "in_reply_to_user_id" : 397518511,
  "text" : "@EffyVayena not yet, will come in tomorrow and leave Sa or Su, depending on your plans. Actually, wanted to email you today. :)",
  "id" : 606073759066411008,
  "in_reply_to_status_id" : 606073531735146496,
  "created_at" : "2015-06-03 12:23:39 +0000",
  "in_reply_to_screen_name" : "EffyVayena",
  "in_reply_to_user_id_str" : "397518511",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 36 ],
      "url" : "https:\/\/t.co\/w4ourjrbxC",
      "expanded_url" : "https:\/\/twitter.com\/hannesgassert\/status\/606071880416698368",
      "display_url" : "twitter.com\/hannesgassert\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "606073189505073152",
  "text" : "No pressure! https:\/\/t.co\/w4ourjrbxC",
  "id" : 606073189505073152,
  "created_at" : "2015-06-03 12:21:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kriszta Berkes",
      "screen_name" : "KrisztaB",
      "indices" : [ 3, 12 ],
      "id_str" : "922402893411561472",
      "id" : 922402893411561472
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 14, 30 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "606052737646792706",
  "text" : "RT @Krisztab: @gedankenstuecke or pseudoreplication?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 0, 16 ],
        "id_str" : "14286491",
        "id" : 14286491
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "606042352587800576",
    "geo" : { },
    "id_str" : "606052480967966720",
    "in_reply_to_user_id" : 14286491,
    "text" : "@gedankenstuecke or pseudoreplication?",
    "id" : 606052480967966720,
    "in_reply_to_status_id" : 606042352587800576,
    "created_at" : "2015-06-03 10:59:06 +0000",
    "in_reply_to_screen_name" : "gedankenstuecke",
    "in_reply_to_user_id_str" : "14286491",
    "user" : {
      "name" : "Kriszta Kezia V",
      "screen_name" : "kri_keziush",
      "protected" : false,
      "id_str" : "19334473",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/836703338775343104\/tM-WE4G6_normal.jpg",
      "id" : 19334473,
      "verified" : false
    }
  },
  "id" : 606052737646792706,
  "created_at" : "2015-06-03 11:00:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kriszta Berkes",
      "screen_name" : "KrisztaB",
      "indices" : [ 0, 9 ],
      "id_str" : "922402893411561472",
      "id" : 922402893411561472
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "606052480967966720",
  "geo" : { },
  "id_str" : "606052731707654144",
  "in_reply_to_user_id" : 19334473,
  "text" : "@Krisztab also a good idea!",
  "id" : 606052731707654144,
  "in_reply_to_status_id" : 606052480967966720,
  "created_at" : "2015-06-03 11:00:05 +0000",
  "in_reply_to_screen_name" : "kri_keziush",
  "in_reply_to_user_id_str" : "19334473",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17218661236865, 8.627507335461626 ]
  },
  "id_str" : "606042352587800576",
  "text" : "the easy way to seem well versed in statistics: always ask \u2018but isn\u2019t there a multiple testing problem?\u2019 and then just wait.",
  "id" : 606042352587800576,
  "created_at" : "2015-06-03 10:18:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katie Mack",
      "screen_name" : "AstroKatie",
      "indices" : [ 3, 14 ],
      "id_str" : "33773592",
      "id" : 33773592
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/Su4vy4RiLb",
      "expanded_url" : "http:\/\/www.wandering-scientist.com\/2015\/06\/playing-game-rigged-against-you.html",
      "display_url" : "wandering-scientist.com\/2015\/06\/playin\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "606009318878625792",
  "text" : "RT @AstroKatie: This is a good article about why sexual harassment in science really sucks http:\/\/t.co\/Su4vy4RiLb &amp; why profs should STOP H\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 75, 97 ],
        "url" : "http:\/\/t.co\/Su4vy4RiLb",
        "expanded_url" : "http:\/\/www.wandering-scientist.com\/2015\/06\/playing-game-rigged-against-you.html",
        "display_url" : "wandering-scientist.com\/2015\/06\/playin\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "606002375225020416",
    "text" : "This is a good article about why sexual harassment in science really sucks http:\/\/t.co\/Su4vy4RiLb &amp; why profs should STOP HARASSING PEOPLE.",
    "id" : 606002375225020416,
    "created_at" : "2015-06-03 07:39:59 +0000",
    "user" : {
      "name" : "Katie Mack",
      "screen_name" : "AstroKatie",
      "protected" : false,
      "id_str" : "33773592",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2818477708\/0ef050189a11bb7f9cf56306f5d171bf_normal.png",
      "id" : 33773592,
      "verified" : true
    }
  },
  "id" : 606009318878625792,
  "created_at" : "2015-06-03 08:07:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/w8nqWbOTes",
      "expanded_url" : "http:\/\/asofterworld.com\/index.php?id=887",
      "display_url" : "asofterworld.com\/index.php?id=8\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17229832757154, 8.627590575348684 ]
  },
  "id_str" : "606005134682947584",
  "text" : "Luckily I know just the artist who will be up for the job http:\/\/t.co\/w8nqWbOTes",
  "id" : 606005134682947584,
  "created_at" : "2015-06-03 07:50:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "605996795928440833",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723868195057, 8.62751138287368 ]
  },
  "id_str" : "605997096412565504",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot bebo dancas malrapide?",
  "id" : 605997096412565504,
  "in_reply_to_status_id" : 605996795928440833,
  "created_at" : "2015-06-03 07:19:01 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "@zeitweise",
      "screen_name" : "zeitweise",
      "indices" : [ 0, 10 ],
      "id_str" : "15494684",
      "id" : 15494684
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/605982319762112512\/photo\/1",
      "indices" : [ 27, 49 ],
      "url" : "http:\/\/t.co\/Nq6FsF5Cwb",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CGjhtWEWwAAGo51.png",
      "id_str" : "605982319015542784",
      "id" : 605982319015542784,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CGjhtWEWwAAGo51.png",
      "sizes" : [ {
        "h" : 282,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 282,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 282,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 282,
        "resize" : "fit",
        "w" : 500
      } ],
      "display_url" : "pic.twitter.com\/Nq6FsF5Cwb"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "605982100320354304",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723072905238, 8.62758150172859 ]
  },
  "id_str" : "605982319762112512",
  "in_reply_to_user_id" : 15494684,
  "text" : "@zeitweise dann halt so :) http:\/\/t.co\/Nq6FsF5Cwb",
  "id" : 605982319762112512,
  "in_reply_to_status_id" : 605982100320354304,
  "created_at" : "2015-06-03 06:20:18 +0000",
  "in_reply_to_screen_name" : "zeitweise",
  "in_reply_to_user_id_str" : "15494684",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "@zeitweise",
      "screen_name" : "zeitweise",
      "indices" : [ 0, 10 ],
      "id_str" : "15494684",
      "id" : 15494684
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/yjHziIBplF",
      "expanded_url" : "http:\/\/i500.listal.com\/image\/4780763\/600full.jpg",
      "display_url" : "i500.listal.com\/image\/4780763\/\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "605981339175800832",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723072905238, 8.62758150172859 ]
  },
  "id_str" : "605981887258107905",
  "in_reply_to_user_id" : 15494684,
  "text" : "@zeitweise ist mein erster (so weit sehr cooler) Versuch, f\u00FChlt sich aber an wie http:\/\/t.co\/yjHziIBplF :-)",
  "id" : 605981887258107905,
  "in_reply_to_status_id" : 605981339175800832,
  "created_at" : "2015-06-03 06:18:35 +0000",
  "in_reply_to_screen_name" : "zeitweise",
  "in_reply_to_user_id_str" : "15494684",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "@zeitweise",
      "screen_name" : "zeitweise",
      "indices" : [ 0, 10 ],
      "id_str" : "15494684",
      "id" : 15494684
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/IT7asLKgqc",
      "expanded_url" : "http:\/\/incubator.duolingo.com\/courses\/eo\/en\/status",
      "display_url" : "incubator.duolingo.com\/courses\/eo\/en\/\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "605980495978078208",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723691249133, 8.627519528623658 ]
  },
  "id_str" : "605980810936762368",
  "in_reply_to_user_id" : 15494684,
  "text" : "@zeitweise ja, ist allerdings noch Beta und seit &lt; 1 Woche verf\u00FCgbar. :) http:\/\/t.co\/IT7asLKgqc",
  "id" : 605980810936762368,
  "in_reply_to_status_id" : 605980495978078208,
  "created_at" : "2015-06-03 06:14:18 +0000",
  "in_reply_to_screen_name" : "zeitweise",
  "in_reply_to_user_id_str" : "15494684",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/605979209769611264\/photo\/1",
      "indices" : [ 51, 73 ],
      "url" : "http:\/\/t.co\/rhQpYPrw23",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CGje4TIWwAAVFQM.png",
      "id_str" : "605979208670691328",
      "id" : 605979208670691328,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CGje4TIWwAAVFQM.png",
      "sizes" : [ {
        "h" : 167,
        "resize" : "fit",
        "w" : 403
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 167,
        "resize" : "fit",
        "w" : 403
      }, {
        "h" : 167,
        "resize" : "fit",
        "w" : 403
      }, {
        "h" : 167,
        "resize" : "fit",
        "w" : 403
      } ],
      "display_url" : "pic.twitter.com\/rhQpYPrw23"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 50 ],
      "url" : "http:\/\/t.co\/itPTb0vU1b",
      "expanded_url" : "http:\/\/38.media.tumblr.com\/tumblr_mchf7fdrhd1r7swjzo1_250.gif",
      "display_url" : "38.media.tumblr.com\/tumblr_mchf7fd\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723691249133, 8.627519528623658 ]
  },
  "id_str" : "605979209769611264",
  "text" : "Whatever you say, Duolingo. http:\/\/t.co\/itPTb0vU1b http:\/\/t.co\/rhQpYPrw23",
  "id" : 605979209769611264,
  "created_at" : "2015-06-03 06:07:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ali",
      "screen_name" : "zoonpolitikon",
      "indices" : [ 0, 14 ],
      "id_str" : "13040652",
      "id" : 13040652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "605842264015831041",
  "geo" : { },
  "id_str" : "605842501287579648",
  "in_reply_to_user_id" : 13040652,
  "text" : "@zoonpolitikon oh yes, its for the Swiss train fares that I\u2019ll drive down by car as it\u2019s cheaper\u2026",
  "id" : 605842501287579648,
  "in_reply_to_status_id" : 605842264015831041,
  "created_at" : "2015-06-02 21:04:42 +0000",
  "in_reply_to_screen_name" : "zoonpolitikon",
  "in_reply_to_user_id_str" : "13040652",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ali",
      "screen_name" : "zoonpolitikon",
      "indices" : [ 0, 14 ],
      "id_str" : "13040652",
      "id" : 13040652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "605841728243834884",
  "geo" : { },
  "id_str" : "605842012005203968",
  "in_reply_to_user_id" : 13040652,
  "text" : "@zoonpolitikon not exactly great for a daily commute ;)",
  "id" : 605842012005203968,
  "in_reply_to_status_id" : 605841728243834884,
  "created_at" : "2015-06-02 21:02:46 +0000",
  "in_reply_to_screen_name" : "zoonpolitikon",
  "in_reply_to_user_id_str" : "13040652",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 74 ],
      "url" : "http:\/\/t.co\/oyBT5SyfAW",
      "expanded_url" : "http:\/\/make.opendata.ch\/wiki\/event:2015-06",
      "display_url" : "make.opendata.ch\/wiki\/event:201\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "605841041934020608",
  "text" : "On the off chance: I\u2019ll be in Zurich from Th\u2014Su for http:\/\/t.co\/oyBT5SyfAW. Do I have any followers there who could host me on their couch?",
  "id" : 605841041934020608,
  "created_at" : "2015-06-02 20:58:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "nad no ennas",
      "screen_name" : "nadnoennas",
      "indices" : [ 0, 11 ],
      "id_str" : "769945612167081984",
      "id" : 769945612167081984
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "605797447361642496",
  "geo" : { },
  "id_str" : "605837440914325504",
  "in_reply_to_user_id" : 102096393,
  "text" : "@nadnoennas \\o\/",
  "id" : 605837440914325504,
  "in_reply_to_status_id" : 605797447361642496,
  "created_at" : "2015-06-02 20:44:36 +0000",
  "in_reply_to_screen_name" : "kianelazin",
  "in_reply_to_user_id_str" : "102096393",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul-Olivier Dehaye",
      "screen_name" : "podehaye",
      "indices" : [ 0, 9 ],
      "id_str" : "2219841242",
      "id" : 2219841242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "605738961940713473",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723248064467, 8.627526467732498 ]
  },
  "id_str" : "605740233284567040",
  "in_reply_to_user_id" : 2219841242,
  "text" : "@podehaye thanks, it\u2019s a pain to balance it. ;-)",
  "id" : 605740233284567040,
  "in_reply_to_status_id" : 605738961940713473,
  "created_at" : "2015-06-02 14:18:20 +0000",
  "in_reply_to_screen_name" : "podehaye",
  "in_reply_to_user_id_str" : "2219841242",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 50 ],
      "url" : "https:\/\/t.co\/qQyBiArgsp",
      "expanded_url" : "https:\/\/instagram.com\/p\/3beCrTBwvK\/",
      "display_url" : "instagram.com\/p\/3beCrTBwvK\/"
    } ]
  },
  "geo" : { },
  "id_str" : "605734541458870272",
  "text" : "manual tree reconstruction https:\/\/t.co\/qQyBiArgsp",
  "id" : 605734541458870272,
  "created_at" : "2015-06-02 13:55:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/3QJD7WPucI",
      "expanded_url" : "http:\/\/media.giphy.com\/media\/A0y7IyLbIb1G8\/giphy.gif",
      "display_url" : "media.giphy.com\/media\/A0y7IyLb\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17218308702797, 8.627504551403112 ]
  },
  "id_str" : "605647055407726592",
  "text" : "Somehow I was put in charge of a task that requires only a iota of physics knowledge. still the results are: http:\/\/t.co\/3QJD7WPucI",
  "id" : 605647055407726592,
  "created_at" : "2015-06-02 08:08:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christophe Dessimoz",
      "screen_name" : "cdessimoz",
      "indices" : [ 0, 10 ],
      "id_str" : "274388734",
      "id" : 274388734
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "605638288964235264",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17218855135278, 8.627507948416282 ]
  },
  "id_str" : "605638560067268608",
  "in_reply_to_user_id" : 274388734,
  "text" : "@cdessimoz actually it seems the link is just missing from the prelim. version as there\u2019s no cover page. Guess will be fixed in final. :-)",
  "id" : 605638560067268608,
  "in_reply_to_status_id" : 605638288964235264,
  "created_at" : "2015-06-02 07:34:19 +0000",
  "in_reply_to_screen_name" : "cdessimoz",
  "in_reply_to_user_id_str" : "274388734",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christophe Dessimoz",
      "screen_name" : "cdessimoz",
      "indices" : [ 0, 10 ],
      "id_str" : "274388734",
      "id" : 274388734
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "605635817193787392",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17226804420405, 8.62755727284646 ]
  },
  "id_str" : "605636735394062336",
  "in_reply_to_user_id" : 274388734,
  "text" : "@cdessimoz oh, I searched for those on the Syst Biol page but didn\u2019t find the link. I blame my lack of coffee for that. Thanks :-)",
  "id" : 605636735394062336,
  "in_reply_to_status_id" : 605635817193787392,
  "created_at" : "2015-06-02 07:27:04 +0000",
  "in_reply_to_screen_name" : "cdessimoz",
  "in_reply_to_user_id_str" : "274388734",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christophe Dessimoz",
      "screen_name" : "cdessimoz",
      "indices" : [ 0, 10 ],
      "id_str" : "274388734",
      "id" : 274388734
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "605634948398202880",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17226804420405, 8.62755727284646 ]
  },
  "id_str" : "605635206343720960",
  "in_reply_to_user_id" : 274388734,
  "text" : "@cdessimoz No, I don\u2019t think so. I just wondered because it wasn\u2019t explicitly stated whether it\u2019s in- or exclusive fungi.",
  "id" : 605635206343720960,
  "in_reply_to_status_id" : 605634948398202880,
  "created_at" : "2015-06-02 07:21:00 +0000",
  "in_reply_to_screen_name" : "cdessimoz",
  "in_reply_to_user_id_str" : "274388734",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christophe Dessimoz",
      "screen_name" : "cdessimoz",
      "indices" : [ 3, 13 ],
      "id_str" : "274388734",
      "id" : 274388734
    }, {
      "name" : "Systematic Biology",
      "screen_name" : "systbiol",
      "indices" : [ 65, 74 ],
      "id_str" : "30054271",
      "id" : 30054271
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "605634342967230465",
  "text" : "RT @cdessimoz: Alignment trimming results in worse trees\u2014now out @systbiol!Took us 5 yrs in all, mostly spent convincing reviewers\u2026 http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Systematic Biology",
        "screen_name" : "systbiol",
        "indices" : [ 50, 59 ],
        "id_str" : "30054271",
        "id" : 30054271
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/fN51PgiMCt",
        "expanded_url" : "http:\/\/sysbio.oxfordjournals.org\/cgi\/content\/abstract\/syv033",
        "display_url" : "sysbio.oxfordjournals.org\/cgi\/content\/ab\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "605631125017501696",
    "text" : "Alignment trimming results in worse trees\u2014now out @systbiol!Took us 5 yrs in all, mostly spent convincing reviewers\u2026 http:\/\/t.co\/fN51PgiMCt",
    "id" : 605631125017501696,
    "created_at" : "2015-06-02 07:04:46 +0000",
    "user" : {
      "name" : "Christophe Dessimoz",
      "screen_name" : "cdessimoz",
      "protected" : false,
      "id_str" : "274388734",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1467970873\/photo_normal.png",
      "id" : 274388734,
      "verified" : false
    }
  },
  "id" : 605634342967230465,
  "created_at" : "2015-06-02 07:17:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christophe Dessimoz",
      "screen_name" : "cdessimoz",
      "indices" : [ 0, 10 ],
      "id_str" : "274388734",
      "id" : 274388734
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "605631125017501696",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17228035078277, 8.62753825987083 ]
  },
  "id_str" : "605634326156480512",
  "in_reply_to_user_id" : 274388734,
  "text" : "@cdessimoz congrats! Are the eukaryotic data = Fungi + X? :-)",
  "id" : 605634326156480512,
  "in_reply_to_status_id" : 605631125017501696,
  "created_at" : "2015-06-02 07:17:30 +0000",
  "in_reply_to_screen_name" : "cdessimoz",
  "in_reply_to_user_id_str" : "274388734",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/2HSJpeBhsr",
      "expanded_url" : "http:\/\/www.herecomestheairplane.co\/",
      "display_url" : "herecomestheairplane.co"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17230051359532, 8.627506105161691 ]
  },
  "id_str" : "605625226240622592",
  "text" : "\u00ABThis team of mavericks has created a roomba for your mouth.\u00BB http:\/\/t.co\/2HSJpeBhsr",
  "id" : 605625226240622592,
  "created_at" : "2015-06-02 06:41:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hadley Wickham",
      "screen_name" : "hadleywickham",
      "indices" : [ 3, 17 ],
      "id_str" : "69133574",
      "id" : 69133574
    }, {
      "name" : "Katherine Ognyanova",
      "screen_name" : "Ognyanova",
      "indices" : [ 19, 29 ],
      "id_str" : "75641981",
      "id" : 75641981
    }, {
      "name" : "Dean Eckles",
      "screen_name" : "deaneckles",
      "indices" : [ 30, 41 ],
      "id_str" : "759249",
      "id" : 759249
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "605504174940372993",
  "text" : "RT @hadleywickham: @Ognyanova @deaneckles your graphics software hasn't made it until someone has committed scientific fraud with it :\/",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Katherine Ognyanova",
        "screen_name" : "Ognyanova",
        "indices" : [ 0, 10 ],
        "id_str" : "75641981",
        "id" : 75641981
      }, {
        "name" : "Dean Eckles",
        "screen_name" : "deaneckles",
        "indices" : [ 11, 22 ],
        "id_str" : "759249",
        "id" : 759249
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "605448652232880129",
    "geo" : { },
    "id_str" : "605496377217392640",
    "in_reply_to_user_id" : 75641981,
    "text" : "@Ognyanova @deaneckles your graphics software hasn't made it until someone has committed scientific fraud with it :\/",
    "id" : 605496377217392640,
    "in_reply_to_status_id" : 605448652232880129,
    "created_at" : "2015-06-01 22:09:20 +0000",
    "in_reply_to_screen_name" : "Ognyanova",
    "in_reply_to_user_id_str" : "75641981",
    "user" : {
      "name" : "Hadley Wickham",
      "screen_name" : "hadleywickham",
      "protected" : false,
      "id_str" : "69133574",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/905186381995147264\/7zKAG5sY_normal.jpg",
      "id" : 69133574,
      "verified" : true
    }
  },
  "id" : 605504174940372993,
  "created_at" : "2015-06-01 22:40:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Martin Paul Eve",
      "screen_name" : "martin_eve",
      "indices" : [ 3, 14 ],
      "id_str" : "118747590",
      "id" : 118747590
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/6WZfpsH1wG",
      "expanded_url" : "http:\/\/opencon2015.org\/blog\/opencon-2015-applications-are-open",
      "display_url" : "opencon2015.org\/blog\/opencon-2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "605465390391685121",
  "text" : "RT @martin_eve: Applications are now open for OpenCon 2015! http:\/\/t.co\/6WZfpsH1wG",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 44, 66 ],
        "url" : "http:\/\/t.co\/6WZfpsH1wG",
        "expanded_url" : "http:\/\/opencon2015.org\/blog\/opencon-2015-applications-are-open",
        "display_url" : "opencon2015.org\/blog\/opencon-2\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "605459115255721984",
    "text" : "Applications are now open for OpenCon 2015! http:\/\/t.co\/6WZfpsH1wG",
    "id" : 605459115255721984,
    "created_at" : "2015-06-01 19:41:16 +0000",
    "user" : {
      "name" : "Martin Paul Eve",
      "screen_name" : "martin_eve",
      "protected" : false,
      "id_str" : "118747590",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/855017454384402432\/rajP3b7b_normal.jpg",
      "id" : 118747590,
      "verified" : false
    }
  },
  "id" : 605465390391685121,
  "created_at" : "2015-06-01 20:06:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Yoder \uD83D\uDD96\uD83C\uDFFB",
      "screen_name" : "JBYoder",
      "indices" : [ 0, 8 ],
      "id_str" : "19984919",
      "id" : 19984919
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "605433678689206273",
  "geo" : { },
  "id_str" : "605435923501838336",
  "in_reply_to_user_id" : 19984919,
  "text" : "@JBYoder don\u2019t make me senselessly buy domains!",
  "id" : 605435923501838336,
  "in_reply_to_status_id" : 605433678689206273,
  "created_at" : "2015-06-01 18:09:07 +0000",
  "in_reply_to_screen_name" : "JBYoder",
  "in_reply_to_user_id_str" : "19984919",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Schweitzer Sortiment",
      "screen_name" : "SchweitzerInfo",
      "indices" : [ 3, 18 ],
      "id_str" : "264754275",
      "id" : 264754275
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "icanhazpdf",
      "indices" : [ 79, 90 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/xJFazfE7Qj",
      "expanded_url" : "http:\/\/hdl.handle.net\/10760\/24847",
      "display_url" : "hdl.handle.net\/10760\/24847"
    } ]
  },
  "geo" : { },
  "id_str" : "605388585513172992",
  "text" : "RT @SchweitzerInfo: Bypassing Interlibrary Loan via Twitter: An Exploration of #icanhazpdf Requests --&gt; http:\/\/t.co\/xJFazfE7Qj",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "icanhazpdf",
        "indices" : [ 59, 70 ]
      } ],
      "urls" : [ {
        "indices" : [ 87, 109 ],
        "url" : "http:\/\/t.co\/xJFazfE7Qj",
        "expanded_url" : "http:\/\/hdl.handle.net\/10760\/24847",
        "display_url" : "hdl.handle.net\/10760\/24847"
      } ]
    },
    "geo" : { },
    "id_str" : "604298958329008128",
    "text" : "Bypassing Interlibrary Loan via Twitter: An Exploration of #icanhazpdf Requests --&gt; http:\/\/t.co\/xJFazfE7Qj",
    "id" : 604298958329008128,
    "created_at" : "2015-05-29 14:51:13 +0000",
    "user" : {
      "name" : "Schweitzer Sortiment",
      "screen_name" : "SchweitzerInfo",
      "protected" : false,
      "id_str" : "264754275",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2930462684\/32e043da76237307aa48319249cd49f9_normal.jpeg",
      "id" : 264754275,
      "verified" : false
    }
  },
  "id" : 605388585513172992,
  "created_at" : "2015-06-01 15:01:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 3, 12 ],
      "id_str" : "14245811",
      "id" : 14245811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/FV9xmT2H7s",
      "expanded_url" : "https:\/\/twitter.com\/mmoyr\/status\/605376619675566080",
      "display_url" : "twitter.com\/mmoyr\/status\/6\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "605386518472077313",
  "text" : "RT @wilbanks: This is why we can't have nice things. I mean, this was *Science*.  https:\/\/t.co\/FV9xmT2H7s",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 68, 91 ],
        "url" : "https:\/\/t.co\/FV9xmT2H7s",
        "expanded_url" : "https:\/\/twitter.com\/mmoyr\/status\/605376619675566080",
        "display_url" : "twitter.com\/mmoyr\/status\/6\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "605384265803534336",
    "text" : "This is why we can't have nice things. I mean, this was *Science*.  https:\/\/t.co\/FV9xmT2H7s",
    "id" : 605384265803534336,
    "created_at" : "2015-06-01 14:43:51 +0000",
    "user" : {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "protected" : false,
      "id_str" : "14245811",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/925696899566440448\/BUTdp410_normal.jpg",
      "id" : 14245811,
      "verified" : false
    }
  },
  "id" : 605386518472077313,
  "created_at" : "2015-06-01 14:52:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 3, 12 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FixCopyright",
      "indices" : [ 93, 106 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/mUCdFQisOS",
      "expanded_url" : "http:\/\/copywrongs.eu\/",
      "display_url" : "copywrongs.eu"
    } ]
  },
  "geo" : { },
  "id_str" : "605374329250017281",
  "text" : "RT @Senficon: Monday afternoon, most MEPs should be back in the office. Time to call them to #FixCopyright! http:\/\/t.co\/mUCdFQisOS http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Senficon\/status\/605374056263745536\/photo\/1",
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/DZCxZ1Fv5A",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CGa4fv8XEAErBwF.png",
        "id_str" : "605374055513001985",
        "id" : 605374055513001985,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CGa4fv8XEAErBwF.png",
        "sizes" : [ {
          "h" : 413,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 413,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 413,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 413,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/DZCxZ1Fv5A"
      } ],
      "hashtags" : [ {
        "text" : "FixCopyright",
        "indices" : [ 79, 92 ]
      } ],
      "urls" : [ {
        "indices" : [ 94, 116 ],
        "url" : "http:\/\/t.co\/mUCdFQisOS",
        "expanded_url" : "http:\/\/copywrongs.eu\/",
        "display_url" : "copywrongs.eu"
      } ]
    },
    "geo" : { },
    "id_str" : "605374056263745536",
    "text" : "Monday afternoon, most MEPs should be back in the office. Time to call them to #FixCopyright! http:\/\/t.co\/mUCdFQisOS http:\/\/t.co\/DZCxZ1Fv5A",
    "id" : 605374056263745536,
    "created_at" : "2015-06-01 14:03:16 +0000",
    "user" : {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "protected" : false,
      "id_str" : "14861745",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/637016870638350336\/QrtPmoul_normal.jpg",
      "id" : 14861745,
      "verified" : true
    }
  },
  "id" : 605374329250017281,
  "created_at" : "2015-06-01 14:04:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 49 ],
      "url" : "http:\/\/t.co\/XpdormqXTS",
      "expanded_url" : "http:\/\/boingboing.net\/2015\/06\/01\/helpful-video-explains-how-to.html",
      "display_url" : "boingboing.net\/2015\/06\/01\/hel\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17232870221228, 8.627525342654117 ]
  },
  "id_str" : "605362321851092992",
  "text" : "how to make a hamster\u00A0flat http:\/\/t.co\/XpdormqXTS",
  "id" : 605362321851092992,
  "created_at" : "2015-06-01 13:16:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722284195852, 8.627553876466944 ]
  },
  "id_str" : "605347818098855936",
  "text" : "Readability of my handwriting: student mistook my \u201Ccetacea\u201D-leaf label for a nucleotide sequence\u2026",
  "id" : 605347818098855936,
  "created_at" : "2015-06-01 12:19:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 87, 96 ],
      "id_str" : "14245811",
      "id" : 14245811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/IGvlnDNRXi",
      "expanded_url" : "http:\/\/www.lsspjournal.com\/content\/11\/1\/1",
      "display_url" : "lsspjournal.com\/content\/11\/1\/1"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17229803817831, 8.627538159729394 ]
  },
  "id_str" : "605303048265707520",
  "text" : "\u00ABcan open consent be \u2018informed\u2019 under the forthcoming data protection regulation?\u00BB \/cc @wilbanks http:\/\/t.co\/IGvlnDNRXi",
  "id" : 605303048265707520,
  "created_at" : "2015-06-01 09:21:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BOSC2015",
      "indices" : [ 12, 21 ]
    }, {
      "text" : "SMBE15",
      "indices" : [ 28, 35 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17229197797186, 8.627562274026618 ]
  },
  "id_str" : "605293119903543296",
  "text" : "Flights for #BOSC2015 &amp; #SMBE15 (FRA-&gt;DUB-&gt;VIE-&gt;FRA) \u2713",
  "id" : 605293119903543296,
  "created_at" : "2015-06-01 08:41:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PHP CEO",
      "screen_name" : "PHP_CEO",
      "indices" : [ 3, 11 ],
      "id_str" : "2317524115",
      "id" : 2317524115
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "605287595527008256",
  "text" : "RT @PHP_CEO: COMPANY CULTURE ISN\u2019T SOMETHING YOU CAN JUST GET OVERNIGHT\n\nUSUALLY TAKES ABOUT A WEEK TO SHIP THAT PING PONG TABLE",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "492089140201406465",
    "text" : "COMPANY CULTURE ISN\u2019T SOMETHING YOU CAN JUST GET OVERNIGHT\n\nUSUALLY TAKES ABOUT A WEEK TO SHIP THAT PING PONG TABLE",
    "id" : 492089140201406465,
    "created_at" : "2014-07-23 23:29:28 +0000",
    "user" : {
      "name" : "PHP CEO",
      "screen_name" : "PHP_CEO",
      "protected" : false,
      "id_str" : "2317524115",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/552595603687874561\/Yd-jBihK_normal.jpeg",
      "id" : 2317524115,
      "verified" : false
    }
  },
  "id" : 605287595527008256,
  "created_at" : "2015-06-01 08:19:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 65 ],
      "url" : "https:\/\/t.co\/h6GVagQwwJ",
      "expanded_url" : "https:\/\/medium.com\/openexplorer-journal\/makers-the-new-explorers-of-the-universe-7cc61eeb53b4",
      "display_url" : "medium.com\/openexplorer-j\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17239136999998, 8.627507369999998 ]
  },
  "id_str" : "605257187783520257",
  "text" : "Makers: The New Explorers of the Universe https:\/\/t.co\/h6GVagQwwJ",
  "id" : 605257187783520257,
  "created_at" : "2015-06-01 06:18:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Skellett",
      "screen_name" : "Gurdur",
      "indices" : [ 0, 7 ],
      "id_str" : "125928028",
      "id" : 125928028
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "605250689816776704",
  "geo" : { },
  "id_str" : "605252306226003968",
  "in_reply_to_user_id" : 125928028,
  "text" : "@Gurdur and here\u2019s me thinking that I had it bad, as many English-speaking people opt for \u2018grease-shake\u2019 for my last name",
  "id" : 605252306226003968,
  "in_reply_to_status_id" : 605250689816776704,
  "created_at" : "2015-06-01 05:59:29 +0000",
  "in_reply_to_screen_name" : "Gurdur",
  "in_reply_to_user_id_str" : "125928028",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Skellett",
      "screen_name" : "Gurdur",
      "indices" : [ 3, 10 ],
      "id_str" : "125928028",
      "id" : 125928028
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 12, 28 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "605251567638429696",
  "text" : "RT @Gurdur: @gedankenstuecke A most unfortunate name for its (especially male) owners in English-speaking countries.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 0, 16 ],
        "id_str" : "14286491",
        "id" : 14286491
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "605250339307196416",
    "geo" : { },
    "id_str" : "605250689816776704",
    "in_reply_to_user_id" : 14286491,
    "text" : "@gedankenstuecke A most unfortunate name for its (especially male) owners in English-speaking countries.",
    "id" : 605250689816776704,
    "in_reply_to_status_id" : 605250339307196416,
    "created_at" : "2015-06-01 05:53:04 +0000",
    "in_reply_to_screen_name" : "gedankenstuecke",
    "in_reply_to_user_id_str" : "14286491",
    "user" : {
      "name" : "Tim Skellett",
      "screen_name" : "Gurdur",
      "protected" : false,
      "id_str" : "125928028",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/721158367398506496\/c4cchuLu_normal.jpg",
      "id" : 125928028,
      "verified" : false
    }
  },
  "id" : 605251567638429696,
  "created_at" : "2015-06-01 05:56:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/605250339307196416\/photo\/1",
      "indices" : [ 33, 55 ],
      "url" : "http:\/\/t.co\/IbNJG1rpuN",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CGZH-XcW8AAS-oh.jpg",
      "id_str" : "605250336698331136",
      "id" : 605250336698331136,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CGZH-XcW8AAS-oh.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/IbNJG1rpuN"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "605250339307196416",
  "text" : "Maybe the most German name ever. http:\/\/t.co\/IbNJG1rpuN",
  "id" : 605250339307196416,
  "created_at" : "2015-06-01 05:51:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lenny Teytelman",
      "screen_name" : "lteytelman",
      "indices" : [ 3, 14 ],
      "id_str" : "1343132275",
      "id" : 1343132275
    }, {
      "name" : "thespectroscope",
      "screen_name" : "thespectroscope",
      "indices" : [ 57, 73 ],
      "id_str" : "2578128949",
      "id" : 2578128949
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/E82s7KRfXi",
      "expanded_url" : "http:\/\/www.thespectroscope.com\/read\/want-to-be-ethical-in-science-speak-up-by-lenny-teytelman-321",
      "display_url" : "thespectroscope.com\/read\/want-to-b\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "605238112034430976",
  "text" : "RT @lteytelman: Want to be ethical in science? Speak up. @thespectroscope http:\/\/t.co\/E82s7KRfXi",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "thespectroscope",
        "screen_name" : "thespectroscope",
        "indices" : [ 41, 57 ],
        "id_str" : "2578128949",
        "id" : 2578128949
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 58, 80 ],
        "url" : "http:\/\/t.co\/E82s7KRfXi",
        "expanded_url" : "http:\/\/www.thespectroscope.com\/read\/want-to-be-ethical-in-science-speak-up-by-lenny-teytelman-321",
        "display_url" : "thespectroscope.com\/read\/want-to-b\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "605024892585508864",
    "text" : "Want to be ethical in science? Speak up. @thespectroscope http:\/\/t.co\/E82s7KRfXi",
    "id" : 605024892585508864,
    "created_at" : "2015-05-31 14:55:49 +0000",
    "user" : {
      "name" : "Lenny Teytelman",
      "screen_name" : "lteytelman",
      "protected" : false,
      "id_str" : "1343132275",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/819433710831472640\/WxJQTMMz_normal.jpg",
      "id" : 1343132275,
      "verified" : false
    }
  },
  "id" : 605238112034430976,
  "created_at" : "2015-06-01 05:03:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
} ]