Grailbird.data.tweets_2015_10 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/8GX1szT919",
      "expanded_url" : "http:\/\/journals.plos.org\/plosone\/article?id=10.1371\/journal.pone.0141694",
      "display_url" : "journals.plos.org\/plosone\/articl\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "660569202785390593",
  "text" : "A Validated Smartphone-Based Assessment of Gait and Gait Variability in Parkinson\u2019s Disease https:\/\/t.co\/8GX1szT919",
  "id" : 660569202785390593,
  "created_at" : "2015-10-31 21:29:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 60 ],
      "url" : "https:\/\/t.co\/nsZbzNImos",
      "expanded_url" : "http:\/\/www.smbc-comics.com\/index.php?id=3911",
      "display_url" : "smbc-comics.com\/index.php?id=3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "660568560301944834",
  "text" : "the stolen trolley made out of bread https:\/\/t.co\/nsZbzNImos",
  "id" : 660568560301944834,
  "created_at" : "2015-10-31 21:26:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Disgusted Ape",
      "screen_name" : "lechimp_p",
      "indices" : [ 0, 10 ],
      "id_str" : "53635012",
      "id" : 53635012
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "660541359984680961",
  "geo" : { },
  "id_str" : "660541630827597824",
  "in_reply_to_user_id" : 53635012,
  "text" : "@lechimp_p danke! :)",
  "id" : 660541630827597824,
  "in_reply_to_status_id" : 660541359984680961,
  "created_at" : "2015-10-31 19:39:31 +0000",
  "in_reply_to_screen_name" : "lechimp_p",
  "in_reply_to_user_id_str" : "53635012",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "liftbasel",
      "indices" : [ 58, 68 ]
    } ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/lL6Yb8uF3j",
      "expanded_url" : "https:\/\/twitter.com\/e_richterich\/status\/660415863728775168",
      "display_url" : "twitter.com\/e_richterich\/s\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11407427636667, 8.753385346307272 ]
  },
  "id_str" : "660531745406787585",
  "text" : "This I noticed too. Gender balance of the speaker list at #liftbasel was abysmal. https:\/\/t.co\/lL6Yb8uF3j",
  "id" : 660531745406787585,
  "created_at" : "2015-10-31 19:00:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael R. Crusoe",
      "screen_name" : "biocrusoe",
      "indices" : [ 0, 10 ],
      "id_str" : "17645638",
      "id" : 17645638
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "660502193343041536",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11407387504345, 8.753390309001167 ]
  },
  "id_str" : "660504724127539200",
  "in_reply_to_user_id" : 17645638,
  "text" : "@biocrusoe good point. I got too used to travel on my own. In that case I want 3-4 bags :3",
  "id" : 660504724127539200,
  "in_reply_to_status_id" : 660502193343041536,
  "created_at" : "2015-10-31 17:12:52 +0000",
  "in_reply_to_screen_name" : "biocrusoe",
  "in_reply_to_user_id_str" : "17645638",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael R. Crusoe",
      "screen_name" : "biocrusoe",
      "indices" : [ 0, 10 ],
      "id_str" : "17645638",
      "id" : 17645638
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "660498158431047681",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11402119024149, 8.753376203765463 ]
  },
  "id_str" : "660500471950479360",
  "in_reply_to_user_id" : 17645638,
  "text" : "@biocrusoe I like to travel with little weight :)",
  "id" : 660500471950479360,
  "in_reply_to_status_id" : 660498158431047681,
  "created_at" : "2015-10-31 16:55:58 +0000",
  "in_reply_to_screen_name" : "biocrusoe",
  "in_reply_to_user_id_str" : "17645638",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael R. Crusoe",
      "screen_name" : "biocrusoe",
      "indices" : [ 0, 10 ],
      "id_str" : "17645638",
      "id" : 17645638
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "660495581538680832",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11304021197931, 8.754934551781396 ]
  },
  "id_str" : "660497851395530752",
  "in_reply_to_user_id" : 17645638,
  "text" : "@biocrusoe what\u2019s more fun than a packed bag? ;)",
  "id" : 660497851395530752,
  "in_reply_to_status_id" : 660495581538680832,
  "created_at" : "2015-10-31 16:45:33 +0000",
  "in_reply_to_screen_name" : "biocrusoe",
  "in_reply_to_user_id_str" : "17645638",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.10670997408639, 8.766275198932 ]
  },
  "id_str" : "660479763908272128",
  "text" : "Swarm: \u00ABYou have been at home 5 days in a row. That\u2019s a new record.\u00BB Yeah, this is how I feel.",
  "id" : 660479763908272128,
  "created_at" : "2015-10-31 15:33:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "apollooptik",
      "indices" : [ 123, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11407266974491, 8.753393231905939 ]
  },
  "id_str" : "660464328525651969",
  "text" : "Advice: If you tell me \u201CDid you pick glasses from this aisle?! They are for women!\u201C, we won\u2019t do business. Looking at you, #apollooptik.",
  "id" : 660464328525651969,
  "created_at" : "2015-10-31 14:32:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Denker",
      "screen_name" : "Phaidr0s",
      "indices" : [ 0, 9 ],
      "id_str" : "40466433",
      "id" : 40466433
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "660438746932842496",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11407342064867, 8.753391846051738 ]
  },
  "id_str" : "660438843225677824",
  "in_reply_to_user_id" : 40466433,
  "text" : "@Phaidr0s danke :)",
  "id" : 660438843225677824,
  "in_reply_to_status_id" : 660438746932842496,
  "created_at" : "2015-10-31 12:51:05 +0000",
  "in_reply_to_screen_name" : "Phaidr0s",
  "in_reply_to_user_id_str" : "40466433",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "malech maltz",
      "screen_name" : "malech",
      "indices" : [ 0, 7 ],
      "id_str" : "784085846391713793",
      "id" : 784085846391713793
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11407177105489, 8.753404933623674 ]
  },
  "id_str" : "660433911349145600",
  "text" : "@malech beim Mrozsad braucht man halt Decknamen (i\u2019ll just show myself out)",
  "id" : 660433911349145600,
  "created_at" : "2015-10-31 12:31:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Denker",
      "screen_name" : "Phaidr0s",
      "indices" : [ 0, 9 ],
      "id_str" : "40466433",
      "id" : 40466433
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "660422817620475906",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11407239887098, 8.75340370761928 ]
  },
  "id_str" : "660432767981903872",
  "in_reply_to_user_id" : 40466433,
  "text" : "@Phaidr0s neue Brille :)",
  "id" : 660432767981903872,
  "in_reply_to_status_id" : 660422817620475906,
  "created_at" : "2015-10-31 12:26:56 +0000",
  "in_reply_to_screen_name" : "Phaidr0s",
  "in_reply_to_user_id_str" : "40466433",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "660410610321072128",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.10486459397968, 8.762465734395938 ]
  },
  "id_str" : "660422746321629184",
  "in_reply_to_user_id" : 14286491,
  "text" : "Pink it is.",
  "id" : 660422746321629184,
  "in_reply_to_status_id" : 660410610321072128,
  "created_at" : "2015-10-31 11:47:07 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 13, 19 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "660420360052043776",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.10409522555722, 8.76266346290006 ]
  },
  "id_str" : "660422538825228289",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch @Lobot I did!",
  "id" : 660422538825228289,
  "in_reply_to_status_id" : 660420360052043776,
  "created_at" : "2015-10-31 11:46:17 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "phlox81, JW",
      "screen_name" : "phlox81",
      "indices" : [ 0, 8 ],
      "id_str" : "70190045",
      "id" : 70190045
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "660415234784514048",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.10491176324643, 8.762469745831986 ]
  },
  "id_str" : "660415606672465920",
  "in_reply_to_user_id" : 70190045,
  "text" : "@phlox81 I really like pink. It used to be my hair color until a couple of months ago for a reason :3",
  "id" : 660415606672465920,
  "in_reply_to_status_id" : 660415234784514048,
  "created_at" : "2015-10-31 11:18:45 +0000",
  "in_reply_to_screen_name" : "phlox81",
  "in_reply_to_user_id_str" : "70190045",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hans Zauner",
      "screen_name" : "HansZauner",
      "indices" : [ 0, 11 ],
      "id_str" : "995259308",
      "id" : 995259308
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "660412568406769664",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.10492252596099, 8.762370100691973 ]
  },
  "id_str" : "660414528698601472",
  "in_reply_to_user_id" : 995259308,
  "text" : "@HansZauner die tut es ja auch noch. Ich m\u00F6chte eine Ersatz\/Notfallbrille :)",
  "id" : 660414528698601472,
  "in_reply_to_status_id" : 660412568406769664,
  "created_at" : "2015-10-31 11:14:28 +0000",
  "in_reply_to_screen_name" : "HansZauner",
  "in_reply_to_user_id_str" : "995259308",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cae Vye",
      "screen_name" : "CaeVye",
      "indices" : [ 0, 7 ],
      "id_str" : "31104704",
      "id" : 31104704
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/660411323235332096\/photo\/1",
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/9CKhgAYAYT",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CSpAmPuWUAEds0C.jpg",
      "id_str" : "660411321163337729",
      "id" : 660411321163337729,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSpAmPuWUAEds0C.jpg",
      "sizes" : [ {
        "h" : 1280,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 1280,
        "resize" : "fit",
        "w" : 960
      } ],
      "display_url" : "pic.twitter.com\/9CKhgAYAYT"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "660410973195497472",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.10487974036187, 8.762426761255822 ]
  },
  "id_str" : "660411323235332096",
  "in_reply_to_user_id" : 31104704,
  "text" : "@CaeVye ich mag das pink &amp; B\u00FCgelmuster der linken. Und das hier ist meine aktuelle Primary. https:\/\/t.co\/9CKhgAYAYT",
  "id" : 660411323235332096,
  "in_reply_to_status_id" : 660410973195497472,
  "created_at" : "2015-10-31 11:01:43 +0000",
  "in_reply_to_screen_name" : "CaeVye",
  "in_reply_to_user_id_str" : "31104704",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/660410610321072128\/photo\/1",
      "indices" : [ 35, 58 ],
      "url" : "https:\/\/t.co\/tHsG8sFgUg",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CSo_8ebWIAAGGvP.jpg",
      "id_str" : "660410603555659776",
      "id" : 660410603555659776,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSo_8ebWIAAGGvP.jpg",
      "sizes" : [ {
        "h" : 1280,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1280,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      } ],
      "display_url" : "pic.twitter.com\/tHsG8sFgUg"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/660410610321072128\/photo\/1",
      "indices" : [ 35, 58 ],
      "url" : "https:\/\/t.co\/tHsG8sFgUg",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CSo_8w6WUAADQ6r.jpg",
      "id_str" : "660410608517533696",
      "id" : 660410608517533696,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSo_8w6WUAADQ6r.jpg",
      "sizes" : [ {
        "h" : 1280,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1280,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      } ],
      "display_url" : "pic.twitter.com\/tHsG8sFgUg"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.10487285078342, 8.762473687130841 ]
  },
  "id_str" : "660410610321072128",
  "text" : "Hey Twitter, what should I go for? https:\/\/t.co\/tHsG8sFgUg",
  "id" : 660410610321072128,
  "created_at" : "2015-10-31 10:58:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "K.Rotten Saft\u2728",
      "screen_name" : "Mirabellensaft",
      "indices" : [ 0, 15 ],
      "id_str" : "533210532",
      "id" : 533210532
    }, {
      "name" : "herr_schrat",
      "screen_name" : "herr_schrat",
      "indices" : [ 16, 28 ],
      "id_str" : "16066591",
      "id" : 16066591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "660294063736946688",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11117040844884, 8.757713729449856 ]
  },
  "id_str" : "660376754448695296",
  "in_reply_to_user_id" : 533210532,
  "text" : "@Mirabellensaft @herr_schrat die korrekte Akademiker-Antwort: Im Prinzip.",
  "id" : 660376754448695296,
  "in_reply_to_status_id" : 660294063736946688,
  "created_at" : "2015-10-31 08:44:22 +0000",
  "in_reply_to_screen_name" : "Mirabellensaft",
  "in_reply_to_user_id_str" : "533210532",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 36 ],
      "url" : "https:\/\/t.co\/uHXqlQwog1",
      "expanded_url" : "https:\/\/m.youtube.com\/watch?v=gNhN6lT-y5U",
      "display_url" : "m.youtube.com\/watch?v=gNhN6l\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "660191671922073601",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.98258727687324, 8.436811175424156 ]
  },
  "id_str" : "660191952974061569",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot close https:\/\/t.co\/uHXqlQwog1",
  "id" : 660191952974061569,
  "in_reply_to_status_id" : 660191671922073601,
  "created_at" : "2015-10-30 20:30:02 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kaitlin Thaney \uD83D\uDC81\uD83C\uDFFB",
      "screen_name" : "kaythaney",
      "indices" : [ 0, 10 ],
      "id_str" : "22839233",
      "id" : 22839233
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "660130445586231296",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.54965388644585, 7.587820725295498 ]
  },
  "id_str" : "660133439996370944",
  "in_reply_to_user_id" : 22839233,
  "text" : "@kaythaney in that case I do expect you to join in \uD83D\uDE09",
  "id" : 660133439996370944,
  "in_reply_to_status_id" : 660130445586231296,
  "created_at" : "2015-10-30 16:37:31 +0000",
  "in_reply_to_screen_name" : "kaythaney",
  "in_reply_to_user_id_str" : "22839233",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "liftbasel",
      "indices" : [ 75, 85 ]
    } ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/l8NYqzmutF",
      "expanded_url" : "https:\/\/twitter.com\/kaythaney\/status\/660128624297644032",
      "display_url" : "twitter.com\/kaythaney\/stat\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.54917040006029, 7.587719103328499 ]
  },
  "id_str" : "660129374230994948",
  "text" : "E.g. if you want to talk about the ethics of open source genomics with me. #liftbasel  https:\/\/t.co\/l8NYqzmutF",
  "id" : 660129374230994948,
  "created_at" : "2015-10-30 16:21:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "660126650638729217",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.54915602509635, 7.587370332337532 ]
  },
  "id_str" : "660127492385193985",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot wie es zu \uD83D\uDD28\u26A1\uFE0F\uD83D\uDC68 kam?",
  "id" : 660127492385193985,
  "in_reply_to_status_id" : 660126650638729217,
  "created_at" : "2015-10-30 16:13:53 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Akshat Rathi",
      "screen_name" : "AkshatRathi",
      "indices" : [ 0, 12 ],
      "id_str" : "13766492",
      "id" : 13766492
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "660124489565478912",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.55006932953156, 7.587977188550075 ]
  },
  "id_str" : "660125065191772160",
  "in_reply_to_user_id" : 13766492,
  "text" : "@AkshatRathi I see, you are a fellow gelato lover \uD83C\uDF67\uD83C\uDF68\uD83C\uDF66",
  "id" : 660125065191772160,
  "in_reply_to_status_id" : 660124489565478912,
  "created_at" : "2015-10-30 16:04:14 +0000",
  "in_reply_to_screen_name" : "AkshatRathi",
  "in_reply_to_user_id_str" : "13766492",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 81 ],
      "url" : "https:\/\/t.co\/uvEI0inj1o",
      "expanded_url" : "https:\/\/twitter.com\/sibylle_p\/status\/660116256083861504",
      "display_url" : "twitter.com\/sibylle_p\/stat\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.55486665278107, 7.58964605820502 ]
  },
  "id_str" : "660123736557920256",
  "text" : "I think this really means we need open textbooks already. https:\/\/t.co\/uvEI0inj1o",
  "id" : 660123736557920256,
  "created_at" : "2015-10-30 15:58:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Akshat Rathi",
      "screen_name" : "AkshatRathi",
      "indices" : [ 0, 12 ],
      "id_str" : "13766492",
      "id" : 13766492
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "660122866810281984",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.54905446865, 7.588050107295199 ]
  },
  "id_str" : "660123031050854400",
  "in_reply_to_user_id" : 13766492,
  "text" : "@AkshatRathi thanks, but i cheated: I had the gelato before the talk ;)",
  "id" : 660123031050854400,
  "in_reply_to_status_id" : 660122866810281984,
  "created_at" : "2015-10-30 15:56:09 +0000",
  "in_reply_to_screen_name" : "AkshatRathi",
  "in_reply_to_user_id_str" : "13766492",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Akshat Rathi",
      "screen_name" : "AkshatRathi",
      "indices" : [ 0, 12 ],
      "id_str" : "13766492",
      "id" : 13766492
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "659756060048302081",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.5492520817067, 7.588230986155186 ]
  },
  "id_str" : "660120894409437184",
  "in_reply_to_user_id" : 13766492,
  "text" : "@AkshatRathi btw I tried it today. I wouldn\u2019t say the best ever but still amazingly good. Thanks for the pointer!",
  "id" : 660120894409437184,
  "in_reply_to_status_id" : 659756060048302081,
  "created_at" : "2015-10-30 15:47:40 +0000",
  "in_reply_to_screen_name" : "AkshatRathi",
  "in_reply_to_user_id_str" : "13766492",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Oleg Lavrovsky",
      "screen_name" : "loleg",
      "indices" : [ 3, 9 ],
      "id_str" : "5429882",
      "id" : 5429882
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 104, 120 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "660119201504485376",
  "text" : "RT @loleg: \"Making money is like, yeah, but [DNA] is medicine - and your goal should be to save lives\" \u2013@gedankenstuecke on motives #23andM\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 93, 109 ],
        "id_str" : "14286491",
        "id" : 14286491
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "23andMe",
        "indices" : [ 121, 129 ]
      }, {
        "text" : "liftbasel",
        "indices" : [ 130, 140 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "660116635701919744",
    "geo" : { },
    "id_str" : "660117846119305216",
    "in_reply_to_user_id" : 5429882,
    "text" : "\"Making money is like, yeah, but [DNA] is medicine - and your goal should be to save lives\" \u2013@gedankenstuecke on motives #23andMe #liftbasel",
    "id" : 660117846119305216,
    "in_reply_to_status_id" : 660116635701919744,
    "created_at" : "2015-10-30 15:35:33 +0000",
    "in_reply_to_screen_name" : "loleg",
    "in_reply_to_user_id_str" : "5429882",
    "user" : {
      "name" : "Oleg Lavrovsky",
      "screen_name" : "loleg",
      "protected" : false,
      "id_str" : "5429882",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/843805445986893824\/zBNormYJ_normal.jpg",
      "id" : 5429882,
      "verified" : false
    }
  },
  "id" : 660119201504485376,
  "created_at" : "2015-10-30 15:40:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Oleg Lavrovsky",
      "screen_name" : "loleg",
      "indices" : [ 3, 9 ],
      "id_str" : "5429882",
      "id" : 5429882
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 41, 57 ],
      "id_str" : "14286491",
      "id" : 14286491
    }, {
      "name" : "Patrik Tschudin",
      "screen_name" : "patsch",
      "indices" : [ 74, 81 ],
      "id_str" : "8614392",
      "id" : 8614392
    }, {
      "name" : "openSNP team",
      "screen_name" : "openSNPorg",
      "indices" : [ 82, 93 ],
      "id_str" : "380205172",
      "id" : 380205172
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "liftbasel",
      "indices" : [ 94, 104 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "660119190213435392",
  "text" : "RT @loleg: \"Open data can save lives\". \u2013 @gedankenstuecke puts it bluntly @patsch @openSNPorg #liftbasel",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 30, 46 ],
        "id_str" : "14286491",
        "id" : 14286491
      }, {
        "name" : "Patrik Tschudin",
        "screen_name" : "patsch",
        "indices" : [ 63, 70 ],
        "id_str" : "8614392",
        "id" : 8614392
      }, {
        "name" : "openSNP team",
        "screen_name" : "openSNPorg",
        "indices" : [ 71, 82 ],
        "id_str" : "380205172",
        "id" : 380205172
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "liftbasel",
        "indices" : [ 83, 93 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "660114792154275841",
    "geo" : { },
    "id_str" : "660116635701919744",
    "in_reply_to_user_id" : 8614392,
    "text" : "\"Open data can save lives\". \u2013 @gedankenstuecke puts it bluntly @patsch @openSNPorg #liftbasel",
    "id" : 660116635701919744,
    "in_reply_to_status_id" : 660114792154275841,
    "created_at" : "2015-10-30 15:30:44 +0000",
    "in_reply_to_screen_name" : "patsch",
    "in_reply_to_user_id_str" : "8614392",
    "user" : {
      "name" : "Oleg Lavrovsky",
      "screen_name" : "loleg",
      "protected" : false,
      "id_str" : "5429882",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/843805445986893824\/zBNormYJ_normal.jpg",
      "id" : 5429882,
      "verified" : false
    }
  },
  "id" : 660119190213435392,
  "created_at" : "2015-10-30 15:40:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sibylle Peuker",
      "screen_name" : "sibylle_p",
      "indices" : [ 3, 13 ],
      "id_str" : "113741366",
      "id" : 113741366
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 96, 112 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "liftbasel",
      "indices" : [ 113, 123 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "660119146877833221",
  "text" : "RT @sibylle_p: \"You can buy a DNA test on Amazon and it costs less than the textbook about it.\" @gedankenstuecke #liftbasel https:\/\/t.co\/Hg\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 81, 97 ],
        "id_str" : "14286491",
        "id" : 14286491
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/sibylle_p\/status\/660116256083861504\/photo\/1",
        "indices" : [ 109, 132 ],
        "url" : "https:\/\/t.co\/Hg0Evg4yZw",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CSk0Ok9UwAEtq_N.jpg",
        "id_str" : "660116245430190081",
        "id" : 660116245430190081,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSk0Ok9UwAEtq_N.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/Hg0Evg4yZw"
      } ],
      "hashtags" : [ {
        "text" : "liftbasel",
        "indices" : [ 98, 108 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "660116256083861504",
    "text" : "\"You can buy a DNA test on Amazon and it costs less than the textbook about it.\" @gedankenstuecke #liftbasel https:\/\/t.co\/Hg0Evg4yZw",
    "id" : 660116256083861504,
    "created_at" : "2015-10-30 15:29:14 +0000",
    "user" : {
      "name" : "Sibylle Peuker",
      "screen_name" : "sibylle_p",
      "protected" : false,
      "id_str" : "113741366",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/716294851654889472\/kDZWetbX_normal.jpg",
      "id" : 113741366,
      "verified" : false
    }
  },
  "id" : 660119146877833221,
  "created_at" : "2015-10-30 15:40:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Novozymes Innovation",
      "screen_name" : "NZbioinno",
      "indices" : [ 3, 13 ],
      "id_str" : "912196987",
      "id" : 912196987
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 23, 39 ],
      "id_str" : "14286491",
      "id" : 14286491
    }, {
      "name" : "Luc Henry",
      "screen_name" : "heluc",
      "indices" : [ 89, 95 ],
      "id_str" : "850645992",
      "id" : 850645992
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "open",
      "indices" : [ 43, 48 ]
    }, {
      "text" : "lifescience",
      "indices" : [ 65, 77 ]
    }, {
      "text" : "liftbasel",
      "indices" : [ 78, 88 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "660119118113304577",
  "text" : "RT @NZbioinno: Bastian @gedankenstuecke on #open data sharing in #lifescience #liftbasel @heluc How open should we go ? https:\/\/t.co\/cuacky\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 8, 24 ],
        "id_str" : "14286491",
        "id" : 14286491
      }, {
        "name" : "Luc Henry",
        "screen_name" : "heluc",
        "indices" : [ 74, 80 ],
        "id_str" : "850645992",
        "id" : 850645992
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/NZbioinno\/status\/660115084652519424\/photo\/1",
        "indices" : [ 105, 128 ],
        "url" : "https:\/\/t.co\/cuackydDAY",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CSkzKpiWoAEJRJh.jpg",
        "id_str" : "660115078428139521",
        "id" : 660115078428139521,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSkzKpiWoAEJRJh.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/cuackydDAY"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/NZbioinno\/status\/660115084652519424\/photo\/1",
        "indices" : [ 105, 128 ],
        "url" : "https:\/\/t.co\/cuackydDAY",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CSkzKphWoAEwSTN.jpg",
        "id_str" : "660115078423945217",
        "id" : 660115078423945217,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSkzKphWoAEwSTN.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/cuackydDAY"
      } ],
      "hashtags" : [ {
        "text" : "open",
        "indices" : [ 28, 33 ]
      }, {
        "text" : "lifescience",
        "indices" : [ 50, 62 ]
      }, {
        "text" : "liftbasel",
        "indices" : [ 63, 73 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "660115084652519424",
    "text" : "Bastian @gedankenstuecke on #open data sharing in #lifescience #liftbasel @heluc How open should we go ? https:\/\/t.co\/cuackydDAY",
    "id" : 660115084652519424,
    "created_at" : "2015-10-30 15:24:35 +0000",
    "user" : {
      "name" : "Novozymes Innovation",
      "screen_name" : "NZbioinno",
      "protected" : false,
      "id_str" : "912196987",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/423128922855714817\/-W6RExzy_normal.png",
      "id" : 912196987,
      "verified" : false
    }
  },
  "id" : 660119118113304577,
  "created_at" : "2015-10-30 15:40:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 45 ],
      "url" : "https:\/\/t.co\/4D4NFG8oHz",
      "expanded_url" : "https:\/\/instagram.com\/p\/9dvOIVBwtD\/",
      "display_url" : "instagram.com\/p\/9dvOIVBwtD\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.5489502, 7.5872598 ]
  },
  "id_str" : "660096989443530752",
  "text" : "Heads up @ Markthalle https:\/\/t.co\/4D4NFG8oHz",
  "id" : 660096989443530752,
  "created_at" : "2015-10-30 14:12:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Effy Vayena",
      "screen_name" : "EffyVayena",
      "indices" : [ 3, 14 ],
      "id_str" : "397518511",
      "id" : 397518511
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 83 ],
      "url" : "https:\/\/t.co\/7olJiNfhXU",
      "expanded_url" : "http:\/\/bostonreview.net\/books-ideas\/yarden-katz-who-owns-molecular-biology#.VjNfxM_d0zo.twitter",
      "display_url" : "bostonreview.net\/books-ideas\/ya\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "660082141288615936",
  "text" : "RT @EffyVayena: Who Owns Molecular Biology? | Boston Review https:\/\/t.co\/7olJiNfhXU",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 44, 67 ],
        "url" : "https:\/\/t.co\/7olJiNfhXU",
        "expanded_url" : "http:\/\/bostonreview.net\/books-ideas\/yarden-katz-who-owns-molecular-biology#.VjNfxM_d0zo.twitter",
        "display_url" : "bostonreview.net\/books-ideas\/ya\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "660067925802541056",
    "text" : "Who Owns Molecular Biology? | Boston Review https:\/\/t.co\/7olJiNfhXU",
    "id" : 660067925802541056,
    "created_at" : "2015-10-30 12:17:11 +0000",
    "user" : {
      "name" : "Effy Vayena",
      "screen_name" : "EffyVayena",
      "protected" : false,
      "id_str" : "397518511",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/837580905615085568\/EBU1zR7D_normal.jpg",
      "id" : 397518511,
      "verified" : false
    }
  },
  "id" : 660082141288615936,
  "created_at" : "2015-10-30 13:13:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "beerdecoded",
      "indices" : [ 81, 93 ]
    }, {
      "text" : "liftbasel",
      "indices" : [ 94, 104 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "660080416100114432",
  "text" : "\u00ABWho had beer yesterday?\u00BB \u2013 \u00ABMh, did we? I can\u2019t really remember what happened!\u00BB #beerdecoded #liftbasel",
  "id" : 660080416100114432,
  "created_at" : "2015-10-30 13:06:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "liftbasel",
      "indices" : [ 44, 54 ]
    } ],
    "urls" : [ {
      "indices" : [ 68, 91 ],
      "url" : "https:\/\/t.co\/fPp3iJ7h7j",
      "expanded_url" : "https:\/\/instagram.com\/p\/9dnTN1hwuE\/",
      "display_url" : "instagram.com\/p\/9dnTN1hwuE\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.5489502, 7.5872598 ]
  },
  "id_str" : "660079572080312321",
  "text" : "I have seen some things in the virtual lab. #liftbasel @ Markthalle https:\/\/t.co\/fPp3iJ7h7j",
  "id" : 660079572080312321,
  "created_at" : "2015-10-30 13:03:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erik Garrison",
      "screen_name" : "erikgarrison",
      "indices" : [ 0, 13 ],
      "id_str" : "95685725",
      "id" : 95685725
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "660038035183149056",
  "geo" : { },
  "id_str" : "660038283653726208",
  "in_reply_to_user_id" : 95685725,
  "text" : "@erikgarrison aye, I always like to say \u201Ebig data\u201C is whatever is too large to easily fit into HDD\/RAM today.",
  "id" : 660038283653726208,
  "in_reply_to_status_id" : 660038035183149056,
  "created_at" : "2015-10-30 10:19:24 +0000",
  "in_reply_to_screen_name" : "erikgarrison",
  "in_reply_to_user_id_str" : "95685725",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DNAdigest.org",
      "screen_name" : "DNADigest",
      "indices" : [ 3, 13 ],
      "id_str" : "334912047",
      "id" : 334912047
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "660035855759843328",
  "text" : "RT @DNADigest: Become part of the DNAdigest Team! We're seeking volunteers to work with us on our visuals &amp; communications https:\/\/t.co\/Wt4\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 112, 135 ],
        "url" : "https:\/\/t.co\/Wt4s1vC0Gc",
        "expanded_url" : "http:\/\/buff.ly\/1W5Ta6d",
        "display_url" : "buff.ly\/1W5Ta6d"
      } ]
    },
    "geo" : { },
    "id_str" : "660035473570680832",
    "text" : "Become part of the DNAdigest Team! We're seeking volunteers to work with us on our visuals &amp; communications https:\/\/t.co\/Wt4s1vC0Gc",
    "id" : 660035473570680832,
    "created_at" : "2015-10-30 10:08:14 +0000",
    "user" : {
      "name" : "DNAdigest.org",
      "screen_name" : "DNADigest",
      "protected" : false,
      "id_str" : "334912047",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/430707142232772608\/Vmx-V5fY_normal.png",
      "id" : 334912047,
      "verified" : false
    }
  },
  "id" : 660035855759843328,
  "created_at" : "2015-10-30 10:09:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul-Olivier Dehaye",
      "screen_name" : "podehaye",
      "indices" : [ 0, 9 ],
      "id_str" : "2219841242",
      "id" : 2219841242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "660032679975518208",
  "geo" : { },
  "id_str" : "660032893297819648",
  "in_reply_to_user_id" : 2219841242,
  "text" : "@podehaye so it\u2019s more like drinking from the cholera well than from the firehose :D",
  "id" : 660032893297819648,
  "in_reply_to_status_id" : 660032679975518208,
  "created_at" : "2015-10-30 09:57:59 +0000",
  "in_reply_to_screen_name" : "podehaye",
  "in_reply_to_user_id_str" : "2219841242",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul-Olivier Dehaye",
      "screen_name" : "podehaye",
      "indices" : [ 3, 12 ],
      "id_str" : "2219841242",
      "id" : 2219841242
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 14, 30 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "660032795272724480",
  "text" : "RT @podehaye: @gedankenstuecke powerful analogy: industrial revolution shoddy water reservoirs and lawsuits around their leaks https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 0, 16 ],
        "id_str" : "14286491",
        "id" : 14286491
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/d1B28yRe6N",
        "expanded_url" : "http:\/\/papers.ssrn.com\/sol3\/papers.cfm?abstract_id=928401",
        "display_url" : "papers.ssrn.com\/sol3\/papers.cf\u2026"
      } ]
    },
    "in_reply_to_status_id_str" : "660030921882640384",
    "geo" : { },
    "id_str" : "660032679975518208",
    "in_reply_to_user_id" : 14286491,
    "text" : "@gedankenstuecke powerful analogy: industrial revolution shoddy water reservoirs and lawsuits around their leaks https:\/\/t.co\/d1B28yRe6N",
    "id" : 660032679975518208,
    "in_reply_to_status_id" : 660030921882640384,
    "created_at" : "2015-10-30 09:57:08 +0000",
    "in_reply_to_screen_name" : "gedankenstuecke",
    "in_reply_to_user_id_str" : "14286491",
    "user" : {
      "name" : "Paul-Olivier Dehaye",
      "screen_name" : "podehaye",
      "protected" : false,
      "id_str" : "2219841242",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/840965162349797376\/7hdkcm04_normal.jpg",
      "id" : 2219841242,
      "verified" : false
    }
  },
  "id" : 660032795272724480,
  "created_at" : "2015-10-30 09:57:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Schawinski",
      "screen_name" : "kevinschawinski",
      "indices" : [ 0, 16 ],
      "id_str" : "242844365",
      "id" : 242844365
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "660031019345698817",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.54899822989277, 7.588019320193301 ]
  },
  "id_str" : "660031166263767040",
  "in_reply_to_user_id" : 242844365,
  "text" : "@kevinschawinski a firestorm of data that can only be handled by drinking from the firehose?",
  "id" : 660031166263767040,
  "in_reply_to_status_id" : 660031019345698817,
  "created_at" : "2015-10-30 09:51:07 +0000",
  "in_reply_to_screen_name" : "kevinschawinski",
  "in_reply_to_user_id_str" : "242844365",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "liftbasel",
      "indices" : [ 121, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.54899822989277, 7.588019320193301 ]
  },
  "id_str" : "660030921882640384",
  "text" : "\u00ABI\u2019m tired of saying big data [\u2026] this is why I will say \u2018a tsunami of data\u2019.\u00BB I say: \u2018a natural disaster of an analogy\u2019 #liftbasel",
  "id" : 660030921882640384,
  "created_at" : "2015-10-30 09:50:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "liftbasel",
      "indices" : [ 45, 55 ]
    } ],
    "urls" : [ {
      "indices" : [ 21, 44 ],
      "url" : "https:\/\/t.co\/oMOOU3spX7",
      "expanded_url" : "https:\/\/vine.co\/v\/e3BIEz7Mtt5",
      "display_url" : "vine.co\/v\/e3BIEz7Mtt5"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.54956569203802, 7.586534982509842 ]
  },
  "id_str" : "660029058827337728",
  "text" : "Centrifuge on a bike https:\/\/t.co\/oMOOU3spX7 #liftbasel",
  "id" : 660029058827337728,
  "created_at" : "2015-10-30 09:42:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 63 ],
      "url" : "https:\/\/t.co\/IA6OAm6pfx",
      "expanded_url" : "http:\/\/media.giphy.com\/media\/IL1sMUfQVRNFC\/giphy.gif",
      "display_url" : "media.giphy.com\/media\/IL1sMUfQ\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.55486358840716, 7.589642467847969 ]
  },
  "id_str" : "660026656757817344",
  "text" : "Naive believers in biotechnology\u2026 I be\u2026 https:\/\/t.co\/IA6OAm6pfx",
  "id" : 660026656757817344,
  "created_at" : "2015-10-30 09:33:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 57 ],
      "url" : "https:\/\/t.co\/BrI1Rf0ubt",
      "expanded_url" : "http:\/\/stream1.gifsoup.com\/view5\/4042908\/mars-attacks-head-explode-o.gif",
      "display_url" : "stream1.gifsoup.com\/view5\/4042908\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.5516325425743, 7.587815031902079 ]
  },
  "id_str" : "660023391102046208",
  "text" : "\u00ABIterative innovative disruption\u00BB https:\/\/t.co\/BrI1Rf0ubt",
  "id" : 660023391102046208,
  "created_at" : "2015-10-30 09:20:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Loman",
      "screen_name" : "pathogenomenick",
      "indices" : [ 3, 19 ],
      "id_str" : "85906238",
      "id" : 85906238
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 87 ],
      "url" : "https:\/\/t.co\/XslifqBTBh",
      "expanded_url" : "http:\/\/omicsomics.blogspot.com\/2015\/10\/this-weekend-brought-formal-launch-of.html?spref=tw",
      "display_url" : "omicsomics.blogspot.com\/2015\/10\/this-w\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "660021263876939776",
  "text" : "RT @pathogenomenick: Omics! Omics!: BGI Launches the BGISEQ-500 https:\/\/t.co\/XslifqBTBh",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 43, 66 ],
        "url" : "https:\/\/t.co\/XslifqBTBh",
        "expanded_url" : "http:\/\/omicsomics.blogspot.com\/2015\/10\/this-weekend-brought-formal-launch-of.html?spref=tw",
        "display_url" : "omicsomics.blogspot.com\/2015\/10\/this-w\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "660011173501341696",
    "text" : "Omics! Omics!: BGI Launches the BGISEQ-500 https:\/\/t.co\/XslifqBTBh",
    "id" : 660011173501341696,
    "created_at" : "2015-10-30 08:31:40 +0000",
    "user" : {
      "name" : "Nick Loman",
      "screen_name" : "pathogenomenick",
      "protected" : false,
      "id_str" : "85906238",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/654948428951195648\/i5lt2BWa_normal.jpg",
      "id" : 85906238,
      "verified" : false
    }
  },
  "id" : 660021263876939776,
  "created_at" : "2015-10-30 09:11:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Schawinski",
      "screen_name" : "kevinschawinski",
      "indices" : [ 0, 16 ],
      "id_str" : "242844365",
      "id" : 242844365
    }, {
      "name" : "Misha Angrist",
      "screen_name" : "MishaAngrist",
      "indices" : [ 17, 30 ],
      "id_str" : "116877838",
      "id" : 116877838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "659992944930369536",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.55380143311775, 7.586091789132716 ]
  },
  "id_str" : "659993312137449472",
  "in_reply_to_user_id" : 242844365,
  "text" : "@kevinschawinski @MishaAngrist that people still haven\u2019t learnt the \u2018too good to be true\u2019-lesson amazes me.",
  "id" : 659993312137449472,
  "in_reply_to_status_id" : 659992944930369536,
  "created_at" : "2015-10-30 07:20:42 +0000",
  "in_reply_to_screen_name" : "kevinschawinski",
  "in_reply_to_user_id_str" : "242844365",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/NZwBsqdtvF",
      "expanded_url" : "https:\/\/twitter.com\/MishaAngrist\/status\/659937170107535360",
      "display_url" : "twitter.com\/MishaAngrist\/s\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.55377424575667, 7.586088060483703 ]
  },
  "id_str" : "659992484672634880",
  "text" : "\u00ABTheranos has bumped up against the scientific method, which puts a premium on verification over narrative\u00BB https:\/\/t.co\/NZwBsqdtvF",
  "id" : 659992484672634880,
  "created_at" : "2015-10-30 07:17:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "li5a",
      "screen_name" : "li5a",
      "indices" : [ 0, 5 ],
      "id_str" : "11712822",
      "id" : 11712822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "659808379548778496",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.55361092978598, 7.590829439003295 ]
  },
  "id_str" : "659808654636527616",
  "in_reply_to_user_id" : 11712822,
  "text" : "@li5a I think DIYBio in Berlin could profit :)",
  "id" : 659808654636527616,
  "in_reply_to_status_id" : 659808379548778496,
  "created_at" : "2015-10-29 19:06:56 +0000",
  "in_reply_to_screen_name" : "li5a",
  "in_reply_to_user_id_str" : "11712822",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "li5a",
      "screen_name" : "li5a",
      "indices" : [ 0, 5 ],
      "id_str" : "11712822",
      "id" : 11712822
    }, {
      "name" : "Gernot J. Abel",
      "screen_name" : "gernotJabel",
      "indices" : [ 30, 42 ],
      "id_str" : "1912181796",
      "id" : 1912181796
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "659807079842975744",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.55359776420419, 7.590763963879566 ]
  },
  "id_str" : "659807290615316480",
  "in_reply_to_user_id" : 11712822,
  "text" : "@li5a you should meet up with @gernotJabel if you find a chance :)",
  "id" : 659807290615316480,
  "in_reply_to_status_id" : 659807079842975744,
  "created_at" : "2015-10-29 19:01:31 +0000",
  "in_reply_to_screen_name" : "li5a",
  "in_reply_to_user_id_str" : "11712822",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.54926791276572, 7.587708801832589 ]
  },
  "id_str" : "659797643443466240",
  "text" : "Found the DIYBio-Table for dinner \\o\/",
  "id" : 659797643443466240,
  "created_at" : "2015-10-29 18:23:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "liftbasel",
      "indices" : [ 91, 101 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.54933975641387, 7.587609803311143 ]
  },
  "id_str" : "659788345195761664",
  "text" : "\u00ABETH has its own brewery. Just in case you where wondering where your tax money is going.\u00BB #liftbasel",
  "id" : 659788345195761664,
  "created_at" : "2015-10-29 17:46:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "659764905860579328",
  "text" : "I truly have a diverse set of skills: A student acknowledges me in her thesis for \u2018keeping her sweets from getting old\u2019.",
  "id" : 659764905860579328,
  "created_at" : "2015-10-29 16:13:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Denker",
      "screen_name" : "Phaidr0s",
      "indices" : [ 0, 9 ],
      "id_str" : "40466433",
      "id" : 40466433
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "659761059167911936",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.549404336097, 7.587767048226789 ]
  },
  "id_str" : "659761564652802048",
  "in_reply_to_user_id" : 40466433,
  "text" : "@Phaidr0s willst du etwa nicht mit mir in die H\u00F6hle gehen?",
  "id" : 659761564652802048,
  "in_reply_to_status_id" : 659761059167911936,
  "created_at" : "2015-10-29 15:59:49 +0000",
  "in_reply_to_screen_name" : "Phaidr0s",
  "in_reply_to_user_id_str" : "40466433",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Denker",
      "screen_name" : "Phaidr0s",
      "indices" : [ 0, 9 ],
      "id_str" : "40466433",
      "id" : 40466433
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "659760838920830977",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.55486584727407, 7.589645420588809 ]
  },
  "id_str" : "659760950585729024",
  "in_reply_to_user_id" : 40466433,
  "text" : "@Phaidr0s das sieht mir doch gar nicht \u00E4hnlich!",
  "id" : 659760950585729024,
  "in_reply_to_status_id" : 659760838920830977,
  "created_at" : "2015-10-29 15:57:23 +0000",
  "in_reply_to_screen_name" : "Phaidr0s",
  "in_reply_to_user_id_str" : "40466433",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Denker",
      "screen_name" : "Phaidr0s",
      "indices" : [ 0, 9 ],
      "id_str" : "40466433",
      "id" : 40466433
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "659759427994705924",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.54903632704055, 7.587346212504648 ]
  },
  "id_str" : "659760784726212608",
  "in_reply_to_user_id" : 40466433,
  "text" : "@Phaidr0s als h\u00E4tte ich das verdient!  \u00AF\\_(\u30C4)_\/\u00AF",
  "id" : 659760784726212608,
  "in_reply_to_status_id" : 659759427994705924,
  "created_at" : "2015-10-29 15:56:43 +0000",
  "in_reply_to_screen_name" : "Phaidr0s",
  "in_reply_to_user_id_str" : "40466433",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Denker",
      "screen_name" : "Phaidr0s",
      "indices" : [ 0, 9 ],
      "id_str" : "40466433",
      "id" : 40466433
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "659757900185911298",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.5508260903838, 7.590016961105557 ]
  },
  "id_str" : "659758130415411200",
  "in_reply_to_user_id" : 40466433,
  "text" : "@Phaidr0s I want those 20 minutes of my life back.",
  "id" : 659758130415411200,
  "in_reply_to_status_id" : 659757900185911298,
  "created_at" : "2015-10-29 15:46:10 +0000",
  "in_reply_to_screen_name" : "Phaidr0s",
  "in_reply_to_user_id_str" : "40466433",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.54940724103609, 7.587591685556068 ]
  },
  "id_str" : "659756472281243648",
  "text" : "If you collect data that you know is useless, why do you have to give a workshop presenting your \u2018results\u2019?",
  "id" : 659756472281243648,
  "created_at" : "2015-10-29 15:39:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Akshat Rathi",
      "screen_name" : "AkshatRathi",
      "indices" : [ 0, 12 ],
      "id_str" : "13766492",
      "id" : 13766492
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "659756060048302081",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.54940724103609, 7.587591685556068 ]
  },
  "id_str" : "659756132492255233",
  "in_reply_to_user_id" : 13766492,
  "text" : "@AkshatRathi I will take that risk :)",
  "id" : 659756132492255233,
  "in_reply_to_status_id" : 659756060048302081,
  "created_at" : "2015-10-29 15:38:14 +0000",
  "in_reply_to_screen_name" : "AkshatRathi",
  "in_reply_to_user_id_str" : "13766492",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Akshat Rathi",
      "screen_name" : "AkshatRathi",
      "indices" : [ 0, 12 ],
      "id_str" : "13766492",
      "id" : 13766492
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "659752155641995264",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.54940724103609, 7.587591685556068 ]
  },
  "id_str" : "659755740534566912",
  "in_reply_to_user_id" : 13766492,
  "text" : "@AkshatRathi where can I find this? :3",
  "id" : 659755740534566912,
  "in_reply_to_status_id" : 659752155641995264,
  "created_at" : "2015-10-29 15:36:40 +0000",
  "in_reply_to_screen_name" : "AkshatRathi",
  "in_reply_to_user_id_str" : "13766492",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 63 ],
      "url" : "https:\/\/t.co\/Yvsw0M9TrI",
      "expanded_url" : "http:\/\/massgenomics.org\/2015\/10\/ngs-analysis-not-free.html",
      "display_url" : "massgenomics.org\/2015\/10\/ngs-an\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "659730484231053313",
  "text" : "Why Bioinformatics Analysis Is Not Free https:\/\/t.co\/Yvsw0M9TrI",
  "id" : 659730484231053313,
  "created_at" : "2015-10-29 13:56:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/659725592582086656\/photo\/1",
      "indices" : [ 48, 71 ],
      "url" : "https:\/\/t.co\/FOPLZ5L6DS",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CSfQ7lOWwAALEPD.jpg",
      "id_str" : "659725592456249344",
      "id" : 659725592456249344,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSfQ7lOWwAALEPD.jpg",
      "sizes" : [ {
        "h" : 1028,
        "resize" : "fit",
        "w" : 1371
      }, {
        "h" : 1028,
        "resize" : "fit",
        "w" : 1371
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/FOPLZ5L6DS"
    } ],
    "hashtags" : [ {
      "text" : "liftbasel",
      "indices" : [ 3, 13 ]
    }, {
      "text" : "beersdecoded",
      "indices" : [ 34, 47 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.550826, 7.590017 ]
  },
  "id_str" : "659725592582086656",
  "text" : "At #liftbasel: The bento lab, for #beersdecoded https:\/\/t.co\/FOPLZ5L6DS",
  "id" : 659725592582086656,
  "created_at" : "2015-10-29 13:36:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Madeleine Price Ball",
      "screen_name" : "madprime",
      "indices" : [ 0, 9 ],
      "id_str" : "71557700",
      "id" : 71557700
    }, {
      "name" : "Chris Ball",
      "screen_name" : "cjbprime",
      "indices" : [ 10, 19 ],
      "id_str" : "41779829",
      "id" : 41779829
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "659722191509000192",
  "geo" : { },
  "id_str" : "659722837482147840",
  "in_reply_to_user_id" : 71557700,
  "text" : "@madprime @cjbprime that\u2019s a great encouragement!",
  "id" : 659722837482147840,
  "in_reply_to_status_id" : 659722191509000192,
  "created_at" : "2015-10-29 13:25:56 +0000",
  "in_reply_to_screen_name" : "madprime",
  "in_reply_to_user_id_str" : "71557700",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Madeleine Price Ball",
      "screen_name" : "madprime",
      "indices" : [ 3, 12 ],
      "id_str" : "71557700",
      "id" : 71557700
    }, {
      "name" : "Chris Ball",
      "screen_name" : "cjbprime",
      "indices" : [ 47, 56 ],
      "id_str" : "41779829",
      "id" : 41779829
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "659722710101176320",
  "text" : "RT @madprime: Today's a special day for me and @cjbprime \u2013 our 10th wedding anniversary! This is how we're celebrating: https:\/\/t.co\/U1YfOD\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Chris Ball",
        "screen_name" : "cjbprime",
        "indices" : [ 33, 42 ],
        "id_str" : "41779829",
        "id" : 41779829
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 106, 129 ],
        "url" : "https:\/\/t.co\/U1YfODiNo0",
        "expanded_url" : "https:\/\/medium.com\/@madprime\/an-interview-with-myself-explaining-our-10th-anniversary-celebration-ac922df73352#.af6k4s98u",
        "display_url" : "medium.com\/@madprime\/an-i\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "659722191509000192",
    "text" : "Today's a special day for me and @cjbprime \u2013 our 10th wedding anniversary! This is how we're celebrating: https:\/\/t.co\/U1YfODiNo0",
    "id" : 659722191509000192,
    "created_at" : "2015-10-29 13:23:22 +0000",
    "user" : {
      "name" : "Madeleine Price Ball",
      "screen_name" : "madprime",
      "protected" : false,
      "id_str" : "71557700",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/515539302931910656\/9N7oFHFZ_normal.png",
      "id" : 71557700,
      "verified" : false
    }
  },
  "id" : 659722710101176320,
  "created_at" : "2015-10-29 13:25:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\/\" rel=\"nofollow\"\u003EOS X\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrik Tschudin",
      "screen_name" : "patsch",
      "indices" : [ 0, 7 ],
      "id_str" : "8614392",
      "id" : 8614392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "659720516287229952",
  "geo" : { },
  "id_str" : "659720647480901632",
  "in_reply_to_user_id" : 8614392,
  "text" : "@patsch \u201Epsst, dreh dich nicht um!\u201C :D",
  "id" : 659720647480901632,
  "in_reply_to_status_id" : 659720516287229952,
  "created_at" : "2015-10-29 13:17:14 +0000",
  "in_reply_to_screen_name" : "patsch",
  "in_reply_to_user_id_str" : "8614392",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrik Tschudin",
      "screen_name" : "patsch",
      "indices" : [ 0, 7 ],
      "id_str" : "8614392",
      "id" : 8614392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "659716479869427712",
  "geo" : { },
  "id_str" : "659716538430287872",
  "in_reply_to_user_id" : 8614392,
  "text" : "@patsch cool, freu mich drauf :)",
  "id" : 659716538430287872,
  "in_reply_to_status_id" : 659716479869427712,
  "created_at" : "2015-10-29 13:00:54 +0000",
  "in_reply_to_screen_name" : "patsch",
  "in_reply_to_user_id_str" : "8614392",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrik Tschudin",
      "screen_name" : "patsch",
      "indices" : [ 0, 7 ],
      "id_str" : "8614392",
      "id" : 8614392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "659700625131888640",
  "geo" : { },
  "id_str" : "659715291056836608",
  "in_reply_to_user_id" : 8614392,
  "text" : "@patsch sehen wir uns auf einen Kaffee sp\u00E4ter? :)",
  "id" : 659715291056836608,
  "in_reply_to_status_id" : 659700625131888640,
  "created_at" : "2015-10-29 12:55:56 +0000",
  "in_reply_to_screen_name" : "patsch",
  "in_reply_to_user_id_str" : "8614392",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gernot J. Abel",
      "screen_name" : "gernotJabel",
      "indices" : [ 0, 12 ],
      "id_str" : "1912181796",
      "id" : 1912181796
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "659706075843809280",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.54919118800053, 7.587518591141001 ]
  },
  "id_str" : "659706646357286913",
  "in_reply_to_user_id" : 1912181796,
  "text" : "@gernotJabel me too!",
  "id" : 659706646357286913,
  "in_reply_to_status_id" : 659706075843809280,
  "created_at" : "2015-10-29 12:21:35 +0000",
  "in_reply_to_screen_name" : "gernotJabel",
  "in_reply_to_user_id_str" : "1912181796",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Akshat Rathi",
      "screen_name" : "AkshatRathi",
      "indices" : [ 0, 12 ],
      "id_str" : "13766492",
      "id" : 13766492
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "659704057901285376",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.55105096385586, 7.587314425043377 ]
  },
  "id_str" : "659704317084086272",
  "in_reply_to_user_id" : 13766492,
  "text" : "@AkshatRathi will do!",
  "id" : 659704317084086272,
  "in_reply_to_status_id" : 659704057901285376,
  "created_at" : "2015-10-29 12:12:20 +0000",
  "in_reply_to_screen_name" : "AkshatRathi",
  "in_reply_to_user_id_str" : "13766492",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "liftbasel",
      "indices" : [ 38, 48 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.55386875150151, 7.586053284642435 ]
  },
  "id_str" : "659701811314606081",
  "text" : "Safely arrived. Next: heading over to #liftbasel.",
  "id" : 659701811314606081,
  "created_at" : "2015-10-29 12:02:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 62 ],
      "url" : "https:\/\/t.co\/vFNbivQUla",
      "expanded_url" : "http:\/\/thememorypalace.us\/2015\/10\/mary-walker-would-wear-what-she-wanted\/",
      "display_url" : "thememorypalace.us\/2015\/10\/mary-w\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.485666, 7.901273 ]
  },
  "id_str" : "659680245910515712",
  "text" : "Mary Walker Would Wear What She Wanted https:\/\/t.co\/vFNbivQUla",
  "id" : 659680245910515712,
  "created_at" : "2015-10-29 10:36:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1069409028222, 8.732893038891275 ]
  },
  "id_str" : "659650230045032448",
  "text" : "And off to Basel for LIFT15.",
  "id" : 659650230045032448,
  "created_at" : "2015-10-29 08:37:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Torsten Seemann",
      "screen_name" : "torstenseemann",
      "indices" : [ 3, 18 ],
      "id_str" : "42558652",
      "id" : 42558652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/X6DLIgrsHH",
      "expanded_url" : "http:\/\/priceonomics.com\/whats-the-difference-between-data-science-and\/",
      "display_url" : "priceonomics.com\/whats-the-diff\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "659472730815901696",
  "text" : "RT @torstenseemann: \"A data scientist is a statistician who lives in San Franscisco\" https:\/\/t.co\/X6DLIgrsHH",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 65, 88 ],
        "url" : "https:\/\/t.co\/X6DLIgrsHH",
        "expanded_url" : "http:\/\/priceonomics.com\/whats-the-difference-between-data-science-and\/",
        "display_url" : "priceonomics.com\/whats-the-diff\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "659464539461652480",
    "text" : "\"A data scientist is a statistician who lives in San Franscisco\" https:\/\/t.co\/X6DLIgrsHH",
    "id" : 659464539461652480,
    "created_at" : "2015-10-28 20:19:33 +0000",
    "user" : {
      "name" : "Torsten Seemann",
      "screen_name" : "torstenseemann",
      "protected" : false,
      "id_str" : "42558652",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/720526185361510400\/dA-svJxC_normal.jpg",
      "id" : 42558652,
      "verified" : false
    }
  },
  "id" : 659472730815901696,
  "created_at" : "2015-10-28 20:52:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 3, 12 ],
      "id_str" : "14245811",
      "id" : 14245811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "659429101158211584",
  "text" : "RT @wilbanks: I\u2019m about 1\/3 through this and am going to stop, brew fresh coffee, and read the whole thing 3 times in a row. https:\/\/t.co\/V\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 111, 134 ],
        "url" : "https:\/\/t.co\/Vkbi9yufRn",
        "expanded_url" : "https:\/\/twitter.com\/dylanw\/status\/659422758338629632",
        "display_url" : "twitter.com\/dylanw\/status\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "659423649045327872",
    "text" : "I\u2019m about 1\/3 through this and am going to stop, brew fresh coffee, and read the whole thing 3 times in a row. https:\/\/t.co\/Vkbi9yufRn",
    "id" : 659423649045327872,
    "created_at" : "2015-10-28 17:37:04 +0000",
    "user" : {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "protected" : false,
      "id_str" : "14245811",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/925696899566440448\/BUTdp410_normal.jpg",
      "id" : 14245811,
      "verified" : false
    }
  },
  "id" : 659429101158211584,
  "created_at" : "2015-10-28 17:58:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "nikki forebber",
      "screen_name" : "antischokke",
      "indices" : [ 0, 12 ],
      "id_str" : "2813661",
      "id" : 2813661
    }, {
      "name" : "Jens Ohlig",
      "screen_name" : "johl",
      "indices" : [ 13, 18 ],
      "id_str" : "1147751",
      "id" : 1147751
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "659402705434210305",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1729797980524, 8.62758443403004 ]
  },
  "id_str" : "659403413516632064",
  "in_reply_to_user_id" : 2813661,
  "text" : "@antischokke @johl the genome in the machine \u2014 ethics of open data meeting very personal data.",
  "id" : 659403413516632064,
  "in_reply_to_status_id" : 659402705434210305,
  "created_at" : "2015-10-28 16:16:39 +0000",
  "in_reply_to_screen_name" : "antischokke",
  "in_reply_to_user_id_str" : "2813661",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jens Ohlig",
      "screen_name" : "johl",
      "indices" : [ 0, 5 ],
      "id_str" : "1147751",
      "id" : 1147751
    }, {
      "name" : "nikki forebber",
      "screen_name" : "antischokke",
      "indices" : [ 6, 18 ],
      "id_str" : "2813661",
      "id" : 2813661
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "659401680178540544",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17234947260905, 8.627513143411596 ]
  },
  "id_str" : "659401850257592320",
  "in_reply_to_user_id" : 1147751,
  "text" : "@johl @antischokke nice, versuche bei euch vorbeizuschauen :)",
  "id" : 659401850257592320,
  "in_reply_to_status_id" : 659401680178540544,
  "created_at" : "2015-10-28 16:10:26 +0000",
  "in_reply_to_screen_name" : "johl",
  "in_reply_to_user_id_str" : "1147751",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jens Ohlig",
      "screen_name" : "johl",
      "indices" : [ 0, 5 ],
      "id_str" : "1147751",
      "id" : 1147751
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "659401154674208768",
  "geo" : { },
  "id_str" : "659401242343510017",
  "in_reply_to_user_id" : 1147751,
  "text" : "@johl cool, dann sieht man sich ja. Machst du auch eine Session? :)",
  "id" : 659401242343510017,
  "in_reply_to_status_id" : 659401154674208768,
  "created_at" : "2015-10-28 16:08:01 +0000",
  "in_reply_to_screen_name" : "johl",
  "in_reply_to_user_id_str" : "1147751",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jens Ohlig",
      "screen_name" : "johl",
      "indices" : [ 0, 5 ],
      "id_str" : "1147751",
      "id" : 1147751
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "659394948358414336",
  "geo" : { },
  "id_str" : "659400114138689536",
  "in_reply_to_user_id" : 1147751,
  "text" : "@johl bist du auch dabei? :)",
  "id" : 659400114138689536,
  "in_reply_to_status_id" : 659394948358414336,
  "created_at" : "2015-10-28 16:03:32 +0000",
  "in_reply_to_screen_name" : "johl",
  "in_reply_to_user_id_str" : "1147751",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 56 ],
      "url" : "https:\/\/t.co\/S0yrw61xjE",
      "expanded_url" : "https:\/\/twitter.com\/opendata_hk\/status\/658624513681199104",
      "display_url" : "twitter.com\/opendata_hk\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "659365606135832576",
  "text" : "I put on my robe and wizard hat\u2026 https:\/\/t.co\/S0yrw61xjE",
  "id" : 659365606135832576,
  "created_at" : "2015-10-28 13:46:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "659353867742781440",
  "text" : "Updated MacOS, it still forgets which Keyboard layouts I installed.  \u00AF\\_(\u30C4)_\/\u00AF",
  "id" : 659353867742781440,
  "created_at" : "2015-10-28 12:59:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonas",
      "screen_name" : "lsanoj",
      "indices" : [ 0, 7 ],
      "id_str" : "18918915",
      "id" : 18918915
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "659336311665487875",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17235816046654, 8.627513454862509 ]
  },
  "id_str" : "659337443959816192",
  "in_reply_to_user_id" : 18918915,
  "text" : "@lsanoj avoiding jet lag :)",
  "id" : 659337443959816192,
  "in_reply_to_status_id" : 659336311665487875,
  "created_at" : "2015-10-28 11:54:31 +0000",
  "in_reply_to_screen_name" : "lsanoj",
  "in_reply_to_user_id_str" : "18918915",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc RobinsonRechavi",
      "screen_name" : "marc_rr",
      "indices" : [ 0, 8 ],
      "id_str" : "454724555",
      "id" : 454724555
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "659327010024632320",
  "geo" : { },
  "id_str" : "659327750902300672",
  "in_reply_to_user_id" : 454724555,
  "text" : "@marc_rr \u2018admit that the data around you have grown\u2019 ;)",
  "id" : 659327750902300672,
  "in_reply_to_status_id" : 659327010024632320,
  "created_at" : "2015-10-28 11:16:00 +0000",
  "in_reply_to_screen_name" : "marc_rr",
  "in_reply_to_user_id_str" : "454724555",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jan Tr\u00F6semeier",
      "screen_name" : "PiMuNu",
      "indices" : [ 0, 7 ],
      "id_str" : "86105423",
      "id" : 86105423
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "659322174805843969",
  "geo" : { },
  "id_str" : "659322395698794496",
  "in_reply_to_user_id" : 86105423,
  "text" : "@PiMuNu i think there are lots of differences between academic peer review for journals and code review. :)",
  "id" : 659322395698794496,
  "in_reply_to_status_id" : 659322174805843969,
  "created_at" : "2015-10-28 10:54:43 +0000",
  "in_reply_to_screen_name" : "PiMuNu",
  "in_reply_to_user_id_str" : "86105423",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/J2xvcFCB7L",
      "expanded_url" : "https:\/\/medium.com\/life-learning\/why-you-need-to-move-away-from-your-home-town-44a86f685035#.bf85gyckt",
      "display_url" : "medium.com\/life-learning\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "659321963253506048",
  "text" : "\u00ABLeave. Go out into the world and discover who you are. Not who you were when your imagination was limited.\u00BB https:\/\/t.co\/J2xvcFCB7L",
  "id" : 659321963253506048,
  "created_at" : "2015-10-28 10:53:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc RobinsonRechavi",
      "screen_name" : "marc_rr",
      "indices" : [ 76, 84 ],
      "id_str" : "454724555",
      "id" : 454724555
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/t1oTOx81A7",
      "expanded_url" : "http:\/\/wp.unil.ch\/sequenceagenome\/2015\/10\/27\/good-assembly-of-genomes-with-pacbio-no-difference-between-our-strains\/",
      "display_url" : "wp.unil.ch\/sequenceagenom\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "659321015902863360",
  "text" : "And I thought my Master\u2019s time was nice, sequencing a mitochondrial genome: @marc_rr does PacBio with students. https:\/\/t.co\/t1oTOx81A7",
  "id" : 659321015902863360,
  "created_at" : "2015-10-28 10:49:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Keith Bradnam",
      "screen_name" : "kbradnam",
      "indices" : [ 49, 58 ],
      "id_str" : "17061155",
      "id" : 17061155
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 82 ],
      "url" : "https:\/\/t.co\/XSUSSAirTf",
      "expanded_url" : "http:\/\/www.acgt.me\/blog\/2015\/10\/18\/we-asked-272-bioinformaticiansname-something-that-makes-you-angry-more-reflections-on-the-poor-state-of-software-documentation",
      "display_url" : "acgt.me\/blog\/2015\/10\/1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "659320411138691072",
  "text" : "The 10 point checklist for reviewing software by @kbradnam https:\/\/t.co\/XSUSSAirTf",
  "id" : 659320411138691072,
  "created_at" : "2015-10-28 10:46:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 3, 9 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/EnKe5dV1Sj",
      "expanded_url" : "https:\/\/twitter.com\/langziehohr\/status\/658984313388670976",
      "display_url" : "twitter.com\/langziehohr\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "659318144801095680",
  "text" : "RT @Lobot: Men in tech get away with looking like mad professors, women in tech obviously don't. https:\/\/t.co\/EnKe5dV1Sj",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 86, 109 ],
        "url" : "https:\/\/t.co\/EnKe5dV1Sj",
        "expanded_url" : "https:\/\/twitter.com\/langziehohr\/status\/658984313388670976",
        "display_url" : "twitter.com\/langziehohr\/st\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "659300066809749504",
    "text" : "Men in tech get away with looking like mad professors, women in tech obviously don't. https:\/\/t.co\/EnKe5dV1Sj",
    "id" : 659300066809749504,
    "created_at" : "2015-10-28 09:25:59 +0000",
    "user" : {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "protected" : false,
      "id_str" : "1492631",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/783617256173494272\/7QL2FeUx_normal.jpg",
      "id" : 1492631,
      "verified" : false
    }
  },
  "id" : 659318144801095680,
  "created_at" : "2015-10-28 10:37:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "659315657201340416",
  "geo" : { },
  "id_str" : "659315707549777920",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot largely interesting :3",
  "id" : 659315707549777920,
  "in_reply_to_status_id" : 659315657201340416,
  "created_at" : "2015-10-28 10:28:08 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fiona Nielsen",
      "screen_name" : "glyn_dk",
      "indices" : [ 76, 84 ],
      "id_str" : "32340834",
      "id" : 32340834
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HKgenome",
      "indices" : [ 18, 27 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/Ram9mxIbum",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=1Kk0a4WRiCI",
      "display_url" : "youtube.com\/watch?v=1Kk0a4\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "659314945260130304",
  "text" : "If you missed our #HKgenome evening you can see the recordings of the talks @glyn_dk, Laurent Tellier and I gave: https:\/\/t.co\/Ram9mxIbum",
  "id" : 659314945260130304,
  "created_at" : "2015-10-28 10:25:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "659311119568404480",
  "geo" : { },
  "id_str" : "659314395445620736",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot \u00ABinteresting and terrible in equal measures\u00BB? I have to disagree!",
  "id" : 659314395445620736,
  "in_reply_to_status_id" : 659311119568404480,
  "created_at" : "2015-10-28 10:22:56 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 65 ],
      "url" : "https:\/\/t.co\/YyTkNJS02y",
      "expanded_url" : "http:\/\/letterboxd.com\/foggy\/film\/penis-man-dickapitated\/",
      "display_url" : "letterboxd.com\/foggy\/film\/pen\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "659303144933994497",
  "text" : "The movies you learn about on letterboxd. https:\/\/t.co\/YyTkNJS02y",
  "id" : 659303144933994497,
  "created_at" : "2015-10-28 09:38:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MozFest",
      "indices" : [ 4, 12 ]
    } ],
    "urls" : [ {
      "indices" : [ 48, 71 ],
      "url" : "https:\/\/t.co\/2tmkPOWnUO",
      "expanded_url" : "https:\/\/www.mozillascience.org\/mozfest-2015",
      "display_url" : "mozillascience.org\/mozfest-2015"
    } ]
  },
  "geo" : { },
  "id_str" : "659300282887729153",
  "text" : "The #MozFest Open Science schedule looks great! https:\/\/t.co\/2tmkPOWnUO",
  "id" : 659300282887729153,
  "created_at" : "2015-10-28 09:26:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "659292307414491136",
  "text" : "Apparently the most pressing question for everyone in the office: \u00ABWhat did the Israeli Airport Security do to you?!\u00BB m)",
  "id" : 659292307414491136,
  "created_at" : "2015-10-28 08:55:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "laura clarke",
      "screen_name" : "laurastephen",
      "indices" : [ 0, 13 ],
      "id_str" : "20142273",
      "id" : 20142273
    }, {
      "name" : "not best practice",
      "screen_name" : "moeffju",
      "indices" : [ 14, 22 ],
      "id_str" : "5618832",
      "id" : 5618832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "659289124298469376",
  "geo" : { },
  "id_str" : "659290192965214208",
  "in_reply_to_user_id" : 20142273,
  "text" : "@laurastephen @moeffju yeah, this is how I heard about this :)",
  "id" : 659290192965214208,
  "in_reply_to_status_id" : 659289124298469376,
  "created_at" : "2015-10-28 08:46:45 +0000",
  "in_reply_to_screen_name" : "laurastephen",
  "in_reply_to_user_id_str" : "20142273",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u03B8ourkni\u02D0r\u0325",
      "screen_name" : "thorgnyr",
      "indices" : [ 3, 12 ],
      "id_str" : "38015980",
      "id" : 38015980
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "netneutrality",
      "indices" : [ 110, 124 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "659282836625731584",
  "text" : "RT @thorgnyr: Damn turds! The fact is that financial interests reign over personal freedoms almost every time.#netneutrality  https:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "netneutrality",
        "indices" : [ 96, 110 ]
      } ],
      "urls" : [ {
        "indices" : [ 112, 135 ],
        "url" : "https:\/\/t.co\/PseemOWecG",
        "expanded_url" : "https:\/\/twitter.com\/Senficon\/status\/659124055489015809",
        "display_url" : "twitter.com\/Senficon\/statu\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "659282208725868544",
    "text" : "Damn turds! The fact is that financial interests reign over personal freedoms almost every time.#netneutrality  https:\/\/t.co\/PseemOWecG",
    "id" : 659282208725868544,
    "created_at" : "2015-10-28 08:15:02 +0000",
    "user" : {
      "name" : "\u03B8ourkni\u02D0r\u0325",
      "screen_name" : "thorgnyr",
      "protected" : false,
      "id_str" : "38015980",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/447694106848817152\/3dFuiwdW_normal.jpeg",
      "id" : 38015980,
      "verified" : false
    }
  },
  "id" : 659282836625731584,
  "created_at" : "2015-10-28 08:17:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.14219220592353, 8.668808615920979 ]
  },
  "id_str" : "659281674807726080",
  "text" : "TIL: you can get Melatonin over-the-counter in the Netherlands. \\o\/",
  "id" : 659281674807726080,
  "created_at" : "2015-10-28 08:12:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/659121787473678336\/photo\/1",
      "indices" : [ 43, 66 ],
      "url" : "https:\/\/t.co\/LAHVeR1sll",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CSWrxfYWIAEdewV.jpg",
      "id_str" : "659121787205197825",
      "id" : 659121787205197825,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSWrxfYWIAEdewV.jpg",
      "sizes" : [ {
        "h" : 470,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 741,
        "resize" : "fit",
        "w" : 1893
      }, {
        "h" : 741,
        "resize" : "fit",
        "w" : 1893
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 266,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/LAHVeR1sll"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "659121787473678336",
  "text" : "From the photo backlog: Shenzhen by night. https:\/\/t.co\/LAHVeR1sll",
  "id" : 659121787473678336,
  "created_at" : "2015-10-27 21:37:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nazeefa",
      "screen_name" : "NazeefaFatima",
      "indices" : [ 3, 17 ],
      "id_str" : "37054704",
      "id" : 37054704
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "academia",
      "indices" : [ 101, 110 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "659090270894608385",
  "text" : "RT @NazeefaFatima: research  \u2192 eat &amp; drink \n     \u2191                      \u2193\ncry\/sleep \u2190  research\n\n#academia",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "academia",
        "indices" : [ 82, 91 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "659040696926666752",
    "text" : "research  \u2192 eat &amp; drink \n     \u2191                      \u2193\ncry\/sleep \u2190  research\n\n#academia",
    "id" : 659040696926666752,
    "created_at" : "2015-10-27 16:15:21 +0000",
    "user" : {
      "name" : "Nazeefa",
      "screen_name" : "NazeefaFatima",
      "protected" : false,
      "id_str" : "37054704",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/930210077885202432\/DY8D8hGM_normal.jpg",
      "id" : 37054704,
      "verified" : false
    }
  },
  "id" : 659090270894608385,
  "created_at" : "2015-10-27 19:32:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Maximilian Haack",
      "screen_name" : "coffeejunk",
      "indices" : [ 0, 11 ],
      "id_str" : "14201785",
      "id" : 14201785
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "659043731543334912",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.04249645401728, 8.56781336479687 ]
  },
  "id_str" : "659044057071644672",
  "in_reply_to_user_id" : 14201785,
  "text" : "@coffeejunk glad I\u2019m not the only freak \uD83D\uDE02\u2708\uFE0F",
  "id" : 659044057071644672,
  "in_reply_to_status_id" : 659043731543334912,
  "created_at" : "2015-10-27 16:28:42 +0000",
  "in_reply_to_screen_name" : "coffeejunk",
  "in_reply_to_user_id_str" : "14201785",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/veyPb1NfQt",
      "expanded_url" : "https:\/\/instagram.com\/p\/9WPy-ahwon\/",
      "display_url" : "instagram.com\/p\/9WPy-ahwon\/"
    } ]
  },
  "geo" : { },
  "id_str" : "659042724012797952",
  "text" : "This is still not getting old. Even after 15 flights so far this year. https:\/\/t.co\/veyPb1NfQt",
  "id" : 659042724012797952,
  "created_at" : "2015-10-27 16:23:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/P86LNvPjTX",
      "expanded_url" : "https:\/\/instagram.com\/p\/9VEVdohwmb\/",
      "display_url" : "instagram.com\/p\/9VEVdohwmb\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.075849457, 116.606143737 ]
  },
  "id_str" : "658876784121913344",
  "text" : "the transit waiting game @ Beijing Capital International Airport Terminal 3 https:\/\/t.co\/P86LNvPjTX",
  "id" : 658876784121913344,
  "created_at" : "2015-10-27 05:24:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "658874696843194368",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.07460114229729, 116.6061330920688 ]
  },
  "id_str" : "658875445274783744",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer will check it out once I\u2019m back in a non-VPN country :3",
  "id" : 658875445274783744,
  "in_reply_to_status_id" : 658874696843194368,
  "created_at" : "2015-10-27 05:18:42 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 3, 16 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "openSNP team",
      "screen_name" : "openSNPorg",
      "indices" : [ 19, 30 ],
      "id_str" : "380205172",
      "id" : 380205172
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 122, 138 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 91 ],
      "url" : "https:\/\/t.co\/Xtf2Hqx8Wi",
      "expanded_url" : "http:\/\/dna.land",
      "display_url" : "dna.land"
    }, {
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/mZ0c5xAYb2",
      "expanded_url" : "http:\/\/www.theatlantic.com\/science\/archive\/2015\/10\/crowdsourcing-site-dnaland-attracts-a-genome-a-minute-on-opening-day\/410533\/",
      "display_url" : "theatlantic.com\/science\/archiv\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "658873648674004992",
  "text" : "RT @PhilippBayer: .@openSNPorg mentioned in the Atlantic article on https:\/\/t.co\/Xtf2Hqx8Wi - https:\/\/t.co\/mZ0c5xAYb2 \ncc @gedankenstuecke \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "openSNP team",
        "screen_name" : "openSNPorg",
        "indices" : [ 1, 12 ],
        "id_str" : "380205172",
        "id" : 380205172
      }, {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 104, 120 ],
        "id_str" : "14286491",
        "id" : 14286491
      }, {
        "name" : "Helge Rausch \uD83E\uDD59",
        "screen_name" : "helgerausch",
        "indices" : [ 121, 133 ],
        "id_str" : "52747896",
        "id" : 52747896
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 50, 73 ],
        "url" : "https:\/\/t.co\/Xtf2Hqx8Wi",
        "expanded_url" : "http:\/\/dna.land",
        "display_url" : "dna.land"
      }, {
        "indices" : [ 76, 99 ],
        "url" : "https:\/\/t.co\/mZ0c5xAYb2",
        "expanded_url" : "http:\/\/www.theatlantic.com\/science\/archive\/2015\/10\/crowdsourcing-site-dnaland-attracts-a-genome-a-minute-on-opening-day\/410533\/",
        "display_url" : "theatlantic.com\/science\/archiv\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "658848104045608960",
    "text" : ".@openSNPorg mentioned in the Atlantic article on https:\/\/t.co\/Xtf2Hqx8Wi - https:\/\/t.co\/mZ0c5xAYb2 \ncc @gedankenstuecke @helgerausch",
    "id" : 658848104045608960,
    "created_at" : "2015-10-27 03:30:03 +0000",
    "user" : {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "protected" : false,
      "id_str" : "121777206",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2013711027\/IMG_1088_normal.png",
      "id" : 121777206,
      "verified" : false
    }
  },
  "id" : 658873648674004992,
  "created_at" : "2015-10-27 05:11:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "658848104045608960",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.07066177219063, 116.6073564923313 ]
  },
  "id_str" : "658873483561033728",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer nice, thanks for sharing :)",
  "id" : 658873483561033728,
  "in_reply_to_status_id" : 658848104045608960,
  "created_at" : "2015-10-27 05:10:54 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 22.3137784756973, 113.9338561256285 ]
  },
  "id_str" : "658795733055705088",
  "text" : "Goodbye Hong Kong. That was fun, we should do this more often.",
  "id" : 658795733055705088,
  "created_at" : "2015-10-27 00:01:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 22.31398970569426, 113.9337987241182 ]
  },
  "id_str" : "658793405758107648",
  "text" : "\u00ABAre the terms of service for the WiFi only in Chinese?!\u00BB\u2014\u00ABNope, you\u2019re already reading the English version\u00BB\u2014\u00ABOh, I really need my glasses\u2026\u00BB",
  "id" : 658793405758107648,
  "created_at" : "2015-10-26 23:52:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul-Olivier Dehaye",
      "screen_name" : "podehaye",
      "indices" : [ 0, 9 ],
      "id_str" : "2219841242",
      "id" : 2219841242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "658789761390387200",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 22.31375758483806, 113.9338768924836 ]
  },
  "id_str" : "658789980706246656",
  "in_reply_to_user_id" : 2219841242,
  "text" : "@podehaye thanks :)",
  "id" : 658789980706246656,
  "in_reply_to_status_id" : 658789761390387200,
  "created_at" : "2015-10-26 23:39:05 +0000",
  "in_reply_to_screen_name" : "podehaye",
  "in_reply_to_user_id_str" : "2219841242",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "658788669126393856",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 22.31372208666605, 113.9338650436219 ]
  },
  "id_str" : "658789427636932608",
  "in_reply_to_user_id" : 14286491,
  "text" : "Making new friends at airports can be so easy.",
  "id" : 658789427636932608,
  "in_reply_to_status_id" : 658788669126393856,
  "created_at" : "2015-10-26 23:36:53 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 22.31377412023907, 113.9338787071877 ]
  },
  "id_str" : "658788669126393856",
  "text" : "\u00ABCould you get me some food? I have to wait here at the wall plugs, as I\u2019m the \u2018Guardian of the Charging Phones\u2019.\u00BB",
  "id" : 658788669126393856,
  "created_at" : "2015-10-26 23:33:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul-Olivier Dehaye",
      "screen_name" : "podehaye",
      "indices" : [ 0, 9 ],
      "id_str" : "2219841242",
      "id" : 2219841242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "658787067204382720",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 22.3137582972992, 113.9339065928292 ]
  },
  "id_str" : "658787685352378368",
  "in_reply_to_user_id" : 2219841242,
  "text" : "@podehaye source? :)",
  "id" : 658787685352378368,
  "in_reply_to_status_id" : 658787067204382720,
  "created_at" : "2015-10-26 23:29:58 +0000",
  "in_reply_to_screen_name" : "podehaye",
  "in_reply_to_user_id_str" : "2219841242",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 35 ],
      "url" : "https:\/\/t.co\/mJ66asOFjj",
      "expanded_url" : "https:\/\/flic.kr\/p\/A144e6",
      "display_url" : "flic.kr\/p\/A144e6"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 22.314646, 113.933874 ]
  },
  "id_str" : "658778275330715648",
  "text" : "Lei Yue Mun https:\/\/t.co\/mJ66asOFjj",
  "id" : 658778275330715648,
  "created_at" : "2015-10-26 22:52:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 8, 31 ],
      "url" : "https:\/\/t.co\/lSocDMKllC",
      "expanded_url" : "https:\/\/instagram.com\/p\/9UQ54QBwrN\/",
      "display_url" : "instagram.com\/p\/9UQ54QBwrN\/"
    } ]
  },
  "geo" : { },
  "id_str" : "658763685196865536",
  "text" : "Leaving https:\/\/t.co\/lSocDMKllC",
  "id" : 658763685196865536,
  "created_at" : "2015-10-26 21:54:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 22.30306507843729, 114.1693176601952 ]
  },
  "id_str" : "658752040114483202",
  "text" : "Off to the airport. Going HKG \u2708\uFE0F PEK \u2708\uFE0F FRA again.",
  "id" : 658752040114483202,
  "created_at" : "2015-10-26 21:08:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 67 ],
      "url" : "https:\/\/t.co\/DfEoNeAjLu",
      "expanded_url" : "https:\/\/instagram.com\/p\/9TsYlAhwlO\/",
      "display_url" : "instagram.com\/p\/9TsYlAhwlO\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 22.30665486, 114.171575779 ]
  },
  "id_str" : "658683377273458688",
  "text" : "Roaming II @ Nathan Road, Jordan, Hong Kong https:\/\/t.co\/DfEoNeAjLu",
  "id" : 658683377273458688,
  "created_at" : "2015-10-26 16:35:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 58 ],
      "url" : "https:\/\/t.co\/sJcqkxig5t",
      "expanded_url" : "https:\/\/instagram.com\/p\/9TsBzJBwki\/",
      "display_url" : "instagram.com\/p\/9TsBzJBwki\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 22.30589, 114.16987 ]
  },
  "id_str" : "658682594394025984",
  "text" : "Roaming @ Temple Street, Hong Kong https:\/\/t.co\/sJcqkxig5t",
  "id" : 658682594394025984,
  "created_at" : "2015-10-26 16:32:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 37 ],
      "url" : "https:\/\/t.co\/Dn04uvlIEr",
      "expanded_url" : "https:\/\/instagram.com\/p\/9Tp8T2Bwgq\/",
      "display_url" : "instagram.com\/p\/9Tp8T2Bwgq\/"
    } ]
  },
  "geo" : { },
  "id_str" : "658678006559436800",
  "text" : "Electrics 101 https:\/\/t.co\/Dn04uvlIEr",
  "id" : 658678006559436800,
  "created_at" : "2015-10-26 16:14:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "658664249028419584",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 22.30761214627168, 114.1704900843223 ]
  },
  "id_str" : "658664631397916672",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot that explains your avatar ;)",
  "id" : 658664631397916672,
  "in_reply_to_status_id" : 658664249028419584,
  "created_at" : "2015-10-26 15:21:00 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "658660312099508224",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 22.30576445812487, 114.1698621706114 ]
  },
  "id_str" : "658661005627686912",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot nope, Wood. :)",
  "id" : 658661005627686912,
  "in_reply_to_status_id" : 658660312099508224,
  "created_at" : "2015-10-26 15:06:35 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrick Suen",
      "screen_name" : "patricksuen",
      "indices" : [ 0, 12 ],
      "id_str" : "52655442",
      "id" : 52655442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "658659020174065664",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 22.30314183451535, 114.1705223612266 ]
  },
  "id_str" : "658659474715099136",
  "in_reply_to_user_id" : 52655442,
  "text" : "@patricksuen oh, nice! Too bad we didn\u2019t chat then! :) I tried to keep it simple, because assume most hackers aren\u2019t too fluent in genetics",
  "id" : 658659474715099136,
  "in_reply_to_status_id" : 658659020174065664,
  "created_at" : "2015-10-26 15:00:30 +0000",
  "in_reply_to_screen_name" : "patricksuen",
  "in_reply_to_user_id_str" : "52655442",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/658658435282571264\/photo\/1",
      "indices" : [ 63, 86 ],
      "url" : "https:\/\/t.co\/rUfITd8wPU",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CSQGW2fU8AIDuUy.jpg",
      "id_str" : "658658435156733954",
      "id" : 658658435156733954,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSQGW2fU8AIDuUy.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1150,
        "resize" : "fit",
        "w" : 863
      }, {
        "h" : 1150,
        "resize" : "fit",
        "w" : 863
      }, {
        "h" : 1150,
        "resize" : "fit",
        "w" : 863
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      } ],
      "display_url" : "pic.twitter.com\/rUfITd8wPU"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 22.303248, 114.170469 ]
  },
  "id_str" : "658658435282571264",
  "text" : "What else would you do if you have a makerspace full of tools? https:\/\/t.co\/rUfITd8wPU",
  "id" : 658658435282571264,
  "created_at" : "2015-10-26 14:56:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 35 ],
      "url" : "https:\/\/t.co\/62nquZ2H2N",
      "expanded_url" : "https:\/\/instagram.com\/p\/9TgbbZBwu2\/",
      "display_url" : "instagram.com\/p\/9TgbbZBwu2\/"
    } ]
  },
  "geo" : { },
  "id_str" : "658657086587408384",
  "text" : "Floating II https:\/\/t.co\/62nquZ2H2N",
  "id" : 658657086587408384,
  "created_at" : "2015-10-26 14:51:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MakerBay",
      "screen_name" : "MakerBay",
      "indices" : [ 7, 16 ],
      "id_str" : "2917700821",
      "id" : 2917700821
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 22.30327538860399, 114.1704712367568 ]
  },
  "id_str" : "658656125621932032",
  "text" : "Thanks @MakerBay for hosting us. It\u2019s a lovely space!",
  "id" : 658656125621932032,
  "created_at" : "2015-10-26 14:47:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrick Suen",
      "screen_name" : "patricksuen",
      "indices" : [ 0, 12 ],
      "id_str" : "52655442",
      "id" : 52655442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "658600886353027072",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 22.30327538860399, 114.1704712367568 ]
  },
  "id_str" : "658655919459274752",
  "in_reply_to_user_id" : 52655442,
  "text" : "@patricksuen great you where there. Thanks for dropping by! :)",
  "id" : 658655919459274752,
  "in_reply_to_status_id" : 658600886353027072,
  "created_at" : "2015-10-26 14:46:23 +0000",
  "in_reply_to_screen_name" : "patricksuen",
  "in_reply_to_user_id_str" : "52655442",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 58 ],
      "url" : "https:\/\/t.co\/BDZ70r0033",
      "expanded_url" : "https:\/\/twitter.com\/glyn_dk\/status\/658625700035858432",
      "display_url" : "twitter.com\/glyn_dk\/status\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 22.29438730289122, 114.2348252716678 ]
  },
  "id_str" : "658638667741663233",
  "text" : "A near miss event in three slides. https:\/\/t.co\/BDZ70r0033",
  "id" : 658638667741663233,
  "created_at" : "2015-10-26 13:37:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 64 ],
      "url" : "https:\/\/t.co\/Ny0V3e50mi",
      "expanded_url" : "https:\/\/instagram.com\/p\/9TMhMvBwsF\/",
      "display_url" : "instagram.com\/p\/9TMhMvBwsF\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 22.291122594, 114.238245907 ]
  },
  "id_str" : "658613304441634816",
  "text" : "Floating @ Lei Yue Mun Fisherman Village https:\/\/t.co\/Ny0V3e50mi",
  "id" : 658613304441634816,
  "created_at" : "2015-10-26 11:57:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Repositive.io",
      "screen_name" : "repositiveio",
      "indices" : [ 54, 67 ],
      "id_str" : "3059929578",
      "id" : 3059929578
    }, {
      "name" : "GigaScience",
      "screen_name" : "GigaScience",
      "indices" : [ 72, 84 ],
      "id_str" : "208988759",
      "id" : 208988759
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HKgenome",
      "indices" : [ 108, 117 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 22.29236237954866, 114.2378473249069 ]
  },
  "id_str" : "658581305542746112",
  "text" : "That was a lovely workshop, I learned so much. Thanks @repositiveio and @GigaScience for the collaboration! #HKgenome",
  "id" : 658581305542746112,
  "created_at" : "2015-10-26 09:49:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 62 ],
      "url" : "https:\/\/t.co\/6vaLYSj3R0",
      "expanded_url" : "https:\/\/twitter.com\/glyn_dk\/status\/658578803266973696",
      "display_url" : "twitter.com\/glyn_dk\/status\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 22.29311115136947, 114.2373396200882 ]
  },
  "id_str" : "658580360419233792",
  "text" : "Doing science (aka downloading photos) https:\/\/t.co\/6vaLYSj3R0",
  "id" : 658580360419233792,
  "created_at" : "2015-10-26 09:46:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GigaScience",
      "screen_name" : "GigaScience",
      "indices" : [ 0, 12 ],
      "id_str" : "208988759",
      "id" : 208988759
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "658559093980852224",
  "geo" : { },
  "id_str" : "658576834494251008",
  "in_reply_to_user_id" : 208988759,
  "text" : "@GigaScience i read this in Oprahs voice and was internally screaming \u201Ebees!\u201C",
  "id" : 658576834494251008,
  "in_reply_to_status_id" : 658559093980852224,
  "created_at" : "2015-10-26 09:32:07 +0000",
  "in_reply_to_screen_name" : "GigaScience",
  "in_reply_to_user_id_str" : "208988759",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HKgenome",
      "indices" : [ 85, 94 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "658572415249723392",
  "text" : "I\u2019m still always amazed when openSNP is loading and even usable during live demos. \uD83D\uDE02 #HKgenome",
  "id" : 658572415249723392,
  "created_at" : "2015-10-26 09:14:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Open Data Hong Kong",
      "screen_name" : "opendata_hk",
      "indices" : [ 3, 15 ],
      "id_str" : "1255061316",
      "id" : 1255061316
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 63, 79 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "opendata",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "658570991665221632",
  "text" : "RT @opendata_hk: Teaching us about the frontline of #opendata, @gedankenstuecke with a hands on demo on crowdsourced genomics data https:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 46, 62 ],
        "id_str" : "14286491",
        "id" : 14286491
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/opendata_hk\/status\/658557055490531328\/photo\/1",
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/3NNtSWtbLV",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CSOqI8WUsAAT67a.jpg",
        "id_str" : "658557041141657600",
        "id" : 658557041141657600,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSOqI8WUsAAT67a.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/3NNtSWtbLV"
      } ],
      "hashtags" : [ {
        "text" : "opendata",
        "indices" : [ 35, 44 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "658557055490531328",
    "text" : "Teaching us about the frontline of #opendata, @gedankenstuecke with a hands on demo on crowdsourced genomics data https:\/\/t.co\/3NNtSWtbLV",
    "id" : 658557055490531328,
    "created_at" : "2015-10-26 08:13:32 +0000",
    "user" : {
      "name" : "Open Data Hong Kong",
      "screen_name" : "opendata_hk",
      "protected" : false,
      "id_str" : "1255061316",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464607838971494400\/3-L5y1ZT_normal.png",
      "id" : 1255061316,
      "verified" : false
    }
  },
  "id" : 658570991665221632,
  "created_at" : "2015-10-26 09:08:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "658564317542002688",
  "geo" : { },
  "id_str" : "658569534429773824",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot yep, totally worth the taste of colonialism.",
  "id" : 658569534429773824,
  "in_reply_to_status_id" : 658564317542002688,
  "created_at" : "2015-10-26 09:03:07 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GigaScience",
      "screen_name" : "GigaScience",
      "indices" : [ 3, 15 ],
      "id_str" : "208988759",
      "id" : 208988759
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 34, 50 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "658569443010744320",
  "text" : "RT @GigaScience: In the demo from @gedankenstuecke on OpenSNP already found 5x more people with perfect pitch than the researcher asking ab\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 17, 33 ],
        "id_str" : "14286491",
        "id" : 14286491
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "hkgenome",
        "indices" : [ 129, 138 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "658557607372713984",
    "text" : "In the demo from @gedankenstuecke on OpenSNP already found 5x more people with perfect pitch than the researcher asking about it #hkgenome",
    "id" : 658557607372713984,
    "created_at" : "2015-10-26 08:15:43 +0000",
    "user" : {
      "name" : "GigaScience",
      "screen_name" : "GigaScience",
      "protected" : false,
      "id_str" : "208988759",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1404305552\/profile-photo-GigaScience-96x96_normal.jpg",
      "id" : 208988759,
      "verified" : false
    }
  },
  "id" : 658569443010744320,
  "created_at" : "2015-10-26 09:02:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/658549588941406208\/photo\/1",
      "indices" : [ 30, 53 ],
      "url" : "https:\/\/t.co\/uiZPiMw7kV",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CSOjXKOUEAAAvkw.jpg",
      "id_str" : "658549588802932736",
      "id" : 658549588802932736,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSOjXKOUEAAAvkw.jpg",
      "sizes" : [ {
        "h" : 990,
        "resize" : "fit",
        "w" : 990
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 990,
        "resize" : "fit",
        "w" : 990
      }, {
        "h" : 990,
        "resize" : "fit",
        "w" : 990
      } ],
      "display_url" : "pic.twitter.com\/uiZPiMw7kV"
    } ],
    "hashtags" : [ {
      "text" : "HKgenome",
      "indices" : [ 20, 29 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 22.294446, 114.2348 ]
  },
  "id_str" : "658549588941406208",
  "text" : "Sailing at MakerBay #HKgenome https:\/\/t.co\/uiZPiMw7kV",
  "id" : 658549588941406208,
  "created_at" : "2015-10-26 07:43:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 73 ],
      "url" : "https:\/\/t.co\/cPUdKOBsnA",
      "expanded_url" : "https:\/\/instagram.com\/p\/9SlxSHBwq0\/",
      "display_url" : "instagram.com\/p\/9SlxSHBwq0\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 22.30665486, 114.171575779 ]
  },
  "id_str" : "658528094559580160",
  "text" : "room with a view @ Nathan Road, Jordan, Hong Kong https:\/\/t.co\/cPUdKOBsnA",
  "id" : 658528094559580160,
  "created_at" : "2015-10-26 06:18:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HKgenome",
      "indices" : [ 77, 86 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 22.2943604383941, 114.234845886133 ]
  },
  "id_str" : "658477060810141696",
  "text" : "Pro-Tip #1: involve a statistician from the start when designing your study. #HKgenome",
  "id" : 658477060810141696,
  "created_at" : "2015-10-26 02:55:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fiona Nielsen",
      "screen_name" : "glyn_dk",
      "indices" : [ 4, 12 ],
      "id_str" : "32340834",
      "id" : 32340834
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/658473636706127873\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/GtKagdQmMm",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CSNeSBMUEAAZFEL.jpg",
      "id_str" : "658473634176962560",
      "id" : 658473634176962560,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSNeSBMUEAAZFEL.jpg",
      "sizes" : [ {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 2448,
        "resize" : "fit",
        "w" : 3264
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/GtKagdQmMm"
    } ],
    "hashtags" : [ {
      "text" : "HKgenome",
      "indices" : [ 25, 34 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 22.29437174529583, 114.2348445247339 ]
  },
  "id_str" : "658473636706127873",
  "text" : "Now @glyn_dk kicking off #HKgenome: \u00ABYou never have enough statistical power, regardless of how much data you have\u00BB https:\/\/t.co\/GtKagdQmMm",
  "id" : 658473636706127873,
  "created_at" : "2015-10-26 02:42:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 42 ],
      "url" : "https:\/\/t.co\/UXiFVy4JW9",
      "expanded_url" : "https:\/\/flic.kr\/p\/zXQfLG",
      "display_url" : "flic.kr\/p\/zXQfLG"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 22.294703, 114.23646 ]
  },
  "id_str" : "658468166436155393",
  "text" : "View from Yau Tong https:\/\/t.co\/UXiFVy4JW9",
  "id" : 658468166436155393,
  "created_at" : "2015-10-26 02:20:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GigaScience",
      "screen_name" : "GigaScience",
      "indices" : [ 3, 15 ],
      "id_str" : "208988759",
      "id" : 208988759
    }, {
      "name" : "Repositive.io",
      "screen_name" : "repositiveio",
      "indices" : [ 55, 68 ],
      "id_str" : "3059929578",
      "id" : 3059929578
    }, {
      "name" : "openSNP team",
      "screen_name" : "openSNPorg",
      "indices" : [ 75, 86 ],
      "id_str" : "380205172",
      "id" : 380205172
    }, {
      "name" : "MakerBay",
      "screen_name" : "MakerBay",
      "indices" : [ 112, 121 ],
      "id_str" : "2917700821",
      "id" : 2917700821
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hackathon",
      "indices" : [ 39, 49 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "658465373214240768",
  "text" : "RT @GigaScience: Our human genome data #hackathon with @repositiveio &amp; @openSNPorg starting shortly here at @MakerBay https:\/\/t.co\/7b4WI6Gx\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Repositive.io",
        "screen_name" : "repositiveio",
        "indices" : [ 38, 51 ],
        "id_str" : "3059929578",
        "id" : 3059929578
      }, {
        "name" : "openSNP team",
        "screen_name" : "openSNPorg",
        "indices" : [ 58, 69 ],
        "id_str" : "380205172",
        "id" : 380205172
      }, {
        "name" : "MakerBay",
        "screen_name" : "MakerBay",
        "indices" : [ 95, 104 ],
        "id_str" : "2917700821",
        "id" : 2917700821
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/GigaScience\/status\/658462293504557056\/photo\/1",
        "indices" : [ 105, 128 ],
        "url" : "https:\/\/t.co\/7b4WI6Gx0g",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CSNT8_AUYAASe6D.jpg",
        "id_str" : "658462277696249856",
        "id" : 658462277696249856,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSNT8_AUYAASe6D.jpg",
        "sizes" : [ {
          "h" : 680,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/7b4WI6Gx0g"
      } ],
      "hashtags" : [ {
        "text" : "hackathon",
        "indices" : [ 22, 32 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "658462293504557056",
    "text" : "Our human genome data #hackathon with @repositiveio &amp; @openSNPorg starting shortly here at @MakerBay https:\/\/t.co\/7b4WI6Gx0g",
    "id" : 658462293504557056,
    "created_at" : "2015-10-26 01:56:59 +0000",
    "user" : {
      "name" : "GigaScience",
      "screen_name" : "GigaScience",
      "protected" : false,
      "id_str" : "208988759",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1404305552\/profile-photo-GigaScience-96x96_normal.jpg",
      "id" : 208988759,
      "verified" : false
    }
  },
  "id" : 658465373214240768,
  "created_at" : "2015-10-26 02:09:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/cxOAvTsjh3",
      "expanded_url" : "http:\/\/www.theatlantic.com\/health\/archive\/2014\/10\/the-cold-logic-of-drunk-people\/381908\/?utm_source=SFFB",
      "display_url" : "theatlantic.com\/health\/archive\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "658342225881862144",
  "text" : "\u00ABUtilitarian or no, the inebriated may be the philosophy researcher's dream.\u00BB The same is true for being inebriated. https:\/\/t.co\/cxOAvTsjh3",
  "id" : 658342225881862144,
  "created_at" : "2015-10-25 17:59:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 77 ],
      "url" : "https:\/\/t.co\/Qjuoi3hdTj",
      "expanded_url" : "https:\/\/flic.kr\/p\/zhigpC",
      "display_url" : "flic.kr\/p\/zhigpC"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 22.303216, 114.170584 ]
  },
  "id_str" : "658324811727265792",
  "text" : "Shenzhen from the 40th floor of the Shangri-La hotel. https:\/\/t.co\/Qjuoi3hdTj",
  "id" : 658324811727265792,
  "created_at" : "2015-10-25 16:50:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 47 ],
      "url" : "https:\/\/t.co\/jAzFjoFy7C",
      "expanded_url" : "https:\/\/flic.kr\/p\/zhg1Wo",
      "display_url" : "flic.kr\/p\/zhg1Wo"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 22.303275, 114.170568 ]
  },
  "id_str" : "658320201423843328",
  "text" : "China National Genebank https:\/\/t.co\/jAzFjoFy7C",
  "id" : 658320201423843328,
  "created_at" : "2015-10-25 16:32:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emanuel Wyler",
      "screen_name" : "ewyler",
      "indices" : [ 0, 7 ],
      "id_str" : "122329006",
      "id" : 122329006
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "658308769278001152",
  "geo" : { },
  "id_str" : "658308976581324800",
  "in_reply_to_user_id" : 122329006,
  "text" : "@ewyler oh, another fan of the word? :D",
  "id" : 658308976581324800,
  "in_reply_to_status_id" : 658308769278001152,
  "created_at" : "2015-10-25 15:47:45 +0000",
  "in_reply_to_screen_name" : "ewyler",
  "in_reply_to_user_id_str" : "122329006",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/OyLgHqFUfl",
      "expanded_url" : "http:\/\/www.haaretz.com\/jewish\/jewish-world-opinions\/.premium-1.680190",
      "display_url" : "haaretz.com\/jewish\/jewish-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "658298288718786560",
  "text" : "\u00ABOn the right, a device that might save your life. On the left, a device that might save your soul\u00BB https:\/\/t.co\/OyLgHqFUfl",
  "id" : 658298288718786560,
  "created_at" : "2015-10-25 15:05:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/658296614830780417\/photo\/1",
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/cMBqbs241Y",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CSK9R7hUcAEGImd.jpg",
      "id_str" : "658296611282382849",
      "id" : 658296611282382849,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSK9R7hUcAEGImd.jpg",
      "sizes" : [ {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 3264,
        "resize" : "fit",
        "w" : 2448
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      } ],
      "display_url" : "pic.twitter.com\/cMBqbs241Y"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 22.30323152209984, 114.1705462845053 ]
  },
  "id_str" : "658296614830780417",
  "text" : "Having my first British Christmas Pudding in Hong Kong. Lest you think Imperialism is dead. https:\/\/t.co\/cMBqbs241Y",
  "id" : 658296614830780417,
  "created_at" : "2015-10-25 14:58:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Schawinski",
      "screen_name" : "kevinschawinski",
      "indices" : [ 0, 16 ],
      "id_str" : "242844365",
      "id" : 242844365
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "658295021016363008",
  "geo" : { },
  "id_str" : "658295319877148672",
  "in_reply_to_user_id" : 242844365,
  "text" : "@kevinschawinski or I\u2019ll just come down to Zurich again ;)",
  "id" : 658295319877148672,
  "in_reply_to_status_id" : 658295021016363008,
  "created_at" : "2015-10-25 14:53:29 +0000",
  "in_reply_to_screen_name" : "kevinschawinski",
  "in_reply_to_user_id_str" : "242844365",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Schawinski",
      "screen_name" : "kevinschawinski",
      "indices" : [ 0, 16 ],
      "id_str" : "242844365",
      "id" : 242844365
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "658294115331887104",
  "geo" : { },
  "id_str" : "658294385105219584",
  "in_reply_to_user_id" : 242844365,
  "text" : "@kevinschawinski unfortunately I was in Shenzhen until 6pm, otherwise we could have met up. Well, next time :)",
  "id" : 658294385105219584,
  "in_reply_to_status_id" : 658294115331887104,
  "created_at" : "2015-10-25 14:49:46 +0000",
  "in_reply_to_screen_name" : "kevinschawinski",
  "in_reply_to_user_id_str" : "242844365",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Schawinski",
      "screen_name" : "kevinschawinski",
      "indices" : [ 0, 16 ],
      "id_str" : "242844365",
      "id" : 242844365
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "658294115331887104",
  "geo" : { },
  "id_str" : "658294219451199488",
  "in_reply_to_user_id" : 242844365,
  "text" : "@kevinschawinski ouch, that sucks!",
  "id" : 658294219451199488,
  "in_reply_to_status_id" : 658294115331887104,
  "created_at" : "2015-10-25 14:49:07 +0000",
  "in_reply_to_screen_name" : "kevinschawinski",
  "in_reply_to_user_id_str" : "242844365",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Schawinski",
      "screen_name" : "kevinschawinski",
      "indices" : [ 0, 16 ],
      "id_str" : "242844365",
      "id" : 242844365
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "658293772879601665",
  "geo" : { },
  "id_str" : "658293927544393728",
  "in_reply_to_user_id" : 242844365,
  "text" : "@kevinschawinski did we barely miss? because I already came through on Friday.",
  "id" : 658293927544393728,
  "in_reply_to_status_id" : 658293772879601665,
  "created_at" : "2015-10-25 14:47:57 +0000",
  "in_reply_to_screen_name" : "kevinschawinski",
  "in_reply_to_user_id_str" : "242844365",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 40 ],
      "url" : "https:\/\/t.co\/xJwAmnbMKW",
      "expanded_url" : "https:\/\/instagram.com\/p\/9Q7DXuBwoq\/",
      "display_url" : "instagram.com\/p\/9Q7DXuBwoq\/"
    } ]
  },
  "geo" : { },
  "id_str" : "658293420868411392",
  "text" : "Hello Hong Kong! https:\/\/t.co\/xJwAmnbMKW",
  "id" : 658293420868411392,
  "created_at" : "2015-10-25 14:45:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 22.30320987965694, 114.1705829826391 ]
  },
  "id_str" : "658257138800721920",
  "text" : "Fun fact: the walkable wardrobe of the hotel room in Shenzhen is larger than the bathroom of the AirBnB in Hong Kong.",
  "id" : 658257138800721920,
  "created_at" : "2015-10-25 12:21:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 22.50588927354692, 113.9445178153167 ]
  },
  "id_str" : "658238615206498304",
  "text" : "No conference should end without being interviewed by Dr. Shawarma\u2019s \u2018Telepathic Orgasm\u2019 Tag Team\u2026",
  "id" : 658238615206498304,
  "created_at" : "2015-10-25 11:08:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/Tkhfq14ozJ",
      "expanded_url" : "https:\/\/twitter.com\/GigaScience\/status\/658174137999990784",
      "display_url" : "twitter.com\/GigaScience\/st\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 22.53564750234809, 114.0486794458388 ]
  },
  "id_str" : "658186084375916545",
  "text" : "Looking forward to see whether tipsy test confirms the 23andMe results. Also: me trying to read Chinese. https:\/\/t.co\/Tkhfq14ozJ",
  "id" : 658186084375916545,
  "created_at" : "2015-10-25 07:39:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ICG10",
      "indices" : [ 127, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 22.53863575401715, 114.0515647920221 ]
  },
  "id_str" : "658156491199811585",
  "text" : "HL: investigate chromosome evolution, see whether rearrangement rates differ between lineages &amp; clustering of breakpoints. #ICG10",
  "id" : 658156491199811585,
  "created_at" : "2015-10-25 05:41:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ICG10",
      "indices" : [ 69, 75 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 22.53863575401715, 114.0515647920221 ]
  },
  "id_str" : "658155630234984448",
  "text" : "Now: Harris Lewin on Reconstructing Ancestral Mammalian Chromosomes. #ICG10",
  "id" : 658155630234984448,
  "created_at" : "2015-10-25 05:38:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GigaScience",
      "screen_name" : "GigaScience",
      "indices" : [ 3, 15 ],
      "id_str" : "208988759",
      "id" : 208988759
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 85 ],
      "url" : "https:\/\/t.co\/tkC4oJoekb",
      "expanded_url" : "https:\/\/twitter.com\/DaleYuzuki\/status\/658079546168602624",
      "display_url" : "twitter.com\/DaleYuzuki\/sta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "658153573293789184",
  "text" : "RT @GigaScience: Nice post on the BGISEQ-500 launch yesterday https:\/\/t.co\/tkC4oJoekb",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 45, 68 ],
        "url" : "https:\/\/t.co\/tkC4oJoekb",
        "expanded_url" : "https:\/\/twitter.com\/DaleYuzuki\/status\/658079546168602624",
        "display_url" : "twitter.com\/DaleYuzuki\/sta\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "658151652713766912",
    "text" : "Nice post on the BGISEQ-500 launch yesterday https:\/\/t.co\/tkC4oJoekb",
    "id" : 658151652713766912,
    "created_at" : "2015-10-25 05:22:36 +0000",
    "user" : {
      "name" : "GigaScience",
      "screen_name" : "GigaScience",
      "protected" : false,
      "id_str" : "208988759",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1404305552\/profile-photo-GigaScience-96x96_normal.jpg",
      "id" : 208988759,
      "verified" : false
    }
  },
  "id" : 658153573293789184,
  "created_at" : "2015-10-25 05:30:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "beau",
      "screen_name" : "beaugunderson",
      "indices" : [ 0, 14 ],
      "id_str" : "5746882",
      "id" : 5746882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "658150039001239552",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 22.53855917020604, 114.0519807606263 ]
  },
  "id_str" : "658152938456506368",
  "in_reply_to_user_id" : 5746882,
  "text" : "@beaugunderson same here.",
  "id" : 658152938456506368,
  "in_reply_to_status_id" : 658150039001239552,
  "created_at" : "2015-10-25 05:27:43 +0000",
  "in_reply_to_screen_name" : "beaugunderson",
  "in_reply_to_user_id_str" : "5746882",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "beau",
      "screen_name" : "beaugunderson",
      "indices" : [ 0, 14 ],
      "id_str" : "5746882",
      "id" : 5746882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "658149468156506113",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 22.53937084821288, 114.0516612975076 ]
  },
  "id_str" : "658149914862481408",
  "in_reply_to_user_id" : 5746882,
  "text" : "@beaugunderson i want to avoid the confusion of turning on my phone after arrival and having no clue what my timeline is discussing.",
  "id" : 658149914862481408,
  "in_reply_to_status_id" : 658149468156506113,
  "created_at" : "2015-10-25 05:15:42 +0000",
  "in_reply_to_screen_name" : "beaugunderson",
  "in_reply_to_user_id_str" : "5746882",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "beau",
      "screen_name" : "beaugunderson",
      "indices" : [ 0, 14 ],
      "id_str" : "5746882",
      "id" : 5746882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "658146049270247424",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 22.53934071477917, 114.0516512774535 ]
  },
  "id_str" : "658149250501509120",
  "in_reply_to_user_id" : 5746882,
  "text" : "@beaugunderson I want this! Would be so useful to catch up after long flights.",
  "id" : 658149250501509120,
  "in_reply_to_status_id" : 658146049270247424,
  "created_at" : "2015-10-25 05:13:03 +0000",
  "in_reply_to_screen_name" : "beaugunderson",
  "in_reply_to_user_id_str" : "5746882",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alice Sheppard",
      "screen_name" : "PenguinGalaxy",
      "indices" : [ 0, 14 ],
      "id_str" : "20635230",
      "id" : 20635230
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "658110988177285120",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 22.53928170117717, 114.0515950478311 ]
  },
  "id_str" : "658112524718440448",
  "in_reply_to_user_id" : 20635230,
  "text" : "@PenguinGalaxy it\u2019s just split. For a total of 6h. But Friday is just missing ;) (btw Mi==Wed :))",
  "id" : 658112524718440448,
  "in_reply_to_status_id" : 658110988177285120,
  "created_at" : "2015-10-25 02:47:07 +0000",
  "in_reply_to_screen_name" : "PenguinGalaxy",
  "in_reply_to_user_id_str" : "20635230",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/658110706894569472\/photo\/1",
      "indices" : [ 46, 69 ],
      "url" : "https:\/\/t.co\/8rwX6IpSIZ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CSIULq4UsAAgIJY.png",
      "id_str" : "658110686271156224",
      "id" : 658110686271156224,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSIULq4UsAAgIJY.png",
      "sizes" : [ {
        "h" : 1334,
        "resize" : "fit",
        "w" : 750
      }, {
        "h" : 1334,
        "resize" : "fit",
        "w" : 750
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 382
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 675
      } ],
      "display_url" : "pic.twitter.com\/8rwX6IpSIZ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 22.53932247721911, 114.0517225644168 ]
  },
  "id_str" : "658110706894569472",
  "text" : "Also: let\u2019s talk messed up circadian rhythms. https:\/\/t.co\/8rwX6IpSIZ",
  "id" : 658110706894569472,
  "created_at" : "2015-10-25 02:39:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 79 ],
      "url" : "https:\/\/t.co\/Pn1K8sA4GQ",
      "expanded_url" : "https:\/\/instagram.com\/p\/9PnAaUBwvn\/",
      "display_url" : "instagram.com\/p\/9PnAaUBwvn\/"
    } ]
  },
  "geo" : { },
  "id_str" : "658108601135988736",
  "text" : "It's not the beach, but also a nice view to wake up to. https:\/\/t.co\/Pn1K8sA4GQ",
  "id" : 658108601135988736,
  "created_at" : "2015-10-25 02:31:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Albert Vilella",
      "screen_name" : "AlbertVilella",
      "indices" : [ 0, 14 ],
      "id_str" : "635567256",
      "id" : 635567256
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "657977219411759104",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 22.53930775162335, 114.051638432494 ]
  },
  "id_str" : "657986711213834240",
  "in_reply_to_user_id" : 635567256,
  "text" : "@AlbertVilella i  don\u2019t know, missed the announcement.",
  "id" : 657986711213834240,
  "in_reply_to_status_id" : 657977219411759104,
  "created_at" : "2015-10-24 18:27:11 +0000",
  "in_reply_to_screen_name" : "AlbertVilella",
  "in_reply_to_user_id_str" : "635567256",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 22.53655576105496, 114.0497536055126 ]
  },
  "id_str" : "657955992295092225",
  "text" : "\u00ABBut these are supposed to be healthy cigarettes! They even have Native Americans as their logo!\u00BB \u2014 \u00ABWell, how many are left of them?\u00BB",
  "id" : 657955992295092225,
  "created_at" : "2015-10-24 16:25:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 22.53650314703901, 114.0497449125831 ]
  },
  "id_str" : "657954863083573248",
  "text" : "\u00ABWelcome to the international competition of drinking games!\u00BB",
  "id" : 657954863083573248,
  "created_at" : "2015-10-24 16:20:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 22.53652330604301, 114.0497847549224 ]
  },
  "id_str" : "657932721906425856",
  "text" : "Traveling 10k km to hear lectures about German beer. m)",
  "id" : 657932721906425856,
  "created_at" : "2015-10-24 14:52:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nyborg",
      "screen_name" : "ny_borg",
      "indices" : [ 0, 8 ],
      "id_str" : "570156398",
      "id" : 570156398
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "657907168268689409",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 22.53906367768214, 114.0526830760039 ]
  },
  "id_str" : "657907915165077504",
  "in_reply_to_user_id" : 570156398,
  "text" : "@ny_borg badumts!",
  "id" : 657907915165077504,
  "in_reply_to_status_id" : 657907168268689409,
  "created_at" : "2015-10-24 13:14:04 +0000",
  "in_reply_to_screen_name" : "ny_borg",
  "in_reply_to_user_id_str" : "570156398",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nyborg",
      "screen_name" : "ny_borg",
      "indices" : [ 0, 8 ],
      "id_str" : "570156398",
      "id" : 570156398
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "657906324802547713",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 22.53905379995037, 114.0526628413283 ]
  },
  "id_str" : "657907004166443008",
  "in_reply_to_user_id" : 570156398,
  "text" : "@ny_borg all because I\u2019m visiting?",
  "id" : 657907004166443008,
  "in_reply_to_status_id" : 657906324802547713,
  "created_at" : "2015-10-24 13:10:27 +0000",
  "in_reply_to_screen_name" : "ny_borg",
  "in_reply_to_user_id_str" : "570156398",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kit Stubbs, Ph.D.",
      "screen_name" : "vortacist",
      "indices" : [ 0, 10 ],
      "id_str" : "347340056",
      "id" : 347340056
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "657898124325842945",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 22.53905379995037, 114.0526628413283 ]
  },
  "id_str" : "657906974764371972",
  "in_reply_to_user_id" : 347340056,
  "text" : "@vortacist seed pods. Now you can make even more fun of them ;)",
  "id" : 657906974764371972,
  "in_reply_to_status_id" : 657898124325842945,
  "created_at" : "2015-10-24 13:10:20 +0000",
  "in_reply_to_screen_name" : "vortacist",
  "in_reply_to_user_id_str" : "347340056",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 76 ],
      "url" : "https:\/\/t.co\/UK0uy4bnNI",
      "expanded_url" : "https:\/\/instagram.com\/p\/9OG_2YBws1\/",
      "display_url" : "instagram.com\/p\/9OG_2YBws1\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 22.5925138, 114.26376337 ]
  },
  "id_str" : "657897475085324288",
  "text" : "intercultural communication gone wrong @ BGI College https:\/\/t.co\/UK0uy4bnNI",
  "id" : 657897475085324288,
  "created_at" : "2015-10-24 12:32:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 39 ],
      "url" : "https:\/\/t.co\/nzcVaCvGNo",
      "expanded_url" : "https:\/\/instagram.com\/p\/9OAKYIBwhk\/",
      "display_url" : "instagram.com\/p\/9OAKYIBwhk\/"
    } ]
  },
  "geo" : { },
  "id_str" : "657882442360094720",
  "text" : "who needs SUVs? https:\/\/t.co\/nzcVaCvGNo",
  "id" : 657882442360094720,
  "created_at" : "2015-10-24 11:32:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 55 ],
      "url" : "https:\/\/t.co\/BIIYnzipir",
      "expanded_url" : "https:\/\/instagram.com\/p\/9N8ThNBwqy\/",
      "display_url" : "instagram.com\/p\/9N8ThNBwqy\/"
    } ]
  },
  "geo" : { },
  "id_str" : "657873963251597312",
  "text" : "National Genebank in the making https:\/\/t.co\/BIIYnzipir",
  "id" : 657873963251597312,
  "created_at" : "2015-10-24 10:59:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GigaScience",
      "screen_name" : "GigaScience",
      "indices" : [ 3, 15 ],
      "id_str" : "208988759",
      "id" : 208988759
    }, {
      "name" : "Fay-Wei Li",
      "screen_name" : "fern_way",
      "indices" : [ 32, 41 ],
      "id_str" : "2188625971",
      "id" : 2188625971
    }, {
      "name" : "Holly Ganz",
      "screen_name" : "hollyhganz",
      "indices" : [ 42, 53 ],
      "id_str" : "23547345",
      "id" : 23547345
    }, {
      "name" : "Mesude Bicak",
      "screen_name" : "MesudeBicak",
      "indices" : [ 54, 66 ],
      "id_str" : "381436537",
      "id" : 381436537
    }, {
      "name" : "Fiona Nielsen",
      "screen_name" : "glyn_dk",
      "indices" : [ 67, 75 ],
      "id_str" : "32340834",
      "id" : 32340834
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 76, 92 ],
      "id_str" : "14286491",
      "id" : 14286491
    }, {
      "name" : "Hallam Stevens",
      "screen_name" : "hallam_stevens",
      "indices" : [ 99, 114 ],
      "id_str" : "572324513",
      "id" : 572324513
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "657859256016744449",
  "text" : "RT @GigaScience: Thanks so much @fern_way @hollyhganz @MesudeBicak @glyn_dk @gedankenstuecke &amp; @hallam_stevens for a brilliant &amp; inspiring \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Fay-Wei Li",
        "screen_name" : "fern_way",
        "indices" : [ 15, 24 ],
        "id_str" : "2188625971",
        "id" : 2188625971
      }, {
        "name" : "Holly Ganz",
        "screen_name" : "hollyhganz",
        "indices" : [ 25, 36 ],
        "id_str" : "23547345",
        "id" : 23547345
      }, {
        "name" : "Mesude Bicak",
        "screen_name" : "MesudeBicak",
        "indices" : [ 37, 49 ],
        "id_str" : "381436537",
        "id" : 381436537
      }, {
        "name" : "Fiona Nielsen",
        "screen_name" : "glyn_dk",
        "indices" : [ 50, 58 ],
        "id_str" : "32340834",
        "id" : 32340834
      }, {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 59, 75 ],
        "id_str" : "14286491",
        "id" : 14286491
      }, {
        "name" : "Hallam Stevens",
        "screen_name" : "hallam_stevens",
        "indices" : [ 82, 97 ],
        "id_str" : "572324513",
        "id" : 572324513
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ICG10",
        "indices" : [ 141, 147 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "657856311275687936",
    "geo" : { },
    "id_str" : "657856987208790016",
    "in_reply_to_user_id" : 208988759,
    "text" : "Thanks so much @fern_way @hollyhganz @MesudeBicak @glyn_dk @gedankenstuecke &amp; @hallam_stevens for a brilliant &amp; inspiring session at #ICG10",
    "id" : 657856987208790016,
    "in_reply_to_status_id" : 657856311275687936,
    "created_at" : "2015-10-24 09:51:42 +0000",
    "in_reply_to_screen_name" : "GigaScience",
    "in_reply_to_user_id_str" : "208988759",
    "user" : {
      "name" : "GigaScience",
      "screen_name" : "GigaScience",
      "protected" : false,
      "id_str" : "208988759",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1404305552\/profile-photo-GigaScience-96x96_normal.jpg",
      "id" : 208988759,
      "verified" : false
    }
  },
  "id" : 657859256016744449,
  "created_at" : "2015-10-24 10:00:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 22.59309706368279, 114.262654934403 ]
  },
  "id_str" : "657843904520175616",
  "text" : "The bus driver blasts the Chinese equivalent to the Scorpions.",
  "id" : 657843904520175616,
  "created_at" : "2015-10-24 08:59:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "657775219721920513",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 22.58079208182475, 114.4566819330349 ]
  },
  "id_str" : "657810464059973632",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer thanks!",
  "id" : 657810464059973632,
  "in_reply_to_status_id" : 657775219721920513,
  "created_at" : "2015-10-24 06:46:50 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ICG10",
      "indices" : [ 48, 54 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 22.6005243743049, 114.4546153956228 ]
  },
  "id_str" : "657808461552422912",
  "text" : "Now: touring the country site to visit the BGI. #ICG10",
  "id" : 657808461552422912,
  "created_at" : "2015-10-24 06:38:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fiona Nielsen",
      "screen_name" : "glyn_dk",
      "indices" : [ 3, 11 ],
      "id_str" : "32340834",
      "id" : 32340834
    }, {
      "name" : "openSNP team",
      "screen_name" : "openSNPorg",
      "indices" : [ 29, 40 ],
      "id_str" : "380205172",
      "id" : 380205172
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OpenData",
      "indices" : [ 103, 112 ]
    }, {
      "text" : "genomics",
      "indices" : [ 113, 122 ]
    }, {
      "text" : "ICG10",
      "indices" : [ 123, 129 ]
    } ],
    "urls" : [ {
      "indices" : [ 54, 77 ],
      "url" : "https:\/\/t.co\/8cLlv17Mxc",
      "expanded_url" : "https:\/\/opensnp.wordpress.com\/2015\/09\/23\/support-opensnp-on-patreon\/",
      "display_url" : "opensnp.wordpress.com\/2015\/09\/23\/sup\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "657787981013495808",
  "text" : "RT @glyn_dk: You can support @openSNPorg via Patreon: https:\/\/t.co\/8cLlv17Mxc &lt;-- Support OpenSNP = #OpenData #genomics #ICG10",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "openSNP team",
        "screen_name" : "openSNPorg",
        "indices" : [ 16, 27 ],
        "id_str" : "380205172",
        "id" : 380205172
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "OpenData",
        "indices" : [ 90, 99 ]
      }, {
        "text" : "genomics",
        "indices" : [ 100, 109 ]
      }, {
        "text" : "ICG10",
        "indices" : [ 110, 116 ]
      } ],
      "urls" : [ {
        "indices" : [ 41, 64 ],
        "url" : "https:\/\/t.co\/8cLlv17Mxc",
        "expanded_url" : "https:\/\/opensnp.wordpress.com\/2015\/09\/23\/support-opensnp-on-patreon\/",
        "display_url" : "opensnp.wordpress.com\/2015\/09\/23\/sup\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "657777502069354496",
    "text" : "You can support @openSNPorg via Patreon: https:\/\/t.co\/8cLlv17Mxc &lt;-- Support OpenSNP = #OpenData #genomics #ICG10",
    "id" : 657777502069354496,
    "created_at" : "2015-10-24 04:35:52 +0000",
    "user" : {
      "name" : "Fiona Nielsen",
      "screen_name" : "glyn_dk",
      "protected" : false,
      "id_str" : "32340834",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3409523398\/35ae8a97e778ebb56089e9a9b58ab9b1_normal.png",
      "id" : 32340834,
      "verified" : false
    }
  },
  "id" : 657787981013495808,
  "created_at" : "2015-10-24 05:17:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GigaScience",
      "screen_name" : "GigaScience",
      "indices" : [ 3, 15 ],
      "id_str" : "208988759",
      "id" : 208988759
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 17, 33 ],
      "id_str" : "14286491",
      "id" : 14286491
    }, {
      "name" : "openSNP team",
      "screen_name" : "openSNPorg",
      "indices" : [ 52, 63 ],
      "id_str" : "380205172",
      "id" : 380205172
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "657787756010041345",
  "text" : "RT @GigaScience: @gedankenstuecke people also using @openSNPorg for education -see \"beginners guide to genome hacking\" https:\/\/t.co\/8sZbhpY\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 0, 16 ],
        "id_str" : "14286491",
        "id" : 14286491
      }, {
        "name" : "openSNP team",
        "screen_name" : "openSNPorg",
        "indices" : [ 35, 46 ],
        "id_str" : "380205172",
        "id" : 380205172
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ICG10",
        "indices" : [ 126, 132 ]
      } ],
      "urls" : [ {
        "indices" : [ 102, 125 ],
        "url" : "https:\/\/t.co\/8sZbhpYToZ",
        "expanded_url" : "https:\/\/medium.com\/@matthiasshap\/the-beginner-s-guide-to-genetics-hacking-84d612b4235",
        "display_url" : "medium.com\/@matthiasshap\/\u2026"
      } ]
    },
    "in_reply_to_status_id_str" : "657776554659983360",
    "geo" : { },
    "id_str" : "657777092663316480",
    "in_reply_to_user_id" : 208988759,
    "text" : "@gedankenstuecke people also using @openSNPorg for education -see \"beginners guide to genome hacking\" https:\/\/t.co\/8sZbhpYToZ #ICG10",
    "id" : 657777092663316480,
    "in_reply_to_status_id" : 657776554659983360,
    "created_at" : "2015-10-24 04:34:14 +0000",
    "in_reply_to_screen_name" : "GigaScience",
    "in_reply_to_user_id_str" : "208988759",
    "user" : {
      "name" : "GigaScience",
      "screen_name" : "GigaScience",
      "protected" : false,
      "id_str" : "208988759",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1404305552\/profile-photo-GigaScience-96x96_normal.jpg",
      "id" : 208988759,
      "verified" : false
    }
  },
  "id" : 657787756010041345,
  "created_at" : "2015-10-24 05:16:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fiona Nielsen",
      "screen_name" : "glyn_dk",
      "indices" : [ 3, 11 ],
      "id_str" : "32340834",
      "id" : 32340834
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 14, 30 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "657787724393377792",
  "text" : "RT @glyn_dk: .@gedankenstuecke \"are there other people than me crazy enough to share their genome data online? Yes, lucky for us there are \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 1, 17 ],
        "id_str" : "14286491",
        "id" : 14286491
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ICG10",
        "indices" : [ 133, 139 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "657776169060839424",
    "text" : ".@gedankenstuecke \"are there other people than me crazy enough to share their genome data online? Yes, lucky for us there are many!\" #ICG10",
    "id" : 657776169060839424,
    "created_at" : "2015-10-24 04:30:34 +0000",
    "user" : {
      "name" : "Fiona Nielsen",
      "screen_name" : "glyn_dk",
      "protected" : false,
      "id_str" : "32340834",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3409523398\/35ae8a97e778ebb56089e9a9b58ab9b1_normal.png",
      "id" : 32340834,
      "verified" : false
    }
  },
  "id" : 657787724393377792,
  "created_at" : "2015-10-24 05:16:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GigaScience",
      "screen_name" : "GigaScience",
      "indices" : [ 3, 15 ],
      "id_str" : "208988759",
      "id" : 208988759
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 18, 34 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "657787680483184640",
  "text" : "RT @GigaScience: .@gedankenstuecke Being in prototyping capital of the world (Shenzhen) why can't we have similarly rapid prototyping of hy\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 1, 17 ],
        "id_str" : "14286491",
        "id" : 14286491
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ICG10",
        "indices" : [ 132, 138 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "657774086685347840",
    "geo" : { },
    "id_str" : "657775033608224768",
    "in_reply_to_user_id" : 208988759,
    "text" : ".@gedankenstuecke Being in prototyping capital of the world (Shenzhen) why can't we have similarly rapid prototyping of hypotheses? #ICG10",
    "id" : 657775033608224768,
    "in_reply_to_status_id" : 657774086685347840,
    "created_at" : "2015-10-24 04:26:03 +0000",
    "in_reply_to_screen_name" : "GigaScience",
    "in_reply_to_user_id_str" : "208988759",
    "user" : {
      "name" : "GigaScience",
      "screen_name" : "GigaScience",
      "protected" : false,
      "id_str" : "208988759",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1404305552\/profile-photo-GigaScience-96x96_normal.jpg",
      "id" : 208988759,
      "verified" : false
    }
  },
  "id" : 657787680483184640,
  "created_at" : "2015-10-24 05:16:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 46 ],
      "url" : "https:\/\/t.co\/cjGAjcAy3H",
      "expanded_url" : "https:\/\/twitter.com\/GigaScience\/status\/657773628197572610",
      "display_url" : "twitter.com\/GigaScience\/st\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 22.53916543119994, 114.0521943774946 ]
  },
  "id_str" : "657787509326245888",
  "text" : "I just couldn\u2019t resist https:\/\/t.co\/cjGAjcAy3H",
  "id" : 657787509326245888,
  "created_at" : "2015-10-24 05:15:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "kittybiome",
      "screen_name" : "kittybiome",
      "indices" : [ 44, 55 ],
      "id_str" : "3164853619",
      "id" : 3164853619
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ICG10",
      "indices" : [ 56, 62 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 22.53918263924204, 114.0522477726338 ]
  },
  "id_str" : "657759458324410368",
  "text" : "Grumpy cat was too grumpy to participate in @kittybiome #ICG10",
  "id" : 657759458324410368,
  "created_at" : "2015-10-24 03:24:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "kittybiome",
      "screen_name" : "kittybiome",
      "indices" : [ 23, 34 ],
      "id_str" : "3164853619",
      "id" : 3164853619
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ICG10",
      "indices" : [ 35, 41 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 22.53918288127534, 114.0522487558582 ]
  },
  "id_str" : "657758495098277892",
  "text" : "Now: hearing about the @kittybiome #ICG10",
  "id" : 657758495098277892,
  "created_at" : "2015-10-24 03:20:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul-Olivier Dehaye",
      "screen_name" : "podehaye",
      "indices" : [ 0, 9 ],
      "id_str" : "2219841242",
      "id" : 2219841242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "657756829624217602",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 22.53918479098563, 114.0522302989121 ]
  },
  "id_str" : "657757183635951616",
  "in_reply_to_user_id" : 2219841242,
  "text" : "@podehaye I think I will pass ;)",
  "id" : 657757183635951616,
  "in_reply_to_status_id" : 657756829624217602,
  "created_at" : "2015-10-24 03:15:07 +0000",
  "in_reply_to_screen_name" : "podehaye",
  "in_reply_to_user_id_str" : "2219841242",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fay-Wei Li",
      "screen_name" : "fern_way",
      "indices" : [ 29, 38 ],
      "id_str" : "2188625971",
      "id" : 2188625971
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ICG10",
      "indices" : [ 122, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 22.53916643930295, 114.0521653020772 ]
  },
  "id_str" : "657756119629099009",
  "text" : "Had the same experience that @fern_way had: university PR departments are slow to pick up on novel ways of doing science. #ICG10",
  "id" : 657756119629099009,
  "created_at" : "2015-10-24 03:10:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/657753103593148416\/photo\/1",
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/Vc01seIX17",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CSDO9nGUsAAi9Fi.jpg",
      "id_str" : "657753103458938880",
      "id" : 657753103458938880,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSDO9nGUsAAi9Fi.jpg",
      "sizes" : [ {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1085,
        "resize" : "fit",
        "w" : 1446
      }, {
        "h" : 1085,
        "resize" : "fit",
        "w" : 1446
      } ],
      "display_url" : "pic.twitter.com\/Vc01seIX17"
    } ],
    "hashtags" : [ {
      "text" : "ICG10",
      "indices" : [ 73, 79 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "657753103593148416",
  "text" : "Named appropriately to test the Mark Zuckerberg of Open Source Genetics. #ICG10 https:\/\/t.co\/Vc01seIX17",
  "id" : 657753103593148416,
  "created_at" : "2015-10-24 02:58:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/657752345762095104\/photo\/1",
      "indices" : [ 38, 61 ],
      "url" : "https:\/\/t.co\/3m0XNynldS",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CSDORflUYAEe9lM.jpg",
      "id_str" : "657752345527214081",
      "id" : 657752345527214081,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSDORflUYAEe9lM.jpg",
      "sizes" : [ {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1404,
        "resize" : "fit",
        "w" : 1053
      }, {
        "h" : 1404,
        "resize" : "fit",
        "w" : 1053
      } ],
      "display_url" : "pic.twitter.com\/3m0XNynldS"
    } ],
    "hashtags" : [ {
      "text" : "ICG10",
      "indices" : [ 31, 37 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 22.539125, 114.052066 ]
  },
  "id_str" : "657752345762095104",
  "text" : "Doing some more DNA testing at #ICG10 https:\/\/t.co\/3m0XNynldS",
  "id" : 657752345762095104,
  "created_at" : "2015-10-24 02:55:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u2697\uFE0FDale Yuzuki",
      "screen_name" : "DaleYuzuki",
      "indices" : [ 0, 11 ],
      "id_str" : "514806103",
      "id" : 514806103
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "657744877954990082",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 22.53896514360459, 114.0526562406336 ]
  },
  "id_str" : "657745247091359744",
  "in_reply_to_user_id" : 514806103,
  "text" : "@DaleYuzuki great, I will present in the Community Genomes session. After that? :)",
  "id" : 657745247091359744,
  "in_reply_to_status_id" : 657744877954990082,
  "created_at" : "2015-10-24 02:27:41 +0000",
  "in_reply_to_screen_name" : "DaleYuzuki",
  "in_reply_to_user_id_str" : "514806103",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/657735697898405888\/photo\/1",
      "indices" : [ 23, 46 ],
      "url" : "https:\/\/t.co\/8ae5EZWctR",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CSC_IP7U8AA28YK.jpg",
      "id_str" : "657735694031319040",
      "id" : 657735694031319040,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSC_IP7U8AA28YK.jpg",
      "sizes" : [ {
        "h" : 2448,
        "resize" : "fit",
        "w" : 3264
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/8ae5EZWctR"
    } ],
    "hashtags" : [ {
      "text" : "ICG10",
      "indices" : [ 16, 22 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 22.53909640358057, 114.0527538746759 ]
  },
  "id_str" : "657735697898405888",
  "text" : "The BGMiseq 500 #ICG10 https:\/\/t.co\/8ae5EZWctR",
  "id" : 657735697898405888,
  "created_at" : "2015-10-24 01:49:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "A. History",
      "screen_name" : "AhistoricalPics",
      "indices" : [ 3, 19 ],
      "id_str" : "2277140276",
      "id" : 2277140276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/yZYmn1FU18",
      "expanded_url" : "https:\/\/twitter.com\/oldpicsarchive\/status\/657691473773789184",
      "display_url" : "twitter.com\/oldpicsarchive\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "657724498326654976",
  "text" : "RT @AhistoricalPics: Fun fact: \"Nachtwey\" is a Tutsi word for stealing someone's photos https:\/\/t.co\/yZYmn1FU18",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 67, 90 ],
        "url" : "https:\/\/t.co\/yZYmn1FU18",
        "expanded_url" : "https:\/\/twitter.com\/oldpicsarchive\/status\/657691473773789184",
        "display_url" : "twitter.com\/oldpicsarchive\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "657696290621497346",
    "text" : "Fun fact: \"Nachtwey\" is a Tutsi word for stealing someone's photos https:\/\/t.co\/yZYmn1FU18",
    "id" : 657696290621497346,
    "created_at" : "2015-10-23 23:13:09 +0000",
    "user" : {
      "name" : "A. History",
      "screen_name" : "AhistoricalPics",
      "protected" : false,
      "id_str" : "2277140276",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/419701923944480769\/AzrkOS2P_normal.jpeg",
      "id" : 2277140276,
      "verified" : false
    }
  },
  "id" : 657724498326654976,
  "created_at" : "2015-10-24 01:05:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GigaScience",
      "screen_name" : "GigaScience",
      "indices" : [ 0, 12 ],
      "id_str" : "208988759",
      "id" : 208988759
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "657723978367303680",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 22.53917332381228, 114.0517829316586 ]
  },
  "id_str" : "657724200824606720",
  "in_reply_to_user_id" : 208988759,
  "text" : "@GigaScience but I need some small drones to facilitate open science. Really!",
  "id" : 657724200824606720,
  "in_reply_to_status_id" : 657723978367303680,
  "created_at" : "2015-10-24 01:04:04 +0000",
  "in_reply_to_screen_name" : "GigaScience",
  "in_reply_to_user_id_str" : "208988759",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 22.53917332381228, 114.0517829316586 ]
  },
  "id_str" : "657723767313960960",
  "text" : "\u00ABAnd over there you see the world second largest building. It\u2019s the larger of the two towers you see there.\u00BB",
  "id" : 657723767313960960,
  "created_at" : "2015-10-24 01:02:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shreejoy Tripathy",
      "screen_name" : "neuronJoy",
      "indices" : [ 0, 10 ],
      "id_str" : "22292146",
      "id" : 22292146
    }, {
      "name" : "ASJ Editors",
      "screen_name" : "ASJeditors",
      "indices" : [ 11, 22 ],
      "id_str" : "3413688976",
      "id" : 3413688976
    }, {
      "name" : "ARCScon",
      "screen_name" : "ARCScon",
      "indices" : [ 23, 31 ],
      "id_str" : "1529905135",
      "id" : 1529905135
    }, {
      "name" : "the Winnower",
      "screen_name" : "theWinnower",
      "indices" : [ 32, 44 ],
      "id_str" : "748018813",
      "id" : 748018813
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "657718671868076033",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 22.53869334306324, 114.0520467566005 ]
  },
  "id_str" : "657723202974564352",
  "in_reply_to_user_id" : 22292146,
  "text" : "@neuronJoy @ASJeditors @ARCScon @theWinnower yes, the whole collection is really worth reading. :)",
  "id" : 657723202974564352,
  "in_reply_to_status_id" : 657718671868076033,
  "created_at" : "2015-10-24 01:00:06 +0000",
  "in_reply_to_screen_name" : "neuronJoy",
  "in_reply_to_user_id_str" : "22292146",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ASJ Editors",
      "screen_name" : "ASJeditors",
      "indices" : [ 0, 11 ],
      "id_str" : "3413688976",
      "id" : 3413688976
    }, {
      "name" : "ARCScon",
      "screen_name" : "ARCScon",
      "indices" : [ 12, 20 ],
      "id_str" : "1529905135",
      "id" : 1529905135
    }, {
      "name" : "the Winnower",
      "screen_name" : "theWinnower",
      "indices" : [ 21, 33 ],
      "id_str" : "748018813",
      "id" : 748018813
    }, {
      "name" : "Shreejoy Tripathy",
      "screen_name" : "neuronJoy",
      "indices" : [ 61, 71 ],
      "id_str" : "22292146",
      "id" : 22292146
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "657649395811393537",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 22.53890124414568, 114.0521994426761 ]
  },
  "id_str" : "657708562425090048",
  "in_reply_to_user_id" : 3413688976,
  "text" : "@ASJeditors @ARCScon @theWinnower Thanks a lot. And congrats @neuronJoy :)",
  "id" : 657708562425090048,
  "in_reply_to_status_id" : 657649395811393537,
  "created_at" : "2015-10-24 00:01:55 +0000",
  "in_reply_to_screen_name" : "ASJeditors",
  "in_reply_to_user_id_str" : "3413688976",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 76 ],
      "url" : "https:\/\/t.co\/fWsMrWhPUq",
      "expanded_url" : "https:\/\/instagram.com\/p\/9MwTg4Bwub\/",
      "display_url" : "instagram.com\/p\/9MwTg4Bwub\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 22.538948427, 114.051915951 ]
  },
  "id_str" : "657706837710675968",
  "text" : "The view by day @ Futian Shangri-La, Shenzhen, China https:\/\/t.co\/fWsMrWhPUq",
  "id" : 657706837710675968,
  "created_at" : "2015-10-23 23:55:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonas",
      "screen_name" : "lsanoj",
      "indices" : [ 0, 7 ],
      "id_str" : "18918915",
      "id" : 18918915
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "657698480358563840",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 22.53933018583275, 114.0517216224631 ]
  },
  "id_str" : "657698667533434880",
  "in_reply_to_user_id" : 18918915,
  "text" : "@lsanoj and to update the CV ;)",
  "id" : 657698667533434880,
  "in_reply_to_status_id" : 657698480358563840,
  "created_at" : "2015-10-23 23:22:36 +0000",
  "in_reply_to_screen_name" : "lsanoj",
  "in_reply_to_user_id_str" : "18918915",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 56 ],
      "url" : "https:\/\/t.co\/PCvRVxaMoT",
      "expanded_url" : "https:\/\/twitter.com\/theWinnower\/status\/657648273583423488",
      "display_url" : "twitter.com\/theWinnower\/st\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 22.53934588888433, 114.0517259391878 ]
  },
  "id_str" : "657697457225138176",
  "text" : "That\u2019s great news to wake up to! https:\/\/t.co\/PCvRVxaMoT",
  "id" : 657697457225138176,
  "created_at" : "2015-10-23 23:17:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "fasel",
      "screen_name" : "fasel",
      "indices" : [ 0, 6 ],
      "id_str" : "21739255",
      "id" : 21739255
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 7, 30 ],
      "url" : "https:\/\/t.co\/JgvMqFI8t6",
      "expanded_url" : "http:\/\/www.picgifs.com\/movies-and-series\/movies\/indiana-jones\/picgifs-indiana-jones-4431047.gif",
      "display_url" : "picgifs.com\/movies-and-ser\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "657504601411833856",
  "geo" : { },
  "id_str" : "657596990172196864",
  "in_reply_to_user_id" : 21739255,
  "text" : "@fasel https:\/\/t.co\/JgvMqFI8t6",
  "id" : 657596990172196864,
  "in_reply_to_status_id" : 657504601411833856,
  "created_at" : "2015-10-23 16:38:34 +0000",
  "in_reply_to_screen_name" : "fasel",
  "in_reply_to_user_id_str" : "21739255",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nyborg",
      "screen_name" : "ny_borg",
      "indices" : [ 0, 8 ],
      "id_str" : "570156398",
      "id" : 570156398
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "657589758391156736",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 22.53939691355752, 114.0516850963748 ]
  },
  "id_str" : "657589894299058177",
  "in_reply_to_user_id" : 570156398,
  "text" : "@ny_borg ein paar gibt es ja schon. Richtiges Cyberpunk dann morgen :)",
  "id" : 657589894299058177,
  "in_reply_to_status_id" : 657589758391156736,
  "created_at" : "2015-10-23 16:10:22 +0000",
  "in_reply_to_screen_name" : "ny_borg",
  "in_reply_to_user_id_str" : "570156398",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nyborg",
      "screen_name" : "ny_borg",
      "indices" : [ 0, 8 ],
      "id_str" : "570156398",
      "id" : 570156398
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "657589166709035008",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 22.53939691355752, 114.0516850963748 ]
  },
  "id_str" : "657589640724017152",
  "in_reply_to_user_id" : 570156398,
  "text" : "@ny_borg aber sonst voll gut bislang. :)",
  "id" : 657589640724017152,
  "in_reply_to_status_id" : 657589166709035008,
  "created_at" : "2015-10-23 16:09:22 +0000",
  "in_reply_to_screen_name" : "ny_borg",
  "in_reply_to_user_id_str" : "570156398",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nyborg",
      "screen_name" : "ny_borg",
      "indices" : [ 0, 8 ],
      "id_str" : "570156398",
      "id" : 570156398
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "657589166709035008",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 22.53939691355752, 114.0516850963748 ]
  },
  "id_str" : "657589575804547072",
  "in_reply_to_user_id" : 570156398,
  "text" : "@ny_borg Schlafmangel und noch etwas sprachverwirrt. Rede momentan manchmal in einem Deutsch\/Englisch\/Ivrit-Mix. Denke REM-Rebound incoming.",
  "id" : 657589575804547072,
  "in_reply_to_status_id" : 657589166709035008,
  "created_at" : "2015-10-23 16:09:06 +0000",
  "in_reply_to_screen_name" : "ny_borg",
  "in_reply_to_user_id_str" : "570156398",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nyborg",
      "screen_name" : "ny_borg",
      "indices" : [ 0, 8 ],
      "id_str" : "570156398",
      "id" : 570156398
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "657586157363044352",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 22.53939691355752, 114.0516850963748 ]
  },
  "id_str" : "657589040112254976",
  "in_reply_to_user_id" : 570156398,
  "text" : "@ny_borg such a near-miss :)",
  "id" : 657589040112254976,
  "in_reply_to_status_id" : 657586157363044352,
  "created_at" : "2015-10-23 16:06:59 +0000",
  "in_reply_to_screen_name" : "ny_borg",
  "in_reply_to_user_id_str" : "570156398",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "H. Nikbakht",
      "screen_name" : "nikleotide",
      "indices" : [ 3, 14 ],
      "id_str" : "92132955",
      "id" : 92132955
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "657583738038038528",
  "text" : "RT @nikleotide: There are a lot of pure garbage software papers out there. This is a good starting guideline on how to review them. https:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/gTk57qS1Oc",
        "expanded_url" : "https:\/\/twitter.com\/michaelhoffman\/status\/657243210096508928",
        "display_url" : "twitter.com\/michaelhoffman\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "657570084571975681",
    "text" : "There are a lot of pure garbage software papers out there. This is a good starting guideline on how to review them. https:\/\/t.co\/gTk57qS1Oc",
    "id" : 657570084571975681,
    "created_at" : "2015-10-23 14:51:39 +0000",
    "user" : {
      "name" : "H. Nikbakht",
      "screen_name" : "nikleotide",
      "protected" : false,
      "id_str" : "92132955",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/856849880266018818\/mGtDP7oS_normal.jpg",
      "id" : 92132955,
      "verified" : false
    }
  },
  "id" : 657583738038038528,
  "created_at" : "2015-10-23 15:45:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "latergram",
      "indices" : [ 43, 53 ]
    } ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/khVIZhcxNG",
      "expanded_url" : "https:\/\/instagram.com\/p\/9L0PKoBwsy\/",
      "display_url" : "instagram.com\/p\/9L0PKoBwsy\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 22.34425, 114.055361111 ]
  },
  "id_str" : "657574747375587328",
  "text" : "Let's cross that bridge when we come to it #latergram @ Kap Shui Mun Bridge https:\/\/t.co\/khVIZhcxNG",
  "id" : 657574747375587328,
  "created_at" : "2015-10-23 15:10:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "latergram",
      "indices" : [ 8, 18 ]
    } ],
    "urls" : [ {
      "indices" : [ 19, 42 ],
      "url" : "https:\/\/t.co\/2QaFMPdGmk",
      "expanded_url" : "https:\/\/instagram.com\/p\/9Loat2Bwmf\/",
      "display_url" : "instagram.com\/p\/9Loat2Bwmf\/"
    } ]
  },
  "geo" : { },
  "id_str" : "657548759077908480",
  "text" : "Shippy! #latergram https:\/\/t.co\/2QaFMPdGmk",
  "id" : 657548759077908480,
  "created_at" : "2015-10-23 13:26:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "657546750379597824",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 22.53887632007115, 114.0522295974727 ]
  },
  "id_str" : "657547990773600256",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot not so far!",
  "id" : 657547990773600256,
  "in_reply_to_status_id" : 657546750379597824,
  "created_at" : "2015-10-23 13:23:52 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "657545865574404096",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 22.53935573600919, 114.0516457423254 ]
  },
  "id_str" : "657546193250070528",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot only for role playing purposes!",
  "id" : 657546193250070528,
  "in_reply_to_status_id" : 657545865574404096,
  "created_at" : "2015-10-23 13:16:43 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "latergram",
      "indices" : [ 31, 41 ]
    } ],
    "urls" : [ {
      "indices" : [ 42, 65 ],
      "url" : "https:\/\/t.co\/n1eo9WB9Ax",
      "expanded_url" : "https:\/\/instagram.com\/p\/9Lm2ZJhwjh\/",
      "display_url" : "instagram.com\/p\/9Lm2ZJhwjh\/"
    } ]
  },
  "geo" : { },
  "id_str" : "657545306628870144",
  "text" : "even more blue in the distance #latergram https:\/\/t.co\/n1eo9WB9Ax",
  "id" : 657545306628870144,
  "created_at" : "2015-10-23 13:13:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "657527824132218880",
  "geo" : { },
  "id_str" : "657528059256377344",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot there's also Mung bean and Tartary Buckwheat. Make of that what you will ;)",
  "id" : 657528059256377344,
  "in_reply_to_status_id" : 657527824132218880,
  "created_at" : "2015-10-23 12:04:40 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "657525892189655040",
  "geo" : { },
  "id_str" : "657527357410951168",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot Instead it's tea and berries I'll bring home. And I indeed don't have driver for the way back. :D",
  "id" : 657527357410951168,
  "in_reply_to_status_id" : 657525892189655040,
  "created_at" : "2015-10-23 12:01:52 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "657520528081690624",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 22.53940477886499, 114.0516963907217 ]
  },
  "id_str" : "657523717614899200",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot I have bad news: no micropig in the conference bag.",
  "id" : 657523717614899200,
  "in_reply_to_status_id" : 657520528081690624,
  "created_at" : "2015-10-23 11:47:25 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "657520528081690624",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 22.53931544813718, 114.0517292290252 ]
  },
  "id_str" : "657521993995042817",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot made it!",
  "id" : 657521993995042817,
  "in_reply_to_status_id" : 657520528081690624,
  "created_at" : "2015-10-23 11:40:34 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 22.50414237847785, 113.9457982500214 ]
  },
  "id_str" : "657504347287236608",
  "text" : "I don\u2019t always jump into the car of strangers with whom I don\u2019t share a language. But if I do they take me to China.",
  "id" : 657504347287236608,
  "created_at" : "2015-10-23 10:30:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "657485085583777792",
  "geo" : { },
  "id_str" : "657485977401733124",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich \u00E4h, danke ;)",
  "id" : 657485977401733124,
  "in_reply_to_status_id" : 657485085583777792,
  "created_at" : "2015-10-23 09:17:27 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luc Henry",
      "screen_name" : "heluc",
      "indices" : [ 0, 6 ],
      "id_str" : "850645992",
      "id" : 850645992
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "657484771459792896",
  "geo" : { },
  "id_str" : "657485143834144768",
  "in_reply_to_user_id" : 850645992,
  "text" : "@heluc thanks :)",
  "id" : 657485143834144768,
  "in_reply_to_status_id" : 657484771459792896,
  "created_at" : "2015-10-23 09:14:08 +0000",
  "in_reply_to_screen_name" : "heluc",
  "in_reply_to_user_id_str" : "850645992",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "657484207971696640",
  "text" : "\u2708\uFE0F HKG! Finished slides for yet another talk, only two to go.",
  "id" : 657484207971696640,
  "created_at" : "2015-10-23 09:10:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : ".",
      "screen_name" : "punkish",
      "indices" : [ 0, 8 ],
      "id_str" : "15322269",
      "id" : 15322269
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "657413410678816768",
  "geo" : { },
  "id_str" : "657414187535044610",
  "in_reply_to_user_id" : 15322269,
  "text" : "@punkish better buy me a beer",
  "id" : 657414187535044610,
  "in_reply_to_status_id" : 657413410678816768,
  "created_at" : "2015-10-23 04:32:11 +0000",
  "in_reply_to_screen_name" : "punkish",
  "in_reply_to_user_id_str" : "15322269",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 82 ],
      "url" : "https:\/\/t.co\/QRbdkdYAky",
      "expanded_url" : "https:\/\/instagram.com\/p\/9KrH_YBwmR\/",
      "display_url" : "instagram.com\/p\/9KrH_YBwmR\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.075849457, 116.606143737 ]
  },
  "id_str" : "657413970266071040",
  "text" : "Onwards @ Beijing Capital International Airport Terminal 3 https:\/\/t.co\/QRbdkdYAky",
  "id" : 657413970266071040,
  "created_at" : "2015-10-23 04:31:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "657407259509559296",
  "text" : "First leg of the trip is done. In 20 minutes it\u2019s onwards to Hong Kong.",
  "id" : 657407259509559296,
  "created_at" : "2015-10-23 04:04:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arikia\uD83D\uDCAB",
      "screen_name" : "arikia",
      "indices" : [ 0, 7 ],
      "id_str" : "71654283",
      "id" : 71654283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "657269952844603392",
  "geo" : { },
  "id_str" : "657407010732806144",
  "in_reply_to_user_id" : 71654283,
  "text" : "@arikia for how long are you in London? Could finally be a chance to meet up. :D",
  "id" : 657407010732806144,
  "in_reply_to_status_id" : 657269952844603392,
  "created_at" : "2015-10-23 04:03:40 +0000",
  "in_reply_to_screen_name" : "arikia",
  "in_reply_to_user_id_str" : "71654283",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : ".",
      "screen_name" : "punkish",
      "indices" : [ 0, 8 ],
      "id_str" : "15322269",
      "id" : 15322269
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "657291469582041089",
  "geo" : { },
  "id_str" : "657406659543744512",
  "in_reply_to_user_id" : 15322269,
  "text" : "@punkish that\u2019s not like me ;)",
  "id" : 657406659543744512,
  "in_reply_to_status_id" : 657291469582041089,
  "created_at" : "2015-10-23 04:02:16 +0000",
  "in_reply_to_screen_name" : "punkish",
  "in_reply_to_user_id_str" : "15322269",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lara",
      "screen_name" : "alibi_ranch",
      "indices" : [ 0, 12 ],
      "id_str" : "265371167",
      "id" : 265371167
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "657257413981151232",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0473706983496, 8.572971755646703 ]
  },
  "id_str" : "657257559015989248",
  "in_reply_to_user_id" : 265371167,
  "text" : "@alibi_ranch Wenn man daf\u00FCr nicht das Gruselkistendiplom ben\u00F6tigt weiss ich auch nicht!",
  "id" : 657257559015989248,
  "in_reply_to_status_id" : 657257413981151232,
  "created_at" : "2015-10-22 18:09:47 +0000",
  "in_reply_to_screen_name" : "alibi_ranch",
  "in_reply_to_user_id_str" : "265371167",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lara",
      "screen_name" : "alibi_ranch",
      "indices" : [ 0, 12 ],
      "id_str" : "265371167",
      "id" : 265371167
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "657255709885734912",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.04746570722205, 8.573317592971561 ]
  },
  "id_str" : "657256443008196608",
  "in_reply_to_user_id" : 265371167,
  "text" : "@alibi_ranch jetzt steht dem Traumjob nichts mehr im Weg!",
  "id" : 657256443008196608,
  "in_reply_to_status_id" : 657255709885734912,
  "created_at" : "2015-10-22 18:05:21 +0000",
  "in_reply_to_screen_name" : "alibi_ranch",
  "in_reply_to_user_id_str" : "265371167",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/9HQydar59a",
      "expanded_url" : "https:\/\/twitter.com\/DNADigest\/status\/657253080883441664",
      "display_url" : "twitter.com\/DNADigest\/stat\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.04751331799919, 8.573492763927687 ]
  },
  "id_str" : "657254671434829824",
  "text" : "And I think we should all be worried that it\u2019s in private rather than public hands\u2026 https:\/\/t.co\/9HQydar59a",
  "id" : 657254671434829824,
  "created_at" : "2015-10-22 17:58:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "657253164182302720",
  "text" : "\u00ABWe will start hoarding soon.\u00BB This autocorrect fail is even funnier if you\u2019ve seen our apartment.",
  "id" : 657253164182302720,
  "created_at" : "2015-10-22 17:52:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/kXosbLs4gf",
      "expanded_url" : "https:\/\/twitter.com\/michaelhoffman\/status\/657206553204756481",
      "display_url" : "twitter.com\/michaelhoffman\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.04734371209386, 8.572383292670136 ]
  },
  "id_str" : "657245965045338113",
  "text" : "Using math to call BS on the idea of meritocracy when it comes to organizing conferences https:\/\/t.co\/kXosbLs4gf",
  "id" : 657245965045338113,
  "created_at" : "2015-10-22 17:23:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 85 ],
      "url" : "https:\/\/t.co\/J5RASrFMXi",
      "expanded_url" : "http:\/\/arstechnica.com\/science\/2015\/10\/23andme-reboots-genetic-health-testing-now-with-fda-approval\/",
      "display_url" : "arstechnica.com\/science\/2015\/1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "657242500747436032",
  "text" : "23andMe reboots genetic health testing, now with FDA approval https:\/\/t.co\/J5RASrFMXi",
  "id" : 657242500747436032,
  "created_at" : "2015-10-22 17:09:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 71 ],
      "url" : "https:\/\/t.co\/FImTwSdPX2",
      "expanded_url" : "http:\/\/blogs.plos.org\/blog\/2015\/10\/21\/why-arent-we-all-machine-friendly-researchers\/?utm_source=feedburner&utm_medium=feed&utm_campaign=Feed%3A+plos%2Fblogs%2Fmain+%28Blogs+-+Main%29",
      "display_url" : "blogs.plos.org\/blog\/2015\/10\/2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "657242404173565952",
  "text" : "Why Aren\u2019t We All Machine-Friendly Researchers? https:\/\/t.co\/FImTwSdPX2",
  "id" : 657242404173565952,
  "created_at" : "2015-10-22 17:09:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/arEpm4sphR",
      "expanded_url" : "http:\/\/existentialcomics.com\/comic\/103",
      "display_url" : "existentialcomics.com\/comic\/103"
    } ]
  },
  "geo" : { },
  "id_str" : "657241439118729216",
  "text" : "hokey philosophies and ancient weapons are no match for a good blaster https:\/\/t.co\/arEpm4sphR",
  "id" : 657241439118729216,
  "created_at" : "2015-10-22 17:05:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 43 ],
      "url" : "https:\/\/t.co\/mhEY9tGOnW",
      "expanded_url" : "http:\/\/www.smbc-comics.com\/index.php?id=3903",
      "display_url" : "smbc-comics.com\/index.php?id=3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "657240668801269760",
  "text" : "teaching philosophy https:\/\/t.co\/mhEY9tGOnW",
  "id" : 657240668801269760,
  "created_at" : "2015-10-22 17:02:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.04734489295542, 8.572435078715923 ]
  },
  "id_str" : "657223393788432384",
  "text" : "It\u2019s definitely a plus if the airport security already knows you\u2026",
  "id" : 657223393788432384,
  "created_at" : "2015-10-22 15:54:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uD83D\uDCABKelsey Merkley \uD83D\uDCAB",
      "screen_name" : "bella_velo",
      "indices" : [ 3, 14 ],
      "id_str" : "6745972",
      "id" : 6745972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/ABHnh6WMH9",
      "expanded_url" : "https:\/\/twitter.com\/papadimitriou\/status\/657210866731995136",
      "display_url" : "twitter.com\/papadimitriou\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "657216684961484800",
  "text" : "RT @bella_velo: We don't hate uber - we hate our deal loving moral tossing selves  https:\/\/t.co\/ABHnh6WMH9",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 67, 90 ],
        "url" : "https:\/\/t.co\/ABHnh6WMH9",
        "expanded_url" : "https:\/\/twitter.com\/papadimitriou\/status\/657210866731995136",
        "display_url" : "twitter.com\/papadimitriou\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "657212307009904640",
    "text" : "We don't hate uber - we hate our deal loving moral tossing selves  https:\/\/t.co\/ABHnh6WMH9",
    "id" : 657212307009904640,
    "created_at" : "2015-10-22 15:09:59 +0000",
    "user" : {
      "name" : "\uD83D\uDCABKelsey Merkley \uD83D\uDCAB",
      "screen_name" : "bella_velo",
      "protected" : false,
      "id_str" : "6745972",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/875913994929934336\/1aiBO2bG_normal.jpg",
      "id" : 6745972,
      "verified" : false
    }
  },
  "id" : 657216684961484800,
  "created_at" : "2015-10-22 15:27:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthias Shapiro",
      "screen_name" : "matthiasshap",
      "indices" : [ 0, 13 ],
      "id_str" : "16098270",
      "id" : 16098270
    }, {
      "name" : "pinfoto",
      "screen_name" : "pinfoto",
      "indices" : [ 14, 22 ],
      "id_str" : "4092610099",
      "id" : 4092610099
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "657207682768568321",
  "geo" : { },
  "id_str" : "657209052187987968",
  "in_reply_to_user_id" : 16098270,
  "text" : "@matthiasshap @pinfoto Also: I think it\u2019s inflated through crawling errors on our side: having duplicates\/triplicates in the DB.",
  "id" : 657209052187987968,
  "in_reply_to_status_id" : 657207682768568321,
  "created_at" : "2015-10-22 14:57:03 +0000",
  "in_reply_to_screen_name" : "matthiasshap",
  "in_reply_to_user_id_str" : "16098270",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthias Shapiro",
      "screen_name" : "matthiasshap",
      "indices" : [ 0, 13 ],
      "id_str" : "16098270",
      "id" : 16098270
    }, {
      "name" : "pinfoto",
      "screen_name" : "pinfoto",
      "indices" : [ 14, 22 ],
      "id_str" : "4092610099",
      "id" : 4092610099
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "657207682768568321",
  "geo" : { },
  "id_str" : "657208929110401024",
  "in_reply_to_user_id" : 16098270,
  "text" : "@matthiasshap @pinfoto thanks that won\u2019t be useful for the static presentation for now. :)",
  "id" : 657208929110401024,
  "in_reply_to_status_id" : 657207682768568321,
  "created_at" : "2015-10-22 14:56:33 +0000",
  "in_reply_to_screen_name" : "matthiasshap",
  "in_reply_to_user_id_str" : "16098270",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ICG10",
      "indices" : [ 52, 58 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "657206050580471808",
  "text" : "And off to the airport again. FRA \u2708\uFE0F PEK \u2708\uFE0F HKG for #ICG10. Taking recommendations for books to read on the flights.",
  "id" : 657206050580471808,
  "created_at" : "2015-10-22 14:45:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthias Shapiro",
      "screen_name" : "matthiasshap",
      "indices" : [ 0, 13 ],
      "id_str" : "16098270",
      "id" : 16098270
    }, {
      "name" : "pinfoto",
      "screen_name" : "pinfoto",
      "indices" : [ 14, 22 ],
      "id_str" : "4092610099",
      "id" : 4092610099
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "657191680433459201",
  "geo" : { },
  "id_str" : "657194506245263360",
  "in_reply_to_user_id" : 16098270,
  "text" : "@matthiasshap @pinfoto sweet, thanks a lot. Mind if I use the graphic in a presentation? (with credit of course!) :-)",
  "id" : 657194506245263360,
  "in_reply_to_status_id" : 657191680433459201,
  "created_at" : "2015-10-22 13:59:15 +0000",
  "in_reply_to_screen_name" : "matthiasshap",
  "in_reply_to_user_id_str" : "16098270",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "657172733957165057",
  "geo" : { },
  "id_str" : "657173975420792832",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot more important (\uD83D\uDC14\uD83D\uDC25\uD83D\uDC27\uD83D\uDC26\uD83D\uDC24\uD83D\uDC23\uD83E\uDD83\uD83D\uDC13), (\uD83D\uDC33\uD83D\uDC2C\uD83D\uDC0B\uD83D\uDC04\uD83D\uDC02\uD83D\uDC16) &amp; ( \uD83D\uDC0C\uD83D\uDC1A)",
  "id" : 657173975420792832,
  "in_reply_to_status_id" : 657172733957165057,
  "created_at" : "2015-10-22 12:37:40 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "657172733957165057",
  "geo" : { },
  "id_str" : "657173302570545152",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot (\uD83E\uDD84\uD83D\uDC34) &amp; (\uD83D\uDC32\uD83D\uDC09\uD83D\uDC0A\uD83D\uDC22\uD83D\uDC0D)",
  "id" : 657173302570545152,
  "in_reply_to_status_id" : 657172733957165057,
  "created_at" : "2015-10-22 12:34:59 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "the Winnower",
      "screen_name" : "theWinnower",
      "indices" : [ 69, 81 ],
      "id_str" : "748018813",
      "id" : 748018813
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "openscience",
      "indices" : [ 82, 94 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/tQZY3AlP4m",
      "expanded_url" : "https:\/\/thewinnower.com\/papers\/2368-you-don-t-get-to-2000-open-data-sets-without-making-a-few-friends-or-how-i-got-to-be-called-the-mark-zuckerberg-of-open-source-genetics",
      "display_url" : "thewinnower.com\/papers\/2368-yo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "657152849072246784",
  "text" : "Today\u2019s the last chance to leave a review for my contribution to the @theWinnower #openscience story competition! https:\/\/t.co\/tQZY3AlP4m",
  "id" : 657152849072246784,
  "created_at" : "2015-10-22 11:13:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 76 ],
      "url" : "https:\/\/t.co\/eJNhGkYASD",
      "expanded_url" : "http:\/\/www.vanityfair.com\/culture\/2015\/10\/ermahgerd-girl-true-story",
      "display_url" : "vanityfair.com\/culture\/2015\/1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "657151978443816960",
  "text" : "Ermahgerddon: The Untold Story of the Ermahgerd Girl https:\/\/t.co\/eJNhGkYASD",
  "id" : 657151978443816960,
  "created_at" : "2015-10-22 11:10:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "657149557399289856",
  "text" : "With new emoji in iOS it bugs me even more that the animal emoji aren\u2019t grouped by taxonomy. How am I supposed to find what I\u2019m looking for?",
  "id" : 657149557399289856,
  "created_at" : "2015-10-22 11:00:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pinfoto",
      "screen_name" : "pinfoto",
      "indices" : [ 0, 8 ],
      "id_str" : "4092610099",
      "id" : 4092610099
    }, {
      "name" : "Matthias Shapiro",
      "screen_name" : "matthiasshap",
      "indices" : [ 9, 22 ],
      "id_str" : "16098270",
      "id" : 16098270
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "656948614963531778",
  "geo" : { },
  "id_str" : "657126299924889600",
  "in_reply_to_user_id" : 95494624,
  "text" : "@pinfoto @matthiasshap should be back up. Would be super interested in hearing what you are using the data for. :)",
  "id" : 657126299924889600,
  "in_reply_to_status_id" : 656948614963531778,
  "created_at" : "2015-10-22 09:28:13 +0000",
  "in_reply_to_screen_name" : "cancrx",
  "in_reply_to_user_id_str" : "95494624",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 142 ],
      "url" : "https:\/\/t.co\/n1HXwIpcgf",
      "expanded_url" : "https:\/\/twitter.com\/SFWeekly\/status\/657013572245979136",
      "display_url" : "twitter.com\/SFWeekly\/statu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "657123499136434176",
  "text" : "Time &amp; again startups have to learn that you can\u2019t only disrupt industries but flow of blood to the brain as well\u2026 https:\/\/t.co\/n1HXwIpcgf",
  "id" : 657123499136434176,
  "created_at" : "2015-10-22 09:17:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "657110938114465792",
  "geo" : { },
  "id_str" : "657113327504642048",
  "in_reply_to_user_id" : 14286491,
  "text" : "That\u2019s it of the Israel photo backlog. Clears the pipeline for Hong Kong pictures.",
  "id" : 657113327504642048,
  "in_reply_to_status_id" : 657110938114465792,
  "created_at" : "2015-10-22 08:36:40 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 59 ],
      "url" : "https:\/\/t.co\/ilgSSfHrtO",
      "expanded_url" : "https:\/\/instagram.com\/p\/9IhUnCBwhN\/",
      "display_url" : "instagram.com\/p\/9IhUnCBwhN\/"
    } ]
  },
  "geo" : { },
  "id_str" : "657110938114465792",
  "text" : "the color of where you can never go https:\/\/t.co\/ilgSSfHrtO",
  "id" : 657110938114465792,
  "created_at" : "2015-10-22 08:27:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 39 ],
      "url" : "https:\/\/t.co\/hWd1vvZGjb",
      "expanded_url" : "https:\/\/flic.kr\/p\/A7z2CM",
      "display_url" : "flic.kr\/p\/A7z2CM"
    } ]
  },
  "geo" : { },
  "id_str" : "657108416167587840",
  "text" : "\u05DE\u05D3\u05E8\u05E9\u05EA \u05D1\u05DF-\u05D2\u05D5\u05E8\u05D9\u05D5\u05DF https:\/\/t.co\/hWd1vvZGjb",
  "id" : 657108416167587840,
  "created_at" : "2015-10-22 08:17:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "656924197709594630",
  "geo" : { },
  "id_str" : "656955473699184640",
  "in_reply_to_user_id" : 448328735,
  "text" : "@VetoSeb erinnert mich an Big Seb is watching you \uD83D\uDE13",
  "id" : 656955473699184640,
  "in_reply_to_status_id" : 656924197709594630,
  "created_at" : "2015-10-21 22:09:25 +0000",
  "in_reply_to_screen_name" : "SebInAction",
  "in_reply_to_user_id_str" : "448328735",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 33 ],
      "url" : "https:\/\/t.co\/I1BXXgeS29",
      "expanded_url" : "https:\/\/flic.kr\/p\/zMWvrT",
      "display_url" : "flic.kr\/p\/zMWvrT"
    } ]
  },
  "geo" : { },
  "id_str" : "656922720458903552",
  "text" : "\u05DE\u05DB\u05EA\u05E9 \u05E8\u05DE\u05D5\u05DF https:\/\/t.co\/I1BXXgeS29",
  "id" : 656922720458903552,
  "created_at" : "2015-10-21 19:59:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael R. Crusoe",
      "screen_name" : "biocrusoe",
      "indices" : [ 10, 20 ],
      "id_str" : "17645638",
      "id" : 17645638
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 78 ],
      "url" : "https:\/\/t.co\/tQZY3AlP4m",
      "expanded_url" : "https:\/\/thewinnower.com\/papers\/2368-you-don-t-get-to-2000-open-data-sets-without-making-a-few-friends-or-how-i-got-to-be-called-the-mark-zuckerberg-of-open-source-genetics",
      "display_url" : "thewinnower.com\/papers\/2368-yo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "656921248539242497",
  "text" : "Thanks to @biocrusoe for providing such a nice review! https:\/\/t.co\/tQZY3AlP4m",
  "id" : 656921248539242497,
  "created_at" : "2015-10-21 19:53:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 6, 29 ],
      "url" : "https:\/\/t.co\/YSeSDVEaLG",
      "expanded_url" : "https:\/\/flic.kr\/p\/z8pCj4",
      "display_url" : "flic.kr\/p\/z8pCj4"
    } ]
  },
  "geo" : { },
  "id_str" : "656914093606072320",
  "text" : "Negev https:\/\/t.co\/YSeSDVEaLG",
  "id" : 656914093606072320,
  "created_at" : "2015-10-21 19:24:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "656900416337223680",
  "text" : "And back, for less than 24 hours\u2026",
  "id" : 656900416337223680,
  "created_at" : "2015-10-21 18:30:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonas",
      "screen_name" : "lsanoj",
      "indices" : [ 0, 7 ],
      "id_str" : "18918915",
      "id" : 18918915
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "656830692152754177",
  "geo" : { },
  "id_str" : "656897341245509632",
  "in_reply_to_user_id" : 18918915,
  "text" : "@lsanoj from tomorrow on until Monday. :)",
  "id" : 656897341245509632,
  "in_reply_to_status_id" : 656830692152754177,
  "created_at" : "2015-10-21 18:18:25 +0000",
  "in_reply_to_screen_name" : "lsanoj",
  "in_reply_to_user_id_str" : "18918915",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonas",
      "screen_name" : "lsanoj",
      "indices" : [ 0, 7 ],
      "id_str" : "18918915",
      "id" : 18918915
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "656821661736505344",
  "geo" : { },
  "id_str" : "656822236175822849",
  "in_reply_to_user_id" : 18918915,
  "text" : "@lsanoj okay :D",
  "id" : 656822236175822849,
  "in_reply_to_status_id" : 656821661736505344,
  "created_at" : "2015-10-21 13:19:58 +0000",
  "in_reply_to_screen_name" : "lsanoj",
  "in_reply_to_user_id_str" : "18918915",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 5, 28 ],
      "url" : "https:\/\/t.co\/o9TI7nX7wE",
      "expanded_url" : "https:\/\/flic.kr\/p\/A4JP5c",
      "display_url" : "flic.kr\/p\/A4JP5c"
    } ]
  },
  "geo" : { },
  "id_str" : "656822156140093440",
  "text" : "\u05E2\u05D1\u05D3\u05EA https:\/\/t.co\/o9TI7nX7wE",
  "id" : 656822156140093440,
  "created_at" : "2015-10-21 13:19:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "latergram",
      "indices" : [ 34, 44 ]
    } ],
    "urls" : [ {
      "indices" : [ 45, 68 ],
      "url" : "https:\/\/t.co\/rohnySRdYO",
      "expanded_url" : "https:\/\/instagram.com\/p\/9Gahq4Bwmy\/",
      "display_url" : "instagram.com\/p\/9Gahq4Bwmy\/"
    } ]
  },
  "geo" : { },
  "id_str" : "656814518845206529",
  "text" : "The things you find in the Negev. #latergram https:\/\/t.co\/rohnySRdYO",
  "id" : 656814518845206529,
  "created_at" : "2015-10-21 12:49:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "656810922552504320",
  "text" : "As I somehow made it through security and emigration: which VPN provider do I want to use for China where I\u2019ll go to tomorrow?",
  "id" : 656810922552504320,
  "created_at" : "2015-10-21 12:35:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "656756168329662464",
  "geo" : { },
  "id_str" : "656799178836852736",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot the airport wifi blocks the URL. we should celebrate this \u270A\u270A\u270A\u270A\uD83C\uDFFD",
  "id" : 656799178836852736,
  "in_reply_to_status_id" : 656756168329662464,
  "created_at" : "2015-10-21 11:48:21 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 6, 29 ],
      "url" : "https:\/\/t.co\/Lwgp3zHchT",
      "expanded_url" : "https:\/\/instagram.com\/p\/9GPsVFhwki\/",
      "display_url" : "instagram.com\/p\/9GPsVFhwki\/"
    } ]
  },
  "geo" : { },
  "id_str" : "656790695647252480",
  "text" : "\u05D4\u05D1\u05D9\u05DE\u05D4 https:\/\/t.co\/Lwgp3zHchT",
  "id" : 656790695647252480,
  "created_at" : "2015-10-21 11:14:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "656748935978065920",
  "geo" : { },
  "id_str" : "656789902827376640",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot I want a dog!",
  "id" : 656789902827376640,
  "in_reply_to_status_id" : 656748935978065920,
  "created_at" : "2015-10-21 11:11:30 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "656789690708791297",
  "text" : "Airport security: still calling things with zero entropy random\u2026",
  "id" : 656789690708791297,
  "created_at" : "2015-10-21 11:10:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "656737430792445953",
  "geo" : { },
  "id_str" : "656744308599627780",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot you have a dog waiting for me?!\uD83D\uDC36\uD83D\uDC36\uD83D\uDC36\uD83D\uDC36",
  "id" : 656744308599627780,
  "in_reply_to_status_id" : 656737430792445953,
  "created_at" : "2015-10-21 08:10:19 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "656737330498260992",
  "geo" : { },
  "id_str" : "656744215574130688",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot wait until you tasted it ;) and I think in terms of traveling across borders the short beard is really useful :3",
  "id" : 656744215574130688,
  "in_reply_to_status_id" : 656737330498260992,
  "created_at" : "2015-10-21 08:09:57 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 111, 117 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "656735013678006272",
  "text" : "Now my bag is full of halva and za\u2019atar. Might have to fly naked to stay inside the luggage weight limits. \/cc @Lobot",
  "id" : 656735013678006272,
  "created_at" : "2015-10-21 07:33:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "The_Smoking_GNU",
      "indices" : [ 0, 16 ],
      "id_str" : "14535787",
      "id" : 14535787
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "656734197332189184",
  "geo" : { },
  "id_str" : "656734588195241984",
  "in_reply_to_user_id" : 14535787,
  "text" : "@The_Smoking_GNU in keinster Weise vergleichbar mit dem was man hier frisch bekommt :)",
  "id" : 656734588195241984,
  "in_reply_to_status_id" : 656734197332189184,
  "created_at" : "2015-10-21 07:31:42 +0000",
  "in_reply_to_screen_name" : "The_Smoking_GNU",
  "in_reply_to_user_id_str" : "14535787",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "656730482730598400",
  "text" : "Hard decisions: shall I abandon most of my luggage to have more space for halva?",
  "id" : 656730482730598400,
  "created_at" : "2015-10-21 07:15:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nyborg",
      "screen_name" : "ny_borg",
      "indices" : [ 0, 8 ],
      "id_str" : "570156398",
      "id" : 570156398
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "656716001157902336",
  "geo" : { },
  "id_str" : "656716595717271552",
  "in_reply_to_user_id" : 570156398,
  "text" : "@ny_borg I\u2019ll have a comeback tomorrow when arriving in Hong Kong ;)",
  "id" : 656716595717271552,
  "in_reply_to_status_id" : 656716001157902336,
  "created_at" : "2015-10-21 06:20:12 +0000",
  "in_reply_to_screen_name" : "ny_borg",
  "in_reply_to_user_id_str" : "570156398",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/656714772201664513\/photo\/1",
      "indices" : [ 42, 65 ],
      "url" : "https:\/\/t.co\/VwplYfTwW3",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CR0emxRUcAEshnQ.jpg",
      "id_str" : "656714772075802625",
      "id" : 656714772075802625,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CR0emxRUcAEshnQ.jpg",
      "sizes" : [ {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 995,
        "resize" : "fit",
        "w" : 1327
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 995,
        "resize" : "fit",
        "w" : 1327
      } ],
      "display_url" : "pic.twitter.com\/VwplYfTwW3"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 32.080137, 34.768056 ]
  },
  "id_str" : "656714772201664513",
  "text" : "I'll miss this view to have breakfast to. https:\/\/t.co\/VwplYfTwW3",
  "id" : 656714772201664513,
  "created_at" : "2015-10-21 06:12:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "656589371072716800",
  "geo" : { },
  "id_str" : "656589702661804032",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot will do open science for food. (as long as it pays for rent in TLV as well).",
  "id" : 656589702661804032,
  "in_reply_to_status_id" : 656589371072716800,
  "created_at" : "2015-10-20 21:55:58 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "656586836056408065",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 32.08007823556304, 34.76808070858851 ]
  },
  "id_str" : "656589225769488384",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot will do open science for food.",
  "id" : 656589225769488384,
  "in_reply_to_status_id" : 656586836056408065,
  "created_at" : "2015-10-20 21:54:04 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 142 ],
      "url" : "https:\/\/t.co\/tQZY3AlP4m",
      "expanded_url" : "https:\/\/thewinnower.com\/papers\/2368-you-don-t-get-to-2000-open-data-sets-without-making-a-few-friends-or-how-i-got-to-be-called-the-mark-zuckerberg-of-open-source-genetics",
      "display_url" : "thewinnower.com\/papers\/2368-yo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "656585724679073792",
  "text" : "bored &amp; having some time to spare? write a review for my article (and help me have a chance at a prize of USD1000) https:\/\/t.co\/tQZY3AlP4m",
  "id" : 656585724679073792,
  "created_at" : "2015-10-20 21:40:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 38 ],
      "url" : "https:\/\/t.co\/RmvBUVSZvA",
      "expanded_url" : "https:\/\/instagram.com\/p\/9EoQ39Bwr8\/",
      "display_url" : "instagram.com\/p\/9EoQ39Bwr8\/"
    } ]
  },
  "geo" : { },
  "id_str" : "656563255377330176",
  "text" : "Into the Dunes https:\/\/t.co\/RmvBUVSZvA",
  "id" : 656563255377330176,
  "created_at" : "2015-10-20 20:10:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "656555232374206465",
  "text" : "Crying into my halva over the fact that I\u2019ll return to the land of bad food tomorrow.",
  "id" : 656555232374206465,
  "created_at" : "2015-10-20 19:39:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 8, 31 ],
      "url" : "https:\/\/t.co\/DTTQmaGesH",
      "expanded_url" : "https:\/\/instagram.com\/p\/9EPgt2Bwte\/",
      "display_url" : "instagram.com\/p\/9EPgt2Bwte\/"
    } ]
  },
  "geo" : { },
  "id_str" : "656508821972590594",
  "text" : "Oh hai! https:\/\/t.co\/DTTQmaGesH",
  "id" : 656508821972590594,
  "created_at" : "2015-10-20 16:34:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 41 ],
      "url" : "https:\/\/t.co\/w70ZsUJ8Dm",
      "expanded_url" : "https:\/\/instagram.com\/p\/9EOynuhwsY\/",
      "display_url" : "instagram.com\/p\/9EOynuhwsY\/"
    } ]
  },
  "geo" : { },
  "id_str" : "656507238383755264",
  "text" : "Playing biologist https:\/\/t.co\/w70ZsUJ8Dm",
  "id" : 656507238383755264,
  "created_at" : "2015-10-20 16:28:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 37 ],
      "url" : "https:\/\/t.co\/aV2lQijWiH",
      "expanded_url" : "https:\/\/instagram.com\/p\/9EOEJThwq4\/",
      "display_url" : "instagram.com\/p\/9EOEJThwq4\/"
    } ]
  },
  "geo" : { },
  "id_str" : "656505641008254976",
  "text" : "Cupish lichen https:\/\/t.co\/aV2lQijWiH",
  "id" : 656505641008254976,
  "created_at" : "2015-10-20 16:21:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "656469242603290624",
  "text" : "\u00ABHe\u2019s trying to resurrect Ben Gurion. By singing The Internationale.\u00BB",
  "id" : 656469242603290624,
  "created_at" : "2015-10-20 13:57:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 30.76534571935262, 34.77150801681955 ]
  },
  "id_str" : "656445191977570304",
  "text" : "\u00ABYou\u2019ll have a couple of years to travel.\u00BB\u2014\u00BBYes? Doesn\u2019t life end after the PhD?\u00BB\u2014\u00ABThis I didn\u2019t deny, I said: you have a couple of years.\u00BB",
  "id" : 656445191977570304,
  "created_at" : "2015-10-20 12:21:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "656415016971825152",
  "text" : "Doing fieldwork with Apache helicopters hovering overhead and artillery training nearby is strange.",
  "id" : 656415016971825152,
  "created_at" : "2015-10-20 10:21:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 36 ],
      "url" : "https:\/\/t.co\/ev3P77E21p",
      "expanded_url" : "https:\/\/instagram.com\/p\/9DjVowhwjR\/",
      "display_url" : "instagram.com\/p\/9DjVowhwjR\/"
    } ]
  },
  "geo" : { },
  "id_str" : "656411683590656004",
  "text" : "in the dunes https:\/\/t.co\/ev3P77E21p",
  "id" : 656411683590656004,
  "created_at" : "2015-10-20 10:08:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "latergram",
      "indices" : [ 6, 16 ]
    } ],
    "urls" : [ {
      "indices" : [ 17, 40 ],
      "url" : "https:\/\/t.co\/fvQCfK52Q5",
      "expanded_url" : "https:\/\/instagram.com\/p\/9Dgz2wBwgu\/",
      "display_url" : "instagram.com\/p\/9Dgz2wBwgu\/"
    } ]
  },
  "geo" : { },
  "id_str" : "656406125433200640",
  "text" : "Jaffa #latergram https:\/\/t.co\/fvQCfK52Q5",
  "id" : 656406125433200640,
  "created_at" : "2015-10-20 09:46:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Repositive.io",
      "screen_name" : "repositiveio",
      "indices" : [ 3, 16 ],
      "id_str" : "3059929578",
      "id" : 3059929578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/1U6AFdncxQ",
      "expanded_url" : "http:\/\/buff.ly\/1GIr4Hj",
      "display_url" : "buff.ly\/1GIr4Hj"
    } ]
  },
  "geo" : { },
  "id_str" : "656395958612283392",
  "text" : "RT @repositiveio: \"How do I find human genomics data to power my research?\" Find out @ our Hong Kong Workshop https:\/\/t.co\/1U6AFdncxQ @Giga\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "GigaScience",
        "screen_name" : "GigaScience",
        "indices" : [ 116, 128 ],
        "id_str" : "208988759",
        "id" : 208988759
      }, {
        "name" : "openSNP team",
        "screen_name" : "openSNPorg",
        "indices" : [ 129, 140 ],
        "id_str" : "380205172",
        "id" : 380205172
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 92, 115 ],
        "url" : "https:\/\/t.co\/1U6AFdncxQ",
        "expanded_url" : "http:\/\/buff.ly\/1GIr4Hj",
        "display_url" : "buff.ly\/1GIr4Hj"
      } ]
    },
    "geo" : { },
    "id_str" : "656395746900582400",
    "text" : "\"How do I find human genomics data to power my research?\" Find out @ our Hong Kong Workshop https:\/\/t.co\/1U6AFdncxQ @GigaScience @openSNPorg",
    "id" : 656395746900582400,
    "created_at" : "2015-10-20 09:05:15 +0000",
    "user" : {
      "name" : "Repositive.io",
      "screen_name" : "repositiveio",
      "protected" : false,
      "id_str" : "3059929578",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/661114195753230336\/N89yr0lj_normal.png",
      "id" : 3059929578,
      "verified" : false
    }
  },
  "id" : 656395958612283392,
  "created_at" : "2015-10-20 09:06:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "656381100600770560",
  "text" : "\u00ABIf we don\u2019t start slowing down now, we\u2019ll end up in Egypt.\u00BB",
  "id" : 656381100600770560,
  "created_at" : "2015-10-20 08:07:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "656319328120406016",
  "text" : "Now: off to the desert.",
  "id" : 656319328120406016,
  "created_at" : "2015-10-20 04:01:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "656208551115902976",
  "text" : "impromptu jam session \u2611\uFE0F",
  "id" : 656208551115902976,
  "created_at" : "2015-10-19 20:41:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael R. Crusoe",
      "screen_name" : "biocrusoe",
      "indices" : [ 0, 10 ],
      "id_str" : "17645638",
      "id" : 17645638
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "656194363555491841",
  "geo" : { },
  "id_str" : "656208426977071104",
  "in_reply_to_user_id" : 17645638,
  "text" : "@biocrusoe we should do some joint cooking some day!",
  "id" : 656208426977071104,
  "in_reply_to_status_id" : 656194363555491841,
  "created_at" : "2015-10-19 20:40:55 +0000",
  "in_reply_to_screen_name" : "biocrusoe",
  "in_reply_to_user_id_str" : "17645638",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael R. Crusoe",
      "screen_name" : "biocrusoe",
      "indices" : [ 0, 10 ],
      "id_str" : "17645638",
      "id" : 17645638
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "656192959965220865",
  "geo" : { },
  "id_str" : "656194115667890177",
  "in_reply_to_user_id" : 17645638,
  "text" : "@biocrusoe I can help out with lots of vegan Israeli recipes if you want :)",
  "id" : 656194115667890177,
  "in_reply_to_status_id" : 656192959965220865,
  "created_at" : "2015-10-19 19:44:03 +0000",
  "in_reply_to_screen_name" : "biocrusoe",
  "in_reply_to_user_id_str" : "17645638",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "656155757814095872",
  "text" : "I want to take all the vegan food you can find here home.",
  "id" : 656155757814095872,
  "created_at" : "2015-10-19 17:11:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 8, 31 ],
      "url" : "https:\/\/t.co\/N7DhuKFwuG",
      "expanded_url" : "https:\/\/instagram.com\/p\/9BluR8Bwks\/",
      "display_url" : "instagram.com\/p\/9BluR8Bwks\/"
    } ]
  },
  "geo" : { },
  "id_str" : "656135455080099841",
  "text" : "Birding https:\/\/t.co\/N7DhuKFwuG",
  "id" : 656135455080099841,
  "created_at" : "2015-10-19 15:50:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 7, 30 ],
      "url" : "https:\/\/t.co\/wGSHkGZkJB",
      "expanded_url" : "https:\/\/instagram.com\/p\/9Bb-xUhwiE\/",
      "display_url" : "instagram.com\/p\/9Bb-xUhwiE\/"
    } ]
  },
  "geo" : { },
  "id_str" : "656114032127164416",
  "text" : "Python https:\/\/t.co\/wGSHkGZkJB",
  "id" : 656114032127164416,
  "created_at" : "2015-10-19 14:25:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 48 ],
      "url" : "https:\/\/t.co\/d2ZmvDObGX",
      "expanded_url" : "https:\/\/instagram.com\/p\/9A5bP6BwuX\/",
      "display_url" : "instagram.com\/p\/9A5bP6BwuX\/"
    } ]
  },
  "geo" : { },
  "id_str" : "656038043409895424",
  "text" : "Pythonistas behind bars. https:\/\/t.co\/d2ZmvDObGX",
  "id" : 656038043409895424,
  "created_at" : "2015-10-19 09:23:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "656032899901366272",
  "text" : "always happy to hear about how ornithologists are integrating citizen science in data collection and for local expertise.",
  "id" : 656032899901366272,
  "created_at" : "2015-10-19 09:03:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : ".",
      "screen_name" : "punkish",
      "indices" : [ 0, 8 ],
      "id_str" : "15322269",
      "id" : 15322269
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "656020732007350272",
  "geo" : { },
  "id_str" : "656020864287289344",
  "in_reply_to_user_id" : 15322269,
  "text" : "@punkish i think they have to practice every day in order to not hurt themselves!",
  "id" : 656020864287289344,
  "in_reply_to_status_id" : 656020732007350272,
  "created_at" : "2015-10-19 08:15:36 +0000",
  "in_reply_to_screen_name" : "punkish",
  "in_reply_to_user_id_str" : "15322269",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 39 ],
      "url" : "https:\/\/t.co\/P91DnY7JOb",
      "expanded_url" : "https:\/\/instagram.com\/p\/9Aw6dhhwlk\/",
      "display_url" : "instagram.com\/p\/9Aw6dhhwlk\/"
    } ]
  },
  "geo" : { },
  "id_str" : "656019324000444416",
  "text" : "Weird Mushrooms https:\/\/t.co\/P91DnY7JOb",
  "id" : 656019324000444416,
  "created_at" : "2015-10-19 08:09:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "656012381047386112",
  "text" : "TIL: porcupines have sex even outside the breeding season. 8 times per day.",
  "id" : 656012381047386112,
  "created_at" : "2015-10-19 07:41:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "latergram",
      "indices" : [ 30, 40 ]
    } ],
    "urls" : [ {
      "indices" : [ 41, 64 ],
      "url" : "https:\/\/t.co\/NhR94hW9iL",
      "expanded_url" : "https:\/\/instagram.com\/p\/9Asa4MBwgx\/",
      "display_url" : "instagram.com\/p\/9Asa4MBwgx\/"
    } ]
  },
  "geo" : { },
  "id_str" : "656009444074102785",
  "text" : "Late night drink preparation. #latergram https:\/\/t.co\/NhR94hW9iL",
  "id" : 656009444074102785,
  "created_at" : "2015-10-19 07:30:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 37, 46 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "656006280264466432",
  "text" : "Spending the morning watching birds. @Senficon will be sad when she hears my species count for our not-so-big year.",
  "id" : 656006280264466432,
  "created_at" : "2015-10-19 07:17:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/655873093840302080\/photo\/1",
      "indices" : [ 48, 70 ],
      "url" : "http:\/\/t.co\/nXHmkoy6GD",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CRohF8OWUAAG0h6.jpg",
      "id_str" : "655873081685200896",
      "id" : 655873081685200896,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CRohF8OWUAAG0h6.jpg",
      "sizes" : [ {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2448,
        "resize" : "fit",
        "w" : 3264
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/nXHmkoy6GD"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "655873093840302080",
  "text" : "I have seen things you humans wouldn\u2019t believe\u2026 http:\/\/t.co\/nXHmkoy6GD",
  "id" : 655873093840302080,
  "created_at" : "2015-10-18 22:28:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "himbeerkomplott",
      "screen_name" : "raspberryperson",
      "indices" : [ 0, 16 ],
      "id_str" : "2841131495",
      "id" : 2841131495
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "655866733094420481",
  "geo" : { },
  "id_str" : "655869886615396352",
  "in_reply_to_user_id" : 2841131495,
  "text" : "@raspberryperson the goldilocks turtles :3",
  "id" : 655869886615396352,
  "in_reply_to_status_id" : 655866733094420481,
  "created_at" : "2015-10-18 22:15:41 +0000",
  "in_reply_to_screen_name" : "raspberryperson",
  "in_reply_to_user_id_str" : "2841131495",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "655837990145642496",
  "text" : "Smart-ass level: correcting Hebrew grammar of an Israeli.",
  "id" : 655837990145642496,
  "created_at" : "2015-10-18 20:08:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "655803112322637829",
  "text" : "\u00ABOh no, my freezer keeps calling me!\u00BB Biologists, having the Internet of Things for their freezers for quite a while already.",
  "id" : 655803112322637829,
  "created_at" : "2015-10-18 17:50:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "655739978702528512",
  "text" : "\u00ABI advise students: work on turtles if you want to do fieldwork. they wake up late, go to bed early and don\u2019t like it too cold or hot.\u00BB",
  "id" : 655739978702528512,
  "created_at" : "2015-10-18 13:39:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "655738639473840128",
  "text" : "\u00ABGlobal temperatures are rising. And as we all know \u2013 and have to write in every grant \u2013 animals are feeling the effects.\u00BB",
  "id" : 655738639473840128,
  "created_at" : "2015-10-18 13:34:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Esther Dyson",
      "screen_name" : "edyson",
      "indices" : [ 3, 10 ],
      "id_str" : "15921173",
      "id" : 15921173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/PXvECfGr1d",
      "expanded_url" : "http:\/\/www.mcsweeneys.net\/articles\/an-interactive-guide-to-ambiguous-grammar#.ViOZRZDZmQE.twitter",
      "display_url" : "mcsweeneys.net\/articles\/an-in\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "655738406388002816",
  "text" : "RT @edyson: How to make a formal statement without saying anything - read to to the end. \nhttp:\/\/t.co\/PXvECfGr1d",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 78, 100 ],
        "url" : "http:\/\/t.co\/PXvECfGr1d",
        "expanded_url" : "http:\/\/www.mcsweeneys.net\/articles\/an-interactive-guide-to-ambiguous-grammar#.ViOZRZDZmQE.twitter",
        "display_url" : "mcsweeneys.net\/articles\/an-in\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "655734269562765312",
    "text" : "How to make a formal statement without saying anything - read to to the end. \nhttp:\/\/t.co\/PXvECfGr1d",
    "id" : 655734269562765312,
    "created_at" : "2015-10-18 13:16:47 +0000",
    "user" : {
      "name" : "Esther Dyson",
      "screen_name" : "edyson",
      "protected" : false,
      "id_str" : "15921173",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/474207333111705601\/GYvWOPew_normal.jpeg",
      "id" : 15921173,
      "verified" : false
    }
  },
  "id" : 655738406388002816,
  "created_at" : "2015-10-18 13:33:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "655713102831460352",
  "text" : "\u00ABFor sit-and-prey predators it\u2019s arguable whether the animal is hunting or just resting.\u00BB",
  "id" : 655713102831460352,
  "created_at" : "2015-10-18 11:52:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/KmBBSX01vf",
      "expanded_url" : "https:\/\/instagram.com\/p\/8-j25DhwiL\/",
      "display_url" : "instagram.com\/p\/8-j25DhwiL\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 32.112472984, 34.80396977 ]
  },
  "id_str" : "655709139562315776",
  "text" : "oh my love, is that a vulture? @ Tel Aviv University | \u05D0\u05D5\u05E0\u05D9\u05D1\u05E8\u05E1\u05D9\u05D8\u05EA \u05EA\u05DC-\u05D0\u05D1\u05D9\u05D1 https:\/\/t.co\/KmBBSX01vf",
  "id" : 655709139562315776,
  "created_at" : "2015-10-18 11:36:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert",
      "screen_name" : "kventil",
      "indices" : [ 0, 8 ],
      "id_str" : "7431192",
      "id" : 7431192
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 9, 15 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "655680341584257024",
  "geo" : { },
  "id_str" : "655680441534521344",
  "in_reply_to_user_id" : 7431192,
  "text" : "@kventil @Lobot das war leider als der Christian Metal lief ;)",
  "id" : 655680441534521344,
  "in_reply_to_status_id" : 655680341584257024,
  "created_at" : "2015-10-18 09:42:53 +0000",
  "in_reply_to_screen_name" : "kventil",
  "in_reply_to_user_id_str" : "7431192",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rob Davidson",
      "screen_name" : "bobbledavidson",
      "indices" : [ 0, 15 ],
      "id_str" : "20198007",
      "id" : 20198007
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "655678913448771584",
  "geo" : { },
  "id_str" : "655680310210883584",
  "in_reply_to_user_id" : 20198007,
  "text" : "@bobbledavidson look at the geotag ;)",
  "id" : 655680310210883584,
  "in_reply_to_status_id" : 655678913448771584,
  "created_at" : "2015-10-18 09:42:22 +0000",
  "in_reply_to_screen_name" : "bobbledavidson",
  "in_reply_to_user_id_str" : "20198007",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael R. Crusoe",
      "screen_name" : "biocrusoe",
      "indices" : [ 0, 10 ],
      "id_str" : "17645638",
      "id" : 17645638
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "655678200392077312",
  "geo" : { },
  "id_str" : "655680224651292672",
  "in_reply_to_user_id" : 17645638,
  "text" : "@biocrusoe pretty comfy actually, but as the doors are open it\u2019s easy to say. :)",
  "id" : 655680224651292672,
  "in_reply_to_status_id" : 655678200392077312,
  "created_at" : "2015-10-18 09:42:02 +0000",
  "in_reply_to_screen_name" : "biocrusoe",
  "in_reply_to_user_id_str" : "17645638",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert",
      "screen_name" : "kventil",
      "indices" : [ 0, 8 ],
      "id_str" : "7431192",
      "id" : 7431192
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 20, 26 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "655677199002017792",
  "geo" : { },
  "id_str" : "655680035563708417",
  "in_reply_to_user_id" : 7431192,
  "text" : "@kventil cool, dann @lobot endlich das Ende h\u00F6ren ;)",
  "id" : 655680035563708417,
  "in_reply_to_status_id" : 655677199002017792,
  "created_at" : "2015-10-18 09:41:17 +0000",
  "in_reply_to_screen_name" : "kventil",
  "in_reply_to_user_id_str" : "7431192",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert",
      "screen_name" : "kventil",
      "indices" : [ 0, 8 ],
      "id_str" : "7431192",
      "id" : 7431192
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "655676826426175488",
  "geo" : { },
  "id_str" : "655676913202151424",
  "in_reply_to_user_id" : 7431192,
  "text" : "@kventil ich wollte dir auch den andren artikel verlinken :)",
  "id" : 655676913202151424,
  "in_reply_to_status_id" : 655676826426175488,
  "created_at" : "2015-10-18 09:28:52 +0000",
  "in_reply_to_screen_name" : "kventil",
  "in_reply_to_user_id_str" : "7431192",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert",
      "screen_name" : "kventil",
      "indices" : [ 0, 8 ],
      "id_str" : "7431192",
      "id" : 7431192
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 42 ],
      "url" : "https:\/\/t.co\/0WsukgNx85",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/655300997858856960",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "655676432346148865",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 32.11350326026498, 34.80751419067381 ]
  },
  "id_str" : "655676652861673472",
  "in_reply_to_user_id" : 7431192,
  "text" : "@kventil yep, c.f. https:\/\/t.co\/0WsukgNx85 :)",
  "id" : 655676652861673472,
  "in_reply_to_status_id" : 655676432346148865,
  "created_at" : "2015-10-18 09:27:50 +0000",
  "in_reply_to_screen_name" : "kventil",
  "in_reply_to_user_id_str" : "7431192",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nyborg",
      "screen_name" : "ny_borg",
      "indices" : [ 0, 8 ],
      "id_str" : "570156398",
      "id" : 570156398
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "655676199809777664",
  "geo" : { },
  "id_str" : "655676468241014784",
  "in_reply_to_user_id" : 570156398,
  "text" : "@ny_borg nah, i think it\u2019s just a room that wasn\u2019t booked for obvious reasons ;)",
  "id" : 655676468241014784,
  "in_reply_to_status_id" : 655676199809777664,
  "created_at" : "2015-10-18 09:27:06 +0000",
  "in_reply_to_screen_name" : "ny_borg",
  "in_reply_to_user_id_str" : "570156398",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nyborg",
      "screen_name" : "ny_borg",
      "indices" : [ 0, 8 ],
      "id_str" : "570156398",
      "id" : 570156398
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "655675799438282752",
  "geo" : { },
  "id_str" : "655675975762583552",
  "in_reply_to_user_id" : 570156398,
  "text" : "@ny_borg no worries, it was the planned seminar room all along :)",
  "id" : 655675975762583552,
  "in_reply_to_status_id" : 655675799438282752,
  "created_at" : "2015-10-18 09:25:09 +0000",
  "in_reply_to_screen_name" : "ny_borg",
  "in_reply_to_user_id_str" : "570156398",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "655665207415558145",
  "text" : "how is it even possible to give a lecture about european &amp; middle-eastern swallows without mentioning the unladen airspeed velocity?!",
  "id" : 655665207415558145,
  "created_at" : "2015-10-18 08:42:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "655661902215958528",
  "text" : "there\u2019s a first time for everything. today: having lectures in a bomb shelter.",
  "id" : 655661902215958528,
  "created_at" : "2015-10-18 08:29:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/xsRAHs0HB2",
      "expanded_url" : "http:\/\/www.haaretz.com\/wwwMobileSite\/opinion\/.premium-1.680876?v=1AB44B4633BB2A5D834ED30350666BF0",
      "display_url" : "haaretz.com\/wwwMobileSite\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 32.080154, 34.767535 ]
  },
  "id_str" : "655611040521175040",
  "text" : "\u00ABIf I die in the current wave of terrorism, in talking about me, I want you to say that I refused to eat the hummus\u00BB http:\/\/t.co\/xsRAHs0HB2",
  "id" : 655611040521175040,
  "created_at" : "2015-10-18 05:07:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "655596531614142464",
  "text" : "Workshop Day 1: Going for a swim at dawn.",
  "id" : 655596531614142464,
  "created_at" : "2015-10-18 04:09:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "655499128177192962",
  "text" : "\u00ABYou speak Hebrew?\u00BB \u2013 \u00ABOnly the essentials, e.g. I can read whether something contains alcohol or not. By the way: don\u2019t drink that beer!\u00BB",
  "id" : 655499128177192962,
  "created_at" : "2015-10-17 21:42:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 57 ],
      "url" : "https:\/\/t.co\/W3F0uGyZn0",
      "expanded_url" : "https:\/\/instagram.com\/p\/88vsUlhwkL\/",
      "display_url" : "instagram.com\/p\/88vsUlhwkL\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 32.080253129, 34.766919361 ]
  },
  "id_str" : "655453690518720512",
  "text" : "Street Musicians @ Frishman Beach https:\/\/t.co\/W3F0uGyZn0",
  "id" : 655453690518720512,
  "created_at" : "2015-10-17 18:41:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "655431254813351936",
  "geo" : { },
  "id_str" : "655447229805797376",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot there aren\u2019t enough emoji to describe how good it was :3",
  "id" : 655447229805797376,
  "in_reply_to_status_id" : 655431254813351936,
  "created_at" : "2015-10-17 18:16:11 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "655426945786748928",
  "text" : "ODing on Hummus and Tahini.",
  "id" : 655426945786748928,
  "created_at" : "2015-10-17 16:55:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/655383837678137344\/photo\/1",
      "indices" : [ 27, 49 ],
      "url" : "http:\/\/t.co\/ZVC4XRS6R2",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CRhkHIEWsAAAp0d.png",
      "id_str" : "655383819370016768",
      "id" : 655383819370016768,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CRhkHIEWsAAAp0d.png",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 272
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 272
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 272
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 272
      } ],
      "display_url" : "pic.twitter.com\/ZVC4XRS6R2"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "655383837678137344",
  "text" : "Thermal Ecology in Action. http:\/\/t.co\/ZVC4XRS6R2",
  "id" : 655383837678137344,
  "created_at" : "2015-10-17 14:04:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    }, {
      "name" : "Parker Higgins, 1337 |-|",
      "screen_name" : "xor",
      "indices" : [ 22, 26 ],
      "id_str" : "24500377",
      "id" : 24500377
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "655374231216066560",
  "geo" : { },
  "id_str" : "655381842879762432",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon yes please! @xor",
  "id" : 655381842879762432,
  "in_reply_to_status_id" : 655374231216066560,
  "created_at" : "2015-10-17 13:56:22 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    }, {
      "name" : "Fiona Nielsen",
      "screen_name" : "glyn_dk",
      "indices" : [ 10, 18 ],
      "id_str" : "32340834",
      "id" : 32340834
    }, {
      "name" : "Parker Higgins, 1337 |-|",
      "screen_name" : "xor",
      "indices" : [ 46, 50 ],
      "id_str" : "24500377",
      "id" : 24500377
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "655372532330041344",
  "geo" : { },
  "id_str" : "655373931810017280",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon @glyn_dk bring some back. And bring @xor with you. Have to meet, as you speak so highly of him. :D",
  "id" : 655373931810017280,
  "in_reply_to_status_id" : 655372532330041344,
  "created_at" : "2015-10-17 13:24:56 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    }, {
      "name" : "Fiona Nielsen",
      "screen_name" : "glyn_dk",
      "indices" : [ 10, 18 ],
      "id_str" : "32340834",
      "id" : 32340834
    }, {
      "name" : "Parker Higgins, 1337 |-|",
      "screen_name" : "xor",
      "indices" : [ 19, 23 ],
      "id_str" : "24500377",
      "id" : 24500377
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "655369970210107392",
  "geo" : { },
  "id_str" : "655372353296297984",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon @glyn_dk @xor she\u2019s the reason I have a place to stay in HongKong. I guess that beats getting food :3",
  "id" : 655372353296297984,
  "in_reply_to_status_id" : 655369970210107392,
  "created_at" : "2015-10-17 13:18:39 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fiona Nielsen",
      "screen_name" : "glyn_dk",
      "indices" : [ 0, 8 ],
      "id_str" : "32340834",
      "id" : 32340834
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "655364228224851968",
  "geo" : { },
  "id_str" : "655364430981693440",
  "in_reply_to_user_id" : 32340834,
  "text" : "@glyn_dk thanks for making sure I don\u2019t have to camp under some bridge. :D",
  "id" : 655364430981693440,
  "in_reply_to_status_id" : 655364228224851968,
  "created_at" : "2015-10-17 12:47:11 +0000",
  "in_reply_to_screen_name" : "glyn_dk",
  "in_reply_to_user_id_str" : "32340834",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fiona Nielsen",
      "screen_name" : "glyn_dk",
      "indices" : [ 52, 60 ],
      "id_str" : "32340834",
      "id" : 32340834
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "655363908534947841",
  "text" : "You can\u2019t find a better conference travel mate than @glyn_dk!",
  "id" : 655363908534947841,
  "created_at" : "2015-10-17 12:45:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michelle N. Meyer",
      "screen_name" : "MichelleNMeyer",
      "indices" : [ 3, 18 ],
      "id_str" : "59518694",
      "id" : 59518694
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "655303234635059201",
  "text" : "RT @MichelleNMeyer: \u201CI died in Switzerland with Eternal Spirit on Monday 19 October 2015 and my funeral was on Friday 13 November 2015.\" ht\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/3Y5AOlLe7h",
        "expanded_url" : "https:\/\/twitter.com\/bioethicsuk\/status\/655142838582300673",
        "display_url" : "twitter.com\/bioethicsuk\/st\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "655158657202704384",
    "text" : "\u201CI died in Switzerland with Eternal Spirit on Monday 19 October 2015 and my funeral was on Friday 13 November 2015.\" https:\/\/t.co\/3Y5AOlLe7h",
    "id" : 655158657202704384,
    "created_at" : "2015-10-16 23:09:30 +0000",
    "user" : {
      "name" : "Michelle N. Meyer",
      "screen_name" : "MichelleNMeyer",
      "protected" : false,
      "id_str" : "59518694",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/660800998177415168\/uCbNVkPf_normal.jpg",
      "id" : 59518694,
      "verified" : false
    }
  },
  "id" : 655303234635059201,
  "created_at" : "2015-10-17 08:44:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/XB7zceWczE",
      "expanded_url" : "https:\/\/twitter.com\/PhilippBayer\/status\/655246088954212356",
      "display_url" : "twitter.com\/PhilippBayer\/s\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.04913210959572, 8.57673294851701 ]
  },
  "id_str" : "655300997858856960",
  "text" : "so basically law enforcement now can do more science with the data than scientists can do\u2026 https:\/\/t.co\/XB7zceWczE",
  "id" : 655300997858856960,
  "created_at" : "2015-10-17 08:35:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "655291740509876224",
  "geo" : { },
  "id_str" : "655294619975032832",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot Bat-simian?",
  "id" : 655294619975032832,
  "in_reply_to_status_id" : 655291740509876224,
  "created_at" : "2015-10-17 08:09:46 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "655291740509876224",
  "geo" : { },
  "id_str" : "655292795452825600",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot Batsian",
  "id" : 655292795452825600,
  "in_reply_to_status_id" : 655291740509876224,
  "created_at" : "2015-10-17 08:02:31 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0492559034366, 8.580189598176172 ]
  },
  "id_str" : "655288773970890752",
  "text" : "It\u2019s nice if you want to acknowledge me in your thesis. But maybe make at least sure you get my name right.",
  "id" : 655288773970890752,
  "created_at" : "2015-10-17 07:46:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "655287186334593024",
  "text" : "\u05D0\u05E0\u05D9 \u05D8\u05E1 \u05DC\u05EA\u05DC \u05D0\u05D1\u05D9\u05D1 \u05E2\u05DB\u05E9\u05D9\u05D5. \u05DE\u05D9\u05E9\u05D4\u05D5 \u05E8\u05D5\u05E6\u05D4 \u05E7\u05E4\u05D4 \u05D0\u05D9\u05EA\u05D9?",
  "id" : 655287186334593024,
  "created_at" : "2015-10-17 07:40:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "655128217397915648",
  "geo" : { },
  "id_str" : "655136538909646848",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot das kann ich ganz ohne additional chemical enhancement! \uD83C\uDF46\u264E\uFE0F",
  "id" : 655136538909646848,
  "in_reply_to_status_id" : 655128217397915648,
  "created_at" : "2015-10-16 21:41:37 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 63 ],
      "url" : "https:\/\/t.co\/YtWTFVFXW5",
      "expanded_url" : "https:\/\/twitter.com\/romanmars\/status\/655077583877378048",
      "display_url" : "twitter.com\/romanmars\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "655109043166560256",
  "text" : "The unofficial beautiful nerd passport? https:\/\/t.co\/YtWTFVFXW5",
  "id" : 655109043166560256,
  "created_at" : "2015-10-16 19:52:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 3, 12 ],
      "id_str" : "14245811",
      "id" : 14245811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "655053649572438017",
  "text" : "RT @wilbanks: Language in GBooks decision relevant to text mining - expression doesn\u2019t protect the facts. As we\u2019ve been saying. https:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/ZtdRzcHC7W",
        "expanded_url" : "https:\/\/twitter.com\/sarahjeong\/status\/655038801857806336",
        "display_url" : "twitter.com\/sarahjeong\/sta\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "655040486055550976",
    "text" : "Language in GBooks decision relevant to text mining - expression doesn\u2019t protect the facts. As we\u2019ve been saying. https:\/\/t.co\/ZtdRzcHC7W",
    "id" : 655040486055550976,
    "created_at" : "2015-10-16 15:19:56 +0000",
    "user" : {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "protected" : false,
      "id_str" : "14245811",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/925696899566440448\/BUTdp410_normal.jpg",
      "id" : 14245811,
      "verified" : false
    }
  },
  "id" : 655053649572438017,
  "created_at" : "2015-10-16 16:12:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mick Watson",
      "screen_name" : "BioMickWatson",
      "indices" : [ 3, 17 ],
      "id_str" : "228586748",
      "id" : 228586748
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/bF4OOjLyQQ",
      "expanded_url" : "http:\/\/www.genomebiology.com\/2015\/16\/1\/177",
      "display_url" : "genomebiology.com\/2015\/16\/1\/177"
    } ]
  },
  "geo" : { },
  "id_str" : "655049487451340800",
  "text" : "RT @BioMickWatson: Hey!  Just remember: your RNA-Seq results are probably wrong: http:\/\/t.co\/bF4OOjLyQQ\n\nHappy Friday!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 62, 84 ],
        "url" : "http:\/\/t.co\/bF4OOjLyQQ",
        "expanded_url" : "http:\/\/www.genomebiology.com\/2015\/16\/1\/177",
        "display_url" : "genomebiology.com\/2015\/16\/1\/177"
      } ]
    },
    "geo" : { },
    "id_str" : "654986430452776960",
    "text" : "Hey!  Just remember: your RNA-Seq results are probably wrong: http:\/\/t.co\/bF4OOjLyQQ\n\nHappy Friday!",
    "id" : 654986430452776960,
    "created_at" : "2015-10-16 11:45:08 +0000",
    "user" : {
      "name" : "Mick Watson",
      "screen_name" : "BioMickWatson",
      "protected" : false,
      "id_str" : "228586748",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/870214569679093760\/YIZGIDTS_normal.jpg",
      "id" : 228586748,
      "verified" : false
    }
  },
  "id" : 655049487451340800,
  "created_at" : "2015-10-16 15:55:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Science Web",
      "screen_name" : "TheScienceWeb",
      "indices" : [ 3, 17 ],
      "id_str" : "2315551122",
      "id" : 2315551122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/zfWV3uRkIt",
      "expanded_url" : "http:\/\/wp.me\/p4ik2k-5L",
      "display_url" : "wp.me\/p4ik2k-5L"
    } ]
  },
  "geo" : { },
  "id_str" : "655049067635023872",
  "text" : "RT @TheScienceWeb: Scientists sequence same thing on same machine many times and get same result http:\/\/t.co\/zfWV3uRkIt",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 78, 100 ],
        "url" : "http:\/\/t.co\/zfWV3uRkIt",
        "expanded_url" : "http:\/\/wp.me\/p4ik2k-5L",
        "display_url" : "wp.me\/p4ik2k-5L"
      } ]
    },
    "geo" : { },
    "id_str" : "655002891195928576",
    "text" : "Scientists sequence same thing on same machine many times and get same result http:\/\/t.co\/zfWV3uRkIt",
    "id" : 655002891195928576,
    "created_at" : "2015-10-16 12:50:33 +0000",
    "user" : {
      "name" : "The Science Web",
      "screen_name" : "TheScienceWeb",
      "protected" : false,
      "id_str" : "2315551122",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/428172546672824320\/1lZmC7lz_normal.jpeg",
      "id" : 2315551122,
      "verified" : false
    }
  },
  "id" : 655049067635023872,
  "created_at" : "2015-10-16 15:54:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "654971958296223744",
  "text" : "\u00ABDid you just catcall the dog?!\u00BB",
  "id" : 654971958296223744,
  "created_at" : "2015-10-16 10:47:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "liftbasel",
      "indices" : [ 64, 74 ]
    } ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/uPLSMGMyZj",
      "expanded_url" : "http:\/\/liftconference.com\/lift-basel-15",
      "display_url" : "liftconference.com\/lift-basel-15"
    } ]
  },
  "geo" : { },
  "id_str" : "654948390518792192",
  "text" : "And if you can\u2019t make it to Hong Kong: I\u2019ll also be speaking at #liftbasel at the end of this month. http:\/\/t.co\/uPLSMGMyZj",
  "id" : 654948390518792192,
  "created_at" : "2015-10-16 09:13:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GigaScience",
      "screen_name" : "GigaScience",
      "indices" : [ 19, 31 ],
      "id_str" : "208988759",
      "id" : 208988759
    }, {
      "name" : "DNAdigest.org",
      "screen_name" : "DNADigest",
      "indices" : [ 32, 42 ],
      "id_str" : "334912047",
      "id" : 334912047
    }, {
      "name" : "Repositive.io",
      "screen_name" : "repositiveio",
      "indices" : [ 44, 57 ],
      "id_str" : "3059929578",
      "id" : 3059929578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/PcbJvm9cGO",
      "expanded_url" : "https:\/\/www.eventbrite.hk\/e\/genome-hackathon-makerbay-tickets-18836695062?utm_content=buffer57d71&utm_medium=social&utm_source=twitter.com&utm_campaign=buffer",
      "display_url" : "eventbrite.hk\/e\/genome-hacka\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "654948001341943808",
  "text" : "You can still join @GigaScience @DNADigest, @repositiveio and me for our Hong Kong Genome Hackathon: https:\/\/t.co\/PcbJvm9cGO",
  "id" : 654948001341943808,
  "created_at" : "2015-10-16 09:12:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DNAdigest.org",
      "screen_name" : "DNADigest",
      "indices" : [ 0, 10 ],
      "id_str" : "334912047",
      "id" : 334912047
    }, {
      "name" : "openSNP team",
      "screen_name" : "openSNPorg",
      "indices" : [ 16, 27 ],
      "id_str" : "380205172",
      "id" : 380205172
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "654945145884946432",
  "geo" : { },
  "id_str" : "654946074575151104",
  "in_reply_to_user_id" : 334912047,
  "text" : "@DNADigest it\u2019s @opensnporg :)",
  "id" : 654946074575151104,
  "in_reply_to_status_id" : 654945145884946432,
  "created_at" : "2015-10-16 09:04:47 +0000",
  "in_reply_to_screen_name" : "DNADigest",
  "in_reply_to_user_id_str" : "334912047",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/GZvoWVRktN",
      "expanded_url" : "https:\/\/twitter.com\/BioMickWatson\/status\/654938311400759296",
      "display_url" : "twitter.com\/BioMickWatson\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "654939483863961600",
  "text" : "I think it\u2019s more like Star Trek: You basically do the same movie again and again and hope some are successful. https:\/\/t.co\/GZvoWVRktN",
  "id" : 654939483863961600,
  "created_at" : "2015-10-16 08:38:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ewen Callaway",
      "screen_name" : "ewencallaway",
      "indices" : [ 3, 16 ],
      "id_str" : "17251787",
      "id" : 17251787
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "654936275141730304",
  "text" : "RT @ewencallaway: For such a shitty, old film, Gattaca still gets a lot of play in science news. I for one would like to see more allusions\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "654933166222876672",
    "text" : "For such a shitty, old film, Gattaca still gets a lot of play in science news. I for one would like to see more allusions to Short Circuit",
    "id" : 654933166222876672,
    "created_at" : "2015-10-16 08:13:29 +0000",
    "user" : {
      "name" : "Ewen Callaway",
      "screen_name" : "ewencallaway",
      "protected" : false,
      "id_str" : "17251787",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/905426585880289282\/-Fg5BkEr_normal.jpg",
      "id" : 17251787,
      "verified" : true
    }
  },
  "id" : 654936275141730304,
  "created_at" : "2015-10-16 08:25:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    }, {
      "name" : "\uD83D\uDCABKelsey Merkley \uD83D\uDCAB",
      "screen_name" : "bella_velo",
      "indices" : [ 10, 21 ],
      "id_str" : "6745972",
      "id" : 6745972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "654926080181186560",
  "geo" : { },
  "id_str" : "654926588694409216",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon @bella_velo the good thing is: being a politician isn\u2019t among those things \uD83D\uDE09",
  "id" : 654926588694409216,
  "in_reply_to_status_id" : 654926080181186560,
  "created_at" : "2015-10-16 07:47:21 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael R. Crusoe",
      "screen_name" : "biocrusoe",
      "indices" : [ 0, 10 ],
      "id_str" : "17645638",
      "id" : 17645638
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "654926107741962240",
  "geo" : { },
  "id_str" : "654926329528360960",
  "in_reply_to_user_id" : 17645638,
  "text" : "@biocrusoe ah, snap. I really should open those g+ notifications from time to time :D",
  "id" : 654926329528360960,
  "in_reply_to_status_id" : 654926107741962240,
  "created_at" : "2015-10-16 07:46:19 +0000",
  "in_reply_to_screen_name" : "biocrusoe",
  "in_reply_to_user_id_str" : "17645638",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael R. Crusoe",
      "screen_name" : "biocrusoe",
      "indices" : [ 0, 10 ],
      "id_str" : "17645638",
      "id" : 17645638
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "654925075121074176",
  "geo" : { },
  "id_str" : "654925757832155136",
  "in_reply_to_user_id" : 17645638,
  "text" : "@biocrusoe no, i didn\u2019t! where is it? :)",
  "id" : 654925757832155136,
  "in_reply_to_status_id" : 654925075121074176,
  "created_at" : "2015-10-16 07:44:03 +0000",
  "in_reply_to_screen_name" : "biocrusoe",
  "in_reply_to_user_id_str" : "17645638",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uD83D\uDCABKelsey Merkley \uD83D\uDCAB",
      "screen_name" : "bella_velo",
      "indices" : [ 0, 11 ],
      "id_str" : "6745972",
      "id" : 6745972
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 12, 21 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "654925315769131008",
  "geo" : { },
  "id_str" : "654925704245714945",
  "in_reply_to_user_id" : 6745972,
  "text" : "@bella_velo @Senficon that\u2019s a bit too much to say, but I\u2019m still proudly wearing the pin! doing another anthem-interpretation at opencon?",
  "id" : 654925704245714945,
  "in_reply_to_status_id" : 654925315769131008,
  "created_at" : "2015-10-16 07:43:50 +0000",
  "in_reply_to_screen_name" : "bella_velo",
  "in_reply_to_user_id_str" : "6745972",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael R. Crusoe",
      "screen_name" : "biocrusoe",
      "indices" : [ 0, 10 ],
      "id_str" : "17645638",
      "id" : 17645638
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "654924460424826880",
  "geo" : { },
  "id_str" : "654925036709654528",
  "in_reply_to_user_id" : 17645638,
  "text" : "@biocrusoe should even allow for easy co-locating for some projects. :)",
  "id" : 654925036709654528,
  "in_reply_to_status_id" : 654924460424826880,
  "created_at" : "2015-10-16 07:41:11 +0000",
  "in_reply_to_screen_name" : "biocrusoe",
  "in_reply_to_user_id_str" : "17645638",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    }, {
      "name" : "\uD83D\uDCABKelsey Merkley \uD83D\uDCAB",
      "screen_name" : "bella_velo",
      "indices" : [ 10, 21 ],
      "id_str" : "6745972",
      "id" : 6745972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "654924768530026496",
  "geo" : { },
  "id_str" : "654924946410504192",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon @bella_velo make that some whisky, but otherwise you are spot on. :D",
  "id" : 654924946410504192,
  "in_reply_to_status_id" : 654924768530026496,
  "created_at" : "2015-10-16 07:40:49 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael R. Crusoe",
      "screen_name" : "biocrusoe",
      "indices" : [ 0, 10 ],
      "id_str" : "17645638",
      "id" : 17645638
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "654804301370408960",
  "geo" : { },
  "id_str" : "654924056622403585",
  "in_reply_to_user_id" : 17645638,
  "text" : "@biocrusoe nice. That\u2019s really close :)",
  "id" : 654924056622403585,
  "in_reply_to_status_id" : 654804301370408960,
  "created_at" : "2015-10-16 07:37:17 +0000",
  "in_reply_to_screen_name" : "biocrusoe",
  "in_reply_to_user_id_str" : "17645638",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/6dra83rQaL",
      "expanded_url" : "https:\/\/33.media.tumblr.com\/tumblr_m982fmg6s41re8x6to1_500.gif",
      "display_url" : "33.media.tumblr.com\/tumblr_m982fmg\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "654922359435100160",
  "text" : "\u00ABi don\u2019t know how you\u2019d look like if you\u2019d get enough sleep.\u00BB i think i\u2019d look like: https:\/\/t.co\/6dra83rQaL",
  "id" : 654922359435100160,
  "created_at" : "2015-10-16 07:30:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/PypXnOPUAv",
      "expanded_url" : "http:\/\/journals.plos.org\/plosgenetics\/article?id=10.1371\/journal.pgen.1005548",
      "display_url" : "journals.plos.org\/plosgenetics\/a\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "654798370045726720",
  "text" : "\u00ABWe have an API, [\u2026] to enable people to pull down their data.\u00BB says Anne Wojcicki of 23andMe. Openwashing galore\u2026 http:\/\/t.co\/PypXnOPUAv",
  "id" : 654798370045726720,
  "created_at" : "2015-10-15 23:17:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/LnFK1eYTzz",
      "expanded_url" : "http:\/\/www.theatlantic.com\/science\/archive\/2015\/10\/the-many-myths-of-paleo-sleeping\/410707\/",
      "display_url" : "theatlantic.com\/science\/archiv\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "654793864960606209",
  "text" : "the problem when your story just sounds too nice: what you can learn from hunter-gatherers\u2019 sleep patterns  http:\/\/t.co\/LnFK1eYTzz",
  "id" : 654793864960606209,
  "created_at" : "2015-10-15 22:59:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 3, 12 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/m7C1ROzMFj",
      "expanded_url" : "http:\/\/www.mnn.com\/lifestyle\/arts-culture\/stories\/why-do-we-hate-things-teen-girls-love",
      "display_url" : "mnn.com\/lifestyle\/arts\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "654749332604784641",
  "text" : "RT @Senficon: Why must we hate the things teen girls love? http:\/\/t.co\/m7C1ROzMFj",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 45, 67 ],
        "url" : "http:\/\/t.co\/m7C1ROzMFj",
        "expanded_url" : "http:\/\/www.mnn.com\/lifestyle\/arts-culture\/stories\/why-do-we-hate-things-teen-girls-love",
        "display_url" : "mnn.com\/lifestyle\/arts\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "654746558173327360",
    "text" : "Why must we hate the things teen girls love? http:\/\/t.co\/m7C1ROzMFj",
    "id" : 654746558173327360,
    "created_at" : "2015-10-15 19:51:58 +0000",
    "user" : {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "protected" : false,
      "id_str" : "14861745",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/637016870638350336\/QrtPmoul_normal.jpg",
      "id" : 14861745,
      "verified" : true
    }
  },
  "id" : 654749332604784641,
  "created_at" : "2015-10-15 20:03:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 69 ],
      "url" : "https:\/\/t.co\/yqBr6o8j9j",
      "expanded_url" : "https:\/\/twitter.com\/wilbanks\/status\/654705891271315456",
      "display_url" : "twitter.com\/wilbanks\/statu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "654710857868296193",
  "text" : "Which beats the whole point of having an API. https:\/\/t.co\/yqBr6o8j9j",
  "id" : 654710857868296193,
  "created_at" : "2015-10-15 17:30:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 91 ],
      "url" : "https:\/\/t.co\/tQZY3A4dFM",
      "expanded_url" : "https:\/\/thewinnower.com\/papers\/2368-you-don-t-get-to-2000-open-data-sets-without-making-a-few-friends-or-how-i-got-to-be-called-the-mark-zuckerberg-of-open-source-genetics",
      "display_url" : "thewinnower.com\/papers\/2368-yo\u2026"
    }, {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/pwonBPb4Er",
      "expanded_url" : "https:\/\/twitter.com\/theWinnower\/status\/654631443478499328",
      "display_url" : "twitter.com\/theWinnower\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "654689776059088896",
  "text" : "This means: Leave a review here &amp; help me stop being broke-ish. https:\/\/t.co\/tQZY3A4dFM https:\/\/t.co\/pwonBPb4Er",
  "id" : 654689776059088896,
  "created_at" : "2015-10-15 16:06:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "654686533807566848",
  "text" : "spam that starts with \u2018enhance your\u2026\u2019 I somehow expected it to be sex-related. Instead it was \u2018enhance your transgenic mouse\u2019\u2026",
  "id" : 654686533807566848,
  "created_at" : "2015-10-15 15:53:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nathan Yau",
      "screen_name" : "flowingdata",
      "indices" : [ 3, 15 ],
      "id_str" : "14109167",
      "id" : 14109167
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/flowingdata\/status\/654329852611330048\/photo\/1",
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/txOQ2SjpJA",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CRSliKdUwAAMkaW.png",
      "id_str" : "654329852217049088",
      "id" : 654329852217049088,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CRSliKdUwAAMkaW.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 557,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1534,
        "resize" : "fit",
        "w" : 1874
      }, {
        "h" : 1534,
        "resize" : "fit",
        "w" : 1874
      }, {
        "h" : 982,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/txOQ2SjpJA"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 68 ],
      "url" : "http:\/\/t.co\/MlB4eIsOLz",
      "expanded_url" : "http:\/\/flowingdata.com\/2015\/10\/14\/work-counts\/",
      "display_url" : "flowingdata.com\/2015\/10\/14\/wor\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "654685557335855104",
  "text" : "RT @flowingdata: Counting the people who work http:\/\/t.co\/MlB4eIsOLz http:\/\/t.co\/txOQ2SjpJA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/flowingdata\/status\/654329852611330048\/photo\/1",
        "indices" : [ 52, 74 ],
        "url" : "http:\/\/t.co\/txOQ2SjpJA",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CRSliKdUwAAMkaW.png",
        "id_str" : "654329852217049088",
        "id" : 654329852217049088,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CRSliKdUwAAMkaW.png",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 557,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1534,
          "resize" : "fit",
          "w" : 1874
        }, {
          "h" : 1534,
          "resize" : "fit",
          "w" : 1874
        }, {
          "h" : 982,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/txOQ2SjpJA"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 29, 51 ],
        "url" : "http:\/\/t.co\/MlB4eIsOLz",
        "expanded_url" : "http:\/\/flowingdata.com\/2015\/10\/14\/work-counts\/",
        "display_url" : "flowingdata.com\/2015\/10\/14\/wor\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "654329852611330048",
    "text" : "Counting the people who work http:\/\/t.co\/MlB4eIsOLz http:\/\/t.co\/txOQ2SjpJA",
    "id" : 654329852611330048,
    "created_at" : "2015-10-14 16:16:08 +0000",
    "user" : {
      "name" : "Nathan Yau",
      "screen_name" : "flowingdata",
      "protected" : false,
      "id_str" : "14109167",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/907718661711867904\/iqgbgxhD_normal.jpg",
      "id" : 14109167,
      "verified" : true
    }
  },
  "id" : 654685557335855104,
  "created_at" : "2015-10-15 15:49:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 78 ],
      "url" : "https:\/\/t.co\/fesL9PO4Zg",
      "expanded_url" : "https:\/\/twitter.com\/genetics_blog\/status\/654655794466557952",
      "display_url" : "twitter.com\/genetics_blog\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "654678911658258433",
  "text" : "I can\u2019t way for the first \u2018gay psychopathome\u2019 studies\u2026 https:\/\/t.co\/fesL9PO4Zg",
  "id" : 654678911658258433,
  "created_at" : "2015-10-15 15:23:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/iysmKOPUo4",
      "expanded_url" : "http:\/\/cdn.ymaservices.com\/editorial_service\/media\/images\/000\/086\/737\/compressed\/ezgif.com-resize.gif?1424367694",
      "display_url" : "cdn.ymaservices.com\/editorial_serv\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "654676831702904832",
  "text" : "i love how the office is buzzing when deadlines are approaching. am i a bad person? http:\/\/t.co\/iysmKOPUo4",
  "id" : 654676831702904832,
  "created_at" : "2015-10-15 15:14:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Edmunds",
      "screen_name" : "SCEdmunds",
      "indices" : [ 3, 13 ],
      "id_str" : "176024190",
      "id" : 176024190
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 72 ],
      "url" : "https:\/\/t.co\/awBOdtqxf0",
      "expanded_url" : "https:\/\/twitter.com\/NewYorker\/status\/654549687605821440",
      "display_url" : "twitter.com\/NewYorker\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "654578735304282112",
  "text" : "RT @SCEdmunds: Incredible film. Incredible guy.  https:\/\/t.co\/awBOdtqxf0",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 34, 57 ],
        "url" : "https:\/\/t.co\/awBOdtqxf0",
        "expanded_url" : "https:\/\/twitter.com\/NewYorker\/status\/654549687605821440",
        "display_url" : "twitter.com\/NewYorker\/stat\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "654550541687648257",
    "text" : "Incredible film. Incredible guy.  https:\/\/t.co\/awBOdtqxf0",
    "id" : 654550541687648257,
    "created_at" : "2015-10-15 06:53:04 +0000",
    "user" : {
      "name" : "Scott Edmunds",
      "screen_name" : "SCEdmunds",
      "protected" : false,
      "id_str" : "176024190",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1098248807\/chess_normal.JPG",
      "id" : 176024190,
      "verified" : false
    }
  },
  "id" : 654578735304282112,
  "created_at" : "2015-10-15 08:45:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katharine Viner",
      "screen_name" : "KathViner",
      "indices" : [ 3, 13 ],
      "id_str" : "27212264",
      "id" : 27212264
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/9DKHMQmueM",
      "expanded_url" : "http:\/\/gu.com\/p\/4dapy\/stw",
      "display_url" : "gu.com\/p\/4dapy\/stw"
    } ]
  },
  "geo" : { },
  "id_str" : "654578472451506176",
  "text" : "RT @KathViner: 'Homeland is racist': artists sneak subversive graffiti on to TV show http:\/\/t.co\/9DKHMQmueM",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 70, 92 ],
        "url" : "http:\/\/t.co\/9DKHMQmueM",
        "expanded_url" : "http:\/\/gu.com\/p\/4dapy\/stw",
        "display_url" : "gu.com\/p\/4dapy\/stw"
      } ]
    },
    "geo" : { },
    "id_str" : "654548192193826816",
    "text" : "'Homeland is racist': artists sneak subversive graffiti on to TV show http:\/\/t.co\/9DKHMQmueM",
    "id" : 654548192193826816,
    "created_at" : "2015-10-15 06:43:44 +0000",
    "user" : {
      "name" : "Katharine Viner",
      "screen_name" : "KathViner",
      "protected" : false,
      "id_str" : "27212264",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/612008735905574913\/-nQeaPiv_normal.jpg",
      "id" : 27212264,
      "verified" : true
    }
  },
  "id" : 654578472451506176,
  "created_at" : "2015-10-15 08:44:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Edmunds",
      "screen_name" : "SCEdmunds",
      "indices" : [ 0, 10 ],
      "id_str" : "176024190",
      "id" : 176024190
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "654550541687648257",
  "geo" : { },
  "id_str" : "654578137464971264",
  "in_reply_to_user_id" : 176024190,
  "text" : "@SCEdmunds aye, just saw Taxi last week. :)",
  "id" : 654578137464971264,
  "in_reply_to_status_id" : 654550541687648257,
  "created_at" : "2015-10-15 08:42:44 +0000",
  "in_reply_to_screen_name" : "SCEdmunds",
  "in_reply_to_user_id_str" : "176024190",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 10, 16 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 46 ],
      "url" : "http:\/\/t.co\/YLIwCw4akL",
      "expanded_url" : "http:\/\/www.klasse-umweltgestaltung.de\/index.php\/margarita-khomenker-zwischen-vergangenheit-und-gegenwart.html",
      "display_url" : "klasse-umweltgestaltung.de\/index.php\/marg\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "654573936303316992",
  "geo" : { },
  "id_str" : "654576065386577920",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich @Lobot indeed http:\/\/t.co\/YLIwCw4akL Umweg \u00FCber die Google Bildersuche + my abysmal hebrew :D",
  "id" : 654576065386577920,
  "in_reply_to_status_id" : 654573936303316992,
  "created_at" : "2015-10-15 08:34:30 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    }, {
      "name" : "\uD83D\uDCA5#BurnItDownSis\uD83D\uDCA5",
      "screen_name" : "DoraKristina",
      "indices" : [ 10, 23 ],
      "id_str" : "359928088",
      "id" : 359928088
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "654573179474706432",
  "geo" : { },
  "id_str" : "654575858078863360",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich @DoraKristina Ist \u201E\u05DE\u05D2\u05E0\u05E6\u05D0\u201C -&gt; Magenza :)",
  "id" : 654575858078863360,
  "in_reply_to_status_id" : 654573179474706432,
  "created_at" : "2015-10-15 08:33:40 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    }, {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 7, 16 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "654565064301744128",
  "geo" : { },
  "id_str" : "654567485107236864",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot @JP_Stich ~ \u201Elicht der diaspora: synagoge mainz\u201C",
  "id" : 654567485107236864,
  "in_reply_to_status_id" : 654565064301744128,
  "created_at" : "2015-10-15 08:00:24 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Edmunds",
      "screen_name" : "SCEdmunds",
      "indices" : [ 0, 10 ],
      "id_str" : "176024190",
      "id" : 176024190
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "654549447083364352",
  "geo" : { },
  "id_str" : "654550286527299584",
  "in_reply_to_user_id" : 176024190,
  "text" : "@SCEdmunds I think it was 800 to 1000 words, so there's not much wiggle room. But thanks, looking forward to see how you will use it ;)",
  "id" : 654550286527299584,
  "in_reply_to_status_id" : 654549447083364352,
  "created_at" : "2015-10-15 06:52:03 +0000",
  "in_reply_to_screen_name" : "SCEdmunds",
  "in_reply_to_user_id_str" : "176024190",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Edmunds",
      "screen_name" : "SCEdmunds",
      "indices" : [ 0, 10 ],
      "id_str" : "176024190",
      "id" : 176024190
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "654544483590123520",
  "geo" : { },
  "id_str" : "654544857088806912",
  "in_reply_to_user_id" : 176024190,
  "text" : "@SCEdmunds yes, that would be a good idea, but was kind of hard to fit into the word limit. :)",
  "id" : 654544857088806912,
  "in_reply_to_status_id" : 654544483590123520,
  "created_at" : "2015-10-15 06:30:29 +0000",
  "in_reply_to_screen_name" : "SCEdmunds",
  "in_reply_to_user_id_str" : "176024190",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "beau",
      "screen_name" : "beaugunderson",
      "indices" : [ 0, 14 ],
      "id_str" : "5746882",
      "id" : 5746882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/YJHyBsBjD0",
      "expanded_url" : "https:\/\/github.com\/gedankenstuecke\/snpr\/issues\/179",
      "display_url" : "github.com\/gedankenstueck\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "654480490552954880",
  "geo" : { },
  "id_str" : "654544043624505344",
  "in_reply_to_user_id" : 5746882,
  "text" : "@beaugunderson the team is a bit mixed about it. I would love to see it, but compare https:\/\/t.co\/YJHyBsBjD0 :)",
  "id" : 654544043624505344,
  "in_reply_to_status_id" : 654480490552954880,
  "created_at" : "2015-10-15 06:27:15 +0000",
  "in_reply_to_screen_name" : "beaugunderson",
  "in_reply_to_user_id_str" : "5746882",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "beau",
      "screen_name" : "beaugunderson",
      "indices" : [ 0, 14 ],
      "id_str" : "5746882",
      "id" : 5746882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "654428705645719552",
  "geo" : { },
  "id_str" : "654428910202060800",
  "in_reply_to_user_id" : 5746882,
  "text" : "@beaugunderson absolutely, I wish some PGP would sequence me. \uD83D\uDE02",
  "id" : 654428910202060800,
  "in_reply_to_status_id" : 654428705645719552,
  "created_at" : "2015-10-14 22:49:45 +0000",
  "in_reply_to_screen_name" : "beaugunderson",
  "in_reply_to_user_id_str" : "5746882",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "beau",
      "screen_name" : "beaugunderson",
      "indices" : [ 3, 17 ],
      "id_str" : "5746882",
      "id" : 5746882
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 19, 35 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "654428758879928320",
  "text" : "RT @beaugunderson: @gedankenstuecke is FOMA 'fear of missing alleles'? ;)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 0, 16 ],
        "id_str" : "14286491",
        "id" : 14286491
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "654428511084613632",
    "geo" : { },
    "id_str" : "654428705645719552",
    "in_reply_to_user_id" : 14286491,
    "text" : "@gedankenstuecke is FOMA 'fear of missing alleles'? ;)",
    "id" : 654428705645719552,
    "in_reply_to_status_id" : 654428511084613632,
    "created_at" : "2015-10-14 22:48:56 +0000",
    "in_reply_to_screen_name" : "gedankenstuecke",
    "in_reply_to_user_id_str" : "14286491",
    "user" : {
      "name" : "beau",
      "screen_name" : "beaugunderson",
      "protected" : false,
      "id_str" : "5746882",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/913840034016399360\/pU3IIxqf_normal.jpg",
      "id" : 5746882,
      "verified" : false
    }
  },
  "id" : 654428758879928320,
  "created_at" : "2015-10-14 22:49:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "beau",
      "screen_name" : "beaugunderson",
      "indices" : [ 0, 14 ],
      "id_str" : "5746882",
      "id" : 5746882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "654426586310033408",
  "geo" : { },
  "id_str" : "654428511084613632",
  "in_reply_to_user_id" : 5746882,
  "text" : "@beaugunderson now I again suffer from FOMA because I only have my exome ;)",
  "id" : 654428511084613632,
  "in_reply_to_status_id" : 654426586310033408,
  "created_at" : "2015-10-14 22:48:10 +0000",
  "in_reply_to_screen_name" : "beaugunderson",
  "in_reply_to_user_id_str" : "5746882",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 74 ],
      "url" : "http:\/\/t.co\/Eoqw1OYDYQ",
      "expanded_url" : "http:\/\/publicdomainreview.org\/2015\/10\/14\/richard-spruce-and-the-trials-of-victorian-bryology\/",
      "display_url" : "publicdomainreview.org\/2015\/10\/14\/ric\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "654421611655876608",
  "text" : "Richard Spruce and the Trials of Victorian Bryology http:\/\/t.co\/Eoqw1OYDYQ",
  "id" : 654421611655876608,
  "created_at" : "2015-10-14 22:20:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ed Yong",
      "screen_name" : "edyong209",
      "indices" : [ 0, 10 ],
      "id_str" : "19767193",
      "id" : 19767193
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 55 ],
      "url" : "https:\/\/t.co\/bdwjvS1Qxm",
      "expanded_url" : "https:\/\/opensnp.org",
      "display_url" : "opensnp.org"
    } ]
  },
  "in_reply_to_status_id_str" : "654398693748142080",
  "geo" : { },
  "id_str" : "654411984969072640",
  "in_reply_to_user_id" : 19767193,
  "text" : "@edyong209 may we get a link to https:\/\/t.co\/bdwjvS1Qxm? :)",
  "id" : 654411984969072640,
  "in_reply_to_status_id" : 654398693748142080,
  "created_at" : "2015-10-14 21:42:30 +0000",
  "in_reply_to_screen_name" : "edyong209",
  "in_reply_to_user_id_str" : "19767193",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u24EA Rik Smith-Unna \uD83C\uDDF0\uD83C\uDDEA",
      "screen_name" : "blahah404",
      "indices" : [ 0, 10 ],
      "id_str" : "99173786",
      "id" : 99173786
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 11, 20 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "654409775023849472",
  "geo" : { },
  "id_str" : "654410062975365120",
  "in_reply_to_user_id" : 99173786,
  "text" : "@blahah404 @Senficon great, really looking forward to it! Also to discussing science if we get the chance :)",
  "id" : 654410062975365120,
  "in_reply_to_status_id" : 654409775023849472,
  "created_at" : "2015-10-14 21:34:52 +0000",
  "in_reply_to_screen_name" : "blahah404",
  "in_reply_to_user_id_str" : "99173786",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katha",
      "screen_name" : "kathakatze",
      "indices" : [ 0, 11 ],
      "id_str" : "541170257",
      "id" : 541170257
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "654394752109006848",
  "geo" : { },
  "id_str" : "654409096624517120",
  "in_reply_to_user_id" : 541170257,
  "text" : "@kathakatze strammstehen vor der Zeit? :3",
  "id" : 654409096624517120,
  "in_reply_to_status_id" : 654394752109006848,
  "created_at" : "2015-10-14 21:31:01 +0000",
  "in_reply_to_screen_name" : "kathakatze",
  "in_reply_to_user_id_str" : "541170257",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nyborg",
      "screen_name" : "ny_borg",
      "indices" : [ 0, 8 ],
      "id_str" : "570156398",
      "id" : 570156398
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "654391993502703616",
  "geo" : { },
  "id_str" : "654408397295632385",
  "in_reply_to_user_id" : 570156398,
  "text" : "@ny_borg safe travels, don\u2019t die :3",
  "id" : 654408397295632385,
  "in_reply_to_status_id" : 654391993502703616,
  "created_at" : "2015-10-14 21:28:14 +0000",
  "in_reply_to_screen_name" : "ny_borg",
  "in_reply_to_user_id_str" : "570156398",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    }, {
      "name" : "\u24EA Rik Smith-Unna \uD83C\uDDF0\uD83C\uDDEA",
      "screen_name" : "blahah404",
      "indices" : [ 10, 20 ],
      "id_str" : "99173786",
      "id" : 99173786
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MozFest",
      "indices" : [ 45, 53 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "654405006934835200",
  "geo" : { },
  "id_str" : "654405121414164482",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon @blahah404 hope we get a chance at #MozFest :)",
  "id" : 654405121414164482,
  "in_reply_to_status_id" : 654405006934835200,
  "created_at" : "2015-10-14 21:15:13 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    }, {
      "name" : "\u24EA Rik Smith-Unna \uD83C\uDDF0\uD83C\uDDEA",
      "screen_name" : "blahah404",
      "indices" : [ 21, 31 ],
      "id_str" : "99173786",
      "id" : 99173786
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "654391465989271552",
  "geo" : { },
  "id_str" : "654404879356723201",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon I will buy @blahah404 a beer in your name when we meet ;)",
  "id" : 654404879356723201,
  "in_reply_to_status_id" : 654391465989271552,
  "created_at" : "2015-10-14 21:14:16 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jun Axup",
      "screen_name" : "junaxup",
      "indices" : [ 0, 8 ],
      "id_str" : "19210703",
      "id" : 19210703
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "654374384153440256",
  "geo" : { },
  "id_str" : "654374631307145216",
  "in_reply_to_user_id" : 19210703,
  "text" : "@junaxup awesome!",
  "id" : 654374631307145216,
  "in_reply_to_status_id" : 654374384153440256,
  "created_at" : "2015-10-14 19:14:04 +0000",
  "in_reply_to_screen_name" : "junaxup",
  "in_reply_to_user_id_str" : "19210703",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jun Axup",
      "screen_name" : "junaxup",
      "indices" : [ 3, 11 ],
      "id_str" : "19210703",
      "id" : 19210703
    }, {
      "name" : "Sci Hack Day Dublin",
      "screen_name" : "SciHackDay_Dub",
      "indices" : [ 23, 38 ],
      "id_str" : "352367272",
      "id" : 352367272
    }, {
      "name" : "Science Hack Day",
      "screen_name" : "sciencehackday",
      "indices" : [ 47, 62 ],
      "id_str" : "134705572",
      "id" : 134705572
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "654374596418871296",
  "text" : "RT @junaxup: Following @SciHackDay_Dub's lead, @sciencehackday SF is also doing CHILDCARE and TRAVEL bursaries for our Oct event! http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Sci Hack Day Dublin",
        "screen_name" : "SciHackDay_Dub",
        "indices" : [ 10, 25 ],
        "id_str" : "352367272",
        "id" : 352367272
      }, {
        "name" : "Science Hack Day",
        "screen_name" : "sciencehackday",
        "indices" : [ 34, 49 ],
        "id_str" : "134705572",
        "id" : 134705572
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/QSJ93U6x0b",
        "expanded_url" : "http:\/\/sf.sciencehackday.org\/childcare-and-travel-bursaries\/",
        "display_url" : "sf.sciencehackday.org\/childcare-and-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "654374384153440256",
    "text" : "Following @SciHackDay_Dub's lead, @sciencehackday SF is also doing CHILDCARE and TRAVEL bursaries for our Oct event! http:\/\/t.co\/QSJ93U6x0b",
    "id" : 654374384153440256,
    "created_at" : "2015-10-14 19:13:05 +0000",
    "user" : {
      "name" : "Jun Axup",
      "screen_name" : "junaxup",
      "protected" : false,
      "id_str" : "19210703",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/893612721337282560\/p81RwmVK_normal.jpg",
      "id" : 19210703,
      "verified" : false
    }
  },
  "id" : 654374596418871296,
  "created_at" : "2015-10-14 19:13:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/JennyMartin_UQ\/status\/654364728521654272\/photo\/1",
      "indices" : [ 37, 59 ],
      "url" : "http:\/\/t.co\/7uMCJVmfb4",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CRTFMLPUYAAxvUk.jpg",
      "id_str" : "654364658841706496",
      "id" : 654364658841706496,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CRTFMLPUYAAxvUk.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/7uMCJVmfb4"
    } ],
    "hashtags" : [ {
      "text" : "WiSTEMspotlight",
      "indices" : [ 20, 36 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "654371729918312449",
  "text" : "RT @JennyMartin_UQ: #WiSTEMspotlight http:\/\/t.co\/7uMCJVmfb4",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/JennyMartin_UQ\/status\/654364728521654272\/photo\/1",
        "indices" : [ 17, 39 ],
        "url" : "http:\/\/t.co\/7uMCJVmfb4",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CRTFMLPUYAAxvUk.jpg",
        "id_str" : "654364658841706496",
        "id" : 654364658841706496,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CRTFMLPUYAAxvUk.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/7uMCJVmfb4"
      } ],
      "hashtags" : [ {
        "text" : "WiSTEMspotlight",
        "indices" : [ 0, 16 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 51.53564891647768, -0.1168453741398117 ]
    },
    "id_str" : "654364728521654272",
    "text" : "#WiSTEMspotlight http:\/\/t.co\/7uMCJVmfb4",
    "id" : 654364728521654272,
    "created_at" : "2015-10-14 18:34:43 +0000",
    "user" : {
      "name" : "Jenny Martin",
      "screen_name" : "Jenny_STEM",
      "protected" : false,
      "id_str" : "1607703990",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/827114378453331968\/n_Kd5whX_normal.jpg",
      "id" : 1607703990,
      "verified" : false
    }
  },
  "id" : 654371729918312449,
  "created_at" : "2015-10-14 19:02:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DNAdigest.org",
      "screen_name" : "DNADigest",
      "indices" : [ 84, 94 ],
      "id_str" : "334912047",
      "id" : 334912047
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/YyBrkJZ4T1",
      "expanded_url" : "https:\/\/twitter.com\/DNADigest\/status\/654353996338098176",
      "display_url" : "twitter.com\/DNADigest\/stat\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "654353996338098176",
  "geo" : { },
  "id_str" : "654369307862953988",
  "in_reply_to_user_id" : 334912047,
  "text" : "If (for whatever reason) you can\u2019t read enough about\/of me: I gave an interview for @DNADigest https:\/\/t.co\/YyBrkJZ4T1",
  "id" : 654369307862953988,
  "in_reply_to_status_id" : 654353996338098176,
  "created_at" : "2015-10-14 18:52:55 +0000",
  "in_reply_to_screen_name" : "DNADigest",
  "in_reply_to_user_id_str" : "334912047",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Deprecated - see @_sagesharp_",
      "screen_name" : "sarahsharp",
      "indices" : [ 3, 14 ],
      "id_str" : "922891160598732800",
      "id" : 922891160598732800
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/2DxRCxx5Bq",
      "expanded_url" : "http:\/\/sarah.thesharps.us\/2015\/10\/06\/what-makes-a-good-community\/",
      "display_url" : "sarah.thesharps.us\/2015\/10\/06\/wha\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "654366740969820161",
  "text" : "RT @sarahsharp: What makes a welcoming open source community?\nhttp:\/\/t.co\/2DxRCxx5Bq",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 46, 68 ],
        "url" : "http:\/\/t.co\/2DxRCxx5Bq",
        "expanded_url" : "http:\/\/sarah.thesharps.us\/2015\/10\/06\/what-makes-a-good-community\/",
        "display_url" : "sarah.thesharps.us\/2015\/10\/06\/wha\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "651385355321520129",
    "text" : "What makes a welcoming open source community?\nhttp:\/\/t.co\/2DxRCxx5Bq",
    "id" : 651385355321520129,
    "created_at" : "2015-10-06 13:15:45 +0000",
    "user" : {
      "name" : "Sage Sharp",
      "screen_name" : "_sagesharp_",
      "protected" : false,
      "id_str" : "14804579",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/927788526422212608\/pCvRUAYh_normal.jpg",
      "id" : 14804579,
      "verified" : false
    }
  },
  "id" : 654366740969820161,
  "created_at" : "2015-10-14 18:42:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/tQZY3AlP4m",
      "expanded_url" : "https:\/\/thewinnower.com\/papers\/2368-you-don-t-get-to-2000-open-data-sets-without-making-a-few-friends-or-how-i-got-to-be-called-the-mark-zuckerberg-of-open-source-genetics",
      "display_url" : "thewinnower.com\/papers\/2368-yo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "654365693840891904",
  "text" : "I would love to get some more post-publication peer review on my text about the benefits of open: https:\/\/t.co\/tQZY3AlP4m",
  "id" : 654365693840891904,
  "created_at" : "2015-10-14 18:38:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 4, 13 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/zRT89azcH7",
      "expanded_url" : "https:\/\/twitter.com\/blahah404\/status\/654324822672064513",
      "display_url" : "twitter.com\/blahah404\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "654360049154965504",
  "text" : "Uh, @Senficon, you might want to click through those slides, you especially want to get to slide 10. :3 https:\/\/t.co\/zRT89azcH7",
  "id" : 654360049154965504,
  "created_at" : "2015-10-14 18:16:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 57 ],
      "url" : "http:\/\/t.co\/IQRqTNFdI3",
      "expanded_url" : "http:\/\/www.nature.com\/news\/kilogram-conflict-resolved-at-last-1.18550?WT.mc_id=TWT_NatureNews",
      "display_url" : "nature.com\/news\/kilogram-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "654287253737500673",
  "text" : "Kilogram conflict resolved at last http:\/\/t.co\/IQRqTNFdI3",
  "id" : 654287253737500673,
  "created_at" : "2015-10-14 13:26:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul-Olivier Dehaye",
      "screen_name" : "podehaye",
      "indices" : [ 0, 9 ],
      "id_str" : "2219841242",
      "id" : 2219841242
    }, {
      "name" : "DNA Land",
      "screen_name" : "dl1dl1",
      "indices" : [ 10, 17 ],
      "id_str" : "3178131275",
      "id" : 3178131275
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "654280904890806272",
  "geo" : { },
  "id_str" : "654281435923251200",
  "in_reply_to_user_id" : 2219841242,
  "text" : "@podehaye @dl1dl1 You mean instead of just asking participants whether they would be willing to share that data?",
  "id" : 654281435923251200,
  "in_reply_to_status_id" : 654280904890806272,
  "created_at" : "2015-10-14 13:03:44 +0000",
  "in_reply_to_screen_name" : "podehaye",
  "in_reply_to_user_id_str" : "2219841242",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "J\u00FCrgen Geuter",
      "screen_name" : "tante",
      "indices" : [ 0, 6 ],
      "id_str" : "14179278",
      "id" : 14179278
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "654272023137505281",
  "geo" : { },
  "id_str" : "654272415099416577",
  "in_reply_to_user_id" : 14179278,
  "text" : "@tante but even if BMI was a more valid measurement. discussion \u00B1 says \u201Ehumans still outperform algorithms when it comes to fatshaming\u201C\u2026",
  "id" : 654272415099416577,
  "in_reply_to_status_id" : 654272023137505281,
  "created_at" : "2015-10-14 12:27:54 +0000",
  "in_reply_to_screen_name" : "tante",
  "in_reply_to_user_id_str" : "14179278",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/7FIkoH3Hor",
      "expanded_url" : "http:\/\/journals.plos.org\/plosone\/article?id=10.1371\/journal.pone.0140347",
      "display_url" : "journals.plos.org\/plosone\/articl\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "654271827397713920",
  "text" : "Assessing BMI from Face Images. Even if the r2 wasn\u2019t so abysmal I\u2019d be unsure why you\u2019d even want that\u2026 http:\/\/t.co\/7FIkoH3Hor",
  "id" : 654271827397713920,
  "created_at" : "2015-10-14 12:25:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthew Herper",
      "screen_name" : "matthewherper",
      "indices" : [ 3, 17 ],
      "id_str" : "44438256",
      "id" : 44438256
    }, {
      "name" : "23andMe",
      "screen_name" : "23andMe",
      "indices" : [ 34, 42 ],
      "id_str" : "14738561",
      "id" : 14738561
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "654269788148101120",
  "text" : "RT @matthewherper: Here comes the @23andme comeback. The company just raised $115 million, and has plans to reach consumers once again. htt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "23andMe",
        "screen_name" : "23andMe",
        "indices" : [ 15, 23 ],
        "id_str" : "14738561",
        "id" : 14738561
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/KcQ2cn0LQM",
        "expanded_url" : "http:\/\/onforb.es\/1jyFlB4",
        "display_url" : "onforb.es\/1jyFlB4"
      } ]
    },
    "geo" : { },
    "id_str" : "654266375410728960",
    "text" : "Here comes the @23andme comeback. The company just raised $115 million, and has plans to reach consumers once again. http:\/\/t.co\/KcQ2cn0LQM",
    "id" : 654266375410728960,
    "created_at" : "2015-10-14 12:03:54 +0000",
    "user" : {
      "name" : "Matthew Herper",
      "screen_name" : "matthewherper",
      "protected" : false,
      "id_str" : "44438256",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/804670477939724288\/qMG4aBwA_normal.jpg",
      "id" : 44438256,
      "verified" : true
    }
  },
  "id" : 654269788148101120,
  "created_at" : "2015-10-14 12:17:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sophia Banks",
      "screen_name" : "sophiaphotos",
      "indices" : [ 3, 16 ],
      "id_str" : "474314181",
      "id" : 474314181
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/sophiaphotos\/status\/654107859593101312\/photo\/1",
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/9nzesSgNVg",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CRPbnawWUAAzI6G.jpg",
      "id_str" : "654107841142345728",
      "id" : 654107841142345728,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CRPbnawWUAAzI6G.jpg",
      "sizes" : [ {
        "h" : 1005,
        "resize" : "fit",
        "w" : 638
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1005,
        "resize" : "fit",
        "w" : 638
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 432
      }, {
        "h" : 1005,
        "resize" : "fit",
        "w" : 638
      } ],
      "display_url" : "pic.twitter.com\/9nzesSgNVg"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "654269400686698496",
  "text" : "RT @sophiaphotos: See how easy it is to gender a person properly. Correct a pronoun mistake. http:\/\/t.co\/9nzesSgNVg",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/sophiaphotos\/status\/654107859593101312\/photo\/1",
        "indices" : [ 75, 97 ],
        "url" : "http:\/\/t.co\/9nzesSgNVg",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CRPbnawWUAAzI6G.jpg",
        "id_str" : "654107841142345728",
        "id" : 654107841142345728,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CRPbnawWUAAzI6G.jpg",
        "sizes" : [ {
          "h" : 1005,
          "resize" : "fit",
          "w" : 638
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1005,
          "resize" : "fit",
          "w" : 638
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 432
        }, {
          "h" : 1005,
          "resize" : "fit",
          "w" : 638
        } ],
        "display_url" : "pic.twitter.com\/9nzesSgNVg"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "654107859593101312",
    "text" : "See how easy it is to gender a person properly. Correct a pronoun mistake. http:\/\/t.co\/9nzesSgNVg",
    "id" : 654107859593101312,
    "created_at" : "2015-10-14 01:34:01 +0000",
    "user" : {
      "name" : "Sophia Banks",
      "screen_name" : "sophiaphotos",
      "protected" : false,
      "id_str" : "474314181",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/864851880488427520\/Vk34CkId_normal.jpg",
      "id" : 474314181,
      "verified" : true
    }
  },
  "id" : 654269400686698496,
  "created_at" : "2015-10-14 12:15:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nazeefa",
      "screen_name" : "NazeefaFatima",
      "indices" : [ 0, 14 ],
      "id_str" : "37054704",
      "id" : 37054704
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "654262819479789568",
  "geo" : { },
  "id_str" : "654268322113036288",
  "in_reply_to_user_id" : 37054704,
  "text" : "@NazeefaFatima in older maps it\u2019s denoted as \u201Eacademia\u201C ;)",
  "id" : 654268322113036288,
  "in_reply_to_status_id" : 654262819479789568,
  "created_at" : "2015-10-14 12:11:38 +0000",
  "in_reply_to_screen_name" : "NazeefaFatima",
  "in_reply_to_user_id_str" : "37054704",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TJ \uD83D\uDC3E\uD83E\uDD89",
      "screen_name" : "theTJ23",
      "indices" : [ 0, 8 ],
      "id_str" : "622178855",
      "id" : 622178855
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "654267848907444224",
  "geo" : { },
  "id_str" : "654268104747450368",
  "in_reply_to_user_id" : 622178855,
  "text" : "@theTJ23 danke, mal schauen ob das klappt. Sonst geht\u2019s direkt drauf auch noch mal nach Hong Kong, die Vorhersage ist da z.Z. \u00E4hnlich :)",
  "id" : 654268104747450368,
  "in_reply_to_status_id" : 654267848907444224,
  "created_at" : "2015-10-14 12:10:46 +0000",
  "in_reply_to_screen_name" : "theTJ23",
  "in_reply_to_user_id_str" : "622178855",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TJ \uD83D\uDC3E\uD83E\uDD89",
      "screen_name" : "theTJ23",
      "indices" : [ 0, 8 ],
      "id_str" : "622178855",
      "id" : 622178855
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "654265018779848704",
  "geo" : { },
  "id_str" : "654265104935092224",
  "in_reply_to_user_id" : 622178855,
  "text" : "@theTJ23 tel aviv :)",
  "id" : 654265104935092224,
  "in_reply_to_status_id" : 654265018779848704,
  "created_at" : "2015-10-14 11:58:51 +0000",
  "in_reply_to_screen_name" : "theTJ23",
  "in_reply_to_user_id_str" : "622178855",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/654264793923235840\/photo\/1",
      "indices" : [ 53, 75 ],
      "url" : "http:\/\/t.co\/jk3Qfb8m0l",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CRRqXI9WgAAxJmk.png",
      "id_str" : "654264791649910784",
      "id" : 654264791649910784,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CRRqXI9WgAAxJmk.png",
      "sizes" : [ {
        "h" : 242,
        "resize" : "fit",
        "w" : 311
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 242,
        "resize" : "fit",
        "w" : 311
      }, {
        "h" : 242,
        "resize" : "fit",
        "w" : 311
      }, {
        "h" : 242,
        "resize" : "fit",
        "w" : 311
      } ],
      "display_url" : "pic.twitter.com\/jk3Qfb8m0l"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "654264793923235840",
  "text" : "The upcoming workshop will have its perks after all. http:\/\/t.co\/jk3Qfb8m0l",
  "id" : 654264793923235840,
  "created_at" : "2015-10-14 11:57:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 33 ],
      "url" : "https:\/\/t.co\/Z3amrotiUd",
      "expanded_url" : "https:\/\/twitter.com\/haaretzcom\/status\/654238995300265985",
      "display_url" : "twitter.com\/haaretzcom\/sta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "654261714368753664",
  "text" : "Nomnomnom https:\/\/t.co\/Z3amrotiUd",
  "id" : 654261714368753664,
  "created_at" : "2015-10-14 11:45:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "654261274520494080",
  "geo" : { },
  "id_str" : "654261508931776513",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot I can cope with that!",
  "id" : 654261508931776513,
  "in_reply_to_status_id" : 654261274520494080,
  "created_at" : "2015-10-14 11:44:33 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "654225440299700224",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17227374151737, 8.627549474018563 ]
  },
  "id_str" : "654236270365966336",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot gehen wir mal in den streichelzoo?",
  "id" : 654236270365966336,
  "in_reply_to_status_id" : 654225440299700224,
  "created_at" : "2015-10-14 10:04:16 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 91 ],
      "url" : "https:\/\/t.co\/qJRCbl0zQz",
      "expanded_url" : "https:\/\/apply.refline.ch\/673277\/0401\/pub\/1\/index.html",
      "display_url" : "apply.refline.ch\/673277\/0401\/pu\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722732776577, 8.627544015525414 ]
  },
  "id_str" : "654227411333197824",
  "text" : "if you wanna do a PhD in speciation genomics this might be for you: https:\/\/t.co\/qJRCbl0zQz",
  "id" : 654227411333197824,
  "created_at" : "2015-10-14 09:29:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "654223497242222597",
  "geo" : { },
  "id_str" : "654224600377753601",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot do want!",
  "id" : 654224600377753601,
  "in_reply_to_status_id" : 654223497242222597,
  "created_at" : "2015-10-14 09:17:54 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "654222990528356352",
  "geo" : { },
  "id_str" : "654224567188221952",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot I nearly wrote \u2018chicken-sexting\u2019 \uD83D\uDCF1\uD83D\uDC14",
  "id" : 654224567188221952,
  "in_reply_to_status_id" : 654222990528356352,
  "created_at" : "2015-10-14 09:17:46 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "654219963520184320",
  "geo" : { },
  "id_str" : "654220080226697216",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot is sheep-sorting similar to chicken-sexing?",
  "id" : 654220080226697216,
  "in_reply_to_status_id" : 654219963520184320,
  "created_at" : "2015-10-14 08:59:56 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "654217246210977792",
  "geo" : { },
  "id_str" : "654217479569448960",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot i will have to got back until one of those \uD83D\uDC11 allows me to pet it.",
  "id" : 654217479569448960,
  "in_reply_to_status_id" : 654217246210977792,
  "created_at" : "2015-10-14 08:49:36 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "654214801741213696",
  "geo" : { },
  "id_str" : "654215147284770816",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot recently all my okc matches have profile pictures showing them in Iceland, I think the algorithm is learning after all.",
  "id" : 654215147284770816,
  "in_reply_to_status_id" : 654214801741213696,
  "created_at" : "2015-10-14 08:40:20 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/ky8CSCRar1",
      "expanded_url" : "http:\/\/journals.plos.org\/plosone\/article?id=10.1371\/journal.pone.0140261",
      "display_url" : "journals.plos.org\/plosone\/articl\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "654214685089251328",
  "text" : "\u00AB\u2026feelings of hopelessness already in midlife may have long-term implications for cognitive health\u2026\u00BB http:\/\/t.co\/ky8CSCRar1",
  "id" : 654214685089251328,
  "created_at" : "2015-10-14 08:38:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : ".",
      "screen_name" : "punkish",
      "indices" : [ 0, 8 ],
      "id_str" : "15322269",
      "id" : 15322269
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "654206614694707200",
  "geo" : { },
  "id_str" : "654206769330286592",
  "in_reply_to_user_id" : 15322269,
  "text" : "@punkish yes, absolutely. i felt very flattered reading this.",
  "id" : 654206769330286592,
  "in_reply_to_status_id" : 654206614694707200,
  "created_at" : "2015-10-14 08:07:03 +0000",
  "in_reply_to_screen_name" : "punkish",
  "in_reply_to_user_id_str" : "15322269",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 48 ],
      "url" : "https:\/\/t.co\/vokaSIB5yN",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/652463484295323648",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "652463484295323648",
  "geo" : { },
  "id_str" : "654200987012476928",
  "in_reply_to_user_id" : 14286491,
  "text" : "I have to RT me on this: https:\/\/t.co\/vokaSIB5yN",
  "id" : 654200987012476928,
  "in_reply_to_status_id" : 652463484295323648,
  "created_at" : "2015-10-14 07:44:04 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arikia\uD83D\uDCAB",
      "screen_name" : "arikia",
      "indices" : [ 31, 38 ],
      "id_str" : "71654283",
      "id" : 71654283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/0000UQoez1",
      "expanded_url" : "http:\/\/thebirderandbiologist.blogspot.ca\/2015\/10\/noah-stryckers-global-year-world-record.html?m=1",
      "display_url" : "thebirderandbiologist.blogspot.ca\/2015\/10\/noah-s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "654188335703949313",
  "text" : "data viz porn for birders. \/cc @arikia http:\/\/t.co\/0000UQoez1",
  "id" : 654188335703949313,
  "created_at" : "2015-10-14 06:53:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 58 ],
      "url" : "https:\/\/t.co\/ZLnpH1EmWq",
      "expanded_url" : "https:\/\/opensnp.org\/",
      "display_url" : "opensnp.org"
    } ]
  },
  "geo" : { },
  "id_str" : "654187565021532160",
  "text" : "\u00ABBastian is one of the creators of https:\/\/t.co\/ZLnpH1EmWq, plays the guitar, &amp; is generally a hippie.\u00BB One of the nicest intros I ever got.",
  "id" : 654187565021532160,
  "created_at" : "2015-10-14 06:50:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arikia\uD83D\uDCAB",
      "screen_name" : "arikia",
      "indices" : [ 3, 10 ],
      "id_str" : "71654283",
      "id" : 71654283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/ChXworsUJy",
      "expanded_url" : "http:\/\/www.audubon.org\/news\/the-species-list",
      "display_url" : "audubon.org\/news\/the-speci\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "654065555062845440",
  "text" : "RT @arikia: Noah has been traveling for 286 days and has seen 4811 bird species (with only 3 no-bird days). http:\/\/t.co\/ChXworsUJy #XTREMEB\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "XTREMEBIRDING",
        "indices" : [ 119, 133 ]
      } ],
      "urls" : [ {
        "indices" : [ 96, 118 ],
        "url" : "http:\/\/t.co\/ChXworsUJy",
        "expanded_url" : "http:\/\/www.audubon.org\/news\/the-species-list",
        "display_url" : "audubon.org\/news\/the-speci\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "654063851441422337",
    "text" : "Noah has been traveling for 286 days and has seen 4811 bird species (with only 3 no-bird days). http:\/\/t.co\/ChXworsUJy #XTREMEBIRDING",
    "id" : 654063851441422337,
    "created_at" : "2015-10-13 22:39:08 +0000",
    "user" : {
      "name" : "Arikia\uD83D\uDCAB",
      "screen_name" : "arikia",
      "protected" : false,
      "id_str" : "71654283",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/897255084073025537\/5uB8YwJG_normal.jpg",
      "id" : 71654283,
      "verified" : false
    }
  },
  "id" : 654065555062845440,
  "created_at" : "2015-10-13 22:45:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nyborg",
      "screen_name" : "ny_borg",
      "indices" : [ 0, 8 ],
      "id_str" : "570156398",
      "id" : 570156398
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "654060366910091264",
  "geo" : { },
  "id_str" : "654060616378904576",
  "in_reply_to_user_id" : 570156398,
  "text" : "@ny_borg immerhin mal im gleichen Land :D",
  "id" : 654060616378904576,
  "in_reply_to_status_id" : 654060366910091264,
  "created_at" : "2015-10-13 22:26:17 +0000",
  "in_reply_to_screen_name" : "ny_borg",
  "in_reply_to_user_id_str" : "570156398",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nyborg",
      "screen_name" : "ny_borg",
      "indices" : [ 0, 8 ],
      "id_str" : "570156398",
      "id" : 570156398
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "654059817229778949",
  "geo" : { },
  "id_str" : "654060146402938880",
  "in_reply_to_user_id" : 570156398,
  "text" : "@ny_borg w\u00E4hrend der opencon dann vermutlich? \u2708\uFE0F",
  "id" : 654060146402938880,
  "in_reply_to_status_id" : 654059817229778949,
  "created_at" : "2015-10-13 22:24:25 +0000",
  "in_reply_to_screen_name" : "ny_borg",
  "in_reply_to_user_id_str" : "570156398",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nyborg",
      "screen_name" : "ny_borg",
      "indices" : [ 0, 8 ],
      "id_str" : "570156398",
      "id" : 570156398
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "654059620919570433",
  "geo" : { },
  "id_str" : "654059709243256832",
  "in_reply_to_user_id" : 570156398,
  "text" : "@ny_borg nope, da bin ich noch ein Shenzhen\/HongKong.",
  "id" : 654059709243256832,
  "in_reply_to_status_id" : 654059620919570433,
  "created_at" : "2015-10-13 22:22:41 +0000",
  "in_reply_to_screen_name" : "ny_borg",
  "in_reply_to_user_id_str" : "570156398",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nyborg",
      "screen_name" : "ny_borg",
      "indices" : [ 0, 8 ],
      "id_str" : "570156398",
      "id" : 570156398
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "654059261564166144",
  "geo" : { },
  "id_str" : "654059411586027524",
  "in_reply_to_user_id" : 570156398,
  "text" : "@ny_borg \u201Edemn\u00E4chst\u201C, ich glaube wir weilen erst Mitte November wieder auf dem gleichen Kontinent? :&gt;",
  "id" : 654059411586027524,
  "in_reply_to_status_id" : 654059261564166144,
  "created_at" : "2015-10-13 22:21:30 +0000",
  "in_reply_to_screen_name" : "ny_borg",
  "in_reply_to_user_id_str" : "570156398",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nyborg",
      "screen_name" : "ny_borg",
      "indices" : [ 0, 8 ],
      "id_str" : "570156398",
      "id" : 570156398
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 41 ],
      "url" : "https:\/\/t.co\/JQDZY0Agh4",
      "expanded_url" : "https:\/\/en.wikipedia.org\/wiki\/The_Book_of_Eli",
      "display_url" : "en.wikipedia.org\/wiki\/The_Book_\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "654059009687879680",
  "geo" : { },
  "id_str" : "654059143289008128",
  "in_reply_to_user_id" : 570156398,
  "text" : "@ny_borg nope. :) https:\/\/t.co\/JQDZY0Agh4",
  "id" : 654059143289008128,
  "in_reply_to_status_id" : 654059009687879680,
  "created_at" : "2015-10-13 22:20:26 +0000",
  "in_reply_to_screen_name" : "ny_borg",
  "in_reply_to_user_id_str" : "570156398",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nyborg",
      "screen_name" : "ny_borg",
      "indices" : [ 0, 8 ],
      "id_str" : "570156398",
      "id" : 570156398
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 31 ],
      "url" : "http:\/\/t.co\/VIhOmPZvsZ",
      "expanded_url" : "http:\/\/38.media.tumblr.com\/47ee8378cae4fefb3f81fa30de5beca9\/tumblr_mqpu99jfye1sofhfso2_250.gif",
      "display_url" : "38.media.tumblr.com\/47ee8378cae4fe\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "654056588802658304",
  "geo" : { },
  "id_str" : "654057694643519488",
  "in_reply_to_user_id" : 570156398,
  "text" : "@ny_borg http:\/\/t.co\/VIhOmPZvsZ",
  "id" : 654057694643519488,
  "in_reply_to_status_id" : 654056588802658304,
  "created_at" : "2015-10-13 22:14:40 +0000",
  "in_reply_to_screen_name" : "ny_borg",
  "in_reply_to_user_id_str" : "570156398",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Tasioulas",
      "screen_name" : "JTasioulas",
      "indices" : [ 3, 14 ],
      "id_str" : "707463510",
      "id" : 707463510
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "654032148962390017",
  "text" : "RT @JTasioulas: \"Broadening Bioethics\" by Onora O'Neill, a powerful case for going beyond individual rights to include public goods http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/qwRwv3TYkn",
        "expanded_url" : "http:\/\/nuffieldbioethics.org\/wp-content\/uploads\/Broadening_bioethics_clinical_ethics_public_health_global_health.pdf",
        "display_url" : "nuffieldbioethics.org\/wp-content\/upl\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "653594391580426240",
    "text" : "\"Broadening Bioethics\" by Onora O'Neill, a powerful case for going beyond individual rights to include public goods http:\/\/t.co\/qwRwv3TYkn",
    "id" : 653594391580426240,
    "created_at" : "2015-10-12 15:33:40 +0000",
    "user" : {
      "name" : "John Tasioulas",
      "screen_name" : "JTasioulas",
      "protected" : false,
      "id_str" : "707463510",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/926487720448237568\/J0yl5rZm_normal.jpg",
      "id" : 707463510,
      "verified" : true
    }
  },
  "id" : 654032148962390017,
  "created_at" : "2015-10-13 20:33:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/Tjo04dcP9c",
      "expanded_url" : "http:\/\/www.forbes.com\/sites\/matthewherper\/2015\/10\/13\/four-reasons-drugs-are-expensive-of-which-two-are-false\/",
      "display_url" : "forbes.com\/sites\/matthewh\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "654029153172365312",
  "text" : "a two cuppa long, but very worthy read: Four Reasons Drugs Are Expensive, Of Which Two Are False http:\/\/t.co\/Tjo04dcP9c",
  "id" : 654029153172365312,
  "created_at" : "2015-10-13 20:21:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Greg Wilson",
      "screen_name" : "gvwilson",
      "indices" : [ 3, 12 ],
      "id_str" : "21506708",
      "id" : 21506708
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 58 ],
      "url" : "http:\/\/t.co\/ETEOPfpvlW",
      "expanded_url" : "http:\/\/ebola.nextflu.org\/",
      "display_url" : "ebola.nextflu.org"
    } ]
  },
  "geo" : { },
  "id_str" : "654000861199380480",
  "text" : "RT @gvwilson: This is now possible: http:\/\/t.co\/ETEOPfpvlW",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 22, 44 ],
        "url" : "http:\/\/t.co\/ETEOPfpvlW",
        "expanded_url" : "http:\/\/ebola.nextflu.org\/",
        "display_url" : "ebola.nextflu.org"
      } ]
    },
    "geo" : { },
    "id_str" : "653997146992197633",
    "text" : "This is now possible: http:\/\/t.co\/ETEOPfpvlW",
    "id" : 653997146992197633,
    "created_at" : "2015-10-13 18:14:05 +0000",
    "user" : {
      "name" : "Greg Wilson",
      "screen_name" : "gvwilson",
      "protected" : false,
      "id_str" : "21506708",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/929161487507185665\/wQ99bMQv_normal.jpg",
      "id" : 21506708,
      "verified" : false
    }
  },
  "id" : 654000861199380480,
  "created_at" : "2015-10-13 18:28:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert",
      "screen_name" : "kventil",
      "indices" : [ 0, 8 ],
      "id_str" : "7431192",
      "id" : 7431192
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "653994759598546948",
  "geo" : { },
  "id_str" : "653996541401767936",
  "in_reply_to_user_id" : 7431192,
  "text" : "@kventil oh, das hatte ich auch gewollt \uD83D\uDE02\uD83D\uDC36",
  "id" : 653996541401767936,
  "in_reply_to_status_id" : 653994759598546948,
  "created_at" : "2015-10-13 18:11:40 +0000",
  "in_reply_to_screen_name" : "kventil",
  "in_reply_to_user_id_str" : "7431192",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert",
      "screen_name" : "kventil",
      "indices" : [ 0, 8 ],
      "id_str" : "7431192",
      "id" : 7431192
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "653987759909158915",
  "geo" : { },
  "id_str" : "653988820531183621",
  "in_reply_to_user_id" : 7431192,
  "text" : "@kventil kann sie beim n\u00E4chsten Podcast mitkommen? :3",
  "id" : 653988820531183621,
  "in_reply_to_status_id" : 653987759909158915,
  "created_at" : "2015-10-13 17:40:59 +0000",
  "in_reply_to_screen_name" : "kventil",
  "in_reply_to_user_id_str" : "7431192",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/N6VB7QphOp",
      "expanded_url" : "http:\/\/www.7deadlymag.com\/sex\/this-mushroom-gives-women-mind-blowing-orgasms-just-from-sniffing-it\/",
      "display_url" : "7deadlymag.com\/sex\/this-mushr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "653987564211318785",
  "text" : "If you are doing mycology you really have to try everything to lure people into your field. http:\/\/t.co\/N6VB7QphOp",
  "id" : 653987564211318785,
  "created_at" : "2015-10-13 17:36:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Keith Bradnam",
      "screen_name" : "ACGT_blog",
      "indices" : [ 3, 13 ],
      "id_str" : "3386600902",
      "id" : 3386600902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/4aDGiikssi",
      "expanded_url" : "http:\/\/buff.ly\/1hCyZ2d",
      "display_url" : "buff.ly\/1hCyZ2d"
    } ]
  },
  "geo" : { },
  "id_str" : "653979455417896961",
  "text" : "RT @ACGT_blog: New post: We have not yet reached 'peak CEGMA' http:\/\/t.co\/4aDGiikssi",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 47, 69 ],
        "url" : "http:\/\/t.co\/4aDGiikssi",
        "expanded_url" : "http:\/\/buff.ly\/1hCyZ2d",
        "display_url" : "buff.ly\/1hCyZ2d"
      } ]
    },
    "geo" : { },
    "id_str" : "653965567548878848",
    "text" : "New post: We have not yet reached 'peak CEGMA' http:\/\/t.co\/4aDGiikssi",
    "id" : 653965567548878848,
    "created_at" : "2015-10-13 16:08:36 +0000",
    "user" : {
      "name" : "Keith Bradnam",
      "screen_name" : "ACGT_blog",
      "protected" : false,
      "id_str" : "3386600902",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/664320067522301954\/5JbZDVSq_normal.png",
      "id" : 3386600902,
      "verified" : false
    }
  },
  "id" : 653979455417896961,
  "created_at" : "2015-10-13 17:03:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Fitzpatrick",
      "screen_name" : "therealfitz",
      "indices" : [ 3, 15 ],
      "id_str" : "14515931",
      "id" : 14515931
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "653978719564992513",
  "text" : "RT @therealfitz: I know that I always say \"never read the comments,\" but this is an exception. Read the comments. Now. https:\/\/t.co\/gHVwPMa\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 102, 125 ],
        "url" : "https:\/\/t.co\/gHVwPMaQOZ",
        "expanded_url" : "https:\/\/www.facebook.com\/mcmorrisrodgers\/photos\/a.405156824771.195673.321618789771\/10153225909544772\/?type=3&fref=nf",
        "display_url" : "facebook.com\/mcmorrisrodger\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "653968144629919744",
    "text" : "I know that I always say \"never read the comments,\" but this is an exception. Read the comments. Now. https:\/\/t.co\/gHVwPMaQOZ",
    "id" : 653968144629919744,
    "created_at" : "2015-10-13 16:18:50 +0000",
    "user" : {
      "name" : "Brian Fitzpatrick",
      "screen_name" : "therealfitz",
      "protected" : false,
      "id_str" : "14515931",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/803279158067347458\/I1idY7-N_normal.jpg",
      "id" : 14515931,
      "verified" : true
    }
  },
  "id" : 653978719564992513,
  "created_at" : "2015-10-13 17:00:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 75 ],
      "url" : "http:\/\/t.co\/YyYIXI8F1d",
      "expanded_url" : "http:\/\/existentialcomics.com\/comic\/102",
      "display_url" : "existentialcomics.com\/comic\/102"
    } ]
  },
  "geo" : { },
  "id_str" : "653975653721722880",
  "text" : "This is more or less my experience with board games. http:\/\/t.co\/YyYIXI8F1d",
  "id" : 653975653721722880,
  "created_at" : "2015-10-13 16:48:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 56 ],
      "url" : "http:\/\/t.co\/AzFbMUJHa1",
      "expanded_url" : "http:\/\/whatshouldwecallgradschool.tumblr.com\/post\/131040244639",
      "display_url" : "whatshouldwecallgradschool.tumblr.com\/post\/131040244\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "653975152351383552",
  "text" : "That never changes if you ask me. http:\/\/t.co\/AzFbMUJHa1",
  "id" : 653975152351383552,
  "created_at" : "2015-10-13 16:46:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "653919589772857344",
  "geo" : { },
  "id_str" : "653919924696543232",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer the barista are also safe.",
  "id" : 653919924696543232,
  "in_reply_to_status_id" : 653919589772857344,
  "created_at" : "2015-10-13 13:07:13 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sci Hack Day Dublin",
      "screen_name" : "SciHackDay_Dub",
      "indices" : [ 3, 18 ],
      "id_str" : "352367272",
      "id" : 352367272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/W356XLkpPD",
      "expanded_url" : "http:\/\/sciencehackdaydublin.com\/childcare-and-transport-bursaries\/",
      "display_url" : "sciencehackdaydublin.com\/childcare-and-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "653917828450545664",
  "text" : "RT @SciHackDay_Dub: We are SO EXCITED to announce our CHILDCARE and TRAVEL bursaries http:\/\/t.co\/W356XLkpPD\nPlease share! Also happy #AdaLo\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "AdaLovelaceDay",
        "indices" : [ 113, 128 ]
      } ],
      "urls" : [ {
        "indices" : [ 65, 87 ],
        "url" : "http:\/\/t.co\/W356XLkpPD",
        "expanded_url" : "http:\/\/sciencehackdaydublin.com\/childcare-and-transport-bursaries\/",
        "display_url" : "sciencehackdaydublin.com\/childcare-and-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "653903520727482368",
    "text" : "We are SO EXCITED to announce our CHILDCARE and TRAVEL bursaries http:\/\/t.co\/W356XLkpPD\nPlease share! Also happy #AdaLovelaceDay everyone!",
    "id" : 653903520727482368,
    "created_at" : "2015-10-13 12:02:02 +0000",
    "user" : {
      "name" : "Sci Hack Day Dublin",
      "screen_name" : "SciHackDay_Dub",
      "protected" : false,
      "id_str" : "352367272",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/625715671805108224\/GIZOfNhN_normal.png",
      "id" : 352367272,
      "verified" : false
    }
  },
  "id" : 653917828450545664,
  "created_at" : "2015-10-13 12:58:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "653903408034811904",
  "geo" : { },
  "id_str" : "653917547780263936",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer is there anything safe in bioinformatics? :D",
  "id" : 653917547780263936,
  "in_reply_to_status_id" : 653903408034811904,
  "created_at" : "2015-10-13 12:57:47 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "653834410610020352",
  "text" : "what\u2019s the cleverest way to add emoji-clock to the powerline?",
  "id" : 653834410610020352,
  "created_at" : "2015-10-13 07:27:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Manuel W\u00FCst",
      "screen_name" : "ManuelWuest",
      "indices" : [ 0, 12 ],
      "id_str" : "88493882",
      "id" : 88493882
    }, {
      "name" : "Walk off the Earth",
      "screen_name" : "WalkOffTheEarth",
      "indices" : [ 13, 29 ],
      "id_str" : "34027831",
      "id" : 34027831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "653693080063840257",
  "geo" : { },
  "id_str" : "653702779593207808",
  "in_reply_to_user_id" : 88493882,
  "text" : "@ManuelWuest @WalkOffTheEarth in der Batschkapp. :)",
  "id" : 653702779593207808,
  "in_reply_to_status_id" : 653693080063840257,
  "created_at" : "2015-10-12 22:44:22 +0000",
  "in_reply_to_screen_name" : "ManuelWuest",
  "in_reply_to_user_id_str" : "88493882",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pawel Szczesny",
      "screen_name" : "freesci",
      "indices" : [ 0, 8 ],
      "id_str" : "14163008",
      "id" : 14163008
    }, {
      "name" : ".",
      "screen_name" : "punkish",
      "indices" : [ 9, 17 ],
      "id_str" : "15322269",
      "id" : 15322269
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "653651388715659264",
  "geo" : { },
  "id_str" : "653671798647713797",
  "in_reply_to_user_id" : 14163008,
  "text" : "@freesci @punkish have fun! :)",
  "id" : 653671798647713797,
  "in_reply_to_status_id" : 653651388715659264,
  "created_at" : "2015-10-12 20:41:16 +0000",
  "in_reply_to_screen_name" : "freesci",
  "in_reply_to_user_id_str" : "14163008",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Walk off the Earth",
      "screen_name" : "WalkOffTheEarth",
      "indices" : [ 20, 36 ],
      "id_str" : "34027831",
      "id" : 34027831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 60 ],
      "url" : "https:\/\/t.co\/7MuBgBEGbv",
      "expanded_url" : "https:\/\/instagram.com\/p\/8wEt5Whwj7\/",
      "display_url" : "instagram.com\/p\/8wEt5Whwj7\/"
    } ]
  },
  "geo" : { },
  "id_str" : "653670346403540992",
  "text" : "Tripping balls with @walkofftheearth https:\/\/t.co\/7MuBgBEGbv",
  "id" : 653670346403540992,
  "created_at" : "2015-10-12 20:35:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Walk off the Earth",
      "screen_name" : "WalkOffTheEarth",
      "indices" : [ 46, 62 ],
      "id_str" : "34027831",
      "id" : 34027831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/aWr2J6IiY0",
      "expanded_url" : "http:\/\/thelantern.com\/media\/2912753-1839059187.jpg",
      "display_url" : "thelantern.com\/media\/2912753-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "653659612693032960",
  "text" : "Finally figured out of whom the keyboarder of @WalkOffTheEarth reminds me! http:\/\/t.co\/aWr2J6IiY0",
  "id" : 653659612693032960,
  "created_at" : "2015-10-12 19:52:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 81, 87 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/tc1i2RSv6K",
      "expanded_url" : "http:\/\/www.wired.com\/2015\/10\/pitfalls-of-studying-language-with-google-ngram\/",
      "display_url" : "wired.com\/2015\/10\/pitfal\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "653647091923853312",
  "text" : "Why you should be careful if you use Google ngrams for your corpus research. \/cc @Lobot  http:\/\/t.co\/tc1i2RSv6K",
  "id" : 653647091923853312,
  "created_at" : "2015-10-12 19:03:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 44 ],
      "url" : "https:\/\/t.co\/nasTXGFSrB",
      "expanded_url" : "https:\/\/instagram.com\/p\/8v31aShwnH\/",
      "display_url" : "instagram.com\/p\/8v31aShwnH\/"
    } ]
  },
  "geo" : { },
  "id_str" : "653642024776822784",
  "text" : "old school pony play https:\/\/t.co\/nasTXGFSrB",
  "id" : 653642024776822784,
  "created_at" : "2015-10-12 18:42:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Melissa WilsonSayres",
      "screen_name" : "mwilsonsayres",
      "indices" : [ 3, 17 ],
      "id_str" : "143086518",
      "id" : 143086518
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/mwilsonsayres\/status\/653629162020712448\/photo\/1",
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/FbD4QntEaD",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CRIn_ptUYAAf41y.jpg",
      "id_str" : "653628870403317760",
      "id" : 653628870403317760,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CRIn_ptUYAAf41y.jpg",
      "sizes" : [ {
        "h" : 1200,
        "resize" : "fit",
        "w" : 1054
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1600,
        "resize" : "fit",
        "w" : 1405
      }, {
        "h" : 1600,
        "resize" : "fit",
        "w" : 1405
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 597
      } ],
      "display_url" : "pic.twitter.com\/FbD4QntEaD"
    } ],
    "hashtags" : [ {
      "text" : "ASHG15",
      "indices" : [ 101, 108 ]
    } ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/T4NeiNea8K",
      "expanded_url" : "http:\/\/mathbionerd.blogspot.com\/2015\/10\/im-not-laughing.html",
      "display_url" : "mathbionerd.blogspot.com\/2015\/10\/im-not\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "653639626004000768",
  "text" : "RT @mwilsonsayres: I\u2019m not laughing. \n\nhttp:\/\/t.co\/T4NeiNea8K\n\nThoughts and follow-up to a \u201Cjoke\u201D at #ASHG15 http:\/\/t.co\/FbD4QntEaD",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/mwilsonsayres\/status\/653629162020712448\/photo\/1",
        "indices" : [ 90, 112 ],
        "url" : "http:\/\/t.co\/FbD4QntEaD",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CRIn_ptUYAAf41y.jpg",
        "id_str" : "653628870403317760",
        "id" : 653628870403317760,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CRIn_ptUYAAf41y.jpg",
        "sizes" : [ {
          "h" : 1200,
          "resize" : "fit",
          "w" : 1054
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1600,
          "resize" : "fit",
          "w" : 1405
        }, {
          "h" : 1600,
          "resize" : "fit",
          "w" : 1405
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 597
        } ],
        "display_url" : "pic.twitter.com\/FbD4QntEaD"
      } ],
      "hashtags" : [ {
        "text" : "ASHG15",
        "indices" : [ 82, 89 ]
      } ],
      "urls" : [ {
        "indices" : [ 20, 42 ],
        "url" : "http:\/\/t.co\/T4NeiNea8K",
        "expanded_url" : "http:\/\/mathbionerd.blogspot.com\/2015\/10\/im-not-laughing.html",
        "display_url" : "mathbionerd.blogspot.com\/2015\/10\/im-not\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "653629162020712448",
    "text" : "I\u2019m not laughing. \n\nhttp:\/\/t.co\/T4NeiNea8K\n\nThoughts and follow-up to a \u201Cjoke\u201D at #ASHG15 http:\/\/t.co\/FbD4QntEaD",
    "id" : 653629162020712448,
    "created_at" : "2015-10-12 17:51:50 +0000",
    "user" : {
      "name" : "Melissa WilsonSayres",
      "screen_name" : "mwilsonsayres",
      "protected" : false,
      "id_str" : "143086518",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/850459123124641792\/29LRtOHv_normal.jpg",
      "id" : 143086518,
      "verified" : false
    }
  },
  "id" : 653639626004000768,
  "created_at" : "2015-10-12 18:33:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "beau",
      "screen_name" : "beaugunderson",
      "indices" : [ 3, 17 ],
      "id_str" : "5746882",
      "id" : 5746882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/OGJXvNEBi2",
      "expanded_url" : "https:\/\/github.com\/google\/brotli\/commit\/c4f439dbe6007b2a37d50c20419253d5aaa8b46b",
      "display_url" : "github.com\/google\/brotli\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "653637151020740608",
  "text" : "RT @beaugunderson: if you need male tears today you can find them in this github thread about renaming \".bro\" https:\/\/t.co\/OGJXvNEBi2",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 91, 114 ],
        "url" : "https:\/\/t.co\/OGJXvNEBi2",
        "expanded_url" : "https:\/\/github.com\/google\/brotli\/commit\/c4f439dbe6007b2a37d50c20419253d5aaa8b46b",
        "display_url" : "github.com\/google\/brotli\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "653619237383110656",
    "text" : "if you need male tears today you can find them in this github thread about renaming \".bro\" https:\/\/t.co\/OGJXvNEBi2",
    "id" : 653619237383110656,
    "created_at" : "2015-10-12 17:12:24 +0000",
    "user" : {
      "name" : "beau",
      "screen_name" : "beaugunderson",
      "protected" : false,
      "id_str" : "5746882",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/913840034016399360\/pU3IIxqf_normal.jpg",
      "id" : 5746882,
      "verified" : false
    }
  },
  "id" : 653637151020740608,
  "created_at" : "2015-10-12 18:23:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/NkKv82o9Wg",
      "expanded_url" : "http:\/\/memesvault.com\/wp-content\/uploads\/I-Have-No-Idea-What-Im-Doing-Dog-02.jpg",
      "display_url" : "memesvault.com\/wp-content\/upl\u2026"
    }, {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/xLySphmja0",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/653548312428154880",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "653548312428154880",
  "geo" : { },
  "id_str" : "653581379888918528",
  "in_reply_to_user_id" : 14286491,
  "text" : "Every time this is RT\u2019d I read \u2018doggy perl scripts\u2019 in the notification\u2026 http:\/\/t.co\/NkKv82o9Wg https:\/\/t.co\/xLySphmja0",
  "id" : 653581379888918528,
  "in_reply_to_status_id" : 653548312428154880,
  "created_at" : "2015-10-12 14:41:58 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/S0P618J37A",
      "expanded_url" : "http:\/\/www.ncbi.nlm.nih.gov\/pubmed\/24245977",
      "display_url" : "ncbi.nlm.nih.gov\/pubmed\/24245977"
    } ]
  },
  "geo" : { },
  "id_str" : "653561829990514690",
  "text" : "Genome skimming reveals origin of Jerusalem Artichoke tuber crop species: neither from Jerusalem nor an artichoke http:\/\/t.co\/S0P618J37A",
  "id" : 653561829990514690,
  "created_at" : "2015-10-12 13:24:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/RCAcrs9dCB",
      "expanded_url" : "https:\/\/thescienceweb.wordpress.com\/2015\/10\/12\/perl-6-just-perl-5-with-use-strict-turned-on-2\/",
      "display_url" : "thescienceweb.wordpress.com\/2015\/10\/12\/per\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "653548312428154880",
  "text" : "\u00ABDodgy Perl 5 scripts were behind the financial crisis of 2008 &amp; the assassination of Archduke Franz Ferdinand.\u00BB https:\/\/t.co\/RCAcrs9dCB",
  "id" : 653548312428154880,
  "created_at" : "2015-10-12 12:30:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 86 ],
      "url" : "https:\/\/t.co\/p1LNBpaB34",
      "expanded_url" : "https:\/\/twitter.com\/Lobot\/status\/653521387521486848",
      "display_url" : "twitter.com\/Lobot\/status\/6\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "653522024455868416",
  "text" : "I don\u2019t always play \u2018raining blood\u2019 on the drums, but if I do\u2026 https:\/\/t.co\/p1LNBpaB34",
  "id" : 653522024455868416,
  "created_at" : "2015-10-12 10:46:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ICG10",
      "indices" : [ 85, 91 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/Fc4o2JhfbV",
      "expanded_url" : "https:\/\/twitter.com\/DNADigest\/status\/653495520720195584",
      "display_url" : "twitter.com\/DNADigest\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "653497078946091008",
  "text" : "There\u2019s still space if you want to join us in Hong Kong for some more genomics after #ICG10 https:\/\/t.co\/Fc4o2JhfbV",
  "id" : 653497078946091008,
  "created_at" : "2015-10-12 09:06:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/653471479229751296\/photo\/1",
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/KP8K06X2zP",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CRGY2JBWIAAPXvM.png",
      "id_str" : "653471476847353856",
      "id" : 653471476847353856,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CRGY2JBWIAAPXvM.png",
      "sizes" : [ {
        "h" : 675,
        "resize" : "fit",
        "w" : 1179
      }, {
        "h" : 675,
        "resize" : "fit",
        "w" : 1179
      }, {
        "h" : 675,
        "resize" : "fit",
        "w" : 1179
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 389,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/KP8K06X2zP"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "653471479229751296",
  "text" : "workshop preparation: on how to visualize yourself in relation to the hapmap populations. http:\/\/t.co\/KP8K06X2zP",
  "id" : 653471479229751296,
  "created_at" : "2015-10-12 07:25:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/LPXCdeoVG9",
      "expanded_url" : "http:\/\/megabiome.net\/2015\/06\/the-real-ghost-tree\/",
      "display_url" : "megabiome.net\/2015\/06\/the-re\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "653347277365506048",
  "text" : "\u00ABThe REAL Ghost-tree: a hybrid-media phylogenetic tree for diversity analyses in apparitional science\u00BB http:\/\/t.co\/LPXCdeoVG9",
  "id" : 653347277365506048,
  "created_at" : "2015-10-11 23:11:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GigaScience",
      "screen_name" : "GigaScience",
      "indices" : [ 0, 12 ],
      "id_str" : "208988759",
      "id" : 208988759
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "652935148019810304",
  "geo" : { },
  "id_str" : "653325390904205312",
  "in_reply_to_user_id" : 208988759,
  "text" : "@GigaScience works now :)",
  "id" : 653325390904205312,
  "in_reply_to_status_id" : 652935148019810304,
  "created_at" : "2015-10-11 21:44:46 +0000",
  "in_reply_to_screen_name" : "GigaScience",
  "in_reply_to_user_id_str" : "208988759",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/MKDkGuVHeX",
      "expanded_url" : "http:\/\/www.michaeleisen.org\/blog\/?p=1768",
      "display_url" : "michaeleisen.org\/blog\/?p=1768"
    } ]
  },
  "geo" : { },
  "id_str" : "653307797388558337",
  "text" : "What Geoffrey Marcy did was abominable; What Berkeley didn\u2019t do was worse http:\/\/t.co\/MKDkGuVHeX",
  "id" : 653307797388558337,
  "created_at" : "2015-10-11 20:34:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karyn MeltzSteinberg",
      "screen_name" : "KMS_Meltzy",
      "indices" : [ 3, 14 ],
      "id_str" : "1425644274",
      "id" : 1425644274
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cocksnotglocks",
      "indices" : [ 16, 31 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/2OTk5LTOC9",
      "expanded_url" : "http:\/\/www.addictinginfo.org\/2015\/10\/10\/ut-gun-carry-protest\/",
      "display_url" : "addictinginfo.org\/2015\/10\/10\/ut-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "653275966354145280",
  "text" : "RT @KMS_Meltzy: #cocksnotglocks Students Plan To Open-Carry Dildos Over Controversial Texas Campus Gun Law: http:\/\/t.co\/2OTk5LTOC9",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "cocksnotglocks",
        "indices" : [ 0, 15 ]
      } ],
      "urls" : [ {
        "indices" : [ 92, 114 ],
        "url" : "http:\/\/t.co\/2OTk5LTOC9",
        "expanded_url" : "http:\/\/www.addictinginfo.org\/2015\/10\/10\/ut-gun-carry-protest\/",
        "display_url" : "addictinginfo.org\/2015\/10\/10\/ut-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "653274457008529408",
    "text" : "#cocksnotglocks Students Plan To Open-Carry Dildos Over Controversial Texas Campus Gun Law: http:\/\/t.co\/2OTk5LTOC9",
    "id" : 653274457008529408,
    "created_at" : "2015-10-11 18:22:22 +0000",
    "user" : {
      "name" : "Karyn MeltzSteinberg",
      "screen_name" : "KMS_Meltzy",
      "protected" : false,
      "id_str" : "1425644274",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/753988827065311232\/X0IHveuE_normal.jpg",
      "id" : 1425644274,
      "verified" : false
    }
  },
  "id" : 653275966354145280,
  "created_at" : "2015-10-11 18:28:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 77 ],
      "url" : "http:\/\/t.co\/F4vc6dywg9",
      "expanded_url" : "http:\/\/www.nature.com\/news\/how-scientists-fool-themselves-and-how-they-can-stop-1.18517",
      "display_url" : "nature.com\/news\/how-scien\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "653270071637372928",
  "text" : "How scientists fool themselves \u2013 and how they can stop http:\/\/t.co\/F4vc6dywg9",
  "id" : 653270071637372928,
  "created_at" : "2015-10-11 18:04:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wellcome Trust",
      "screen_name" : "wellcometrust",
      "indices" : [ 3, 17 ],
      "id_str" : "19837528",
      "id" : 19837528
    }, {
      "name" : "UK Fungus Day",
      "screen_name" : "ukfungusday",
      "indices" : [ 28, 40 ],
      "id_str" : "1247165292",
      "id" : 1247165292
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/yP4Oa6AtEA",
      "expanded_url" : "http:\/\/wellc.me\/1rCgLiJ",
      "display_url" : "wellc.me\/1rCgLiJ"
    } ]
  },
  "geo" : { },
  "id_str" : "653264763405905922",
  "text" : "RT @wellcometrust: Today is @ukfungusday. How much do you know about fungal science? http:\/\/t.co\/yP4Oa6AtEA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "UK Fungus Day",
        "screen_name" : "ukfungusday",
        "indices" : [ 9, 21 ],
        "id_str" : "1247165292",
        "id" : 1247165292
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 66, 88 ],
        "url" : "http:\/\/t.co\/yP4Oa6AtEA",
        "expanded_url" : "http:\/\/wellc.me\/1rCgLiJ",
        "display_url" : "wellc.me\/1rCgLiJ"
      } ]
    },
    "geo" : { },
    "id_str" : "653246205737086976",
    "text" : "Today is @ukfungusday. How much do you know about fungal science? http:\/\/t.co\/yP4Oa6AtEA",
    "id" : 653246205737086976,
    "created_at" : "2015-10-11 16:30:06 +0000",
    "user" : {
      "name" : "Wellcome Trust",
      "screen_name" : "wellcometrust",
      "protected" : false,
      "id_str" : "19837528",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/884429057819103234\/PpfTd798_normal.jpg",
      "id" : 19837528,
      "verified" : true
    }
  },
  "id" : 653264763405905922,
  "created_at" : "2015-10-11 17:43:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pall Melsted",
      "screen_name" : "pmelsted",
      "indices" : [ 3, 12 ],
      "id_str" : "1135472480",
      "id" : 1135472480
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "653260974368161793",
  "text" : "RT @pmelsted: Tweeps: what are good bioinfo papers for students to present, novel algorithmic work, but still relatively self contained",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "653260110077276160",
    "text" : "Tweeps: what are good bioinfo papers for students to present, novel algorithmic work, but still relatively self contained",
    "id" : 653260110077276160,
    "created_at" : "2015-10-11 17:25:21 +0000",
    "user" : {
      "name" : "Pall Melsted",
      "screen_name" : "pmelsted",
      "protected" : false,
      "id_str" : "1135472480",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3185781099\/3f5c881ce8adc3b5aaf3568530290c31_normal.jpeg",
      "id" : 1135472480,
      "verified" : false
    }
  },
  "id" : 653260974368161793,
  "created_at" : "2015-10-11 17:28:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ed Yong",
      "screen_name" : "edyong209",
      "indices" : [ 3, 13 ],
      "id_str" : "19767193",
      "id" : 19767193
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/s6JSxTSVXU",
      "expanded_url" : "http:\/\/andrewgelman.com\/2015\/10\/10\/gay-gene-tabloid-hype-update\/",
      "display_url" : "andrewgelman.com\/2015\/10\/10\/gay\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "653238670787485697",
  "text" : "RT @edyong209: Andrew Gelman knows his stats. That is all. http:\/\/t.co\/s6JSxTSVXU",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 44, 66 ],
        "url" : "http:\/\/t.co\/s6JSxTSVXU",
        "expanded_url" : "http:\/\/andrewgelman.com\/2015\/10\/10\/gay-gene-tabloid-hype-update\/",
        "display_url" : "andrewgelman.com\/2015\/10\/10\/gay\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "653174588973678593",
    "text" : "Andrew Gelman knows his stats. That is all. http:\/\/t.co\/s6JSxTSVXU",
    "id" : 653174588973678593,
    "created_at" : "2015-10-11 11:45:32 +0000",
    "user" : {
      "name" : "Ed Yong",
      "screen_name" : "edyong209",
      "protected" : false,
      "id_str" : "19767193",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/926063794912153600\/962ygzzx_normal.jpg",
      "id" : 19767193,
      "verified" : true
    }
  },
  "id" : 653238670787485697,
  "created_at" : "2015-10-11 16:00:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Definitely Not Jake",
      "screen_name" : "SadBoySyndrome",
      "indices" : [ 3, 18 ],
      "id_str" : "3816754940",
      "id" : 3816754940
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/SadBoySyndrome\/status\/652469505982005248\/photo\/1",
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/ZaRbXRr1gq",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CQ4JjsbUEAAGdsb.png",
      "id_str" : "652469504841093120",
      "id" : 652469504841093120,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQ4JjsbUEAAGdsb.png",
      "sizes" : [ {
        "h" : 678,
        "resize" : "fit",
        "w" : 468
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 678,
        "resize" : "fit",
        "w" : 468
      }, {
        "h" : 678,
        "resize" : "fit",
        "w" : 468
      }, {
        "h" : 678,
        "resize" : "fit",
        "w" : 468
      } ],
      "display_url" : "pic.twitter.com\/ZaRbXRr1gq"
    } ],
    "hashtags" : [ {
      "text" : "funny",
      "indices" : [ 78, 84 ]
    } ],
    "urls" : [ {
      "indices" : [ 55, 77 ],
      "url" : "http:\/\/t.co\/9svRddYyqZ",
      "expanded_url" : "http:\/\/theycantalk.com",
      "display_url" : "theycantalk.com"
    } ]
  },
  "geo" : { },
  "id_str" : "653212228850728961",
  "text" : "RT @SadBoySyndrome: Enter the mind of a shark\nCredits: http:\/\/t.co\/9svRddYyqZ\n#funny http:\/\/t.co\/ZaRbXRr1gq",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SadBoySyndrome\/status\/652469505982005248\/photo\/1",
        "indices" : [ 65, 87 ],
        "url" : "http:\/\/t.co\/ZaRbXRr1gq",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CQ4JjsbUEAAGdsb.png",
        "id_str" : "652469504841093120",
        "id" : 652469504841093120,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQ4JjsbUEAAGdsb.png",
        "sizes" : [ {
          "h" : 678,
          "resize" : "fit",
          "w" : 468
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 678,
          "resize" : "fit",
          "w" : 468
        }, {
          "h" : 678,
          "resize" : "fit",
          "w" : 468
        }, {
          "h" : 678,
          "resize" : "fit",
          "w" : 468
        } ],
        "display_url" : "pic.twitter.com\/ZaRbXRr1gq"
      } ],
      "hashtags" : [ {
        "text" : "funny",
        "indices" : [ 58, 64 ]
      } ],
      "urls" : [ {
        "indices" : [ 35, 57 ],
        "url" : "http:\/\/t.co\/9svRddYyqZ",
        "expanded_url" : "http:\/\/theycantalk.com",
        "display_url" : "theycantalk.com"
      } ]
    },
    "geo" : { },
    "id_str" : "652469505982005248",
    "text" : "Enter the mind of a shark\nCredits: http:\/\/t.co\/9svRddYyqZ\n#funny http:\/\/t.co\/ZaRbXRr1gq",
    "id" : 652469505982005248,
    "created_at" : "2015-10-09 13:03:47 +0000",
    "user" : {
      "name" : "Definitely Not Jake",
      "screen_name" : "SadBoySyndrome",
      "protected" : false,
      "id_str" : "3816754940",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/764518406708076544\/9b0tFMkC_normal.jpg",
      "id" : 3816754940,
      "verified" : false
    }
  },
  "id" : 653212228850728961,
  "created_at" : "2015-10-11 14:15:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 45, 54 ],
      "id_str" : "14245811",
      "id" : 14245811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 79 ],
      "url" : "https:\/\/t.co\/qpK2nUfs1D",
      "expanded_url" : "https:\/\/instagram.com\/p\/8swTuKBwnx\/",
      "display_url" : "instagram.com\/p\/8swTuKBwnx\/"
    } ]
  },
  "geo" : { },
  "id_str" : "653203362016587776",
  "text" : "Look who\u2019s auditioning for the next video of @wilbanks. https:\/\/t.co\/qpK2nUfs1D",
  "id" : 653203362016587776,
  "created_at" : "2015-10-11 13:39:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 7, 30 ],
      "url" : "https:\/\/t.co\/6VCbLiJxLs",
      "expanded_url" : "https:\/\/instagram.com\/p\/8suweshwkt\/",
      "display_url" : "instagram.com\/p\/8suweshwkt\/"
    } ]
  },
  "geo" : { },
  "id_str" : "653199832660713476",
  "text" : "on air https:\/\/t.co\/6VCbLiJxLs",
  "id" : 653199832660713476,
  "created_at" : "2015-10-11 13:25:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonas",
      "screen_name" : "lsanoj",
      "indices" : [ 0, 7 ],
      "id_str" : "18918915",
      "id" : 18918915
    }, {
      "name" : "Robert",
      "screen_name" : "kventil",
      "indices" : [ 21, 29 ],
      "id_str" : "7431192",
      "id" : 7431192
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "653191725712867328",
  "geo" : { },
  "id_str" : "653199489646362624",
  "in_reply_to_user_id" : 18918915,
  "text" : "@lsanoj frag mal den @kventil :)",
  "id" : 653199489646362624,
  "in_reply_to_status_id" : 653191725712867328,
  "created_at" : "2015-10-11 13:24:28 +0000",
  "in_reply_to_screen_name" : "lsanoj",
  "in_reply_to_user_id_str" : "18918915",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "653187217364525056",
  "text" : "Our radio talk on genetics was followed by the Christian Rock-series \u00ABWhy should the devil have all the good music?\u00BB.",
  "id" : 653187217364525056,
  "created_at" : "2015-10-11 12:35:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "653147825149227008",
  "text" : "In a radio station which plays 40s Jazz and where you can still smoke indoors.",
  "id" : 653147825149227008,
  "created_at" : "2015-10-11 09:59:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fnordfunk",
      "screen_name" : "Fnordfunk",
      "indices" : [ 0, 10 ],
      "id_str" : "149090725",
      "id" : 149090725
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/653125352940810240\/photo\/1",
      "indices" : [ 31, 53 ],
      "url" : "http:\/\/t.co\/JuOrHBj0LA",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CRBeC6OWcAABIBu.jpg",
      "id_str" : "653125350050918400",
      "id" : 653125350050918400,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CRBeC6OWcAABIBu.jpg",
      "sizes" : [ {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 3264,
        "resize" : "fit",
        "w" : 2448
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      } ],
      "display_url" : "pic.twitter.com\/JuOrHBj0LA"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "653119759849025536",
  "geo" : { },
  "id_str" : "653125352940810240",
  "in_reply_to_user_id" : 149090725,
  "text" : "@Fnordfunk schon bereitgelegt: http:\/\/t.co\/JuOrHBj0LA",
  "id" : 653125352940810240,
  "in_reply_to_status_id" : 653119759849025536,
  "created_at" : "2015-10-11 08:29:53 +0000",
  "in_reply_to_screen_name" : "Fnordfunk",
  "in_reply_to_user_id_str" : "149090725",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Brechler",
      "screen_name" : "plaetzchen",
      "indices" : [ 0, 11 ],
      "id_str" : "14305613",
      "id" : 14305613
    }, {
      "name" : "TheConstructor",
      "screen_name" : "TheConstructor",
      "indices" : [ 12, 27 ],
      "id_str" : "14362840",
      "id" : 14362840
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "652946774068432896",
  "geo" : { },
  "id_str" : "652951845355286529",
  "in_reply_to_user_id" : 14305613,
  "text" : "@plaetzchen @TheConstructor dito",
  "id" : 652951845355286529,
  "in_reply_to_status_id" : 652946774068432896,
  "created_at" : "2015-10-10 21:00:25 +0000",
  "in_reply_to_screen_name" : "plaetzchen",
  "in_reply_to_user_id_str" : "14305613",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arikia\uD83D\uDCAB",
      "screen_name" : "arikia",
      "indices" : [ 0, 7 ],
      "id_str" : "71654283",
      "id" : 71654283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "652901150702833664",
  "geo" : { },
  "id_str" : "652907116542492672",
  "in_reply_to_user_id" : 71654283,
  "text" : "@arikia I was just shown your tweet and asked \u2018and this is what you crowdfund?!\u2019 I\u2019ve never been more proud to do so :3",
  "id" : 652907116542492672,
  "in_reply_to_status_id" : 652901150702833664,
  "created_at" : "2015-10-10 18:02:41 +0000",
  "in_reply_to_screen_name" : "arikia",
  "in_reply_to_user_id_str" : "71654283",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/gXa9mJLloq",
      "expanded_url" : "https:\/\/twitter.com\/SCEdmunds\/status\/652873742780137472",
      "display_url" : "twitter.com\/SCEdmunds\/stat\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11407383930655, 8.753393388440442 ]
  },
  "id_str" : "652875430295437312",
  "text" : "It is difficult to get a company to understand something, when its profit depends upon not understanding it\u2026 https:\/\/t.co\/gXa9mJLloq",
  "id" : 652875430295437312,
  "created_at" : "2015-10-10 15:56:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yaniv (((Erlich)))",
      "screen_name" : "erlichya",
      "indices" : [ 0, 9 ],
      "id_str" : "495517322",
      "id" : 495517322
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "652860462393131008",
  "geo" : { },
  "id_str" : "652864488337764352",
  "in_reply_to_user_id" : 495517322,
  "text" : "@erlichya Netflix and chill? ;) seriously: sure, sounds great. I\u2019m pretty booked until Tuesday. Let\u2019s find a date via mail?",
  "id" : 652864488337764352,
  "in_reply_to_status_id" : 652860462393131008,
  "created_at" : "2015-10-10 15:13:18 +0000",
  "in_reply_to_screen_name" : "erlichya",
  "in_reply_to_user_id_str" : "495517322",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yaniv (((Erlich)))",
      "screen_name" : "erlichya",
      "indices" : [ 0, 9 ],
      "id_str" : "495517322",
      "id" : 495517322
    }, {
      "name" : "GigaScience",
      "screen_name" : "GigaScience",
      "indices" : [ 10, 22 ],
      "id_str" : "208988759",
      "id" : 208988759
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/c1gxGkc7eO",
      "expanded_url" : "http:\/\/DNA.land",
      "display_url" : "DNA.land"
    } ]
  },
  "in_reply_to_status_id_str" : "652859226801442816",
  "geo" : { },
  "id_str" : "652860055134556160",
  "in_reply_to_user_id" : 495517322,
  "text" : "@erlichya @GigaScience very nice. Do you have any interest in linking openSNP to http:\/\/t.co\/c1gxGkc7eO? :)",
  "id" : 652860055134556160,
  "in_reply_to_status_id" : 652859226801442816,
  "created_at" : "2015-10-10 14:55:41 +0000",
  "in_reply_to_screen_name" : "erlichya",
  "in_reply_to_user_id_str" : "495517322",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yaniv (((Erlich)))",
      "screen_name" : "erlichya",
      "indices" : [ 0, 9 ],
      "id_str" : "495517322",
      "id" : 495517322
    }, {
      "name" : "GigaScience",
      "screen_name" : "GigaScience",
      "indices" : [ 10, 22 ],
      "id_str" : "208988759",
      "id" : 208988759
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "652859484159770624",
  "geo" : { },
  "id_str" : "652859798510301184",
  "in_reply_to_user_id" : 495517322,
  "text" : "@erlichya @GigaScience which is cool, love how many options there are around by now! :)",
  "id" : 652859798510301184,
  "in_reply_to_status_id" : 652859484159770624,
  "created_at" : "2015-10-10 14:54:40 +0000",
  "in_reply_to_screen_name" : "erlichya",
  "in_reply_to_user_id_str" : "495517322",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GigaScience",
      "screen_name" : "GigaScience",
      "indices" : [ 0, 12 ],
      "id_str" : "208988759",
      "id" : 208988759
    }, {
      "name" : "Yaniv (((Erlich)))",
      "screen_name" : "erlichya",
      "indices" : [ 13, 22 ],
      "id_str" : "495517322",
      "id" : 495517322
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "652858121690480646",
  "geo" : { },
  "id_str" : "652859674321113088",
  "in_reply_to_user_id" : 208988759,
  "text" : "@GigaScience @erlichya ah, thanks. So in short: no. :)",
  "id" : 652859674321113088,
  "in_reply_to_status_id" : 652858121690480646,
  "created_at" : "2015-10-10 14:54:10 +0000",
  "in_reply_to_screen_name" : "GigaScience",
  "in_reply_to_user_id_str" : "208988759",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GigaScience",
      "screen_name" : "GigaScience",
      "indices" : [ 0, 12 ],
      "id_str" : "208988759",
      "id" : 208988759
    }, {
      "name" : "Yaniv (((Erlich)))",
      "screen_name" : "erlichya",
      "indices" : [ 13, 22 ],
      "id_str" : "495517322",
      "id" : 495517322
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/c1gxGkc7eO",
      "expanded_url" : "http:\/\/DNA.land",
      "display_url" : "DNA.land"
    } ]
  },
  "in_reply_to_status_id_str" : "652855694840958976",
  "geo" : { },
  "id_str" : "652856881237598208",
  "in_reply_to_user_id" : 208988759,
  "text" : "@GigaScience @erlichya thanks for the coverage! Wondered: is http:\/\/t.co\/c1gxGkc7eO completely open as well? :)",
  "id" : 652856881237598208,
  "in_reply_to_status_id" : 652855694840958976,
  "created_at" : "2015-10-10 14:43:04 +0000",
  "in_reply_to_screen_name" : "GigaScience",
  "in_reply_to_user_id_str" : "208988759",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Oddur Vilhelmsson",
      "screen_name" : "OddurV",
      "indices" : [ 0, 7 ],
      "id_str" : "1280137776",
      "id" : 1280137776
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/chSePrcRPl",
      "expanded_url" : "http:\/\/onlinelibrary.wiley.com\/doi\/10.1111\/1755-0998.12463\/abstract",
      "display_url" : "onlinelibrary.wiley.com\/doi\/10.1111\/17\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "652842074321063937",
  "geo" : { },
  "id_str" : "652852404795375616",
  "in_reply_to_user_id" : 1280137776,
  "text" : "@OddurV my PhD will probably last until mid next year in any case. So far I largely worked on myco\/photobionts, c.f. http:\/\/t.co\/chSePrcRPl",
  "id" : 652852404795375616,
  "in_reply_to_status_id" : 652842074321063937,
  "created_at" : "2015-10-10 14:25:17 +0000",
  "in_reply_to_screen_name" : "OddurV",
  "in_reply_to_user_id_str" : "1280137776",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GigaScience",
      "screen_name" : "GigaScience",
      "indices" : [ 0, 12 ],
      "id_str" : "208988759",
      "id" : 208988759
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "652837039705038848",
  "geo" : { },
  "id_str" : "652837943690829824",
  "in_reply_to_user_id" : 208988759,
  "text" : "@GigaScience iPhone with latest iOS9.",
  "id" : 652837943690829824,
  "in_reply_to_status_id" : 652837039705038848,
  "created_at" : "2015-10-10 13:27:49 +0000",
  "in_reply_to_screen_name" : "GigaScience",
  "in_reply_to_user_id_str" : "208988759",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Oddur Vilhelmsson",
      "screen_name" : "OddurV",
      "indices" : [ 0, 7 ],
      "id_str" : "1280137776",
      "id" : 1280137776
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "652836509796667392",
  "geo" : { },
  "id_str" : "652836977822289920",
  "in_reply_to_user_id" : 1280137776,
  "text" : "@OddurV but what about visitors without much external funding? Any chance you have positions coming up? :)",
  "id" : 652836977822289920,
  "in_reply_to_status_id" : 652836509796667392,
  "created_at" : "2015-10-10 13:23:59 +0000",
  "in_reply_to_screen_name" : "OddurV",
  "in_reply_to_user_id_str" : "1280137776",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Oddur Vilhelmsson",
      "screen_name" : "OddurV",
      "indices" : [ 0, 7 ],
      "id_str" : "1280137776",
      "id" : 1280137776
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "652834427492560896",
  "geo" : { },
  "id_str" : "652834654370799616",
  "in_reply_to_user_id" : 1280137776,
  "text" : "@OddurV do you happen to need a visiting scientist who\u2019s doing lichen genomics? ;)",
  "id" : 652834654370799616,
  "in_reply_to_status_id" : 652834427492560896,
  "created_at" : "2015-10-10 13:14:45 +0000",
  "in_reply_to_screen_name" : "OddurV",
  "in_reply_to_user_id_str" : "1280137776",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 69 ],
      "url" : "https:\/\/t.co\/HjoUmHl4b1",
      "expanded_url" : "https:\/\/www.washingtonpost.com\/news\/speaking-of-science\/wp\/2015\/06\/22\/neanderthal-hybrid-suggests-modern-humans-bred-with-them-much-later-than-thought\/",
      "display_url" : "washingtonpost.com\/news\/speaking-\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "652831686183526401",
  "geo" : { },
  "id_str" : "652834066992074752",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich actually: zu 3-10 Prozent schon. :3 https:\/\/t.co\/HjoUmHl4b1",
  "id" : 652834066992074752,
  "in_reply_to_status_id" : 652831686183526401,
  "created_at" : "2015-10-10 13:12:25 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeffrey Ross-Ibarra",
      "screen_name" : "jrossibarra",
      "indices" : [ 3, 15 ],
      "id_str" : "561297215",
      "id" : 561297215
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 72 ],
      "url" : "https:\/\/t.co\/2hebTgfd8g",
      "expanded_url" : "https:\/\/twitter.com\/ijuric_tldr\/status\/652665138764378112",
      "display_url" : "twitter.com\/ijuric_tldr\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "652763021375369216",
  "text" : "RT @jrossibarra: Or at least finally explained.  https:\/\/t.co\/2hebTgfd8g",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 32, 55 ],
        "url" : "https:\/\/t.co\/2hebTgfd8g",
        "expanded_url" : "https:\/\/twitter.com\/ijuric_tldr\/status\/652665138764378112",
        "display_url" : "twitter.com\/ijuric_tldr\/st\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "652671524927737856",
    "text" : "Or at least finally explained.  https:\/\/t.co\/2hebTgfd8g",
    "id" : 652671524927737856,
    "created_at" : "2015-10-10 02:26:32 +0000",
    "user" : {
      "name" : "Jeffrey Ross-Ibarra",
      "screen_name" : "jrossibarra",
      "protected" : false,
      "id_str" : "561297215",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656691317519466496\/tJ966bzU_normal.png",
      "id" : 561297215,
      "verified" : false
    }
  },
  "id" : 652763021375369216,
  "created_at" : "2015-10-10 08:30:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GigaScience",
      "screen_name" : "GigaScience",
      "indices" : [ 0, 12 ],
      "id_str" : "208988759",
      "id" : 208988759
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "652683036673359872",
  "geo" : { },
  "id_str" : "652743101044363264",
  "in_reply_to_user_id" : 208988759,
  "text" : "@GigaScience now it\u2019s 403 forbidden.",
  "id" : 652743101044363264,
  "in_reply_to_status_id" : 652683036673359872,
  "created_at" : "2015-10-10 07:10:57 +0000",
  "in_reply_to_screen_name" : "GigaScience",
  "in_reply_to_user_id_str" : "208988759",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GigaScience",
      "screen_name" : "GigaScience",
      "indices" : [ 0, 12 ],
      "id_str" : "208988759",
      "id" : 208988759
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/652613158734045184\/photo\/1",
      "indices" : [ 13, 35 ],
      "url" : "http:\/\/t.co\/UqV93ZD1bc",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CQ6MNUDWcAA8FGg.png",
      "id_str" : "652613156364251136",
      "id" : 652613156364251136,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQ6MNUDWcAA8FGg.png",
      "sizes" : [ {
        "h" : 1334,
        "resize" : "fit",
        "w" : 750
      }, {
        "h" : 1334,
        "resize" : "fit",
        "w" : 750
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 382
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 675
      } ],
      "display_url" : "pic.twitter.com\/UqV93ZD1bc"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "652610581288124416",
  "geo" : { },
  "id_str" : "652613158734045184",
  "in_reply_to_user_id" : 208988759,
  "text" : "@GigaScience http:\/\/t.co\/UqV93ZD1bc",
  "id" : 652613158734045184,
  "in_reply_to_status_id" : 652610581288124416,
  "created_at" : "2015-10-09 22:34:36 +0000",
  "in_reply_to_screen_name" : "GigaScience",
  "in_reply_to_user_id_str" : "208988759",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "652609017081147393",
  "geo" : { },
  "id_str" : "652610027497385984",
  "in_reply_to_user_id" : 14286491,
  "text" : "Which I don\u2019t mind at all, but I guess in the short run this could be abused much easier than my publicly available genetic data.",
  "id" : 652610027497385984,
  "in_reply_to_status_id" : 652609017081147393,
  "created_at" : "2015-10-09 22:22:10 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "652609017081147393",
  "text" : "Due to openSNP I\u2019ve now participated in so many sociological studies that you can get my complete psych-profile from peer reviewed articles.",
  "id" : 652609017081147393,
  "created_at" : "2015-10-09 22:18:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Madeleine Price Ball",
      "screen_name" : "madprime",
      "indices" : [ 3, 12 ],
      "id_str" : "71557700",
      "id" : 71557700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/jpGoNgWWz1",
      "expanded_url" : "http:\/\/arstechnica.com\/tech-policy\/2015\/10\/gene-patents-probably-dead-worldwide-following-australian-court-decision\/",
      "display_url" : "arstechnica.com\/tech-policy\/20\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "652545690376237056",
  "text" : "RT @madprime: Australia follows the US in rejecting genotype\u2192phenotype gene patents http:\/\/t.co\/jpGoNgWWz1",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 70, 92 ],
        "url" : "http:\/\/t.co\/jpGoNgWWz1",
        "expanded_url" : "http:\/\/arstechnica.com\/tech-policy\/2015\/10\/gene-patents-probably-dead-worldwide-following-australian-court-decision\/",
        "display_url" : "arstechnica.com\/tech-policy\/20\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "652527215679283201",
    "text" : "Australia follows the US in rejecting genotype\u2192phenotype gene patents http:\/\/t.co\/jpGoNgWWz1",
    "id" : 652527215679283201,
    "created_at" : "2015-10-09 16:53:06 +0000",
    "user" : {
      "name" : "Madeleine Price Ball",
      "screen_name" : "madprime",
      "protected" : false,
      "id_str" : "71557700",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/515539302931910656\/9N7oFHFZ_normal.png",
      "id" : 71557700,
      "verified" : false
    }
  },
  "id" : 652545690376237056,
  "created_at" : "2015-10-09 18:06:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GigaScience",
      "screen_name" : "GigaScience",
      "indices" : [ 0, 12 ],
      "id_str" : "208988759",
      "id" : 208988759
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "652522725328715776",
  "geo" : { },
  "id_str" : "652523419909660672",
  "in_reply_to_user_id" : 208988759,
  "text" : "@GigaScience best flash drive ever!",
  "id" : 652523419909660672,
  "in_reply_to_status_id" : 652522725328715776,
  "created_at" : "2015-10-09 16:38:01 +0000",
  "in_reply_to_screen_name" : "GigaScience",
  "in_reply_to_user_id_str" : "208988759",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick England",
      "screen_name" : "nwe23",
      "indices" : [ 0, 6 ],
      "id_str" : "228203253",
      "id" : 228203253
    }, {
      "name" : "Fiona Nielsen",
      "screen_name" : "glyn_dk",
      "indices" : [ 7, 15 ],
      "id_str" : "32340834",
      "id" : 32340834
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "652418449264771072",
  "geo" : { },
  "id_str" : "652523330956828672",
  "in_reply_to_user_id" : 228203253,
  "text" : "@nwe23 @glyn_dk the second rule unfortunately seems to be: \u201Cexcept when it is this very special case that I have with my data\u201D\u2026",
  "id" : 652523330956828672,
  "in_reply_to_status_id" : 652418449264771072,
  "created_at" : "2015-10-09 16:37:40 +0000",
  "in_reply_to_screen_name" : "nwe23",
  "in_reply_to_user_id_str" : "228203253",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GigaScience",
      "screen_name" : "GigaScience",
      "indices" : [ 0, 12 ],
      "id_str" : "208988759",
      "id" : 208988759
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "652511322320584705",
  "geo" : { },
  "id_str" : "652520425952542720",
  "in_reply_to_user_id" : 208988759,
  "text" : "@GigaScience do you decapitate it in order to access the connector?",
  "id" : 652520425952542720,
  "in_reply_to_status_id" : 652511322320584705,
  "created_at" : "2015-10-09 16:26:07 +0000",
  "in_reply_to_screen_name" : "GigaScience",
  "in_reply_to_user_id_str" : "208988759",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "652463484295323648",
  "text" : "Btw: any bioinformatics\/genomics conferences in January in India that would like me as speaker? Need an excuse to attend a wedding in India.",
  "id" : 652463484295323648,
  "created_at" : "2015-10-09 12:39:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "malech maltz",
      "screen_name" : "malech",
      "indices" : [ 0, 7 ],
      "id_str" : "784085846391713793",
      "id" : 784085846391713793
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "652461763716378624",
  "text" : "@malech darf ich mal zu Besuch kommen? :3",
  "id" : 652461763716378624,
  "created_at" : "2015-10-09 12:33:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "652453910226075648",
  "text" : "\u00ABYou don\u2019t have to search too hard to find social monogamy in animals. Real genetic monogamy is quite a different story.\u00BB",
  "id" : 652453910226075648,
  "created_at" : "2015-10-09 12:01:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 37 ],
      "url" : "https:\/\/t.co\/apcp6jsVLl",
      "expanded_url" : "https:\/\/instagram.com\/p\/8nFAfYBwvF\/",
      "display_url" : "instagram.com\/p\/8nFAfYBwvF\/"
    } ]
  },
  "geo" : { },
  "id_str" : "652404336467812352",
  "text" : "Gone fishing. https:\/\/t.co\/apcp6jsVLl",
  "id" : 652404336467812352,
  "created_at" : "2015-10-09 08:44:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/5OfqTtUC4f",
      "expanded_url" : "http:\/\/journals.plos.org\/plosone\/article?id=10.1371\/journal.pone.0137974",
      "display_url" : "journals.plos.org\/plosone\/articl\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "652396313804472320",
  "text" : "how competitive exclusion might not work in practice. http:\/\/t.co\/5OfqTtUC4f",
  "id" : 652396313804472320,
  "created_at" : "2015-10-09 08:12:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 46 ],
      "url" : "http:\/\/t.co\/7LWsSQBIhb",
      "expanded_url" : "http:\/\/i.imgur.com\/m8MKD0G.gif",
      "display_url" : "i.imgur.com\/m8MKD0G.gif"
    } ]
  },
  "geo" : { },
  "id_str" : "652378235590823937",
  "text" : "an allegory of academia http:\/\/t.co\/7LWsSQBIhb",
  "id" : 652378235590823937,
  "created_at" : "2015-10-09 07:01:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Allium",
      "screen_name" : "TheAllium",
      "indices" : [ 3, 13 ],
      "id_str" : "2246304439",
      "id" : 2246304439
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/gnnf6A2IGB",
      "expanded_url" : "http:\/\/tinyurl.com\/oozumjw",
      "display_url" : "tinyurl.com\/oozumjw"
    } ]
  },
  "geo" : { },
  "id_str" : "652373342754865152",
  "text" : "RT @TheAllium: Tears Of Joy At Conference As Bioinformaticist Says \u201CI Won\u2019t Go Into Detail Of Algorithm\u201D http:\/\/t.co\/gnnf6A2IGB via @theall\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The Allium",
        "screen_name" : "TheAllium",
        "indices" : [ 117, 127 ],
        "id_str" : "2246304439",
        "id" : 2246304439
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 90, 112 ],
        "url" : "http:\/\/t.co\/gnnf6A2IGB",
        "expanded_url" : "http:\/\/tinyurl.com\/oozumjw",
        "display_url" : "tinyurl.com\/oozumjw"
      } ]
    },
    "geo" : { },
    "id_str" : "652217579205955584",
    "text" : "Tears Of Joy At Conference As Bioinformaticist Says \u201CI Won\u2019t Go Into Detail Of Algorithm\u201D http:\/\/t.co\/gnnf6A2IGB via @theallium",
    "id" : 652217579205955584,
    "created_at" : "2015-10-08 20:22:43 +0000",
    "user" : {
      "name" : "The Allium",
      "screen_name" : "TheAllium",
      "protected" : false,
      "id_str" : "2246304439",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/415147347018924032\/qbYkkvbo_normal.png",
      "id" : 2246304439,
      "verified" : false
    }
  },
  "id" : 652373342754865152,
  "created_at" : "2015-10-09 06:41:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katha",
      "screen_name" : "kathakatze",
      "indices" : [ 0, 11 ],
      "id_str" : "541170257",
      "id" : 541170257
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 35 ],
      "url" : "https:\/\/t.co\/tb9eHExEI7",
      "expanded_url" : "https:\/\/media.giphy.com\/media\/pP3yXxuuPeHug\/giphy.gif",
      "display_url" : "media.giphy.com\/media\/pP3yXxuu\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "652260648483745792",
  "geo" : { },
  "id_str" : "652261548132564993",
  "in_reply_to_user_id" : 541170257,
  "text" : "@kathakatze https:\/\/t.co\/tb9eHExEI7",
  "id" : 652261548132564993,
  "in_reply_to_status_id" : 652260648483745792,
  "created_at" : "2015-10-08 23:17:26 +0000",
  "in_reply_to_screen_name" : "kathakatze",
  "in_reply_to_user_id_str" : "541170257",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/7ofLm8dlXu",
      "expanded_url" : "http:\/\/www.nytimes.com\/2015\/10\/08\/fashion\/throw-momma-from-the-plane.html?smid=tw-share",
      "display_url" : "nytimes.com\/2015\/10\/08\/fas\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "652259979387400192",
  "text" : "once we reach cruising altitude, our hearts and minds don\u2019t have to be quite as cramped as our legs\u00BB \u2708\uFE0F http:\/\/t.co\/7ofLm8dlXu",
  "id" : 652259979387400192,
  "created_at" : "2015-10-08 23:11:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fiona Nielsen",
      "screen_name" : "glyn_dk",
      "indices" : [ 0, 8 ],
      "id_str" : "32340834",
      "id" : 32340834
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "652234514803130368",
  "geo" : { },
  "id_str" : "652238070809554945",
  "in_reply_to_user_id" : 32340834,
  "text" : "@glyn_dk that escalated quickly ;)",
  "id" : 652238070809554945,
  "in_reply_to_status_id" : 652234514803130368,
  "created_at" : "2015-10-08 21:44:08 +0000",
  "in_reply_to_screen_name" : "glyn_dk",
  "in_reply_to_user_id_str" : "32340834",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kaitlin Thaney \uD83D\uDC81\uD83C\uDFFB",
      "screen_name" : "kaythaney",
      "indices" : [ 0, 10 ],
      "id_str" : "22839233",
      "id" : 22839233
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 44 ],
      "url" : "http:\/\/t.co\/YSkv1cnZm2",
      "expanded_url" : "http:\/\/adainitiative.org\/category\/ada-initiative-projects\/anti-harassment-policy\/",
      "display_url" : "adainitiative.org\/category\/ada-i\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "652214992033447937",
  "geo" : { },
  "id_str" : "652215931926638592",
  "in_reply_to_user_id" : 22839233,
  "text" : "@kaythaney what about http:\/\/t.co\/YSkv1cnZm2 ?",
  "id" : 652215931926638592,
  "in_reply_to_status_id" : 652214992033447937,
  "created_at" : "2015-10-08 20:16:10 +0000",
  "in_reply_to_screen_name" : "kaythaney",
  "in_reply_to_user_id_str" : "22839233",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kaitlin Thaney \uD83D\uDC81\uD83C\uDFFB",
      "screen_name" : "kaythaney",
      "indices" : [ 3, 13 ],
      "id_str" : "22839233",
      "id" : 22839233
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "652214759618703360",
  "text" : "RT @kaythaney: Facing a \"but why point out bad behavior, people are well-behaved\" argument for not having a Code of Conduct. Resource sugge\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "652213682831794176",
    "text" : "Facing a \"but why point out bad behavior, people are well-behaved\" argument for not having a Code of Conduct. Resource suggestions?",
    "id" : 652213682831794176,
    "created_at" : "2015-10-08 20:07:14 +0000",
    "user" : {
      "name" : "Kaitlin Thaney \uD83D\uDC81\uD83C\uDFFB",
      "screen_name" : "kaythaney",
      "protected" : false,
      "id_str" : "22839233",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/932288468029509632\/_I0e0wgc_normal.jpg",
      "id" : 22839233,
      "verified" : false
    }
  },
  "id" : 652214759618703360,
  "created_at" : "2015-10-08 20:11:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 71 ],
      "url" : "http:\/\/t.co\/LLIlRGKUaf",
      "expanded_url" : "http:\/\/www.op-online.de\/bilder\/2013\/06\/28\/2979241\/1364663869-dpa_1482dc0054ced2e3-iGYesUOB1a7.jpg",
      "display_url" : "op-online.de\/bilder\/2013\/06\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "652203814896934912",
  "geo" : { },
  "id_str" : "652204201334935552",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot das sieht nur auf dem Produktfoto so aus. http:\/\/t.co\/LLIlRGKUaf",
  "id" : 652204201334935552,
  "in_reply_to_status_id" : 652203814896934912,
  "created_at" : "2015-10-08 19:29:33 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "652202827503267844",
  "geo" : { },
  "id_str" : "652203358770569216",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot \u2018f\u00FCr Kinder\u2019, fr\u00FCh \u00FCbt sich?",
  "id" : 652203358770569216,
  "in_reply_to_status_id" : 652202827503267844,
  "created_at" : "2015-10-08 19:26:12 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 3, 12 ],
      "id_str" : "14861745",
      "id" : 14861745
    }, {
      "name" : "European Parliament",
      "screen_name" : "europarl",
      "indices" : [ 87, 96 ],
      "id_str" : "1324782410",
      "id" : 1324782410
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/kgFCIxWEVP",
      "expanded_url" : "http:\/\/mepassistant.tumblr.com\/post\/130325907312\/when-youre-successfully-bluffing-on-your-level-of",
      "display_url" : "mepassistant.tumblr.com\/post\/130325907\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "652199169482977280",
  "text" : "RT @Senficon: Every scientific publisher's \"text and data mining demonstration\" in the @europarl ever. http:\/\/t.co\/kgFCIxWEVP via @mepassis\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "European Parliament",
        "screen_name" : "europarl",
        "indices" : [ 73, 82 ],
        "id_str" : "1324782410",
        "id" : 1324782410
      }, {
        "name" : "mepassistant",
        "screen_name" : "mepassistants",
        "indices" : [ 116, 130 ],
        "id_str" : "2256741062",
        "id" : 2256741062
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 89, 111 ],
        "url" : "http:\/\/t.co\/kgFCIxWEVP",
        "expanded_url" : "http:\/\/mepassistant.tumblr.com\/post\/130325907312\/when-youre-successfully-bluffing-on-your-level-of",
        "display_url" : "mepassistant.tumblr.com\/post\/130325907\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "652177666662092800",
    "text" : "Every scientific publisher's \"text and data mining demonstration\" in the @europarl ever. http:\/\/t.co\/kgFCIxWEVP via @mepassistants",
    "id" : 652177666662092800,
    "created_at" : "2015-10-08 17:44:07 +0000",
    "user" : {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "protected" : false,
      "id_str" : "14861745",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/637016870638350336\/QrtPmoul_normal.jpg",
      "id" : 14861745,
      "verified" : true
    }
  },
  "id" : 652199169482977280,
  "created_at" : "2015-10-08 19:09:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "652198927593308160",
  "text" : "I like when we\u2019re called \u2018refreshingly honest\u2019 for the approach we are taking with openSNP.",
  "id" : 652198927593308160,
  "created_at" : "2015-10-08 19:08:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "beau",
      "screen_name" : "beaugunderson",
      "indices" : [ 0, 14 ],
      "id_str" : "5746882",
      "id" : 5746882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "652151022224175110",
  "geo" : { },
  "id_str" : "652155249247956992",
  "in_reply_to_user_id" : 5746882,
  "text" : "@beaugunderson sounds like the plot for a serial killer-movie.",
  "id" : 652155249247956992,
  "in_reply_to_status_id" : 652151022224175110,
  "created_at" : "2015-10-08 16:15:02 +0000",
  "in_reply_to_screen_name" : "beaugunderson",
  "in_reply_to_user_id_str" : "5746882",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Susie Theroux",
      "screen_name" : "coccolithophile",
      "indices" : [ 3, 19 ],
      "id_str" : "36953014",
      "id" : 36953014
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/coccolithophile\/status\/651949930391601153\/photo\/1",
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/8gTAdUShlr",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CQwxAa5UYAIoVkZ.png",
      "id_str" : "651949929351372802",
      "id" : 651949929351372802,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQwxAa5UYAIoVkZ.png",
      "sizes" : [ {
        "h" : 1504,
        "resize" : "fit",
        "w" : 3000
      }, {
        "h" : 341,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1027,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 602,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/8gTAdUShlr"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/E5G3XvAJGT",
      "expanded_url" : "http:\/\/megabiome.net\/2015\/06\/the-real-ghost-tree\/",
      "display_url" : "megabiome.net\/2015\/06\/the-re\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "652148620632809472",
  "text" : "RT @coccolithophile: \"...there are no ghosts in the entire paper...\"\n\nhttp:\/\/t.co\/E5G3XvAJGT http:\/\/t.co\/8gTAdUShlr",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/coccolithophile\/status\/651949930391601153\/photo\/1",
        "indices" : [ 72, 94 ],
        "url" : "http:\/\/t.co\/8gTAdUShlr",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CQwxAa5UYAIoVkZ.png",
        "id_str" : "651949929351372802",
        "id" : 651949929351372802,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQwxAa5UYAIoVkZ.png",
        "sizes" : [ {
          "h" : 1504,
          "resize" : "fit",
          "w" : 3000
        }, {
          "h" : 341,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1027,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 602,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/8gTAdUShlr"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 49, 71 ],
        "url" : "http:\/\/t.co\/E5G3XvAJGT",
        "expanded_url" : "http:\/\/megabiome.net\/2015\/06\/the-real-ghost-tree\/",
        "display_url" : "megabiome.net\/2015\/06\/the-re\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "651949930391601153",
    "text" : "\"...there are no ghosts in the entire paper...\"\n\nhttp:\/\/t.co\/E5G3XvAJGT http:\/\/t.co\/8gTAdUShlr",
    "id" : 651949930391601153,
    "created_at" : "2015-10-08 02:39:10 +0000",
    "user" : {
      "name" : "Susie Theroux",
      "screen_name" : "coccolithophile",
      "protected" : false,
      "id_str" : "36953014",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/519371405188546560\/4sjmSVcM_normal.jpeg",
      "id" : 36953014,
      "verified" : false
    }
  },
  "id" : 652148620632809472,
  "created_at" : "2015-10-08 15:48:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mick Watson",
      "screen_name" : "BioMickWatson",
      "indices" : [ 0, 14 ],
      "id_str" : "228586748",
      "id" : 228586748
    }, {
      "name" : "Nick Loman",
      "screen_name" : "pathogenomenick",
      "indices" : [ 15, 31 ],
      "id_str" : "85906238",
      "id" : 85906238
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/652148409969717248\/photo\/1",
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/2gTD53MDk3",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CQzlhXbWwAA_HDf.png",
      "id_str" : "652148407449075712",
      "id" : 652148407449075712,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQzlhXbWwAA_HDf.png",
      "sizes" : [ {
        "h" : 256,
        "resize" : "fit",
        "w" : 292
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 256,
        "resize" : "fit",
        "w" : 292
      }, {
        "h" : 256,
        "resize" : "fit",
        "w" : 292
      }, {
        "h" : 256,
        "resize" : "fit",
        "w" : 292
      } ],
      "display_url" : "pic.twitter.com\/2gTD53MDk3"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "652147338480214016",
  "geo" : { },
  "id_str" : "652148409969717248",
  "in_reply_to_user_id" : 228586748,
  "text" : "@BioMickWatson @pathogenomenick so someone managed to have a -5 expertise in bioinformatics? :D http:\/\/t.co\/2gTD53MDk3",
  "id" : 652148409969717248,
  "in_reply_to_status_id" : 652147338480214016,
  "created_at" : "2015-10-08 15:47:51 +0000",
  "in_reply_to_screen_name" : "BioMickWatson",
  "in_reply_to_user_id_str" : "228586748",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "montypoosdaily",
      "indices" : [ 11, 26 ]
    } ],
    "urls" : [ {
      "indices" : [ 52, 75 ],
      "url" : "https:\/\/t.co\/pi5aXtvmgm",
      "expanded_url" : "https:\/\/instagram.com\/monty_poos_daily\/",
      "display_url" : "instagram.com\/monty_poos_dai\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "652133597009174529",
  "text" : "I love how #montypoosdaily is a thing on Instagram. https:\/\/t.co\/pi5aXtvmgm",
  "id" : 652133597009174529,
  "created_at" : "2015-10-08 14:49:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 10, 22 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "652124354227138560",
  "text" : "Thanks to @helgerausch for migrating our openSNP database to a much faster machine!",
  "id" : 652124354227138560,
  "created_at" : "2015-10-08 14:12:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mozilla Science Lab",
      "screen_name" : "MozillaScience",
      "indices" : [ 3, 18 ],
      "id_str" : "1428575976",
      "id" : 1428575976
    }, {
      "name" : "Joey  Lee",
      "screen_name" : "leejoeyk",
      "indices" : [ 77, 86 ],
      "id_str" : "575961466",
      "id" : 575961466
    }, {
      "name" : "\u24EA Rik Smith-Unna \uD83C\uDDF0\uD83C\uDDEA",
      "screen_name" : "blahah404",
      "indices" : [ 87, 97 ],
      "id_str" : "99173786",
      "id" : 99173786
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 98, 114 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "652114177906089984",
  "text" : "RT @MozillaScience: We\u2019ll be using this etherpad for our call at 11ET, feat. @leejoeyk @blahah404 @gedankenstuecke + more-  https:\/\/t.co\/5l\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Joey  Lee",
        "screen_name" : "leejoeyk",
        "indices" : [ 57, 66 ],
        "id_str" : "575961466",
        "id" : 575961466
      }, {
        "name" : "\u24EA Rik Smith-Unna \uD83C\uDDF0\uD83C\uDDEA",
        "screen_name" : "blahah404",
        "indices" : [ 67, 77 ],
        "id_str" : "99173786",
        "id" : 99173786
      }, {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 78, 94 ],
        "id_str" : "14286491",
        "id" : 14286491
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "openscience",
        "indices" : [ 128, 140 ]
      } ],
      "urls" : [ {
        "indices" : [ 104, 127 ],
        "url" : "https:\/\/t.co\/5lUSjGdEPU",
        "expanded_url" : "https:\/\/public.etherpad-mozilla.org\/p\/T007eAyPQG",
        "display_url" : "public.etherpad-mozilla.org\/p\/T007eAyPQG"
      } ]
    },
    "geo" : { },
    "id_str" : "652111096686485505",
    "text" : "We\u2019ll be using this etherpad for our call at 11ET, feat. @leejoeyk @blahah404 @gedankenstuecke + more-  https:\/\/t.co\/5lUSjGdEPU #openscience",
    "id" : 652111096686485505,
    "created_at" : "2015-10-08 13:19:35 +0000",
    "user" : {
      "name" : "Mozilla Science Lab",
      "screen_name" : "MozillaScience",
      "protected" : false,
      "id_str" : "1428575976",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/687287790049034240\/lwIk-ZQT_normal.png",
      "id" : 1428575976,
      "verified" : false
    }
  },
  "id" : 652114177906089984,
  "created_at" : "2015-10-08 13:31:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/87q6lunpig",
      "expanded_url" : "http:\/\/www.emilyerotica.com\/blog\/2015\/8\/5\/brains-bunnies-and-boners",
      "display_url" : "emilyerotica.com\/blog\/2015\/8\/5\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "652109137489317888",
  "text" : "on tacit pleasures and how you can explain everything: \u00ABwe began testing the sex toy of the future.\u00A0 For science\u00BB http:\/\/t.co\/87q6lunpig",
  "id" : 652109137489317888,
  "created_at" : "2015-10-08 13:11:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Edmunds",
      "screen_name" : "SCEdmunds",
      "indices" : [ 0, 10 ],
      "id_str" : "176024190",
      "id" : 176024190
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "652095666907389953",
  "geo" : { },
  "id_str" : "652095960382894080",
  "in_reply_to_user_id" : 176024190,
  "text" : "@SCEdmunds and now steal their fire!",
  "id" : 652095960382894080,
  "in_reply_to_status_id" : 652095666907389953,
  "created_at" : "2015-10-08 12:19:26 +0000",
  "in_reply_to_screen_name" : "SCEdmunds",
  "in_reply_to_user_id_str" : "176024190",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/652087200516018176\/photo\/1",
      "indices" : [ 52, 74 ],
      "url" : "http:\/\/t.co\/Tgcbehj37Q",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CQyt2hPWoAE07FC.png",
      "id_str" : "652087198209187841",
      "id" : 652087198209187841,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQyt2hPWoAE07FC.png",
      "sizes" : [ {
        "h" : 548,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 968,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 975,
        "resize" : "fit",
        "w" : 1209
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 975,
        "resize" : "fit",
        "w" : 1209
      } ],
      "display_url" : "pic.twitter.com\/Tgcbehj37Q"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "652087200516018176",
  "text" : "Your De Bruijn graphs should look like this, right? http:\/\/t.co\/Tgcbehj37Q",
  "id" : 652087200516018176,
  "created_at" : "2015-10-08 11:44:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 52 ],
      "url" : "http:\/\/t.co\/DRjrN7QqPx",
      "expanded_url" : "http:\/\/media2.giphy.com\/media\/UgL1I9HwiDBdu\/giphy.gif",
      "display_url" : "media2.giphy.com\/media\/UgL1I9Hw\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "652061910423216129",
  "text" : "all glory to the hypno-coffee http:\/\/t.co\/DRjrN7QqPx",
  "id" : 652061910423216129,
  "created_at" : "2015-10-08 10:04:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "lifehack",
      "indices" : [ 68, 77 ]
    } ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/D0qjcOKFFo",
      "expanded_url" : "http:\/\/lifehacker.com\/5952455\/how-to-create-a-blackmail-file-on-someone",
      "display_url" : "lifehacker.com\/5952455\/how-to\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "652036926703316996",
  "text" : "\u2019how to blackmail someone\u2019 exactly what the world needed filed with #lifehack\u2026 http:\/\/t.co\/D0qjcOKFFo",
  "id" : 652036926703316996,
  "created_at" : "2015-10-08 08:24:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "652033995237146624",
  "text" : "\u00ABDid you have an other expenses?\u00BB \u2014 \u00ABI guess the university won\u2019t reimburse our karaoke expenses, will they?\u00BB",
  "id" : 652033995237146624,
  "created_at" : "2015-10-08 08:13:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 81 ],
      "url" : "https:\/\/t.co\/aGnEZYrhEO",
      "expanded_url" : "https:\/\/twitter.com\/GigaScience\/status\/651943690848587776",
      "display_url" : "twitter.com\/GigaScience\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "652020529474486272",
  "text" : "Probably just an external attachment to their magic wand. https:\/\/t.co\/aGnEZYrhEO",
  "id" : 652020529474486272,
  "created_at" : "2015-10-08 07:19:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mozilla Science Lab",
      "screen_name" : "MozillaScience",
      "indices" : [ 3, 18 ],
      "id_str" : "1428575976",
      "id" : 1428575976
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 83, 99 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MozFest",
      "indices" : [ 67, 75 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "651842391134052352",
  "text" : "RT @MozillaScience: Join us tmrw (11ET) for our call on all things #MozFest, feat. @gedankenstuecke, a team from RIT, + the new Fellows: ht\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 63, 79 ],
        "id_str" : "14286491",
        "id" : 14286491
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MozFest",
        "indices" : [ 47, 55 ]
      } ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/5lUSjGdEPU",
        "expanded_url" : "https:\/\/public.etherpad-mozilla.org\/p\/T007eAyPQG",
        "display_url" : "public.etherpad-mozilla.org\/p\/T007eAyPQG"
      } ]
    },
    "geo" : { },
    "id_str" : "651831327688392705",
    "text" : "Join us tmrw (11ET) for our call on all things #MozFest, feat. @gedankenstuecke, a team from RIT, + the new Fellows: https:\/\/t.co\/5lUSjGdEPU",
    "id" : 651831327688392705,
    "created_at" : "2015-10-07 18:47:53 +0000",
    "user" : {
      "name" : "Mozilla Science Lab",
      "screen_name" : "MozillaScience",
      "protected" : false,
      "id_str" : "1428575976",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/687287790049034240\/lwIk-ZQT_normal.png",
      "id" : 1428575976,
      "verified" : false
    }
  },
  "id" : 651842391134052352,
  "created_at" : "2015-10-07 19:31:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 39 ],
      "url" : "http:\/\/t.co\/Ufu5x6uWQG",
      "expanded_url" : "http:\/\/www.qwantz.com\/index.php?comic=2877&mobile=2",
      "display_url" : "qwantz.com\/index.php?comi\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.113982, 8.753493 ]
  },
  "id_str" : "651814574027575300",
  "text" : "It's everywhere! http:\/\/t.co\/Ufu5x6uWQG",
  "id" : 651814574027575300,
  "created_at" : "2015-10-07 17:41:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "651811717954039809",
  "text" : "My apartment door won\u2019t unlock and my first belief is that it\u2019s due to me standing in front of the wrong door, not a broken lock.",
  "id" : 651811717954039809,
  "created_at" : "2015-10-07 17:29:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason_Scroggins",
      "screen_name" : "Jason_Scroggins",
      "indices" : [ 3, 19 ],
      "id_str" : "14167226",
      "id" : 14167226
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/h9jT988BSl",
      "expanded_url" : "http:\/\/goo.gl\/fvzNGH",
      "display_url" : "goo.gl\/fvzNGH"
    } ]
  },
  "geo" : { },
  "id_str" : "651712127225491456",
  "text" : "RT @Jason_Scroggins: \"Why I Was Fired\" By Steven Salaita  http:\/\/t.co\/h9jT988BSl",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 37, 59 ],
        "url" : "http:\/\/t.co\/h9jT988BSl",
        "expanded_url" : "http:\/\/goo.gl\/fvzNGH",
        "display_url" : "goo.gl\/fvzNGH"
      } ]
    },
    "geo" : { },
    "id_str" : "651602111512375296",
    "text" : "\"Why I Was Fired\" By Steven Salaita  http:\/\/t.co\/h9jT988BSl",
    "id" : 651602111512375296,
    "created_at" : "2015-10-07 03:37:04 +0000",
    "user" : {
      "name" : "Jason_Scroggins",
      "screen_name" : "Jason_Scroggins",
      "protected" : false,
      "id_str" : "14167226",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/438873266082439168\/LImyvzxl_normal.jpeg",
      "id" : 14167226,
      "verified" : false
    }
  },
  "id" : 651712127225491456,
  "created_at" : "2015-10-07 10:54:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christophe Dessimoz",
      "screen_name" : "cdessimoz",
      "indices" : [ 3, 13 ],
      "id_str" : "274388734",
      "id" : 274388734
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RECOMB_CG2015",
      "indices" : [ 15, 29 ]
    } ],
    "urls" : [ {
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/CsvzDTxaAv",
      "expanded_url" : "http:\/\/www.biomedcentral.com\/bmcgenomics\/supplements\/16\/S10",
      "display_url" : "biomedcentral.com\/bmcgenomics\/su\u2026"
    }, {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/JFteL8awio",
      "expanded_url" : "http:\/\/www.biomedcentral.com\/bmcbioinformatics\/supplements\/16\/S14",
      "display_url" : "biomedcentral.com\/bmcbioinformat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "651696500498661376",
  "text" : "RT @cdessimoz: #RECOMB_CG2015 proceedings available here: http:\/\/t.co\/CsvzDTxaAv and here: http:\/\/t.co\/JFteL8awio",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "RECOMB_CG2015",
        "indices" : [ 0, 14 ]
      } ],
      "urls" : [ {
        "indices" : [ 43, 65 ],
        "url" : "http:\/\/t.co\/CsvzDTxaAv",
        "expanded_url" : "http:\/\/www.biomedcentral.com\/bmcgenomics\/supplements\/16\/S10",
        "display_url" : "biomedcentral.com\/bmcgenomics\/su\u2026"
      }, {
        "indices" : [ 76, 98 ],
        "url" : "http:\/\/t.co\/JFteL8awio",
        "expanded_url" : "http:\/\/www.biomedcentral.com\/bmcbioinformatics\/supplements\/16\/S14",
        "display_url" : "biomedcentral.com\/bmcbioinformat\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "651695700267401216",
    "text" : "#RECOMB_CG2015 proceedings available here: http:\/\/t.co\/CsvzDTxaAv and here: http:\/\/t.co\/JFteL8awio",
    "id" : 651695700267401216,
    "created_at" : "2015-10-07 09:48:57 +0000",
    "user" : {
      "name" : "Christophe Dessimoz",
      "screen_name" : "cdessimoz",
      "protected" : false,
      "id_str" : "274388734",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1467970873\/photo_normal.png",
      "id" : 274388734,
      "verified" : false
    }
  },
  "id" : 651696500498661376,
  "created_at" : "2015-10-07 09:52:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11569330908083, 8.649542863272101 ]
  },
  "id_str" : "651691183996071936",
  "text" : "coming from biology i\u2019m always a bit offended when computational people go \u2018biologists don\u2019t care &amp; don\u2019t need to know\u2019. unnecessary divide\u2026",
  "id" : 651691183996071936,
  "created_at" : "2015-10-07 09:31:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 46 ],
      "url" : "http:\/\/t.co\/4JnmEX2ioS",
      "expanded_url" : "http:\/\/www.smbc-comics.com\/index.php?id=3883",
      "display_url" : "smbc-comics.com\/index.php?id=3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "651673924695117824",
  "text" : "The Most American Movie http:\/\/t.co\/4JnmEX2ioS",
  "id" : 651673924695117824,
  "created_at" : "2015-10-07 08:22:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Loman",
      "screen_name" : "pathogenomenick",
      "indices" : [ 3, 19 ],
      "id_str" : "85906238",
      "id" : 85906238
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "651660995073585153",
  "text" : "RT @pathogenomenick: We Asked 92 Bioinformaticians What Frustrated Them About Their Work: You Won't Believe What They Said! https:\/\/t.co\/Gy\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 103, 126 ],
        "url" : "https:\/\/t.co\/GyLJrRWT1K",
        "expanded_url" : "https:\/\/docs.google.com\/spreadsheets\/d\/1MnVIxyTR8cQy4TZ1nsKRzHhQUfFuPywLm7Z1zNOqCII\/edit?usp=sharing",
        "display_url" : "docs.google.com\/spreadsheets\/d\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "651441210024984576",
    "text" : "We Asked 92 Bioinformaticians What Frustrated Them About Their Work: You Won't Believe What They Said! https:\/\/t.co\/GyLJrRWT1K",
    "id" : 651441210024984576,
    "created_at" : "2015-10-06 16:57:42 +0000",
    "user" : {
      "name" : "Nick Loman",
      "screen_name" : "pathogenomenick",
      "protected" : false,
      "id_str" : "85906238",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/654948428951195648\/i5lt2BWa_normal.jpg",
      "id" : 85906238,
      "verified" : false
    }
  },
  "id" : 651660995073585153,
  "created_at" : "2015-10-07 07:31:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "beau",
      "screen_name" : "beaugunderson",
      "indices" : [ 3, 17 ],
      "id_str" : "5746882",
      "id" : 5746882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/46HATL86Xh",
      "expanded_url" : "https:\/\/gist.github.com\/beaugunderson\/16ddea6d0cbe1d53db44",
      "display_url" : "gist.github.com\/beaugunderson\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "651643676184178688",
  "text" : "RT @beaugunderson: can't wait until the 2015 re:invent videos are online to rehash this: https:\/\/t.co\/46HATL86Xh (still haven't got anyone \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 70, 93 ],
        "url" : "https:\/\/t.co\/46HATL86Xh",
        "expanded_url" : "https:\/\/gist.github.com\/beaugunderson\/16ddea6d0cbe1d53db44",
        "display_url" : "gist.github.com\/beaugunderson\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "651626762766422016",
    "text" : "can't wait until the 2015 re:invent videos are online to rehash this: https:\/\/t.co\/46HATL86Xh (still haven't got anyone to comment, sadly)",
    "id" : 651626762766422016,
    "created_at" : "2015-10-07 05:15:01 +0000",
    "user" : {
      "name" : "beau",
      "screen_name" : "beaugunderson",
      "protected" : false,
      "id_str" : "5746882",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/913840034016399360\/pU3IIxqf_normal.jpg",
      "id" : 5746882,
      "verified" : false
    }
  },
  "id" : 651643676184178688,
  "created_at" : "2015-10-07 06:22:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Whitehead",
      "screen_name" : "Mikey_Whitehead",
      "indices" : [ 0, 16 ],
      "id_str" : "25774136",
      "id" : 25774136
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "651575207480528896",
  "geo" : { },
  "id_str" : "651579988311977984",
  "in_reply_to_user_id" : 25774136,
  "text" : "@Mikey_Whitehead the Australian guy who had to listen to it was just shaking his head. That\u2019s good, right?",
  "id" : 651579988311977984,
  "in_reply_to_status_id" : 651575207480528896,
  "created_at" : "2015-10-07 02:09:09 +0000",
  "in_reply_to_screen_name" : "Mikey_Whitehead",
  "in_reply_to_user_id_str" : "25774136",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.10497283942957, 8.68872642574797 ]
  },
  "id_str" : "651573995410735104",
  "text" : "Item completed from my bucket list: Performing a karaoke duet of \u2018Where the Wild Roses Grow\u2019 in an underground bar.",
  "id" : 651573995410735104,
  "created_at" : "2015-10-07 01:45:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "beau",
      "screen_name" : "beaugunderson",
      "indices" : [ 0, 14 ],
      "id_str" : "5746882",
      "id" : 5746882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "651440019685552128",
  "geo" : { },
  "id_str" : "651440188422533120",
  "in_reply_to_user_id" : 5746882,
  "text" : "@beaugunderson yeah, that\u2019s a bit dated ;)",
  "id" : 651440188422533120,
  "in_reply_to_status_id" : 651440019685552128,
  "created_at" : "2015-10-06 16:53:38 +0000",
  "in_reply_to_screen_name" : "beaugunderson",
  "in_reply_to_user_id_str" : "5746882",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "beau",
      "screen_name" : "beaugunderson",
      "indices" : [ 0, 14 ],
      "id_str" : "5746882",
      "id" : 5746882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "651437855231729664",
  "geo" : { },
  "id_str" : "651439854786641920",
  "in_reply_to_user_id" : 5746882,
  "text" : "@beaugunderson around 1700 I think, do you need an exact number?",
  "id" : 651439854786641920,
  "in_reply_to_status_id" : 651437855231729664,
  "created_at" : "2015-10-06 16:52:19 +0000",
  "in_reply_to_screen_name" : "beaugunderson",
  "in_reply_to_user_id_str" : "5746882",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Loman",
      "screen_name" : "pathogenomenick",
      "indices" : [ 0, 16 ],
      "id_str" : "85906238",
      "id" : 85906238
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "651420370965262336",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11563250848651, 8.649692819378858 ]
  },
  "id_str" : "651420694316761088",
  "in_reply_to_user_id" : 85906238,
  "text" : "@pathogenomenick too bad, really want to have a paper published which contains my twitter handle on the author list! But i\u2019ll take the beer.",
  "id" : 651420694316761088,
  "in_reply_to_status_id" : 651420370965262336,
  "created_at" : "2015-10-06 15:36:10 +0000",
  "in_reply_to_screen_name" : "pathogenomenick",
  "in_reply_to_user_id_str" : "85906238",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Loman",
      "screen_name" : "pathogenomenick",
      "indices" : [ 0, 16 ],
      "id_str" : "85906238",
      "id" : 85906238
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "651416685510008833",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11562306020375, 8.649678441049382 ]
  },
  "id_str" : "651420278015324160",
  "in_reply_to_user_id" : 85906238,
  "text" : "@pathogenomenick will we all become co-authors on the resulting publication?",
  "id" : 651420278015324160,
  "in_reply_to_status_id" : 651416685510008833,
  "created_at" : "2015-10-06 15:34:31 +0000",
  "in_reply_to_screen_name" : "pathogenomenick",
  "in_reply_to_user_id_str" : "85906238",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Loman",
      "screen_name" : "pathogenomenick",
      "indices" : [ 3, 19 ],
      "id_str" : "85906238",
      "id" : 85906238
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "651420177393938433",
  "text" : "RT @pathogenomenick: I NEVER ask for this. If you do bioinformatics at any level please could you fill this 2 minute Q&amp;A out? https:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 109, 132 ],
        "url" : "https:\/\/t.co\/xwUiH3A1mA",
        "expanded_url" : "https:\/\/docs.google.com\/forms\/d\/10P299OB_cfwC7zyTBAdddo1Wh9py_vUGcTy-yczQoTU\/viewform",
        "display_url" : "docs.google.com\/forms\/d\/10P299\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "651416685510008833",
    "text" : "I NEVER ask for this. If you do bioinformatics at any level please could you fill this 2 minute Q&amp;A out? https:\/\/t.co\/xwUiH3A1mA",
    "id" : 651416685510008833,
    "created_at" : "2015-10-06 15:20:15 +0000",
    "user" : {
      "name" : "Nick Loman",
      "screen_name" : "pathogenomenick",
      "protected" : false,
      "id_str" : "85906238",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/654948428951195648\/i5lt2BWa_normal.jpg",
      "id" : 85906238,
      "verified" : false
    }
  },
  "id" : 651420177393938433,
  "created_at" : "2015-10-06 15:34:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Loman",
      "screen_name" : "pathogenomenick",
      "indices" : [ 0, 16 ],
      "id_str" : "85906238",
      "id" : 85906238
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "651416760357359616",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11560928591139, 8.649673197472515 ]
  },
  "id_str" : "651420077355569152",
  "in_reply_to_user_id" : 85906238,
  "text" : "@pathogenomenick there you go!",
  "id" : 651420077355569152,
  "in_reply_to_status_id" : 651416760357359616,
  "created_at" : "2015-10-06 15:33:43 +0000",
  "in_reply_to_screen_name" : "pathogenomenick",
  "in_reply_to_user_id_str" : "85906238",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lars Arvestad",
      "screen_name" : "arvestad",
      "indices" : [ 0, 9 ],
      "id_str" : "403987115",
      "id" : 403987115
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "651412826209275904",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11570724014111, 8.649528404061808 ]
  },
  "id_str" : "651413087023665152",
  "in_reply_to_user_id" : 403987115,
  "text" : "@arvestad yes, it\u2019s a very well executed talk. Really like his style!",
  "id" : 651413087023665152,
  "in_reply_to_status_id" : 651412826209275904,
  "created_at" : "2015-10-06 15:05:57 +0000",
  "in_reply_to_screen_name" : "arvestad",
  "in_reply_to_user_id_str" : "403987115",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RECOMB_CG2015",
      "indices" : [ 120, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11554880683418, 8.649520536006772 ]
  },
  "id_str" : "651411842246516736",
  "text" : "\u00ABLet me tell you what we\u2019ve tried to solve the problem. To say it right away: We failed. It\u2019s a really negative paper.\u00BB #RECOMB_CG2015",
  "id" : 651411842246516736,
  "created_at" : "2015-10-06 15:01:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nicola Segata",
      "screen_name" : "nsegata",
      "indices" : [ 0, 8 ],
      "id_str" : "18667519",
      "id" : 18667519
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "651405360377524224",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11559955955681, 8.649709255153548 ]
  },
  "id_str" : "651405654717018113",
  "in_reply_to_user_id" : 18667519,
  "text" : "@nsegata agree, that would be ideal. But i think it should be okay here, because each contribution is published now anyhow.",
  "id" : 651405654717018113,
  "in_reply_to_status_id" : 651405360377524224,
  "created_at" : "2015-10-06 14:36:25 +0000",
  "in_reply_to_screen_name" : "nsegata",
  "in_reply_to_user_id_str" : "18667519",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nicola Segata",
      "screen_name" : "nsegata",
      "indices" : [ 0, 8 ],
      "id_str" : "18667519",
      "id" : 18667519
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "651402814552436736",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11568370208536, 8.649392906395738 ]
  },
  "id_str" : "651404844448784386",
  "in_reply_to_user_id" : 18667519,
  "text" : "@nsegata thanks, trying to cover at least the people who are on Twitter themselves. For many others I\u2019m \u00B1unsure whether they\u2019d agree to it.",
  "id" : 651404844448784386,
  "in_reply_to_status_id" : 651402814552436736,
  "created_at" : "2015-10-06 14:33:12 +0000",
  "in_reply_to_screen_name" : "nsegata",
  "in_reply_to_user_id_str" : "18667519",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "openSNP team",
      "screen_name" : "openSNPorg",
      "indices" : [ 3, 14 ],
      "id_str" : "380205172",
      "id" : 380205172
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "651392574511521792",
  "text" : "RT @openSNPorg: We\u2019re down as we are moving our database to a new &amp; faster machine. Thanks to all the patrons who made it possible! https:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 120, 143 ],
        "url" : "https:\/\/t.co\/9P3qKmIaEg",
        "expanded_url" : "https:\/\/www.patreon.com\/openSNP",
        "display_url" : "patreon.com\/openSNP"
      } ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 50.11569270540146, 8.649503951466611 ]
    },
    "id_str" : "651392300745158656",
    "text" : "We\u2019re down as we are moving our database to a new &amp; faster machine. Thanks to all the patrons who made it possible! https:\/\/t.co\/9P3qKmIaEg",
    "id" : 651392300745158656,
    "created_at" : "2015-10-06 13:43:21 +0000",
    "user" : {
      "name" : "openSNP team",
      "screen_name" : "openSNPorg",
      "protected" : false,
      "id_str" : "380205172",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/735374825187909632\/wJEJW1zW_normal.jpg",
      "id" : 380205172,
      "verified" : false
    }
  },
  "id" : 651392574511521792,
  "created_at" : "2015-10-06 13:44:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nicola Segata",
      "screen_name" : "nsegata",
      "indices" : [ 0, 8 ],
      "id_str" : "18667519",
      "id" : 18667519
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11548074267211, 8.64958799314005 ]
  },
  "id_str" : "651389463357222913",
  "in_reply_to_user_id" : 18667519,
  "text" : "@nsegata thanks for the great talk!",
  "id" : 651389463357222913,
  "created_at" : "2015-10-06 13:32:04 +0000",
  "in_reply_to_screen_name" : "nsegata",
  "in_reply_to_user_id_str" : "18667519",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lars Arvestad",
      "screen_name" : "arvestad",
      "indices" : [ 0, 9 ],
      "id_str" : "403987115",
      "id" : 403987115
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "651386268836884480",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11563015999884, 8.649529369720355 ]
  },
  "id_str" : "651389420134924288",
  "in_reply_to_user_id" : 403987115,
  "text" : "@arvestad me too, maybe that\u2019s something for my next journal club :)",
  "id" : 651389420134924288,
  "in_reply_to_status_id" : 651386268836884480,
  "created_at" : "2015-10-06 13:31:54 +0000",
  "in_reply_to_screen_name" : "arvestad",
  "in_reply_to_user_id_str" : "403987115",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nicola Segata",
      "screen_name" : "nsegata",
      "indices" : [ 68, 76 ],
      "id_str" : "18667519",
      "id" : 18667519
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RECOMB_CG2015",
      "indices" : [ 128, 142 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/yigOZtCyjk",
      "expanded_url" : "http:\/\/www.sciencedirect.com\/science\/article\/pii\/S0960982215006144?_fmt=high&_origin=na&md5=f7512f030eca4f11c41b855faadb6576",
      "display_url" : "sciencedirect.com\/science\/articl\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11568240147392, 8.649565240677061 ]
  },
  "id_str" : "651385346698162177",
  "text" : "\u00ABWesternization &amp; the Disappearance of Intestinal Diversity\u00BB by @nsegata has interesting perspective http:\/\/t.co\/yigOZtCyjk #RECOMB_CG2015",
  "id" : 651385346698162177,
  "created_at" : "2015-10-06 13:15:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RECOMB_CG2015",
      "indices" : [ 109, 123 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/JD9jsDzbK8",
      "expanded_url" : "https:\/\/twitter.com\/pathogenomenick\/status\/255979319740989440",
      "display_url" : "twitter.com\/pathogenomenic\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "651378250036461568",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11550864903302, 8.649853471865251 ]
  },
  "id_str" : "651379072082296833",
  "in_reply_to_user_id" : 14286491,
  "text" : "to read more about the 100 bp example of doing metagenomics wrongly c.f. this thread https:\/\/t.co\/JD9jsDzbK8 #RECOMB_CG2015",
  "id" : 651379072082296833,
  "in_reply_to_status_id" : 651378250036461568,
  "created_at" : "2015-10-06 12:50:47 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Loman",
      "screen_name" : "pathogenomenick",
      "indices" : [ 55, 71 ],
      "id_str" : "85906238",
      "id" : 85906238
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RECOMB_CG2015",
      "indices" : [ 111, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11569095366902, 8.649558593317456 ]
  },
  "id_str" : "651378250036461568",
  "text" : "Toy example of shredding E. coli K12 in 100bp reads by @pathogenomenick &amp; the subway plague are discussed. #RECOMB_CG2015",
  "id" : 651378250036461568,
  "created_at" : "2015-10-06 12:47:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nicola Segata",
      "screen_name" : "nsegata",
      "indices" : [ 8, 16 ],
      "id_str" : "18667519",
      "id" : 18667519
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RECOMB_CG2015",
      "indices" : [ 53, 67 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11558794786026, 8.64952740687795 ]
  },
  "id_str" : "651376573136928768",
  "text" : "Up now: @nsegata talking about shotgun metagenomics. #RECOMB_CG2015",
  "id" : 651376573136928768,
  "created_at" : "2015-10-06 12:40:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "651368224739696640",
  "geo" : { },
  "id_str" : "651375885229129728",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot \uD83D\uDC36\uD83C\uDF46\u26A1\uFE0F\uD83D\uDC33\uD83C\uDF4C",
  "id" : 651375885229129728,
  "in_reply_to_status_id" : 651368224739696640,
  "created_at" : "2015-10-06 12:38:07 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "651363951096266752",
  "geo" : { },
  "id_str" : "651367538098634752",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot happy to teach you a lesson in comparative anatomy ;)",
  "id" : 651367538098634752,
  "in_reply_to_status_id" : 651363951096266752,
  "created_at" : "2015-10-06 12:04:57 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 19, 25 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 53 ],
      "url" : "https:\/\/t.co\/PHl0iv0jXy",
      "expanded_url" : "https:\/\/instagram.com\/p\/8fpbdghwmY\/",
      "display_url" : "instagram.com\/p\/8fpbdghwmY\/"
    } ]
  },
  "geo" : { },
  "id_str" : "651358826168455168",
  "text" : "Look what I found, @Lobot! \uD83D\uDC33\uD83C\uDF46 https:\/\/t.co\/PHl0iv0jXy",
  "id" : 651358826168455168,
  "created_at" : "2015-10-06 11:30:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sebastian Greiner",
      "screen_name" : "Seb666",
      "indices" : [ 0, 7 ],
      "id_str" : "2365333778",
      "id" : 2365333778
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "651348331843723264",
  "geo" : { },
  "id_str" : "651350568796037120",
  "in_reply_to_user_id" : 2365333778,
  "text" : "@Seb666 vor dem Senckenberg :)",
  "id" : 651350568796037120,
  "in_reply_to_status_id" : 651348331843723264,
  "created_at" : "2015-10-06 10:57:31 +0000",
  "in_reply_to_screen_name" : "Seb666",
  "in_reply_to_user_id_str" : "2365333778",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/651347796247900160\/photo\/1",
      "indices" : [ 8, 30 ],
      "url" : "http:\/\/t.co\/L1tlUOw62J",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CQoNXplWUAA60Nd.jpg",
      "id_str" : "651347796059115520",
      "id" : 651347796059115520,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQoNXplWUAA60Nd.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 1334,
        "resize" : "fit",
        "w" : 2668
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/L1tlUOw62J"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "651347796247900160",
  "text" : "Roooar! http:\/\/t.co\/L1tlUOw62J",
  "id" : 651347796247900160,
  "created_at" : "2015-10-06 10:46:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/douHEZKohX",
      "expanded_url" : "https:\/\/giphy.com\/gifs\/oktoberfest-clark-griswold-national-lampoons-european-vacation-3xz2BCe5jn2j4OM9ZS",
      "display_url" : "giphy.com\/gifs\/oktoberfe\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "651340618103394304",
  "text" : "Every time I hear people talk about \u2018conservative regions in the genome\u2019 my mind goes https:\/\/t.co\/douHEZKohX",
  "id" : 651340618103394304,
  "created_at" : "2015-10-06 10:17:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Melissa \uD83D\uDCAB",
      "screen_name" : "0xabad1dea",
      "indices" : [ 3, 14 ],
      "id_str" : "126030998",
      "id" : 126030998
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "651331864590970880",
  "text" : "RT @0xabad1dea: The Linux kernel community, insofar as that word applies, is driving out contributors with basic human decency. http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 112, 134 ],
        "url" : "http:\/\/t.co\/FvVXo1A1VR",
        "expanded_url" : "http:\/\/sarah.thesharps.us\/2015\/10\/05\/closing-a-door\/",
        "display_url" : "sarah.thesharps.us\/2015\/10\/05\/clo\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "651043200455561216",
    "text" : "The Linux kernel community, insofar as that word applies, is driving out contributors with basic human decency. http:\/\/t.co\/FvVXo1A1VR",
    "id" : 651043200455561216,
    "created_at" : "2015-10-05 14:36:09 +0000",
    "user" : {
      "name" : "Melissa \uD83D\uDCAB",
      "screen_name" : "0xabad1dea",
      "protected" : false,
      "id_str" : "126030998",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/925537797649457152\/t3oznBxk_normal.jpg",
      "id" : 126030998,
      "verified" : false
    }
  },
  "id" : 651331864590970880,
  "created_at" : "2015-10-06 09:43:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lars Arvestad",
      "screen_name" : "arvestad",
      "indices" : [ 3, 12 ],
      "id_str" : "403987115",
      "id" : 403987115
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "651326256437436416",
  "text" : "RT @arvestad: Wandrille Duchemin works with Yersinia pestis and estimates ancestral genomes. Shows ancestral gene adjacency graph. http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/arvestad\/status\/651324394288074752\/photo\/1",
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/k43ESdTEH3",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CQn4E8xUEAAyHv3.jpg",
        "id_str" : "651324385047875584",
        "id" : 651324385047875584,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQn4E8xUEAAyHv3.jpg",
        "sizes" : [ {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 900,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 2448,
          "resize" : "fit",
          "w" : 3264
        } ],
        "display_url" : "pic.twitter.com\/k43ESdTEH3"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "651324394288074752",
    "text" : "Wandrille Duchemin works with Yersinia pestis and estimates ancestral genomes. Shows ancestral gene adjacency graph. http:\/\/t.co\/k43ESdTEH3",
    "id" : 651324394288074752,
    "created_at" : "2015-10-06 09:13:31 +0000",
    "user" : {
      "name" : "Lars Arvestad",
      "screen_name" : "arvestad",
      "protected" : false,
      "id_str" : "403987115",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/715465108319834112\/4f9_q7-Q_normal.jpg",
      "id" : 403987115,
      "verified" : false
    }
  },
  "id" : 651326256437436416,
  "created_at" : "2015-10-06 09:20:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 73 ],
      "url" : "https:\/\/t.co\/j51lSsumjZ",
      "expanded_url" : "https:\/\/twitter.com\/sebotic\/status\/651321569579438080",
      "display_url" : "twitter.com\/sebotic\/status\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11548600672232, 8.649714097639665 ]
  },
  "id_str" : "651325887351271424",
  "text" : "Now just put a nanopore machine in there as well. https:\/\/t.co\/j51lSsumjZ",
  "id" : 651325887351271424,
  "created_at" : "2015-10-06 09:19:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RECOMB_CG2015",
      "indices" : [ 57, 71 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11552172946736, 8.649717258707419 ]
  },
  "id_str" : "651322778923192320",
  "text" : "Now: Reconstructing an ancestral Yersenia pestis genome. #RECOMB_CG2015",
  "id" : 651322778923192320,
  "created_at" : "2015-10-06 09:07:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RECOMB_CG2015",
      "indices" : [ 123, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "651308934024835072",
  "text" : "RF: Let\u2019s use machine learning not only to predict whether customers are pregnant or not. What about phenotype prediction? #RECOMB_CG2015",
  "id" : 651308934024835072,
  "created_at" : "2015-10-06 08:12:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RECOMB_CG2015",
      "indices" : [ 44, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 59, 82 ],
      "url" : "https:\/\/t.co\/ld2DGLoC3g",
      "expanded_url" : "https:\/\/twitter.com\/arvestad\/status\/651306261556953088",
      "display_url" : "twitter.com\/arvestad\/statu\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11565974828653, 8.649640368152415 ]
  },
  "id_str" : "651307914922192896",
  "text" : "That\u2019s a really nice synteny visualization. #RECOMB_CG2015 https:\/\/t.co\/ld2DGLoC3g",
  "id" : 651307914922192896,
  "created_at" : "2015-10-06 08:08:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "651300097452474369",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11566100486067, 8.649600331435884 ]
  },
  "id_str" : "651302315014623232",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer yes, this is what I hand each of our students when they are writing up.",
  "id" : 651302315014623232,
  "in_reply_to_status_id" : 651300097452474369,
  "created_at" : "2015-10-06 07:45:47 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/s23FHabwKx",
      "expanded_url" : "http:\/\/existentialcomics.com\/comic\/101",
      "display_url" : "existentialcomics.com\/comic\/101"
    } ]
  },
  "geo" : { },
  "id_str" : "651300795653165056",
  "text" : "Sartre's Waiter? I think I still prefer Pascal's Wager. http:\/\/t.co\/s23FHabwKx",
  "id" : 651300795653165056,
  "created_at" : "2015-10-06 07:39:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/6mM3nFDFp5",
      "expanded_url" : "http:\/\/www.wired.com\/2015\/10\/battle-genome-editing-gets-science-wrong\/",
      "display_url" : "wired.com\/2015\/10\/battle\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "651298890671607809",
  "text" : "More on the CRISPR priority debates: The Battle Over Genome Editing Gets Science All Wrong http:\/\/t.co\/6mM3nFDFp5",
  "id" : 651298890671607809,
  "created_at" : "2015-10-06 07:32:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "651296374697295872",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11582575361287, 8.650201215566794 ]
  },
  "id_str" : "651297281874993152",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer yeah, but tbh: i also just followed the workflow used for nematodes that\u2019s on GH. :D",
  "id" : 651297281874993152,
  "in_reply_to_status_id" : 651296374697295872,
  "created_at" : "2015-10-06 07:25:47 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "651295849918525440",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11562650402656, 8.649606470820931 ]
  },
  "id_str" : "651296187354587136",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer argument is that augustus performance superior to \u201Cconsensus\u201D ;)",
  "id" : 651296187354587136,
  "in_reply_to_status_id" : 651295849918525440,
  "created_at" : "2015-10-06 07:21:26 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "651294575907090432",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11550595093293, 8.64973074861606 ]
  },
  "id_str" : "651294781738500096",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer ah, okay. Sitting next to some ppl involved with Augustus right now. They say: don\u2019t use maker ;)",
  "id" : 651294781738500096,
  "in_reply_to_status_id" : 651294575907090432,
  "created_at" : "2015-10-06 07:15:51 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RECOMB_CG2015",
      "indices" : [ 17, 31 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11579831242364, 8.650048839392584 ]
  },
  "id_str" : "651291715425443840",
  "text" : "Now for Day 2 of #RECOMB_CG2015. Starting off with \u2018Simulating Vertebrate Genome Evolution\u2019.",
  "id" : 651291715425443840,
  "created_at" : "2015-10-06 07:03:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "651228159497498625",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11655621270588, 8.684400674055276 ]
  },
  "id_str" : "651289482315046912",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer doh, that never happened to me so far. How much memory did you allocate?",
  "id" : 651289482315046912,
  "in_reply_to_status_id" : 651228159497498625,
  "created_at" : "2015-10-06 06:54:47 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 65 ],
      "url" : "http:\/\/t.co\/6VRkC8VEhb",
      "expanded_url" : "http:\/\/www.theverge.com\/2015\/9\/30\/9416579\/spotify-discover-weekly-online-music-curation-interview?goal=0_717559c8d5-a50d627964-56833397&mc_cid=a50d627964&mc_eid=87e4c098ac",
      "display_url" : "theverge.com\/2015\/9\/30\/9416\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "651157365539012608",
  "text" : "A nice look at Spotify's Discover Weekly.  http:\/\/t.co\/6VRkC8VEhb",
  "id" : 651157365539012608,
  "created_at" : "2015-10-05 22:09:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mozilla Science Lab",
      "screen_name" : "MozillaScience",
      "indices" : [ 3, 18 ],
      "id_str" : "1428575976",
      "id" : 1428575976
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 70, 86 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "651154091536613376",
  "text" : "RT @MozillaScience: Join us THIS THURS (11ET) for our next call feat. @gedankenstuecke from OpenSNP, the Fellows + more : https:\/\/t.co\/0bXY\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 50, 66 ],
        "id_str" : "14286491",
        "id" : 14286491
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "openscience",
        "indices" : [ 126, 138 ]
      } ],
      "urls" : [ {
        "indices" : [ 102, 125 ],
        "url" : "https:\/\/t.co\/0bXYkBrlzt",
        "expanded_url" : "https:\/\/www.mozillascience.org\/opensnp-software-discovery-and-mozfest-oct-8-11-et",
        "display_url" : "mozillascience.org\/opensnp-softwa\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "651154044673658880",
    "text" : "Join us THIS THURS (11ET) for our next call feat. @gedankenstuecke from OpenSNP, the Fellows + more : https:\/\/t.co\/0bXYkBrlzt #openscience",
    "id" : 651154044673658880,
    "created_at" : "2015-10-05 21:56:36 +0000",
    "user" : {
      "name" : "Mozilla Science Lab",
      "screen_name" : "MozillaScience",
      "protected" : false,
      "id_str" : "1428575976",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/687287790049034240\/lwIk-ZQT_normal.png",
      "id" : 1428575976,
      "verified" : false
    }
  },
  "id" : 651154091536613376,
  "created_at" : "2015-10-05 21:56:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "the Winnower",
      "screen_name" : "theWinnower",
      "indices" : [ 61, 73 ],
      "id_str" : "748018813",
      "id" : 748018813
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/tQZY3A4dFM",
      "expanded_url" : "https:\/\/thewinnower.com\/papers\/2368-you-don-t-get-to-2000-open-data-sets-without-making-a-few-friends-or-how-i-got-to-be-called-the-mark-zuckerberg-of-open-source-genetics",
      "display_url" : "thewinnower.com\/papers\/2368-yo\u2026"
    }, {
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/MC4r6RWmwj",
      "expanded_url" : "https:\/\/twitter.com\/theWinnower\/status\/651078577870479360",
      "display_url" : "twitter.com\/theWinnower\/st\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "651078577870479360",
  "geo" : { },
  "id_str" : "651129568862998528",
  "in_reply_to_user_id" : 748018813,
  "text" : "I agree with the sentiment, this is why I wrote my story for @theWinnower https:\/\/t.co\/tQZY3A4dFM https:\/\/t.co\/MC4r6RWmwj",
  "id" : 651129568862998528,
  "in_reply_to_status_id" : 651078577870479360,
  "created_at" : "2015-10-05 20:19:21 +0000",
  "in_reply_to_screen_name" : "theWinnower",
  "in_reply_to_user_id_str" : "748018813",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "651080514581987328",
  "text" : "\u00ABWould there be a naming conflict if we\u2019d call our tool like this?\u00BB \u2014 \u00ABGoogle says no\u2026 well there\u2019s one porn with the title, but otherwise\u2026\u00BB",
  "id" : 651080514581987328,
  "created_at" : "2015-10-05 17:04:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/chSePrcRPl",
      "expanded_url" : "http:\/\/onlinelibrary.wiley.com\/doi\/10.1111\/1755-0998.12463\/abstract",
      "display_url" : "onlinelibrary.wiley.com\/doi\/10.1111\/17\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "651038454952931328",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11570551905777, 8.649495587741308 ]
  },
  "id_str" : "651039394254712832",
  "in_reply_to_user_id" : 14286491,
  "text" : "Fits nicely with our observations from our work on eukaryotic species mixtures. http:\/\/t.co\/chSePrcRPl",
  "id" : 651039394254712832,
  "in_reply_to_status_id" : 651038454952931328,
  "created_at" : "2015-10-05 14:21:01 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nicola Segata",
      "screen_name" : "nsegata",
      "indices" : [ 3, 11 ],
      "id_str" : "18667519",
      "id" : 18667519
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RECOMB_CG2015",
      "indices" : [ 76, 90 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/HOMO206dvJ",
      "expanded_url" : "http:\/\/genome.cshlp.org\/content\/24\/3\/475\/F1.expansion.html",
      "display_url" : "genome.cshlp.org\/content\/24\/3\/4\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "651038623811403777",
  "text" : "RT @nsegata: Luay Nakhleh talking about the multispecies coalescent mode at #RECOMB_CG2015 . Fascinating! http:\/\/t.co\/HOMO206dvJ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "RECOMB_CG2015",
        "indices" : [ 63, 77 ]
      } ],
      "urls" : [ {
        "indices" : [ 93, 115 ],
        "url" : "http:\/\/t.co\/HOMO206dvJ",
        "expanded_url" : "http:\/\/genome.cshlp.org\/content\/24\/3\/475\/F1.expansion.html",
        "display_url" : "genome.cshlp.org\/content\/24\/3\/4\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "651037541353848832",
    "text" : "Luay Nakhleh talking about the multispecies coalescent mode at #RECOMB_CG2015 . Fascinating! http:\/\/t.co\/HOMO206dvJ",
    "id" : 651037541353848832,
    "created_at" : "2015-10-05 14:13:40 +0000",
    "user" : {
      "name" : "Nicola Segata",
      "screen_name" : "nsegata",
      "protected" : false,
      "id_str" : "18667519",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/489291625265233920\/sHYBchXb_normal.jpeg",
      "id" : 18667519,
      "verified" : false
    }
  },
  "id" : 651038623811403777,
  "created_at" : "2015-10-05 14:17:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/o5XQM0dJZF",
      "expanded_url" : "http:\/\/biorxiv.org\/content\/early\/2015\/10\/02\/028134",
      "display_url" : "biorxiv.org\/content\/early\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "651038454952931328",
  "text" : "a computational pipeline to guide the design and analysis of de novo genome sequencing studies http:\/\/t.co\/o5XQM0dJZF",
  "id" : 651038454952931328,
  "created_at" : "2015-10-05 14:17:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/O636vNcLkm",
      "expanded_url" : "http:\/\/biorxiv.org\/content\/early\/2015\/10\/04\/028290",
      "display_url" : "biorxiv.org\/content\/early\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "651036016694923264",
  "text" : "Nanopore sequencing detects structural variants in cancer http:\/\/t.co\/O636vNcLkm",
  "id" : 651036016694923264,
  "created_at" : "2015-10-05 14:07:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ICG10",
      "indices" : [ 26, 32 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11567770742611, 8.649837793506636 ]
  },
  "id_str" : "651028065494155264",
  "text" : "Got my visa for China, so #ICG10 is a go. \u2708\uFE0F",
  "id" : 651028065494155264,
  "created_at" : "2015-10-05 13:36:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RECOMB_CG2015",
      "indices" : [ 73, 87 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11563095648607, 8.64960330213752 ]
  },
  "id_str" : "651022197386014720",
  "text" : "CD: spurious edges, not missing edges are a problem in orthology graphs. #RECOMB_CG2015",
  "id" : 651022197386014720,
  "created_at" : "2015-10-05 13:12:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RECOMB_CG2015",
      "indices" : [ 107, 121 ]
    } ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/rNjBJpiuj3",
      "expanded_url" : "https:\/\/peerj.com\/articles\/607\/",
      "display_url" : "peerj.com\/articles\/607\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11568639870717, 8.649555242856604 ]
  },
  "id_str" : "651020173273628672",
  "text" : "CD showing how to speed up all-against-all protein comparisons, published in PeerJ https:\/\/t.co\/rNjBJpiuj3 #RECOMB_CG2015",
  "id" : 651020173273628672,
  "created_at" : "2015-10-05 13:04:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Schawinski",
      "screen_name" : "kevinschawinski",
      "indices" : [ 0, 16 ],
      "id_str" : "242844365",
      "id" : 242844365
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "651015836598181888",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11565212591573, 8.64963172766314 ]
  },
  "id_str" : "651016400228720641",
  "in_reply_to_user_id" : 242844365,
  "text" : "@kevinschawinski \u201Corthologs\u201D are genes that arose due to a speciation. E.g. the hemoglobin gene in human &amp; chimp come from same ancestor.",
  "id" : 651016400228720641,
  "in_reply_to_status_id" : 651015836598181888,
  "created_at" : "2015-10-05 12:49:39 +0000",
  "in_reply_to_screen_name" : "kevinschawinski",
  "in_reply_to_user_id_str" : "242844365",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RECOMB_CG2015",
      "indices" : [ 125, 139 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "651015465188360193",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11518528204682, 8.649934985223682 ]
  },
  "id_str" : "651015791186444289",
  "in_reply_to_user_id" : 14286491,
  "text" : "CD: All three come with their own drawbacks &amp; pitfalls. Hierarchical orthologous groups designed to help in those cases. #RECOMB_CG2015",
  "id" : 651015791186444289,
  "in_reply_to_status_id" : 651015465188360193,
  "created_at" : "2015-10-05 12:47:14 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RECOMB_CG2015",
      "indices" : [ 125, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11550398569135, 8.649658516540443 ]
  },
  "id_str" : "651015465188360193",
  "text" : "CD on 3 paradigms used for looking at orthology: \n1. pairwise orthology\n2. clusters of 1:1 orthologs\n3. labelled gene trees\n\n#RECOMB_CG2015",
  "id" : 651015465188360193,
  "created_at" : "2015-10-05 12:45:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RECOMB_CG2015",
      "indices" : [ 90, 104 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11554726738639, 8.649522474727636 ]
  },
  "id_str" : "651013528963391489",
  "text" : "CD: Most genomes are in a bad draft status. Knowledge about gene functions is even worse. #RECOMB_CG2015",
  "id" : 651013528963391489,
  "created_at" : "2015-10-05 12:38:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christophe Dessimoz",
      "screen_name" : "cdessimoz",
      "indices" : [ 5, 15 ],
      "id_str" : "274388734",
      "id" : 274388734
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RECOMB_CG2015",
      "indices" : [ 57, 71 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11566328781836, 8.64952992051874 ]
  },
  "id_str" : "651012947377041408",
  "text" : "Now: @cdessimoz about Hierarchical Orthologous Groups at #RECOMB_CG2015",
  "id" : 651012947377041408,
  "created_at" : "2015-10-05 12:35:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 13, 26 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "651000653381300224",
  "geo" : { },
  "id_str" : "651001549301379072",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch @PhilippBayer of we do more than 4 we can switch to amino acids?",
  "id" : 651001549301379072,
  "in_reply_to_status_id" : 651000653381300224,
  "created_at" : "2015-10-05 11:50:39 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 14, 26 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "650999822372114432",
  "geo" : { },
  "id_str" : "651000532350468096",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @helgerausch can we start with blood, sweat &amp; tears?",
  "id" : 651000532350468096,
  "in_reply_to_status_id" : 650999822372114432,
  "created_at" : "2015-10-05 11:46:36 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nyborg",
      "screen_name" : "ny_borg",
      "indices" : [ 0, 8 ],
      "id_str" : "570156398",
      "id" : 570156398
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "650959214203043840",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11564973478958, 8.649596014527688 ]
  },
  "id_str" : "650960016304959488",
  "in_reply_to_user_id" : 570156398,
  "text" : "@ny_borg not my choice :",
  "id" : 650960016304959488,
  "in_reply_to_status_id" : 650959214203043840,
  "created_at" : "2015-10-05 09:05:36 +0000",
  "in_reply_to_screen_name" : "ny_borg",
  "in_reply_to_user_id_str" : "570156398",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "650946591889584128",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11568468282526, 8.649596991984156 ]
  },
  "id_str" : "650959741129228288",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer mission accomplished ;)",
  "id" : 650959741129228288,
  "in_reply_to_status_id" : 650946591889584128,
  "created_at" : "2015-10-05 09:04:31 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "650946591889584128",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11489010917202, 8.650993588627275 ]
  },
  "id_str" : "650947119944237056",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer thanks :D",
  "id" : 650947119944237056,
  "in_reply_to_status_id" : 650946591889584128,
  "created_at" : "2015-10-05 08:14:22 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "650942218367164416",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11523679445361, 8.65010197450661 ]
  },
  "id_str" : "650942827673845760",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer I\u2019ll just send greetings from him as well ;)",
  "id" : 650942827673845760,
  "in_reply_to_status_id" : 650942218367164416,
  "created_at" : "2015-10-05 07:57:18 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "650941969452036096",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11555131177285, 8.649693723216362 ]
  },
  "id_str" : "650942722304516096",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer i assumed something like this. Will do :)",
  "id" : 650942722304516096,
  "in_reply_to_status_id" : 650941969452036096,
  "created_at" : "2015-10-05 07:56:53 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "650941830125760512",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer btw: do you know Annaliese Mason? She just gave a talk on allohexaploidy in Brassica and talked about UQ. :)",
  "id" : 650941830125760512,
  "created_at" : "2015-10-05 07:53:20 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RECOMB_CG2015",
      "indices" : [ 69, 83 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "650941226716426240",
  "text" : "\u00ABThe first meiosis is the worst one\u00BB sounds like a Cat Stevens song. #RECOMB_CG2015",
  "id" : 650941226716426240,
  "created_at" : "2015-10-05 07:50:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RECOMB_CG2015",
      "indices" : [ 11, 25 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "650916097454174208",
  "text" : "Heading to #RECOMB_CG2015. A conference that can be reached by commuter trains has its benefits.",
  "id" : 650916097454174208,
  "created_at" : "2015-10-05 06:11:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Foursquare Swarm",
      "screen_name" : "SwarmApp",
      "indices" : [ 0, 9 ],
      "id_str" : "240676055",
      "id" : 240676055
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "650878614070685696",
  "geo" : { },
  "id_str" : "650914667079069696",
  "in_reply_to_user_id" : 240676055,
  "text" : "@swarmapp indeed, thanks! Though it still makes me check in instead of having it really automated. :)",
  "id" : 650914667079069696,
  "in_reply_to_status_id" : 650878614070685696,
  "created_at" : "2015-10-05 06:05:24 +0000",
  "in_reply_to_screen_name" : "SwarmApp",
  "in_reply_to_user_id_str" : "240676055",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/kindle.amazon.com\" rel=\"nofollow\"\u003EKindle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/HNNxQ9mSol",
      "expanded_url" : "http:\/\/amzn.com\/k\/UnismGBuR9m7vmgfgs58EQ",
      "display_url" : "amzn.com\/k\/UnismGBuR9m7\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "650813037264392192",
  "text" : "full quote found here:  \"Gay men have redefined and occasionally undermined conventional masculinity\u2014publicly,... http:\/\/t.co\/HNNxQ9mSol",
  "id" : 650813037264392192,
  "created_at" : "2015-10-04 23:21:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11407384721777, 8.753374077180835 ]
  },
  "id_str" : "650812422501089280",
  "text" : "\u00AB\u2026as though in some dismal zero-sum game, only one gender at a time could be free and powerful. But we are free together or slaves together\u00BB",
  "id" : 650812422501089280,
  "created_at" : "2015-10-04 23:19:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 0, 9 ],
      "id_str" : "14245811",
      "id" : 14245811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "650806824267087873",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11407435523834, 8.753375519982228 ]
  },
  "id_str" : "650807115926360064",
  "in_reply_to_user_id" : 14245811,
  "text" : "@wilbanks happy I can add to your gif collection ;)",
  "id" : 650807115926360064,
  "in_reply_to_status_id" : 650806824267087873,
  "created_at" : "2015-10-04 22:58:02 +0000",
  "in_reply_to_screen_name" : "wilbanks",
  "in_reply_to_user_id_str" : "14245811",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nyborg",
      "screen_name" : "ny_borg",
      "indices" : [ 0, 8 ],
      "id_str" : "570156398",
      "id" : 570156398
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "650806691714437120",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11407435523834, 8.753375519982228 ]
  },
  "id_str" : "650807054391750656",
  "in_reply_to_user_id" : 570156398,
  "text" : "@ny_borg bis dahin hab ich ja zum Gl\u00FCck noch etwas Zeit :3",
  "id" : 650807054391750656,
  "in_reply_to_status_id" : 650806691714437120,
  "created_at" : "2015-10-04 22:57:47 +0000",
  "in_reply_to_screen_name" : "ny_borg",
  "in_reply_to_user_id_str" : "570156398",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/bbTDQsxpsx",
      "expanded_url" : "http:\/\/giphy.com\/gifs\/thomas-mann-me-and-earl-the-dying-girl-meandearl-CmmUXKluMFudG",
      "display_url" : "giphy.com\/gifs\/thomas-ma\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11407443513136, 8.753375736226769 ]
  },
  "id_str" : "650805189285408769",
  "text" : "10\/10, would watch again http:\/\/t.co\/bbTDQsxpsx",
  "id" : 650805189285408769,
  "created_at" : "2015-10-04 22:50:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kit Stubbs, Ph.D.",
      "screen_name" : "vortacist",
      "indices" : [ 0, 10 ],
      "id_str" : "347340056",
      "id" : 347340056
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "650788513428828161",
  "geo" : { },
  "id_str" : "650796239810883585",
  "in_reply_to_user_id" : 347340056,
  "text" : "@vortacist omg, that\u2019s awesome and is more or less why I first got in touch with you years ago! :)",
  "id" : 650796239810883585,
  "in_reply_to_status_id" : 650788513428828161,
  "created_at" : "2015-10-04 22:14:49 +0000",
  "in_reply_to_screen_name" : "vortacist",
  "in_reply_to_user_id_str" : "347340056",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christophe Dessimoz",
      "screen_name" : "cdessimoz",
      "indices" : [ 0, 10 ],
      "id_str" : "274388734",
      "id" : 274388734
    }, {
      "name" : "Lars Arvestad",
      "screen_name" : "arvestad",
      "indices" : [ 11, 20 ],
      "id_str" : "403987115",
      "id" : 403987115
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "650786220520423424",
  "geo" : { },
  "id_str" : "650786602113966080",
  "in_reply_to_user_id" : 274388734,
  "text" : "@cdessimoz @arvestad I guess that sets the hashtag question. Looking forward to catching up too!",
  "id" : 650786602113966080,
  "in_reply_to_status_id" : 650786220520423424,
  "created_at" : "2015-10-04 21:36:31 +0000",
  "in_reply_to_screen_name" : "cdessimoz",
  "in_reply_to_user_id_str" : "274388734",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Yoder \uD83D\uDD96\uD83C\uDFFB",
      "screen_name" : "JBYoder",
      "indices" : [ 0, 8 ],
      "id_str" : "19984919",
      "id" : 19984919
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "650708609656061952",
  "geo" : { },
  "id_str" : "650769729905364992",
  "in_reply_to_user_id" : 19984919,
  "text" : "@JBYoder congrats!",
  "id" : 650769729905364992,
  "in_reply_to_status_id" : 650708609656061952,
  "created_at" : "2015-10-04 20:29:28 +0000",
  "in_reply_to_screen_name" : "JBYoder",
  "in_reply_to_user_id_str" : "19984919",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "650699749029478402",
  "text" : "If a scientific conference doesn\u2019t have its own hashtag, has it ever happened?",
  "id" : 650699749029478402,
  "created_at" : "2015-10-04 15:51:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Iddo Friedberg",
      "screen_name" : "iddux",
      "indices" : [ 0, 6 ],
      "id_str" : "15276911",
      "id" : 15276911
    }, {
      "name" : "Mick Watson",
      "screen_name" : "BioMickWatson",
      "indices" : [ 7, 21 ],
      "id_str" : "228586748",
      "id" : 228586748
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "650675895837986816",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11407335316694, 8.753375923092122 ]
  },
  "id_str" : "650688592306683904",
  "in_reply_to_user_id" : 15276911,
  "text" : "@iddux @BioMickWatson Overlap Layout Compassion was known to be superior if your empowerments are long enough to make use of it.",
  "id" : 650688592306683904,
  "in_reply_to_status_id" : 650675895837986816,
  "created_at" : "2015-10-04 15:07:04 +0000",
  "in_reply_to_screen_name" : "iddux",
  "in_reply_to_user_id_str" : "15276911",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "650684962400808960",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11407436165095, 8.75337664940024 ]
  },
  "id_str" : "650687347508559872",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot also: do not consumate marriage after expiration date. \u261D",
  "id" : 650687347508559872,
  "in_reply_to_status_id" : 650684962400808960,
  "created_at" : "2015-10-04 15:02:07 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 67 ],
      "url" : "http:\/\/t.co\/DOQB3mAYYx",
      "expanded_url" : "http:\/\/i.kinja-img.com\/gawker-media\/image\/upload\/s--l9_gjJN7--\/drzpjqp41blssr6we3pw.gif",
      "display_url" : "i.kinja-img.com\/gawker-media\/i\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "650661140817649664",
  "geo" : { },
  "id_str" : "650666185139339264",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot do not consume after expiration date? http:\/\/t.co\/DOQB3mAYYx",
  "id" : 650666185139339264,
  "in_reply_to_status_id" : 650661140817649664,
  "created_at" : "2015-10-04 13:38:01 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/60ZTrEFlPU",
      "expanded_url" : "http:\/\/dx.doi.org\/10.1371\/journal.pone.0138061.g002",
      "display_url" : "dx.doi.org\/10.1371\/journa\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "650663001238958081",
  "text" : "\u201Cwhy robots should be social\u201D, looks more like CreepyBot3000 to me. http:\/\/t.co\/60ZTrEFlPU",
  "id" : 650663001238958081,
  "created_at" : "2015-10-04 13:25:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michelle Oyen",
      "screen_name" : "michelleoyen",
      "indices" : [ 3, 16 ],
      "id_str" : "83589523",
      "id" : 83589523
    }, {
      "name" : "The Onion",
      "screen_name" : "TheOnion",
      "indices" : [ 89, 98 ],
      "id_str" : "14075928",
      "id" : 14075928
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/KbZTwGYEWR",
      "expanded_url" : "http:\/\/www.theonion.com\/r\/51422",
      "display_url" : "theonion.com\/r\/51422"
    } ]
  },
  "geo" : { },
  "id_str" : "650607665639464960",
  "text" : "RT @michelleoyen: How The MacArthur Genius Grants Are Awarded http:\/\/t.co\/KbZTwGYEWR via @theonion",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The Onion",
        "screen_name" : "TheOnion",
        "indices" : [ 71, 80 ],
        "id_str" : "14075928",
        "id" : 14075928
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 44, 66 ],
        "url" : "http:\/\/t.co\/KbZTwGYEWR",
        "expanded_url" : "http:\/\/www.theonion.com\/r\/51422",
        "display_url" : "theonion.com\/r\/51422"
      } ]
    },
    "geo" : { },
    "id_str" : "650607358293487616",
    "text" : "How The MacArthur Genius Grants Are Awarded http:\/\/t.co\/KbZTwGYEWR via @theonion",
    "id" : 650607358293487616,
    "created_at" : "2015-10-04 09:44:16 +0000",
    "user" : {
      "name" : "Michelle Oyen",
      "screen_name" : "michelleoyen",
      "protected" : false,
      "id_str" : "83589523",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/479579308\/MyPicture_normal.jpg",
      "id" : 83589523,
      "verified" : false
    }
  },
  "id" : 650607665639464960,
  "created_at" : "2015-10-04 09:45:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 72 ],
      "url" : "http:\/\/t.co\/ta0xRxBEqL",
      "expanded_url" : "http:\/\/mindhacks.com\/2015\/10\/03\/statistical-fallacy-impairs-post-publication-mood",
      "display_url" : "mindhacks.com\/2015\/10\/03\/sta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "650589057030950912",
  "text" : "Statistical fallacy impairs post-publication mood http:\/\/t.co\/ta0xRxBEqL",
  "id" : 650589057030950912,
  "created_at" : "2015-10-04 08:31:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 13, 26 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11407462937142, 8.753375353573007 ]
  },
  "id_str" : "650584735505350656",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch @PhilippBayer did you guys get my email? :3",
  "id" : 650584735505350656,
  "created_at" : "2015-10-04 08:14:22 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 0, 10 ],
      "id_str" : "14700783",
      "id" : 14700783
    }, {
      "name" : "purrrlegon",
      "screen_name" : "pulegon",
      "indices" : [ 11, 19 ],
      "id_str" : "107502279",
      "id" : 107502279
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 42 ],
      "url" : "http:\/\/t.co\/3sqUFJFRvG",
      "expanded_url" : "http:\/\/blogs.scientificamerican.com\/observations\/giant-panda-genome-sequenced-explains-taste-for-bamboo\/",
      "display_url" : "blogs.scientificamerican.com\/observations\/g\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "650581389599973376",
  "geo" : { },
  "id_str" : "650581813560274944",
  "in_reply_to_user_id" : 14700783,
  "text" : "@Fischblog @pulegon http:\/\/t.co\/3sqUFJFRvG \uD83D\uDE09\uD83D\uDC3C (tbh: super low-hanging fruit)",
  "id" : 650581813560274944,
  "in_reply_to_status_id" : 650581389599973376,
  "created_at" : "2015-10-04 08:02:46 +0000",
  "in_reply_to_screen_name" : "Fischblog",
  "in_reply_to_user_id_str" : "14700783",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "purrrlegon",
      "screen_name" : "pulegon",
      "indices" : [ 0, 8 ],
      "id_str" : "107502279",
      "id" : 107502279
    }, {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 9, 19 ],
      "id_str" : "14700783",
      "id" : 14700783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "650578475674378240",
  "geo" : { },
  "id_str" : "650580088782745600",
  "in_reply_to_user_id" : 107502279,
  "text" : "@pulegon @Fischblog dann wird der popelige Frosch halt in den mobilen Nanopore-Sequencer geworfen und on the go DNA-barcoded? ;)",
  "id" : 650580088782745600,
  "in_reply_to_status_id" : 650578475674378240,
  "created_at" : "2015-10-04 07:55:55 +0000",
  "in_reply_to_screen_name" : "pulegon",
  "in_reply_to_user_id_str" : "107502279",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kollektiv Raufaser",
      "screen_name" : "insideX",
      "indices" : [ 0, 8 ],
      "id_str" : "14857351",
      "id" : 14857351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "650566083687133184",
  "geo" : { },
  "id_str" : "650573713507778560",
  "in_reply_to_user_id" : 14857351,
  "text" : "@insideX Eckschrank, Eckschrank, alles muss versteckt sein?",
  "id" : 650573713507778560,
  "in_reply_to_status_id" : 650566083687133184,
  "created_at" : "2015-10-04 07:30:35 +0000",
  "in_reply_to_screen_name" : "insideX",
  "in_reply_to_user_id_str" : "14857351",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nazeefa",
      "screen_name" : "NazeefaFatima",
      "indices" : [ 0, 14 ],
      "id_str" : "37054704",
      "id" : 37054704
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "650571293516017664",
  "geo" : { },
  "id_str" : "650571758345568256",
  "in_reply_to_user_id" : 37054704,
  "text" : "@NazeefaFatima \uD83D\uDC4D",
  "id" : 650571758345568256,
  "in_reply_to_status_id" : 650571293516017664,
  "created_at" : "2015-10-04 07:22:48 +0000",
  "in_reply_to_screen_name" : "NazeefaFatima",
  "in_reply_to_user_id_str" : "37054704",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Maria Popova",
      "screen_name" : "brainpicker",
      "indices" : [ 3, 15 ],
      "id_str" : "9207632",
      "id" : 9207632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/PHnQdNcVR0",
      "expanded_url" : "http:\/\/buff.ly\/1WCqdkw",
      "display_url" : "buff.ly\/1WCqdkw"
    } ]
  },
  "geo" : { },
  "id_str" : "650567881613250560",
  "text" : "RT @brainpicker: Whenever my heart sinks, I reread Martha Nussbaum on how to live with our human fragility http:\/\/t.co\/PHnQdNcVR0 http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/brainpicker\/status\/650075867960492032\/photo\/1",
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/HZzObhNxxZ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CQWIjosWcAAJS_D.jpg",
        "id_str" : "650075867025141760",
        "id" : 650075867025141760,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQWIjosWcAAJS_D.jpg",
        "sizes" : [ {
          "h" : 315,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 315,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 315,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 315,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/HZzObhNxxZ"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 90, 112 ],
        "url" : "http:\/\/t.co\/PHnQdNcVR0",
        "expanded_url" : "http:\/\/buff.ly\/1WCqdkw",
        "display_url" : "buff.ly\/1WCqdkw"
      } ]
    },
    "geo" : { },
    "id_str" : "650075867960492032",
    "text" : "Whenever my heart sinks, I reread Martha Nussbaum on how to live with our human fragility http:\/\/t.co\/PHnQdNcVR0 http:\/\/t.co\/HZzObhNxxZ",
    "id" : 650075867960492032,
    "created_at" : "2015-10-02 22:32:19 +0000",
    "user" : {
      "name" : "Maria Popova",
      "screen_name" : "brainpicker",
      "protected" : false,
      "id_str" : "9207632",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/577255253852065794\/qGnSwsBR_normal.jpg",
      "id" : 9207632,
      "verified" : true
    }
  },
  "id" : 650567881613250560,
  "created_at" : "2015-10-04 07:07:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "EvolDir",
      "screen_name" : "evoldir",
      "indices" : [ 3, 11 ],
      "id_str" : "19108922",
      "id" : 19108922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/0B3f7ufWlK",
      "expanded_url" : "http:\/\/ift.tt\/1OPZsI3",
      "display_url" : "ift.tt\/1OPZsI3"
    } ]
  },
  "geo" : { },
  "id_str" : "650567247602302976",
  "text" : "RT @evoldir: Graduate position: BiKF_Frankfurt.PopulationGenomics http:\/\/t.co\/0B3f7ufWlK",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 53, 75 ],
        "url" : "http:\/\/t.co\/0B3f7ufWlK",
        "expanded_url" : "http:\/\/ift.tt\/1OPZsI3",
        "display_url" : "ift.tt\/1OPZsI3"
      } ]
    },
    "geo" : { },
    "id_str" : "650545953703858176",
    "text" : "Graduate position: BiKF_Frankfurt.PopulationGenomics http:\/\/t.co\/0B3f7ufWlK",
    "id" : 650545953703858176,
    "created_at" : "2015-10-04 05:40:16 +0000",
    "user" : {
      "name" : "EvolDir",
      "screen_name" : "evoldir",
      "protected" : false,
      "id_str" : "19108922",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/71594963\/d_normal.png",
      "id" : 19108922,
      "verified" : false
    }
  },
  "id" : 650567247602302976,
  "created_at" : "2015-10-04 07:04:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "christian m\u00FCller",
      "screen_name" : "capwnd",
      "indices" : [ 0, 7 ],
      "id_str" : "19160866",
      "id" : 19160866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "650440742146588672",
  "geo" : { },
  "id_str" : "650445254563336192",
  "in_reply_to_user_id" : 19160866,
  "text" : "@capwnd danke!",
  "id" : 650445254563336192,
  "in_reply_to_status_id" : 650440742146588672,
  "created_at" : "2015-10-03 23:00:08 +0000",
  "in_reply_to_screen_name" : "capwnd",
  "in_reply_to_user_id_str" : "19160866",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yuri",
      "screen_name" : "Lucif0r",
      "indices" : [ 0, 8 ],
      "id_str" : "113398969",
      "id" : 113398969
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "650434156569169920",
  "geo" : { },
  "id_str" : "650434491958317056",
  "in_reply_to_user_id" : 113398969,
  "text" : "@Lucif0r danke, das sieht gut aus :)",
  "id" : 650434491958317056,
  "in_reply_to_status_id" : 650434156569169920,
  "created_at" : "2015-10-03 22:17:22 +0000",
  "in_reply_to_screen_name" : "Lucif0r",
  "in_reply_to_user_id_str" : "113398969",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "hubx",
      "screen_name" : "hubx",
      "indices" : [ 0, 5 ],
      "id_str" : "16488666",
      "id" : 16488666
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "650432201130135552",
  "geo" : { },
  "id_str" : "650433746433372160",
  "in_reply_to_user_id" : 16488666,
  "text" : "@hubx they seem to not offer an iOS app?",
  "id" : 650433746433372160,
  "in_reply_to_status_id" : 650432201130135552,
  "created_at" : "2015-10-03 22:14:24 +0000",
  "in_reply_to_screen_name" : "hubx",
  "in_reply_to_user_id_str" : "16488666",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "650430644389052416",
  "geo" : { },
  "id_str" : "650431053811838976",
  "in_reply_to_user_id" : 14286491,
  "text" : "Also: Help lazyweb, is there a nice goodreads equivalent for video content? (Don\u2019t say IMDb, I dislike the UX so much)",
  "id" : 650431053811838976,
  "in_reply_to_status_id" : 650430644389052416,
  "created_at" : "2015-10-03 22:03:42 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/Ysh0XGmksL",
      "expanded_url" : "http:\/\/38.media.tumblr.com\/db4ec4abeb95b7331f7bae8a7da08b4e\/tumblr_msl12fsl131rrafppo1_250.gif",
      "display_url" : "38.media.tumblr.com\/db4ec4abeb95b7\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "650430644389052416",
  "text" : "\u2018The Big Year\u2019 is fun. Now I wanna go birding. http:\/\/t.co\/Ysh0XGmksL",
  "id" : 650430644389052416,
  "created_at" : "2015-10-03 22:02:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 64 ],
      "url" : "https:\/\/t.co\/1rOJ6rSxcj",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/650323033438191616",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "650323033438191616",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11405944818397, 8.749832153349411 ]
  },
  "id_str" : "650401055868604416",
  "in_reply_to_user_id" : 14286491,
  "text" : "And did the same for a second thesis. \uD83D\uDCCA\uD83D\uDCDD https:\/\/t.co\/1rOJ6rSxcj",
  "id" : 650401055868604416,
  "in_reply_to_status_id" : 650323033438191616,
  "created_at" : "2015-10-03 20:04:30 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 66 ],
      "url" : "http:\/\/t.co\/7yk8Ze0LbP",
      "expanded_url" : "http:\/\/www.smbc-comics.com\/index.php?id=3878",
      "display_url" : "smbc-comics.com\/index.php?id=3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "650369500328628224",
  "text" : "ethics shouldn't be tied to CPU performance http:\/\/t.co\/7yk8Ze0LbP",
  "id" : 650369500328628224,
  "created_at" : "2015-10-03 17:59:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "650323033438191616",
  "text" : "Doing first-pass thesis corrections. \uD83D\uDCD3\uD83D\uDCDA\u2702\uFE0F\u270F\uFE0F",
  "id" : 650323033438191616,
  "created_at" : "2015-10-03 14:54:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 47 ],
      "url" : "https:\/\/t.co\/YqxYseVfTy",
      "expanded_url" : "https:\/\/twitter.com\/lexnederbragt\/status\/649962441246384128",
      "display_url" : "twitter.com\/lexnederbragt\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.18816903517902, 8.698204066827556 ]
  },
  "id_str" : "650309274430779392",
  "text" : "My best guess: nothing. https:\/\/t.co\/YqxYseVfTy",
  "id" : 650309274430779392,
  "created_at" : "2015-10-03 13:59:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Allen",
      "screen_name" : "sarahtallen",
      "indices" : [ 3, 15 ],
      "id_str" : "556876820",
      "id" : 556876820
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MozFest",
      "indices" : [ 123, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "650297143002009600",
  "text" : "RT @sarahtallen: Excited to share our new program for 2015. Introducing 8 Spaces, central hubs of learning that will shape #MozFest\nhttps:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MozFest",
        "indices" : [ 106, 114 ]
      } ],
      "urls" : [ {
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/Yk3yPMwPFt",
        "expanded_url" : "https:\/\/2015.mozillafestival.org\/sessions",
        "display_url" : "2015.mozillafestival.org\/sessions"
      } ]
    },
    "geo" : { },
    "id_str" : "650242853679968256",
    "text" : "Excited to share our new program for 2015. Introducing 8 Spaces, central hubs of learning that will shape #MozFest\nhttps:\/\/t.co\/Yk3yPMwPFt",
    "id" : 650242853679968256,
    "created_at" : "2015-10-03 09:35:51 +0000",
    "user" : {
      "name" : "Sarah Allen",
      "screen_name" : "sarahtallen",
      "protected" : false,
      "id_str" : "556876820",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/480289588234051584\/lnMTRaf0_normal.jpeg",
      "id" : 556876820,
      "verified" : false
    }
  },
  "id" : 650297143002009600,
  "created_at" : "2015-10-03 13:11:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/eWCZhkntbi",
      "expanded_url" : "https:\/\/twitter.com\/SynFutures\/status\/650264197834612736",
      "display_url" : "twitter.com\/SynFutures\/sta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "650266778468270080",
  "text" : "I guess I will have to do some binge watching and claim it\u2019s research. https:\/\/t.co\/eWCZhkntbi",
  "id" : 650266778468270080,
  "created_at" : "2015-10-03 11:10:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael R. Crusoe",
      "screen_name" : "biocrusoe",
      "indices" : [ 0, 10 ],
      "id_str" : "17645638",
      "id" : 17645638
    }, {
      "name" : "Lisa Johnson",
      "screen_name" : "monsterbashseq",
      "indices" : [ 11, 26 ],
      "id_str" : "3091713533",
      "id" : 3091713533
    }, {
      "name" : "Luiz Irber",
      "screen_name" : "luizirber",
      "indices" : [ 27, 37 ],
      "id_str" : "13166572",
      "id" : 13166572
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "650070153405726720",
  "geo" : { },
  "id_str" : "650258041200340993",
  "in_reply_to_user_id" : 17645638,
  "text" : "@biocrusoe @monsterbashseq @luizirber  I guess that\u2019s how you really do cross-platform.",
  "id" : 650258041200340993,
  "in_reply_to_status_id" : 650070153405726720,
  "created_at" : "2015-10-03 10:36:12 +0000",
  "in_reply_to_screen_name" : "biocrusoe",
  "in_reply_to_user_id_str" : "17645638",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "rogier kievit",
      "screen_name" : "rogierK",
      "indices" : [ 3, 11 ],
      "id_str" : "28082102",
      "id" : 28082102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/kuBRSOmM10",
      "expanded_url" : "http:\/\/www.tandfonline.com\/doi\/abs\/10.1300\/J019v27n01_01",
      "display_url" : "tandfonline.com\/doi\/abs\/10.130\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "650257423681331200",
  "text" : "RT @rogierK: Take your publishing sob stories and tell them to the first author of this paper https:\/\/t.co\/kuBRSOmM10 https:\/\/t.co\/yqvX5EKX\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/rogierK\/status\/649680920887304193\/photo\/1",
        "indices" : [ 105, 128 ],
        "url" : "https:\/\/t.co\/yqvX5EKXSp",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CQQhWsjWsAAhSWb.jpg",
        "id_str" : "649680920048480256",
        "id" : 649680920048480256,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQQhWsjWsAAhSWb.jpg",
        "sizes" : [ {
          "h" : 108,
          "resize" : "fit",
          "w" : 406
        }, {
          "h" : 108,
          "resize" : "fit",
          "w" : 406
        }, {
          "h" : 108,
          "resize" : "fit",
          "w" : 406
        }, {
          "h" : 108,
          "resize" : "fit",
          "w" : 406
        }, {
          "h" : 108,
          "resize" : "crop",
          "w" : 108
        } ],
        "display_url" : "pic.twitter.com\/yqvX5EKXSp"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 81, 104 ],
        "url" : "https:\/\/t.co\/kuBRSOmM10",
        "expanded_url" : "http:\/\/www.tandfonline.com\/doi\/abs\/10.1300\/J019v27n01_01",
        "display_url" : "tandfonline.com\/doi\/abs\/10.130\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "649680920887304193",
    "text" : "Take your publishing sob stories and tell them to the first author of this paper https:\/\/t.co\/kuBRSOmM10 https:\/\/t.co\/yqvX5EKXSp",
    "id" : 649680920887304193,
    "created_at" : "2015-10-01 20:22:56 +0000",
    "user" : {
      "name" : "rogier kievit",
      "screen_name" : "rogierK",
      "protected" : false,
      "id_str" : "28082102",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2609282617\/vg54wpa4mmxkjzjqlo7g_normal.jpeg",
      "id" : 28082102,
      "verified" : false
    }
  },
  "id" : 650257423681331200,
  "created_at" : "2015-10-03 10:33:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "the juan",
      "screen_name" : "terminalbreaker",
      "indices" : [ 3, 19 ],
      "id_str" : "214579886",
      "id" : 214579886
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/terminalbreaker\/status\/644526894549852161\/photo\/1",
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/ngYuO0w9pm",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CPHRy1LUwAAbCl1.png",
      "id_str" : "644526892888932352",
      "id" : 644526892888932352,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CPHRy1LUwAAbCl1.png",
      "sizes" : [ {
        "h" : 260,
        "resize" : "fit",
        "w" : 388
      }, {
        "h" : 260,
        "resize" : "fit",
        "w" : 388
      }, {
        "h" : 260,
        "resize" : "fit",
        "w" : 388
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 260,
        "resize" : "fit",
        "w" : 388
      } ],
      "display_url" : "pic.twitter.com\/ngYuO0w9pm"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "650256097136218112",
  "text" : "RT @terminalbreaker: When someone submits a pull request into your project. http:\/\/t.co\/ngYuO0w9pm",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/terminalbreaker\/status\/644526894549852161\/photo\/1",
        "indices" : [ 55, 77 ],
        "url" : "http:\/\/t.co\/ngYuO0w9pm",
        "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CPHRy1LUwAAbCl1.png",
        "id_str" : "644526892888932352",
        "id" : 644526892888932352,
        "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CPHRy1LUwAAbCl1.png",
        "sizes" : [ {
          "h" : 260,
          "resize" : "fit",
          "w" : 388
        }, {
          "h" : 260,
          "resize" : "fit",
          "w" : 388
        }, {
          "h" : 260,
          "resize" : "fit",
          "w" : 388
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 260,
          "resize" : "fit",
          "w" : 388
        } ],
        "display_url" : "pic.twitter.com\/ngYuO0w9pm"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "644526894549852161",
    "text" : "When someone submits a pull request into your project. http:\/\/t.co\/ngYuO0w9pm",
    "id" : 644526894549852161,
    "created_at" : "2015-09-17 15:02:41 +0000",
    "user" : {
      "name" : "the juan",
      "screen_name" : "terminalbreaker",
      "protected" : false,
      "id_str" : "214579886",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1886705431\/lizard_normal.jpg",
      "id" : 214579886,
      "verified" : false
    }
  },
  "id" : 650256097136218112,
  "created_at" : "2015-10-03 10:28:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "650165770643640325",
  "geo" : { },
  "id_str" : "650251085156904960",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer Dr Zompo :3",
  "id" : 650251085156904960,
  "in_reply_to_status_id" : 650165770643640325,
  "created_at" : "2015-10-03 10:08:34 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uD83D\uDCABKelsey Merkley \uD83D\uDCAB",
      "screen_name" : "bella_velo",
      "indices" : [ 0, 11 ],
      "id_str" : "6745972",
      "id" : 6745972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "650095400385298433",
  "geo" : { },
  "id_str" : "650249895643906048",
  "in_reply_to_user_id" : 6745972,
  "text" : "@bella_velo I have tons of people who I will have to show that recording to. :)",
  "id" : 650249895643906048,
  "in_reply_to_status_id" : 650095400385298433,
  "created_at" : "2015-10-03 10:03:50 +0000",
  "in_reply_to_screen_name" : "bella_velo",
  "in_reply_to_user_id_str" : "6745972",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael R. Crusoe",
      "screen_name" : "biocrusoe",
      "indices" : [ 3, 13 ],
      "id_str" : "17645638",
      "id" : 17645638
    }, {
      "name" : "Lisa Johnson",
      "screen_name" : "monsterbashseq",
      "indices" : [ 16, 31 ],
      "id_str" : "3091713533",
      "id" : 3091713533
    }, {
      "name" : "Luiz Irber",
      "screen_name" : "luizirber",
      "indices" : [ 38, 48 ],
      "id_str" : "13166572",
      "id" : 13166572
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "650241624199561216",
  "text" : "RT @biocrusoe: .@monsterbashseq &amp; @luizirber are Installing MS Windows in a MacBook via an Illumina pendrive for our MinION seq'nr. http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Lisa Johnson",
        "screen_name" : "monsterbashseq",
        "indices" : [ 1, 16 ],
        "id_str" : "3091713533",
        "id" : 3091713533
      }, {
        "name" : "Luiz Irber",
        "screen_name" : "luizirber",
        "indices" : [ 23, 33 ],
        "id_str" : "13166572",
        "id" : 13166572
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/biocrusoe\/status\/650070153405726720\/photo\/1",
        "indices" : [ 121, 143 ],
        "url" : "http:\/\/t.co\/herGRqL2vn",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CQWDWtJUwAAhfTD.jpg",
        "id_str" : "650070147323969536",
        "id" : 650070147323969536,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQWDWtJUwAAhfTD.jpg",
        "sizes" : [ {
          "h" : 1520,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 505,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 891,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1520,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/herGRqL2vn"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "650070153405726720",
    "text" : ".@monsterbashseq &amp; @luizirber are Installing MS Windows in a MacBook via an Illumina pendrive for our MinION seq'nr. http:\/\/t.co\/herGRqL2vn",
    "id" : 650070153405726720,
    "created_at" : "2015-10-02 22:09:36 +0000",
    "user" : {
      "name" : "Michael R. Crusoe",
      "screen_name" : "biocrusoe",
      "protected" : false,
      "id_str" : "17645638",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/485998749311721472\/0yX4CFRV_normal.jpeg",
      "id" : 17645638,
      "verified" : false
    }
  },
  "id" : 650241624199561216,
  "created_at" : "2015-10-03 09:30:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GigaScience",
      "screen_name" : "GigaScience",
      "indices" : [ 3, 15 ],
      "id_str" : "208988759",
      "id" : 208988759
    }, {
      "name" : "DNAdigest.org",
      "screen_name" : "DNADigest",
      "indices" : [ 79, 89 ],
      "id_str" : "334912047",
      "id" : 334912047
    }, {
      "name" : "openSNP team",
      "screen_name" : "openSNPorg",
      "indices" : [ 96, 107 ],
      "id_str" : "380205172",
      "id" : 380205172
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HongKong",
      "indices" : [ 33, 42 ]
    }, {
      "text" : "opendata",
      "indices" : [ 43, 52 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/pFUbUWjPg5",
      "expanded_url" : "https:\/\/www.facebook.com\/events\/1064128190288114\/",
      "display_url" : "facebook.com\/events\/1064128\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "650202603712847872",
  "text" : "RT @GigaScience: Sign up for our #HongKong #opendata in genomics workshop with @DNADigest &amp; @openSNPorg https:\/\/t.co\/pFUbUWjPg5 http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "DNAdigest.org",
        "screen_name" : "DNADigest",
        "indices" : [ 62, 72 ],
        "id_str" : "334912047",
        "id" : 334912047
      }, {
        "name" : "openSNP team",
        "screen_name" : "openSNPorg",
        "indices" : [ 79, 90 ],
        "id_str" : "380205172",
        "id" : 380205172
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/GigaScience\/status\/650058630222475265\/photo\/1",
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/KAInK3QxN5",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CQV431JUwAAFEii.jpg",
        "id_str" : "650058621779230720",
        "id" : 650058621779230720,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQV431JUwAAFEii.jpg",
        "sizes" : [ {
          "h" : 365,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 385,
          "resize" : "fit",
          "w" : 717
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 385,
          "resize" : "fit",
          "w" : 717
        }, {
          "h" : 385,
          "resize" : "fit",
          "w" : 717
        } ],
        "display_url" : "pic.twitter.com\/KAInK3QxN5"
      } ],
      "hashtags" : [ {
        "text" : "HongKong",
        "indices" : [ 16, 25 ]
      }, {
        "text" : "opendata",
        "indices" : [ 26, 35 ]
      } ],
      "urls" : [ {
        "indices" : [ 91, 114 ],
        "url" : "https:\/\/t.co\/pFUbUWjPg5",
        "expanded_url" : "https:\/\/www.facebook.com\/events\/1064128190288114\/",
        "display_url" : "facebook.com\/events\/1064128\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "650058630222475265",
    "text" : "Sign up for our #HongKong #opendata in genomics workshop with @DNADigest &amp; @openSNPorg https:\/\/t.co\/pFUbUWjPg5 http:\/\/t.co\/KAInK3QxN5",
    "id" : 650058630222475265,
    "created_at" : "2015-10-02 21:23:49 +0000",
    "user" : {
      "name" : "GigaScience",
      "screen_name" : "GigaScience",
      "protected" : false,
      "id_str" : "208988759",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1404305552\/profile-photo-GigaScience-96x96_normal.jpg",
      "id" : 208988759,
      "verified" : false
    }
  },
  "id" : 650202603712847872,
  "created_at" : "2015-10-03 06:55:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert Sanders",
      "screen_name" : "bobthesciguy",
      "indices" : [ 3, 16 ],
      "id_str" : "16928926",
      "id" : 16928926
    }, {
      "name" : "UC Berkeley",
      "screen_name" : "UCBerkeley",
      "indices" : [ 25, 36 ],
      "id_str" : "176932593",
      "id" : 176932593
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CRISPR",
      "indices" : [ 93, 100 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/nDvidTv5E0",
      "expanded_url" : "http:\/\/buff.ly\/1WCllfi",
      "display_url" : "buff.ly\/1WCllfi"
    } ]
  },
  "geo" : { },
  "id_str" : "650202270110453760",
  "text" : "RT @bobthesciguy: Doudna @UCBerkeley receives Women in Science Award from L\u2019Oreal-UNESCO for #CRISPR work http:\/\/t.co\/nDvidTv5E0 http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "UC Berkeley",
        "screen_name" : "UCBerkeley",
        "indices" : [ 7, 18 ],
        "id_str" : "176932593",
        "id" : 176932593
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/bobthesciguy\/status\/650054025082204160\/photo\/1",
        "indices" : [ 111, 133 ],
        "url" : "http:\/\/t.co\/T3fZMm3mPV",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CQV0sQxWEAEXZuQ.jpg",
        "id_str" : "650054024989904897",
        "id" : 650054024989904897,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQV0sQxWEAEXZuQ.jpg",
        "sizes" : [ {
          "h" : 273,
          "resize" : "fit",
          "w" : 410
        }, {
          "h" : 273,
          "resize" : "fit",
          "w" : 410
        }, {
          "h" : 273,
          "resize" : "fit",
          "w" : 410
        }, {
          "h" : 273,
          "resize" : "fit",
          "w" : 410
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/T3fZMm3mPV"
      } ],
      "hashtags" : [ {
        "text" : "CRISPR",
        "indices" : [ 75, 82 ]
      } ],
      "urls" : [ {
        "indices" : [ 88, 110 ],
        "url" : "http:\/\/t.co\/nDvidTv5E0",
        "expanded_url" : "http:\/\/buff.ly\/1WCllfi",
        "display_url" : "buff.ly\/1WCllfi"
      } ]
    },
    "geo" : { },
    "id_str" : "650054025082204160",
    "text" : "Doudna @UCBerkeley receives Women in Science Award from L\u2019Oreal-UNESCO for #CRISPR work http:\/\/t.co\/nDvidTv5E0 http:\/\/t.co\/T3fZMm3mPV",
    "id" : 650054025082204160,
    "created_at" : "2015-10-02 21:05:31 +0000",
    "user" : {
      "name" : "Robert Sanders",
      "screen_name" : "bobthesciguy",
      "protected" : false,
      "id_str" : "16928926",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/189905488\/bob_normal.jpg",
      "id" : 16928926,
      "verified" : false
    }
  },
  "id" : 650202270110453760,
  "created_at" : "2015-10-03 06:54:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Der @KleineMaulwurf",
      "screen_name" : "KleineMaulwurf",
      "indices" : [ 0, 15 ],
      "id_str" : "49373312",
      "id" : 49373312
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "650077344238071810",
  "geo" : { },
  "id_str" : "650077606604353536",
  "in_reply_to_user_id" : 49373312,
  "text" : "@KleineMaulwurf ich w\u00FCnschte ich w\u00E4re so gut :)",
  "id" : 650077606604353536,
  "in_reply_to_status_id" : 650077344238071810,
  "created_at" : "2015-10-02 22:39:13 +0000",
  "in_reply_to_screen_name" : "KleineMaulwurf",
  "in_reply_to_user_id_str" : "49373312",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 42 ],
      "url" : "https:\/\/t.co\/Z8f8rfbUIf",
      "expanded_url" : "https:\/\/twitter.com\/Dretty\/status\/650051856119402496",
      "display_url" : "twitter.com\/Dretty\/status\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "650076765239554052",
  "text" : "Wait, who\u2019s that?! https:\/\/t.co\/Z8f8rfbUIf",
  "id" : 650076765239554052,
  "created_at" : "2015-10-02 22:35:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uD83C\uDFA8Dretty Pendergrass",
      "screen_name" : "Dretty",
      "indices" : [ 0, 7 ],
      "id_str" : "31086705",
      "id" : 31086705
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "650051856119402496",
  "geo" : { },
  "id_str" : "650076682037104640",
  "in_reply_to_user_id" : 31086705,
  "text" : "@Dretty sweet! Thank you so much!",
  "id" : 650076682037104640,
  "in_reply_to_status_id" : 650051856119402496,
  "created_at" : "2015-10-02 22:35:33 +0000",
  "in_reply_to_screen_name" : "Dretty",
  "in_reply_to_user_id_str" : "31086705",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uD83D\uDCABKelsey Merkley \uD83D\uDCAB",
      "screen_name" : "bella_velo",
      "indices" : [ 0, 11 ],
      "id_str" : "6745972",
      "id" : 6745972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 43 ],
      "url" : "http:\/\/t.co\/DlwSb6Z09P",
      "expanded_url" : "http:\/\/www.sharegif.com\/wp-content\/uploads\/2014\/01\/tumblr_ml87q0tkrp1re3x32o1_.gif",
      "display_url" : "sharegif.com\/wp-content\/upl\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "649990711127879681",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11407454530604, 8.75337612992529 ]
  },
  "id_str" : "650039007167021056",
  "in_reply_to_user_id" : 6745972,
  "text" : "@bella_velo awesome! http:\/\/t.co\/DlwSb6Z09P",
  "id" : 650039007167021056,
  "in_reply_to_status_id" : 649990711127879681,
  "created_at" : "2015-10-02 20:05:51 +0000",
  "in_reply_to_screen_name" : "bella_velo",
  "in_reply_to_user_id_str" : "6745972",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 53 ],
      "url" : "https:\/\/t.co\/fCnGGyqj4S",
      "expanded_url" : "https:\/\/twitter.com\/bella_velo\/status\/649990711127879681",
      "display_url" : "twitter.com\/bella_velo\/sta\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11407454530604, 8.75337612992529 ]
  },
  "id_str" : "650038157212299269",
  "text" : "talking from a place of trust https:\/\/t.co\/fCnGGyqj4S",
  "id" : 650038157212299269,
  "created_at" : "2015-10-02 20:02:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TheConstructor",
      "screen_name" : "TheConstructor",
      "indices" : [ 0, 15 ],
      "id_str" : "14362840",
      "id" : 14362840
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "650037444159647744",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11407454530604, 8.75337612992529 ]
  },
  "id_str" : "650038021203607552",
  "in_reply_to_user_id" : 14362840,
  "text" : "@TheConstructor Kein Ding, hab f\u00FCr ~4 Monate in Frankfurt gelebt, dann Mainz, dann Offenbach :)",
  "id" : 650038021203607552,
  "in_reply_to_status_id" : 650037444159647744,
  "created_at" : "2015-10-02 20:01:56 +0000",
  "in_reply_to_screen_name" : "TheConstructor",
  "in_reply_to_user_id_str" : "14362840",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uD83D\uDCABKelsey Merkley \uD83D\uDCAB",
      "screen_name" : "bella_velo",
      "indices" : [ 3, 14 ],
      "id_str" : "6745972",
      "id" : 6745972
    }, {
      "name" : "TEDxCapeTown",
      "screen_name" : "tedxcapetown",
      "indices" : [ 19, 32 ],
      "id_str" : "240651127",
      "id" : 240651127
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 72 ],
      "url" : "https:\/\/t.co\/nnzYu6An9f",
      "expanded_url" : "https:\/\/m.youtube.com\/watch?v=S1bAP6muuvg",
      "display_url" : "m.youtube.com\/watch?v=S1bAP6\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "650037593439141888",
  "text" : "RT @bella_velo: My @tedxcapetown official talk -\nhttps:\/\/t.co\/nnzYu6An9f  for your enjoyment and my cringing.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "TEDxCapeTown",
        "screen_name" : "tedxcapetown",
        "indices" : [ 3, 16 ],
        "id_str" : "240651127",
        "id" : 240651127
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 33, 56 ],
        "url" : "https:\/\/t.co\/nnzYu6An9f",
        "expanded_url" : "https:\/\/m.youtube.com\/watch?v=S1bAP6muuvg",
        "display_url" : "m.youtube.com\/watch?v=S1bAP6\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "649990711127879681",
    "text" : "My @tedxcapetown official talk -\nhttps:\/\/t.co\/nnzYu6An9f  for your enjoyment and my cringing.",
    "id" : 649990711127879681,
    "created_at" : "2015-10-02 16:53:56 +0000",
    "user" : {
      "name" : "\uD83D\uDCABKelsey Merkley \uD83D\uDCAB",
      "screen_name" : "bella_velo",
      "protected" : false,
      "id_str" : "6745972",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/875913994929934336\/1aiBO2bG_normal.jpg",
      "id" : 6745972,
      "verified" : false
    }
  },
  "id" : 650037593439141888,
  "created_at" : "2015-10-02 20:00:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TheConstructor",
      "screen_name" : "TheConstructor",
      "indices" : [ 0, 15 ],
      "id_str" : "14362840",
      "id" : 14362840
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "649994086699679744",
  "geo" : { },
  "id_str" : "650015840331526144",
  "in_reply_to_user_id" : 14362840,
  "text" : "@TheConstructor ich wohne in Offenbach :)",
  "id" : 650015840331526144,
  "in_reply_to_status_id" : 649994086699679744,
  "created_at" : "2015-10-02 18:33:47 +0000",
  "in_reply_to_screen_name" : "TheConstructor",
  "in_reply_to_user_id_str" : "14362840",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mrgunn",
      "screen_name" : "mrgunn",
      "indices" : [ 0, 7 ],
      "id_str" : "15237935",
      "id" : 15237935
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "649987084778737665",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11405621285003, 8.753421889739833 ]
  },
  "id_str" : "649987351578591232",
  "in_reply_to_user_id" : 15237935,
  "text" : "@mrgunn that\u2019s a good idea, but the whole concept of venues doesn\u2019t really work for \u2018the great outdoors\u2019 category.",
  "id" : 649987351578591232,
  "in_reply_to_status_id" : 649987084778737665,
  "created_at" : "2015-10-02 16:40:35 +0000",
  "in_reply_to_screen_name" : "mrgunn",
  "in_reply_to_user_id_str" : "15237935",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mrgunn",
      "screen_name" : "mrgunn",
      "indices" : [ 0, 7 ],
      "id_str" : "15237935",
      "id" : 15237935
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 91 ],
      "url" : "https:\/\/t.co\/0I7jHQDZXY",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/618743820390416384",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "649984592510758912",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11407381827355, 8.753389013831022 ]
  },
  "id_str" : "649985840412786688",
  "in_reply_to_user_id" : 15237935,
  "text" : "@mrgunn actually wanted to share this one, but you get the idea. :) https:\/\/t.co\/0I7jHQDZXY",
  "id" : 649985840412786688,
  "in_reply_to_status_id" : 649984592510758912,
  "created_at" : "2015-10-02 16:34:35 +0000",
  "in_reply_to_screen_name" : "mrgunn",
  "in_reply_to_user_id_str" : "15237935",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mrgunn",
      "screen_name" : "mrgunn",
      "indices" : [ 0, 7 ],
      "id_str" : "15237935",
      "id" : 15237935
    }, {
      "name" : "Foursquare Swarm",
      "screen_name" : "SwarmApp",
      "indices" : [ 25, 34 ],
      "id_str" : "240676055",
      "id" : 240676055
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/fHsFObdg6y",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/618701515067363328",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "649984592510758912",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11407381827355, 8.753389013831022 ]
  },
  "id_str" : "649985546937352192",
  "in_reply_to_user_id" : 15237935,
  "text" : "@mrgunn and I\u2019m using my @swarmapp data along with Twitter geostamps for data viz, i.e. https:\/\/t.co\/fHsFObdg6y",
  "id" : 649985546937352192,
  "in_reply_to_status_id" : 649984592510758912,
  "created_at" : "2015-10-02 16:33:25 +0000",
  "in_reply_to_screen_name" : "mrgunn",
  "in_reply_to_user_id_str" : "15237935",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mrgunn",
      "screen_name" : "mrgunn",
      "indices" : [ 0, 7 ],
      "id_str" : "15237935",
      "id" : 15237935
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "649984592510758912",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11407448829672, 8.75337682352694 ]
  },
  "id_str" : "649984905288531968",
  "in_reply_to_user_id" : 15237935,
  "text" : "@mrgunn e.g. the venue is \u201Criver bank\u201D and I\u2019m strolling there for 5k, is this stopping there or passing by?",
  "id" : 649984905288531968,
  "in_reply_to_status_id" : 649984592510758912,
  "created_at" : "2015-10-02 16:30:52 +0000",
  "in_reply_to_screen_name" : "mrgunn",
  "in_reply_to_user_id_str" : "15237935",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mrgunn",
      "screen_name" : "mrgunn",
      "indices" : [ 0, 7 ],
      "id_str" : "15237935",
      "id" : 15237935
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "649981975592173569",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11407425500024, 8.753381646188386 ]
  },
  "id_str" : "649984005618728960",
  "in_reply_to_user_id" : 15237935,
  "text" : "@mrgunn I guess it depends. I would love to be checked in into venues I also check in manually when going for a walk instead of run.",
  "id" : 649984005618728960,
  "in_reply_to_status_id" : 649981975592173569,
  "created_at" : "2015-10-02 16:27:17 +0000",
  "in_reply_to_screen_name" : "mrgunn",
  "in_reply_to_user_id_str" : "15237935",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Chapman",
      "screen_name" : "chapmangamo",
      "indices" : [ 0, 12 ],
      "id_str" : "30633376",
      "id" : 30633376
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "649980063430148096",
  "geo" : { },
  "id_str" : "649980229683953664",
  "in_reply_to_user_id" : 30633376,
  "text" : "@chapmangamo I wish I was famous for that reason!",
  "id" : 649980229683953664,
  "in_reply_to_status_id" : 649980063430148096,
  "created_at" : "2015-10-02 16:12:17 +0000",
  "in_reply_to_screen_name" : "chapmangamo",
  "in_reply_to_user_id_str" : "30633376",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fitbit Support",
      "screen_name" : "FitbitSupport",
      "indices" : [ 0, 14 ],
      "id_str" : "476258341",
      "id" : 476258341
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "649979000345858048",
  "geo" : { },
  "id_str" : "649979949114368000",
  "in_reply_to_user_id" : 476258341,
  "text" : "@FitbitSupport thanks :)",
  "id" : 649979949114368000,
  "in_reply_to_status_id" : 649979000345858048,
  "created_at" : "2015-10-02 16:11:10 +0000",
  "in_reply_to_screen_name" : "FitbitSupport",
  "in_reply_to_user_id_str" : "476258341",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Chapman",
      "screen_name" : "chapmangamo",
      "indices" : [ 0, 12 ],
      "id_str" : "30633376",
      "id" : 30633376
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "649973806128304129",
  "geo" : { },
  "id_str" : "649979637133611010",
  "in_reply_to_user_id" : 30633376,
  "text" : "@chapmangamo this is how I refer to you and your work all the time. \uD83D\uDC36\u2764\uFE0F",
  "id" : 649979637133611010,
  "in_reply_to_status_id" : 649973806128304129,
  "created_at" : "2015-10-02 16:09:56 +0000",
  "in_reply_to_screen_name" : "chapmangamo",
  "in_reply_to_user_id_str" : "30633376",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fitbit Support",
      "screen_name" : "FitbitSupport",
      "indices" : [ 0, 14 ],
      "id_str" : "476258341",
      "id" : 476258341
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "649978267663925248",
  "geo" : { },
  "id_str" : "649978381832990721",
  "in_reply_to_user_id" : 476258341,
  "text" : "@FitbitSupport the Apple Watch \u263A\uFE0F",
  "id" : 649978381832990721,
  "in_reply_to_status_id" : 649978267663925248,
  "created_at" : "2015-10-02 16:04:56 +0000",
  "in_reply_to_screen_name" : "FitbitSupport",
  "in_reply_to_user_id_str" : "476258341",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fitbit Support",
      "screen_name" : "FitbitSupport",
      "indices" : [ 0, 14 ],
      "id_str" : "476258341",
      "id" : 476258341
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "649974238774857728",
  "geo" : { },
  "id_str" : "649977214163910656",
  "in_reply_to_user_id" : 476258341,
  "text" : "@FitbitSupport thanks, speaking of features: are you working on adding support for the \u231A\uFE0F? \u263A\uFE0F",
  "id" : 649977214163910656,
  "in_reply_to_status_id" : 649974238774857728,
  "created_at" : "2015-10-02 16:00:18 +0000",
  "in_reply_to_screen_name" : "FitbitSupport",
  "in_reply_to_user_id_str" : "476258341",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fitbit",
      "screen_name" : "fitbit",
      "indices" : [ 33, 40 ],
      "id_str" : "17424053",
      "id" : 17424053
    }, {
      "name" : "Foursquare Swarm",
      "screen_name" : "SwarmApp",
      "indices" : [ 98, 107 ],
      "id_str" : "240676055",
      "id" : 240676055
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "649972933545357312",
  "text" : "I wish there was a way to use my @fitbit GPS running tracks to automatically check me in into all @swarmapp venues I passed.",
  "id" : 649972933545357312,
  "created_at" : "2015-10-02 15:43:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 55 ],
      "url" : "https:\/\/t.co\/ZOxhf6oQTY",
      "expanded_url" : "https:\/\/www.patreon.com\/openSNP?ty=h",
      "display_url" : "patreon.com\/openSNP?ty=h"
    }, {
      "indices" : [ 57, 80 ],
      "url" : "https:\/\/t.co\/ZlN0m95tDu",
      "expanded_url" : "https:\/\/twitter.com\/PhilippBayer\/status\/649940087241728000",
      "display_url" : "twitter.com\/PhilippBayer\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "649942685659365376",
  "text" : "Still, you can give us money at https:\/\/t.co\/ZOxhf6oQTY! https:\/\/t.co\/ZlN0m95tDu",
  "id" : 649942685659365376,
  "created_at" : "2015-10-02 13:43:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bede Constantinides",
      "screen_name" : "beconstant",
      "indices" : [ 0, 11 ],
      "id_str" : "112876914",
      "id" : 112876914
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "649932614036508672",
  "geo" : { },
  "id_str" : "649932794144145408",
  "in_reply_to_user_id" : 112876914,
  "text" : "@beconstant ah, \u201Conly-assembler\u201D, my bad. :)",
  "id" : 649932794144145408,
  "in_reply_to_status_id" : 649932614036508672,
  "created_at" : "2015-10-02 13:03:47 +0000",
  "in_reply_to_screen_name" : "beconstant",
  "in_reply_to_user_id_str" : "112876914",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bede Constantinides",
      "screen_name" : "beconstant",
      "indices" : [ 0, 11 ],
      "id_str" : "112876914",
      "id" : 112876914
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "649931755877740544",
  "geo" : { },
  "id_str" : "649932169205391361",
  "in_reply_to_user_id" : 112876914,
  "text" : "@beconstant you could try it w\/o Hammer by using the -only-assembly flag (at least I think that\u2019s the flag).",
  "id" : 649932169205391361,
  "in_reply_to_status_id" : 649931755877740544,
  "created_at" : "2015-10-02 13:01:18 +0000",
  "in_reply_to_screen_name" : "beconstant",
  "in_reply_to_user_id_str" : "112876914",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bede Constantinides",
      "screen_name" : "beconstant",
      "indices" : [ 0, 11 ],
      "id_str" : "112876914",
      "id" : 112876914
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "649930926928084992",
  "geo" : { },
  "id_str" : "649931201063616512",
  "in_reply_to_user_id" : 112876914,
  "text" : "@beconstant Interesting indeed! This I\u2019ve seen crashing in 3.5 too. But also when running only a single assembly.",
  "id" : 649931201063616512,
  "in_reply_to_status_id" : 649930926928084992,
  "created_at" : "2015-10-02 12:57:28 +0000",
  "in_reply_to_screen_name" : "beconstant",
  "in_reply_to_user_id_str" : "112876914",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bede Constantinides",
      "screen_name" : "beconstant",
      "indices" : [ 0, 11 ],
      "id_str" : "112876914",
      "id" : 112876914
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "649930834062016512",
  "in_reply_to_user_id" : 112876914,
  "text" : "@beconstant BayesHammer or what it\u2019s called is doing the pre-assembly read-correction. The MismatchCorrector uses bwamem for fixing contigs.",
  "id" : 649930834062016512,
  "created_at" : "2015-10-02 12:56:00 +0000",
  "in_reply_to_screen_name" : "beconstant",
  "in_reply_to_user_id_str" : "112876914",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bede Constantinides",
      "screen_name" : "beconstant",
      "indices" : [ 0, 11 ],
      "id_str" : "112876914",
      "id" : 112876914
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "649930032048160768",
  "geo" : { },
  "id_str" : "649930394209505280",
  "in_reply_to_user_id" : 112876914,
  "text" : "@beconstant I\u2019ve had similar problems with 3.5 during mismatchcorrector-step. Which step gives you trouble?",
  "id" : 649930394209505280,
  "in_reply_to_status_id" : 649930032048160768,
  "created_at" : "2015-10-02 12:54:15 +0000",
  "in_reply_to_screen_name" : "beconstant",
  "in_reply_to_user_id_str" : "112876914",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bede Constantinides",
      "screen_name" : "beconstant",
      "indices" : [ 0, 11 ],
      "id_str" : "112876914",
      "id" : 112876914
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "649929379515117568",
  "geo" : { },
  "id_str" : "649929748290871296",
  "in_reply_to_user_id" : 112876914,
  "text" : "@beconstant which Version?",
  "id" : 649929748290871296,
  "in_reply_to_status_id" : 649929379515117568,
  "created_at" : "2015-10-02 12:51:41 +0000",
  "in_reply_to_screen_name" : "beconstant",
  "in_reply_to_user_id_str" : "112876914",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 7, 30 ],
      "url" : "https:\/\/t.co\/ouDBuqnOGF",
      "expanded_url" : "https:\/\/media4.giphy.com\/media\/tK5JkmMAPveNO\/200.gif",
      "display_url" : "media4.giphy.com\/media\/tK5JkmMA\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "649925468599226368",
  "geo" : { },
  "id_str" : "649928865637355520",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot https:\/\/t.co\/ouDBuqnOGF",
  "id" : 649928865637355520,
  "in_reply_to_status_id" : 649925468599226368,
  "created_at" : "2015-10-02 12:48:11 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/gGJFwSXiDs",
      "expanded_url" : "http:\/\/figshare.com\/articles\/De_novo_Assembly_and_Comparative_Genomics_on_Eukaryotic_Species_Mixtures\/1562330",
      "display_url" : "figshare.com\/articles\/De_no\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "649912402226618368",
  "text" : "On Sunday the RECOMB Comparative Genomics will start. Here\u2019s my poster contribution: http:\/\/t.co\/gGJFwSXiDs",
  "id" : 649912402226618368,
  "created_at" : "2015-10-02 11:42:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "649903194231934976",
  "text" : "\u00ABHow did you find that out so quickly?!\u00BB \u2013 \u00ABBlack magic. Actually, I just picked up the phone and gave that guy a call.\u00BB",
  "id" : 649903194231934976,
  "created_at" : "2015-10-02 11:06:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MozFest",
      "indices" : [ 7, 15 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "649864171870375936",
  "text" : "\u2708\uFE0F for #MozFest \u2714\uFE0F",
  "id" : 649864171870375936,
  "created_at" : "2015-10-02 08:31:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 44 ],
      "url" : "https:\/\/t.co\/1eIuQKDZao",
      "expanded_url" : "https:\/\/www.youtube.com\/watch\/?v=UUyJoojCLnc",
      "display_url" : "youtube.com\/watch\/?v=UUyJo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "649847729225617408",
  "text" : "the boxer or the bag https:\/\/t.co\/1eIuQKDZao",
  "id" : 649847729225617408,
  "created_at" : "2015-10-02 07:25:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Google Travel",
      "screen_name" : "GoogleTravel",
      "indices" : [ 0, 13 ],
      "id_str" : "44886859",
      "id" : 44886859
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "649720274082902016",
  "geo" : { },
  "id_str" : "649846062065262592",
  "in_reply_to_user_id" : 44886859,
  "text" : "@GoogleTravel thanks a lot. Also good to know that people are looking out for feedback! :)",
  "id" : 649846062065262592,
  "in_reply_to_status_id" : 649720274082902016,
  "created_at" : "2015-10-02 07:19:09 +0000",
  "in_reply_to_screen_name" : "GoogleTravel",
  "in_reply_to_user_id_str" : "44886859",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Google Travel",
      "screen_name" : "GoogleTravel",
      "indices" : [ 0, 13 ],
      "id_str" : "44886859",
      "id" : 44886859
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "649660934059859969",
  "geo" : { },
  "id_str" : "649663285910994944",
  "in_reply_to_user_id" : 44886859,
  "text" : "@GoogleTravel yes, just today I noticed they are now on the web too. Makes more sense today as I got used to it. :-)",
  "id" : 649663285910994944,
  "in_reply_to_status_id" : 649660934059859969,
  "created_at" : "2015-10-01 19:12:52 +0000",
  "in_reply_to_screen_name" : "GoogleTravel",
  "in_reply_to_user_id_str" : "44886859",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Edmunds",
      "screen_name" : "SCEdmunds",
      "indices" : [ 3, 13 ],
      "id_str" : "176024190",
      "id" : 176024190
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ICG10",
      "indices" : [ 49, 55 ]
    } ],
    "urls" : [ {
      "indices" : [ 56, 79 ],
      "url" : "https:\/\/t.co\/a6I3yR9rfu",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/649610314045067264",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "649615299336081409",
  "text" : "RT @SCEdmunds: Watch this (nanopigs in) space... #ICG10 https:\/\/t.co\/a6I3yR9rfu",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ICG10",
        "indices" : [ 34, 40 ]
      } ],
      "urls" : [ {
        "indices" : [ 41, 64 ],
        "url" : "https:\/\/t.co\/a6I3yR9rfu",
        "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/649610314045067264",
        "display_url" : "twitter.com\/gedankenstueck\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "649610838203068416",
    "text" : "Watch this (nanopigs in) space... #ICG10 https:\/\/t.co\/a6I3yR9rfu",
    "id" : 649610838203068416,
    "created_at" : "2015-10-01 15:44:27 +0000",
    "user" : {
      "name" : "Scott Edmunds",
      "screen_name" : "SCEdmunds",
      "protected" : false,
      "id_str" : "176024190",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1098248807\/chess_normal.JPG",
      "id" : 176024190,
      "verified" : false
    }
  },
  "id" : 649615299336081409,
  "created_at" : "2015-10-01 16:02:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Edmunds",
      "screen_name" : "SCEdmunds",
      "indices" : [ 0, 10 ],
      "id_str" : "176024190",
      "id" : 176024190
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "649604019497926657",
  "geo" : { },
  "id_str" : "649610314045067264",
  "in_reply_to_user_id" : 176024190,
  "text" : "@SCEdmunds announcement of nanopigs which fit in the swag bag?",
  "id" : 649610314045067264,
  "in_reply_to_status_id" : 649604019497926657,
  "created_at" : "2015-10-01 15:42:22 +0000",
  "in_reply_to_screen_name" : "SCEdmunds",
  "in_reply_to_user_id_str" : "176024190",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Edmunds",
      "screen_name" : "SCEdmunds",
      "indices" : [ 0, 10 ],
      "id_str" : "176024190",
      "id" : 176024190
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ICG10",
      "indices" : [ 57, 63 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "649588486891261952",
  "geo" : { },
  "id_str" : "649593329261412352",
  "in_reply_to_user_id" : 176024190,
  "text" : "@SCEdmunds is there any chance I can bring one home from #ICG10?",
  "id" : 649593329261412352,
  "in_reply_to_status_id" : 649588486891261952,
  "created_at" : "2015-10-01 14:34:53 +0000",
  "in_reply_to_screen_name" : "SCEdmunds",
  "in_reply_to_user_id_str" : "176024190",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MakerBay",
      "screen_name" : "MakerBay",
      "indices" : [ 89, 98 ],
      "id_str" : "2917700821",
      "id" : 2917700821
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/rudnCvGDFB",
      "expanded_url" : "https:\/\/www.eventbrite.hk\/e\/genome-hackathon-makerbay-tickets-18836695062",
      "display_url" : "eventbrite.hk\/e\/genome-hacka\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "649580765303455744",
  "text" : "If you happen to be in Hong Kong on 26th of October: Join me for the Genome Hackathon at @MakerBay. https:\/\/t.co\/rudnCvGDFB",
  "id" : 649580765303455744,
  "created_at" : "2015-10-01 13:44:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "the Winnower",
      "screen_name" : "theWinnower",
      "indices" : [ 47, 59 ],
      "id_str" : "748018813",
      "id" : 748018813
    }, {
      "name" : "R\u24EAss Mounce",
      "screen_name" : "rmounce",
      "indices" : [ 71, 79 ],
      "id_str" : "222765418",
      "id" : 222765418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/jLF3gMCEu0",
      "expanded_url" : "https:\/\/thewinnower.com\/papers\/2368-you-don-t-get-to-2000-open-data-sets-without-making-a-few-friends-or-how-i-got-to-be-called-the-mark-zuckerberg-of-open-source-genetics#review_135",
      "display_url" : "thewinnower.com\/papers\/2368-yo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "649572045223776256",
  "text" : "Very nice: my first public post-pub. review on @theWinnower comes from @rmounce https:\/\/t.co\/jLF3gMCEu0",
  "id" : 649572045223776256,
  "created_at" : "2015-10-01 13:10:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Frayling",
      "screen_name" : "timfrayling",
      "indices" : [ 3, 15 ],
      "id_str" : "176089416",
      "id" : 176089416
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "649570477971755008",
  "text" : "RT @timfrayling: GWAS sceptics! Latest menopause effort is lovely example of how large GWAS (70,000 women) enlightens human biology: http:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/SOdKL2iZ7S",
        "expanded_url" : "http:\/\/bit.ly\/1iFFt1c",
        "display_url" : "bit.ly\/1iFFt1c"
      } ]
    },
    "geo" : { },
    "id_str" : "649566710945742848",
    "text" : "GWAS sceptics! Latest menopause effort is lovely example of how large GWAS (70,000 women) enlightens human biology: http:\/\/t.co\/SOdKL2iZ7S",
    "id" : 649566710945742848,
    "created_at" : "2015-10-01 12:49:06 +0000",
    "user" : {
      "name" : "Tim Frayling",
      "screen_name" : "timfrayling",
      "protected" : false,
      "id_str" : "176089416",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/882654956460879883\/EfQbZLST_normal.jpg",
      "id" : 176089416,
      "verified" : false
    }
  },
  "id" : 649570477971755008,
  "created_at" : "2015-10-01 13:04:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SENCKENBERG",
      "screen_name" : "Senckenberg",
      "indices" : [ 0, 12 ],
      "id_str" : "85120200",
      "id" : 85120200
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "649561956903464964",
  "geo" : { },
  "id_str" : "649562083412066304",
  "in_reply_to_user_id" : 85120200,
  "text" : "@Senckenberg super, danke!",
  "id" : 649562083412066304,
  "in_reply_to_status_id" : 649561956903464964,
  "created_at" : "2015-10-01 12:30:43 +0000",
  "in_reply_to_screen_name" : "Senckenberg",
  "in_reply_to_user_id_str" : "85120200",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/9QwEmg2OSN",
      "expanded_url" : "http:\/\/whatshouldwecallgradschool.tumblr.com\/post\/130219857969\/when-i-hang-out-with-non-science-people",
      "display_url" : "whatshouldwecallgradschool.tumblr.com\/post\/130219857\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "649561322544345088",
  "text" : "what is this \u2018hanging out\u2019 I hear non-science people talk about? http:\/\/t.co\/9QwEmg2OSN",
  "id" : 649561322544345088,
  "created_at" : "2015-10-01 12:27:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "William Colgan",
      "screen_name" : "GlacierBytes",
      "indices" : [ 3, 16 ],
      "id_str" : "2835899107",
      "id" : 2835899107
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "caldera",
      "indices" : [ 26, 34 ]
    }, {
      "text" : "flood",
      "indices" : [ 52, 58 ]
    }, {
      "text" : "Vatnaj\u00F6kull",
      "indices" : [ 78, 90 ]
    } ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/vXo9h6DKKp",
      "expanded_url" : "http:\/\/tinyurl.com\/q58hq3k",
      "display_url" : "tinyurl.com\/q58hq3k"
    } ]
  },
  "geo" : { },
  "id_str" : "649547869297491968",
  "text" : "RT @GlacierBytes: Seems a #caldera-related outburst #flood is now underway at #Vatnaj\u00F6kull, Iceland:\nhttp:\/\/t.co\/vXo9h6DKKp http:\/\/t.co\/JMr\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/GlacierBytes\/status\/649210234318270468\/photo\/1",
        "indices" : [ 106, 128 ],
        "url" : "http:\/\/t.co\/JMrgh63fgE",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CQJ1RJrWcAEALAl.jpg",
        "id_str" : "649210233810743297",
        "id" : 649210233810743297,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQJ1RJrWcAEALAl.jpg",
        "sizes" : [ {
          "h" : 387,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 467,
          "resize" : "fit",
          "w" : 820
        }, {
          "h" : 467,
          "resize" : "fit",
          "w" : 820
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 467,
          "resize" : "fit",
          "w" : 820
        } ],
        "display_url" : "pic.twitter.com\/JMrgh63fgE"
      } ],
      "hashtags" : [ {
        "text" : "caldera",
        "indices" : [ 8, 16 ]
      }, {
        "text" : "flood",
        "indices" : [ 34, 40 ]
      }, {
        "text" : "Vatnaj\u00F6kull",
        "indices" : [ 60, 72 ]
      } ],
      "urls" : [ {
        "indices" : [ 83, 105 ],
        "url" : "http:\/\/t.co\/vXo9h6DKKp",
        "expanded_url" : "http:\/\/tinyurl.com\/q58hq3k",
        "display_url" : "tinyurl.com\/q58hq3k"
      } ]
    },
    "geo" : { },
    "id_str" : "649210234318270468",
    "text" : "Seems a #caldera-related outburst #flood is now underway at #Vatnaj\u00F6kull, Iceland:\nhttp:\/\/t.co\/vXo9h6DKKp http:\/\/t.co\/JMrgh63fgE",
    "id" : 649210234318270468,
    "created_at" : "2015-09-30 13:12:36 +0000",
    "user" : {
      "name" : "William Colgan",
      "screen_name" : "GlacierBytes",
      "protected" : false,
      "id_str" : "2835899107",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/777661271676030976\/lwc5ILLF_normal.jpg",
      "id" : 2835899107,
      "verified" : false
    }
  },
  "id" : 649547869297491968,
  "created_at" : "2015-10-01 11:34:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SENCKENBERG",
      "screen_name" : "Senckenberg",
      "indices" : [ 0, 12 ],
      "id_str" : "85120200",
      "id" : 85120200
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "649546364104392705",
  "in_reply_to_user_id" : 85120200,
  "text" : "@Senckenberg Habt ihr das \u201Cworld of biodiversity\u201D-Logo eigentlich irgendwo als Vektor-Grafik zum Download?",
  "id" : 649546364104392705,
  "created_at" : "2015-10-01 11:28:15 +0000",
  "in_reply_to_screen_name" : "Senckenberg",
  "in_reply_to_user_id_str" : "85120200",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 35 ],
      "url" : "https:\/\/t.co\/YZsBtBBcye",
      "expanded_url" : "https:\/\/instagram.com\/p\/8SqKPJBwt_\/",
      "display_url" : "instagram.com\/p\/8SqKPJBwt_\/"
    } ]
  },
  "geo" : { },
  "id_str" : "649530548914941953",
  "text" : "Synchronous https:\/\/t.co\/YZsBtBBcye",
  "id" : 649530548914941953,
  "created_at" : "2015-10-01 10:25:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "649516686236712960",
  "geo" : { },
  "id_str" : "649516918584541184",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer that\u2019s the best thing for me. I enjoy cold climates. I\u2019m already melting just thinking of traveling to Israel in ~2 weeks. :D",
  "id" : 649516918584541184,
  "in_reply_to_status_id" : 649516686236712960,
  "created_at" : "2015-10-01 09:31:15 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 3, 16 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/aJgoQe3ize",
      "expanded_url" : "http:\/\/blog.pacificbiosciences.com\/2015\/09\/introducing-sequel-system-scalable.html",
      "display_url" : "blog.pacificbiosciences.com\/2015\/09\/introd\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "649503391530528769",
  "text" : "RT @PhilippBayer: New PacBio machine - http:\/\/t.co\/aJgoQe3ize 7x more reads, 1\/3 size and weight of RSII",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 21, 43 ],
        "url" : "http:\/\/t.co\/aJgoQe3ize",
        "expanded_url" : "http:\/\/blog.pacificbiosciences.com\/2015\/09\/introducing-sequel-system-scalable.html",
        "display_url" : "blog.pacificbiosciences.com\/2015\/09\/introd\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "649369605782147074",
    "text" : "New PacBio machine - http:\/\/t.co\/aJgoQe3ize 7x more reads, 1\/3 size and weight of RSII",
    "id" : 649369605782147074,
    "created_at" : "2015-09-30 23:45:53 +0000",
    "user" : {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "protected" : false,
      "id_str" : "121777206",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2013711027\/IMG_1088_normal.png",
      "id" : 121777206,
      "verified" : false
    }
  },
  "id" : 649503391530528769,
  "created_at" : "2015-10-01 08:37:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 45 ],
      "url" : "https:\/\/t.co\/BJGecABa02",
      "expanded_url" : "https:\/\/www.goodreads.com\/book\/show\/15796700-americanah",
      "display_url" : "goodreads.com\/book\/show\/1579\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "649499322648817668",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17239058983468, 8.627536864115774 ]
  },
  "id_str" : "649501540408029185",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot you might like https:\/\/t.co\/BJGecABa02",
  "id" : 649501540408029185,
  "in_reply_to_status_id" : 649499322648817668,
  "created_at" : "2015-10-01 08:30:09 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "649497682998722560",
  "geo" : { },
  "id_str" : "649498467266654209",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer you should, can be really nice!",
  "id" : 649498467266654209,
  "in_reply_to_status_id" : 649497682998722560,
  "created_at" : "2015-10-01 08:17:56 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "649496775808540673",
  "geo" : { },
  "id_str" : "649497009544667137",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer SMBE16 will be at Gold Coast anyway. :3",
  "id" : 649497009544667137,
  "in_reply_to_status_id" : 649496775808540673,
  "created_at" : "2015-10-01 08:12:08 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "649495693107720192",
  "geo" : { },
  "id_str" : "649495772531150848",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer I really hope I can manage to visit next year :D",
  "id" : 649495772531150848,
  "in_reply_to_status_id" : 649495693107720192,
  "created_at" : "2015-10-01 08:07:13 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "649493652507484161",
  "geo" : { },
  "id_str" : "649495569686241280",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer I miss dissecting stuff with you :3",
  "id" : 649495569686241280,
  "in_reply_to_status_id" : 649493652507484161,
  "created_at" : "2015-10-01 08:06:25 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "649384403857092608",
  "geo" : { },
  "id_str" : "649489976024018944",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer all I\u2019m seeing on my way to work are dead rats. I envy you a tiny bit!",
  "id" : 649489976024018944,
  "in_reply_to_status_id" : 649384403857092608,
  "created_at" : "2015-10-01 07:44:11 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Google Travel",
      "screen_name" : "GoogleTravel",
      "indices" : [ 0, 13 ],
      "id_str" : "44886859",
      "id" : 44886859
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "649395846052626432",
  "geo" : { },
  "id_str" : "649482865030336512",
  "in_reply_to_user_id" : 44886859,
  "text" : "@GoogleTravel for first time users (aka me) all the little bubbles showing flights on that day are confusing. ;-)",
  "id" : 649482865030336512,
  "in_reply_to_status_id" : 649395846052626432,
  "created_at" : "2015-10-01 07:15:56 +0000",
  "in_reply_to_screen_name" : "GoogleTravel",
  "in_reply_to_user_id_str" : "44886859",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
} ]