Grailbird.data.tweets_2014_03 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095843015, 8.282931667 ]
  },
  "id_str" : "450722259372867584",
  "text" : "Up fronting conference fees to wait for uncertain travel reimbursements, AKA \u2018I don\u2019t need food. I wanted to loose some more weight anyway.\u2018",
  "id" : 450722259372867584,
  "created_at" : "2014-03-31 19:52:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 57 ],
      "url" : "http:\/\/t.co\/gqdFe4fCGZ",
      "expanded_url" : "http:\/\/massgenomics.org\/2014\/03\/gwas-sequencing-realities.html",
      "display_url" : "massgenomics.org\/2014\/03\/gwas-s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "450641796490862592",
  "text" : "8 Realities of the Sequencing GWAS http:\/\/t.co\/gqdFe4fCGZ",
  "id" : 450641796490862592,
  "created_at" : "2014-03-31 14:32:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "450639608154685440",
  "geo" : { },
  "id_str" : "450639983612010496",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot Upbeat, downbeat, alpacabeat. There's probably some indie band out there which already labels themselves that way.",
  "id" : 450639983612010496,
  "in_reply_to_status_id" : 450639608154685440,
  "created_at" : "2014-03-31 14:25:19 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "450638537986420736",
  "text" : "Close, Autocorrect. But I'm pretty sure the IUPAC deals with 'ambiguous alphabets', not 'ambiguous alpaca beats'\u2026",
  "id" : 450638537986420736,
  "created_at" : "2014-03-31 14:19:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1771469276, 8.6244187252 ]
  },
  "id_str" : "450625893229400065",
  "text" : "\u00ABWenn du dich mit dem Kaktus einl\u00E4sst wird er nicht nur deine Gef\u00FChle verletzen.\u00BB",
  "id" : 450625893229400065,
  "created_at" : "2014-03-31 13:29:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723564273, 8.6275927061 ]
  },
  "id_str" : "450566486235836416",
  "text" : "You shouldn\u2019t start jobs before the first coffee: 1000x speed gain just by using the right node\u2026",
  "id" : 450566486235836416,
  "created_at" : "2014-03-31 09:33:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "herr_schrat",
      "screen_name" : "herr_schrat",
      "indices" : [ 0, 12 ],
      "id_str" : "16066591",
      "id" : 16066591
    }, {
      "name" : "BenYaminBoardCutter",
      "screen_name" : "BenYaminBC",
      "indices" : [ 13, 24 ],
      "id_str" : "2301772150",
      "id" : 2301772150
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "450547595400970240",
  "geo" : { },
  "id_str" : "450547728771473408",
  "in_reply_to_user_id" : 16066591,
  "text" : "@herr_schrat @BenYaminBC Wie schade! Aber sch\u00F6n das du es schaffst :)",
  "id" : 450547728771473408,
  "in_reply_to_status_id" : 450547595400970240,
  "created_at" : "2014-03-31 08:18:43 +0000",
  "in_reply_to_screen_name" : "herr_schrat",
  "in_reply_to_user_id_str" : "16066591",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 33 ],
      "url" : "http:\/\/t.co\/TdZ2McpkJX",
      "expanded_url" : "http:\/\/thisisnthappiness.com\/post\/81252552295\/sneeze-the-day",
      "display_url" : "thisisnthappiness.com\/post\/812525522\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.010269, 8.426254 ]
  },
  "id_str" : "450518329565151232",
  "text" : "Carpe diem http:\/\/t.co\/TdZ2McpkJX",
  "id" : 450518329565151232,
  "created_at" : "2014-03-31 06:21:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "450417563705421824",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009672544, 8.2829751726 ]
  },
  "id_str" : "450422277256269824",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer well, as long as that does not become true for corpse runs.",
  "id" : 450422277256269824,
  "in_reply_to_status_id" : 450417563705421824,
  "created_at" : "2014-03-31 00:00:14 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "450416825117843456",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096313044, 8.2830354022 ]
  },
  "id_str" : "450417067020525568",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer i guess by sharding it will end up with more serious instances as well (plus they seem to have game mechanics ;))",
  "id" : 450417067020525568,
  "in_reply_to_status_id" : 450416825117843456,
  "created_at" : "2014-03-30 23:39:31 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "450416141781848064",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096313044, 8.2830354022 ]
  },
  "id_str" : "450416530451603456",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer I never tried SL tbh, always viewed it as less game- and more cybersex-oriented.",
  "id" : 450416530451603456,
  "in_reply_to_status_id" : 450416141781848064,
  "created_at" : "2014-03-30 23:37:23 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 35 ],
      "url" : "http:\/\/t.co\/cmZPU5i6vB",
      "expanded_url" : "http:\/\/instagram.com\/p\/mLxPdaBwjc\/",
      "display_url" : "instagram.com\/p\/mLxPdaBwjc\/"
    } ]
  },
  "geo" : { },
  "id_str" : "450402573770850304",
  "text" : "Firebug porn http:\/\/t.co\/cmZPU5i6vB",
  "id" : 450402573770850304,
  "created_at" : "2014-03-30 22:41:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 68 ],
      "url" : "http:\/\/t.co\/bd3RUZVdyM",
      "expanded_url" : "http:\/\/www.newyorker.com\/online\/blogs\/elements\/2014\/03\/the-electronic-holy-war.html",
      "display_url" : "newyorker.com\/online\/blogs\/e\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096313044, 8.2830354022 ]
  },
  "id_str" : "450392073142042624",
  "text" : "On using Monte-Carlo methods for Go computers http:\/\/t.co\/bd3RUZVdyM",
  "id" : 450392073142042624,
  "created_at" : "2014-03-30 22:00:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 10, 16 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "450379277989842944",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009647886, 8.283001052 ]
  },
  "id_str" : "450379571977027584",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC @Lobot Well, so far that were the only ones that made me miss the stop. But with n that small I\u2019d rather not generalize.",
  "id" : 450379571977027584,
  "in_reply_to_status_id" : 450379277989842944,
  "created_at" : "2014-03-30 21:10:32 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 10, 16 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "450376132551245824",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009647886, 8.283001052 ]
  },
  "id_str" : "450376909269262336",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC @Lobot at least partially. Though I made it through ~1\/3rds of Tortengr\u00E4ber sitting at the Rhine today.",
  "id" : 450376909269262336,
  "in_reply_to_status_id" : 450376132551245824,
  "created_at" : "2014-03-30 20:59:57 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 10, 16 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "450374884599037952",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096496307, 8.283044662 ]
  },
  "id_str" : "450375189122273280",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC @Lobot this is why I made it through 2\/3 of the books you brought at home. :)",
  "id" : 450375189122273280,
  "in_reply_to_status_id" : 450374884599037952,
  "created_at" : "2014-03-30 20:53:07 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 54 ],
      "url" : "http:\/\/t.co\/25QtZhKIMA",
      "expanded_url" : "http:\/\/aeon.co\/magazine\/being-human\/olivia-laing-me-lonely-in-manhattan\/",
      "display_url" : "aeon.co\/magazine\/being\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009647886, 8.283001052 ]
  },
  "id_str" : "450331403147034625",
  "text" : "On loneliness: Me, myself and I http:\/\/t.co\/25QtZhKIMA",
  "id" : 450331403147034625,
  "created_at" : "2014-03-30 17:59:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009647886, 8.283001052 ]
  },
  "id_str" : "450258419992526848",
  "text" : "Rot gef\u00E4rbte Haare haben ihre Vorteile: Sich den Kopf blutig sto\u00DFen f\u00E4llt gar nicht auf\u2026",
  "id" : 450258419992526848,
  "created_at" : "2014-03-30 13:09:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096871418, 8.283132908 ]
  },
  "id_str" : "450227648812556288",
  "text" : "\u00ABWenn du diese Stiefel tr\u00E4gst ist unser Gleichschritt noch besser.\u00BB \u2014 \u00ABJawohl! Das Crossdressing war ein Befehl!\u00BB",
  "id" : 450227648812556288,
  "created_at" : "2014-03-30 11:06:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Maarten den Braber",
      "screen_name" : "mdbraber",
      "indices" : [ 3, 12 ],
      "id_str" : "9938952",
      "id" : 9938952
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IAS14",
      "indices" : [ 85, 91 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/DNLKvpgmFa",
      "expanded_url" : "http:\/\/zite.to\/1mC49XN",
      "display_url" : "zite.to\/1mC49XN"
    } ]
  },
  "geo" : { },
  "id_str" : "450226838326226944",
  "text" : "RT @mdbraber: \u201CDesigning for a more forgiving \u2018Quantified Self\u2019\u201D \u2013 Miles Rochford at #IAS14 http:\/\/t.co\/DNLKvpgmFa",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "IAS14",
        "indices" : [ 71, 77 ]
      } ],
      "urls" : [ {
        "indices" : [ 78, 100 ],
        "url" : "http:\/\/t.co\/DNLKvpgmFa",
        "expanded_url" : "http:\/\/zite.to\/1mC49XN",
        "display_url" : "zite.to\/1mC49XN"
      } ]
    },
    "geo" : { },
    "id_str" : "450168134771949568",
    "text" : "\u201CDesigning for a more forgiving \u2018Quantified Self\u2019\u201D \u2013 Miles Rochford at #IAS14 http:\/\/t.co\/DNLKvpgmFa",
    "id" : 450168134771949568,
    "created_at" : "2014-03-30 07:10:21 +0000",
    "user" : {
      "name" : "Maarten den Braber",
      "screen_name" : "mdbraber",
      "protected" : false,
      "id_str" : "9938952",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/831100581322293249\/_TZFF-1S_normal.jpg",
      "id" : 9938952,
      "verified" : false
    }
  },
  "id" : 450226838326226944,
  "created_at" : "2014-03-30 11:03:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 127, 140 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/TF1U56Zuz5",
      "expanded_url" : "http:\/\/www.polygon.com\/2014\/3\/29\/5559608\/shards-citadel-studios",
      "display_url" : "polygon.com\/2014\/3\/29\/5559\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096435843, 8.28300538 ]
  },
  "id_str" : "450075336911630336",
  "text" : "Sounds pretty cool. Being able to choose a shard was what ultimately made Ultima Online fun for me. http:\/\/t.co\/TF1U56Zuz5 \/cc @PhilippBayer",
  "id" : 450075336911630336,
  "created_at" : "2014-03-30 01:01:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1029545869, 8.5428597101 ]
  },
  "id_str" : "450042153184792576",
  "text" : "\u00ABKannst du sie nicht zu deiner Verlobten machen? Dann ist die Levenshtein-Distanz zwischen Name und Deskriptor minimiert.\u00BB",
  "id" : 450042153184792576,
  "created_at" : "2014-03-29 22:49:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0053544165, 8.3466271948 ]
  },
  "id_str" : "449965082681036800",
  "text" : "\u00ABIch leide schon an seniler Bettflucht.\u00BB \u2014 \u00ABDas trifft sich hervorragend. Lass dir mal zeigen wie die Kaffeemaschine funktioniert.\u00BB",
  "id" : 449965082681036800,
  "created_at" : "2014-03-29 17:43:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 56 ],
      "url" : "http:\/\/t.co\/kL5PLBzMb6",
      "expanded_url" : "http:\/\/www.smbc-comics.com\/index.php?db=comics&id=3310",
      "display_url" : "smbc-comics.com\/index.php?db=c\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009645872, 8.282978884 ]
  },
  "id_str" : "449880201267527681",
  "text" : "the greatest romantic of all time http:\/\/t.co\/kL5PLBzMb6",
  "id" : 449880201267527681,
  "created_at" : "2014-03-29 12:06:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/hj5lHN9PuK",
      "expanded_url" : "http:\/\/nittygrittyscience.com\/2014\/03\/28\/manipulating-the-mouse-penis-bone-with-science\/",
      "display_url" : "nittygrittyscience.com\/2014\/03\/28\/man\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "449875155964395520",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009645872, 8.282978884 ]
  },
  "id_str" : "449875737051668480",
  "in_reply_to_user_id" : 14286491,
  "text" : "Last quote from this article about sexual selection in mice: \u00ABManipulating the mouse penis bone, with\u00A0science\u00BB http:\/\/t.co\/hj5lHN9PuK",
  "id" : 449875737051668480,
  "in_reply_to_status_id" : 449875155964395520,
  "created_at" : "2014-03-29 11:48:28 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009645872, 8.282978884 ]
  },
  "id_str" : "449875155964395520",
  "text" : "\u00ABThis was continued for 27 mouse generations, or a little less than\u00A0the length of 1 PhD.\u00BB",
  "id" : 449875155964395520,
  "created_at" : "2014-03-29 11:46:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 66 ],
      "url" : "http:\/\/t.co\/amJmexRCKB",
      "expanded_url" : "http:\/\/elfaproject.wordpress.com\/2014\/03\/28\/why-mixing-languages-isnt-so-bad-after-all\/",
      "display_url" : "elfaproject.wordpress.com\/2014\/03\/28\/why\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009645872, 8.282978884 ]
  },
  "id_str" : "449871871543373824",
  "text" : "why mixing languages isn\u2019t so bad after all http:\/\/t.co\/amJmexRCKB",
  "id" : 449871871543373824,
  "created_at" : "2014-03-29 11:33:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "killme",
      "indices" : [ 51, 58 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009645872, 8.282978884 ]
  },
  "id_str" : "449870020773163008",
  "text" : "Such a nice day to relabel unusable FASTA headers\u2026 #killme",
  "id" : 449870020773163008,
  "created_at" : "2014-03-29 11:25:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "whitney erin boesel",
      "screen_name" : "weboesel",
      "indices" : [ 0, 9 ],
      "id_str" : "264101497",
      "id" : 264101497
    }, {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 10, 19 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "449645088596303872",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009645872, 8.282978884 ]
  },
  "id_str" : "449868544390725632",
  "in_reply_to_user_id" : 264101497,
  "text" : "@weboesel @eramirez We try to encourage people to discuss with next of kin before sharing the data. But hard ethical questions re: ownership",
  "id" : 449868544390725632,
  "in_reply_to_status_id" : 449645088596303872,
  "created_at" : "2014-03-29 11:19:53 +0000",
  "in_reply_to_screen_name" : "weboesel",
  "in_reply_to_user_id_str" : "264101497",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 10, 16 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "449764431590080512",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096770283, 8.2829088718 ]
  },
  "id_str" : "449818312818827264",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC @Lobot \u2018no one had a limb amputated and eaten or lost eye sight. It was a great date.\u2019",
  "id" : 449818312818827264,
  "in_reply_to_status_id" : 449764431590080512,
  "created_at" : "2014-03-29 08:00:17 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 10, 16 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "449755386120515584",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096216287, 8.2831946883 ]
  },
  "id_str" : "449817868784635904",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC @Lobot but how will I miss getting of the train then?",
  "id" : 449817868784635904,
  "in_reply_to_status_id" : 449755386120515584,
  "created_at" : "2014-03-29 07:58:31 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096454262, 8.2829943258 ]
  },
  "id_str" : "449713792000475137",
  "text" : "\u00ABAber wir haben uns gar nicht auf Twitter kennengelernt?!\u00BB \u2014 \u00ABUnd wir sind nicht mehr zusammen. Q.E.D.\u00BB",
  "id" : 449713792000475137,
  "created_at" : "2014-03-29 01:04:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.000268935, 8.2761100549 ]
  },
  "id_str" : "449652162088669184",
  "text" : "\u00ABDu bist ein Tier was das Wissen des Partners aussaugt &amp; ihn wegwirft wenn nur noch eine H\u00FClle da ist. Aber das ist nicht negativ gemeint.\u00BB",
  "id" : 449652162088669184,
  "created_at" : "2014-03-28 21:00:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "449547456473464833",
  "text" : "\u00ABIch bin ja froh das du es nicht falsch verstanden hast und dachtest du sollst so fahren wie ein Wal!\u00BB",
  "id" : 449547456473464833,
  "created_at" : "2014-03-28 14:04:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 7, 16 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "449338366208000001",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096419614, 8.2830068643 ]
  },
  "id_str" : "449338577680617472",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot @Senficon I call this ppt-karaoke for beginners",
  "id" : 449338577680617472,
  "in_reply_to_status_id" : 449338366208000001,
  "created_at" : "2014-03-28 00:13:59 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 43 ],
      "url" : "http:\/\/t.co\/HmebEi5Pz1",
      "expanded_url" : "http:\/\/boingboing.net\/2014\/03\/27\/time-lapse-fireflies.html",
      "display_url" : "boingboing.net\/2014\/03\/27\/tim\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096419614, 8.2830068643 ]
  },
  "id_str" : "449331383593607168",
  "text" : "Time-lapse\u00A0fireflies http:\/\/t.co\/HmebEi5Pz1",
  "id" : 449331383593607168,
  "created_at" : "2014-03-27 23:45:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096419614, 8.2830068643 ]
  },
  "id_str" : "449326942958125056",
  "text" : "\u00ABHallo, ich bin zum ersten Mal hier und tracke Schlaf, Schritte, Gewicht, Kaffeekonsum und wie gl\u00FCcklich meine Freundinnen mich machen.\u00BB",
  "id" : 449326942958125056,
  "created_at" : "2014-03-27 23:27:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "QS Meetup Cologne",
      "screen_name" : "QS_Cologne",
      "indices" : [ 46, 57 ],
      "id_str" : "1400648731",
      "id" : 1400648731
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.8976839297, 7.1528859157 ]
  },
  "id_str" : "449298070338273281",
  "text" : "Thanks for the invite and the nice discussion @QS_Cologne. I had a great evening!",
  "id" : 449298070338273281,
  "created_at" : "2014-03-27 21:33:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u03B8ourkni\u02D0r\u0325",
      "screen_name" : "thorgnyr",
      "indices" : [ 0, 9 ],
      "id_str" : "38015980",
      "id" : 38015980
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 10, 19 ],
      "id_str" : "14861745",
      "id" : 14861745
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 20, 26 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "449231909122752512",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.9484039465, 6.9450208481 ]
  },
  "id_str" : "449243014289162240",
  "in_reply_to_user_id" : 38015980,
  "text" : "@thorgnyr @Senficon @Lobot but we will have a drink to commemorate!",
  "id" : 449243014289162240,
  "in_reply_to_status_id" : 449231909122752512,
  "created_at" : "2014-03-27 17:54:15 +0000",
  "in_reply_to_screen_name" : "thorgnyr",
  "in_reply_to_user_id_str" : "38015980",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "449220337373151232",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.547007774, 7.5861858856 ]
  },
  "id_str" : "449220689183383552",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez ok, thanks for the recommendation :)",
  "id" : 449220689183383552,
  "in_reply_to_status_id" : 449220337373151232,
  "created_at" : "2014-03-27 16:25:33 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u03B8ourkni\u02D0r\u0325",
      "screen_name" : "thorgnyr",
      "indices" : [ 0, 9 ],
      "id_str" : "38015980",
      "id" : 38015980
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 10, 16 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "449220228984344576",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.5470310757, 7.5861969497 ]
  },
  "id_str" : "449220618798784512",
  "in_reply_to_user_id" : 38015980,
  "text" : "@thorgnyr @Lobot for me that will do. :)",
  "id" : 449220618798784512,
  "in_reply_to_status_id" : 449220228984344576,
  "created_at" : "2014-03-27 16:25:16 +0000",
  "in_reply_to_screen_name" : "thorgnyr",
  "in_reply_to_user_id_str" : "38015980",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "449214593034752001",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.5469993042, 7.586098518 ]
  },
  "id_str" : "449220047962386432",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez thanks. Anyone I should definitely talk to? :D",
  "id" : 449220047962386432,
  "in_reply_to_status_id" : 449214593034752001,
  "created_at" : "2014-03-27 16:23:00 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u03B8ourkni\u02D0r\u0325",
      "screen_name" : "thorgnyr",
      "indices" : [ 0, 9 ],
      "id_str" : "38015980",
      "id" : 38015980
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 10, 16 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "449202393709023232",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.5470403386, 7.5860649151 ]
  },
  "id_str" : "449219988688478208",
  "in_reply_to_user_id" : 38015980,
  "text" : "@thorgnyr @Lobot naked, in a hot spring?",
  "id" : 449219988688478208,
  "in_reply_to_status_id" : 449202393709023232,
  "created_at" : "2014-03-27 16:22:46 +0000",
  "in_reply_to_screen_name" : "thorgnyr",
  "in_reply_to_user_id_str" : "38015980",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    }, {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 118, 127 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "449203093000175616",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.5470300049, 7.5860733769 ]
  },
  "id_str" : "449219939900350464",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot a whale? But that reminds me, the intercoder reliability tests for the drive to the airport are still missing! @SuicideC",
  "id" : 449219939900350464,
  "in_reply_to_status_id" : 449203093000175616,
  "created_at" : "2014-03-27 16:22:34 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "449201783693664257",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1743721141, 8.6412952651 ]
  },
  "id_str" : "449202259948503040",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot if I was there were buckets of icecream, not cones!",
  "id" : 449202259948503040,
  "in_reply_to_status_id" : 449201783693664257,
  "created_at" : "2014-03-27 15:12:19 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/EbvTk2yo5i",
      "expanded_url" : "http:\/\/instagram.com\/p\/mDOepHBwif\/",
      "display_url" : "instagram.com\/p\/mDOepHBwif\/"
    } ]
  },
  "geo" : { },
  "id_str" : "449200229414604800",
  "text" : "Off to Cologne for the Quantified Self meetup to talk about openSNP. In perfect dress. http:\/\/t.co\/EbvTk2yo5i",
  "id" : 449200229414604800,
  "created_at" : "2014-03-27 15:04:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 94, 100 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "449186739006226432",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723204583, 8.627627155 ]
  },
  "id_str" : "449187399575564288",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon Sicheres auftreten bei v\u00F6lliger Ahnungslosigkeit ist auch meine Kernkompetenz. Frag @Lobot nach Walpenissen oder Pair Bonding. :P",
  "id" : 449187399575564288,
  "in_reply_to_status_id" : 449186739006226432,
  "created_at" : "2014-03-27 14:13:16 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "449186467693477888",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723204583, 8.627627155 ]
  },
  "id_str" : "449186579748499457",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon that makes us two!",
  "id" : 449186579748499457,
  "in_reply_to_status_id" : 449186467693477888,
  "created_at" : "2014-03-27 14:10:00 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "449185880704811008",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723204583, 8.627627155 ]
  },
  "id_str" : "449186009805488128",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon surprise: _Wir_ erz\u00E4hlen was \u00FCber openSNP :P",
  "id" : 449186009805488128,
  "in_reply_to_status_id" : 449185880704811008,
  "created_at" : "2014-03-27 14:07:44 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723204583, 8.627627155 ]
  },
  "id_str" : "449185848840699904",
  "text" : "Ok, this is getting ridiculous: is there any way to automate grabbing genomic, cDNA &amp; protein sequences for a set of species from JGI?",
  "id" : 449185848840699904,
  "created_at" : "2014-03-27 14:07:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    }, {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 10, 19 ],
      "id_str" : "14245811",
      "id" : 14245811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "449184404272087040",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723204583, 8.627627155 ]
  },
  "id_str" : "449185142465368064",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon @wilbanks just in case 6 reviewers and 4 rounds of revisions weren\u2019t enough?",
  "id" : 449185142465368064,
  "in_reply_to_status_id" : 449184404272087040,
  "created_at" : "2014-03-27 14:04:18 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 0, 9 ],
      "id_str" : "14245811",
      "id" : 14245811
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 37, 46 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "449181174188236800",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723204583, 8.627627155 ]
  },
  "id_str" : "449181454061539328",
  "in_reply_to_user_id" : 14245811,
  "text" : "@wilbanks you definitely should keep @Senficon in mind. She\u2019s running for European Parliament &amp; thus will shape EU privacy laws soon. :)",
  "id" : 449181454061539328,
  "in_reply_to_status_id" : 449181174188236800,
  "created_at" : "2014-03-27 13:49:38 +0000",
  "in_reply_to_screen_name" : "wilbanks",
  "in_reply_to_user_id_str" : "14245811",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 0, 9 ],
      "id_str" : "14245811",
      "id" : 14245811
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 50, 63 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 64, 76 ],
      "id_str" : "52747896",
      "id" : 52747896
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 81, 90 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "449179179926712320",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723204583, 8.627627155 ]
  },
  "id_str" : "449179619267448832",
  "in_reply_to_user_id" : 14245811,
  "text" : "@wilbanks thanks! The team is on Twitter as well: @PhilippBayer @helgerausch and @Senficon :)",
  "id" : 449179619267448832,
  "in_reply_to_status_id" : 449179179926712320,
  "created_at" : "2014-03-27 13:42:21 +0000",
  "in_reply_to_screen_name" : "wilbanks",
  "in_reply_to_user_id_str" : "14245811",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723397261, 8.627589901 ]
  },
  "id_str" : "449164556435456000",
  "text" : "\u00ABPlease keep in mind that downloading tape files (\uD83D\uDCFC) can take a few minutes.\u00BB Love how JGI feels it needs to give a pictogram to clarify.",
  "id" : 449164556435456000,
  "created_at" : "2014-03-27 12:42:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723204583, 8.627627155 ]
  },
  "id_str" : "449161793639034880",
  "text" : "\u00ABTop hat, Bow tie and cufflinks? She will look like a bioinformatics software package!\u00BB",
  "id" : 449161793639034880,
  "created_at" : "2014-03-27 12:31:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/MHjEcwsjzj",
      "expanded_url" : "http:\/\/www.wired.com\/wiredscience\/2014\/03\/prehistoric-spider-footprints\/",
      "display_url" : "wired.com\/wiredscience\/2\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723204583, 8.627627155 ]
  },
  "id_str" : "449156151507419136",
  "text" : "Fossil Detectives Close the Case on Prehistoric Spider Footprints http:\/\/t.co\/MHjEcwsjzj",
  "id" : 449156151507419136,
  "created_at" : "2014-03-27 12:09:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723204583, 8.627627155 ]
  },
  "id_str" : "449110133860478976",
  "text" : "Lucky me: apparently my go bag includes not only a toothbrush but also a wireless presenter and a mini display-to-VGA adapter.",
  "id" : 449110133860478976,
  "created_at" : "2014-03-27 09:06:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/s0VyVDpsfv",
      "expanded_url" : "http:\/\/crushingreviewercomments.wordpress.com\/2014\/03\/26\/61\/",
      "display_url" : "crushingreviewercomments.wordpress.com\/2014\/03\/26\/61\/"
    } ]
  },
  "geo" : { },
  "id_str" : "449100375845769216",
  "text" : "\u00ABperhaps we could write a paper about the data we have, and you could write one about the data you wish we had.\u00BB http:\/\/t.co\/s0VyVDpsfv",
  "id" : 449100375845769216,
  "created_at" : "2014-03-27 08:27:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "448978831429234688",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096864657, 8.2830339328 ]
  },
  "id_str" : "448979123793588227",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer not doing it for the money, but to have an impact on the minds of young readers, vaccinating them against EP!",
  "id" : 448979123793588227,
  "in_reply_to_status_id" : 448978831429234688,
  "created_at" : "2014-03-27 00:25:39 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "448977630826487809",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095713325, 8.2831902523 ]
  },
  "id_str" : "448978239382622209",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer I would have gone with the Panda, but that\u2019s nice as well. We should go for it :D",
  "id" : 448978239382622209,
  "in_reply_to_status_id" : 448977630826487809,
  "created_at" : "2014-03-27 00:22:08 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "448976918876930048",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096828785, 8.283036611 ]
  },
  "id_str" : "448977255377940480",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer only the heroes of the story have read Gould\u2019s spandrels and rebel against the system? Would read that!",
  "id" : 448977255377940480,
  "in_reply_to_status_id" : 448976918876930048,
  "created_at" : "2014-03-27 00:18:13 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "448974007212060673",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096802135, 8.2830796111 ]
  },
  "id_str" : "448975013673463809",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer and years later the EP crowd will find an evolutionary adaptive \u2018explanation\u2019 :p",
  "id" : 448975013673463809,
  "in_reply_to_status_id" : 448974007212060673,
  "created_at" : "2014-03-27 00:09:19 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Neuroskeptic",
      "screen_name" : "Neuro_Skeptic",
      "indices" : [ 3, 17 ],
      "id_str" : "316327930",
      "id" : 316327930
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/rJ6Q6ECydL",
      "expanded_url" : "http:\/\/blogs.discovermagazine.com\/neuroskeptic\/2014\/03\/26\/ugly-ducklings-science\/",
      "display_url" : "blogs.discovermagazine.com\/neuroskeptic\/2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "448971621857255424",
  "text" : "RT @Neuro_Skeptic: New post: The Ugly Ducklings of Science http:\/\/t.co\/rJ6Q6ECydL On \"How Ugly Initial Results Metamorphosize Into Beautifu\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 40, 62 ],
        "url" : "http:\/\/t.co\/rJ6Q6ECydL",
        "expanded_url" : "http:\/\/blogs.discovermagazine.com\/neuroskeptic\/2014\/03\/26\/ugly-ducklings-science\/",
        "display_url" : "blogs.discovermagazine.com\/neuroskeptic\/2\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "448955751298781184",
    "text" : "New post: The Ugly Ducklings of Science http:\/\/t.co\/rJ6Q6ECydL On \"How Ugly Initial Results Metamorphosize Into Beautiful Articles\"",
    "id" : 448955751298781184,
    "created_at" : "2014-03-26 22:52:46 +0000",
    "user" : {
      "name" : "Neuroskeptic",
      "screen_name" : "Neuro_Skeptic",
      "protected" : false,
      "id_str" : "316327930",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/703637604181393409\/iCflIKVK_normal.jpg",
      "id" : 316327930,
      "verified" : false
    }
  },
  "id" : 448971621857255424,
  "created_at" : "2014-03-26 23:55:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "herr_schrat",
      "screen_name" : "herr_schrat",
      "indices" : [ 0, 12 ],
      "id_str" : "16066591",
      "id" : 16066591
    }, {
      "name" : "BenYaminBoardCutter",
      "screen_name" : "BenYaminBC",
      "indices" : [ 13, 24 ],
      "id_str" : "2301772150",
      "id" : 2301772150
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "448963749735849985",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096558693, 8.2830833479 ]
  },
  "id_str" : "448964017240158208",
  "in_reply_to_user_id" : 16066591,
  "text" : "@herr_schrat @BenYaminBC wow, das habe ich nie geschafft. Und ob sie mich m\u00F6gen wei\u00DF ich nicht, bin vermutlich \u2018der mit der Gardinenstange\u2019?",
  "id" : 448964017240158208,
  "in_reply_to_status_id" : 448963749735849985,
  "created_at" : "2014-03-26 23:25:37 +0000",
  "in_reply_to_screen_name" : "herr_schrat",
  "in_reply_to_user_id_str" : "16066591",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "herr_schrat",
      "screen_name" : "herr_schrat",
      "indices" : [ 0, 12 ],
      "id_str" : "16066591",
      "id" : 16066591
    }, {
      "name" : "BenYaminBoardCutter",
      "screen_name" : "BenYaminBC",
      "indices" : [ 13, 24 ],
      "id_str" : "2301772150",
      "id" : 2301772150
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 25, 34 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "448962531961606144",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009629922, 8.2829800341 ]
  },
  "id_str" : "448962784068657152",
  "in_reply_to_user_id" : 16066591,
  "text" : "@herr_schrat @BenYaminBC @Senficon nein, nur die Serie. Endgame und nat\u00FCrlich der famose The Source blieben ihr erspart.",
  "id" : 448962784068657152,
  "in_reply_to_status_id" : 448962531961606144,
  "created_at" : "2014-03-26 23:20:43 +0000",
  "in_reply_to_screen_name" : "herr_schrat",
  "in_reply_to_user_id_str" : "16066591",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "herr_schrat",
      "screen_name" : "herr_schrat",
      "indices" : [ 0, 12 ],
      "id_str" : "16066591",
      "id" : 16066591
    }, {
      "name" : "BenYaminBoardCutter",
      "screen_name" : "BenYaminBC",
      "indices" : [ 13, 24 ],
      "id_str" : "2301772150",
      "id" : 2301772150
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 39, 48 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "448961918427230208",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096665801, 8.2829836121 ]
  },
  "id_str" : "448962158567886849",
  "in_reply_to_user_id" : 16066591,
  "text" : "@herr_schrat @BenYaminBC ja, auch wenn @Senficon tapfer alle 6 Staffeln Highlander durchgestanden hat. :p",
  "id" : 448962158567886849,
  "in_reply_to_status_id" : 448961918427230208,
  "created_at" : "2014-03-26 23:18:14 +0000",
  "in_reply_to_screen_name" : "herr_schrat",
  "in_reply_to_user_id_str" : "16066591",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "herr_schrat",
      "screen_name" : "herr_schrat",
      "indices" : [ 0, 12 ],
      "id_str" : "16066591",
      "id" : 16066591
    }, {
      "name" : "BenYaminBoardCutter",
      "screen_name" : "BenYaminBC",
      "indices" : [ 13, 24 ],
      "id_str" : "2301772150",
      "id" : 2301772150
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "448960635112792064",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096084644, 8.2829468418 ]
  },
  "id_str" : "448960971747635202",
  "in_reply_to_user_id" : 16066591,
  "text" : "@herr_schrat @BenYaminBC fair enough. Aber als ob ich das nicht schon zu Gen\u00FCge bereuen w\u00FCrd!",
  "id" : 448960971747635202,
  "in_reply_to_status_id" : 448960635112792064,
  "created_at" : "2014-03-26 23:13:31 +0000",
  "in_reply_to_screen_name" : "herr_schrat",
  "in_reply_to_user_id_str" : "16066591",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "herr_schrat",
      "screen_name" : "herr_schrat",
      "indices" : [ 0, 12 ],
      "id_str" : "16066591",
      "id" : 16066591
    }, {
      "name" : "BenYaminBoardCutter",
      "screen_name" : "BenYaminBC",
      "indices" : [ 13, 24 ],
      "id_str" : "2301772150",
      "id" : 2301772150
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "448959980029624320",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096180011, 8.282981343 ]
  },
  "id_str" : "448960332195962880",
  "in_reply_to_user_id" : 16066591,
  "text" : "@herr_schrat @BenYaminBC ah, und ich soll nun evaluieren ob ihr ein guter Match seid? ;)",
  "id" : 448960332195962880,
  "in_reply_to_status_id" : 448959980029624320,
  "created_at" : "2014-03-26 23:10:59 +0000",
  "in_reply_to_screen_name" : "herr_schrat",
  "in_reply_to_user_id_str" : "16066591",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "herr_schrat",
      "screen_name" : "herr_schrat",
      "indices" : [ 0, 12 ],
      "id_str" : "16066591",
      "id" : 16066591
    }, {
      "name" : "BenYaminBoardCutter",
      "screen_name" : "BenYaminBC",
      "indices" : [ 13, 24 ],
      "id_str" : "2301772150",
      "id" : 2301772150
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "448959445687885824",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096052327, 8.2829600449 ]
  },
  "id_str" : "448959652840366080",
  "in_reply_to_user_id" : 16066591,
  "text" : "@herr_schrat @BenYaminBC why sure. Ist das ein Ben den ich schon kenne? :p",
  "id" : 448959652840366080,
  "in_reply_to_status_id" : 448959445687885824,
  "created_at" : "2014-03-26 23:08:17 +0000",
  "in_reply_to_screen_name" : "herr_schrat",
  "in_reply_to_user_id_str" : "16066591",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/3jiO42XeLO",
      "expanded_url" : "http:\/\/www.slate.com\/blogs\/wild_things\/2014\/03\/25\/how_do_dogs_have_sex_copulatory_tie_baculum_humping_coital_tie_dog_knot.html",
      "display_url" : "slate.com\/blogs\/wild_thi\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096366425, 8.282995835 ]
  },
  "id_str" : "448956129172013057",
  "text" : "on dogs &amp; penis bones (including lots of YouTube links) http:\/\/t.co\/3jiO42XeLO",
  "id" : 448956129172013057,
  "created_at" : "2014-03-26 22:54:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Book Bat",
      "screen_name" : "book_bat",
      "indices" : [ 3, 12 ],
      "id_str" : "263376016",
      "id" : 263376016
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Elsevier",
      "indices" : [ 92, 101 ]
    }, {
      "text" : "ElsevierGate",
      "indices" : [ 126, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/HSeaLxJk1D",
      "expanded_url" : "http:\/\/www.aktuelles.uni-konstanz.de\/en\/presseinformationen\/2014\/28\/",
      "display_url" : "aktuelles.uni-konstanz.de\/en\/presseinfor\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "448955666045362176",
  "text" : "RT @book_bat: University of Konstanz cancels license negotiations with scientific publisher #Elsevier. http:\/\/t.co\/HSeaLxJk1D #ElsevierGate\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Elsevier",
        "indices" : [ 78, 87 ]
      }, {
        "text" : "ElsevierGate",
        "indices" : [ 112, 125 ]
      }, {
        "text" : "libraries",
        "indices" : [ 126, 136 ]
      } ],
      "urls" : [ {
        "indices" : [ 89, 111 ],
        "url" : "http:\/\/t.co\/HSeaLxJk1D",
        "expanded_url" : "http:\/\/www.aktuelles.uni-konstanz.de\/en\/presseinformationen\/2014\/28\/",
        "display_url" : "aktuelles.uni-konstanz.de\/en\/presseinfor\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "448921972685418496",
    "text" : "University of Konstanz cancels license negotiations with scientific publisher #Elsevier. http:\/\/t.co\/HSeaLxJk1D #ElsevierGate #libraries",
    "id" : 448921972685418496,
    "created_at" : "2014-03-26 20:38:33 +0000",
    "user" : {
      "name" : "Book Bat",
      "screen_name" : "book_bat",
      "protected" : false,
      "id_str" : "263376016",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1270223034\/bookbat_Kopie_normal.jpg",
      "id" : 263376016,
      "verified" : false
    }
  },
  "id" : 448955666045362176,
  "created_at" : "2014-03-26 22:52:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alon Keinan",
      "screen_name" : "AlonKeinan",
      "indices" : [ 3, 14 ],
      "id_str" : "330101315",
      "id" : 330101315
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CommentsWelcome",
      "indices" : [ 107, 123 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "448954289860653056",
  "text" : "RT @AlonKeinan: High burden of private mutations due to explosive human pop growth and purifying selection #CommentsWelcome http:\/\/t.co\/r1u\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CommentsWelcome",
        "indices" : [ 91, 107 ]
      } ],
      "urls" : [ {
        "indices" : [ 108, 130 ],
        "url" : "http:\/\/t.co\/r1ut7F0HVl",
        "expanded_url" : "http:\/\/arxiv.org\/abs\/1403.5615",
        "display_url" : "arxiv.org\/abs\/1403.5615"
      } ]
    },
    "geo" : { },
    "id_str" : "448901248985870336",
    "text" : "High burden of private mutations due to explosive human pop growth and purifying selection #CommentsWelcome http:\/\/t.co\/r1ut7F0HVl",
    "id" : 448901248985870336,
    "created_at" : "2014-03-26 19:16:12 +0000",
    "user" : {
      "name" : "Alon Keinan",
      "screen_name" : "AlonKeinan",
      "protected" : false,
      "id_str" : "330101315",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000411860504\/293bf4ed81569c5b3667982ec87b6984_normal.jpeg",
      "id" : 330101315,
      "verified" : false
    }
  },
  "id" : 448954289860653056,
  "created_at" : "2014-03-26 22:46:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/uIIVfyd4qi",
      "expanded_url" : "http:\/\/earthlingnature.wordpress.com\/2014\/03\/26\/the-lack-of-taxonomists-and-its-consequences-on-ecology\/",
      "display_url" : "earthlingnature.wordpress.com\/2014\/03\/26\/the\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096366425, 8.282995835 ]
  },
  "id_str" : "448953606776291328",
  "text" : "The lack of taxonomists and its consequences on\u00A0ecology http:\/\/t.co\/uIIVfyd4qi",
  "id" : 448953606776291328,
  "created_at" : "2014-03-26 22:44:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/27yZR6ZhBy",
      "expanded_url" : "http:\/\/kernelmag.dailydot.com\/features\/report\/9394\/how-a-middle-aged-economist-became-the-most-unlikely-porn-star-on-xvideos\/#",
      "display_url" : "kernelmag.dailydot.com\/features\/repor\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096366425, 8.282995835 ]
  },
  "id_str" : "448950126015696896",
  "text" : "TIL: If you call your lecture series \u2018Hardcore Economics\u2019 the recordings of said series might end on porn sites. http:\/\/t.co\/27yZR6ZhBy",
  "id" : 448950126015696896,
  "created_at" : "2014-03-26 22:30:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "448934352588926977",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009664514, 8.2829707287 ]
  },
  "id_str" : "448944700599574528",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC it\u2019s applied chaos theory and as such a large scale demonstration of cascading failure.",
  "id" : 448944700599574528,
  "in_reply_to_status_id" : 448934352588926977,
  "created_at" : "2014-03-26 22:08:52 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fhtagn",
      "indices" : [ 33, 40 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096719696, 8.2829952099 ]
  },
  "id_str" : "448840973104472064",
  "text" : "At the Data Mountains of Madness #fhtagn",
  "id" : 448840973104472064,
  "created_at" : "2014-03-26 15:16:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/v8bmRnge86",
      "expanded_url" : "http:\/\/thememorypalace.us\/2014\/03\/400000-stars\/",
      "display_url" : "thememorypalace.us\/2014\/03\/400000\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0011913108, 8.3009292205 ]
  },
  "id_str" : "448832765124177920",
  "text" : "Such a beautiful \u2018the memory palace\u2019 episode on the women who transformed astronomy as the Harvard Computers http:\/\/t.co\/v8bmRnge86",
  "id" : 448832765124177920,
  "created_at" : "2014-03-26 14:44:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "S\u00F6ren Schewe",
      "screen_name" : "Roterhai",
      "indices" : [ 0, 9 ],
      "id_str" : "25101713",
      "id" : 25101713
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "448817744084234240",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096366425, 8.282995835 ]
  },
  "id_str" : "448818331739754496",
  "in_reply_to_user_id" : 25101713,
  "text" : "@Roterhai ja, danke :)",
  "id" : 448818331739754496,
  "in_reply_to_status_id" : 448817744084234240,
  "created_at" : "2014-03-26 13:46:43 +0000",
  "in_reply_to_screen_name" : "Roterhai",
  "in_reply_to_user_id_str" : "25101713",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "L3viathan",
      "screen_name" : "L3viathan2142",
      "indices" : [ 0, 14 ],
      "id_str" : "23305817",
      "id" : 23305817
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "448799483015737344",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009562866, 8.282951812 ]
  },
  "id_str" : "448799612279615488",
  "in_reply_to_user_id" : 23305817,
  "text" : "@L3viathan2142 stimmt, eines der sch\u00F6nsten Dinge an FFM ist der Flughaften.",
  "id" : 448799612279615488,
  "in_reply_to_status_id" : 448799483015737344,
  "created_at" : "2014-03-26 12:32:20 +0000",
  "in_reply_to_screen_name" : "L3viathan2142",
  "in_reply_to_user_id_str" : "23305817",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "L3viathan",
      "screen_name" : "L3viathan2142",
      "indices" : [ 0, 14 ],
      "id_str" : "23305817",
      "id" : 23305817
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "448798910111576064",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009562866, 8.282951812 ]
  },
  "id_str" : "448799222763376640",
  "in_reply_to_user_id" : 23305817,
  "text" : "@L3viathan2142 versuchst du das jemandem zu erz\u00E4hlen der noch mindestens 2 Jahre FFM vor sich hat? :P",
  "id" : 448799222763376640,
  "in_reply_to_status_id" : 448798910111576064,
  "created_at" : "2014-03-26 12:30:47 +0000",
  "in_reply_to_screen_name" : "L3viathan2142",
  "in_reply_to_user_id_str" : "23305817",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "L3viathan",
      "screen_name" : "L3viathan2142",
      "indices" : [ 0, 14 ],
      "id_str" : "23305817",
      "id" : 23305817
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "448798477196468224",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009562866, 8.282951812 ]
  },
  "id_str" : "448798693270224896",
  "in_reply_to_user_id" : 23305817,
  "text" : "@L3viathan2142 viel erfolg dabei. Ich hab aber geh\u00F6rt es ist sonst auch ziemlich egal in was &amp; wo genau man seinen Master macht ;)",
  "id" : 448798693270224896,
  "in_reply_to_status_id" : 448798477196468224,
  "created_at" : "2014-03-26 12:28:41 +0000",
  "in_reply_to_screen_name" : "L3viathan2142",
  "in_reply_to_user_id_str" : "23305817",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "L3viathan",
      "screen_name" : "L3viathan2142",
      "indices" : [ 0, 14 ],
      "id_str" : "23305817",
      "id" : 23305817
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "448798209708924928",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009562866, 8.282951812 ]
  },
  "id_str" : "448798422129455104",
  "in_reply_to_user_id" : 23305817,
  "text" : "@L3viathan2142 was ist denn der Wunsch? :)",
  "id" : 448798422129455104,
  "in_reply_to_status_id" : 448798209708924928,
  "created_at" : "2014-03-26 12:27:36 +0000",
  "in_reply_to_screen_name" : "L3viathan2142",
  "in_reply_to_user_id_str" : "23305817",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "L3viathan",
      "screen_name" : "L3viathan2142",
      "indices" : [ 0, 14 ],
      "id_str" : "23305817",
      "id" : 23305817
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "448797657956622338",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009562866, 8.282951812 ]
  },
  "id_str" : "448797971791237121",
  "in_reply_to_user_id" : 23305817,
  "text" : "@L3viathan2142 gratulations! :)",
  "id" : 448797971791237121,
  "in_reply_to_status_id" : 448797657956622338,
  "created_at" : "2014-03-26 12:25:49 +0000",
  "in_reply_to_screen_name" : "L3viathan2142",
  "in_reply_to_user_id_str" : "23305817",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 68 ],
      "url" : "http:\/\/t.co\/PjVxPAv7x3",
      "expanded_url" : "http:\/\/www.slate.com\/blogs\/lexicon_valley\/2014\/03\/25\/that_the_self_conscious_utility_of_that_in_phrases_like_that_guy_or_that.html",
      "display_url" : "slate.com\/blogs\/lexicon_\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009562866, 8.282951812 ]
  },
  "id_str" : "448797179340419072",
  "text" : "That Word for a Meme-Obsessed, Self-Aware Age http:\/\/t.co\/PjVxPAv7x3",
  "id" : 448797179340419072,
  "created_at" : "2014-03-26 12:22:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 8, 30 ],
      "url" : "http:\/\/t.co\/nHlQZ5w8zZ",
      "expanded_url" : "http:\/\/25.media.tumblr.com\/25e21af06e79ddf1cac38fe554d4df15\/tumblr_n23h4q6SBl1qdlh1io1_400.gif",
      "display_url" : "25.media.tumblr.com\/25e21af06e79dd\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096493983, 8.2830391733 ]
  },
  "id_str" : "448778088797970432",
  "text" : "status: http:\/\/t.co\/nHlQZ5w8zZ",
  "id" : 448778088797970432,
  "created_at" : "2014-03-26 11:06:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "The_Smoking_GNU",
      "indices" : [ 3, 19 ],
      "id_str" : "14535787",
      "id" : 14535787
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GoogleStreetview",
      "indices" : [ 68, 85 ]
    }, {
      "text" : "Reddit",
      "indices" : [ 86, 93 ]
    } ],
    "urls" : [ {
      "indices" : [ 21, 43 ],
      "url" : "http:\/\/t.co\/g5IFFaFNdf",
      "expanded_url" : "http:\/\/i.imgur.com\/7HnXg14.png",
      "display_url" : "i.imgur.com\/7HnXg14.png"
    }, {
      "indices" : [ 44, 67 ],
      "url" : "https:\/\/t.co\/0K3KsOT3NY",
      "expanded_url" : "https:\/\/maps.google.com\/maps?q=Iqaluit,+NU,+Canada&hl=en&ll=63.722283,-68.514175&spn=0.047347,0.154324&sll=68.212369,-87.363281&sspn=1.262147,4.938354&oq=iqaluit&t=h&hnear=Iqaluit,+Baffin+Region,+Nunavut,+Canada&z=13&layer=c&cbll=63.714132,-68.516001&panoid=w82llOHzAEVbB_Lrl8zp5w&cbp=12,173.79,,0,13.01",
      "display_url" : "maps.google.com\/maps?q=Iqaluit\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "448754689811939328",
  "text" : "RT @The_Smoking_GNU: http:\/\/t.co\/g5IFFaFNdf https:\/\/t.co\/0K3KsOT3NY #GoogleStreetview #Reddit",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GoogleStreetview",
        "indices" : [ 47, 64 ]
      }, {
        "text" : "Reddit",
        "indices" : [ 65, 72 ]
      } ],
      "urls" : [ {
        "indices" : [ 0, 22 ],
        "url" : "http:\/\/t.co\/g5IFFaFNdf",
        "expanded_url" : "http:\/\/i.imgur.com\/7HnXg14.png",
        "display_url" : "i.imgur.com\/7HnXg14.png"
      }, {
        "indices" : [ 23, 46 ],
        "url" : "https:\/\/t.co\/0K3KsOT3NY",
        "expanded_url" : "https:\/\/maps.google.com\/maps?q=Iqaluit,+NU,+Canada&hl=en&ll=63.722283,-68.514175&spn=0.047347,0.154324&sll=68.212369,-87.363281&sspn=1.262147,4.938354&oq=iqaluit&t=h&hnear=Iqaluit,+Baffin+Region,+Nunavut,+Canada&z=13&layer=c&cbll=63.714132,-68.516001&panoid=w82llOHzAEVbB_Lrl8zp5w&cbp=12,173.79,,0,13.01",
        "display_url" : "maps.google.com\/maps?q=Iqaluit\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "448754300416978944",
    "text" : "http:\/\/t.co\/g5IFFaFNdf https:\/\/t.co\/0K3KsOT3NY #GoogleStreetview #Reddit",
    "id" : 448754300416978944,
    "created_at" : "2014-03-26 09:32:17 +0000",
    "user" : {
      "name" : "Michael",
      "screen_name" : "The_Smoking_GNU",
      "protected" : false,
      "id_str" : "14535787",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2761947084\/9f21f669a1629e0af7949d685517ee66_normal.jpeg",
      "id" : 14535787,
      "verified" : false
    }
  },
  "id" : 448754689811939328,
  "created_at" : "2014-03-26 09:33:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/OaPrJ48IYh",
      "expanded_url" : "http:\/\/biomickwatson.wordpress.com\/2014\/03\/25\/biologists-this-is-why-bioinformaticians-hate-you\/",
      "display_url" : "biomickwatson.wordpress.com\/2014\/03\/25\/bio\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "448754432231346176",
  "text" : "Why bioinformaticians hate\u00A0you: every time you make a spelling mistake, computers explode in silent fury http:\/\/t.co\/OaPrJ48IYh",
  "id" : 448754432231346176,
  "created_at" : "2014-03-26 09:32:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 50 ],
      "url" : "http:\/\/t.co\/2Y6LSKv2ol",
      "expanded_url" : "http:\/\/www.qwantz.com\/index.php?comic=2596",
      "display_url" : "qwantz.com\/index.php?comi\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00963605, 8.28302803 ]
  },
  "id_str" : "448746383869489152",
  "text" : "How-To: be a medical doctor http:\/\/t.co\/2Y6LSKv2ol",
  "id" : 448746383869489152,
  "created_at" : "2014-03-26 09:00:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/qXDm7SBLWk",
      "expanded_url" : "http:\/\/news.discovery.com\/human\/life\/are-exclamation-marks-killing-us-with-kindness-140324.htm",
      "display_url" : "news.discovery.com\/human\/life\/are\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00963605, 8.28302803 ]
  },
  "id_str" : "448624552927838208",
  "text" : "soon: multiple exclamation marks will no longer be a sign of a diseased mind http:\/\/t.co\/qXDm7SBLWk",
  "id" : 448624552927838208,
  "created_at" : "2014-03-26 00:56:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/3v53KFSWBq",
      "expanded_url" : "http:\/\/www.plosone.org\/article\/info%3Adoi%2F10.1371%2Fjournal.pone.0092406",
      "display_url" : "plosone.org\/article\/info%3\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00963605, 8.28302803 ]
  },
  "id_str" : "448623914181492736",
  "text" : "Do Adults Show a Curse of Knowledge in False-Belief Reasoning? A Robust Estimate of the True Effect Size http:\/\/t.co\/3v53KFSWBq",
  "id" : 448623914181492736,
  "created_at" : "2014-03-26 00:54:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 72 ],
      "url" : "http:\/\/t.co\/O32mJCTc6I",
      "expanded_url" : "http:\/\/blogs.scientificamerican.com\/moral-universe\/2014\/03\/25\/quantiphobia-and-turning-morals-into-facts\/",
      "display_url" : "blogs.scientificamerican.com\/moral-universe\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00963605, 8.28302803 ]
  },
  "id_str" : "448618101853405184",
  "text" : "Quantiphobia and the turning of morals into facts http:\/\/t.co\/O32mJCTc6I",
  "id" : 448618101853405184,
  "created_at" : "2014-03-26 00:31:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "448616059629604864",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00963605, 8.28302803 ]
  },
  "id_str" : "448616706102263808",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer I did ~600k of ours, speeding things up by doing really small chunks when there\u2019s low traffic :P",
  "id" : 448616706102263808,
  "in_reply_to_status_id" : 448616059629604864,
  "created_at" : "2014-03-26 00:25:32 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "448614498794872834",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00963605, 8.28302803 ]
  },
  "id_str" : "448614948735041536",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer we\u2019re at 990k or so. I might find out tomorrow (while doing home office, so the sysadmin can\u2019t perform corporal punishment).",
  "id" : 448614948735041536,
  "in_reply_to_status_id" : 448614498794872834,
  "created_at" : "2014-03-26 00:18:33 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "448613022236282881",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00963605, 8.28302803 ]
  },
  "id_str" : "448614208843038721",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer after pulling one of those tricks I wondered what happens when the qstat job-ID counter roles over the 6-digit limitation.",
  "id" : 448614208843038721,
  "in_reply_to_status_id" : 448613022236282881,
  "created_at" : "2014-03-26 00:15:36 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "448612241445642240",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096634063, 8.2830273757 ]
  },
  "id_str" : "448612643746885632",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer and you started it 5 minutes before running from the office, screaming like a madman?",
  "id" : 448612643746885632,
  "in_reply_to_status_id" : 448612241445642240,
  "created_at" : "2014-03-26 00:09:23 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095498988, 8.2829731977 ]
  },
  "id_str" : "448593520858001408",
  "text" : "\u00ABIs there anything you don\u2019t approach with bayesian decision theory?\u00BB \u2014 \u00ABWell, I do calculate posteriors to find out whether I\u2019m in love\u2026\u00BB",
  "id" : 448593520858001408,
  "created_at" : "2014-03-25 22:53:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095591843, 8.2829158241 ]
  },
  "id_str" : "448561906350325761",
  "text" : "\u00ABJaja, du bist ein ganz niedlicher Teil der Giant Component im Poly-Graphen.\u00BB \u2014 \u00ABEy, hast du mich gerade Fett genannt?!\u00BB",
  "id" : 448561906350325761,
  "created_at" : "2014-03-25 20:47:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jens-Wolfhard",
      "screen_name" : "Drahflow",
      "indices" : [ 0, 9 ],
      "id_str" : "92904426",
      "id" : 92904426
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 10, 16 ],
      "id_str" : "1492631",
      "id" : 1492631
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 17, 26 ],
      "id_str" : "14861745",
      "id" : 14861745
    }, {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 27, 36 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "448560269812576256",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095591843, 8.2829158241 ]
  },
  "id_str" : "448560482740613120",
  "in_reply_to_user_id" : 92904426,
  "text" : "@Drahflow @Lobot @Senficon @SuicideC alleine schon weil die 8 Slots langsam eng werden.",
  "id" : 448560482740613120,
  "in_reply_to_status_id" : 448560269812576256,
  "created_at" : "2014-03-25 20:42:07 +0000",
  "in_reply_to_screen_name" : "Drahflow",
  "in_reply_to_user_id_str" : "92904426",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 7, 16 ],
      "id_str" : "14861745",
      "id" : 14861745
    }, {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 17, 26 ],
      "id_str" : "78977466",
      "id" : 78977466
    }, {
      "name" : "Jens-Wolfhard",
      "screen_name" : "Drahflow",
      "indices" : [ 38, 47 ],
      "id_str" : "92904426",
      "id" : 92904426
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "448556117808144385",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096542296, 8.283039378 ]
  },
  "id_str" : "448556794450022400",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot @Senficon @SuicideC ich glaube @Drahflow nicht, nachher liegt sein langes Teil wieder so lange auf unserem Sofa rum.",
  "id" : 448556794450022400,
  "in_reply_to_status_id" : 448556117808144385,
  "created_at" : "2014-03-25 20:27:28 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "448542264240123904",
  "text" : "\u00ABYou\u2019re giving me a warm fuzzy logic feeling inside.\u00BB",
  "id" : 448542264240123904,
  "created_at" : "2014-03-25 19:29:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Johannes",
      "screen_name" : "scampy_joe",
      "indices" : [ 0, 11 ],
      "id_str" : "49283808",
      "id" : 49283808
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "448465406345613312",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723163501, 8.6276269888 ]
  },
  "id_str" : "448465809162383360",
  "in_reply_to_user_id" : 49283808,
  "text" : "@scampy_joe inkl. Verweis auf \u2018vor 7 Jahren schon mal!!11\u2019 :D",
  "id" : 448465809162383360,
  "in_reply_to_status_id" : 448465406345613312,
  "created_at" : "2014-03-25 14:25:55 +0000",
  "in_reply_to_screen_name" : "scampy_joe",
  "in_reply_to_user_id_str" : "49283808",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Johannes",
      "screen_name" : "scampy_joe",
      "indices" : [ 0, 11 ],
      "id_str" : "49283808",
      "id" : 49283808
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "448464575282049024",
  "geo" : { },
  "id_str" : "448465128431042560",
  "in_reply_to_user_id" : 49283808,
  "text" : "@scampy_joe Ich weiss, es war als \"so wenig los das man sich schon einen Tier-Serienm\u00F6rder herbeischreiben muss\" gemeint.",
  "id" : 448465128431042560,
  "in_reply_to_status_id" : 448464575282049024,
  "created_at" : "2014-03-25 14:23:13 +0000",
  "in_reply_to_screen_name" : "scampy_joe",
  "in_reply_to_user_id_str" : "49283808",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 38 ],
      "url" : "http:\/\/t.co\/GSNhKew5IE",
      "expanded_url" : "http:\/\/www.faz.net\/aktuell\/rhein-main\/frankfurter-zoo-15-flamingos-brutal-getoetet-12860108.html",
      "display_url" : "faz.net\/aktuell\/rhein-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "448464179071299584",
  "text" : "Ach, Frankfurt\u2026 http:\/\/t.co\/GSNhKew5IE",
  "id" : 448464179071299584,
  "created_at" : "2014-03-25 14:19:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "448422502973587456",
  "geo" : { },
  "id_str" : "448449750980132864",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich the word you are looking for is 'troll'!",
  "id" : 448449750980132864,
  "in_reply_to_status_id" : 448422502973587456,
  "created_at" : "2014-03-25 13:22:07 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "448421035353075712",
  "geo" : { },
  "id_str" : "448421663496241152",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich you really should do Kabarett.",
  "id" : 448421663496241152,
  "in_reply_to_status_id" : 448421035353075712,
  "created_at" : "2014-03-25 11:30:30 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "448419695969173504",
  "geo" : { },
  "id_str" : "448421444859752448",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot nah, that's for beginners.",
  "id" : 448421444859752448,
  "in_reply_to_status_id" : 448419695969173504,
  "created_at" : "2014-03-25 11:29:38 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/924dtQy78w",
      "expanded_url" : "http:\/\/disinfo.com\/2014\/03\/poo-date-wins-oddest-book-title-year\/",
      "display_url" : "disinfo.com\/2014\/03\/poo-da\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "448420681953587200",
  "text" : "\u2018How to Poo on a Date\u2019 Wins Oddest Book Title of the Year http:\/\/t.co\/924dtQy78w",
  "id" : 448420681953587200,
  "created_at" : "2014-03-25 11:26:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "448418612815347712",
  "geo" : { },
  "id_str" : "448418806642511872",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot but obviously it's not IRL",
  "id" : 448418806642511872,
  "in_reply_to_status_id" : 448418612815347712,
  "created_at" : "2014-03-25 11:19:09 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "448415171074334720",
  "geo" : { },
  "id_str" : "448417393292115968",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot probably because graduating sounds so appealing?",
  "id" : 448417393292115968,
  "in_reply_to_status_id" : 448415171074334720,
  "created_at" : "2014-03-25 11:13:32 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/RJKFucaNeR",
      "expanded_url" : "http:\/\/theness.com\/neurologicablog\/index.php\/homeopathic-products-recalled-for-containing-actual-drugs\/",
      "display_url" : "theness.com\/neurologicablo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "448416036258590721",
  "text" : "\u00ABHomeopathic Products Recalled for Containing Actual Drugs\u00BB http:\/\/t.co\/RJKFucaNeR",
  "id" : 448416036258590721,
  "created_at" : "2014-03-25 11:08:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "mrgunn",
      "screen_name" : "mrgunn",
      "indices" : [ 14, 21 ],
      "id_str" : "15237935",
      "id" : 15237935
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "448407859139596288",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723893825, 8.6279193219 ]
  },
  "id_str" : "448409971185963008",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @mrgunn ruled by the statistically illiterate\u2026",
  "id" : 448409971185963008,
  "in_reply_to_status_id" : 448407859139596288,
  "created_at" : "2014-03-25 10:44:02 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723255111, 8.6276317648 ]
  },
  "id_str" : "448401333453062144",
  "text" : "\u00ABThese days just being alive is a testament to my willpower. Neither did I throw myself in front of a train nor did I step into traffic.\u00BB",
  "id" : 448401333453062144,
  "created_at" : "2014-03-25 10:09:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "448394422666158080",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723195077, 8.6276243466 ]
  },
  "id_str" : "448394922560081920",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot and all that only because I\u2019m such a fan of The Graduate. ;)",
  "id" : 448394922560081920,
  "in_reply_to_status_id" : 448394422666158080,
  "created_at" : "2014-03-25 09:44:14 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Denker",
      "screen_name" : "Phaidr0s",
      "indices" : [ 0, 9 ],
      "id_str" : "40466433",
      "id" : 40466433
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "448357010401402881",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1025237469, 8.5437934287 ]
  },
  "id_str" : "448357738637459456",
  "in_reply_to_user_id" : 40466433,
  "text" : "@Phaidr0s rescuing scientists and IT departments in dire need all over the world!",
  "id" : 448357738637459456,
  "in_reply_to_status_id" : 448357010401402881,
  "created_at" : "2014-03-25 07:16:29 +0000",
  "in_reply_to_screen_name" : "Phaidr0s",
  "in_reply_to_user_id_str" : "40466433",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TwistedDoodles",
      "screen_name" : "twisteddoodles",
      "indices" : [ 3, 18 ],
      "id_str" : "487584390",
      "id" : 487584390
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/twisteddoodles\/status\/448265307740966912\/photo\/1",
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/Wbh1fth3bt",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BjiO7BGIQAAu84O.png",
      "id_str" : "448265307480932352",
      "id" : 448265307480932352,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BjiO7BGIQAAu84O.png",
      "sizes" : [ {
        "h" : 1101,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 494
      }, {
        "h" : 1101,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 1101,
        "resize" : "fit",
        "w" : 800
      } ],
      "display_url" : "pic.twitter.com\/Wbh1fth3bt"
    } ],
    "hashtags" : [ {
      "text" : "Science",
      "indices" : [ 55, 63 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "448357338135953408",
  "text" : "RT @twisteddoodles: Questions people ask PhD students. #Science http:\/\/t.co\/Wbh1fth3bt",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/twisteddoodles\/status\/448265307740966912\/photo\/1",
        "indices" : [ 44, 66 ],
        "url" : "http:\/\/t.co\/Wbh1fth3bt",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BjiO7BGIQAAu84O.png",
        "id_str" : "448265307480932352",
        "id" : 448265307480932352,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BjiO7BGIQAAu84O.png",
        "sizes" : [ {
          "h" : 1101,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 494
        }, {
          "h" : 1101,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 1101,
          "resize" : "fit",
          "w" : 800
        } ],
        "display_url" : "pic.twitter.com\/Wbh1fth3bt"
      } ],
      "hashtags" : [ {
        "text" : "Science",
        "indices" : [ 35, 43 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "448265307740966912",
    "text" : "Questions people ask PhD students. #Science http:\/\/t.co\/Wbh1fth3bt",
    "id" : 448265307740966912,
    "created_at" : "2014-03-25 01:09:12 +0000",
    "user" : {
      "name" : "TwistedDoodles",
      "screen_name" : "twisteddoodles",
      "protected" : false,
      "id_str" : "487584390",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2923852396\/20613163743438c5ee92899367284184_normal.jpeg",
      "id" : 487584390,
      "verified" : true
    }
  },
  "id" : 448357338135953408,
  "created_at" : "2014-03-25 07:14:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/krUGtKsUNE",
      "expanded_url" : "http:\/\/feeds.wired.com\/c\/35185\/f\/661470\/s\/388982bc\/sc\/32\/l\/0L0Swired0N0Cwiredscience0C20A140C0A30Cbionic0Ebiofilms0C\/story01.htm",
      "display_url" : "feeds.wired.com\/c\/35185\/f\/6614\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.102524, 8.543793 ]
  },
  "id_str" : "448356600286552064",
  "text" : "Misread as 'Scientists Tweak Genes to Give Barista Electrical Superpowers'\u2026 Coffee, pretty please? http:\/\/t.co\/krUGtKsUNE",
  "id" : 448356600286552064,
  "created_at" : "2014-03-25 07:11:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0100928965, 8.2828045171 ]
  },
  "id_str" : "448238372717625344",
  "text" : "Everything I know about herbs I know thanks to Simon &amp; Garfunkel. Apparently that\u2019s enough to be viewed as a botany expert on first look.",
  "id" : 448238372717625344,
  "created_at" : "2014-03-24 23:22:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "448234850018144257",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096544143, 8.2830352103 ]
  },
  "id_str" : "448235061616599040",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC I\u2019m so up to that. But please don\u2019t let it end with KIA!",
  "id" : 448235061616599040,
  "in_reply_to_status_id" : 448234850018144257,
  "created_at" : "2014-03-24 23:09:01 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "448233001961668608",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096871857, 8.2830373328 ]
  },
  "id_str" : "448233341494763520",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC I learned that from an expert in the field. And I stand by my opinion: it was badly phrased but the intended meaning was nice.",
  "id" : 448233341494763520,
  "in_reply_to_status_id" : 448233001961668608,
  "created_at" : "2014-03-24 23:02:11 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/wG9GOZXyCG",
      "expanded_url" : "http:\/\/whatshouldwecallgradschool.tumblr.com\/post\/80391600424",
      "display_url" : "whatshouldwecallgradschool.tumblr.com\/post\/803916004\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.008454, 8.4185 ]
  },
  "id_str" : "448227001141567489",
  "text" : "that's a pretty accurate depiction of my work\u2026 http:\/\/t.co\/wG9GOZXyCG",
  "id" : 448227001141567489,
  "created_at" : "2014-03-24 22:36:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "448218474205442048",
  "text" : "\u00ABIch wollte ja auch mal studieren: Internationaler Terrorismus. Das wird aber nur in den USA angeboten.\u00BB",
  "id" : 448218474205442048,
  "created_at" : "2014-03-24 22:03:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert Krause",
      "screen_name" : "euleule",
      "indices" : [ 0, 8 ],
      "id_str" : "563152502",
      "id" : 563152502
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "448215212215504896",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1138823323, 8.6789391684 ]
  },
  "id_str" : "448218152691048449",
  "in_reply_to_user_id" : 563152502,
  "text" : "@euleule haha, from Mainz it would be more like 80km in total. The 17 are the commute inside Frankfurt. :)",
  "id" : 448218152691048449,
  "in_reply_to_status_id" : 448215212215504896,
  "created_at" : "2014-03-24 22:01:49 +0000",
  "in_reply_to_screen_name" : "euleule",
  "in_reply_to_user_id_str" : "563152502",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "448215411369463809",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1137920739, 8.6789873223 ]
  },
  "id_str" : "448217449050435584",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon nope, that will be tomorrow.",
  "id" : 448217449050435584,
  "in_reply_to_status_id" : 448215411369463809,
  "created_at" : "2014-03-24 21:59:02 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.113701272, 8.6788652175 ]
  },
  "id_str" : "448214439255638016",
  "text" : "Another useful skill to add to my CV: schedule meetings for days where public transport is on strike. So once again: walking 17 km it is\u2026",
  "id" : 448214439255638016,
  "created_at" : "2014-03-24 21:47:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niels-Arne M\u00FCnck",
      "screen_name" : "Wernermuende",
      "indices" : [ 0, 13 ],
      "id_str" : "56502413",
      "id" : 56502413
    }, {
      "name" : "alios",
      "screen_name" : "alios",
      "indices" : [ 14, 20 ],
      "id_str" : "16309072",
      "id" : 16309072
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "448138612824367104",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722928859, 8.6276425482 ]
  },
  "id_str" : "448156095027380224",
  "in_reply_to_user_id" : 56502413,
  "text" : "@Wernermuende @alios danke! :)",
  "id" : 448156095027380224,
  "in_reply_to_status_id" : 448138612824367104,
  "created_at" : "2014-03-24 17:55:14 +0000",
  "in_reply_to_screen_name" : "Wernermuende",
  "in_reply_to_user_id_str" : "56502413",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Science Web",
      "screen_name" : "TheScienceWeb",
      "indices" : [ 3, 17 ],
      "id_str" : "2315551122",
      "id" : 2315551122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/H9PN11qDaL",
      "expanded_url" : "http:\/\/wp.me\/p4ik2k-2G",
      "display_url" : "wp.me\/p4ik2k-2G"
    } ]
  },
  "geo" : { },
  "id_str" : "448074458855931905",
  "text" : "RT @TheScienceWeb: EU to save on admin costs by funding exactly the same people it did last time http:\/\/t.co\/H9PN11qDaL",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 78, 100 ],
        "url" : "http:\/\/t.co\/H9PN11qDaL",
        "expanded_url" : "http:\/\/wp.me\/p4ik2k-2G",
        "display_url" : "wp.me\/p4ik2k-2G"
      } ]
    },
    "geo" : { },
    "id_str" : "448064812153446401",
    "text" : "EU to save on admin costs by funding exactly the same people it did last time http:\/\/t.co\/H9PN11qDaL",
    "id" : 448064812153446401,
    "created_at" : "2014-03-24 11:52:30 +0000",
    "user" : {
      "name" : "The Science Web",
      "screen_name" : "TheScienceWeb",
      "protected" : false,
      "id_str" : "2315551122",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/428172546672824320\/1lZmC7lz_normal.jpeg",
      "id" : 2315551122,
      "verified" : false
    }
  },
  "id" : 448074458855931905,
  "created_at" : "2014-03-24 12:30:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172201586, 8.6275713891 ]
  },
  "id_str" : "448072208225947648",
  "text" : "\u00ABWer \u2018Du bist mir wichtiger als ein beliebiger Hamster\u2019 als Kompliment verwendet sollte sich im lustig machen vielleicht zur\u00FCckhalten.\u00BB",
  "id" : 448072208225947648,
  "created_at" : "2014-03-24 12:21:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dierk Haasis",
      "screen_name" : "Evo2Me",
      "indices" : [ 0, 7 ],
      "id_str" : "22910316",
      "id" : 22910316
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "448068290762772480",
  "geo" : { },
  "id_str" : "448068596749848576",
  "in_reply_to_user_id" : 22910316,
  "text" : "@Evo2Me klang f\u00FCr mich mehr nach dem heissen Schmacht am kalten Buffet.",
  "id" : 448068596749848576,
  "in_reply_to_status_id" : 448068290762772480,
  "created_at" : "2014-03-24 12:07:32 +0000",
  "in_reply_to_screen_name" : "Evo2Me",
  "in_reply_to_user_id_str" : "22910316",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723319225, 8.6276149449 ]
  },
  "id_str" : "448067498366468096",
  "text" : "\u00ABHatte euch \u2018get a room!\u2019 hinterhergerufen. In retrospect unangemessen, auf der Party sp\u00E4ter haben sich zwei noch schlimmer aufgefressen.\u00BB",
  "id" : 448067498366468096,
  "created_at" : "2014-03-24 12:03:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "448053057352638464",
  "text" : "You're doing it wrong if you're using a variable numbers of spaces as separator in order to make your plain text table look nice\u2026",
  "id" : 448053057352638464,
  "created_at" : "2014-03-24 11:05:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "448020728575950848",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723180926, 8.6276284076 ]
  },
  "id_str" : "448022775106895872",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC I interpret that as \u2018in English, but except for that the same\u2019 ;)",
  "id" : 448022775106895872,
  "in_reply_to_status_id" : 448020728575950848,
  "created_at" : "2014-03-24 09:05:28 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723249922, 8.6276171977 ]
  },
  "id_str" : "448015362710568961",
  "text" : "\u00ABSo everyone expected this to happen except for the both of you?\u00BB \u2014 \u00ABYep, welcome to Team \u2018Told You So\u2019.\u00BB",
  "id" : 448015362710568961,
  "created_at" : "2014-03-24 08:36:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009677959, 8.2829924217 ]
  },
  "id_str" : "447878826077720576",
  "text" : "\u00ABIch wei\u00DF wie du Dreadlocks bekommst. Ich h\u00F6re einfach auf dich zu b\u00FCrsten und fick dich weiter, du mittelalter wei\u00DFer Mann.\u00BB",
  "id" : 447878826077720576,
  "created_at" : "2014-03-23 23:33:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 71 ],
      "url" : "https:\/\/t.co\/wKfNd4hFPQ",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/447807700555284480",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "447858566498893824",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096705662, 8.2830735565 ]
  },
  "id_str" : "447878550797164544",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC I half-expected this being a reply to https:\/\/t.co\/wKfNd4hFPQ ;)",
  "id" : 447878550797164544,
  "in_reply_to_status_id" : 447858566498893824,
  "created_at" : "2014-03-23 23:32:22 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096421163, 8.2829905514 ]
  },
  "id_str" : "447820041724370945",
  "text" : "\u00ABWie war das denn als Kompliment gemeint?! Es klingt nach \u2018sorry Baby, aber ich hab schon alles gesehen &amp; nichts kann mich noch schocken\u2019!\u00BB",
  "id" : 447820041724370945,
  "created_at" : "2014-03-23 19:39:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "herr_schrat",
      "screen_name" : "herr_schrat",
      "indices" : [ 0, 12 ],
      "id_str" : "16066591",
      "id" : 16066591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "447811113221361664",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096165985, 8.2829703851 ]
  },
  "id_str" : "447811198445449217",
  "in_reply_to_user_id" : 16066591,
  "text" : "@herr_schrat will do.",
  "id" : 447811198445449217,
  "in_reply_to_status_id" : 447811113221361664,
  "created_at" : "2014-03-23 19:04:44 +0000",
  "in_reply_to_screen_name" : "herr_schrat",
  "in_reply_to_user_id_str" : "16066591",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "herr_schrat",
      "screen_name" : "herr_schrat",
      "indices" : [ 0, 12 ],
      "id_str" : "16066591",
      "id" : 16066591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "447810759700254720",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096165985, 8.2829703851 ]
  },
  "id_str" : "447810973307764737",
  "in_reply_to_user_id" : 16066591,
  "text" : "@herr_schrat bringst du Gin mit? ;)",
  "id" : 447810973307764737,
  "in_reply_to_status_id" : 447810759700254720,
  "created_at" : "2014-03-23 19:03:50 +0000",
  "in_reply_to_screen_name" : "herr_schrat",
  "in_reply_to_user_id_str" : "16066591",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "herr_schrat",
      "screen_name" : "herr_schrat",
      "indices" : [ 0, 12 ],
      "id_str" : "16066591",
      "id" : 16066591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "447808403436744705",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096165985, 8.2829703851 ]
  },
  "id_str" : "447810581895327744",
  "in_reply_to_user_id" : 16066591,
  "text" : "@herr_schrat yay, ich freu mich drauf \\o\/",
  "id" : 447810581895327744,
  "in_reply_to_status_id" : 447808403436744705,
  "created_at" : "2014-03-23 19:02:17 +0000",
  "in_reply_to_screen_name" : "herr_schrat",
  "in_reply_to_user_id_str" : "16066591",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "herr_schrat",
      "screen_name" : "herr_schrat",
      "indices" : [ 0, 12 ],
      "id_str" : "16066591",
      "id" : 16066591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "447807700555284480",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096471244, 8.2830031979 ]
  },
  "id_str" : "447807896051781632",
  "in_reply_to_user_id" : 14286491,
  "text" : "@herr_schrat reminds me: does April work out for you?",
  "id" : 447807896051781632,
  "in_reply_to_status_id" : 447807700555284480,
  "created_at" : "2014-03-23 18:51:36 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096782075, 8.2830573182 ]
  },
  "id_str" : "447807700555284480",
  "text" : "\u00ABHe has most of the fun, and all of the good women.\u00BB",
  "id" : 447807700555284480,
  "created_at" : "2014-03-23 18:50:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/amIB4OUnUs",
      "expanded_url" : "http:\/\/chapmangamo.tumblr.com\/post\/80289135934",
      "display_url" : "chapmangamo.tumblr.com\/post\/802891359\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009667, 8.283169 ]
  },
  "id_str" : "447293833903374336",
  "text" : "The International Guide for Shutting People Up http:\/\/t.co\/amIB4OUnUs",
  "id" : 447293833903374336,
  "created_at" : "2014-03-22 08:48:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Bond",
      "screen_name" : "TheLabAndField",
      "indices" : [ 3, 18 ],
      "id_str" : "1060545835",
      "id" : 1060545835
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ProteomicsSexism",
      "indices" : [ 34, 51 ]
    } ],
    "urls" : [ {
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/sh2nRY5unv",
      "expanded_url" : "http:\/\/labandfield.wordpress.com\/2014\/03\/21\/your-daily-dose-of-sexism-again-and-proteomicssexism\/",
      "display_url" : "labandfield.wordpress.com\/2014\/03\/21\/you\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "447018432736022528",
  "text" : "RT @thelabandfield: I'm compiling #ProteomicsSexism updates here: http:\/\/t.co\/sh2nRY5unv; let me know what I've missed!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ProteomicsSexism",
        "indices" : [ 14, 31 ]
      } ],
      "urls" : [ {
        "indices" : [ 46, 68 ],
        "url" : "http:\/\/t.co\/sh2nRY5unv",
        "expanded_url" : "http:\/\/labandfield.wordpress.com\/2014\/03\/21\/your-daily-dose-of-sexism-again-and-proteomicssexism\/",
        "display_url" : "labandfield.wordpress.com\/2014\/03\/21\/you\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "447010845147811840",
    "text" : "I'm compiling #ProteomicsSexism updates here: http:\/\/t.co\/sh2nRY5unv; let me know what I've missed!",
    "id" : 447010845147811840,
    "created_at" : "2014-03-21 14:04:25 +0000",
    "user" : {
      "name" : "Alex Bond",
      "screen_name" : "TheLabAndField",
      "protected" : false,
      "id_str" : "1060545835",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/851184072890167297\/jIBXYvtR_normal.jpg",
      "id" : 1060545835,
      "verified" : false
    }
  },
  "id" : 447018432736022528,
  "created_at" : "2014-03-21 14:34:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723204583, 8.627627155 ]
  },
  "id_str" : "446989156049514496",
  "text" : "He-Man &amp; the Masters of the Sample Universe: \u2018By the statistical power of Grayskull\u2026\u2019",
  "id" : 446989156049514496,
  "created_at" : "2014-03-21 12:38:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "446949934864924672",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723204583, 8.627627155 ]
  },
  "id_str" : "446950783637286912",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer And I already wondered that no idiot complained\u2026",
  "id" : 446950783637286912,
  "in_reply_to_status_id" : 446949934864924672,
  "created_at" : "2014-03-21 10:05:45 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jens Ohlig",
      "screen_name" : "johl",
      "indices" : [ 0, 5 ],
      "id_str" : "1147751",
      "id" : 1147751
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "446948536060739584",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723204583, 8.627627155 ]
  },
  "id_str" : "446948800587108352",
  "in_reply_to_user_id" : 1147751,
  "text" : "@johl haben die Piraten schon Unterst\u00FCtzung bei diesem sehr ehrenwerten Orgastreik-Ziel angek\u00FCndigt?",
  "id" : 446948800587108352,
  "in_reply_to_status_id" : 446948536060739584,
  "created_at" : "2014-03-21 09:57:52 +0000",
  "in_reply_to_screen_name" : "johl",
  "in_reply_to_user_id_str" : "1147751",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723204583, 8.627627155 ]
  },
  "id_str" : "446941963166965760",
  "text" : "Am I really too stupid or is the low complexity filtering of MEGAN not described in the manual and the paper?",
  "id" : 446941963166965760,
  "created_at" : "2014-03-21 09:30:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 14, 26 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "446909342403399680",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1759103359, 8.6286190471 ]
  },
  "id_str" : "446916310614958081",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @helgerausch thx, at least one is about openSNP. That is pretty easy by now. ;)",
  "id" : 446916310614958081,
  "in_reply_to_status_id" : 446909342403399680,
  "created_at" : "2014-03-21 07:48:46 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 14, 26 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "446907701411336192",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.105379615, 8.6431962868 ]
  },
  "id_str" : "446908915046154240",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @helgerausch \u2026so things are a bit slow at my end, as usual.",
  "id" : 446908915046154240,
  "in_reply_to_status_id" : 446907701411336192,
  "created_at" : "2014-03-21 07:19:23 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 123, 135 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "446907701411336192",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.103963828, 8.652640847 ]
  },
  "id_str" : "446908845160669184",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer okay. I\u2019m still on the financial stuff, but I\u2019ve 3 talks to give next week and none of them prepared so far\u2026 @helgerausch",
  "id" : 446908845160669184,
  "in_reply_to_status_id" : 446907701411336192,
  "created_at" : "2014-03-21 07:19:06 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 14, 26 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "446908337603375104",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1034194796, 8.6534553475 ]
  },
  "id_str" : "446908579589914624",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @helgerausch yeah, we should look out for #1000 :)",
  "id" : 446908579589914624,
  "in_reply_to_status_id" : 446908337603375104,
  "created_at" : "2014-03-21 07:18:03 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 13, 26 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "446906667905851392",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1019195103, 8.5703495072 ]
  },
  "id_str" : "446906929433296896",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch @PhilippBayer so how fucked are we? ;)",
  "id" : 446906929433296896,
  "in_reply_to_status_id" : 446906667905851392,
  "created_at" : "2014-03-21 07:11:29 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/1zSffcE9Go",
      "expanded_url" : "http:\/\/www.plosone.org\/article\/info%3Adoi%2F10.1371%2Fjournal.pone.0090628",
      "display_url" : "plosone.org\/article\/info%3\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096694943, 8.2830289857 ]
  },
  "id_str" : "446781820391399424",
  "text" : "Personality and Healthy Sleep: The Importance of Conscientiousness and Neuroticism http:\/\/t.co\/1zSffcE9Go",
  "id" : 446781820391399424,
  "created_at" : "2014-03-20 22:54:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/SLDRKetfYC",
      "expanded_url" : "http:\/\/www.qwantz.com\/index.php?comic=2589",
      "display_url" : "qwantz.com\/index.php?comi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "446639163874766850",
  "text" : "\u00ABit was the best of times, it was the worst of times, it was a warm night on the bearskin rug\u2026\u00BB http:\/\/t.co\/SLDRKetfYC",
  "id" : 446639163874766850,
  "created_at" : "2014-03-20 13:27:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Cock",
      "screen_name" : "pjacock",
      "indices" : [ 3, 11 ],
      "id_str" : "58756672",
      "id" : 58756672
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/ZW0qGALdFo",
      "expanded_url" : "http:\/\/genomebiology.com\/2014\/15\/3\/R59\/abstract",
      "display_url" : "genomebiology.com\/2014\/15\/3\/R59\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "446632659218083840",
  "text" : "RT @pjacock: Remember the 6-set banana genome Venn Diagram? Here\u2019s equally silly 5-set conifer version http:\/\/t.co\/ZW0qGALdFo http:\/\/t.co\/V\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/pjacock\/status\/446609022222094336\/photo\/1",
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/VcDN9wDmxa",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BjKsihIIAAAHaq1.png",
        "id_str" : "446609022071078912",
        "id" : 446609022071078912,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BjKsihIIAAAHaq1.png",
        "sizes" : [ {
          "h" : 534,
          "resize" : "fit",
          "w" : 590
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 534,
          "resize" : "fit",
          "w" : 590
        }, {
          "h" : 534,
          "resize" : "fit",
          "w" : 590
        }, {
          "h" : 534,
          "resize" : "fit",
          "w" : 590
        } ],
        "display_url" : "pic.twitter.com\/VcDN9wDmxa"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 90, 112 ],
        "url" : "http:\/\/t.co\/ZW0qGALdFo",
        "expanded_url" : "http:\/\/genomebiology.com\/2014\/15\/3\/R59\/abstract",
        "display_url" : "genomebiology.com\/2014\/15\/3\/R59\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "446609594631327744",
    "text" : "Remember the 6-set banana genome Venn Diagram? Here\u2019s equally silly 5-set conifer version http:\/\/t.co\/ZW0qGALdFo http:\/\/t.co\/VcDN9wDmxa\u201D",
    "id" : 446609594631327744,
    "created_at" : "2014-03-20 11:29:59 +0000",
    "user" : {
      "name" : "Peter Cock",
      "screen_name" : "pjacock",
      "protected" : false,
      "id_str" : "58756672",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/324343873\/peter_cliff_normal.jpg",
      "id" : 58756672,
      "verified" : false
    }
  },
  "id" : 446632659218083840,
  "created_at" : "2014-03-20 13:01:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1771008985, 8.6159776952 ]
  },
  "id_str" : "446630317450096640",
  "text" : "From my publication list it looks like my research can be best described as \u2018is interested in sitting in front of a computer, waiting\u2019.",
  "id" : 446630317450096640,
  "created_at" : "2014-03-20 12:52:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1721740095, 8.6271840613 ]
  },
  "id_str" : "446618484890697728",
  "text" : "Yay, and just got the news that another paper was accepted! \\o\/",
  "id" : 446618484890697728,
  "created_at" : "2014-03-20 12:05:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Linus Schumacher",
      "screen_name" : "LinusSchumacher",
      "indices" : [ 0, 16 ],
      "id_str" : "2289913051",
      "id" : 2289913051
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 17, 30 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "446604754631032832",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723436174, 8.6276713014 ]
  },
  "id_str" : "446616335901290496",
  "in_reply_to_user_id" : 2289913051,
  "text" : "@LinusSchumacher @PhilippBayer will do, so far I\u2019ve only managed to go to Cambridge a couple of times.",
  "id" : 446616335901290496,
  "in_reply_to_status_id" : 446604754631032832,
  "created_at" : "2014-03-20 11:56:46 +0000",
  "in_reply_to_screen_name" : "LinusSchumacher",
  "in_reply_to_user_id_str" : "2289913051",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Linus Schumacher",
      "screen_name" : "LinusSchumacher",
      "indices" : [ 0, 16 ],
      "id_str" : "2289913051",
      "id" : 2289913051
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 17, 30 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "446601382402203648",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1731770469, 8.6241165415 ]
  },
  "id_str" : "446603770198503424",
  "in_reply_to_user_id" : 2289913051,
  "text" : "@LinusSchumacher @PhilippBayer some things never change. ;) and funny: like 2 days ago I also talked to Michael. :)",
  "id" : 446603770198503424,
  "in_reply_to_status_id" : 446601382402203648,
  "created_at" : "2014-03-20 11:06:50 +0000",
  "in_reply_to_screen_name" : "LinusSchumacher",
  "in_reply_to_user_id_str" : "2289913051",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Linus Schumacher",
      "screen_name" : "LinusSchumacher",
      "indices" : [ 0, 16 ],
      "id_str" : "2289913051",
      "id" : 2289913051
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "446591302436913152",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.178001953, 8.6146060684 ]
  },
  "id_str" : "446600540617998336",
  "in_reply_to_user_id" : 2289913051,
  "text" : "@LinusSchumacher yeah, once in a while we still write. And great to see that you\u2019re also back to blogging. :)",
  "id" : 446600540617998336,
  "in_reply_to_status_id" : 446591302436913152,
  "created_at" : "2014-03-20 10:54:00 +0000",
  "in_reply_to_screen_name" : "LinusSchumacher",
  "in_reply_to_user_id_str" : "2289913051",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Linus Schumacher",
      "screen_name" : "LinusSchumacher",
      "indices" : [ 0, 16 ],
      "id_str" : "2289913051",
      "id" : 2289913051
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1784171653, 8.620393569 ]
  },
  "id_str" : "446590842757980160",
  "in_reply_to_user_id" : 2289913051,
  "text" : "@LinusSchumacher welcome :)",
  "id" : 446590842757980160,
  "created_at" : "2014-03-20 10:15:28 +0000",
  "in_reply_to_screen_name" : "LinusSchumacher",
  "in_reply_to_user_id_str" : "2289913051",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "446579742226276352",
  "text" : "\u00ABIch sch\u00E4tze deine Bem\u00FChungen. Aber bei einer weiteren Partnerin kann ich die Schlafmangel-induzierte Kaffeerechnung nicht mehr bezahlen.\u00BB",
  "id" : 446579742226276352,
  "created_at" : "2014-03-20 09:31:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emanuel Wyler",
      "screen_name" : "ewyler",
      "indices" : [ 0, 7 ],
      "id_str" : "122329006",
      "id" : 122329006
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 47, 59 ],
      "id_str" : "52747896",
      "id" : 52747896
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 115, 124 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "446577438857117697",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1680895842, 8.6347149736 ]
  },
  "id_str" : "446577893377052672",
  "in_reply_to_user_id" : 122329006,
  "text" : "@ewyler ah, da bin ich leider am UCL. Aber mit @helgerausch haben wir einen Berliner der vielleicht Lust hat &amp; @Senficon ist auch \u00F6fter da.",
  "id" : 446577893377052672,
  "in_reply_to_status_id" : 446577438857117697,
  "created_at" : "2014-03-20 09:24:01 +0000",
  "in_reply_to_screen_name" : "ewyler",
  "in_reply_to_user_id_str" : "122329006",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emanuel Wyler",
      "screen_name" : "ewyler",
      "indices" : [ 0, 7 ],
      "id_str" : "122329006",
      "id" : 122329006
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 8, 17 ],
      "id_str" : "14861745",
      "id" : 14861745
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 18, 31 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "446575856375586816",
  "geo" : { },
  "id_str" : "446576666610266112",
  "in_reply_to_user_id" : 122329006,
  "text" : "@ewyler @Senficon @PhilippBayer Oh, sehr cool. Wann findet die statt? :)",
  "id" : 446576666610266112,
  "in_reply_to_status_id" : 446575856375586816,
  "created_at" : "2014-03-20 09:19:08 +0000",
  "in_reply_to_screen_name" : "ewyler",
  "in_reply_to_user_id_str" : "122329006",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emanuel Wyler",
      "screen_name" : "ewyler",
      "indices" : [ 0, 7 ],
      "id_str" : "122329006",
      "id" : 122329006
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 8, 17 ],
      "id_str" : "14861745",
      "id" : 14861745
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 18, 31 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "446569858571182080",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1725200145, 8.6276929267 ]
  },
  "id_str" : "446570401796464640",
  "in_reply_to_user_id" : 122329006,
  "text" : "@ewyler @Senficon @PhilippBayer aber danke f\u00FCr die Gratulation nat\u00FCrlich :)",
  "id" : 446570401796464640,
  "in_reply_to_status_id" : 446569858571182080,
  "created_at" : "2014-03-20 08:54:15 +0000",
  "in_reply_to_screen_name" : "ewyler",
  "in_reply_to_user_id_str" : "122329006",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emanuel Wyler",
      "screen_name" : "ewyler",
      "indices" : [ 0, 7 ],
      "id_str" : "122329006",
      "id" : 122329006
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 8, 17 ],
      "id_str" : "14861745",
      "id" : 14861745
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 18, 31 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "446569858571182080",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1726728585, 8.6276170705 ]
  },
  "id_str" : "446570332863094784",
  "in_reply_to_user_id" : 122329006,
  "text" : "@ewyler @Senficon @PhilippBayer glaube nicht die erste. War Reviewer f\u00FCr ein Paper zu git was per git &amp; iirc Social Media entstanden ist :)",
  "id" : 446570332863094784,
  "in_reply_to_status_id" : 446569858571182080,
  "created_at" : "2014-03-20 08:53:58 +0000",
  "in_reply_to_screen_name" : "ewyler",
  "in_reply_to_user_id_str" : "122329006",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 64, 77 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/uqmFuOg4lh",
      "expanded_url" : "http:\/\/www.scilogs.de\/bierologie\/was-man-als-bioinformatiker-so-wissen-sollte-teil-2\/",
      "display_url" : "scilogs.de\/bierologie\/was\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "446565352231936000",
  "text" : "Teil 2 von \"Was man als Bioinformatikerin so wissen sollte\" von @PhilippBayer und mir ist jetzt auch online: http:\/\/t.co\/uqmFuOg4lh",
  "id" : 446565352231936000,
  "created_at" : "2014-03-20 08:34:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "446564466247737344",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1695133474, 8.6344439855 ]
  },
  "id_str" : "446565012816269312",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer enjoy dinner :)",
  "id" : 446565012816269312,
  "in_reply_to_status_id" : 446564466247737344,
  "created_at" : "2014-03-20 08:32:50 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "446561527953235968",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1761361051, 8.6286168233 ]
  },
  "id_str" : "446563841124864000",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer 6pm-ish? This inconsistent use of DST always gets me off.",
  "id" : 446563841124864000,
  "in_reply_to_status_id" : 446561527953235968,
  "created_at" : "2014-03-20 08:28:11 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "446562707781611520",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1761361051, 8.6286168233 ]
  },
  "id_str" : "446563104630251520",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer danke. :) das war doch genau worauf ich hinauswollte weil wir es im Text selbst auch machen :D",
  "id" : 446563104630251520,
  "in_reply_to_status_id" : 446562707781611520,
  "created_at" : "2014-03-20 08:25:15 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "446561527953235968",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1771799095, 8.6298943396 ]
  },
  "id_str" : "446561756962652161",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer BioinformatikerIn!!!",
  "id" : 446561756962652161,
  "in_reply_to_status_id" : 446561527953235968,
  "created_at" : "2014-03-20 08:19:54 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "446527078934913024",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096656171, 8.282961279 ]
  },
  "id_str" : "446539943201234945",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer 8am in 8 minutes. But sure, publish at will. Just remember the headline. ;)",
  "id" : 446539943201234945,
  "in_reply_to_status_id" : 446527078934913024,
  "created_at" : "2014-03-20 06:53:13 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Misha Angrist",
      "screen_name" : "MishaAngrist",
      "indices" : [ 0, 13 ],
      "id_str" : "116877838",
      "id" : 116877838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "446415057392791553",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096598578, 8.2830128244 ]
  },
  "id_str" : "446415882043277312",
  "in_reply_to_user_id" : 116877838,
  "text" : "@MishaAngrist that means a lot coming from you!",
  "id" : 446415882043277312,
  "in_reply_to_status_id" : 446415057392791553,
  "created_at" : "2014-03-19 22:40:14 +0000",
  "in_reply_to_screen_name" : "MishaAngrist",
  "in_reply_to_user_id_str" : "116877838",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Austin Richardson",
      "screen_name" : "heyaudy",
      "indices" : [ 0, 8 ],
      "id_str" : "14534523",
      "id" : 14534523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "446407996550422528",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096598578, 8.2830128244 ]
  },
  "id_str" : "446408255267684352",
  "in_reply_to_user_id" : 14534523,
  "text" : "@heyaudy not if you\u2019ve updated to iOS 7.1!",
  "id" : 446408255267684352,
  "in_reply_to_status_id" : 446407996550422528,
  "created_at" : "2014-03-19 22:09:56 +0000",
  "in_reply_to_screen_name" : "heyaudy",
  "in_reply_to_user_id_str" : "14534523",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 14, 23 ],
      "id_str" : "14861745",
      "id" : 14861745
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 24, 36 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "446404490099707904",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096598578, 8.2830128244 ]
  },
  "id_str" : "446405601263120384",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @Senficon @helgerausch yes, well done :)",
  "id" : 446405601263120384,
  "in_reply_to_status_id" : 446404490099707904,
  "created_at" : "2014-03-19 21:59:23 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 94, 107 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 108, 117 ],
      "id_str" : "14861745",
      "id" : 14861745
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 118, 130 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/s5QOYesx2l",
      "expanded_url" : "http:\/\/www.plosone.org\/article\/info:doi\/10.1371\/journal.pone.0089204",
      "display_url" : "plosone.org\/article\/info:d\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "446404096871120896",
  "text" : "Finally: openSNP\u2013A Crowdsourced Web Resource for Personal Genomics http:\/\/t.co\/s5QOYesx2l \/cc @PhilippBayer @Senficon @helgerausch",
  "id" : 446404096871120896,
  "created_at" : "2014-03-19 21:53:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Misha Angrist",
      "screen_name" : "MishaAngrist",
      "indices" : [ 3, 16 ],
      "id_str" : "116877838",
      "id" : 116877838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/IV9iFNoIXe",
      "expanded_url" : "http:\/\/www.plosone.org\/article\/info%3Adoi%2F10.1371%2Fjournal.pone.0092060",
      "display_url" : "plosone.org\/article\/info%3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "446403819401121792",
  "text" : "RT @MishaAngrist: Open Window: When Easily Identifiable Genomes and Traits Are in the Public Domain http:\/\/t.co\/IV9iFNoIXe cc: @gedankenstu\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 109, 125 ],
        "id_str" : "14286491",
        "id" : 14286491
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 82, 104 ],
        "url" : "http:\/\/t.co\/IV9iFNoIXe",
        "expanded_url" : "http:\/\/www.plosone.org\/article\/info%3Adoi%2F10.1371%2Fjournal.pone.0092060",
        "display_url" : "plosone.org\/article\/info%3\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "446402030564032512",
    "text" : "Open Window: When Easily Identifiable Genomes and Traits Are in the Public Domain http:\/\/t.co\/IV9iFNoIXe cc: @gedankenstuecke",
    "id" : 446402030564032512,
    "created_at" : "2014-03-19 21:45:12 +0000",
    "user" : {
      "name" : "Misha Angrist",
      "screen_name" : "MishaAngrist",
      "protected" : false,
      "id_str" : "116877838",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747461459974717441\/GIrZkLT-_normal.jpg",
      "id" : 116877838,
      "verified" : false
    }
  },
  "id" : 446403819401121792,
  "created_at" : "2014-03-19 21:52:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Misha Angrist",
      "screen_name" : "MishaAngrist",
      "indices" : [ 0, 13 ],
      "id_str" : "116877838",
      "id" : 116877838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "446402030564032512",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00966165, 8.2830180883 ]
  },
  "id_str" : "446403783573372928",
  "in_reply_to_user_id" : 116877838,
  "text" : "@MishaAngrist &amp; thanks for the great comment. article. Now I can go full fanboy &amp; say: w\/o Here Is a Human Being there\u2019d be no openSNP :)",
  "id" : 446403783573372928,
  "in_reply_to_status_id" : 446402030564032512,
  "created_at" : "2014-03-19 21:52:10 +0000",
  "in_reply_to_screen_name" : "MishaAngrist",
  "in_reply_to_user_id_str" : "116877838",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Misha Angrist",
      "screen_name" : "MishaAngrist",
      "indices" : [ 0, 13 ],
      "id_str" : "116877838",
      "id" : 116877838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "446402030564032512",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00966165, 8.2830180883 ]
  },
  "id_str" : "446402643364446208",
  "in_reply_to_user_id" : 116877838,
  "text" : "@MishaAngrist wow, we had no idea that the article would come live today! Thanks!",
  "id" : 446402643364446208,
  "in_reply_to_status_id" : 446402030564032512,
  "created_at" : "2014-03-19 21:47:38 +0000",
  "in_reply_to_screen_name" : "MishaAngrist",
  "in_reply_to_user_id_str" : "116877838",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "446359662573522944",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0028828807, 8.4400958385 ]
  },
  "id_str" : "446359966140882944",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez I should make that my PhD project. I even would take all the stress of traveling to exotic locations to do the recordings. ;)",
  "id" : 446359966140882944,
  "in_reply_to_status_id" : 446359662573522944,
  "created_at" : "2014-03-19 18:58:03 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "446358464705482752",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0623206347, 8.5281176806 ]
  },
  "id_str" : "446359522559275008",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez w\/ over 7 bio fellow humans you could even cover each position twice and make it into a duet to signify maternal\/paternal remixing",
  "id" : 446359522559275008,
  "in_reply_to_status_id" : 446358464705482752,
  "created_at" : "2014-03-19 18:56:17 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    }, {
      "name" : "Jun Axup",
      "screen_name" : "junaxup",
      "indices" : [ 10, 18 ],
      "id_str" : "19210703",
      "id" : 19210703
    }, {
      "name" : "dvzrv",
      "screen_name" : "dvzrv",
      "indices" : [ 19, 25 ],
      "id_str" : "30868098",
      "id" : 30868098
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "446357965851738113",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0623206347, 8.5281176806 ]
  },
  "id_str" : "446358322531532800",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez @junaxup @dvzrv from an art perspective I think crowdsourcing it is even nicer, as it\u2019s not only your genome but widely shared.",
  "id" : 446358322531532800,
  "in_reply_to_status_id" : 446357965851738113,
  "created_at" : "2014-03-19 18:51:31 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    }, {
      "name" : "Jun Axup",
      "screen_name" : "junaxup",
      "indices" : [ 10, 18 ],
      "id_str" : "19210703",
      "id" : 19210703
    }, {
      "name" : "dvzrv",
      "screen_name" : "dvzrv",
      "indices" : [ 19, 25 ],
      "id_str" : "30868098",
      "id" : 30868098
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "446357107432906752",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0623377753, 8.529362317 ]
  },
  "id_str" : "446357823665217536",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez @junaxup @dvzrv even if you would do it full time and only stop for basic human needs like eating\/sleep it would take like 50ys.",
  "id" : 446357823665217536,
  "in_reply_to_status_id" : 446357107432906752,
  "created_at" : "2014-03-19 18:49:32 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "446356649444257792",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0513254238, 8.5712312722 ]
  },
  "id_str" : "446357185346695168",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez glad I made it to a train. The conductors are on strike, made me walk a total of 17 kilometers to\/from work today :p",
  "id" : 446357185346695168,
  "in_reply_to_status_id" : 446356649444257792,
  "created_at" : "2014-03-19 18:47:00 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    }, {
      "name" : "Jun Axup",
      "screen_name" : "junaxup",
      "indices" : [ 10, 18 ],
      "id_str" : "19210703",
      "id" : 19210703
    }, {
      "name" : "dvzrv",
      "screen_name" : "dvzrv",
      "indices" : [ 19, 25 ],
      "id_str" : "30868098",
      "id" : 30868098
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "446356596356964352",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0513254238, 8.5712312722 ]
  },
  "id_str" : "446356960318087168",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez @junaxup @dvzrv you could have the crowd do the reading in small chunks via Mechanical Turk et al.",
  "id" : 446356960318087168,
  "in_reply_to_status_id" : 446356596356964352,
  "created_at" : "2014-03-19 18:46:06 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    }, {
      "name" : "Jun Axup",
      "screen_name" : "junaxup",
      "indices" : [ 10, 18 ],
      "id_str" : "19210703",
      "id" : 19210703
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "446356039797985280",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0514860434, 8.5716982434 ]
  },
  "id_str" : "446356595275206656",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez @junaxup yeah, currently on a train with spotty connectivity, thus the overlap :)",
  "id" : 446356595275206656,
  "in_reply_to_status_id" : 446356039797985280,
  "created_at" : "2014-03-19 18:44:39 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    }, {
      "name" : "Jun Axup",
      "screen_name" : "junaxup",
      "indices" : [ 10, 18 ],
      "id_str" : "19210703",
      "id" : 19210703
    }, {
      "name" : "dvzrv",
      "screen_name" : "dvzrv",
      "indices" : [ 23, 29 ],
      "id_str" : "30868098",
      "id" : 30868098
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "446355387139096576",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0610393369, 8.599516165 ]
  },
  "id_str" : "446356443826892800",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez @junaxup ask @dvzrv, he did a sonification of my 23andMe data. :)",
  "id" : 446356443826892800,
  "in_reply_to_status_id" : 446355387139096576,
  "created_at" : "2014-03-19 18:44:03 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    }, {
      "name" : "Jun Axup",
      "screen_name" : "junaxup",
      "indices" : [ 10, 18 ],
      "id_str" : "19210703",
      "id" : 19210703
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "446353277915914240",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.070103924, 8.636531491 ]
  },
  "id_str" : "446355946500292609",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez @junaxup but let\u2019s say 3.5 letters\/second for easier guesstimating, so somewhere around 31 years?",
  "id" : 446355946500292609,
  "in_reply_to_status_id" : 446353277915914240,
  "created_at" : "2014-03-19 18:42:05 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    }, {
      "name" : "Jun Axup",
      "screen_name" : "junaxup",
      "indices" : [ 10, 18 ],
      "id_str" : "19210703",
      "id" : 19210703
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "446353277915914240",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1014406195, 8.646430612 ]
  },
  "id_str" : "446354781112901633",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez @junaxup that only depends on the speed. It\u2019s ~3.5 billion letters. I guesstimate you could recite 4-5 letters per second.",
  "id" : 446354781112901633,
  "in_reply_to_status_id" : 446353277915914240,
  "created_at" : "2014-03-19 18:37:27 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "alios",
      "screen_name" : "alios",
      "indices" : [ 0, 6 ],
      "id_str" : "16309072",
      "id" : 16309072
    }, {
      "name" : "Caro Mahn-Gauseweg",
      "screen_name" : "688i",
      "indices" : [ 7, 12 ],
      "id_str" : "432028832",
      "id" : 432028832
    }, {
      "name" : "laprintemps",
      "screen_name" : "laprintemps",
      "indices" : [ 13, 25 ],
      "id_str" : "1483038588",
      "id" : 1483038588
    }, {
      "name" : "Katharina Nocun",
      "screen_name" : "kattascha",
      "indices" : [ 26, 36 ],
      "id_str" : "395873726",
      "id" : 395873726
    }, {
      "name" : "Marina Weisband",
      "screen_name" : "Afelia",
      "indices" : [ 37, 44 ],
      "id_str" : "16569660",
      "id" : 16569660
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "446252404766683136",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1725840963, 8.6278705943 ]
  },
  "id_str" : "446254864902148096",
  "in_reply_to_user_id" : 16309072,
  "text" : "@alios @688i @laprintemps @kattascha @Afelia du meinst weil ich Experte f\u00FCr not giving a fuck bin? ;)",
  "id" : 446254864902148096,
  "in_reply_to_status_id" : 446252404766683136,
  "created_at" : "2014-03-19 12:00:25 +0000",
  "in_reply_to_screen_name" : "alios",
  "in_reply_to_user_id_str" : "16309072",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/7KU1i7SUCp",
      "expanded_url" : "http:\/\/bps-research-digest.blogspot.de\/2014\/03\/how-thinking-in-foreign-language-makes.html?utm_source=feedburner&utm_medium=feed&utm_campaign=Feed:+BpsResearchDigest+%28BPS+Research+Digest%29",
      "display_url" : "bps-research-digest.blogspot.de\/2014\/03\/how-th\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "446236261645574145",
  "text" : "How thinking in a foreign language makes you more rational in some ways but not others http:\/\/t.co\/7KU1i7SUCp",
  "id" : 446236261645574145,
  "created_at" : "2014-03-19 10:46:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/tXyczJP11G",
      "expanded_url" : "http:\/\/www.themorningnews.org\/article\/what-doesnt-kill-you-doesnt-kill-you",
      "display_url" : "themorningnews.org\/article\/what-d\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "446230958002692096",
  "text" : "Visiting bear country: \u00ABSome husbands give flowers or chocolate; mine gave me the chance to challenge a phobia\u00BB http:\/\/t.co\/tXyczJP11G",
  "id" : 446230958002692096,
  "created_at" : "2014-03-19 10:25:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lara",
      "screen_name" : "alibi_ranch",
      "indices" : [ 0, 12 ],
      "id_str" : "265371167",
      "id" : 265371167
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "446217166820753408",
  "geo" : { },
  "id_str" : "446221060867129345",
  "in_reply_to_user_id" : 265371167,
  "text" : "@alibi_ranch good luck ;)",
  "id" : 446221060867129345,
  "in_reply_to_status_id" : 446217166820753408,
  "created_at" : "2014-03-19 09:46:05 +0000",
  "in_reply_to_screen_name" : "alibi_ranch",
  "in_reply_to_user_id_str" : "265371167",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lara",
      "screen_name" : "alibi_ranch",
      "indices" : [ 0, 12 ],
      "id_str" : "265371167",
      "id" : 265371167
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "446208071451557888",
  "geo" : { },
  "id_str" : "446216595531399168",
  "in_reply_to_user_id" : 265371167,
  "text" : "@alibi_ranch Hauptwache -&gt; Riedberg: 8.5 km, ~ 1h15min. Made it! :)",
  "id" : 446216595531399168,
  "in_reply_to_status_id" : 446208071451557888,
  "created_at" : "2014-03-19 09:28:21 +0000",
  "in_reply_to_screen_name" : "alibi_ranch",
  "in_reply_to_user_id_str" : "265371167",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 42 ],
      "url" : "http:\/\/t.co\/wyFFl8rIsO",
      "expanded_url" : "http:\/\/instagram.com\/p\/lt6lnYhwn2\/",
      "display_url" : "instagram.com\/p\/lt6lnYhwn2\/"
    } ]
  },
  "geo" : { },
  "id_str" : "446201001742434304",
  "text" : "Just what I needed. http:\/\/t.co\/wyFFl8rIsO",
  "id" : 446201001742434304,
  "created_at" : "2014-03-19 08:26:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0070418837, 8.2825746015 ]
  },
  "id_str" : "446183262596399104",
  "text" : "2.5 hours of sleep &amp; day starts with me being informed that I\u2019m now in charge of handling bureaucracy. Test driving stoicism at the limit.",
  "id" : 446183262596399104,
  "created_at" : "2014-03-19 07:15:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 63, 69 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00966165, 8.2830180883 ]
  },
  "id_str" : "446094456367104000",
  "text" : "After clicking on all those Amazon links to sex toys posted by @Lobot I now get weird product recommendations: tons of XLR to Jack adaptors\u2026",
  "id" : 446094456367104000,
  "created_at" : "2014-03-19 01:23:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 14, 23 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "446066141845131264",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00966165, 8.2830180883 ]
  },
  "id_str" : "446067464292814848",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @Senficon not directly, but I guess in a way \u201Cliving abroad\u201D is a typical science topic?",
  "id" : 446067464292814848,
  "in_reply_to_status_id" : 446066141845131264,
  "created_at" : "2014-03-18 23:35:45 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Impact Ethics",
      "screen_name" : "ImpactEthics",
      "indices" : [ 3, 16 ],
      "id_str" : "932367882",
      "id" : 932367882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 79 ],
      "url" : "http:\/\/t.co\/O3WFhhQL4h",
      "expanded_url" : "http:\/\/wp.me\/p38o3S-je",
      "display_url" : "wp.me\/p38o3S-je"
    } ]
  },
  "geo" : { },
  "id_str" : "446044490625601536",
  "text" : "RT @ImpactEthics: On Silence in the Dan Markingson Case, http:\/\/t.co\/O3WFhhQL4h",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 39, 61 ],
        "url" : "http:\/\/t.co\/O3WFhhQL4h",
        "expanded_url" : "http:\/\/wp.me\/p38o3S-je",
        "display_url" : "wp.me\/p38o3S-je"
      } ]
    },
    "geo" : { },
    "id_str" : "445963643361169408",
    "text" : "On Silence in the Dan Markingson Case, http:\/\/t.co\/O3WFhhQL4h",
    "id" : 445963643361169408,
    "created_at" : "2014-03-18 16:43:12 +0000",
    "user" : {
      "name" : "Impact Ethics",
      "screen_name" : "ImpactEthics",
      "protected" : false,
      "id_str" : "932367882",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2823008136\/cb1de1b6cc23d8e1b49429e5cbe5c95f_normal.png",
      "id" : 932367882,
      "verified" : false
    }
  },
  "id" : 446044490625601536,
  "created_at" : "2014-03-18 22:04:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "446027534309003264",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0129191265, 8.2775087689 ]
  },
  "id_str" : "446028396532088832",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot chance favors the prepared mind \u2014 Louis Pasteur iirc ;)",
  "id" : 446028396532088832,
  "in_reply_to_status_id" : 446027534309003264,
  "created_at" : "2014-03-18 21:00:31 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "446020396610240513",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095703567, 8.2829421317 ]
  },
  "id_str" : "446022337629286401",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC oh yes, please! (you had me at \u03BA)",
  "id" : 446022337629286401,
  "in_reply_to_status_id" : 446020396610240513,
  "created_at" : "2014-03-18 20:36:26 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "446016499523014656",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095703567, 8.2829421317 ]
  },
  "id_str" : "446018272312721408",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC oh, we\u2019re even doing independent note keeping, so we can check for inter-rater reliability!",
  "id" : 446018272312721408,
  "in_reply_to_status_id" : 446016499523014656,
  "created_at" : "2014-03-18 20:20:17 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095703567, 8.2829421317 ]
  },
  "id_str" : "446012708958527488",
  "text" : "crashed into another customer at the supermarket because she and I were both too focussed on our flawless air guitar play w\/ headphones on.",
  "id" : 446012708958527488,
  "created_at" : "2014-03-18 19:58:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Effy Vayena",
      "screen_name" : "EffyVayena",
      "indices" : [ 3, 14 ],
      "id_str" : "397518511",
      "id" : 397518511
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "446008423130607616",
  "text" : "RT @EffyVayena: Guess what? Self-Citation Gender Gap:Female researchers don't self-cite  as often as their male colleagues. http:\/\/t.co\/XXR\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 108, 130 ],
        "url" : "http:\/\/t.co\/XXRWQ3Ws7X",
        "expanded_url" : "http:\/\/bit.ly\/1d9O7S9",
        "display_url" : "bit.ly\/1d9O7S9"
      } ]
    },
    "geo" : { },
    "id_str" : "446007530901483520",
    "text" : "Guess what? Self-Citation Gender Gap:Female researchers don't self-cite  as often as their male colleagues. http:\/\/t.co\/XXRWQ3Ws7X",
    "id" : 446007530901483520,
    "created_at" : "2014-03-18 19:37:36 +0000",
    "user" : {
      "name" : "Effy Vayena",
      "screen_name" : "EffyVayena",
      "protected" : false,
      "id_str" : "397518511",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/837580905615085568\/EBU1zR7D_normal.jpg",
      "id" : 397518511,
      "verified" : false
    }
  },
  "id" : 446008423130607616,
  "created_at" : "2014-03-18 19:41:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096620819, 8.2829161071 ]
  },
  "id_str" : "446004483773177856",
  "text" : "\u00ABNa, willst\u2019 Rubbellose?\u00BB \u2014 \u00ABNein danke. Als guter Statistiker kenne ich nicht nur von allem den Preis sondern auch den Erwartungswert.\u00BB",
  "id" : 446004483773177856,
  "created_at" : "2014-03-18 19:25:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "446003091624980480",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096620819, 8.2829161071 ]
  },
  "id_str" : "446003879126523905",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC in that case I request a second chance so I may get to the advanced level.",
  "id" : 446003879126523905,
  "in_reply_to_status_id" : 446003091624980480,
  "created_at" : "2014-03-18 19:23:05 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "445993144199680000",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0636356138, 8.4847626183 ]
  },
  "id_str" : "445998597029769216",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot nein, mit Kinderwunsch-Zweifeln. Oh, wait!",
  "id" : 445998597029769216,
  "in_reply_to_status_id" : 445993144199680000,
  "created_at" : "2014-03-18 19:02:06 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "445982841571377152",
  "text" : "\u00ABnext steps: go home and cry over my results\u00BB",
  "id" : 445982841571377152,
  "created_at" : "2014-03-18 17:59:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "445977367811747840",
  "geo" : { },
  "id_str" : "445978792784588801",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC oh, a one-handed variety! Is that the beginners or the advanced version?",
  "id" : 445978792784588801,
  "in_reply_to_status_id" : 445977367811747840,
  "created_at" : "2014-03-18 17:43:24 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "445946234487205888",
  "text" : "\u00ABWie wenig Vertrauen habt ihr eigentlich in mich?!\u00BB \u2013 \u00ABAllein die Verwendung des Worts 'Vertrauen' in diesem Zusammenhang beschmutzt es\u2026\u00BB",
  "id" : 445946234487205888,
  "created_at" : "2014-03-18 15:34:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "J\u00FCrgen Geuter",
      "screen_name" : "tante",
      "indices" : [ 3, 9 ],
      "id_str" : "14179278",
      "id" : 14179278
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 58, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 35, 57 ],
      "url" : "http:\/\/t.co\/HJbP07M12k",
      "expanded_url" : "http:\/\/skeletorislove.tumblr.com\/",
      "display_url" : "skeletorislove.tumblr.com"
    } ]
  },
  "geo" : { },
  "id_str" : "445920353169448960",
  "text" : "RT @tante: Heal yourself, Skeletor http:\/\/t.co\/HJbP07M12k #fb",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/hotot.org\" rel=\"nofollow\"\u003EHotot\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "fb",
        "indices" : [ 47, 50 ]
      } ],
      "urls" : [ {
        "indices" : [ 24, 46 ],
        "url" : "http:\/\/t.co\/HJbP07M12k",
        "expanded_url" : "http:\/\/skeletorislove.tumblr.com\/",
        "display_url" : "skeletorislove.tumblr.com"
      } ]
    },
    "geo" : { },
    "id_str" : "445900108593635328",
    "text" : "Heal yourself, Skeletor http:\/\/t.co\/HJbP07M12k #fb",
    "id" : 445900108593635328,
    "created_at" : "2014-03-18 12:30:44 +0000",
    "user" : {
      "name" : "J\u00FCrgen Geuter",
      "screen_name" : "tante",
      "protected" : false,
      "id_str" : "14179278",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/802837466512236544\/UiursIr__normal.jpg",
      "id" : 14179278,
      "verified" : true
    }
  },
  "id" : 445920353169448960,
  "created_at" : "2014-03-18 13:51:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 14, 23 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "445916002857922560",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723394809, 8.6276034121 ]
  },
  "id_str" : "445917289393958914",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @Senficon yeah, I remember how he was elected and all of my Australian followers suddenly cried out in terror.",
  "id" : 445917289393958914,
  "in_reply_to_status_id" : 445916002857922560,
  "created_at" : "2014-03-18 13:39:01 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 114, 127 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/AAA1rkg2eL",
      "expanded_url" : "http:\/\/royrapoport.blogspot.com.au\/2011\/05\/coffee-and-its-effects-on-feature-creep.html",
      "display_url" : "royrapoport.blogspot.com.au\/2011\/05\/coffee\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "445907386566721536",
  "text" : "\u00ABhow I set out to simplify ordering Starbucks and created an internal banking system.\u00BB http:\/\/t.co\/AAA1rkg2eL \/HT @PhilippBayer",
  "id" : 445907386566721536,
  "created_at" : "2014-03-18 12:59:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "445898202362150912",
  "text" : "psychological warfare @ lunch break: playing n-player rock-paper-scissors to determine who has to carry the trays back to the cafeteria.",
  "id" : 445898202362150912,
  "created_at" : "2014-03-18 12:23:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 71, 84 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 85, 94 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/5xqUxPgg5N",
      "expanded_url" : "http:\/\/boingboing.net\/2014\/03\/17\/julia-gillards-epic-anti-sex.html",
      "display_url" : "boingboing.net\/2014\/03\/17\/jul\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "445856628588703744",
  "text" : "Julia Gillard's epic anti-sexist Parliamentary speech set to music \/cc @PhilippBayer @Senficon http:\/\/t.co\/5xqUxPgg5N",
  "id" : 445856628588703744,
  "created_at" : "2014-03-18 09:37:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 59 ],
      "url" : "http:\/\/t.co\/T53gOqQOqi",
      "expanded_url" : "http:\/\/whatshouldwecallgradschool.tumblr.com\/post\/79654417034\/how-people-react-to-data",
      "display_url" : "whatshouldwecallgradschool.tumblr.com\/post\/796544170\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "445855225728229376",
  "text" : "Why I miss doing confocal microscopy http:\/\/t.co\/T53gOqQOqi",
  "id" : 445855225728229376,
  "created_at" : "2014-03-18 09:32:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0071512806, 8.2829252449 ]
  },
  "id_str" : "445827728391303168",
  "text" : "Academia, where you\u2019re constantly unsure whether people are residing in another time zone or also think 2am belongs to standard work hours.",
  "id" : 445827728391303168,
  "created_at" : "2014-03-18 07:43:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "445805284582105089",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.007393702, 8.2826929255 ]
  },
  "id_str" : "445826842738823168",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer ich w\u00FCrd sagen Do\/Fr oder Mo. Wer samstags unser Blog liest braucht vermutlich keine klugen Ratschl\u00E4ge von uns. ;)",
  "id" : 445826842738823168,
  "in_reply_to_status_id" : 445805284582105089,
  "created_at" : "2014-03-18 07:39:37 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/wLLZJjOXQQ",
      "expanded_url" : "http:\/\/chronicle.com\/article\/There-Must-Be-Some\/145273\/",
      "display_url" : "chronicle.com\/article\/There-\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00962973, 8.2829771563 ]
  },
  "id_str" : "445705865178673153",
  "text" : "the important role that misunderstood lyrics play in the way rock music works http:\/\/t.co\/wLLZJjOXQQ",
  "id" : 445705865178673153,
  "created_at" : "2014-03-17 23:38:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "445676386238218240",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00960555, 8.2828565467 ]
  },
  "id_str" : "445676449673252864",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer Ja, sollten wir dann nur drauf achten :)",
  "id" : 445676449673252864,
  "in_reply_to_status_id" : 445676386238218240,
  "created_at" : "2014-03-17 21:42:00 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00960555, 8.2828565467 ]
  },
  "id_str" : "445664863046864896",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer Mir f\u00E4llt jetzt erst auf wie sehr wie bei der \u00DCberschrift f\u00FCr den Post gefailt haben mit unseren Bestrebungen.",
  "id" : 445664863046864896,
  "created_at" : "2014-03-17 20:55:58 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1613913553, 8.6491899646 ]
  },
  "id_str" : "445630410354352128",
  "text" : "\u00ABWhat\u2019s Catch-22?\u00BB\u2014\u00ABIt\u2019s a satire about army bureaucracy.\u00BB\u2014\u00ABArmy? What\u2019s that got to do with us? We\u2019re in the Marine Corps, not the Army.\u00BB",
  "id" : 445630410354352128,
  "created_at" : "2014-03-17 18:39:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "445615945298751488",
  "geo" : { },
  "id_str" : "445618294985617408",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC just handing out recommendations without accompanying that with the book itself felt a bit insufficient after a while ;)",
  "id" : 445618294985617408,
  "in_reply_to_status_id" : 445615945298751488,
  "created_at" : "2014-03-17 17:50:55 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "445614883636514816",
  "geo" : { },
  "id_str" : "445615032324612096",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC I even got you a (print!!) book, just so you can practice!",
  "id" : 445615032324612096,
  "in_reply_to_status_id" : 445614883636514816,
  "created_at" : "2014-03-17 17:37:57 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "445612540140486656",
  "geo" : { },
  "id_str" : "445613514758320128",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC I tend to file those under \"skills that will come in handy after the apocalypse\".",
  "id" : 445613514758320128,
  "in_reply_to_status_id" : 445612540140486656,
  "created_at" : "2014-03-17 17:31:55 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    }, {
      "name" : "ToxX",
      "screen_name" : "ToxXInFlames",
      "indices" : [ 10, 23 ],
      "id_str" : "1421360166",
      "id" : 1421360166
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "445611760616493056",
  "geo" : { },
  "id_str" : "445612669295681536",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC @ToxXInFlames this is exactly who came to my mind when I read that comic. A more specialized version of xkcd's nerd sniping :p",
  "id" : 445612669295681536,
  "in_reply_to_status_id" : 445611760616493056,
  "created_at" : "2014-03-17 17:28:34 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hacker News 20",
      "screen_name" : "newsyc20",
      "indices" : [ 40, 49 ],
      "id_str" : "148969874",
      "id" : 148969874
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/blVnj9Ml4c",
      "expanded_url" : "http:\/\/doge2048.com\/",
      "display_url" : "doge2048.com"
    }, {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/xPDOSwg11B",
      "expanded_url" : "http:\/\/bit.ly\/NnAH8n",
      "display_url" : "bit.ly\/NnAH8n"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723195323, 8.6276177254 ]
  },
  "id_str" : "445589276760489984",
  "text" : "I\u2019ll be busy for the rest of the day RT @newsyc20: Doge2048 http:\/\/t.co\/blVnj9Ml4c (http:\/\/t.co\/xPDOSwg11B)",
  "id" : 445589276760489984,
  "created_at" : "2014-03-17 15:55:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723398455, 8.627610389 ]
  },
  "id_str" : "445569813587693568",
  "text" : "\u00ABAlter, was geht denn bei den Piraten?!\u00BB \u2014 \u00ABSo wie ich das sehe gehen die Spinner.\u00BB",
  "id" : 445569813587693568,
  "created_at" : "2014-03-17 14:38:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 7, 29 ],
      "url" : "http:\/\/t.co\/cFS0kq4R3I",
      "expanded_url" : "http:\/\/www.smbc-comics.com\/index.php?db=comics&id=3296",
      "display_url" : "smbc-comics.com\/index.php?db=c\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "445558328102748160",
  "text" : "crypto http:\/\/t.co\/cFS0kq4R3I",
  "id" : 445558328102748160,
  "created_at" : "2014-03-17 13:52:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "445544441164484608",
  "geo" : { },
  "id_str" : "445544740659159040",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer \u00ABIch wusste schon immer das du der lagging und nicht der leading strand bist\u2026\u00BB",
  "id" : 445544740659159040,
  "in_reply_to_status_id" : 445544441164484608,
  "created_at" : "2014-03-17 12:58:38 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "445543300855255040",
  "text" : "\u00ABWenn ich Kinder bekomme nenne ich sie wie meine Primer\u00BB \u2013 \u00ABIch hoffe du bekommst nur Zwillinge damit du sie Forward\/Reverse nennen kannst.\u00BB",
  "id" : 445543300855255040,
  "created_at" : "2014-03-17 12:52:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 41 ],
      "url" : "http:\/\/t.co\/Mu5IYSAtPw",
      "expanded_url" : "http:\/\/boingboing.net\/2014\/03\/15\/how-to-open-a-book.html",
      "display_url" : "boingboing.net\/2014\/03\/15\/how\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "445537827653423104",
  "text" : "How to open a book http:\/\/t.co\/Mu5IYSAtPw",
  "id" : 445537827653423104,
  "created_at" : "2014-03-17 12:31:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723238279, 8.6275998662 ]
  },
  "id_str" : "445534568360476672",
  "text" : "\u00ABAus dem Selbstvertrauen was mir der Schulterklopfer gegeben hat k\u00F6nnte ich eine eigene Band gr\u00FCnden!\u00BB",
  "id" : 445534568360476672,
  "created_at" : "2014-03-17 12:18:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723397775, 8.6276030792 ]
  },
  "id_str" : "445529085092331520",
  "text" : "\u00ABUnd was machst du als erstes wenn du ins Auto einsteigst?\u00BB \u2014 \u00ABBeten!\u00BB",
  "id" : 445529085092331520,
  "created_at" : "2014-03-17 11:56:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ana Nelson",
      "screen_name" : "ananelson",
      "indices" : [ 3, 13 ],
      "id_str" : "7381872",
      "id" : 7381872
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "445520556809805825",
  "text" : "RT @ananelson: I think the statisticians guild needs to make a complaint to border control agencies around the world at their flagrant abus\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "445310600856358912",
    "text" : "I think the statisticians guild needs to make a complaint to border control agencies around the world at their flagrant abuse of \"random\".",
    "id" : 445310600856358912,
    "created_at" : "2014-03-16 21:28:15 +0000",
    "user" : {
      "name" : "Ana Nelson",
      "screen_name" : "ananelson",
      "protected" : false,
      "id_str" : "7381872",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/835015972201213952\/5_i0AZtw_normal.jpg",
      "id" : 7381872,
      "verified" : false
    }
  },
  "id" : 445520556809805825,
  "created_at" : "2014-03-17 11:22:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 41, 54 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/3lzFtDjfBz",
      "expanded_url" : "http:\/\/www.scilogs.de\/bierologie\/was-man-als-bioinformatiker-so-wissen-sollte-teil-1\/",
      "display_url" : "scilogs.de\/bierologie\/was\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "445516337751027712",
  "text" : "Nach langer Pause gibt es einen Post von @PhilippBayer und mir: Was man als Bioinformatiker wissen sollte (Part 1) http:\/\/t.co\/3lzFtDjfBz",
  "id" : 445516337751027712,
  "created_at" : "2014-03-17 11:05:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096274346, 8.2829948975 ]
  },
  "id_str" : "445489768517087232",
  "text" : "\u00ABIch glaube ich hatte vorher noch nie einen Orgasmus w\u00E4hrend mich mein Partner angefurzt hat.\u00BB",
  "id" : 445489768517087232,
  "created_at" : "2014-03-17 09:20:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "reclamyournetzpartei",
      "indices" : [ 0, 21 ]
    } ],
    "urls" : [ {
      "indices" : [ 22, 44 ],
      "url" : "http:\/\/t.co\/NbZafrShfV",
      "expanded_url" : "http:\/\/www.reclam.de\/data\/cover\/978-3-15-018554-4.jpg",
      "display_url" : "reclam.de\/data\/cover\/978\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096694699, 8.2830357383 ]
  },
  "id_str" : "445334829362839552",
  "text" : "#reclamyournetzpartei http:\/\/t.co\/NbZafrShfV",
  "id" : 445334829362839552,
  "created_at" : "2014-03-16 23:04:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fintan O'Toolbox",
      "screen_name" : "FintanOToolbox",
      "indices" : [ 3, 18 ],
      "id_str" : "550976646",
      "id" : 550976646
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "445279824891105280",
  "text" : "RT @FintanOToolbox: Saint Patti's Day is a celebration of Saint Patti Smith, who brought punk rock to Ireland in the late 1970s and chased \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "444825509235814400",
    "text" : "Saint Patti's Day is a celebration of Saint Patti Smith, who brought punk rock to Ireland in the late 1970s and chased out the showbands.",
    "id" : 444825509235814400,
    "created_at" : "2014-03-15 13:20:40 +0000",
    "user" : {
      "name" : "Fintan O'Toolbox",
      "screen_name" : "FintanOToolbox",
      "protected" : false,
      "id_str" : "550976646",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/470529116538548224\/ZRmBVu-z_normal.png",
      "id" : 550976646,
      "verified" : false
    }
  },
  "id" : 445279824891105280,
  "created_at" : "2014-03-16 19:25:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1163912985, 8.6847141735 ]
  },
  "id_str" : "445265104230449152",
  "text" : "\u00ABDas rrrechts abbiegen war ein Befehl!\u00BB \u2014 \u00ABWarst wohl wieder zu viel im Br\u00E4unungscenter?!\u00BB",
  "id" : 445265104230449152,
  "created_at" : "2014-03-16 18:27:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00960555, 8.2828565467 ]
  },
  "id_str" : "445249913660932096",
  "text" : "\u00ABDarf ich dir in die Hose fassen?\u00BB \u2013 \u00ABJa, aber nicht so tief. Mein Muttermund tut noch weh vom letzten Mal.\u00BB",
  "id" : 445249913660932096,
  "created_at" : "2014-03-16 17:27:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "herr_schrat",
      "screen_name" : "herr_schrat",
      "indices" : [ 0, 12 ],
      "id_str" : "16066591",
      "id" : 16066591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "444906732012453889",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009582828, 8.2828994452 ]
  },
  "id_str" : "444908009836511234",
  "in_reply_to_user_id" : 16066591,
  "text" : "@herr_schrat mach das :)",
  "id" : 444908009836511234,
  "in_reply_to_status_id" : 444906732012453889,
  "created_at" : "2014-03-15 18:48:30 +0000",
  "in_reply_to_screen_name" : "herr_schrat",
  "in_reply_to_user_id_str" : "16066591",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "herr_schrat",
      "screen_name" : "herr_schrat",
      "indices" : [ 0, 12 ],
      "id_str" : "16066591",
      "id" : 16066591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "444906252431556608",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009582828, 8.2828994452 ]
  },
  "id_str" : "444906456786423808",
  "in_reply_to_user_id" : 16066591,
  "text" : "@herr_schrat da ist Ostermontag.",
  "id" : 444906456786423808,
  "in_reply_to_status_id" : 444906252431556608,
  "created_at" : "2014-03-15 18:42:19 +0000",
  "in_reply_to_screen_name" : "herr_schrat",
  "in_reply_to_user_id_str" : "16066591",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "herr_schrat",
      "screen_name" : "herr_schrat",
      "indices" : [ 0, 12 ],
      "id_str" : "16066591",
      "id" : 16066591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "444906019685421056",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009582828, 8.2828994452 ]
  },
  "id_str" : "444906272216084480",
  "in_reply_to_user_id" : 16066591,
  "text" : "@herr_schrat naja, wir kommen am 20. zur\u00FCck.",
  "id" : 444906272216084480,
  "in_reply_to_status_id" : 444906019685421056,
  "created_at" : "2014-03-15 18:41:35 +0000",
  "in_reply_to_screen_name" : "herr_schrat",
  "in_reply_to_user_id_str" : "16066591",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "herr_schrat",
      "screen_name" : "herr_schrat",
      "indices" : [ 0, 12 ],
      "id_str" : "16066591",
      "id" : 16066591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "444905401432420353",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095960394, 8.2829127259 ]
  },
  "id_str" : "444905796821073920",
  "in_reply_to_user_id" : 16066591,
  "text" : "@herr_schrat einfach 20\/21.04.?",
  "id" : 444905796821073920,
  "in_reply_to_status_id" : 444905401432420353,
  "created_at" : "2014-03-15 18:39:42 +0000",
  "in_reply_to_screen_name" : "herr_schrat",
  "in_reply_to_user_id_str" : "16066591",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095599331, 8.2826994918 ]
  },
  "id_str" : "444805413339688960",
  "text" : "\u00ABWas ist denn die Trikalenderation?\u00BB \u2014 \u00ABWenn 3 Polys ihre Google Calendar abgleichen um rauszufinden in welchem Bett sie gerade sind.\u00BB",
  "id" : 444805413339688960,
  "created_at" : "2014-03-15 12:00:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TV Secretes",
      "screen_name" : "BScenex",
      "indices" : [ 3, 11 ],
      "id_str" : "1021557368",
      "id" : 1021557368
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/BehindScenesPic\/status\/399727008168427520\/photo\/1",
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/8xNe2nDfID",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BYwdmJBCcAAoRMr.jpg",
      "id_str" : "399727008021639168",
      "id" : 399727008021639168,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BYwdmJBCcAAoRMr.jpg",
      "sizes" : [ {
        "h" : 398,
        "resize" : "fit",
        "w" : 599
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 398,
        "resize" : "fit",
        "w" : 599
      }, {
        "h" : 398,
        "resize" : "fit",
        "w" : 599
      }, {
        "h" : 398,
        "resize" : "fit",
        "w" : 599
      } ],
      "display_url" : "pic.twitter.com\/8xNe2nDfID"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "444803933689880576",
  "text" : "RT @BScenex: Behind the scenes of National Geographic . http:\/\/t.co\/8xNe2nDfID",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tweetadder.com\" rel=\"nofollow\"\u003ETweetAdder v4\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/BehindScenesPic\/status\/399727008168427520\/photo\/1",
        "indices" : [ 43, 65 ],
        "url" : "http:\/\/t.co\/8xNe2nDfID",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BYwdmJBCcAAoRMr.jpg",
        "id_str" : "399727008021639168",
        "id" : 399727008021639168,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BYwdmJBCcAAoRMr.jpg",
        "sizes" : [ {
          "h" : 398,
          "resize" : "fit",
          "w" : 599
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 398,
          "resize" : "fit",
          "w" : 599
        }, {
          "h" : 398,
          "resize" : "fit",
          "w" : 599
        }, {
          "h" : 398,
          "resize" : "fit",
          "w" : 599
        } ],
        "display_url" : "pic.twitter.com\/8xNe2nDfID"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "444645921486565376",
    "text" : "Behind the scenes of National Geographic . http:\/\/t.co\/8xNe2nDfID",
    "id" : 444645921486565376,
    "created_at" : "2014-03-15 01:27:03 +0000",
    "user" : {
      "name" : "TV Secretes",
      "screen_name" : "BScenex",
      "protected" : false,
      "id_str" : "1021557368",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/419365808179929088\/3lhq25G5_normal.jpeg",
      "id" : 1021557368,
      "verified" : false
    }
  },
  "id" : 444803933689880576,
  "created_at" : "2014-03-15 11:54:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "herr_schrat",
      "screen_name" : "herr_schrat",
      "indices" : [ 0, 12 ],
      "id_str" : "16066591",
      "id" : 16066591
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 13, 22 ],
      "id_str" : "14861745",
      "id" : 14861745
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 23, 29 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "444553626728804352",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009557209, 8.2828701474 ]
  },
  "id_str" : "444803370877206528",
  "in_reply_to_user_id" : 16066591,
  "text" : "@herr_schrat @Senficon @Lobot good thing das du dich mit Trikalendration auskennst.",
  "id" : 444803370877206528,
  "in_reply_to_status_id" : 444553626728804352,
  "created_at" : "2014-03-15 11:52:42 +0000",
  "in_reply_to_screen_name" : "herr_schrat",
  "in_reply_to_user_id_str" : "16066591",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096270958, 8.2828254512 ]
  },
  "id_str" : "444802840566185984",
  "text" : "\u00ABAus gesundheitlichen Gr\u00FCnden habe ich auf Zucker im Kaffee verzichtet. Oh, Moment, also eigentlich habe ich den Zucker nur nicht gefunden\u2026\u00BB",
  "id" : 444802840566185984,
  "created_at" : "2014-03-15 11:50:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 49.8720296499, 8.6524712753 ]
  },
  "id_str" : "444604951848050688",
  "text" : "\u00ABWoah, krass. Mein Kiefer tut jetzt voll weh.\u00BB \u2014 \u00ABOh, tut mir leid das du mich so fest gebissen hast.\u00BB",
  "id" : 444604951848050688,
  "created_at" : "2014-03-14 22:44:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    }, {
      "name" : "herr_schrat",
      "screen_name" : "herr_schrat",
      "indices" : [ 10, 22 ],
      "id_str" : "16066591",
      "id" : 16066591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "444549830476824576",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 49.8727144065, 8.6510630585 ]
  },
  "id_str" : "444552573404848128",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon @herr_schrat komm giess mein Glas noch einmal ein :)",
  "id" : 444552573404848128,
  "in_reply_to_status_id" : 444549830476824576,
  "created_at" : "2014-03-14 19:16:07 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Young Landis",
      "screen_name" : "younglandis",
      "indices" : [ 3, 15 ],
      "id_str" : "37837824",
      "id" : 37837824
    }, {
      "name" : "Buzz Hoot Roar",
      "screen_name" : "BuzzHootRoar",
      "indices" : [ 109, 122 ],
      "id_str" : "1897480711",
      "id" : 1897480711
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/1H86Yxs49r",
      "expanded_url" : "http:\/\/buzzhootroar.com\/taxonomy-puns-we-have-a-winner-part-5\/",
      "display_url" : "buzzhootroar.com\/taxonomy-puns-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "444507839244288000",
  "text" : "RT @younglandis: Love and breakup in the time of taxonomy... http:\/\/t.co\/1H86Yxs49r (my fav among winners of @BuzzHootRoar phylogenomc punf\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Buzz Hoot Roar",
        "screen_name" : "BuzzHootRoar",
        "indices" : [ 92, 105 ],
        "id_str" : "1897480711",
        "id" : 1897480711
      }, {
        "name" : "Natalie Sopinka",
        "screen_name" : "phishdoc",
        "indices" : [ 127, 136 ],
        "id_str" : "1955376680",
        "id" : 1955376680
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 44, 66 ],
        "url" : "http:\/\/t.co\/1H86Yxs49r",
        "expanded_url" : "http:\/\/buzzhootroar.com\/taxonomy-puns-we-have-a-winner-part-5\/",
        "display_url" : "buzzhootroar.com\/taxonomy-puns-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "444497716769329154",
    "text" : "Love and breakup in the time of taxonomy... http:\/\/t.co\/1H86Yxs49r (my fav among winners of @BuzzHootRoar phylogenomc punfest \/@phishdoc)",
    "id" : 444497716769329154,
    "created_at" : "2014-03-14 15:38:08 +0000",
    "user" : {
      "name" : "Ben Young Landis",
      "screen_name" : "younglandis",
      "protected" : false,
      "id_str" : "37837824",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000603782493\/88e45775f70d5a67c85dfb8456b67531_normal.jpeg",
      "id" : 37837824,
      "verified" : false
    }
  },
  "id" : 444507839244288000,
  "created_at" : "2014-03-14 16:18:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/FVCWgQnyYS",
      "expanded_url" : "http:\/\/boingboing.net\/2014\/03\/14\/game-creation-jam-to-be-ruled.html",
      "display_url" : "boingboing.net\/2014\/03\/14\/gam\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "444487154346262529",
  "text" : "\u00ABA sim game where you conceptualize awkwardness because it's the right thing to do.\u00BB (aka life) http:\/\/t.co\/FVCWgQnyYS",
  "id" : 444487154346262529,
  "created_at" : "2014-03-14 14:56:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722971332, 8.6276123169 ]
  },
  "id_str" : "444470661390802944",
  "text" : "\u00ABDon\u2019t argue against the unsorted pile of paper on my desk. It\u2019s art, my sculpture for celebrating 21st century retro futurism!\u00BB",
  "id" : 444470661390802944,
  "created_at" : "2014-03-14 13:50:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Finn",
      "screen_name" : "f_reddi",
      "indices" : [ 3, 11 ],
      "id_str" : "139984101",
      "id" : 139984101
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 53 ],
      "url" : "http:\/\/t.co\/eL28BoqIYS",
      "expanded_url" : "http:\/\/animalssuckingatjumping.tumblr.com\/",
      "display_url" : "animalssuckingatjumping.tumblr.com"
    } ]
  },
  "geo" : { },
  "id_str" : "444469387517759488",
  "text" : "RT @f_reddi: That made my day: http:\/\/t.co\/eL28BoqIYS :-D",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 18, 40 ],
        "url" : "http:\/\/t.co\/eL28BoqIYS",
        "expanded_url" : "http:\/\/animalssuckingatjumping.tumblr.com\/",
        "display_url" : "animalssuckingatjumping.tumblr.com"
      } ]
    },
    "geo" : { },
    "id_str" : "444419855853555712",
    "text" : "That made my day: http:\/\/t.co\/eL28BoqIYS :-D",
    "id" : 444419855853555712,
    "created_at" : "2014-03-14 10:28:45 +0000",
    "user" : {
      "name" : "Finn",
      "screen_name" : "f_reddi",
      "protected" : false,
      "id_str" : "139984101",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/614738170991800320\/MA-CzI2V_normal.jpg",
      "id" : 139984101,
      "verified" : false
    }
  },
  "id" : 444469387517759488,
  "created_at" : "2014-03-14 13:45:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ennomane",
      "screen_name" : "ennomane",
      "indices" : [ 30, 39 ],
      "id_str" : "850704103814705152",
      "id" : 850704103814705152
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 63 ],
      "url" : "http:\/\/t.co\/4Q4qbk4hod",
      "expanded_url" : "http:\/\/priceonomics.com\/who-wants-to-be-a-cyborg\/",
      "display_url" : "priceonomics.com\/who-wants-to-b\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.165178, 8.6433 ]
  },
  "id_str" : "444456712121376768",
  "text" : "Who Wants To Be a Cyborg? \/cc @ennomane  http:\/\/t.co\/4Q4qbk4hod",
  "id" : 444456712121376768,
  "created_at" : "2014-03-14 12:55:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 59 ],
      "url" : "http:\/\/t.co\/zR5SKVfbMI",
      "expanded_url" : "http:\/\/contemplatingcognition.wordpress.com\/2014\/03\/13\/676\/",
      "display_url" : "contemplatingcognition.wordpress.com\/2014\/03\/13\/676\/"
    } ]
  },
  "geo" : { },
  "id_str" : "444454948756287488",
  "text" : "Two sides to learning to think ahead http:\/\/t.co\/zR5SKVfbMI",
  "id" : 444454948756287488,
  "created_at" : "2014-03-14 12:48:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723085412, 8.6276007524 ]
  },
  "id_str" : "444422291460722688",
  "text" : "\u00ABHast du Kaffee auf dem Flur versch\u00FCttet?\u00BB\u2014\u00ABOh, wo du es sagst: Ein Blick auf mein T-Shirt sagt mir das deine Theorie korrekt sein k\u00F6nnte.\u00BB",
  "id" : 444422291460722688,
  "created_at" : "2014-03-14 10:38:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "444412508930322432",
  "text" : "give it some more days and my secret skill will be the ability to map NCBI taxonomy IDs to binomial names\u2026",
  "id" : 444412508930322432,
  "created_at" : "2014-03-14 09:59:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723209016, 8.6276191133 ]
  },
  "id_str" : "444400453330436096",
  "text" : "starting the day by getting lost. somehow i horizontally acquired my students\u2019 navigation skills",
  "id" : 444400453330436096,
  "created_at" : "2014-03-14 09:11:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "444261078499749888",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096660244, 8.2831215067 ]
  },
  "id_str" : "444263277464674304",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer godspeed!",
  "id" : 444263277464674304,
  "in_reply_to_status_id" : 444261078499749888,
  "created_at" : "2014-03-14 00:06:34 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "444255117840109569",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096578083, 8.28300015 ]
  },
  "id_str" : "444255190909485057",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez yes, so awesome! :)",
  "id" : 444255190909485057,
  "in_reply_to_status_id" : 444255117840109569,
  "created_at" : "2014-03-13 23:34:26 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joonas M\u00E4kinen",
      "screen_name" : "JoonasD6",
      "indices" : [ 35, 44 ],
      "id_str" : "43360175",
      "id" : 43360175
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/OpV56TUPLE",
      "expanded_url" : "http:\/\/youtu.be\/QEPHLPmt914",
      "display_url" : "youtu.be\/QEPHLPmt914"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096578083, 8.28300015 ]
  },
  "id_str" : "444247912424689664",
  "text" : "the melody is stuck in my head! MT @JoonasD6: &lt;3 I'd Like To Teach The World To Fap (In Perfect Harmony): http:\/\/t.co\/OpV56TUPLE",
  "id" : 444247912424689664,
  "created_at" : "2014-03-13 23:05:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "[\u02C8p\u028Cta\u02CCf\u0254\u028Ff\u0254\u028F]\u2014\u1E9E\u203D",
      "screen_name" : "PattaFeuFeu",
      "indices" : [ 0, 12 ],
      "id_str" : "36138023",
      "id" : 36138023
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "444211165435277312",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096525257, 8.28300851 ]
  },
  "id_str" : "444211273107255296",
  "in_reply_to_user_id" : 36138023,
  "text" : "@PattaFeuFeu indeed :)",
  "id" : 444211273107255296,
  "in_reply_to_status_id" : 444211165435277312,
  "created_at" : "2014-03-13 20:39:55 +0000",
  "in_reply_to_screen_name" : "PattaFeuFeu",
  "in_reply_to_user_id_str" : "36138023",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/444210870235971584\/photo\/1",
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/n5HdY6yv78",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BionbseIUAALkAG.png",
      "id_str" : "444210869996900352",
      "id" : 444210869996900352,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BionbseIUAALkAG.png",
      "sizes" : [ {
        "h" : 518,
        "resize" : "fit",
        "w" : 834
      }, {
        "h" : 518,
        "resize" : "fit",
        "w" : 834
      }, {
        "h" : 422,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 518,
        "resize" : "fit",
        "w" : 834
      } ],
      "display_url" : "pic.twitter.com\/n5HdY6yv78"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096525257, 8.28300851 ]
  },
  "id_str" : "444210870235971584",
  "text" : "what science taught me: it\u2019s always important to express yourself in a precise manner. http:\/\/t.co\/n5HdY6yv78",
  "id" : 444210870235971584,
  "created_at" : "2014-03-13 20:38:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "444202016890687488",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096525257, 8.28300851 ]
  },
  "id_str" : "444202265155760128",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC too bad it\u2019s non-replicabe! 15 minutes after finding out about the problem and rebooting someone ass dialed me.",
  "id" : 444202265155760128,
  "in_reply_to_status_id" : 444202016890687488,
  "created_at" : "2014-03-13 20:04:07 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0099759006, 8.4218238444 ]
  },
  "id_str" : "444197957379051520",
  "text" : "Managed to crash my smartphone in a way that it won\u2019t accept calls\/SMS but still transfers any other data. Would love to do that on purpose.",
  "id" : 444197957379051520,
  "created_at" : "2014-03-13 19:47:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0706992024, 8.4870658211 ]
  },
  "id_str" : "444195374597959680",
  "text" : "The Mad Hattersheim",
  "id" : 444195374597959680,
  "created_at" : "2014-03-13 19:36:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Yoder \uD83D\uDD96\uD83C\uDFFB",
      "screen_name" : "JBYoder",
      "indices" : [ 3, 11 ],
      "id_str" : "19984919",
      "id" : 19984919
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "444194433161261056",
  "text" : "RT @JBYoder: \u201CWhat do you say we get some romantic, heterosexual music going \u2026? I\u2019ll ask the d.j. to play any song ever recorded.\u201D http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/yzlQssZMnS",
        "expanded_url" : "http:\/\/www.newyorker.com\/online\/blogs\/shouts\/2014\/02\/the-heterosexual-agenda.html",
        "display_url" : "newyorker.com\/online\/blogs\/s\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "443224637451669504",
    "text" : "\u201CWhat do you say we get some romantic, heterosexual music going \u2026? I\u2019ll ask the d.j. to play any song ever recorded.\u201D http:\/\/t.co\/yzlQssZMnS",
    "id" : 443224637451669504,
    "created_at" : "2014-03-11 03:19:22 +0000",
    "user" : {
      "name" : "Jeremy Yoder \uD83D\uDD96\uD83C\uDFFB",
      "screen_name" : "JBYoder",
      "protected" : false,
      "id_str" : "19984919",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/870850169759072256\/r0kxCgGs_normal.jpg",
      "id" : 19984919,
      "verified" : true
    }
  },
  "id" : 444194433161261056,
  "created_at" : "2014-03-13 19:33:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Frightened Rabbit",
      "screen_name" : "FRabbits",
      "indices" : [ 47, 56 ],
      "id_str" : "43200260",
      "id" : 43200260
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1528572011, 8.6612688735 ]
  },
  "id_str" : "444184823671033856",
  "text" : "\u00ABOkay, we will take this flat. But only if the @FRabbits poster stays on the wall!\u00BB",
  "id" : 444184823671033856,
  "created_at" : "2014-03-13 18:54:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 66 ],
      "url" : "http:\/\/t.co\/3OZix0cguk",
      "expanded_url" : "http:\/\/web.mit.edu\/newsoffice\/2014\/soft-robotic-fish-moves-like-the-real-thing-0313.html",
      "display_url" : "web.mit.edu\/newsoffice\/201\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "444152186952744961",
  "text" : "Soft robotic fish moves like the real thing http:\/\/t.co\/3OZix0cguk",
  "id" : 444152186952744961,
  "created_at" : "2014-03-13 16:45:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/kB3fdFIk6J",
      "expanded_url" : "http:\/\/mindhacks.com\/2014\/03\/13\/loving-you-is-easy-because-youre-beautiful\/",
      "display_url" : "mindhacks.com\/2014\/03\/13\/lov\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "444150605138128896",
  "text" : "\u00ABIt\u2019s as if the rave generation stumbled out of life\u2019s warehouse at 7am and ended up being neuroscientists.\u00BB http:\/\/t.co\/kB3fdFIk6J",
  "id" : 444150605138128896,
  "created_at" : "2014-03-13 16:38:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723343479, 8.6276341745 ]
  },
  "id_str" : "444140080157184000",
  "text" : "\u00ABYour search for that data set might work better if you\u2019d spell it correctly. It\u2019s \u2018CEGMA\u2019, not \u2018smegma\u2019\u2026\u00BB",
  "id" : 444140080157184000,
  "created_at" : "2014-03-13 15:57:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722889211, 8.6276469511 ]
  },
  "id_str" : "444118998247309312",
  "text" : "\u00ABRemember: here \u2018fps\u2019 means \u2018facepalms per second\u2019.\u00BB",
  "id" : 444118998247309312,
  "created_at" : "2014-03-13 14:33:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/www.thunderclap.it\" rel=\"nofollow\"\u003EThunderclap\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "supportdnadigest",
      "indices" : [ 96, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/oZjnKa9wU6",
      "expanded_url" : "http:\/\/thndr.it\/1jLUytb",
      "display_url" : "thndr.it\/1jLUytb"
    } ]
  },
  "geo" : { },
  "id_str" : "444095762486820864",
  "text" : "Genetic disease could affect anybody, please support us to reach everyone for faster treatments #supportdnadigest  http:\/\/t.co\/oZjnKa9wU6",
  "id" : 444095762486820864,
  "created_at" : "2014-03-13 13:00:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "444044385752449024",
  "text" : "\u00ABYour work today is best described as being lack-cluster\u2026\u00BB",
  "id" : 444044385752449024,
  "created_at" : "2014-03-13 09:36:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tatjana Scheffler",
      "screen_name" : "tschfflr",
      "indices" : [ 0, 9 ],
      "id_str" : "313810815",
      "id" : 313810815
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/WdLZ4rIVBv",
      "expanded_url" : "http:\/\/en.m.wikipedia.org\/wiki\/Sexually_induced_sneezing",
      "display_url" : "en.m.wikipedia.org\/wiki\/Sexually_\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "444035124083326976",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1725835074, 8.6276262906 ]
  },
  "id_str" : "444035967096483840",
  "in_reply_to_user_id" : 313810815,
  "text" : "@tschfflr there\u2019s at least one article about it on Pubmed. http:\/\/t.co\/WdLZ4rIVBv",
  "id" : 444035967096483840,
  "in_reply_to_status_id" : 444035124083326976,
  "created_at" : "2014-03-13 09:03:19 +0000",
  "in_reply_to_screen_name" : "tschfflr",
  "in_reply_to_user_id_str" : "313810815",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 62 ],
      "url" : "http:\/\/t.co\/WyjZSYJxYy",
      "expanded_url" : "http:\/\/flowingdata.com\/2014\/03\/12\/how-people-really-read-and-share-online\/",
      "display_url" : "flowingdata.com\/2014\/03\/12\/how\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172377, 8.62762 ]
  },
  "id_str" : "444019319941648384",
  "text" : "How people really read and share online http:\/\/t.co\/WyjZSYJxYy",
  "id" : 444019319941648384,
  "created_at" : "2014-03-13 07:57:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 73 ],
      "url" : "http:\/\/t.co\/unACLYheKQ",
      "expanded_url" : "http:\/\/feeds.boingboing.net\/~r\/boingboing\/iBag\/~3\/RX5Rl3lXpNc\/story01.htm",
      "display_url" : "feeds.boingboing.net\/~r\/boingboing\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "444015377669181440",
  "text" : "English mispronunciations that became common\u00A0usage http:\/\/t.co\/unACLYheKQ",
  "id" : 444015377669181440,
  "created_at" : "2014-03-13 07:41:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.152457828, 8.661691977 ]
  },
  "id_str" : "444014751828692992",
  "text" : "\u00AB[T]here isn\u2019t any qualitative difference between reporting detailed Methods and providing comprehensive Data\u00BB Yes, this!",
  "id" : 444014751828692992,
  "created_at" : "2014-03-13 07:39:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PLOS",
      "screen_name" : "PLOS",
      "indices" : [ 67, 72 ],
      "id_str" : "12819112",
      "id" : 12819112
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/u9uvoMZyOS",
      "expanded_url" : "http:\/\/feedproxy.google.com\/~r\/citationNeeded\/~3\/pui9zuO3hFo\/",
      "display_url" : "feedproxy.google.com\/~r\/citationNee\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.152458, 8.661692 ]
  },
  "id_str" : "444014303138807808",
  "text" : "A great post on why mandatory data sharing as suggested by the new @PLOS guidelines is a good thing after all. http:\/\/t.co\/u9uvoMZyOS",
  "id" : 444014303138807808,
  "created_at" : "2014-03-13 07:37:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0067361959, 8.283431051 ]
  },
  "id_str" : "444000957446496256",
  "text" : "Today\u2019s forecast: tons of seminars and meetings interspersed with bouts of actual productivity.",
  "id" : 444000957446496256,
  "created_at" : "2014-03-13 06:44:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "443901328213823488",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096525257, 8.28300851 ]
  },
  "id_str" : "443901549627322368",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC did we accidentally switch to UDP? :p",
  "id" : 443901549627322368,
  "in_reply_to_status_id" : 443901328213823488,
  "created_at" : "2014-03-13 00:09:11 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "443898137833250816",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096525257, 8.28300851 ]
  },
  "id_str" : "443898599861399553",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer I guess the german company was shut down on legal grounds faster than you can say \u2018Gendiagnostikgesetz\u2019.",
  "id" : 443898599861399553,
  "in_reply_to_status_id" : 443898137833250816,
  "created_at" : "2014-03-12 23:57:28 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "443897443151650816",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096525257, 8.28300851 ]
  },
  "id_str" : "443897853254316032",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer iirc there was also a student-startup in Munich which did a similar thing, looking at MHCs for \u2018compatibility\u2019.",
  "id" : 443897853254316032,
  "in_reply_to_status_id" : 443897443151650816,
  "created_at" : "2014-03-12 23:54:30 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "connectionacknowledged",
      "indices" : [ 40, 63 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "443896114455281664",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096525257, 8.28300851 ]
  },
  "id_str" : "443897173722529792",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC I\u2019ll take your word for it ;) #connectionacknowledged",
  "id" : 443897173722529792,
  "in_reply_to_status_id" : 443896114455281664,
  "created_at" : "2014-03-12 23:51:48 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "443896023950180352",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096525257, 8.28300851 ]
  },
  "id_str" : "443897002280378368",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer damn, I knew I shouldn\u2019t have deleted it. We could have been rich!",
  "id" : 443897002280378368,
  "in_reply_to_status_id" : 443896023950180352,
  "created_at" : "2014-03-12 23:51:07 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "443895445434417153",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096251563, 8.28300512 ]
  },
  "id_str" : "443896321188302848",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot being an award-winning scientist I can vouch that this accurately reflects how it\u2019s done in the lab!",
  "id" : 443896321188302848,
  "in_reply_to_status_id" : 443895445434417153,
  "created_at" : "2014-03-12 23:48:24 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "443895247978782721",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096251563, 8.28300512 ]
  },
  "id_str" : "443895763266191360",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer Well, we already do have a recommendation engine in place\u2026 Would just have to replace one dimension of the matrix with users\u2026",
  "id" : 443895763266191360,
  "in_reply_to_status_id" : 443895247978782721,
  "created_at" : "2014-03-12 23:46:11 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "443894873687879681",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096251563, 8.28300512 ]
  },
  "id_str" : "443895250978099200",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot customers also viewed: \u00ABFucking for Science: The Complete Series\u00BB",
  "id" : 443895250978099200,
  "in_reply_to_status_id" : 443894873687879681,
  "created_at" : "2014-03-12 23:44:09 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Science Web",
      "screen_name" : "TheScienceWeb",
      "indices" : [ 3, 17 ],
      "id_str" : "2315551122",
      "id" : 2315551122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/WI6A0IEFNZ",
      "expanded_url" : "http:\/\/wp.me\/p4ik2k-2v",
      "display_url" : "wp.me\/p4ik2k-2v"
    } ]
  },
  "geo" : { },
  "id_str" : "443893988937175040",
  "text" : "RT @TheScienceWeb: Stem cells created by dipping researchers in coffee http:\/\/t.co\/WI6A0IEFNZ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 52, 74 ],
        "url" : "http:\/\/t.co\/WI6A0IEFNZ",
        "expanded_url" : "http:\/\/wp.me\/p4ik2k-2v",
        "display_url" : "wp.me\/p4ik2k-2v"
      } ]
    },
    "geo" : { },
    "id_str" : "443754543914827777",
    "text" : "Stem cells created by dipping researchers in coffee http:\/\/t.co\/WI6A0IEFNZ",
    "id" : 443754543914827777,
    "created_at" : "2014-03-12 14:25:02 +0000",
    "user" : {
      "name" : "The Science Web",
      "screen_name" : "TheScienceWeb",
      "protected" : false,
      "id_str" : "2315551122",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/428172546672824320\/1lZmC7lz_normal.jpeg",
      "id" : 2315551122,
      "verified" : false
    }
  },
  "id" : 443893988937175040,
  "created_at" : "2014-03-12 23:39:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "443891280020795392",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096251563, 8.28300512 ]
  },
  "id_str" : "443892946694598656",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC oh, you want to go full-duplex? :p",
  "id" : 443892946694598656,
  "in_reply_to_status_id" : 443891280020795392,
  "created_at" : "2014-03-12 23:35:00 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "443889879366504448",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096251563, 8.28300512 ]
  },
  "id_str" : "443890453910663168",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC in that case I will have to work on my formal handshake.",
  "id" : 443890453910663168,
  "in_reply_to_status_id" : 443889879366504448,
  "created_at" : "2014-03-12 23:25:05 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "443885643849289728",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096251563, 8.28300512 ]
  },
  "id_str" : "443887314998398977",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC but if you meet me, have some courtesy, have some sympathy, and some taste\u2026 ;)",
  "id" : 443887314998398977,
  "in_reply_to_status_id" : 443885643849289728,
  "created_at" : "2014-03-12 23:12:37 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 72, 85 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/0CXig1izwv",
      "expanded_url" : "http:\/\/www.plosone.org\/article\/info%3Adoi%2F10.1371%2Fjournal.pone.0091722",
      "display_url" : "plosone.org\/article\/info%3\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096251563, 8.28300512 ]
  },
  "id_str" : "443878922741383168",
  "text" : "Linguistic Phylogenies Support Back-Migration from Beringia to Asia \/cc @PhilippBayer http:\/\/t.co\/0CXig1izwv",
  "id" : 443878922741383168,
  "created_at" : "2014-03-12 22:39:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "443874538288611328",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096251563, 8.28300512 ]
  },
  "id_str" : "443878079048736768",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC and I really hoped for the devil!",
  "id" : 443878079048736768,
  "in_reply_to_status_id" : 443874538288611328,
  "created_at" : "2014-03-12 22:35:55 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 10, 16 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "443872661996044288",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096251563, 8.28300512 ]
  },
  "id_str" : "443873712698585088",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC @Lobot I expected a bit more sympathy from someone who knows the \u2018deer in the headlight\u2019-situation from the deer\u2019s perspective. ;)",
  "id" : 443873712698585088,
  "in_reply_to_status_id" : 443872661996044288,
  "created_at" : "2014-03-12 22:18:34 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096251563, 8.28300512 ]
  },
  "id_str" : "443871782211444736",
  "text" : "Furthermore: 1 user (out of 79 users who gave this phenotype) shows \u2018sneezing induced by sexual ideation or orgasm\u2019.",
  "id" : 443871782211444736,
  "created_at" : "2014-03-12 22:10:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Neven Mrgan",
      "screen_name" : "mrgan",
      "indices" : [ 3, 9 ],
      "id_str" : "35293",
      "id" : 35293
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 74 ],
      "url" : "http:\/\/t.co\/zS5WlEPpg6",
      "expanded_url" : "http:\/\/ismyshiftkeyonornot.com",
      "display_url" : "ismyshiftkeyonornot.com"
    } ]
  },
  "geo" : { },
  "id_str" : "443870542987558912",
  "text" : "RT @mrgan: Confused by the iOS 7.1 shift-key state? http:\/\/t.co\/zS5WlEPpg6",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 41, 63 ],
        "url" : "http:\/\/t.co\/zS5WlEPpg6",
        "expanded_url" : "http:\/\/ismyshiftkeyonornot.com",
        "display_url" : "ismyshiftkeyonornot.com"
      } ]
    },
    "geo" : { },
    "id_str" : "443858458144563200",
    "text" : "Confused by the iOS 7.1 shift-key state? http:\/\/t.co\/zS5WlEPpg6",
    "id" : 443858458144563200,
    "created_at" : "2014-03-12 21:17:57 +0000",
    "user" : {
      "name" : "Neven Mrgan",
      "screen_name" : "mrgan",
      "protected" : false,
      "id_str" : "35293",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/925719886457847808\/Vuf2uyPY_normal.jpg",
      "id" : 35293,
      "verified" : true
    }
  },
  "id" : 443870542987558912,
  "created_at" : "2014-03-12 22:05:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "443868667617755137",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096251563, 8.28300512 ]
  },
  "id_str" : "443870404265140224",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot you want to make me feel safe by directing my thoughts to the fruit. But I know you\u2019re feeding on the fear of your date partners!",
  "id" : 443870404265140224,
  "in_reply_to_status_id" : 443868667617755137,
  "created_at" : "2014-03-12 22:05:25 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "443867063980138496",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096251563, 8.28300512 ]
  },
  "id_str" : "443868036911886337",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot guess it depends on who you ask. For me it\u2019s: No data, no date.",
  "id" : 443868036911886337,
  "in_reply_to_status_id" : 443867063980138496,
  "created_at" : "2014-03-12 21:56:01 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "A Queer Has No Name",
      "screen_name" : "memeticsexgod",
      "indices" : [ 0, 14 ],
      "id_str" : "1451060280",
      "id" : 1451060280
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "443866789999808512",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096251563, 8.28300512 ]
  },
  "id_str" : "443867511701131264",
  "in_reply_to_user_id" : 1451060280,
  "text" : "@memeticsexgod nope, I already checked your phenotypes.",
  "id" : 443867511701131264,
  "in_reply_to_status_id" : 443866789999808512,
  "created_at" : "2014-03-12 21:53:56 +0000",
  "in_reply_to_screen_name" : "memeticsexgod",
  "in_reply_to_user_id_str" : "1451060280",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096251563, 8.28300512 ]
  },
  "id_str" : "443866574324527104",
  "text" : "The closer I look into the phenotypes we collected so far the more I suspect that some users are indeed using openSNP for dating purposes.",
  "id" : 443866574324527104,
  "created_at" : "2014-03-12 21:50:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096251563, 8.28300512 ]
  },
  "id_str" : "443863615033315328",
  "text" : "Only a single openSNP user answered (and apparently created) the \u2018phenotype\u2019 regarding sex drive \u2013 with \u2018high\u2019 being the answer.",
  "id" : 443863615033315328,
  "created_at" : "2014-03-12 21:38:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096251563, 8.28300512 ]
  },
  "id_str" : "443862118312734720",
  "text" : "At least one openSNP user answered the \u201Cphenotype\u201D regarding the first spoken word with \u201CI\u2019m sexy and I know it\u201D.",
  "id" : 443862118312734720,
  "created_at" : "2014-03-12 21:32:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096251563, 8.28300512 ]
  },
  "id_str" : "443858003834716160",
  "text" : "Yet another account I will have forgotten about tomorrow\u2026 Could \u201CAcademic User Agreements\u201D be replaced with share-alike licenses already?",
  "id" : 443858003834716160,
  "created_at" : "2014-03-12 21:16:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096511885, 8.2830380002 ]
  },
  "id_str" : "443844144956731392",
  "text" : "\u00ABDu bist ja auch so ein Commons-Typ. Das ist ja auch nur ein fancy Name f\u00FCr Kommunismus.\u00BB \u2014 \u00ABVerrat das blo\u00DF nicht den Piraten!\u00BB",
  "id" : 443844144956731392,
  "created_at" : "2014-03-12 20:21:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "C\u24D0thal G\u24D0rvey",
      "screen_name" : "onetruecathal",
      "indices" : [ 0, 14 ],
      "id_str" : "16066596",
      "id" : 16066596
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "443820067151953920",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0072588937, 8.2830146738 ]
  },
  "id_str" : "443820843693768704",
  "in_reply_to_user_id" : 16066596,
  "text" : "@onetruecathal I wish doing a PhD would pay better so I could throw more money your way. :)",
  "id" : 443820843693768704,
  "in_reply_to_status_id" : 443820067151953920,
  "created_at" : "2014-03-12 18:48:29 +0000",
  "in_reply_to_screen_name" : "onetruecathal",
  "in_reply_to_user_id_str" : "16066596",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "C\u24D0thal G\u24D0rvey",
      "screen_name" : "onetruecathal",
      "indices" : [ 84, 98 ],
      "id_str" : "16066596",
      "id" : 16066596
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/mLwjgrrjxv",
      "expanded_url" : "http:\/\/www.indiegogo.com\/projects\/indiebb-your-first-gmo",
      "display_url" : "indiegogo.com\/projects\/indie\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "443804844185624576",
  "text" : "I really want to see this great DIYBio project get funded. Give \u2018your first GMO\u2019 by @onetruecathal a chance. http:\/\/t.co\/mLwjgrrjxv",
  "id" : 443804844185624576,
  "created_at" : "2014-03-12 17:44:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "443775379015471104",
  "text" : "\u00ABDu bist ja produktiv und spielst gar nicht mehr dieses Text-Adventure?\u00BB \u2013 \u00ABDoch, jetzt nur ein anderes: Perl.\u00BB",
  "id" : 443775379015471104,
  "created_at" : "2014-03-12 15:47:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "443752927455637504",
  "geo" : { },
  "id_str" : "443753348169478144",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot nope, this time they are hand-fed with unnamed, frozen mosquito larvae. So cute when they try to bite my fingers!",
  "id" : 443753348169478144,
  "in_reply_to_status_id" : 443752927455637504,
  "created_at" : "2014-03-12 14:20:17 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723432399, 8.6275991816 ]
  },
  "id_str" : "443751397042184193",
  "text" : "one of the perks of being the pet biologist at work: ending up being in charge of feeding the pufferfish!",
  "id" : 443751397042184193,
  "created_at" : "2014-03-12 14:12:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 141 ],
      "url" : "http:\/\/t.co\/bF04OZo4x9",
      "expanded_url" : "http:\/\/en.wikipedia.org\/wiki\/Isidore_of_Seville#Legacy",
      "display_url" : "en.wikipedia.org\/wiki\/Isidore_o\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "443738538975461376",
  "text" : "\u00ABOkay, I will have to reboot the machines\u2026\u00BB \u2013 \u00ABTime to turn religious for 5 minutes &amp; pray to Isidore of Seville.\u00BB http:\/\/t.co\/bF04OZo4x9",
  "id" : 443738538975461376,
  "created_at" : "2014-03-12 13:21:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "443733806861025280",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723745361, 8.6276096678 ]
  },
  "id_str" : "443734362300100608",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot so schlecht war die Ratte gar nicht! Nur schlecht gew\u00FCrzt!",
  "id" : 443734362300100608,
  "in_reply_to_status_id" : 443733806861025280,
  "created_at" : "2014-03-12 13:04:50 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723745361, 8.6276096678 ]
  },
  "id_str" : "443732901038157824",
  "text" : "\u00ABWe should learn Puerto Rico by Vaya Con Dios before going to the conference.\u00BB \u2014 \u00ABBest poster presentation ever!\u00BB",
  "id" : 443732901038157824,
  "created_at" : "2014-03-12 12:59:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723398087, 8.6276026334 ]
  },
  "id_str" : "443721828247556096",
  "text" : "\u00ABCould you advance 1,500\u20AC for the travel?\u00BB \u2014 \u00ABYou\u2019re paying me and thus should know the answer: nope, of course not!\u00BB",
  "id" : 443721828247556096,
  "created_at" : "2014-03-12 12:15:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723373396, 8.6276021122 ]
  },
  "id_str" : "443717353063604224",
  "text" : "From \u00ABit\u2019s a minor problem and should be fixed in 10 minutes\u00BB to \u00ABhas anyone seen our network documentation?!\u00BB in 3 simple steps\u2026",
  "id" : 443717353063604224,
  "created_at" : "2014-03-12 11:57:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mandi Bishop",
      "screen_name" : "MandiBPro",
      "indices" : [ 0, 10 ],
      "id_str" : "705287821",
      "id" : 705287821
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "443702172145176576",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723221073, 8.6276225698 ]
  },
  "id_str" : "443702558839021568",
  "in_reply_to_user_id" : 705287821,
  "text" : "@MandiBPro cool, let me know if you need any additional information. :)",
  "id" : 443702558839021568,
  "in_reply_to_status_id" : 443702172145176576,
  "created_at" : "2014-03-12 10:58:28 +0000",
  "in_reply_to_screen_name" : "MandiBPro",
  "in_reply_to_user_id_str" : "705287821",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 36 ],
      "url" : "http:\/\/t.co\/QRtpJgd3ox",
      "expanded_url" : "http:\/\/i.imgur.com\/Tl87SM6.jpg",
      "display_url" : "i.imgur.com\/Tl87SM6.jpg"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723221073, 8.6276225698 ]
  },
  "id_str" : "443702476706152448",
  "text" : "Every morning http:\/\/t.co\/QRtpJgd3ox",
  "id" : 443702476706152448,
  "created_at" : "2014-03-12 10:58:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mandi Bishop",
      "screen_name" : "MandiBPro",
      "indices" : [ 0, 10 ],
      "id_str" : "705287821",
      "id" : 705287821
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "443701008577753088",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723221073, 8.6276225698 ]
  },
  "id_str" : "443701869496770561",
  "in_reply_to_user_id" : 705287821,
  "text" : "@MandiBPro so did you nominate us? ;)",
  "id" : 443701869496770561,
  "in_reply_to_status_id" : 443701008577753088,
  "created_at" : "2014-03-12 10:55:43 +0000",
  "in_reply_to_screen_name" : "MandiBPro",
  "in_reply_to_user_id_str" : "705287821",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Webb",
      "screen_name" : "tomjwebb",
      "indices" : [ 3, 12 ],
      "id_str" : "153815481",
      "id" : 153815481
    }, {
      "name" : "Nature News&Comment",
      "screen_name" : "NatureNews",
      "indices" : [ 86, 97 ],
      "id_str" : "15862891",
      "id" : 15862891
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/yKTnP0gHZn",
      "expanded_url" : "http:\/\/www.nature.com\/news\/an-elegant-chaos-1.14849",
      "display_url" : "nature.com\/news\/an-elegan\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "443692633555496962",
  "text" : "RT @tomjwebb: \u201CEcology would be easy, were it not for all the ecosystems\u201D Really nice @NatureNews editorial http:\/\/t.co\/yKTnP0gHZn",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nature News&Comment",
        "screen_name" : "NatureNews",
        "indices" : [ 72, 83 ],
        "id_str" : "15862891",
        "id" : 15862891
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 94, 116 ],
        "url" : "http:\/\/t.co\/yKTnP0gHZn",
        "expanded_url" : "http:\/\/www.nature.com\/news\/an-elegant-chaos-1.14849",
        "display_url" : "nature.com\/news\/an-elegan\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "443681843297406976",
    "text" : "\u201CEcology would be easy, were it not for all the ecosystems\u201D Really nice @NatureNews editorial http:\/\/t.co\/yKTnP0gHZn",
    "id" : 443681843297406976,
    "created_at" : "2014-03-12 09:36:09 +0000",
    "user" : {
      "name" : "Tom Webb",
      "screen_name" : "tomjwebb",
      "protected" : false,
      "id_str" : "153815481",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/844283136561336320\/JjpO9SM3_normal.jpg",
      "id" : 153815481,
      "verified" : false
    }
  },
  "id" : 443692633555496962,
  "created_at" : "2014-03-12 10:19:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722818608, 8.6276212119 ]
  },
  "id_str" : "443690942101733376",
  "text" : "\u00ABSind eure Rechner auch alle eingefroren?\u00BB\u2014\u00ABAlso bei mir geht fast nichts mehr, nur der 3D-Plot von dem mir schlecht wird rotiert noch frei\u00BB",
  "id" : 443690942101733376,
  "created_at" : "2014-03-12 10:12:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 89, 102 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/HNVbHHxya1",
      "expanded_url" : "http:\/\/blogs.biomedcentral.com\/bmcblog\/2014\/03\/11\/sorting-the-neurotrash\/",
      "display_url" : "blogs.biomedcentral.com\/bmcblog\/2014\/0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "443688228999405569",
  "text" : "How-To: detect bad, overselling journalism about neuroscience http:\/\/t.co\/HNVbHHxya1 \/HT @PhilippBayer",
  "id" : 443688228999405569,
  "created_at" : "2014-03-12 10:01:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/nARVu5D5wJ",
      "expanded_url" : "http:\/\/xkcd.com\/1341\/",
      "display_url" : "xkcd.com\/1341\/"
    } ]
  },
  "geo" : { },
  "id_str" : "443679385389129729",
  "text" : "For vim the machine of death-mode is enabled by default http:\/\/t.co\/nARVu5D5wJ",
  "id" : 443679385389129729,
  "created_at" : "2014-03-12 09:26:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "443677362774097921",
  "text" : "\u00ABI guess he has already let pass by too many chances to kill me. Sunk cost &amp; all\u00BB Comforting to see others also using that line of reasoning",
  "id" : 443677362774097921,
  "created_at" : "2014-03-12 09:18:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 46 ],
      "url" : "https:\/\/t.co\/JfT5urPOnZ",
      "expanded_url" : "https:\/\/books.google.com\/ngrams\/graph?content=these+uncertain+times&case_insensitive=on&year_start=1800&year_end=2000&corpus=15&smoothing=3",
      "display_url" : "books.google.com\/ngrams\/graph?c\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1401127028, 8.6699126034 ]
  },
  "id_str" : "443668103768326144",
  "text" : "These uncertain times\u2026 https:\/\/t.co\/JfT5urPOnZ",
  "id" : 443668103768326144,
  "created_at" : "2014-03-12 08:41:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0985506028, 8.5931719348 ]
  },
  "id_str" : "443662073068003328",
  "text" : "\u00AB\u2018See what happens\u2019, indeed, might be the motto of this entire approach to working &amp; living, &amp; it\u2019s a hard-headed message, not a woolly one\u00BB",
  "id" : 443662073068003328,
  "created_at" : "2014-03-12 08:17:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Juul",
      "screen_name" : "Juul",
      "indices" : [ 3, 8 ],
      "id_str" : "3783241",
      "id" : 3783241
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/b7looJxtLR",
      "expanded_url" : "http:\/\/www.indiegogo.com\/projects\/indiebb-your-first-gmo",
      "display_url" : "indiegogo.com\/projects\/indie\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "443653192803684352",
  "text" : "RT @Juul: Get your very own biohacking kit! Make your own green fluorescent GMO! Only 53 hours left on indiegogo http:\/\/t.co\/b7looJxtLR @on\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "C\u24D0thal G\u24D0rvey",
        "screen_name" : "onetruecathal",
        "indices" : [ 126, 140 ],
        "id_str" : "16066596",
        "id" : 16066596
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 103, 125 ],
        "url" : "http:\/\/t.co\/b7looJxtLR",
        "expanded_url" : "http:\/\/www.indiegogo.com\/projects\/indiebb-your-first-gmo",
        "display_url" : "indiegogo.com\/projects\/indie\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "443563274135961600",
    "text" : "Get your very own biohacking kit! Make your own green fluorescent GMO! Only 53 hours left on indiegogo http:\/\/t.co\/b7looJxtLR @onetruecathal",
    "id" : 443563274135961600,
    "created_at" : "2014-03-12 01:45:00 +0000",
    "user" : {
      "name" : "Juul",
      "screen_name" : "Juul",
      "protected" : false,
      "id_str" : "3783241",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/43556122\/indirectly_heated_triode_normal.png",
      "id" : 3783241,
      "verified" : false
    }
  },
  "id" : 443653192803684352,
  "created_at" : "2014-03-12 07:42:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andreas Sj\u00F6din",
      "screen_name" : "druvus",
      "indices" : [ 3, 10 ],
      "id_str" : "133239513",
      "id" : 133239513
    }, {
      "name" : "Mick Watson",
      "screen_name" : "BioMickWatson",
      "indices" : [ 102, 116 ],
      "id_str" : "228586748",
      "id" : 228586748
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/xK0X1YXPlK",
      "expanded_url" : "http:\/\/bit.ly\/1eq4qF6",
      "display_url" : "bit.ly\/1eq4qF6"
    } ]
  },
  "geo" : { },
  "id_str" : "443552220899188736",
  "text" : "RT @druvus: Nice reading:The only core competency you're ever going to need http:\/\/t.co\/xK0X1YXPlK by @BioMickWatson",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Mick Watson",
        "screen_name" : "BioMickWatson",
        "indices" : [ 90, 104 ],
        "id_str" : "228586748",
        "id" : 228586748
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 64, 86 ],
        "url" : "http:\/\/t.co\/xK0X1YXPlK",
        "expanded_url" : "http:\/\/bit.ly\/1eq4qF6",
        "display_url" : "bit.ly\/1eq4qF6"
      } ]
    },
    "geo" : { },
    "id_str" : "443548264546443265",
    "text" : "Nice reading:The only core competency you're ever going to need http:\/\/t.co\/xK0X1YXPlK by @BioMickWatson",
    "id" : 443548264546443265,
    "created_at" : "2014-03-12 00:45:21 +0000",
    "user" : {
      "name" : "Andreas Sj\u00F6din",
      "screen_name" : "druvus",
      "protected" : false,
      "id_str" : "133239513",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/477564580622004225\/gIG7wf6l_normal.jpeg",
      "id" : 133239513,
      "verified" : false
    }
  },
  "id" : 443552220899188736,
  "created_at" : "2014-03-12 01:01:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jake Adelstein\/\u4E2D\u672C\u54F2\u53F2",
      "screen_name" : "jakeadelstein",
      "indices" : [ 3, 17 ],
      "id_str" : "87795485",
      "id" : 87795485
    }, {
      "name" : "Existential Comics",
      "screen_name" : "existentialcoms",
      "indices" : [ 49, 65 ],
      "id_str" : "2163374389",
      "id" : 2163374389
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/xLNffcKPDq",
      "expanded_url" : "http:\/\/existentialcomics.com\/comic\/19",
      "display_url" : "existentialcomics.com\/comic\/19"
    } ]
  },
  "geo" : { },
  "id_str" : "443541532772421634",
  "text" : "RT @jakeadelstein: The Germans Play Monopoly via @existentialcoms - http:\/\/t.co\/xLNffcKPDq",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Existential Comics",
        "screen_name" : "existentialcoms",
        "indices" : [ 30, 46 ],
        "id_str" : "2163374389",
        "id" : 2163374389
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 49, 71 ],
        "url" : "http:\/\/t.co\/xLNffcKPDq",
        "expanded_url" : "http:\/\/existentialcomics.com\/comic\/19",
        "display_url" : "existentialcomics.com\/comic\/19"
      } ]
    },
    "geo" : { },
    "id_str" : "443540441921642496",
    "text" : "The Germans Play Monopoly via @existentialcoms - http:\/\/t.co\/xLNffcKPDq",
    "id" : 443540441921642496,
    "created_at" : "2014-03-12 00:14:16 +0000",
    "user" : {
      "name" : "Jake Adelstein\/\u4E2D\u672C\u54F2\u53F2",
      "screen_name" : "jakeadelstein",
      "protected" : false,
      "id_str" : "87795485",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/931779230668546054\/Pj2SFwhb_normal.jpg",
      "id" : 87795485,
      "verified" : true
    }
  },
  "id" : 443541532772421634,
  "created_at" : "2014-03-12 00:18:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "antidote",
      "indices" : [ 111, 120 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096251563, 8.28300512 ]
  },
  "id_str" : "443528959654113281",
  "text" : "\u00ABAs the Buddha said 2 1\/2 thousand years ago, we\u2019re all out of our fucking minds! That\u2019s just the way we are.\u00BB #antidote",
  "id" : 443528959654113281,
  "created_at" : "2014-03-11 23:28:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shit Academics Say",
      "screen_name" : "AcademicsSay",
      "indices" : [ 3, 16 ],
      "id_str" : "1891806212",
      "id" : 1891806212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "443527005729226752",
  "text" : "RT @AcademicsSay: One weird trick for writing a dissertation: Writing.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "443526860635668480",
    "text" : "One weird trick for writing a dissertation: Writing.",
    "id" : 443526860635668480,
    "created_at" : "2014-03-11 23:20:18 +0000",
    "user" : {
      "name" : "Shit Academics Say",
      "screen_name" : "AcademicsSay",
      "protected" : false,
      "id_str" : "1891806212",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/748151916836716546\/Ldn_dhiC_normal.jpg",
      "id" : 1891806212,
      "verified" : false
    }
  },
  "id" : 443527005729226752,
  "created_at" : "2014-03-11 23:20:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 65 ],
      "url" : "http:\/\/t.co\/PbZ3rf5Gt8",
      "expanded_url" : "http:\/\/imgur.com\/gallery\/1eU2UEn",
      "display_url" : "imgur.com\/gallery\/1eU2UEn"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096251563, 8.28300512 ]
  },
  "id_str" : "443521113688403968",
  "text" : "how eating yogurt while bearded feels like http:\/\/t.co\/PbZ3rf5Gt8",
  "id" : 443521113688403968,
  "created_at" : "2014-03-11 22:57:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christine Corbett M.",
      "screen_name" : "corbett",
      "indices" : [ 3, 11 ],
      "id_str" : "143264018",
      "id" : 143264018
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 60 ],
      "url" : "http:\/\/t.co\/dX4rFux0NN",
      "expanded_url" : "http:\/\/arxiv.org\/pdf\/1403.1911.pdf",
      "display_url" : "arxiv.org\/pdf\/1403.1911.\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "443515154870042624",
  "text" : "RT @corbett: \"Candy Crush is NP Hard\" http:\/\/t.co\/dX4rFux0NN",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 25, 47 ],
        "url" : "http:\/\/t.co\/dX4rFux0NN",
        "expanded_url" : "http:\/\/arxiv.org\/pdf\/1403.1911.pdf",
        "display_url" : "arxiv.org\/pdf\/1403.1911.\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "443294706882314240",
    "text" : "\"Candy Crush is NP Hard\" http:\/\/t.co\/dX4rFux0NN",
    "id" : 443294706882314240,
    "created_at" : "2014-03-11 07:57:48 +0000",
    "user" : {
      "name" : "Christine Corbett M.",
      "screen_name" : "corbett",
      "protected" : false,
      "id_str" : "143264018",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/906696582149447681\/s7tuTs_I_normal.jpg",
      "id" : 143264018,
      "verified" : true
    }
  },
  "id" : 443515154870042624,
  "created_at" : "2014-03-11 22:33:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Austin Richardson",
      "screen_name" : "heyaudy",
      "indices" : [ 0, 8 ],
      "id_str" : "14534523",
      "id" : 14534523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "443507126749892610",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096251563, 8.28300512 ]
  },
  "id_str" : "443507310162640896",
  "in_reply_to_user_id" : 14534523,
  "text" : "@heyaudy it\u2019s already dark over here, so no chance I will spot a closing one!",
  "id" : 443507310162640896,
  "in_reply_to_status_id" : 443507126749892610,
  "created_at" : "2014-03-11 22:02:37 +0000",
  "in_reply_to_screen_name" : "heyaudy",
  "in_reply_to_user_id_str" : "14534523",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Austin Richardson",
      "screen_name" : "heyaudy",
      "indices" : [ 0, 8 ],
      "id_str" : "14534523",
      "id" : 14534523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "443505934430900225",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096251563, 8.28300512 ]
  },
  "id_str" : "443506107160731648",
  "in_reply_to_user_id" : 14534523,
  "text" : "@heyaudy syntax error",
  "id" : 443506107160731648,
  "in_reply_to_status_id" : 443505934430900225,
  "created_at" : "2014-03-11 21:57:50 +0000",
  "in_reply_to_screen_name" : "heyaudy",
  "in_reply_to_user_id_str" : "14534523",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 73 ],
      "url" : "http:\/\/t.co\/GWUgdwYRPA",
      "expanded_url" : "http:\/\/massgenomics.org\/2014\/03\/variant-prioritization-in-rare-disorders.html?utm_source=feedburner&utm_medium=feed&utm_campaign=Feed%3A+Massgenomics+%28MassGenomics%29",
      "display_url" : "massgenomics.org\/2014\/03\/varian\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096251563, 8.28300512 ]
  },
  "id_str" : "443503918342234112",
  "text" : "Variant Prioritization in Rare Mendelian Disorders http:\/\/t.co\/GWUgdwYRPA",
  "id" : 443503918342234112,
  "created_at" : "2014-03-11 21:49:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ken Mortimer",
      "screen_name" : "GranoblasticMan",
      "indices" : [ 0, 16 ],
      "id_str" : "20163160",
      "id" : 20163160
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "443179594355867648",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096251563, 8.28300512 ]
  },
  "id_str" : "443497318428721152",
  "in_reply_to_user_id" : 20163160,
  "text" : "@GranoblasticMan as far as I know you\u2019re the first to comment on that! Glad you like it :)",
  "id" : 443497318428721152,
  "in_reply_to_status_id" : 443179594355867648,
  "created_at" : "2014-03-11 21:22:55 +0000",
  "in_reply_to_screen_name" : "GranoblasticMan",
  "in_reply_to_user_id_str" : "20163160",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095352132, 8.2829320268 ]
  },
  "id_str" : "443483360372219904",
  "text" : "\u00ABWir die selbstdesignten Plugs sowieso st\u00E4ndig inkontinenzbedingt tragen\u00BB\u2014\u00ABEine der sch\u00F6nsten mid-term Zukunftsvorstellungen die ich kenne!\u00BB",
  "id" : 443483360372219904,
  "created_at" : "2014-03-11 20:27:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.008402057, 8.2872594986 ]
  },
  "id_str" : "443473882549612544",
  "text" : "\u00ABIch hab verstanden ihr h\u00E4ttet euch gepr\u00FCgelt, aber du hast gev\u00F6gelt gesagt, oder?\u00BB \u2014 \u00ABSame difference, really.\u00BB",
  "id" : 443473882549612544,
  "created_at" : "2014-03-11 19:49:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/KcTNkhKs55",
      "expanded_url" : "http:\/\/instagram.com\/p\/laY50shwne\/",
      "display_url" : "instagram.com\/p\/laY50shwne\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.005940563, 8.286528378 ]
  },
  "id_str" : "443468554114203648",
  "text" : "Going completely DIY with nail polish remover as acetone source. @ Elfenbeinturm http:\/\/t.co\/KcTNkhKs55",
  "id" : 443468554114203648,
  "created_at" : "2014-03-11 19:28:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0088731235, 8.2812469122 ]
  },
  "id_str" : "443461810159906816",
  "text" : "\u00ABJetzt bin ich fast vor einen Pfahl gelaufen w\u00E4hrend ich twittern wollte wie sch\u00F6n es drau\u00DFen ist\u2026\u00BB",
  "id" : 443461810159906816,
  "created_at" : "2014-03-11 19:01:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 49.9929479956, 8.3561944255 ]
  },
  "id_str" : "443456492134748160",
  "text" : "On Stoics\u2019 mindset: \u00ABIt could always conceivably be worse. If you\u2019re tortured to death slowly, you could always be tortured to death slower\u00BB",
  "id" : 443456492134748160,
  "created_at" : "2014-03-11 18:40:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Neuro Bonkers",
      "screen_name" : "neurobonkers",
      "indices" : [ 3, 16 ],
      "id_str" : "790563710951718913",
      "id" : 790563710951718913
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/usg7yfHi6v",
      "expanded_url" : "http:\/\/www.publish.csiro.au\/?paper=SH13181",
      "display_url" : "publish.csiro.au\/?paper=SH13181"
    } ]
  },
  "geo" : { },
  "id_str" : "443430258176692224",
  "text" : "RT @neurobonkers: BREAKING NEWS: \"Being drunk and high during sex is not associated with condom use behaviours\" http:\/\/t.co\/usg7yfHi6v",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 94, 116 ],
        "url" : "http:\/\/t.co\/usg7yfHi6v",
        "expanded_url" : "http:\/\/www.publish.csiro.au\/?paper=SH13181",
        "display_url" : "publish.csiro.au\/?paper=SH13181"
      } ]
    },
    "geo" : { },
    "id_str" : "443421091999260672",
    "text" : "BREAKING NEWS: \"Being drunk and high during sex is not associated with condom use behaviours\" http:\/\/t.co\/usg7yfHi6v",
    "id" : 443421091999260672,
    "created_at" : "2014-03-11 16:20:01 +0000",
    "user" : {
      "name" : "Simon Oxenham",
      "screen_name" : "simoxenham",
      "protected" : false,
      "id_str" : "134610558",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1604981312\/bwlur_normal.png",
      "id" : 134610558,
      "verified" : false
    }
  },
  "id" : 443430258176692224,
  "created_at" : "2014-03-11 16:56:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/x1LgKzgMT0",
      "expanded_url" : "http:\/\/www.nzherald.co.nz\/nz\/news\/article.cfm?c_id=1&objectid=11217129",
      "display_url" : "nzherald.co.nz\/nz\/news\/articl\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "443419647111880705",
  "text" : "why you shouldn't make too many assumptions while designing sign-up forms for your website: http:\/\/t.co\/x1LgKzgMT0",
  "id" : 443419647111880705,
  "created_at" : "2014-03-11 16:14:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "443411808146432000",
  "text" : "Playing first-person shooters since ~20 years &amp; never experienced motion sickness once. 2 1\/2 hours of doing 3D plots with R fixed that\u2026",
  "id" : 443411808146432000,
  "created_at" : "2014-03-11 15:43:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/RqMm3yXpLH",
      "expanded_url" : "http:\/\/arstechnica.com\/science\/2014\/03\/new-robotic-arm-opens-up-musical-worlds-for-cyborg-drummer\/",
      "display_url" : "arstechnica.com\/science\/2014\/0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "443408410424655872",
  "text" : "New robotic arm opens up musical worlds for \u201Ccyborg\u201D drummer http:\/\/t.co\/RqMm3yXpLH",
  "id" : 443408410424655872,
  "created_at" : "2014-03-11 15:29:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/dxtV4sBRc8",
      "expanded_url" : "http:\/\/www.bbc.co.uk\/programmes\/articles\/1g84m0sXpnNCv84GpN2PLZG\/the-hitchhiker-s-guide-to-the-galaxy-game-30th-anniversary-edition",
      "display_url" : "bbc.co.uk\/programmes\/art\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "443406099199557632",
  "text" : "\u00ABThe Hitchhiker's Guide to the Galaxy Game - 30th Anniversary Edition\u00BB And there goes my productivity http:\/\/t.co\/dxtV4sBRc8",
  "id" : 443406099199557632,
  "created_at" : "2014-03-11 15:20:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/BNVuaf07Fj",
      "expanded_url" : "http:\/\/what-if.xkcd.com\/87\/",
      "display_url" : "what-if.xkcd.com\/87\/"
    } ]
  },
  "geo" : { },
  "id_str" : "443401295723257857",
  "text" : "\u00ABusing nuclear strikes in response to traffic violations is probably overkill\u00BB http:\/\/t.co\/BNVuaf07Fj",
  "id" : 443401295723257857,
  "created_at" : "2014-03-11 15:01:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 67 ],
      "url" : "http:\/\/t.co\/Z7JxuqAk5V",
      "expanded_url" : "http:\/\/whatshouldwecallgradschool.tumblr.com\/post\/78762567220\/as-soon-as-the-seminar-starts",
      "display_url" : "whatshouldwecallgradschool.tumblr.com\/post\/787625672\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "443365980258197504",
  "text" : "i'm awake, i'm awake, i'm awake\u2026 where am i? http:\/\/t.co\/Z7JxuqAk5V",
  "id" : 443365980258197504,
  "created_at" : "2014-03-11 12:41:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "443365308397789184",
  "text" : "\u00ABOh Gott, seid ihr geil ihr zwei!\u00BB \u2013 \u00ABDas war zentraler Bestandteil unserer akademischen Ausbildung.\u00BB",
  "id" : 443365308397789184,
  "created_at" : "2014-03-11 12:38:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "443362335584161792",
  "geo" : { },
  "id_str" : "443362567000702976",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot \u00AB\u2026delete your Twitter account.\u00BB? ;)",
  "id" : 443362567000702976,
  "in_reply_to_status_id" : 443362335584161792,
  "created_at" : "2014-03-11 12:27:27 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/UOR74Ud8FJ",
      "expanded_url" : "http:\/\/codegolf.stackexchange.com\/questions\/23614\/trolling-the-troll",
      "display_url" : "codegolf.stackexchange.com\/questions\/2361\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "443361431053152258",
  "text" : "\u00ABA troll has captured you and is forcing you to write a malware\u2026\u00BB http:\/\/t.co\/UOR74Ud8FJ",
  "id" : 443361431053152258,
  "created_at" : "2014-03-11 12:22:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Weber",
      "screen_name" : "scy",
      "indices" : [ 0, 4 ],
      "id_str" : "8308632",
      "id" : 8308632
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "om10",
      "indices" : [ 21, 26 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "443358297346035713",
  "geo" : { },
  "id_str" : "443360516099293184",
  "in_reply_to_user_id" : 8308632,
  "text" : "@scy Das war f\u00FCr die #om10 auch gar nicht so leicht mit \u00ABA map of the world that doesn't contain Utopia isn't worth looking at.\u00BB",
  "id" : 443360516099293184,
  "in_reply_to_status_id" : 443358297346035713,
  "created_at" : "2014-03-11 12:19:18 +0000",
  "in_reply_to_screen_name" : "scy",
  "in_reply_to_user_id_str" : "8308632",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "443359046801051648",
  "text" : "\u00ABDer Compiler war schon durchgelaufen als er auf der Dachterrasse kam. Wait, that came out wrong.\u00BB",
  "id" : 443359046801051648,
  "created_at" : "2014-03-11 12:13:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Weber",
      "screen_name" : "scy",
      "indices" : [ 0, 4 ],
      "id_str" : "8308632",
      "id" : 8308632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "443357667818766337",
  "geo" : { },
  "id_str" : "443358093980991488",
  "in_reply_to_user_id" : 8308632,
  "text" : "@scy [x] pun found. Aber das soll hier auch nicht in fisting for compliments ausarten.",
  "id" : 443358093980991488,
  "in_reply_to_status_id" : 443357667818766337,
  "created_at" : "2014-03-11 12:09:41 +0000",
  "in_reply_to_screen_name" : "scy",
  "in_reply_to_user_id_str" : "8308632",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Weber",
      "screen_name" : "scy",
      "indices" : [ 0, 4 ],
      "id_str" : "8308632",
      "id" : 8308632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "443356849795252225",
  "geo" : { },
  "id_str" : "443357578442338305",
  "in_reply_to_user_id" : 8308632,
  "text" : "@scy \"challenge accepted\", \"try. something. new.\", \"Let's go exploring\" Wir hatten schon immer ein gutes H\u00E4ndchen bei der Mottowahl.",
  "id" : 443357578442338305,
  "in_reply_to_status_id" : 443356849795252225,
  "created_at" : "2014-03-11 12:07:38 +0000",
  "in_reply_to_screen_name" : "scy",
  "in_reply_to_user_id_str" : "8308632",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "om13",
      "indices" : [ 61, 66 ]
    }, {
      "text" : "om13gape",
      "indices" : [ 67, 76 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723506483, 8.6276214506 ]
  },
  "id_str" : "443354817902444545",
  "text" : "\u00ABZum ersten mal gefistet wurde ich in einer Jugendherberge!\u00BB #om13 #om13gape",
  "id" : 443354817902444545,
  "created_at" : "2014-03-11 11:56:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Austin Richardson",
      "screen_name" : "heyaudy",
      "indices" : [ 0, 8 ],
      "id_str" : "14534523",
      "id" : 14534523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "443165486516547584",
  "geo" : { },
  "id_str" : "443337660963495936",
  "in_reply_to_user_id" : 14534523,
  "text" : "@heyaudy I guess that depends. It's pretty easy to do and you know exactly who's to blame in case it doesn't work.",
  "id" : 443337660963495936,
  "in_reply_to_status_id" : 443165486516547584,
  "created_at" : "2014-03-11 10:48:29 +0000",
  "in_reply_to_screen_name" : "heyaudy",
  "in_reply_to_user_id_str" : "14534523",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.167257426, 8.6862907942 ]
  },
  "id_str" : "443151808765386752",
  "text" : "\u00ABIch glaube wir haben uns auseinandergelebt. Unsere content -curation strategies sind einfach nicht mehr kompatibel.\u00BB",
  "id" : 443151808765386752,
  "created_at" : "2014-03-10 22:29:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 6, 28 ],
      "url" : "http:\/\/t.co\/DnyOwiGgW3",
      "expanded_url" : "http:\/\/instagram.com\/p\/lXkxiRBwlS\/",
      "display_url" : "instagram.com\/p\/lXkxiRBwlS\/"
    } ]
  },
  "geo" : { },
  "id_str" : "443056807385518080",
  "text" : "drive http:\/\/t.co\/DnyOwiGgW3",
  "id" : 443056807385518080,
  "created_at" : "2014-03-10 16:12:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "443009849874739201",
  "text" : "signs of having gone overboard with ones calculations: submitting bash scripts to the cluster to remove all the qstat stdout logs\u2026",
  "id" : 443009849874739201,
  "created_at" : "2014-03-10 13:05:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "442957901192515584",
  "text" : "GO:0000666:help_i_trapped_myself_in_the_gene_ontology_while_recursively_traversing_the_tree",
  "id" : 442957901192515584,
  "created_at" : "2014-03-10 09:39:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "442943531376578560",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723509509, 8.6276307544 ]
  },
  "id_str" : "442944201316392960",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer ok, gib einfach laut via gtalk\/xmpp wenn wir noch mal zusammen dr\u00FCber sollen.",
  "id" : 442944201316392960,
  "in_reply_to_status_id" : 442943531376578560,
  "created_at" : "2014-03-10 08:45:01 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 72 ],
      "url" : "http:\/\/t.co\/Yqt1pV17wx",
      "expanded_url" : "http:\/\/whatshouldwecallgradschool.tumblr.com\/post\/79111841324",
      "display_url" : "whatshouldwecallgradschool.tumblr.com\/post\/791118413\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.153967, 8.66004 ]
  },
  "id_str" : "442935230954242048",
  "text" : "What I fear each time someone forwards me a paper http:\/\/t.co\/Yqt1pV17wx",
  "id" : 442935230954242048,
  "created_at" : "2014-03-10 08:09:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 56 ],
      "url" : "http:\/\/t.co\/N0HYtAMEM5",
      "expanded_url" : "http:\/\/www.vongestern.com\/2014\/03\/schicker-beruf-journalist-1978.html",
      "display_url" : "vongestern.com\/2014\/03\/schick\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.141887, 8.668873 ]
  },
  "id_str" : "442934235880759296",
  "text" : "Schicker Beruf: Journalist (1978) http:\/\/t.co\/N0HYtAMEM5",
  "id" : 442934235880759296,
  "created_at" : "2014-03-10 08:05:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "442829634405531648",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096570001, 8.2830286006 ]
  },
  "id_str" : "442832902012030976",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer still the complete opposite: \u2018whops, that\u2019s probably a bug in my script\u2019 &amp; after hours of hunting bugs the error was elsewhere",
  "id" : 442832902012030976,
  "in_reply_to_status_id" : 442829634405531648,
  "created_at" : "2014-03-10 01:22:45 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Death Star PR",
      "screen_name" : "DeathStarPR",
      "indices" : [ 3, 15 ],
      "id_str" : "157218534",
      "id" : 157218534
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/DeathStarPR\/status\/442831070635913216\/photo\/1",
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/EdMa1lih6s",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BiVAgzUCcAAAkwE.jpg",
      "id_str" : "442831070640107520",
      "id" : 442831070640107520,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BiVAgzUCcAAAkwE.jpg",
      "sizes" : [ {
        "h" : 361,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 361,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 361,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 361,
        "resize" : "fit",
        "w" : 500
      } ],
      "display_url" : "pic.twitter.com\/EdMa1lih6s"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "442831853247287296",
  "text" : "RT @DeathStarPR: KNEW we should have named it, the \"Super Happy Fun Times Laser Moon\". http:\/\/t.co\/EdMa1lih6s",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/DeathStarPR\/status\/442831070635913216\/photo\/1",
        "indices" : [ 70, 92 ],
        "url" : "http:\/\/t.co\/EdMa1lih6s",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BiVAgzUCcAAAkwE.jpg",
        "id_str" : "442831070640107520",
        "id" : 442831070640107520,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BiVAgzUCcAAAkwE.jpg",
        "sizes" : [ {
          "h" : 361,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 361,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 361,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 361,
          "resize" : "fit",
          "w" : 500
        } ],
        "display_url" : "pic.twitter.com\/EdMa1lih6s"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "442831070635913216",
    "text" : "KNEW we should have named it, the \"Super Happy Fun Times Laser Moon\". http:\/\/t.co\/EdMa1lih6s",
    "id" : 442831070635913216,
    "created_at" : "2014-03-10 01:15:29 +0000",
    "user" : {
      "name" : "Death Star PR",
      "screen_name" : "DeathStarPR",
      "protected" : false,
      "id_str" : "157218534",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3661409295\/bb35447683362ca080bd39f057a7216c_normal.jpeg",
      "id" : 157218534,
      "verified" : false
    }
  },
  "id" : 442831853247287296,
  "created_at" : "2014-03-10 01:18:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/FcRPK1trL5",
      "expanded_url" : "http:\/\/www.qwantz.com\/index.php?comic=2586",
      "display_url" : "qwantz.com\/index.php?comi\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009593418, 8.282956894 ]
  },
  "id_str" : "442789624017350657",
  "text" : "\u00ABviolent fights about semantics wherein our skin was broken, and in case you didn't notice, blood is extremely tasty\u00BB http:\/\/t.co\/FcRPK1trL5",
  "id" : 442789624017350657,
  "created_at" : "2014-03-09 22:30:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 4, 14 ],
      "id_str" : "14700783",
      "id" : 14700783
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 75, 88 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009593418, 8.282956894 ]
  },
  "id_str" : "442785586374782977",
  "text" : "Der @Fischblog wird vor Freude weinen (oder vor Schreck vom Stuhl fallen). @PhilippBayer &amp; ich schreiben mal wieder an einem Bierologiepost.",
  "id" : 442785586374782977,
  "created_at" : "2014-03-09 22:14:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NYT Opinion",
      "screen_name" : "nytopinion",
      "indices" : [ 3, 14 ],
      "id_str" : "16686144",
      "id" : 16686144
    }, {
      "name" : "Stoya",
      "screen_name" : "stoya",
      "indices" : [ 17, 23 ],
      "id_str" : "14241468",
      "id" : 14241468
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/NtHwr9Y1i7",
      "expanded_url" : "http:\/\/nyti.ms\/1h2bbPi",
      "display_url" : "nyti.ms\/1h2bbPi"
    } ]
  },
  "geo" : { },
  "id_str" : "442757201695105024",
  "text" : "RT @nytopinion: .@stoya has a few things to tell us about privacy http:\/\/t.co\/NtHwr9Y1i7",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Stoya",
        "screen_name" : "stoya",
        "indices" : [ 1, 7 ],
        "id_str" : "14241468",
        "id" : 14241468
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 50, 72 ],
        "url" : "http:\/\/t.co\/NtHwr9Y1i7",
        "expanded_url" : "http:\/\/nyti.ms\/1h2bbPi",
        "display_url" : "nyti.ms\/1h2bbPi"
      } ]
    },
    "geo" : { },
    "id_str" : "442751461429346304",
    "text" : ".@stoya has a few things to tell us about privacy http:\/\/t.co\/NtHwr9Y1i7",
    "id" : 442751461429346304,
    "created_at" : "2014-03-09 19:59:08 +0000",
    "user" : {
      "name" : "NYT Opinion",
      "screen_name" : "nytopinion",
      "protected" : false,
      "id_str" : "16686144",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/901810717803806720\/bv-ycBFs_normal.jpg",
      "id" : 16686144,
      "verified" : true
    }
  },
  "id" : 442757201695105024,
  "created_at" : "2014-03-09 20:21:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert Krause",
      "screen_name" : "euleule",
      "indices" : [ 0, 8 ],
      "id_str" : "563152502",
      "id" : 563152502
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "442749287056031744",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009593418, 8.282956894 ]
  },
  "id_str" : "442749745111793664",
  "in_reply_to_user_id" : 563152502,
  "text" : "@euleule Oh, congratulations!",
  "id" : 442749745111793664,
  "in_reply_to_status_id" : 442749287056031744,
  "created_at" : "2014-03-09 19:52:19 +0000",
  "in_reply_to_screen_name" : "euleule",
  "in_reply_to_user_id_str" : "563152502",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert Krause",
      "screen_name" : "euleule",
      "indices" : [ 0, 8 ],
      "id_str" : "563152502",
      "id" : 563152502
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "442744028631937024",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096458643, 8.2830323843 ]
  },
  "id_str" : "442748106166517760",
  "in_reply_to_user_id" : 563152502,
  "text" : "@euleule no chance f\u00FCr mich, von structure building war ich noch Meilen entfernt bevor ich gefressen wurde ;)",
  "id" : 442748106166517760,
  "in_reply_to_status_id" : 442744028631937024,
  "created_at" : "2014-03-09 19:45:49 +0000",
  "in_reply_to_screen_name" : "euleule",
  "in_reply_to_user_id_str" : "563152502",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert Krause",
      "screen_name" : "euleule",
      "indices" : [ 0, 8 ],
      "id_str" : "563152502",
      "id" : 563152502
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "442743222029537280",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096458643, 8.2830323843 ]
  },
  "id_str" : "442743610833129472",
  "in_reply_to_user_id" : 563152502,
  "text" : "@euleule das gesamte advanced crafting habe ich nie erlebt mangels \u00DCberlebensdauer ;)",
  "id" : 442743610833129472,
  "in_reply_to_status_id" : 442743222029537280,
  "created_at" : "2014-03-09 19:27:57 +0000",
  "in_reply_to_screen_name" : "euleule",
  "in_reply_to_user_id_str" : "563152502",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert Krause",
      "screen_name" : "euleule",
      "indices" : [ 0, 8 ],
      "id_str" : "563152502",
      "id" : 563152502
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "442742843820756992",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096458643, 8.2830323843 ]
  },
  "id_str" : "442742964935467008",
  "in_reply_to_user_id" : 563152502,
  "text" : "@euleule ich hab dann mal ein bisschen gelesen und es scheint noch so viel Spielmechanik zu geben die ich nie zu Gesicht bekam ;)",
  "id" : 442742964935467008,
  "in_reply_to_status_id" : 442742843820756992,
  "created_at" : "2014-03-09 19:25:23 +0000",
  "in_reply_to_screen_name" : "euleule",
  "in_reply_to_user_id_str" : "563152502",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert Krause",
      "screen_name" : "euleule",
      "indices" : [ 0, 8 ],
      "id_str" : "563152502",
      "id" : 563152502
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "442742269205315584",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096458643, 8.2830323843 ]
  },
  "id_str" : "442742388541620225",
  "in_reply_to_user_id" : 563152502,
  "text" : "@euleule das deckt sich mit meiner Erfahrung, deshalb wurde es mir schnell langweilig.",
  "id" : 442742388541620225,
  "in_reply_to_status_id" : 442742269205315584,
  "created_at" : "2014-03-09 19:23:05 +0000",
  "in_reply_to_screen_name" : "euleule",
  "in_reply_to_user_id_str" : "563152502",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert Krause",
      "screen_name" : "euleule",
      "indices" : [ 0, 8 ],
      "id_str" : "563152502",
      "id" : 563152502
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "442739088375181312",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096458643, 8.2830323843 ]
  },
  "id_str" : "442741079717470208",
  "in_reply_to_user_id" : 563152502,
  "text" : "@euleule Wie fandest du don\u2019t starve? :)",
  "id" : 442741079717470208,
  "in_reply_to_status_id" : 442739088375181312,
  "created_at" : "2014-03-09 19:17:53 +0000",
  "in_reply_to_screen_name" : "euleule",
  "in_reply_to_user_id_str" : "563152502",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Roman Mars",
      "screen_name" : "romanmars",
      "indices" : [ 44, 54 ],
      "id_str" : "8198012",
      "id" : 8198012
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0086221551, 8.2697086531 ]
  },
  "id_str" : "442721254169403392",
  "text" : "Every time I listen to 99% Invisible I wish @romanmars would voice my inner monologues.",
  "id" : 442721254169403392,
  "created_at" : "2014-03-09 17:59:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/jy9E2WXqc4",
      "expanded_url" : "http:\/\/99percentinvisible.org\/episode\/cover-story\/",
      "display_url" : "99percentinvisible.org\/episode\/cover-\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0010383978, 8.2588133377 ]
  },
  "id_str" : "442715770255310848",
  "text" : "\u00AB26 sex positions we must try this weekend!\u00BB On the history of magazine covers. http:\/\/t.co\/jy9E2WXqc4",
  "id" : 442715770255310848,
  "created_at" : "2014-03-09 17:37:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 48 ],
      "url" : "http:\/\/t.co\/9ixNpv9UeO",
      "expanded_url" : "http:\/\/www.crackajack.de\/2014\/03\/09\/narcoleptic-squirrel-song\/",
      "display_url" : "crackajack.de\/2014\/03\/09\/nar\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096458643, 8.2830323843 ]
  },
  "id_str" : "442692846836285440",
  "text" : "Narcoleptic Squirrel Song http:\/\/t.co\/9ixNpv9UeO",
  "id" : 442692846836285440,
  "created_at" : "2014-03-09 16:06:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Ducker",
      "screen_name" : "andrewducker",
      "indices" : [ 3, 16 ],
      "id_str" : "9221622",
      "id" : 9221622
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/4jBnPRjqmk",
      "expanded_url" : "http:\/\/bit.ly\/1dEOGky",
      "display_url" : "bit.ly\/1dEOGky"
    } ]
  },
  "geo" : { },
  "id_str" : "442679871270322176",
  "text" : "RT @andrewducker: Okay, this is my new favourite comments policy http:\/\/t.co\/4jBnPRjqmk",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dlvrit.com\/\" rel=\"nofollow\"\u003Edlvr.it\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 47, 69 ],
        "url" : "http:\/\/t.co\/4jBnPRjqmk",
        "expanded_url" : "http:\/\/bit.ly\/1dEOGky",
        "display_url" : "bit.ly\/1dEOGky"
      } ]
    },
    "geo" : { },
    "id_str" : "442648425201291264",
    "text" : "Okay, this is my new favourite comments policy http:\/\/t.co\/4jBnPRjqmk",
    "id" : 442648425201291264,
    "created_at" : "2014-03-09 13:09:43 +0000",
    "user" : {
      "name" : "Andrew Ducker",
      "screen_name" : "andrewducker",
      "protected" : false,
      "id_str" : "9221622",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/512715233370976256\/QfL7JYGT_normal.jpeg",
      "id" : 9221622,
      "verified" : false
    }
  },
  "id" : 442679871270322176,
  "created_at" : "2014-03-09 15:14:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 52 ],
      "url" : "http:\/\/t.co\/6DMWs34NGY",
      "expanded_url" : "http:\/\/instagram.com\/p\/lU3iyFBwmH\/",
      "display_url" : "instagram.com\/p\/lU3iyFBwmH\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.005940563, 8.286528378 ]
  },
  "id_str" : "442675870105616384",
  "text" : "getting there @ Elfenbeinturm http:\/\/t.co\/6DMWs34NGY",
  "id" : 442675870105616384,
  "created_at" : "2014-03-09 14:58:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095457683, 8.2829570267 ]
  },
  "id_str" : "442669071537283072",
  "text" : "related: amazing how strong\/large the mastication muscles are.",
  "id" : 442669071537283072,
  "created_at" : "2014-03-09 14:31:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095457683, 8.2829570267 ]
  },
  "id_str" : "442667239247196160",
  "text" : "Bitten by a dead squirrel. As embarrassing as it gets.",
  "id" : 442667239247196160,
  "created_at" : "2014-03-09 14:24:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fiona Nielsen",
      "screen_name" : "glyn_dk",
      "indices" : [ 0, 8 ],
      "id_str" : "32340834",
      "id" : 32340834
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "442657803443142656",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095457683, 8.2829570267 ]
  },
  "id_str" : "442658021366583296",
  "in_reply_to_user_id" : 32340834,
  "text" : "@glyn_dk DIY means you have to improvise (but at least I have the standard tool set around)",
  "id" : 442658021366583296,
  "in_reply_to_status_id" : 442657803443142656,
  "created_at" : "2014-03-09 13:47:51 +0000",
  "in_reply_to_screen_name" : "glyn_dk",
  "in_reply_to_user_id_str" : "32340834",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 72 ],
      "url" : "http:\/\/t.co\/g6fUjxRNvs",
      "expanded_url" : "http:\/\/instagram.com\/p\/lUu7ZMhwpg\/",
      "display_url" : "instagram.com\/p\/lUu7ZMhwpg\/"
    } ]
  },
  "geo" : { },
  "id_str" : "442656923939520512",
  "text" : "prepared the first rat skull for the acetone bath http:\/\/t.co\/g6fUjxRNvs",
  "id" : 442656923939520512,
  "created_at" : "2014-03-09 13:43:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 77 ],
      "url" : "http:\/\/t.co\/LF6J1GFSvx",
      "expanded_url" : "http:\/\/www.wired.co.uk\/news\/archive\/2014-03\/06\/care-data",
      "display_url" : "wired.co.uk\/news\/archive\/2\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095457683, 8.2829570267 ]
  },
  "id_str" : "442631297429929984",
  "text" : "Three things to save when the Care.data ship goes down http:\/\/t.co\/LF6J1GFSvx",
  "id" : 442631297429929984,
  "created_at" : "2014-03-09 12:01:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/9vreI9PujA",
      "expanded_url" : "http:\/\/www.theglobeandmail.com\/life\/relationships\/what-family-looks-like-today-three-partners-plus-kids-under-one-roof\/article17341865\/?page=all",
      "display_url" : "theglobeandmail.com\/life\/relations\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095457683, 8.2829570267 ]
  },
  "id_str" : "442629827527733248",
  "text" : "\u00ABCall them bopos (bourgeois polyamorous) or polyfidelitous (the more academic term)\u00BB http:\/\/t.co\/9vreI9PujA",
  "id" : 442629827527733248,
  "created_at" : "2014-03-09 11:55:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert Krause",
      "screen_name" : "euleule",
      "indices" : [ 0, 8 ],
      "id_str" : "563152502",
      "id" : 563152502
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "442448131004047360",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096360171, 8.2830078743 ]
  },
  "id_str" : "442460681947082752",
  "in_reply_to_user_id" : 563152502,
  "text" : "@euleule Wenn du welche davon magst sag gern deine W\u00FCnsche an :)",
  "id" : 442460681947082752,
  "in_reply_to_status_id" : 442448131004047360,
  "created_at" : "2014-03-09 00:43:41 +0000",
  "in_reply_to_screen_name" : "euleule",
  "in_reply_to_user_id_str" : "563152502",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/SriPHXD9oo",
      "expanded_url" : "http:\/\/youtube.com\/watch?v=pYITfEVJ56g",
      "display_url" : "youtube.com\/watch?v=pYITfE\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0119665876, 8.2789007259 ]
  },
  "id_str" : "442455687848017920",
  "text" : "You twist and whisper the wrong name\nI don\u2019t care nor do my ears \nhttp:\/\/t.co\/SriPHXD9oo",
  "id" : 442455687848017920,
  "created_at" : "2014-03-09 00:23:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert Krause",
      "screen_name" : "euleule",
      "indices" : [ 0, 8 ],
      "id_str" : "563152502",
      "id" : 563152502
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "442446678084554752",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0101220364, 8.2689912755 ]
  },
  "id_str" : "442447827344830464",
  "in_reply_to_user_id" : 563152502,
  "text" : "@euleule man k\u00F6nnte bestimmt ein nettes Quartett mit den ganzen Metriken machen (# Publikationen, h-index, Summe eingeworbene Drittmittel,\u2026)",
  "id" : 442447827344830464,
  "in_reply_to_status_id" : 442446678084554752,
  "created_at" : "2014-03-08 23:52:36 +0000",
  "in_reply_to_screen_name" : "euleule",
  "in_reply_to_user_id_str" : "563152502",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert Krause",
      "screen_name" : "euleule",
      "indices" : [ 0, 8 ],
      "id_str" : "563152502",
      "id" : 563152502
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 41 ],
      "url" : "https:\/\/t.co\/cBYlFuwfxT",
      "expanded_url" : "https:\/\/www.etsy.com\/listing\/91982859\/20-scientist-art-stickers-all-20?ref=shop_home_active_8",
      "display_url" : "etsy.com\/listing\/919828\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "442445212854800384",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096884011, 8.283018295 ]
  },
  "id_str" : "442445381734268929",
  "in_reply_to_user_id" : 563152502,
  "text" : "@euleule stickers https:\/\/t.co\/cBYlFuwfxT",
  "id" : 442445381734268929,
  "in_reply_to_status_id" : 442445212854800384,
  "created_at" : "2014-03-08 23:42:53 +0000",
  "in_reply_to_screen_name" : "euleule",
  "in_reply_to_user_id_str" : "563152502",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DNAdigest.org",
      "screen_name" : "DNADigest",
      "indices" : [ 53, 63 ],
      "id_str" : "334912047",
      "id" : 334912047
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/2Wp92t1fbm",
      "expanded_url" : "https:\/\/www.thunderclap.it\/projects\/9138-support-dna-digest?utm_content=buffer3d52a&utm_medium=social&utm_source=twitter.com&utm_campaign=buffer",
      "display_url" : "thunderclap.it\/projects\/9138-\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00956866, 8.28288693 ]
  },
  "id_str" : "442425708284235776",
  "text" : "For those of you who are into sharing genetics data: @DNADigest is only missing 13 supporters for their thunderclap https:\/\/t.co\/2Wp92t1fbm",
  "id" : 442425708284235776,
  "created_at" : "2014-03-08 22:24:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dean Burnett",
      "screen_name" : "garwboy",
      "indices" : [ 3, 11 ],
      "id_str" : "20474878",
      "id" : 20474878
    }, {
      "name" : "GuardianScienceBlogs",
      "screen_name" : "guardiansciblog",
      "indices" : [ 91, 107 ],
      "id_str" : "175691292",
      "id" : 175691292
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 71 ],
      "url" : "http:\/\/t.co\/WXe3IIYHsE",
      "expanded_url" : "http:\/\/www.theguardian.com\/science\/brain-flapping\/2013\/mar\/21\/women-in-science-know-your-limits",
      "display_url" : "theguardian.com\/science\/brain-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "442406136369934336",
  "text" : "RT @garwboy: Women in science: know your limits! http:\/\/t.co\/WXe3IIYHsE My (obvious spoof) @guardiansciblog about why women shouldn't do sc\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "GuardianScienceBlogs",
        "screen_name" : "guardiansciblog",
        "indices" : [ 78, 94 ],
        "id_str" : "175691292",
        "id" : 175691292
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "IWD2014",
        "indices" : [ 132, 140 ]
      } ],
      "urls" : [ {
        "indices" : [ 36, 58 ],
        "url" : "http:\/\/t.co\/WXe3IIYHsE",
        "expanded_url" : "http:\/\/www.theguardian.com\/science\/brain-flapping\/2013\/mar\/21\/women-in-science-know-your-limits",
        "display_url" : "theguardian.com\/science\/brain-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "442403914273792000",
    "text" : "Women in science: know your limits! http:\/\/t.co\/WXe3IIYHsE My (obvious spoof) @guardiansciblog about why women shouldn't do science #IWD2014",
    "id" : 442403914273792000,
    "created_at" : "2014-03-08 20:58:07 +0000",
    "user" : {
      "name" : "Dean Burnett",
      "screen_name" : "garwboy",
      "protected" : false,
      "id_str" : "20474878",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/920282732428775424\/uA6CvDqE_normal.jpg",
      "id" : 20474878,
      "verified" : false
    }
  },
  "id" : 442406136369934336,
  "created_at" : "2014-03-08 21:06:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 38 ],
      "url" : "http:\/\/t.co\/hAHMBzgkux",
      "expanded_url" : "http:\/\/i.imgur.com\/QEVa5jW.jpg",
      "display_url" : "i.imgur.com\/QEVa5jW.jpg"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096877749, 8.2830180034 ]
  },
  "id_str" : "442403960264331264",
  "text" : "Such a fun game http:\/\/t.co\/hAHMBzgkux",
  "id" : 442403960264331264,
  "created_at" : "2014-03-08 20:58:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/Ikjrfik6Lt",
      "expanded_url" : "http:\/\/www.guitarworld.com\/interview-robby-krieger-doors-strange-days?page=0,0",
      "display_url" : "guitarworld.com\/interview-robb\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095283025, 8.2829748575 ]
  },
  "id_str" : "442393817044766720",
  "text" : "Guitarist Robby Krieger Discusses The Doors' Albums &amp; Working with Jim Morrison http:\/\/t.co\/Ikjrfik6Lt",
  "id" : 442393817044766720,
  "created_at" : "2014-03-08 20:17:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095283025, 8.2829748575 ]
  },
  "id_str" : "442392801553420288",
  "text" : "\u00ABIch weiss nicht ob ich dich retweeten darf oder ob es der SPD zu nah ist. Nachher muss ich aufs Sofa oder die Schl\u00F6sser sind ausgetauscht.\u00BB",
  "id" : 442392801553420288,
  "created_at" : "2014-03-08 20:13:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "carridwen",
      "screen_name" : "carridwen",
      "indices" : [ 0, 10 ],
      "id_str" : "197468202",
      "id" : 197468202
    }, {
      "name" : "purrrlegon",
      "screen_name" : "pulegon",
      "indices" : [ 11, 19 ],
      "id_str" : "107502279",
      "id" : 107502279
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 43 ],
      "url" : "https:\/\/t.co\/cBYlFuwfxT",
      "expanded_url" : "https:\/\/www.etsy.com\/listing\/91982859\/20-scientist-art-stickers-all-20?ref=shop_home_active_8",
      "display_url" : "etsy.com\/listing\/919828\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "442388408481357824",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095283025, 8.2829748575 ]
  },
  "id_str" : "442390107619069952",
  "in_reply_to_user_id" : 197468202,
  "text" : "@carridwen @pulegon https:\/\/t.co\/cBYlFuwfxT (hab noch einen 15% off coupon code falls gew\u00FCnscht)",
  "id" : 442390107619069952,
  "in_reply_to_status_id" : 442388408481357824,
  "created_at" : "2014-03-08 20:03:15 +0000",
  "in_reply_to_screen_name" : "carridwen",
  "in_reply_to_user_id_str" : "197468202",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "InternationalWomensDay",
      "indices" : [ 17, 40 ]
    } ],
    "urls" : [ {
      "indices" : [ 57, 79 ],
      "url" : "http:\/\/t.co\/GvVhALxhJG",
      "expanded_url" : "http:\/\/instagram.com\/p\/lS0JQoBwhe\/",
      "display_url" : "instagram.com\/p\/lS0JQoBwhe\/"
    } ]
  },
  "geo" : { },
  "id_str" : "442386920606552064",
  "text" : "Just in time for #InternationalWomensDay. Team Rosalind! http:\/\/t.co\/GvVhALxhJG",
  "id" : 442386920606552064,
  "created_at" : "2014-03-08 19:50:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "purrrlegon",
      "screen_name" : "pulegon",
      "indices" : [ 0, 8 ],
      "id_str" : "107502279",
      "id" : 107502279
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "442379714049867777",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0048666754, 8.2896779138 ]
  },
  "id_str" : "442380653037101056",
  "in_reply_to_user_id" : 107502279,
  "text" : "@pulegon it\u2019s not like (most) mol. biologists wouldn\u2019t be fond of the binomial system as well. ;)",
  "id" : 442380653037101056,
  "in_reply_to_status_id" : 442379714049867777,
  "created_at" : "2014-03-08 19:25:41 +0000",
  "in_reply_to_screen_name" : "pulegon",
  "in_reply_to_user_id_str" : "107502279",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "purrrlegon",
      "screen_name" : "pulegon",
      "indices" : [ 0, 8 ],
      "id_str" : "107502279",
      "id" : 107502279
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "442377956997226497",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0087185148, 8.2860773376 ]
  },
  "id_str" : "442378693026250752",
  "in_reply_to_user_id" : 107502279,
  "text" : "@pulegon fighting labels is a constant uphill battle, seems to be deep seated behavior. Just ask your local taxonomists ;)",
  "id" : 442378693026250752,
  "in_reply_to_status_id" : 442377956997226497,
  "created_at" : "2014-03-08 19:17:54 +0000",
  "in_reply_to_screen_name" : "pulegon",
  "in_reply_to_user_id_str" : "107502279",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "purrrlegon",
      "screen_name" : "pulegon",
      "indices" : [ 0, 8 ],
      "id_str" : "107502279",
      "id" : 107502279
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "442376774614528000",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096426734, 8.2830440502 ]
  },
  "id_str" : "442377400333402113",
  "in_reply_to_user_id" : 107502279,
  "text" : "@pulegon how the no true Scotsman fallacy came to life.",
  "id" : 442377400333402113,
  "in_reply_to_status_id" : 442376774614528000,
  "created_at" : "2014-03-08 19:12:45 +0000",
  "in_reply_to_screen_name" : "pulegon",
  "in_reply_to_user_id_str" : "107502279",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/pCxQVoyPOl",
      "expanded_url" : "http:\/\/instagram.com\/p\/lSsfHXhwhZ\/",
      "display_url" : "instagram.com\/p\/lSsfHXhwhZ\/"
    } ]
  },
  "geo" : { },
  "id_str" : "442370079158968320",
  "text" : "\u00ABBetreibst du da die morbide Variante von 'Betrunkene dekorieren'?\u00BB http:\/\/t.co\/pCxQVoyPOl",
  "id" : 442370079158968320,
  "created_at" : "2014-03-08 18:43:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/4JpujASuUW",
      "expanded_url" : "http:\/\/instagram.com\/p\/lSqUhVBwsh\/",
      "display_url" : "instagram.com\/p\/lSqUhVBwsh\/"
    } ]
  },
  "geo" : { },
  "id_str" : "442365317852172288",
  "text" : "\u00ABKann hier wer Knotenkunde?\u00BB \u2014 \u00ABNicht die Art die zum B\u00E4ume f\u00E4llen ben\u00F6tigt wird.\u00BB http:\/\/t.co\/4JpujASuUW",
  "id" : 442365317852172288,
  "created_at" : "2014-03-08 18:24:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 8, 30 ],
      "url" : "http:\/\/t.co\/hQSsOJpLtT",
      "expanded_url" : "http:\/\/instagram.com\/p\/lSWuq9hwmP\/",
      "display_url" : "instagram.com\/p\/lSWuq9hwmP\/"
    } ]
  },
  "geo" : { },
  "id_str" : "442322235026833408",
  "text" : "Thallus http:\/\/t.co\/hQSsOJpLtT",
  "id" : 442322235026833408,
  "created_at" : "2014-03-08 15:33:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "442320480457216001",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1000059997, 8.2642050043 ]
  },
  "id_str" : "442320955097239552",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC I call it applied psych. ;)",
  "id" : 442320955097239552,
  "in_reply_to_status_id" : 442320480457216001,
  "created_at" : "2014-03-08 15:28:28 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "442314210165669888",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1051259088, 8.251132993 ]
  },
  "id_str" : "442316636867940352",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC sure, it\u2019s always amazing what being nice, pretending to care and feigning to understand can do. ;)",
  "id" : 442316636867940352,
  "in_reply_to_status_id" : 442314210165669888,
  "created_at" : "2014-03-08 15:11:18 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FES history",
      "screen_name" : "FEShistory",
      "indices" : [ 3, 14 ],
      "id_str" : "2376848436",
      "id" : 2376848436
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Frauentag",
      "indices" : [ 32, 42 ]
    }, {
      "text" : "Soz1914",
      "indices" : [ 131, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/Pc8Gjn1KZx",
      "expanded_url" : "http:\/\/blog.sozialdemokratie1914.de\/?p=211",
      "display_url" : "blog.sozialdemokratie1914.de\/?p=211"
    } ]
  },
  "geo" : { },
  "id_str" : "442309013511090176",
  "text" : "RT @FEShistory: Internationaler #Frauentag 1914. Sozialdemokratinnen demonstrieren f\u00FCr das Frauenwahlrecht: http:\/\/t.co\/Pc8Gjn1KZx #Soz1914",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Frauentag",
        "indices" : [ 16, 26 ]
      }, {
        "text" : "Soz1914",
        "indices" : [ 115, 123 ]
      } ],
      "urls" : [ {
        "indices" : [ 92, 114 ],
        "url" : "http:\/\/t.co\/Pc8Gjn1KZx",
        "expanded_url" : "http:\/\/blog.sozialdemokratie1914.de\/?p=211",
        "display_url" : "blog.sozialdemokratie1914.de\/?p=211"
      } ]
    },
    "geo" : { },
    "id_str" : "442215680436617216",
    "text" : "Internationaler #Frauentag 1914. Sozialdemokratinnen demonstrieren f\u00FCr das Frauenwahlrecht: http:\/\/t.co\/Pc8Gjn1KZx #Soz1914",
    "id" : 442215680436617216,
    "created_at" : "2014-03-08 08:30:08 +0000",
    "user" : {
      "name" : "FES history",
      "screen_name" : "FEShistory",
      "protected" : false,
      "id_str" : "2376848436",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/836512421942603776\/QLlSeu1p_normal.jpg",
      "id" : 2376848436,
      "verified" : false
    }
  },
  "id" : 442309013511090176,
  "created_at" : "2014-03-08 14:41:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "antiglitzerfee\uD83D\uDC19",
      "screen_name" : "Molossoidea",
      "indices" : [ 0, 12 ],
      "id_str" : "1874599292",
      "id" : 1874599292
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "442288221142396928",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1050260803, 8.2508411352 ]
  },
  "id_str" : "442288604006850560",
  "in_reply_to_user_id" : 1874599292,
  "text" : "@Molossoidea nein, nur den Sch\u00E4del rauspr\u00E4parieren. :)",
  "id" : 442288604006850560,
  "in_reply_to_status_id" : 442288221142396928,
  "created_at" : "2014-03-08 13:19:55 +0000",
  "in_reply_to_screen_name" : "Molossoidea",
  "in_reply_to_user_id_str" : "1874599292",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.104908566, 8.251076499 ]
  },
  "id_str" : "442287892929712128",
  "text" : "Yay, Eichh\u00F6rnchen - noch in Totenstarre - gefunden. Sonntagsbesch\u00E4ftigung ist gesichert.",
  "id" : 442287892929712128,
  "created_at" : "2014-03-08 13:17:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0823740421, 8.2447924338 ]
  },
  "id_str" : "442246496768262146",
  "text" : "Calming violent people who are having a bad trip. Just what I needed before having the first coffee\u2026",
  "id" : 442246496768262146,
  "created_at" : "2014-03-08 10:32:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.058357094, 8.2535821259 ]
  },
  "id_str" : "442236082177196032",
  "text" : "Romantik 101: \u00ABIch w\u00FCrde dich auch supporten und mit dir nach Thailand reisen, wenn du unbedingt ein K\u00F6rperteil loswerden wollen w\u00FCrdest\u00BB",
  "id" : 442236082177196032,
  "created_at" : "2014-03-08 09:51:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 67 ],
      "url" : "http:\/\/t.co\/c3cTVJKv37",
      "expanded_url" : "http:\/\/instagram.com\/p\/lRumkvhwjd\/",
      "display_url" : "instagram.com\/p\/lRumkvhwjd\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.007545947, 8.281888962 ]
  },
  "id_str" : "442233996072996864",
  "text" : "Oberleitung not found @ Bahnhof Mainz-Kastel http:\/\/t.co\/c3cTVJKv37",
  "id" : 442233996072996864,
  "created_at" : "2014-03-08 09:42:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert Krause",
      "screen_name" : "euleule",
      "indices" : [ 0, 8 ],
      "id_str" : "563152502",
      "id" : 563152502
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "442231621677490176",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0073550392, 8.2827065084 ]
  },
  "id_str" : "442231936841707520",
  "in_reply_to_user_id" : 563152502,
  "text" : "@euleule danke. Irgendwann m\u00FCssen wir das zusammen spielen auch noch mal in Angriff nehmen :)",
  "id" : 442231936841707520,
  "in_reply_to_status_id" : 442231621677490176,
  "created_at" : "2014-03-08 09:34:44 +0000",
  "in_reply_to_screen_name" : "euleule",
  "in_reply_to_user_id_str" : "563152502",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert Krause",
      "screen_name" : "euleule",
      "indices" : [ 0, 8 ],
      "id_str" : "563152502",
      "id" : 563152502
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "442230382147420160",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0072549851, 8.2827292255 ]
  },
  "id_str" : "442230970734104576",
  "in_reply_to_user_id" : 563152502,
  "text" : "@euleule guten Appetit, ich trage meine wieder mit rum :)",
  "id" : 442230970734104576,
  "in_reply_to_status_id" : 442230382147420160,
  "created_at" : "2014-03-08 09:30:54 +0000",
  "in_reply_to_screen_name" : "euleule",
  "in_reply_to_user_id_str" : "563152502",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert Krause",
      "screen_name" : "euleule",
      "indices" : [ 63, 71 ],
      "id_str" : "563152502",
      "id" : 563152502
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00719908, 8.2831162353 ]
  },
  "id_str" : "442229169276346368",
  "text" : "Auf durch den Kurpark. Mal schauen ob ich wieder zuf\u00E4llig \u00FCber @euleule stolpere.",
  "id" : 442229169276346368,
  "created_at" : "2014-03-08 09:23:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/VtjvGc1WXx",
      "expanded_url" : "http:\/\/www.tonedeaf.com.au\/news\/international-news\/391586\/the-most-hipster-bands-in-the-world-as-proven-by-science.htm",
      "display_url" : "tonedeaf.com.au\/news\/internati\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00963887, 8.2829813214 ]
  },
  "id_str" : "442215710283288576",
  "text" : "The Most Hipster Bands In The World, As Proven By Science http:\/\/t.co\/VtjvGc1WXx",
  "id" : 442215710283288576,
  "created_at" : "2014-03-08 08:30:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "The_Smoking_GNU",
      "indices" : [ 0, 16 ],
      "id_str" : "14535787",
      "id" : 14535787
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 66, 72 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "442208161815351296",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096857874, 8.283155635 ]
  },
  "id_str" : "442210965074243584",
  "in_reply_to_user_id" : 14535787,
  "text" : "@The_Smoking_GNU ich vermute genau das Video hat dazu gef\u00FChrt das @Lobot das Ding mitgebracht hat (damit ich auch mal blissful wirke).",
  "id" : 442210965074243584,
  "in_reply_to_status_id" : 442208161815351296,
  "created_at" : "2014-03-08 08:11:24 +0000",
  "in_reply_to_screen_name" : "The_Smoking_GNU",
  "in_reply_to_user_id_str" : "14535787",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "not best practice",
      "screen_name" : "moeffju",
      "indices" : [ 5, 13 ],
      "id_str" : "5618832",
      "id" : 5618832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095896051, 8.2827854063 ]
  },
  "id_str" : "442116847086096384",
  "text" : "\u00ABAls @moeffju das favte wusste ich das man es auch mit einer sexuellen Konnotation lesen kann.\u00BB",
  "id" : 442116847086096384,
  "created_at" : "2014-03-08 01:57:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 14, 23 ],
      "id_str" : "14861745",
      "id" : 14861745
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 24, 36 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "442112262388461568",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009669079, 8.2831079195 ]
  },
  "id_str" : "442112495617343488",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @Senficon @helgerausch me neither, and we tried it once with Novartis iirc and that was mainly a waste of time.",
  "id" : 442112495617343488,
  "in_reply_to_status_id" : 442112262388461568,
  "created_at" : "2014-03-08 01:40:07 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 14, 23 ],
      "id_str" : "14861745",
      "id" : 14861745
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 24, 36 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "442105996815527936",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096588409, 8.2831126915 ]
  },
  "id_str" : "442111154522189824",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @Senficon @helgerausch my head explodes. But I\u2019ll take that as a \u2018we\u2019re not interested\u2019. ;)",
  "id" : 442111154522189824,
  "in_reply_to_status_id" : 442105996815527936,
  "created_at" : "2014-03-08 01:34:47 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 10, 23 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 24, 36 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "442087873832312833",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00963887, 8.2829813214 ]
  },
  "id_str" : "442088519809646593",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon @PhilippBayer @helgerausch actually I was too baffled to reply so far.",
  "id" : 442088519809646593,
  "in_reply_to_status_id" : 442087873832312833,
  "created_at" : "2014-03-08 00:04:51 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 91, 104 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 105, 117 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "442086482598445056",
  "text" : "Somewhere things are going terribly wrong somehow: approached by a VC for openSNP. o_O \/cc @PhilippBayer @helgerausch",
  "id" : 442086482598445056,
  "created_at" : "2014-03-07 23:56:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/B27ab9HdzU",
      "expanded_url" : "http:\/\/instagram.com\/p\/lQqjRLBwic\/",
      "display_url" : "instagram.com\/p\/lQqjRLBwic\/"
    } ]
  },
  "geo" : { },
  "id_str" : "442084349690015744",
  "text" : "\u00ABIch hab dir was mitgebracht!\u00BB\u2014\u00ABEinen semi-faradayschen Aluhut?\u00BB\u2014\u00ABNein, einen Blitzableiter!\u00BB http:\/\/t.co\/B27ab9HdzU",
  "id" : 442084349690015744,
  "created_at" : "2014-03-07 23:48:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dierk Haasis",
      "screen_name" : "Evo2Me",
      "indices" : [ 0, 7 ],
      "id_str" : "22910316",
      "id" : 22910316
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "442008138729127936",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009649004, 8.2830103616 ]
  },
  "id_str" : "442008648605106176",
  "in_reply_to_user_id" : 22910316,
  "text" : "@Evo2Me nice thanks!",
  "id" : 442008648605106176,
  "in_reply_to_status_id" : 442008138729127936,
  "created_at" : "2014-03-07 18:47:28 +0000",
  "in_reply_to_screen_name" : "Evo2Me",
  "in_reply_to_user_id_str" : "22910316",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Terry McGlynn",
      "screen_name" : "hormiga",
      "indices" : [ 0, 8 ],
      "id_str" : "10328012",
      "id" : 10328012
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "441997877670203392",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009649004, 8.2830103616 ]
  },
  "id_str" : "442007779591876608",
  "in_reply_to_user_id" : 10328012,
  "text" : "@hormiga but that obviously depends on the field you\u2019re in. Coming from mol. ecology I probably having a different view on this than you do.",
  "id" : 442007779591876608,
  "in_reply_to_status_id" : 441997877670203392,
  "created_at" : "2014-03-07 18:44:01 +0000",
  "in_reply_to_screen_name" : "hormiga",
  "in_reply_to_user_id_str" : "10328012",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Terry McGlynn",
      "screen_name" : "hormiga",
      "indices" : [ 0, 8 ],
      "id_str" : "10328012",
      "id" : 10328012
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "441997877670203392",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096435806, 8.2830101155 ]
  },
  "id_str" : "442007523529596928",
  "in_reply_to_user_id" : 10328012,
  "text" : "@hormiga I\u2019d say especially small labs can profit from public data when lacking funds to generate huge data sets on their own.",
  "id" : 442007523529596928,
  "in_reply_to_status_id" : 441997877670203392,
  "created_at" : "2014-03-07 18:43:00 +0000",
  "in_reply_to_screen_name" : "hormiga",
  "in_reply_to_user_id_str" : "10328012",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Terry McGlynn",
      "screen_name" : "hormiga",
      "indices" : [ 0, 8 ],
      "id_str" : "10328012",
      "id" : 10328012
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "441996527825735680",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.10660953, 8.7378316174 ]
  },
  "id_str" : "441997356490575872",
  "in_reply_to_user_id" : 10328012,
  "text" : "@hormiga so you think that not everyone could benefit from the data being openly available?",
  "id" : 441997356490575872,
  "in_reply_to_status_id" : 441996527825735680,
  "created_at" : "2014-03-07 18:02:36 +0000",
  "in_reply_to_screen_name" : "hormiga",
  "in_reply_to_user_id_str" : "10328012",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1370298563, 8.6710335615 ]
  },
  "id_str" : "441990411662667776",
  "text" : "\u00ABWenn du gro\u00DF bist wirst du bestimmt auch ein Buch schreiben was ber\u00FChmt wird. Vermutlich \u2018On the Orrr-igin of Species\u2019.\u00BB",
  "id" : 441990411662667776,
  "created_at" : "2014-03-07 17:35:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/pXhBoilY7J",
      "expanded_url" : "http:\/\/smallpondscience.com\/2014\/03\/03\/i-own-my-data-until-i-dont\/comment-page-1\/#comment-6708",
      "display_url" : "smallpondscience.com\/2014\/03\/03\/i-o\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "441958503377551361",
  "geo" : { },
  "id_str" : "441959349096054784",
  "in_reply_to_user_id" : 14286491,
  "text" : "Pretty much sums up why mandatory public archiving rules are needed: to get rid of prisoner's-dilemma-esk equlibrium http:\/\/t.co\/pXhBoilY7J",
  "id" : 441959349096054784,
  "in_reply_to_status_id" : 441958503377551361,
  "created_at" : "2014-03-07 15:31:34 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "441958503377551361",
  "text" : "\u00ABI\u2019m not against public data archiving. I think it\u2019s a great movement. It just doesn\u2019t seem to be in the interest of my lab, at the moment.\u00BB",
  "id" : 441958503377551361,
  "created_at" : "2014-03-07 15:28:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 71 ],
      "url" : "http:\/\/t.co\/rlE7NyiXmE",
      "expanded_url" : "http:\/\/thescienceweb.wordpress.com\/2014\/03\/05\/venter-to-become-god-in-2016-jesus-to-step-down\/",
      "display_url" : "thescienceweb.wordpress.com\/2014\/03\/05\/ven\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "441953882831613952",
  "text" : "Venter to become God in 2016; Jesus to step down http:\/\/t.co\/rlE7NyiXmE",
  "id" : 441953882831613952,
  "created_at" : "2014-03-07 15:09:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/LsScRWSRFj",
      "expanded_url" : "http:\/\/blogs.plos.org\/thestudentblog\/2014\/03\/07\/beakers-ballplayers-failures\/",
      "display_url" : "blogs.plos.org\/thestudentblog\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "441925797872680960",
  "text" : "\u00ABMy participation in research over the past three years has taught me how to fail gracefully\u00BB http:\/\/t.co\/LsScRWSRFj",
  "id" : 441925797872680960,
  "created_at" : "2014-03-07 13:18:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "441914669821751297",
  "geo" : { },
  "id_str" : "441915419281350657",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer sure, I'll also have no time for some actual writing before Sunday.",
  "id" : 441915419281350657,
  "in_reply_to_status_id" : 441914669821751297,
  "created_at" : "2014-03-07 12:37:01 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/jlkQ5oHR8n",
      "expanded_url" : "http:\/\/www.united-academics.org\/magazine\/sex-society\/whats-my-sex-again-self-image-affected-by-media\/",
      "display_url" : "united-academics.org\/magazine\/sex-s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "441904983576178689",
  "text" : "\u00ABsex-[\/gender]-priming has an influence on self-concept because it triggers collective cultural notions of sexuality\u00BB http:\/\/t.co\/jlkQ5oHR8n",
  "id" : 441904983576178689,
  "created_at" : "2014-03-07 11:55:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "441904319709732864",
  "geo" : { },
  "id_str" : "441904630768078848",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer sure, I can open an etherpad for collecting points, doing an outline and writing if you want.",
  "id" : 441904630768078848,
  "in_reply_to_status_id" : 441904319709732864,
  "created_at" : "2014-03-07 11:54:08 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "441894714946486272",
  "geo" : { },
  "id_str" : "441904097927921664",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer interested in doing a joint post? I guess we have different perspectives to bring to the topic.",
  "id" : 441904097927921664,
  "in_reply_to_status_id" : 441894714946486272,
  "created_at" : "2014-03-07 11:52:01 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/9tqBgQrZvP",
      "expanded_url" : "http:\/\/postsecretdotcom.files.wordpress.com\/2014\/02\/3-poe.jpg",
      "display_url" : "postsecretdotcom.files.wordpress.com\/2014\/02\/3-poe.\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "441882838980640769",
  "text" : "if i appear to be preoccupied this might be one of the reasons http:\/\/t.co\/9tqBgQrZvP",
  "id" : 441882838980640769,
  "created_at" : "2014-03-07 10:27:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 121, 143 ],
      "url" : "http:\/\/t.co\/D0XUSx7qgm",
      "expanded_url" : "http:\/\/blogs.scientificamerican.com\/guest-blog\/2014\/03\/06\/our-first-view-into-the-blackout-zones-of-the-human-genome\/",
      "display_url" : "blogs.scientificamerican.com\/guest-blog\/201\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "441880858698739712",
  "text" : "Well written &amp; accessible take on the repeat problem: \u00ABOur first view into the \u2018blackout zones\u2019 of the human genome\u00BB http:\/\/t.co\/D0XUSx7qgm",
  "id" : 441880858698739712,
  "created_at" : "2014-03-07 10:19:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/0FyGPrt6Ld",
      "expanded_url" : "http:\/\/apps.npr.org\/grave-science\/",
      "display_url" : "apps.npr.org\/grave-science\/"
    } ]
  },
  "geo" : { },
  "id_str" : "441879233473048576",
  "text" : "Grave Science: On how the USA tries to identify so far unidentified war dead so they can be brought home http:\/\/t.co\/0FyGPrt6Ld",
  "id" : 441879233473048576,
  "created_at" : "2014-03-07 10:13:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 83, 96 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/KUMkNspPQb",
      "expanded_url" : "http:\/\/www.ploscompbiol.org\/article\/info%3Adoi%2F10.1371%2Fjournal.pcbi.1003496",
      "display_url" : "ploscompbiol.org\/article\/info%3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "441876256020525057",
  "text" : "Bioinformatics Curriculum Guidelines: Toward a Definition of Core Competencies \/cc @PhilippBayer http:\/\/t.co\/KUMkNspPQb",
  "id" : 441876256020525057,
  "created_at" : "2014-03-07 10:01:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/PjoyH7XXXI",
      "expanded_url" : "http:\/\/blogs.plos.org\/dnascience\/2014\/03\/06\/mitohype-3-parent-designer-babies-revisited\/",
      "display_url" : "blogs.plos.org\/dnascience\/201\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "441868727370670080",
  "text" : "Mitohype: 3-Parent Designer Babies Who Will Change Human Evolution http:\/\/t.co\/PjoyH7XXXI",
  "id" : 441868727370670080,
  "created_at" : "2014-03-07 09:31:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 31 ],
      "url" : "http:\/\/t.co\/TrxqEHRpsf",
      "expanded_url" : "http:\/\/xkcd.com\/1339\/",
      "display_url" : "xkcd.com\/1339\/"
    } ]
  },
  "geo" : { },
  "id_str" : "441865147834179584",
  "text" : "assuming http:\/\/t.co\/TrxqEHRpsf",
  "id" : 441865147834179584,
  "created_at" : "2014-03-07 09:17:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PHD Comics",
      "screen_name" : "PHDcomics",
      "indices" : [ 3, 13 ],
      "id_str" : "15521075",
      "id" : 15521075
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/phdcomics\/status\/441588547296841728\/photo\/1",
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/aiAzFKO7YD",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BiDWcbMCUAAp55D.jpg",
      "id_str" : "441588547305230336",
      "id" : 441588547305230336,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BiDWcbMCUAAp55D.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 433,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 294,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 433,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 433,
        "resize" : "fit",
        "w" : 1000
      } ],
      "display_url" : "pic.twitter.com\/aiAzFKO7YD"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 65 ],
      "url" : "http:\/\/t.co\/9G5XsqjdQd",
      "expanded_url" : "http:\/\/phdcomics.com\/comics.php?f=1687",
      "display_url" : "phdcomics.com\/comics.php?f=1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "441863407709724672",
  "text" : "RT @phdcomics: The Magic Code (New comic!) http:\/\/t.co\/9G5XsqjdQd http:\/\/t.co\/aiAzFKO7YD",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/phdcomics\/status\/441588547296841728\/photo\/1",
        "indices" : [ 51, 73 ],
        "url" : "http:\/\/t.co\/aiAzFKO7YD",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BiDWcbMCUAAp55D.jpg",
        "id_str" : "441588547305230336",
        "id" : 441588547305230336,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BiDWcbMCUAAp55D.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 433,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 294,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 433,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 433,
          "resize" : "fit",
          "w" : 1000
        } ],
        "display_url" : "pic.twitter.com\/aiAzFKO7YD"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 28, 50 ],
        "url" : "http:\/\/t.co\/9G5XsqjdQd",
        "expanded_url" : "http:\/\/phdcomics.com\/comics.php?f=1687",
        "display_url" : "phdcomics.com\/comics.php?f=1\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "441588547296841728",
    "text" : "The Magic Code (New comic!) http:\/\/t.co\/9G5XsqjdQd http:\/\/t.co\/aiAzFKO7YD",
    "id" : 441588547296841728,
    "created_at" : "2014-03-06 14:58:08 +0000",
    "user" : {
      "name" : "PHD Comics",
      "screen_name" : "PHDcomics",
      "protected" : false,
      "id_str" : "15521075",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/658834232123502592\/cwurv-IT_normal.png",
      "id" : 15521075,
      "verified" : false
    }
  },
  "id" : 441863407709724672,
  "created_at" : "2014-03-07 09:10:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 14, 26 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "441732471428636672",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097219379, 8.2831430507 ]
  },
  "id_str" : "441732728388460544",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @helgerausch yes, and in many cases for no good reason. Let me watch the videos and do automated tests at the speed I choose.",
  "id" : 441732728388460544,
  "in_reply_to_status_id" : 441732471428636672,
  "created_at" : "2014-03-07 00:31:04 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LadyBits",
      "screen_name" : "LadyBits",
      "indices" : [ 3, 12 ],
      "id_str" : "454244871",
      "id" : 454244871
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/HUcnqigY24",
      "expanded_url" : "http:\/\/www.theatlantic.com\/technology\/archive\/2014\/03\/the-first-woman-to-get-a-phd-in-computer-science-from-mit\/284127\/",
      "display_url" : "theatlantic.com\/technology\/arc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "441731919349153792",
  "text" : "RT @LadyBits: A conversation with Irene Greif, the first woman to get a PhD in computer science at MIT back in 1975 http:\/\/t.co\/HUcnqigY24",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 102, 124 ],
        "url" : "http:\/\/t.co\/HUcnqigY24",
        "expanded_url" : "http:\/\/www.theatlantic.com\/technology\/archive\/2014\/03\/the-first-woman-to-get-a-phd-in-computer-science-from-mit\/284127\/",
        "display_url" : "theatlantic.com\/technology\/arc\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "441654598340980737",
    "text" : "A conversation with Irene Greif, the first woman to get a PhD in computer science at MIT back in 1975 http:\/\/t.co\/HUcnqigY24",
    "id" : 441654598340980737,
    "created_at" : "2014-03-06 19:20:36 +0000",
    "user" : {
      "name" : "LadyBits",
      "screen_name" : "LadyBits",
      "protected" : false,
      "id_str" : "454244871",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/489148432196444160\/JBk5iSxs_normal.jpeg",
      "id" : 454244871,
      "verified" : false
    }
  },
  "id" : 441731919349153792,
  "created_at" : "2014-03-07 00:27:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 14, 26 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "441719216710762496",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0053282832, 8.4137988494 ]
  },
  "id_str" : "441719409808506880",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @helgerausch and it makes just no sense to require that for anti-social students like me. I don\u2019t want support or forums.",
  "id" : 441719409808506880,
  "in_reply_to_status_id" : 441719216710762496,
  "created_at" : "2014-03-06 23:38:08 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 14, 26 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "441718574285979648",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0174295763, 8.4312270675 ]
  },
  "id_str" : "441718957025026048",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @helgerausch that you have to follow a timeline even if all tests are scored automatically bugs me.",
  "id" : 441718957025026048,
  "in_reply_to_status_id" : 441718574285979648,
  "created_at" : "2014-03-06 23:36:20 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 14, 26 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "441718574285979648",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0202057002, 8.434935551 ]
  },
  "id_str" : "441718803882602496",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @helgerausch that\u2019s actually the only MOOC I ever finished.",
  "id" : 441718803882602496,
  "in_reply_to_status_id" : 441718574285979648,
  "created_at" : "2014-03-06 23:35:44 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/U06ZAYRJw2",
      "expanded_url" : "http:\/\/youtube.com\/watch?v=UpeRbbH5Ln4",
      "display_url" : "youtube.com\/watch?v=UpeRbb\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1144343118, 8.6818251105 ]
  },
  "id_str" : "441709539151593472",
  "text" : "Take your life, give it a shake\ngather up all your loose change. I think I\u2019ll save suicide for another year. http:\/\/t.co\/U06ZAYRJw2",
  "id" : 441709539151593472,
  "created_at" : "2014-03-06 22:58:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723897757, 8.6275111472 ]
  },
  "id_str" : "441679184747061249",
  "text" : "\u00ABWir hatten ein Stechen zwischen \u2018AIDS\u2019 und \u2018Foreskin\u2019.\u00BB \u2014 \u00ABUnd es war ein hartes Stechen\u2026\u00BB",
  "id" : 441679184747061249,
  "created_at" : "2014-03-06 20:58:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723171525, 8.6276081868 ]
  },
  "id_str" : "441646213331701761",
  "text" : "\u00ABAber es sind doch nur 3 Garnelen.\u00BB \u2014 \u00ABRede nicht so \u00FCber meine Kinder!\u00BB",
  "id" : 441646213331701761,
  "created_at" : "2014-03-06 18:47:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172318841, 8.6275990519 ]
  },
  "id_str" : "441642451410092032",
  "text" : "\u00ABDu willst die Garnelen an die Kugelfische verf\u00FCttern?!\u00BB \u2014 \u00ABJa, daf\u00FCr sind sie ja da.\u00BB \u2014 \u00ABAber, aber\u2026 Ich habe ihnen schon Namen gegeben!\u00BB",
  "id" : 441642451410092032,
  "created_at" : "2014-03-06 18:32:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 13, 26 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "441631350328934402",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723421374, 8.6276120519 ]
  },
  "id_str" : "441637020453314560",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch @PhilippBayer thanks, took that already though :)",
  "id" : 441637020453314560,
  "in_reply_to_status_id" : 441631350328934402,
  "created_at" : "2014-03-06 18:10:45 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "441616968668696576",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723280695, 8.6276203619 ]
  },
  "id_str" : "441617345950531584",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC yay for white wine (guess I have been living in\/near Mainz for too long already)",
  "id" : 441617345950531584,
  "in_reply_to_status_id" : 441616968668696576,
  "created_at" : "2014-03-06 16:52:34 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "441615600931328000",
  "text" : "on adapters in sequencing data: \u00ABit is a sure sign that someone goofed somewhere\u2026and it's very probably not your fault.\u00BB",
  "id" : 441615600931328000,
  "created_at" : "2014-03-06 16:45:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "441612499201560576",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723062783, 8.6276433317 ]
  },
  "id_str" : "441614000879853568",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC the latter should work ;)",
  "id" : 441614000879853568,
  "in_reply_to_status_id" : 441612499201560576,
  "created_at" : "2014-03-06 16:39:17 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 10, 16 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "441591451840167936",
  "geo" : { },
  "id_str" : "441601960702390273",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich @Lobot was meintest du wieso ich sagte das 6.35 Klinke nicht reicht? :p",
  "id" : 441601960702390273,
  "in_reply_to_status_id" : 441591451840167936,
  "created_at" : "2014-03-06 15:51:26 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 10, 16 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 60 ],
      "url" : "https:\/\/t.co\/GzpTymVMpq",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/435147697008693248",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "441589749598679040",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723280876, 8.6276259726 ]
  },
  "id_str" : "441590642259804160",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich @Lobot let me help you out https:\/\/t.co\/GzpTymVMpq",
  "id" : 441590642259804160,
  "in_reply_to_status_id" : 441589749598679040,
  "created_at" : "2014-03-06 15:06:28 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    }, {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 21, 30 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/eamDFRbsx7",
      "expanded_url" : "https:\/\/i.chzbgr.com\/maxW500\/6013446912\/hEAC4D59F\/",
      "display_url" : "i.chzbgr.com\/maxW500\/601344\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "441587603671121921",
  "geo" : { },
  "id_str" : "441588585394081792",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot you just want @JP_Stich to see yet another awkward boner! given my dress experience I might also choose this https:\/\/t.co\/eamDFRbsx7",
  "id" : 441588585394081792,
  "in_reply_to_status_id" : 441587603671121921,
  "created_at" : "2014-03-06 14:58:17 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "441587566169829376",
  "text" : "\u00ABDu w\u00E4rest eine gute Mami.\u00BB \u2013 \u00ABSpinnst du?! Am liebsten erziehe ich mit den F\u00E4usten!\u00BB",
  "id" : 441587566169829376,
  "created_at" : "2014-03-06 14:54:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "441585906706046977",
  "geo" : { },
  "id_str" : "441586995593502720",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC is that why you dislike the book? Anyway, in that case I'll let you pick the poison. :p",
  "id" : 441586995593502720,
  "in_reply_to_status_id" : 441585906706046977,
  "created_at" : "2014-03-06 14:51:58 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "441584795165163521",
  "geo" : { },
  "id_str" : "441586734816841728",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot dressed to kill, perfect for lumbering.",
  "id" : 441586734816841728,
  "in_reply_to_status_id" : 441584795165163521,
  "created_at" : "2014-03-06 14:50:56 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "441581665396473856",
  "text" : "Trippy, die Jubil\u00E4umsausstellung der Uni nennt sich \u00ABIch sehe wunderbare Dinge\u00BB.",
  "id" : 441581665396473856,
  "created_at" : "2014-03-06 14:30:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "441579417215959040",
  "text" : "Bekomme klare Arbeitsanweisungen: \u00ABSchuhe die gut zu reinigen sind. Ansonsten m\u00F6glichst knapp &amp; eng. Das sieht hei\u00DFer aus beim Arbeiten.\u00BB",
  "id" : 441579417215959040,
  "created_at" : "2014-03-06 14:21:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "441577927868964864",
  "text" : "Auto correct changes 'Carinotetraodon' to 'caring tetrapods'. That's one way to bridge the evolutionary distance\u2026",
  "id" : 441577927868964864,
  "created_at" : "2014-03-06 14:15:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/e1qyBP14dJ",
      "expanded_url" : "http:\/\/instagram.com\/p\/lNDrR3BwmV\/",
      "display_url" : "instagram.com\/p\/lNDrR3BwmV\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172374546, 8.627694567 ]
  },
  "id_str" : "441576650275561472",
  "text" : "Carinotetraodon irrubesco @ Biologicum http:\/\/t.co\/e1qyBP14dJ",
  "id" : 441576650275561472,
  "created_at" : "2014-03-06 14:10:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723390144, 8.627628539 ]
  },
  "id_str" : "441542969305620481",
  "text" : "\u00ABDas ist schon mein zweiter gro\u00DFer Fail heute.\u00BB \u2014 \u00ABNoch einen weiteren und du bist die Dreifailigkeit.\u00BB",
  "id" : 441542969305620481,
  "created_at" : "2014-03-06 11:57:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    }, {
      "name" : "A Queer Has No Name",
      "screen_name" : "memeticsexgod",
      "indices" : [ 7, 21 ],
      "id_str" : "1451060280",
      "id" : 1451060280
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 58 ],
      "url" : "http:\/\/t.co\/bJ3EEJ1B6G",
      "expanded_url" : "http:\/\/www.misplaced.net\/stfu\/spaceballs500lp1.jpg",
      "display_url" : "misplaced.net\/stfu\/spaceball\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "441500586102767617",
  "geo" : { },
  "id_str" : "441507497963446272",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot @memeticsexgod stunt double! http:\/\/t.co\/bJ3EEJ1B6G",
  "id" : 441507497963446272,
  "in_reply_to_status_id" : 441500586102767617,
  "created_at" : "2014-03-06 09:36:04 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leighton Pritchard",
      "screen_name" : "widdowquinn",
      "indices" : [ 3, 15 ],
      "id_str" : "26800968",
      "id" : 26800968
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 79 ],
      "url" : "http:\/\/t.co\/6jdbBsVQGZ",
      "expanded_url" : "http:\/\/vserver1.cscs.lsa.umich.edu\/~crshalizi\/weblog\/1096.html",
      "display_url" : "vserver1.cscs.lsa.umich.edu\/~crshalizi\/web\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "441496851645485056",
  "text" : "RT @widdowquinn: Interesting thoughts on getting tenure: http:\/\/t.co\/6jdbBsVQGZ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 40, 62 ],
        "url" : "http:\/\/t.co\/6jdbBsVQGZ",
        "expanded_url" : "http:\/\/vserver1.cscs.lsa.umich.edu\/~crshalizi\/weblog\/1096.html",
        "display_url" : "vserver1.cscs.lsa.umich.edu\/~crshalizi\/web\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "441492346619035648",
    "text" : "Interesting thoughts on getting tenure: http:\/\/t.co\/6jdbBsVQGZ",
    "id" : 441492346619035648,
    "created_at" : "2014-03-06 08:35:52 +0000",
    "user" : {
      "name" : "Leighton Pritchard",
      "screen_name" : "widdowquinn",
      "protected" : false,
      "id_str" : "26800968",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2361874280\/z7co0zrwaump7iptht1s_normal.jpeg",
      "id" : 26800968,
      "verified" : false
    }
  },
  "id" : 441496851645485056,
  "created_at" : "2014-03-06 08:53:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/BGx9UVRLwr",
      "expanded_url" : "http:\/\/boingboing.net\/2014\/03\/05\/dachsund-insists-on-bringing-i.html",
      "display_url" : "boingboing.net\/2014\/03\/05\/dac\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "441494441124446208",
  "text" : "Dachshund insists on bringing inflatable shark into its crate http:\/\/t.co\/BGx9UVRLwr",
  "id" : 441494441124446208,
  "created_at" : "2014-03-06 08:44:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Skellett",
      "screen_name" : "Gurdur",
      "indices" : [ 0, 7 ],
      "id_str" : "125928028",
      "id" : 125928028
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "441486284541165568",
  "geo" : { },
  "id_str" : "441486818526363648",
  "in_reply_to_user_id" : 125928028,
  "text" : "@Gurdur but Pooh isn't too well known for eucalyptus. Then maybe I'm a result of hybridization?",
  "id" : 441486818526363648,
  "in_reply_to_status_id" : 441486284541165568,
  "created_at" : "2014-03-06 08:13:54 +0000",
  "in_reply_to_screen_name" : "Gurdur",
  "in_reply_to_user_id_str" : "125928028",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/bgSAZem34r",
      "expanded_url" : "http:\/\/www.ruethedayblog.com\/wp-content\/uploads\/2011\/07\/6078a3a6-47d4-4b90-a9ac-32addf4a819d.gif",
      "display_url" : "ruethedayblog.com\/wp-content\/upl\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "441484553811943424",
  "text" : "A student left me a jar of eucalyptus honey on my desk. I guess they found out about my secret identity. http:\/\/t.co\/bgSAZem34r",
  "id" : 441484553811943424,
  "created_at" : "2014-03-06 08:04:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1698133554, 8.6225619988 ]
  },
  "id_str" : "441480142419148801",
  "text" : "Despite the title \u00ABNeanderthal Man: In Search of Lost Genomes\u00BB is not about this grad student searching for his misplaced raw data.",
  "id" : 441480142419148801,
  "created_at" : "2014-03-06 07:47:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 58, 67 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "441457188796514304",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0071178966, 8.2829435149 ]
  },
  "id_str" : "441463988183117824",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer thanks, will have a look into it. And maybe @eramirez is interested as well.",
  "id" : 441463988183117824,
  "in_reply_to_status_id" : 441457188796514304,
  "created_at" : "2014-03-06 06:43:11 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Silviu Ardelean",
      "screen_name" : "silviuardelean",
      "indices" : [ 3, 18 ],
      "id_str" : "115876109",
      "id" : 115876109
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/silviuardelean\/status\/441199377189588992\/photo\/1",
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/kM6JOG3s5E",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bh90fvjCUAA0qlu.png",
      "id_str" : "441199377193783296",
      "id" : 441199377193783296,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bh90fvjCUAA0qlu.png",
      "sizes" : [ {
        "h" : 380,
        "resize" : "fit",
        "w" : 508
      }, {
        "h" : 380,
        "resize" : "fit",
        "w" : 508
      }, {
        "h" : 380,
        "resize" : "fit",
        "w" : 508
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 380,
        "resize" : "fit",
        "w" : 508
      } ],
      "display_url" : "pic.twitter.com\/kM6JOG3s5E"
    } ],
    "hashtags" : [ {
      "text" : "debugging",
      "indices" : [ 45, 55 ]
    }, {
      "text" : "programming",
      "indices" : [ 56, 68 ]
    }, {
      "text" : "epic",
      "indices" : [ 69, 74 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "441376228235558912",
  "text" : "RT @silviuardelean: The Debugging Six Stages #debugging #programming #epic http:\/\/t.co\/kM6JOG3s5E",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/silviuardelean\/status\/441199377189588992\/photo\/1",
        "indices" : [ 55, 77 ],
        "url" : "http:\/\/t.co\/kM6JOG3s5E",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bh90fvjCUAA0qlu.png",
        "id_str" : "441199377193783296",
        "id" : 441199377193783296,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bh90fvjCUAA0qlu.png",
        "sizes" : [ {
          "h" : 380,
          "resize" : "fit",
          "w" : 508
        }, {
          "h" : 380,
          "resize" : "fit",
          "w" : 508
        }, {
          "h" : 380,
          "resize" : "fit",
          "w" : 508
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 380,
          "resize" : "fit",
          "w" : 508
        } ],
        "display_url" : "pic.twitter.com\/kM6JOG3s5E"
      } ],
      "hashtags" : [ {
        "text" : "debugging",
        "indices" : [ 25, 35 ]
      }, {
        "text" : "programming",
        "indices" : [ 36, 48 ]
      }, {
        "text" : "epic",
        "indices" : [ 49, 54 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "441199377189588992",
    "text" : "The Debugging Six Stages #debugging #programming #epic http:\/\/t.co\/kM6JOG3s5E",
    "id" : 441199377189588992,
    "created_at" : "2014-03-05 13:11:43 +0000",
    "user" : {
      "name" : "Silviu Ardelean",
      "screen_name" : "silviuardelean",
      "protected" : false,
      "id_str" : "115876109",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/877146032903258118\/_1-8Fbe-_normal.jpg",
      "id" : 115876109,
      "verified" : false
    }
  },
  "id" : 441376228235558912,
  "created_at" : "2014-03-06 00:54:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mrgunn",
      "screen_name" : "mrgunn",
      "indices" : [ 3, 10 ],
      "id_str" : "15237935",
      "id" : 15237935
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 53 ],
      "url" : "http:\/\/t.co\/ymE7evGuJB",
      "expanded_url" : "http:\/\/www.geeksofdoom.com\/GoD\/img\/2014\/03\/1966686_462058733922226_15568310_n-530x662.jpg",
      "display_url" : "geeksofdoom.com\/GoD\/img\/2014\/0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "441370634959216640",
  "text" : "RT @mrgunn: I want to believe: http:\/\/t.co\/ymE7evGuJB",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 19, 41 ],
        "url" : "http:\/\/t.co\/ymE7evGuJB",
        "expanded_url" : "http:\/\/www.geeksofdoom.com\/GoD\/img\/2014\/03\/1966686_462058733922226_15568310_n-530x662.jpg",
        "display_url" : "geeksofdoom.com\/GoD\/img\/2014\/0\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "441370382050664448",
    "text" : "I want to believe: http:\/\/t.co\/ymE7evGuJB",
    "id" : 441370382050664448,
    "created_at" : "2014-03-06 00:31:14 +0000",
    "user" : {
      "name" : "mrgunn",
      "screen_name" : "mrgunn",
      "protected" : false,
      "id_str" : "15237935",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/679914371770798080\/FBcokUq2_normal.jpg",
      "id" : 15237935,
      "verified" : false
    }
  },
  "id" : 441370634959216640,
  "created_at" : "2014-03-06 00:32:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ToxX",
      "screen_name" : "ToxXInFlames",
      "indices" : [ 0, 13 ],
      "id_str" : "1421360166",
      "id" : 1421360166
    }, {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 14, 23 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/hUUyn9kPxx",
      "expanded_url" : "http:\/\/www.compbiome.com\/2010\/07\/bash-per-directory-bash-history.html",
      "display_url" : "compbiome.com\/2010\/07\/bash-p\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "441365271945936897",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00963887, 8.2829813214 ]
  },
  "id_str" : "441366144449257472",
  "in_reply_to_user_id" : 1421360166,
  "text" : "@ToxXInFlames @SuicideC I\u2019m not sure whether it\u2019s a best practice, but the general idea is found quite often, e.g. http:\/\/t.co\/hUUyn9kPxx",
  "id" : 441366144449257472,
  "in_reply_to_status_id" : 441365271945936897,
  "created_at" : "2014-03-06 00:14:23 +0000",
  "in_reply_to_screen_name" : "ToxXInFlames",
  "in_reply_to_user_id_str" : "1421360166",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ToxX",
      "screen_name" : "ToxXInFlames",
      "indices" : [ 0, 13 ],
      "id_str" : "1421360166",
      "id" : 1421360166
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "441362301351124992",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00963887, 8.2829813214 ]
  },
  "id_str" : "441362689118703616",
  "in_reply_to_user_id" : 1421360166,
  "text" : "@ToxXInFlames but that way it creates a kind of logfile of the operations performed on each data set I\u2019m working on.",
  "id" : 441362689118703616,
  "in_reply_to_status_id" : 441362301351124992,
  "created_at" : "2014-03-06 00:00:39 +0000",
  "in_reply_to_screen_name" : "ToxXInFlames",
  "in_reply_to_user_id_str" : "1421360166",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ToxX",
      "screen_name" : "ToxXInFlames",
      "indices" : [ 0, 13 ],
      "id_str" : "1421360166",
      "id" : 1421360166
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "441359129500987392",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00963887, 8.2829813214 ]
  },
  "id_str" : "441360090986463233",
  "in_reply_to_user_id" : 1421360166,
  "text" : "@ToxXInFlames fortunately I didn\u2019t. And actually I set up my bash to have a directory-wise .bash_history. ;)",
  "id" : 441360090986463233,
  "in_reply_to_status_id" : 441359129500987392,
  "created_at" : "2014-03-05 23:50:20 +0000",
  "in_reply_to_screen_name" : "ToxXInFlames",
  "in_reply_to_user_id_str" : "1421360166",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "441354642635890688",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00963887, 8.2829813214 ]
  },
  "id_str" : "441356044573634560",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC and afterwards we go for some rye whiskey to settle the matter? ;)",
  "id" : 441356044573634560,
  "in_reply_to_status_id" : 441354642635890688,
  "created_at" : "2014-03-05 23:34:15 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "441343601487151104",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00963887, 8.2829813214 ]
  },
  "id_str" : "441345361526132736",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC oh, I could never enjoy spending time with someone who hasn\u2019t read (and enjoyed!) The Catcher in the Rye ;)",
  "id" : 441345361526132736,
  "in_reply_to_status_id" : 441343601487151104,
  "created_at" : "2014-03-05 22:51:48 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "441341512425963520",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096787366, 8.2830790326 ]
  },
  "id_str" : "441342461987008512",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC at least you pretend it\u2019s \u2018recommended\u2019 over \u2018required\u2019 reading ;)",
  "id" : 441342461987008512,
  "in_reply_to_status_id" : 441341512425963520,
  "created_at" : "2014-03-05 22:40:17 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "441339985384706048",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00963887, 8.2829813214 ]
  },
  "id_str" : "441340378604896256",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC feel free to bring Bic pens next time you\u2019re around ;)",
  "id" : 441340378604896256,
  "in_reply_to_status_id" : 441339985384706048,
  "created_at" : "2014-03-05 22:32:00 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 2, 24 ],
      "url" : "http:\/\/t.co\/Mz4biyBoLA",
      "expanded_url" : "http:\/\/weknowmemes.com\/wp-content\/uploads\/2012\/10\/the-difference-between-science-and-screwing-around.jpeg",
      "display_url" : "weknowmemes.com\/wp-content\/upl\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00963887, 8.2829813214 ]
  },
  "id_str" : "441327175455997952",
  "text" : "\u2026 http:\/\/t.co\/Mz4biyBoLA",
  "id" : 441327175455997952,
  "created_at" : "2014-03-05 21:39:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00963887, 8.2829813214 ]
  },
  "id_str" : "441323215819145217",
  "text" : "Sleep deprivation induced amnesia. Now reenacting Memento with the .bash_history instead of tattoos\u2026",
  "id" : 441323215819145217,
  "created_at" : "2014-03-05 21:23:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/iS7YW4vl0b",
      "expanded_url" : "http:\/\/boingboing.net\/2014\/03\/05\/day-fades-to-night-hypnotic-g.html",
      "display_url" : "boingboing.net\/2014\/03\/05\/day\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00963887, 8.2829813214 ]
  },
  "id_str" : "441291406750261248",
  "text" : "Day fades to night, hypnotic GIF\u00A0edition. The radial ones are especially awesome. http:\/\/t.co\/iS7YW4vl0b",
  "id" : 441291406750261248,
  "created_at" : "2014-03-05 19:17:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 7, 29 ],
      "url" : "http:\/\/t.co\/zd8GkBUXi2",
      "expanded_url" : "http:\/\/stream1.gifsoup.com\/view5\/2727456\/balloon-pop-o.gif",
      "display_url" : "stream1.gifsoup.com\/view5\/2727456\/\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "441276859796295681",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00963887, 8.2829813214 ]
  },
  "id_str" : "441277522412838912",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot http:\/\/t.co\/zd8GkBUXi2",
  "id" : 441277522412838912,
  "in_reply_to_status_id" : 441276859796295681,
  "created_at" : "2014-03-05 18:22:14 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/Gd0rhv28fY",
      "expanded_url" : "http:\/\/thescienceweb.wordpress.com\/2014\/03\/05\/work-on-model-organisms-completely-pointless-researchers-admit\/",
      "display_url" : "thescienceweb.wordpress.com\/2014\/03\/05\/wor\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00963887, 8.2829813214 ]
  },
  "id_str" : "441276277300146176",
  "text" : "\u00ABThe number of diseases we\u2019ve cured in rodents far exceeds the number we\u2019ve cured in humans\u00BB http:\/\/t.co\/Gd0rhv28fY",
  "id" : 441276277300146176,
  "created_at" : "2014-03-05 18:17:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097038025, 8.2830638975 ]
  },
  "id_str" : "441274536571711488",
  "text" : "\u00ABAchtung: Bei einer Schalentier-Allergie besteht auch die M\u00F6glichkeit auf eine Allergie auf Speiseinsekten!\u00BB Kennste einen Arthropoden\u2026",
  "id" : 441274536571711488,
  "created_at" : "2014-03-05 18:10:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 66, 75 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/kkFP5XzkWp",
      "expanded_url" : "http:\/\/wuestengarnele.de\/shop\/catalog\/browse?sessid=",
      "display_url" : "wuestengarnele.de\/shop\/catalog\/b\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097038025, 8.2830638975 ]
  },
  "id_str" : "441273225998520320",
  "text" : "Essbare Insekten Snack-R\u00F6hrchen et al. http:\/\/t.co\/kkFP5XzkWp \/cc @Senficon",
  "id" : 441273225998520320,
  "created_at" : "2014-03-05 18:05:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "441272227229483009",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097038025, 8.2830638975 ]
  },
  "id_str" : "441272541261615104",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot hast du meine Gr\u00F6\u00DFe wieder geraten?",
  "id" : 441272541261615104,
  "in_reply_to_status_id" : 441272227229483009,
  "created_at" : "2014-03-05 18:02:26 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tenure, She Wrote",
      "screen_name" : "TenureSheWrote",
      "indices" : [ 3, 18 ],
      "id_str" : "1072269104",
      "id" : 1072269104
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "441242300845670400",
  "text" : "RT @TenureSheWrote: Must-read: I didn\u2019t want to lean out: Why I left, how I left, and what it would have taken to keep me in STEM: http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/janetter.net\/\" rel=\"nofollow\"\u003EJanetter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 111, 133 ],
        "url" : "http:\/\/t.co\/IW9Kd60toE",
        "expanded_url" : "http:\/\/bit.ly\/1l0JJEj",
        "display_url" : "bit.ly\/1l0JJEj"
      } ]
    },
    "geo" : { },
    "id_str" : "441240551053357057",
    "text" : "Must-read: I didn\u2019t want to lean out: Why I left, how I left, and what it would have taken to keep me in STEM: http:\/\/t.co\/IW9Kd60toE",
    "id" : 441240551053357057,
    "created_at" : "2014-03-05 15:55:19 +0000",
    "user" : {
      "name" : "Tenure, She Wrote",
      "screen_name" : "TenureSheWrote",
      "protected" : false,
      "id_str" : "1072269104",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000074157982\/1f4d6a849379d14d7992a6f685bc12af_normal.jpeg",
      "id" : 1072269104,
      "verified" : false
    }
  },
  "id" : 441242300845670400,
  "created_at" : "2014-03-05 16:02:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LibrarianShipwreck",
      "screen_name" : "libshipwreck",
      "indices" : [ 3, 16 ],
      "id_str" : "1143288666",
      "id" : 1143288666
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RightsCon",
      "indices" : [ 126, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "441175759332573184",
  "text" : "RT @libshipwreck: To think we can build \"free\" &amp; \"open\" tech without challenging systemic inequality is ignoring reality. #RightsCon http:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "RightsCon",
        "indices" : [ 108, 118 ]
      } ],
      "urls" : [ {
        "indices" : [ 119, 141 ],
        "url" : "http:\/\/t.co\/blREYwJC4h",
        "expanded_url" : "http:\/\/wp.me\/p38S12-md",
        "display_url" : "wp.me\/p38S12-md"
      } ]
    },
    "geo" : { },
    "id_str" : "440979204075565056",
    "text" : "To think we can build \"free\" &amp; \"open\" tech without challenging systemic inequality is ignoring reality. #RightsCon http:\/\/t.co\/blREYwJC4h",
    "id" : 440979204075565056,
    "created_at" : "2014-03-04 22:36:49 +0000",
    "user" : {
      "name" : "LibrarianShipwreck",
      "screen_name" : "libshipwreck",
      "protected" : false,
      "id_str" : "1143288666",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/885885929268936704\/l0j6xIQf_normal.jpg",
      "id" : 1143288666,
      "verified" : false
    }
  },
  "id" : 441175759332573184,
  "created_at" : "2014-03-05 11:37:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 115, 128 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/GUEK5QHqQm",
      "expanded_url" : "http:\/\/modernfarmer.com\/2014\/03\/monsantos-good-bad-pr-problem\/",
      "display_url" : "modernfarmer.com\/2014\/03\/monsan\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097038025, 8.2830638975 ]
  },
  "id_str" : "441166056007409665",
  "text" : "Why Does Everyone Hate Monsanto? \u00ABMonsanto sucks in one important aspect: spin control\u00BB http:\/\/t.co\/GUEK5QHqQm \/cc @PhilippBayer",
  "id" : 441166056007409665,
  "created_at" : "2014-03-05 10:59:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 40 ],
      "url" : "http:\/\/t.co\/KlhuEMw0v4",
      "expanded_url" : "http:\/\/vimeo.com\/64696537",
      "display_url" : "vimeo.com\/64696537"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097038025, 8.2830638975 ]
  },
  "id_str" : "441163922595672065",
  "text" : "Man's Best Friend http:\/\/t.co\/KlhuEMw0v4",
  "id" : 441163922595672065,
  "created_at" : "2014-03-05 10:50:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 53 ],
      "url" : "http:\/\/t.co\/qaNA0TqEln",
      "expanded_url" : "http:\/\/xkcd.com\/1338\/",
      "display_url" : "xkcd.com\/1338\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096417467, 8.2829911 ]
  },
  "id_str" : "441157887902375936",
  "text" : "Earth\u2019s Land Mammals by Weight http:\/\/t.co\/qaNA0TqEln",
  "id" : 441157887902375936,
  "created_at" : "2014-03-05 10:26:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katharin Tai",
      "screen_name" : "Whitey_chan",
      "indices" : [ 0, 12 ],
      "id_str" : "48357885",
      "id" : 48357885
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "441143921771810816",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096417467, 8.2829911 ]
  },
  "id_str" : "441144962240225280",
  "in_reply_to_user_id" : 48357885,
  "text" : "@Whitey_chan as far as I\u2019m concerned every bureaucracy is the same in that respect. I become catatonic &amp; start crying due2 nonsense-overload",
  "id" : 441144962240225280,
  "in_reply_to_status_id" : 441143921771810816,
  "created_at" : "2014-03-05 09:35:29 +0000",
  "in_reply_to_screen_name" : "Whitey_chan",
  "in_reply_to_user_id_str" : "48357885",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert Krause",
      "screen_name" : "euleule",
      "indices" : [ 0, 8 ],
      "id_str" : "563152502",
      "id" : 563152502
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "441123397247188992",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0349735575, 8.246501355 ]
  },
  "id_str" : "441123828790722560",
  "in_reply_to_user_id" : 563152502,
  "text" : "@euleule viel Erfolg!",
  "id" : 441123828790722560,
  "in_reply_to_status_id" : 441123397247188992,
  "created_at" : "2014-03-05 08:11:31 +0000",
  "in_reply_to_screen_name" : "euleule",
  "in_reply_to_user_id_str" : "563152502",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.034884326, 8.2458476862 ]
  },
  "id_str" : "441121112039358464",
  "text" : "the customs office, it\u2019s like the nightmares of Kafka and Joseph Heller had a love child.",
  "id" : 441121112039358464,
  "created_at" : "2014-03-05 08:00:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/eVQ0NBgvwM",
      "expanded_url" : "http:\/\/i.imgur.com\/KUIIcvO.jpg",
      "display_url" : "i.imgur.com\/KUIIcvO.jpg"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096417467, 8.2829911 ]
  },
  "id_str" : "440991829685989376",
  "text" : "the things you have to do for your job http:\/\/t.co\/eVQ0NBgvwM",
  "id" : 440991829685989376,
  "created_at" : "2014-03-04 23:27:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Weber",
      "screen_name" : "scy",
      "indices" : [ 0, 4 ],
      "id_str" : "8308632",
      "id" : 8308632
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 31, 40 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "440981685249654784",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0098191016, 8.2829139847 ]
  },
  "id_str" : "440981960777670656",
  "in_reply_to_user_id" : 8308632,
  "text" : "@scy that\u2019s what she said. \/cc @Senficon",
  "id" : 440981960777670656,
  "in_reply_to_status_id" : 440981685249654784,
  "created_at" : "2014-03-04 22:47:47 +0000",
  "in_reply_to_screen_name" : "scy",
  "in_reply_to_user_id_str" : "8308632",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 48 ],
      "url" : "http:\/\/t.co\/CUCPzSQlll",
      "expanded_url" : "http:\/\/imgur.com\/a\/o2hpJ",
      "display_url" : "imgur.com\/a\/o2hpJ"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096417467, 8.2829911 ]
  },
  "id_str" : "440977188049797120",
  "text" : "Fallout Vault concept art http:\/\/t.co\/CUCPzSQlll",
  "id" : 440977188049797120,
  "created_at" : "2014-03-04 22:28:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 52 ],
      "url" : "http:\/\/t.co\/HJBozrRl3J",
      "expanded_url" : "http:\/\/www.nytimes.com\/2014\/03\/04\/health\/lsd-reconsidered-for-therapy.html?_r=0",
      "display_url" : "nytimes.com\/2014\/03\/04\/hea\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009564784, 8.283021592 ]
  },
  "id_str" : "440952577409437696",
  "text" : "LSD, Reconsidered for Therapy http:\/\/t.co\/HJBozrRl3J",
  "id" : 440952577409437696,
  "created_at" : "2014-03-04 20:51:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/CnINFNsNZ7",
      "expanded_url" : "http:\/\/gifgif.media.mit.edu\/",
      "display_url" : "gifgif.media.mit.edu"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009564784, 8.283021592 ]
  },
  "id_str" : "440950665477910529",
  "text" : "mapping the emotional language of gifs http:\/\/t.co\/CnINFNsNZ7",
  "id" : 440950665477910529,
  "created_at" : "2014-03-04 20:43:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 72 ],
      "url" : "http:\/\/t.co\/YZfz5tHN7X",
      "expanded_url" : "http:\/\/www.asofterworld.com\/index.php?id=1072",
      "display_url" : "asofterworld.com\/index.php?id=1\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009564784, 8.283021592 ]
  },
  "id_str" : "440949516871942144",
  "text" : "infinity does not have your picture in its locker http:\/\/t.co\/YZfz5tHN7X",
  "id" : 440949516871942144,
  "created_at" : "2014-03-04 20:38:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/p8gzL4KSSW",
      "expanded_url" : "http:\/\/www.reddit.com\/r\/TheBestOfAmazon\/comments\/1zgq99\/im_looking_for_the_largest_dildo_on_amazon_help_me\/",
      "display_url" : "reddit.com\/r\/TheBestOfAma\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009564784, 8.283021592 ]
  },
  "id_str" : "440935271987937280",
  "text" : "\u00ABI'm looking for the largest dildo on amazon. help me. no questions please.\u00BB http:\/\/t.co\/p8gzL4KSSW",
  "id" : 440935271987937280,
  "created_at" : "2014-03-04 19:42:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009564784, 8.283021592 ]
  },
  "id_str" : "440932215271473152",
  "text" : "\u00ABOrr, jetzt muss ich meine W\u00FCnsche schon danach samplen was du akzeptieren k\u00F6nntest!\u00BB",
  "id" : 440932215271473152,
  "created_at" : "2014-03-04 19:30:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Weber",
      "screen_name" : "scy",
      "indices" : [ 41, 45 ],
      "id_str" : "8308632",
      "id" : 8308632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0076239629, 8.2929994789 ]
  },
  "id_str" : "440922475065794560",
  "text" : "\u00ABFremen-Beauftragter? Da bietet sich der @scy doch an?\u00BB",
  "id" : 440922475065794560,
  "created_at" : "2014-03-04 18:51:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TechCrunch Onion",
      "screen_name" : "TechCrunchOnion",
      "indices" : [ 3, 19 ],
      "id_str" : "1262413328",
      "id" : 1262413328
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "440901098984210432",
  "text" : "RT @TechCrunchOnion: Data Science set to replace Guesswork Science at laboratories nationwide.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "440706817123823616",
    "text" : "Data Science set to replace Guesswork Science at laboratories nationwide.",
    "id" : 440706817123823616,
    "created_at" : "2014-03-04 04:34:27 +0000",
    "user" : {
      "name" : "TechCrunch Onion",
      "screen_name" : "TechCrunchOnion",
      "protected" : false,
      "id_str" : "1262413328",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3373971608\/66598a73938a64beeab003aca9558ea7_normal.jpeg",
      "id" : 1262413328,
      "verified" : false
    }
  },
  "id" : 440901098984210432,
  "created_at" : "2014-03-04 17:26:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723156417, 8.6276315317 ]
  },
  "id_str" : "440889808920281088",
  "text" : "Amazing how Skype manages to keep calls at a good audio quality, right until you say \u201Cseems to work now, let\u2019s go on with the interview\u201D\u2026",
  "id" : 440889808920281088,
  "created_at" : "2014-03-04 16:41:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Brechler",
      "screen_name" : "plaetzchen",
      "indices" : [ 0, 11 ],
      "id_str" : "14305613",
      "id" : 14305613
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/5We2H52Ja0",
      "expanded_url" : "https:\/\/github.com\/gedankenstuecke\/blink1_morse",
      "display_url" : "github.com\/gedankenstueck\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "440882196296261632",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723156417, 8.6276315317 ]
  },
  "id_str" : "440885298076336128",
  "in_reply_to_user_id" : 14305613,
  "text" : "@plaetzchen you could give the error\/warning message in morse code ;) https:\/\/t.co\/5We2H52Ja0",
  "id" : 440885298076336128,
  "in_reply_to_status_id" : 440882196296261632,
  "created_at" : "2014-03-04 16:23:40 +0000",
  "in_reply_to_screen_name" : "plaetzchen",
  "in_reply_to_user_id_str" : "14305613",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/yDLUQoZ1Qa",
      "expanded_url" : "http:\/\/anothersb.blogspot.co.uk\/2014\/02\/goodbye-academia.html?m=1",
      "display_url" : "anothersb.blogspot.co.uk\/2014\/02\/goodby\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172314465, 8.627630795 ]
  },
  "id_str" : "440834480497246208",
  "text" : "\u00ABWhat seems crazy is aiming to stay in the academic track\u00BB http:\/\/t.co\/yDLUQoZ1Qa",
  "id" : 440834480497246208,
  "created_at" : "2014-03-04 13:01:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "440806725289926656",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1697496829, 8.6327526865 ]
  },
  "id_str" : "440806850389614592",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer great :)",
  "id" : 440806850389614592,
  "in_reply_to_status_id" : 440806725289926656,
  "created_at" : "2014-03-04 11:11:57 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "440804746459217920",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17231473, 8.627627852 ]
  },
  "id_str" : "440806566485573632",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer drop pls :)",
  "id" : 440806566485573632,
  "in_reply_to_status_id" : 440804746459217920,
  "created_at" : "2014-03-04 11:10:49 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert Krause",
      "screen_name" : "euleule",
      "indices" : [ 3, 11 ],
      "id_str" : "563152502",
      "id" : 563152502
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/MWKNPWtTQz",
      "expanded_url" : "http:\/\/abstrusegoose.com\/558",
      "display_url" : "abstrusegoose.com\/558"
    } ]
  },
  "geo" : { },
  "id_str" : "440804561214009344",
  "text" : "RT @euleule: Doesn't-Understand-Sarcasm Man to teh rescue! http:\/\/t.co\/MWKNPWtTQz",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sites.google.com\/site\/yorufukurou\/\" rel=\"nofollow\"\u003EYoruFukurou\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 46, 68 ],
        "url" : "http:\/\/t.co\/MWKNPWtTQz",
        "expanded_url" : "http:\/\/abstrusegoose.com\/558",
        "display_url" : "abstrusegoose.com\/558"
      } ]
    },
    "geo" : { },
    "id_str" : "440804177128996864",
    "text" : "Doesn't-Understand-Sarcasm Man to teh rescue! http:\/\/t.co\/MWKNPWtTQz",
    "id" : 440804177128996864,
    "created_at" : "2014-03-04 11:01:20 +0000",
    "user" : {
      "name" : "Robert Krause",
      "screen_name" : "euleule",
      "protected" : false,
      "id_str" : "563152502",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/851523263536803841\/cgRV7YuW_normal.jpg",
      "id" : 563152502,
      "verified" : false
    }
  },
  "id" : 440804561214009344,
  "created_at" : "2014-03-04 11:02:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "440800029242974208",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17231473, 8.627627852 ]
  },
  "id_str" : "440800817969627137",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer time to Process.exit!(true)",
  "id" : 440800817969627137,
  "in_reply_to_status_id" : 440800029242974208,
  "created_at" : "2014-03-04 10:47:59 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/a4HNopFqYq",
      "expanded_url" : "http:\/\/arxiv.org\/abs\/1402.7268",
      "display_url" : "arxiv.org\/abs\/1402.7268"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17231473, 8.627627852 ]
  },
  "id_str" : "440799970472771584",
  "text" : "Predicting Scientific Success Based on Coauthorship Networks http:\/\/t.co\/a4HNopFqYq",
  "id" : 440799970472771584,
  "created_at" : "2014-03-04 10:44:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "440799227837296640",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17231473, 8.627627852 ]
  },
  "id_str" : "440799739148500993",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer all those data will be lost, like tears in the rain",
  "id" : 440799739148500993,
  "in_reply_to_status_id" : 440799227837296640,
  "created_at" : "2014-03-04 10:43:42 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "440796250607079424",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17231473, 8.627627852 ]
  },
  "id_str" : "440796448377298944",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer \u201Cand Solr stopped crashing as well!\u201D",
  "id" : 440796448377298944,
  "in_reply_to_status_id" : 440796250607079424,
  "created_at" : "2014-03-04 10:30:37 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "440795924298620928",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17231473, 8.627627852 ]
  },
  "id_str" : "440796091567845376",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer \u201Cgood news, I solved all our speed problems with the database!\u201D",
  "id" : 440796091567845376,
  "in_reply_to_status_id" : 440795924298620928,
  "created_at" : "2014-03-04 10:29:12 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723154633, 8.6276314583 ]
  },
  "id_str" : "440786545155772416",
  "text" : "the pragmatic programmer\u2019s guide to marriage: \u00ABGibt\u2019s einen besseren Grund zu heiraten, als einen gemeinn\u00FCtzigen Verein gr\u00FCnden zu wollen?\u00BB",
  "id" : 440786545155772416,
  "created_at" : "2014-03-04 09:51:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1475217384, 8.6666899376 ]
  },
  "id_str" : "440768153740926976",
  "text" : "\u00ABYou asked about Minnie\u2019s name, sex, breed, and phone number. She doesn\u2019t answer the phone. She is a dachshund and can\u2019t reach it.\u00BB",
  "id" : 440768153740926976,
  "created_at" : "2014-03-04 08:38:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096618617, 8.2830252933 ]
  },
  "id_str" : "440649541688492032",
  "text" : "\u00ABNa, haben die Piraten schon wieder von der euklidischen Distanzierung zur hyperbolischen Distanzierung transformiert?\u00BB",
  "id" : 440649541688492032,
  "created_at" : "2014-03-04 00:46:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096482178, 8.2829534839 ]
  },
  "id_str" : "440638495997313024",
  "text" : "\u00ABAutocorrect macht \u2018Penis\u2019 zu \u2018Penisschlag\u2019. Nutzen wir das oft?\u00BB \u2014 \u00ABDas lese ich zum ersten mal.\u00BB \u2014 \u00ABVielleicht analog zum Ritterschlag?\u00BB",
  "id" : 440638495997313024,
  "created_at" : "2014-03-04 00:02:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/lJZ5tnDjQ5",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=o9A_FTgK4A0",
      "display_url" : "youtube.com\/watch?v=o9A_FT\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096618617, 8.2830252933 ]
  },
  "id_str" : "440634446623297536",
  "text" : "Secret of Mana - Into the Thick of It Acapella http:\/\/t.co\/lJZ5tnDjQ5",
  "id" : 440634446623297536,
  "created_at" : "2014-03-03 23:46:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ed Yong",
      "screen_name" : "edyong209",
      "indices" : [ 3, 13 ],
      "id_str" : "19767193",
      "id" : 19767193
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "440632285118070784",
  "text" : "RT @edyong209: I could sum up this 4,400-word Pacific Stand piece on culture &amp; disease in just two: \"ecological fallacy\". http:\/\/t.co\/kVIAA\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 111, 133 ],
        "url" : "http:\/\/t.co\/kVIAAnHkmV",
        "expanded_url" : "http:\/\/www.psmag.com\/navigation\/health-and-behavior\/bugs-like-made-germ-theory-democracy-beliefs-73958\/",
        "display_url" : "psmag.com\/navigation\/hea\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "440565384836415488",
    "text" : "I could sum up this 4,400-word Pacific Stand piece on culture &amp; disease in just two: \"ecological fallacy\". http:\/\/t.co\/kVIAAnHkmV",
    "id" : 440565384836415488,
    "created_at" : "2014-03-03 19:12:27 +0000",
    "user" : {
      "name" : "Ed Yong",
      "screen_name" : "edyong209",
      "protected" : false,
      "id_str" : "19767193",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/926063794912153600\/962ygzzx_normal.jpg",
      "id" : 19767193,
      "verified" : true
    }
  },
  "id" : 440632285118070784,
  "created_at" : "2014-03-03 23:38:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andy C. Hesse",
      "screen_name" : "Andyhesse",
      "indices" : [ 0, 10 ],
      "id_str" : "22011609",
      "id" : 22011609
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "440618325400629248",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096618617, 8.2830252933 ]
  },
  "id_str" : "440618458376835072",
  "in_reply_to_user_id" : 22011609,
  "text" : "@Andyhesse normaler Montag ;)",
  "id" : 440618458376835072,
  "in_reply_to_status_id" : 440618325400629248,
  "created_at" : "2014-03-03 22:43:21 +0000",
  "in_reply_to_screen_name" : "Andyhesse",
  "in_reply_to_user_id_str" : "22011609",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096618617, 8.2830252933 ]
  },
  "id_str" : "440617790379397120",
  "text" : "Fast von drei \u2013 sich gegenseitig ankotzenden \u2013 M\u00F6nchen umgelaufen worden. Mainz gerade so.",
  "id" : 440617790379397120,
  "created_at" : "2014-03-03 22:40:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 38, 47 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/440603229500768256\/photo\/1",
      "indices" : [ 48, 70 ],
      "url" : "http:\/\/t.co\/P7NGQ9hLjh",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bh1WTVFIAAAp6O9.jpg",
      "id_str" : "440603228628320256",
      "id" : 440603228628320256,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bh1WTVFIAAAp6O9.jpg",
      "sizes" : [ {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/P7NGQ9hLjh"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096784266, 8.2831018599 ]
  },
  "id_str" : "440603229500768256",
  "text" : "Simulation otteresker Volksn\u00E4he durch @Senficon http:\/\/t.co\/P7NGQ9hLjh",
  "id" : 440603229500768256,
  "created_at" : "2014-03-03 21:42:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/tZepduxoPI",
      "expanded_url" : "http:\/\/botpoet.com\/about\/",
      "display_url" : "botpoet.com\/about\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096618617, 8.2830252933 ]
  },
  "id_str" : "440590315901452288",
  "text" : "a Turing test for poetry http:\/\/t.co\/tZepduxoPI",
  "id" : 440590315901452288,
  "created_at" : "2014-03-03 20:51:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 3, 12 ],
      "id_str" : "14245811",
      "id" : 14245811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/IvBl8J8uuK",
      "expanded_url" : "http:\/\/www.popsci.com\/article\/gadgets\/keurig-wants-lock-down-its-pods-coffee-drm",
      "display_url" : "popsci.com\/article\/gadget\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "440588593246253057",
  "text" : "RT @wilbanks: No better way to raise public awareness of DRM than putting it between people and their coffee. http:\/\/t.co\/IvBl8J8uuK",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 96, 118 ],
        "url" : "http:\/\/t.co\/IvBl8J8uuK",
        "expanded_url" : "http:\/\/www.popsci.com\/article\/gadgets\/keurig-wants-lock-down-its-pods-coffee-drm",
        "display_url" : "popsci.com\/article\/gadget\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "440588447720697857",
    "text" : "No better way to raise public awareness of DRM than putting it between people and their coffee. http:\/\/t.co\/IvBl8J8uuK",
    "id" : 440588447720697857,
    "created_at" : "2014-03-03 20:44:06 +0000",
    "user" : {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "protected" : false,
      "id_str" : "14245811",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/925696899566440448\/BUTdp410_normal.jpg",
      "id" : 14245811,
      "verified" : false
    }
  },
  "id" : 440588593246253057,
  "created_at" : "2014-03-03 20:44:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Vines",
      "screen_name" : "TimHVines",
      "indices" : [ 3, 13 ],
      "id_str" : "2216245224",
      "id" : 2216245224
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "PLoSFail",
      "indices" : [ 20, 29 ]
    } ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/yHz5aVW00h",
      "expanded_url" : "http:\/\/en.wikipedia.org\/wiki\/Nirvana_fallacy",
      "display_url" : "en.wikipedia.org\/wiki\/Nirvana_f\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "440587405897515008",
  "text" : "RT @TimHVines: This #PLoSFail thing is a textbook example of the Nirvana fallacy: http:\/\/t.co\/yHz5aVW00h",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "PLoSFail",
        "indices" : [ 5, 14 ]
      } ],
      "urls" : [ {
        "indices" : [ 67, 89 ],
        "url" : "http:\/\/t.co\/yHz5aVW00h",
        "expanded_url" : "http:\/\/en.wikipedia.org\/wiki\/Nirvana_fallacy",
        "display_url" : "en.wikipedia.org\/wiki\/Nirvana_f\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "439161828355358720",
    "text" : "This #PLoSFail thing is a textbook example of the Nirvana fallacy: http:\/\/t.co\/yHz5aVW00h",
    "id" : 439161828355358720,
    "created_at" : "2014-02-27 22:15:13 +0000",
    "user" : {
      "name" : "Tim Vines",
      "screen_name" : "TimHVines",
      "protected" : false,
      "id_str" : "2216245224",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/875450914185728002\/yaW5X7BI_normal.jpg",
      "id" : 2216245224,
      "verified" : false
    }
  },
  "id" : 440587405897515008,
  "created_at" : "2014-03-03 20:39:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.007670266, 8.2824766736 ]
  },
  "id_str" : "440573319537242112",
  "text" : "\u00ABMan k\u00F6nnte meinen ihr beiden feiert gar nicht Fastnacht?!\u00BB \u2014 \u00ABIch hab ein Kind, ich feiere das ganze Jahr \u00FCber Fastnacht\u2026\u00BB",
  "id" : 440573319537242112,
  "created_at" : "2014-03-03 19:43:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Science Web",
      "screen_name" : "TheScienceWeb",
      "indices" : [ 3, 17 ],
      "id_str" : "2315551122",
      "id" : 2315551122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/qa9PiYooIr",
      "expanded_url" : "http:\/\/wp.me\/p4ik2k-2a",
      "display_url" : "wp.me\/p4ik2k-2a"
    } ]
  },
  "geo" : { },
  "id_str" : "440570530341851136",
  "text" : "RT @TheScienceWeb: G8 expresses concern as Python steps up it's rhetoric against neighbouring languages http:\/\/t.co\/qa9PiYooIr",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 85, 107 ],
        "url" : "http:\/\/t.co\/qa9PiYooIr",
        "expanded_url" : "http:\/\/wp.me\/p4ik2k-2a",
        "display_url" : "wp.me\/p4ik2k-2a"
      } ]
    },
    "geo" : { },
    "id_str" : "440515328699686912",
    "text" : "G8 expresses concern as Python steps up it's rhetoric against neighbouring languages http:\/\/t.co\/qa9PiYooIr",
    "id" : 440515328699686912,
    "created_at" : "2014-03-03 15:53:33 +0000",
    "user" : {
      "name" : "The Science Web",
      "screen_name" : "TheScienceWeb",
      "protected" : false,
      "id_str" : "2315551122",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/428172546672824320\/1lZmC7lz_normal.jpeg",
      "id" : 2315551122,
      "verified" : false
    }
  },
  "id" : 440570530341851136,
  "created_at" : "2014-03-03 19:32:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    }, {
      "name" : "Ewen Callaway",
      "screen_name" : "ewencallaway",
      "indices" : [ 10, 23 ],
      "id_str" : "17251787",
      "id" : 17251787
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/iWDmc8Spsd",
      "expanded_url" : "https:\/\/twitter.com\/yokofakun\/status\/439518091756584960",
      "display_url" : "twitter.com\/yokofakun\/stat\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "440503913112817665",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723154633, 8.6276314583 ]
  },
  "id_str" : "440504537951272960",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez @ewencallaway @James_H_Fowler I guess this is pretty fitting https:\/\/t.co\/iWDmc8Spsd",
  "id" : 440504537951272960,
  "in_reply_to_status_id" : 440503913112817665,
  "created_at" : "2014-03-03 15:10:40 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "440504087511961601",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723154633, 8.6276314583 ]
  },
  "id_str" : "440504283554144256",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez and I guess if you\u2019re on the privacy-side of the whole topic it\u2019s certainly a fitting analogy.",
  "id" : 440504283554144256,
  "in_reply_to_status_id" : 440504087511961601,
  "created_at" : "2014-03-03 15:09:40 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "440503678001086464",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723154633, 8.6276314583 ]
  },
  "id_str" : "440503871753179136",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez just thought the headline sounded close to \u201Cliving with cancer\u201D et al. ;)",
  "id" : 440503871753179136,
  "in_reply_to_status_id" : 440503678001086464,
  "created_at" : "2014-03-03 15:08:01 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charlie",
      "screen_name" : "recently",
      "indices" : [ 3, 12 ],
      "id_str" : "849339903108317186",
      "id" : 849339903108317186
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Python",
      "indices" : [ 87, 94 ]
    }, {
      "text" : "Django",
      "indices" : [ 95, 102 ]
    } ],
    "urls" : [ {
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/3ViHBCvrVx",
      "expanded_url" : "http:\/\/recentlyapp.com",
      "display_url" : "recentlyapp.com"
    } ]
  },
  "geo" : { },
  "id_str" : "440500068417011712",
  "text" : "RT @Recently: We are currently looking for developer to work on http:\/\/t.co\/3ViHBCvrVx #Python #Django",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Python",
        "indices" : [ 73, 80 ]
      }, {
        "text" : "Django",
        "indices" : [ 81, 88 ]
      } ],
      "urls" : [ {
        "indices" : [ 50, 72 ],
        "url" : "http:\/\/t.co\/3ViHBCvrVx",
        "expanded_url" : "http:\/\/recentlyapp.com",
        "display_url" : "recentlyapp.com"
      } ]
    },
    "geo" : { },
    "id_str" : "440499778020212737",
    "text" : "We are currently looking for developer to work on http:\/\/t.co\/3ViHBCvrVx #Python #Django",
    "id" : 440499778020212737,
    "created_at" : "2014-03-03 14:51:45 +0000",
    "user" : {
      "name" : "Recently",
      "screen_name" : "RecentlySwap",
      "protected" : false,
      "id_str" : "1106065418",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3133432655\/b8575e066f86c6e42f6f44bcf0174710_normal.png",
      "id" : 1106065418,
      "verified" : false
    }
  },
  "id" : 440500068417011712,
  "created_at" : "2014-03-03 14:52:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/nvuxFdoXn0",
      "expanded_url" : "http:\/\/www.plosone.org\/article\/info:doi%2F10.1371%2Fjournal.pone.0090234",
      "display_url" : "plosone.org\/article\/info:d\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723154633, 8.6276314583 ]
  },
  "id_str" : "440495128307048449",
  "text" : "Sequence Depth, Not PCR Replication, Improves Ecological Inference from Next Generation DNA Sequencing http:\/\/t.co\/nvuxFdoXn0",
  "id" : 440495128307048449,
  "created_at" : "2014-03-03 14:33:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 5, 27 ],
      "url" : "http:\/\/t.co\/YKtHlE8z3w",
      "expanded_url" : "http:\/\/whatshouldwecallgradschool.tumblr.com\/post\/78122180849\/trying-to-make-sense-of-my-data",
      "display_url" : "whatshouldwecallgradschool.tumblr.com\/post\/781221808\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723154633, 8.6276314583 ]
  },
  "id_str" : "440491276568653824",
  "text" : "this http:\/\/t.co\/YKtHlE8z3w",
  "id" : 440491276568653824,
  "created_at" : "2014-03-03 14:17:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ed Yong",
      "screen_name" : "edyong209",
      "indices" : [ 3, 13 ],
      "id_str" : "19767193",
      "id" : 19767193
    }, {
      "name" : "Colin Schultz",
      "screen_name" : "_ColinS_",
      "indices" : [ 65, 74 ],
      "id_str" : "56722075",
      "id" : 56722075
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/BEwT4AxtDF",
      "expanded_url" : "http:\/\/sufficientlyremarkable.com\/comic\/groupthink",
      "display_url" : "sufficientlyremarkable.com\/comic\/groupthi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "440485660999577600",
  "text" : "RT @edyong209: On grouping and randomness. Love this cartoon. HT @_ColinS_ http:\/\/t.co\/BEwT4AxtDF",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Colin Schultz",
        "screen_name" : "_ColinS_",
        "indices" : [ 50, 59 ],
        "id_str" : "56722075",
        "id" : 56722075
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 60, 82 ],
        "url" : "http:\/\/t.co\/BEwT4AxtDF",
        "expanded_url" : "http:\/\/sufficientlyremarkable.com\/comic\/groupthink",
        "display_url" : "sufficientlyremarkable.com\/comic\/groupthi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "440485162200363009",
    "text" : "On grouping and randomness. Love this cartoon. HT @_ColinS_ http:\/\/t.co\/BEwT4AxtDF",
    "id" : 440485162200363009,
    "created_at" : "2014-03-03 13:53:41 +0000",
    "user" : {
      "name" : "Ed Yong",
      "screen_name" : "edyong209",
      "protected" : false,
      "id_str" : "19767193",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/926063794912153600\/962ygzzx_normal.jpg",
      "id" : 19767193,
      "verified" : true
    }
  },
  "id" : 440485660999577600,
  "created_at" : "2014-03-03 13:55:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/8J52xniDDQ",
      "expanded_url" : "http:\/\/4.bp.blogspot.com\/-SU0XOEzHSOA\/UkCGIKyrNqI\/AAAAAAAAAJk\/lpMeb4ZnPyc\/s1600\/cookies.gif",
      "display_url" : "4.bp.blogspot.com\/-SU0XOEzHSOA\/U\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723154633, 8.6276314583 ]
  },
  "id_str" : "440469126088503298",
  "text" : "\u00ABthe sample preparation for the data you\u2019ve been working on for 6 months? there\u2019s one major thing I didn\u2019t tell you\u2026\u00BB http:\/\/t.co\/8J52xniDDQ",
  "id" : 440469126088503298,
  "created_at" : "2014-03-03 12:49:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/HDqfZluUXK",
      "expanded_url" : "http:\/\/bps-research-digest.blogspot.de\/2014\/03\/introducing-youth-bias-how-we-think.html?utm_source=feedburner&utm_medium=feed&utm_campaign=Feed:+BpsResearchDigest+(BPS+Research+Digest",
      "display_url" : "bps-research-digest.blogspot.de\/2014\/03\/introd\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723154633, 8.6276314583 ]
  },
  "id_str" : "440442578618830848",
  "text" : "\u00ABThe youth bias holds that the most notable experiences of one's life, private or public, occur in young adulthood.\u00BB http:\/\/t.co\/HDqfZluUXK)",
  "id" : 440442578618830848,
  "created_at" : "2014-03-03 11:04:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 41, 50 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/TLFjZhXpxn",
      "expanded_url" : "http:\/\/ernestoramirez.com\/2014\/03\/02\/iving-with-data\/",
      "display_url" : "ernestoramirez.com\/2014\/03\/02\/ivi\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723154633, 8.6276314583 ]
  },
  "id_str" : "440406621815320576",
  "text" : "Some questions around Quantified Self by @eramirez: \u00ABLiving With Data\u00BB (makes it sound a bit like data is a disease) http:\/\/t.co\/TLFjZhXpxn",
  "id" : 440406621815320576,
  "created_at" : "2014-03-03 08:41:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/kindle.amazon.com\" rel=\"nofollow\"\u003EKindle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/6qjP2lDDUZ",
      "expanded_url" : "http:\/\/amzn.com\/k\/weXkt8VlR6aJWZIOM-4sZw",
      "display_url" : "amzn.com\/k\/weXkt8VlR6aJ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "440391559088177152",
  "text" : "\u00ABthe dachshund began his research on Christmas Eve and now, 5 months later, is taking his Ph.D.\u00BB http:\/\/t.co\/6qjP2lDDUZ The advertise...",
  "id" : 440391559088177152,
  "created_at" : "2014-03-03 07:41:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 13, 26 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "440383990839525376",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0058449479, 8.332174765 ]
  },
  "id_str" : "440384891902230528",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch @PhilippBayer getting your money was like finding a large sum under your sofa cushions, better just gamble with it? ;)",
  "id" : 440384891902230528,
  "in_reply_to_status_id" : 440383990839525376,
  "created_at" : "2014-03-03 07:15:14 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ali",
      "screen_name" : "zoonpolitikon",
      "indices" : [ 0, 14 ],
      "id_str" : "13040652",
      "id" : 13040652
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 15, 28 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "440382343195664384",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0066378341, 8.2828028407 ]
  },
  "id_str" : "440383123373948928",
  "in_reply_to_user_id" : 13040652,
  "text" : "@zoonpolitikon @PhilippBayer but that would lead to hyperinflation of my waistline!",
  "id" : 440383123373948928,
  "in_reply_to_status_id" : 440382343195664384,
  "created_at" : "2014-03-03 07:08:13 +0000",
  "in_reply_to_screen_name" : "zoonpolitikon",
  "in_reply_to_user_id_str" : "13040652",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "440381477360906240",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0071501958, 8.2833864106 ]
  },
  "id_str" : "440381860875894784",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer nah, this will restock my travel funds.",
  "id" : 440381860875894784,
  "in_reply_to_status_id" : 440381477360906240,
  "created_at" : "2014-03-03 07:03:12 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "440360472361984000",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0073812997, 8.2831800468 ]
  },
  "id_str" : "440380881178742784",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer from rags to riches, in 3 simple emails! ;) thanks!",
  "id" : 440380881178742784,
  "in_reply_to_status_id" : 440360472361984000,
  "created_at" : "2014-03-03 06:59:18 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/FiZsoBEZb2",
      "expanded_url" : "http:\/\/imgur.com\/vIGFPX5",
      "display_url" : "imgur.com\/vIGFPX5"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096713343, 8.2830788 ]
  },
  "id_str" : "440261519616774144",
  "text" : "One of the best headlines ever: \u00ABKoala escapes at zoo, falls asleep before he can do anything interesting\u00BB &lt;3 http:\/\/t.co\/FiZsoBEZb2",
  "id" : 440261519616774144,
  "created_at" : "2014-03-02 23:05:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/pT709gGaN2",
      "expanded_url" : "http:\/\/www.theguardian.com\/higher-education-network\/blog\/2014\/mar\/01\/mental-health-issue-phd-research-university?CMP=twt_gu",
      "display_url" : "theguardian.com\/higher-educati\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009660925, 8.28305201 ]
  },
  "id_str" : "440257642347651072",
  "text" : "\u00ABIt is not OK for PhD students to maintain the culture of working yourself to the point of illness.\u00BB http:\/\/t.co\/pT709gGaN2",
  "id" : 440257642347651072,
  "created_at" : "2014-03-02 22:49:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Martin F. Robbins",
      "screen_name" : "mjrobbins",
      "indices" : [ 3, 13 ],
      "id_str" : "14315063",
      "id" : 14315063
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/mjrobbins\/status\/440151411217539072\/photo\/1",
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/PO53Mmwfp8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bhu7YFmCYAAbT1n.png",
      "id_str" : "440151411091726336",
      "id" : 440151411091726336,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bhu7YFmCYAAbT1n.png",
      "sizes" : [ {
        "h" : 406,
        "resize" : "fit",
        "w" : 652
      }, {
        "h" : 406,
        "resize" : "fit",
        "w" : 652
      }, {
        "h" : 406,
        "resize" : "fit",
        "w" : 652
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 406,
        "resize" : "fit",
        "w" : 652
      } ],
      "display_url" : "pic.twitter.com\/PO53Mmwfp8"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "440160436202524673",
  "text" : "RT @mjrobbins: Mail shocked to discover that BBC staff use computers. Jesus wept. http:\/\/t.co\/PO53Mmwfp8",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/mjrobbins\/status\/440151411217539072\/photo\/1",
        "indices" : [ 67, 89 ],
        "url" : "http:\/\/t.co\/PO53Mmwfp8",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bhu7YFmCYAAbT1n.png",
        "id_str" : "440151411091726336",
        "id" : 440151411091726336,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bhu7YFmCYAAbT1n.png",
        "sizes" : [ {
          "h" : 406,
          "resize" : "fit",
          "w" : 652
        }, {
          "h" : 406,
          "resize" : "fit",
          "w" : 652
        }, {
          "h" : 406,
          "resize" : "fit",
          "w" : 652
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 406,
          "resize" : "fit",
          "w" : 652
        } ],
        "display_url" : "pic.twitter.com\/PO53Mmwfp8"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "440151411217539072",
    "text" : "Mail shocked to discover that BBC staff use computers. Jesus wept. http:\/\/t.co\/PO53Mmwfp8",
    "id" : 440151411217539072,
    "created_at" : "2014-03-02 15:47:28 +0000",
    "user" : {
      "name" : "Martin F. Robbins",
      "screen_name" : "mjrobbins",
      "protected" : false,
      "id_str" : "14315063",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/889888866257297408\/smSw_n3y_normal.jpg",
      "id" : 14315063,
      "verified" : true
    }
  },
  "id" : 440160436202524673,
  "created_at" : "2014-03-02 16:23:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 50 ],
      "url" : "http:\/\/t.co\/tmUowUgaIE",
      "expanded_url" : "http:\/\/instagram.com\/p\/lC79aqBwjI\/",
      "display_url" : "instagram.com\/p\/lC79aqBwjI\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.006663343, 8.277039528 ]
  },
  "id_str" : "440152306508922880",
  "text" : "Meta @ Theodor-Heuss-Br\u00FCcke http:\/\/t.co\/tmUowUgaIE",
  "id" : 440152306508922880,
  "created_at" : "2014-03-02 15:51:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ipoow",
      "indices" : [ 98, 104 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009686919, 8.2831214368 ]
  },
  "id_str" : "440151411255701504",
  "text" : "\u00ABI thought you Europeans were supposed to be heroes in the war of the sexes!\u00BB \u2014 \u00ABI\u2019m a pacifist.\u00BB #ipoow",
  "id" : 440151411255701504,
  "created_at" : "2014-03-02 15:47:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ipoow",
      "indices" : [ 113, 119 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097041048, 8.2830659736 ]
  },
  "id_str" : "440130433712685056",
  "text" : "\u00ABYou\u2019re a student of philosophy \u2014 you should know that life is chaotic, senseless and painful most of the time.\u00BB #ipoow",
  "id" : 440130433712685056,
  "created_at" : "2014-03-02 14:24:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096297204, 8.2830048643 ]
  },
  "id_str" : "440119871670870016",
  "text" : "\u00BBIn der Hinsicht sind intergenerationelle Beziehungen wie interdisziplin\u00E4re Forschung: Personal Growth Hacking.\u00BB",
  "id" : 440119871670870016,
  "created_at" : "2014-03-02 13:42:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0001730822, 8.309031288 ]
  },
  "id_str" : "440102396749176832",
  "text" : "\u00ABPut me in Markov chains and train me!\u00BB \u2014 \u00ABAh, the good old \u2018maximize the emission probabilities\u2019-game.\u00BB",
  "id" : 440102396749176832,
  "created_at" : "2014-03-02 12:32:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "A Queer Has No Name",
      "screen_name" : "memeticsexgod",
      "indices" : [ 0, 14 ],
      "id_str" : "1451060280",
      "id" : 1451060280
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "440091138771677184",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0000473274, 8.2725584249 ]
  },
  "id_str" : "440092305572507648",
  "in_reply_to_user_id" : 1451060280,
  "text" : "@memeticsexgod unfollow-Sonntag um die 50%(-H\u00FCrde) zu nehmen? ;)",
  "id" : 440092305572507648,
  "in_reply_to_status_id" : 440091138771677184,
  "created_at" : "2014-03-02 11:52:36 +0000",
  "in_reply_to_screen_name" : "memeticsexgod",
  "in_reply_to_user_id_str" : "1451060280",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "A Queer Has No Name",
      "screen_name" : "memeticsexgod",
      "indices" : [ 0, 14 ],
      "id_str" : "1451060280",
      "id" : 1451060280
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "440089980372025344",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0020001488, 8.2663192028 ]
  },
  "id_str" : "440091072036089856",
  "in_reply_to_user_id" : 1451060280,
  "text" : "@memeticsexgod life goal: transformation \u2018w\u00FCrde\u2019 -&gt; \u2018hatte\u2019\/\u2018habe\u2019",
  "id" : 440091072036089856,
  "in_reply_to_status_id" : 440089980372025344,
  "created_at" : "2014-03-02 11:47:42 +0000",
  "in_reply_to_screen_name" : "memeticsexgod",
  "in_reply_to_user_id_str" : "1451060280",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vaughan Bell",
      "screen_name" : "vaughanbell",
      "indices" : [ 3, 15 ],
      "id_str" : "20542737",
      "id" : 20542737
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/DYPj7qeFoQ",
      "expanded_url" : "http:\/\/is.gd\/9IhulZ",
      "display_url" : "is.gd\/9IhulZ"
    } ]
  },
  "geo" : { },
  "id_str" : "440073302015770624",
  "text" : "RT @vaughanbell: The misuse of science in 'dating advice' and why it should make you angry http:\/\/t.co\/DYPj7qeFoQ Good piece by @girlonthen\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Girl on the Net",
        "screen_name" : "girlonthenet",
        "indices" : [ 111, 124 ],
        "id_str" : "137466551",
        "id" : 137466551
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 74, 96 ],
        "url" : "http:\/\/t.co\/DYPj7qeFoQ",
        "expanded_url" : "http:\/\/is.gd\/9IhulZ",
        "display_url" : "is.gd\/9IhulZ"
      } ]
    },
    "geo" : { },
    "id_str" : "440070660745097216",
    "text" : "The misuse of science in 'dating advice' and why it should make you angry http:\/\/t.co\/DYPj7qeFoQ Good piece by @girlonthenet",
    "id" : 440070660745097216,
    "created_at" : "2014-03-02 10:26:36 +0000",
    "user" : {
      "name" : "Vaughan Bell",
      "screen_name" : "vaughanbell",
      "protected" : false,
      "id_str" : "20542737",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/882339486641803264\/SHqUUNbc_normal.jpg",
      "id" : 20542737,
      "verified" : false
    }
  },
  "id" : 440073302015770624,
  "created_at" : "2014-03-02 10:37:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Maarten den Braber",
      "screen_name" : "mdbraber",
      "indices" : [ 0, 9 ],
      "id_str" : "9938952",
      "id" : 9938952
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "440069770785083392",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0020744883, 8.2661389337 ]
  },
  "id_str" : "440070370096586752",
  "in_reply_to_user_id" : 9938952,
  "text" : "@mdbraber yes, at least from one iOS device to another.",
  "id" : 440070370096586752,
  "in_reply_to_status_id" : 440069770785083392,
  "created_at" : "2014-03-02 10:25:27 +0000",
  "in_reply_to_screen_name" : "mdbraber",
  "in_reply_to_user_id_str" : "9938952",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 53 ],
      "url" : "http:\/\/t.co\/e7f6tmUXGr",
      "expanded_url" : "http:\/\/paintyourpanda.blogspot.de\/2014\/03\/forensic-anthropology-and-race.html?utm_source=feedburner&utm_medium=feed&utm_campaign=Feed:+ResearchBloggingBiologyEnglish+(Research+Blogging+-+English+-+Biology",
      "display_url" : "paintyourpanda.blogspot.de\/2014\/03\/forens\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.002036, 8.266178 ]
  },
  "id_str" : "440065024519077888",
  "text" : "Forensic Anthropology and Race http:\/\/t.co\/e7f6tmUXGr)",
  "id" : 440065024519077888,
  "created_at" : "2014-03-02 10:04:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096792196, 8.2830664583 ]
  },
  "id_str" : "440058565920059392",
  "text" : "Nifty! TIL you can use the Spotify apps for remote controlling playback on other devices.",
  "id" : 440058565920059392,
  "created_at" : "2014-03-02 09:38:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 3, 16 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 67 ],
      "url" : "http:\/\/t.co\/gs0ojSORjf",
      "expanded_url" : "http:\/\/xcorr.net\/2014\/03\/01\/how-real-science-labs-work\/?utm_source=feedburner&utm_medium=feed&utm_campaign=Feed%3A+ResearchBloggingAllEnglish+%28Research+Blogging+-+English+-+All+Topics%29",
      "display_url" : "xcorr.net\/2014\/03\/01\/how\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "440054908990275584",
  "text" : "RT @PhilippBayer: How real science labs work http:\/\/t.co\/gs0ojSORjf",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 27, 49 ],
        "url" : "http:\/\/t.co\/gs0ojSORjf",
        "expanded_url" : "http:\/\/xcorr.net\/2014\/03\/01\/how-real-science-labs-work\/?utm_source=feedburner&utm_medium=feed&utm_campaign=Feed%3A+ResearchBloggingAllEnglish+%28Research+Blogging+-+English+-+All+Topics%29",
        "display_url" : "xcorr.net\/2014\/03\/01\/how\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "440053267481907200",
    "text" : "How real science labs work http:\/\/t.co\/gs0ojSORjf",
    "id" : 440053267481907200,
    "created_at" : "2014-03-02 09:17:29 +0000",
    "user" : {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "protected" : false,
      "id_str" : "121777206",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2013711027\/IMG_1088_normal.png",
      "id" : 121777206,
      "verified" : false
    }
  },
  "id" : 440054908990275584,
  "created_at" : "2014-03-02 09:24:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ipoow",
      "indices" : [ 120, 126 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097380486, 8.2829902601 ]
  },
  "id_str" : "440046722270904320",
  "text" : "\u00ABWhatever else sex was, it was obviously team-work, and I began to suspect that strangers [\u2026] rarely made a good team.\u00BB #ipoow",
  "id" : 440046722270904320,
  "created_at" : "2014-03-02 08:51:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dan nolan - chief brand respecter",
      "screen_name" : "dannolan",
      "indices" : [ 3, 12 ],
      "id_str" : "971761",
      "id" : 971761
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/dannolan\/status\/439955701369012224\/photo\/1",
      "indices" : [ 30, 52 ],
      "url" : "http:\/\/t.co\/6NXzoh1nyG",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BhsJYRWCEAEHGam.jpg",
      "id_str" : "439955701176078337",
      "id" : 439955701176078337,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BhsJYRWCEAEHGam.jpg",
      "sizes" : [ {
        "h" : 821,
        "resize" : "fit",
        "w" : 576
      }, {
        "h" : 821,
        "resize" : "fit",
        "w" : 576
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 477
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 821,
        "resize" : "fit",
        "w" : 576
      } ],
      "display_url" : "pic.twitter.com\/6NXzoh1nyG"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "440042183769735168",
  "text" : "RT @dannolan: hahahahahahhaha http:\/\/t.co\/6NXzoh1nyG",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/dannolan\/status\/439955701369012224\/photo\/1",
        "indices" : [ 16, 38 ],
        "url" : "http:\/\/t.co\/6NXzoh1nyG",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BhsJYRWCEAEHGam.jpg",
        "id_str" : "439955701176078337",
        "id" : 439955701176078337,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BhsJYRWCEAEHGam.jpg",
        "sizes" : [ {
          "h" : 821,
          "resize" : "fit",
          "w" : 576
        }, {
          "h" : 821,
          "resize" : "fit",
          "w" : 576
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 477
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 821,
          "resize" : "fit",
          "w" : 576
        } ],
        "display_url" : "pic.twitter.com\/6NXzoh1nyG"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "439955701369012224",
    "text" : "hahahahahahhaha http:\/\/t.co\/6NXzoh1nyG",
    "id" : 439955701369012224,
    "created_at" : "2014-03-02 02:49:47 +0000",
    "user" : {
      "name" : "dan nolan - chief brand respecter",
      "screen_name" : "dannolan",
      "protected" : false,
      "id_str" : "971761",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/830008165970227200\/xO0XRuIG_normal.jpg",
      "id" : 971761,
      "verified" : true
    }
  },
  "id" : 440042183769735168,
  "created_at" : "2014-03-02 08:33:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zack Shure",
      "screen_name" : "thesystem",
      "indices" : [ 0, 10 ],
      "id_str" : "15520720",
      "id" : 15520720
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 33 ],
      "url" : "http:\/\/t.co\/ha6kEbkR0b",
      "expanded_url" : "http:\/\/en.wikipedia.org\/wiki\/In_Praise_of_Older_Women_(book)",
      "display_url" : "en.wikipedia.org\/wiki\/In_Praise\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "439925104315994112",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009660925, 8.28305201 ]
  },
  "id_str" : "439925156879032321",
  "in_reply_to_user_id" : 15520720,
  "text" : "@thesystem http:\/\/t.co\/ha6kEbkR0b :)",
  "id" : 439925156879032321,
  "in_reply_to_status_id" : 439925104315994112,
  "created_at" : "2014-03-02 00:48:25 +0000",
  "in_reply_to_screen_name" : "thesystem",
  "in_reply_to_user_id_str" : "15520720",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "punycode",
      "screen_name" : "punycode",
      "indices" : [ 0, 9 ],
      "id_str" : "14328131",
      "id" : 14328131
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 32 ],
      "url" : "http:\/\/t.co\/ha6kEbkR0b",
      "expanded_url" : "http:\/\/en.wikipedia.org\/wiki\/In_Praise_of_Older_Women_(book)",
      "display_url" : "en.wikipedia.org\/wiki\/In_Praise\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "439920478678188032",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009660925, 8.28305201 ]
  },
  "id_str" : "439920590791921664",
  "in_reply_to_user_id" : 14328131,
  "text" : "@punycode http:\/\/t.co\/ha6kEbkR0b",
  "id" : 439920590791921664,
  "in_reply_to_status_id" : 439920478678188032,
  "created_at" : "2014-03-02 00:30:16 +0000",
  "in_reply_to_screen_name" : "punycode",
  "in_reply_to_user_id_str" : "14328131",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ipoow",
      "indices" : [ 129, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009660925, 8.28305201 ]
  },
  "id_str" : "439919282798215168",
  "text" : "\u00ABThe idea that you can only love one person is the reason why most people live in confusion.\u00BB bildungsroman right from the start #ipoow",
  "id" : 439919282798215168,
  "created_at" : "2014-03-02 00:25:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ipoow",
      "indices" : [ 138, 144 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009660925, 8.28305201 ]
  },
  "id_str" : "439917201039310848",
  "text" : "Such a nice rite of passage: \u00ABYou\u2019ll learn that love rarely lasts &amp; that it\u2019s possible to love more than one person at the same time\u00BB #ipoow",
  "id" : 439917201039310848,
  "created_at" : "2014-03-02 00:16:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DNAdigest.org",
      "screen_name" : "DNADigest",
      "indices" : [ 34, 44 ],
      "id_str" : "334912047",
      "id" : 334912047
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/f23kLK43Le",
      "expanded_url" : "http:\/\/dnadigest.org\/data-sharing-essay-competition\/",
      "display_url" : "dnadigest.org\/data-sharing-e\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096618617, 8.2830252933 ]
  },
  "id_str" : "439880971522170880",
  "text" : "Data Sharing Essay Competition by @DNADigest:How do you imagine the future of data sharing in healthcare or research? http:\/\/t.co\/f23kLK43Le",
  "id" : 439880971522170880,
  "created_at" : "2014-03-01 21:52:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason H. Moore, PhD",
      "screen_name" : "moorejh",
      "indices" : [ 3, 11 ],
      "id_str" : "15496407",
      "id" : 15496407
    }, {
      "name" : "Chris. Bourguignat",
      "screen_name" : "chris_bour",
      "indices" : [ 16, 27 ],
      "id_str" : "209472059",
      "id" : 209472059
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/chris_bour\/status\/439879804645429248\/photo\/1",
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/cvxcaTF11M",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BhrEWgwCUAAQA1J.jpg",
      "id_str" : "439879804649623552",
      "id" : 439879804649623552,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BhrEWgwCUAAQA1J.jpg",
      "sizes" : [ {
        "h" : 386,
        "resize" : "fit",
        "w" : 1018
      }, {
        "h" : 258,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 386,
        "resize" : "fit",
        "w" : 1018
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 386,
        "resize" : "fit",
        "w" : 1018
      } ],
      "display_url" : "pic.twitter.com\/cvxcaTF11M"
    } ],
    "hashtags" : [ {
      "text" : "MachineLearning",
      "indices" : [ 44, 60 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "439880566704713728",
  "text" : "RT @moorejh: RT @chris_bour: It's more than #MachineLearning. It's Art. http:\/\/t.co\/cvxcaTF11M",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Chris. Bourguignat",
        "screen_name" : "chris_bour",
        "indices" : [ 3, 14 ],
        "id_str" : "209472059",
        "id" : 209472059
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/chris_bour\/status\/439879804645429248\/photo\/1",
        "indices" : [ 59, 81 ],
        "url" : "http:\/\/t.co\/cvxcaTF11M",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BhrEWgwCUAAQA1J.jpg",
        "id_str" : "439879804649623552",
        "id" : 439879804649623552,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BhrEWgwCUAAQA1J.jpg",
        "sizes" : [ {
          "h" : 386,
          "resize" : "fit",
          "w" : 1018
        }, {
          "h" : 258,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 386,
          "resize" : "fit",
          "w" : 1018
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 386,
          "resize" : "fit",
          "w" : 1018
        } ],
        "display_url" : "pic.twitter.com\/cvxcaTF11M"
      } ],
      "hashtags" : [ {
        "text" : "MachineLearning",
        "indices" : [ 31, 47 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "439880075371372544",
    "text" : "RT @chris_bour: It's more than #MachineLearning. It's Art. http:\/\/t.co\/cvxcaTF11M",
    "id" : 439880075371372544,
    "created_at" : "2014-03-01 21:49:17 +0000",
    "user" : {
      "name" : "Jason H. Moore, PhD",
      "screen_name" : "moorejh",
      "protected" : false,
      "id_str" : "15496407",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/550024402142625793\/5aw9u9E8_normal.jpeg",
      "id" : 15496407,
      "verified" : false
    }
  },
  "id" : 439880566704713728,
  "created_at" : "2014-03-01 21:51:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 125, 138 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/ZrLft6IwQR",
      "expanded_url" : "http:\/\/link.springer.com\/article\/10.1007\/s00439-014-1432-6\/fulltext.html",
      "display_url" : "link.springer.com\/article\/10.100\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096618617, 8.2830252933 ]
  },
  "id_str" : "439878816874655744",
  "text" : "A human rights approach to an international code of conduct for genomic and clinical data sharing http:\/\/t.co\/ZrLft6IwQR \/cc @PhilippBayer",
  "id" : 439878816874655744,
  "created_at" : "2014-03-01 21:44:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096618617, 8.2830252933 ]
  },
  "id_str" : "439868591807406081",
  "text" : "\u00ABDid you put \u2018In Praise of Older Women\u2019 into the Dropbox?!\u00BB\u2013\u00ABNo, I\u2019m not the target audience. Or do you think I still need to be convinced?\u00BB",
  "id" : 439868591807406081,
  "created_at" : "2014-03-01 21:03:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "li5a",
      "screen_name" : "li5a",
      "indices" : [ 3, 8 ],
      "id_str" : "11712822",
      "id" : 11712822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "439864873674358785",
  "text" : "RT @li5a: Die Biotinkerer veranstalten am 6. April einen Workshop: Bakterien, Viren und Computer - Bioinformatik f\u00FCr Anf\u00E4nger http:\/\/t.co\/a\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/azChHqqhW6",
        "expanded_url" : "http:\/\/www.biotinkering-berlin.de\/node\/6",
        "display_url" : "biotinkering-berlin.de\/node\/6"
      } ]
    },
    "geo" : { },
    "id_str" : "439862601682395136",
    "text" : "Die Biotinkerer veranstalten am 6. April einen Workshop: Bakterien, Viren und Computer - Bioinformatik f\u00FCr Anf\u00E4nger http:\/\/t.co\/azChHqqhW6",
    "id" : 439862601682395136,
    "created_at" : "2014-03-01 20:39:51 +0000",
    "user" : {
      "name" : "li5a",
      "screen_name" : "li5a",
      "protected" : false,
      "id_str" : "11712822",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/42645812\/P1010897_normal.JPG",
      "id" : 11712822,
      "verified" : false
    }
  },
  "id" : 439864873674358785,
  "created_at" : "2014-03-01 20:48:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DNAdigest.org",
      "screen_name" : "DNADigest",
      "indices" : [ 4, 14 ],
      "id_str" : "334912047",
      "id" : 334912047
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/MivnkIcKkK",
      "expanded_url" : "http:\/\/thndr.it\/MEkuLL",
      "display_url" : "thndr.it\/MEkuLL"
    } ]
  },
  "geo" : { },
  "id_str" : "439833834331193344",
  "text" : "Oh, @DNADigest will have a thunderclap on March 13th. Have a look at their idea: http:\/\/t.co\/MivnkIcKkK",
  "id" : 439833834331193344,
  "created_at" : "2014-03-01 18:45:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fressesprecher",
      "screen_name" : "Bediko",
      "indices" : [ 0, 7 ],
      "id_str" : "56530362",
      "id" : 56530362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "439831922865627136",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096618617, 8.2830252933 ]
  },
  "id_str" : "439832133566492672",
  "in_reply_to_user_id" : 56530362,
  "text" : "@Bediko ah, ok. Ich muss jetzt mal rausfinden wie man aus tinkercad exportiert ;)",
  "id" : 439832133566492672,
  "in_reply_to_status_id" : 439831922865627136,
  "created_at" : "2014-03-01 18:38:46 +0000",
  "in_reply_to_screen_name" : "Bediko",
  "in_reply_to_user_id_str" : "56530362",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fressesprecher",
      "screen_name" : "Bediko",
      "indices" : [ 0, 7 ],
      "id_str" : "56530362",
      "id" : 56530362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "439830844279386112",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096618617, 8.2830252933 ]
  },
  "id_str" : "439831795497177088",
  "in_reply_to_user_id" : 56530362,
  "text" : "@Bediko huh?",
  "id" : 439831795497177088,
  "in_reply_to_status_id" : 439830844279386112,
  "created_at" : "2014-03-01 18:37:26 +0000",
  "in_reply_to_screen_name" : "Bediko",
  "in_reply_to_user_id_str" : "56530362",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fressesprecher",
      "screen_name" : "Bediko",
      "indices" : [ 0, 7 ],
      "id_str" : "56530362",
      "id" : 56530362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "439830582688616448",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096979563, 8.2831184194 ]
  },
  "id_str" : "439830695134117888",
  "in_reply_to_user_id" : 56530362,
  "text" : "@Bediko danke f\u00FCr den Pointer :)",
  "id" : 439830695134117888,
  "in_reply_to_status_id" : 439830582688616448,
  "created_at" : "2014-03-01 18:33:04 +0000",
  "in_reply_to_screen_name" : "Bediko",
  "in_reply_to_user_id_str" : "56530362",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fressesprecher",
      "screen_name" : "Bediko",
      "indices" : [ 0, 7 ],
      "id_str" : "56530362",
      "id" : 56530362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "439830216832450560",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096618617, 8.2830252933 ]
  },
  "id_str" : "439830448517447680",
  "in_reply_to_user_id" : 56530362,
  "text" : "@Bediko ah, okay. Hab dein repo auch mal forked, mal schauen ob ich Zeit daf\u00FCr finde. tinkercad waren vielleicht 10 Minuten from scratch.",
  "id" : 439830448517447680,
  "in_reply_to_status_id" : 439830216832450560,
  "created_at" : "2014-03-01 18:32:05 +0000",
  "in_reply_to_screen_name" : "Bediko",
  "in_reply_to_user_id_str" : "56530362",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fressesprecher",
      "screen_name" : "Bediko",
      "indices" : [ 0, 7 ],
      "id_str" : "56530362",
      "id" : 56530362
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/439830025513500672\/photo\/1",
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/9wgfnJkOTp",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BhqXE-PIcAAgYO4.png",
      "id_str" : "439830025303781376",
      "id" : 439830025303781376,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BhqXE-PIcAAgYO4.png",
      "sizes" : [ {
        "h" : 680,
        "resize" : "fit",
        "w" : 391
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 813,
        "resize" : "fit",
        "w" : 467
      }, {
        "h" : 813,
        "resize" : "fit",
        "w" : 467
      }, {
        "h" : 813,
        "resize" : "fit",
        "w" : 467
      } ],
      "display_url" : "pic.twitter.com\/9wgfnJkOTp"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "439806261442252800",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096618617, 8.2830252933 ]
  },
  "id_str" : "439830025513500672",
  "in_reply_to_user_id" : 56530362,
  "text" : "@Bediko sehr cool, und du hast recht: tinkercad ist ziemlich easy to use. http:\/\/t.co\/9wgfnJkOTp",
  "id" : 439830025513500672,
  "in_reply_to_status_id" : 439806261442252800,
  "created_at" : "2014-03-01 18:30:24 +0000",
  "in_reply_to_screen_name" : "Bediko",
  "in_reply_to_user_id_str" : "56530362",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "439811913967353856",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096618617, 8.2830252933 ]
  },
  "id_str" : "439812043693375488",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez great. What do you do on mondays? :)",
  "id" : 439812043693375488,
  "in_reply_to_status_id" : 439811913967353856,
  "created_at" : "2014-03-01 17:18:57 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "439811037341024256",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009675105, 8.2829993875 ]
  },
  "id_str" : "439811822003441664",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez cool, love the heatmaps :)",
  "id" : 439811822003441664,
  "in_reply_to_status_id" : 439811037341024256,
  "created_at" : "2014-03-01 17:18:04 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    }, {
      "name" : "Eric Blue",
      "screen_name" : "ericblue",
      "indices" : [ 10, 19 ],
      "id_str" : "15436941",
      "id" : 15436941
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "439810667042705408",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009675105, 8.2829993875 ]
  },
  "id_str" : "439810852842381312",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez @ericblue cool, thanks for the update! :)",
  "id" : 439810852842381312,
  "in_reply_to_status_id" : 439810667042705408,
  "created_at" : "2014-03-01 17:14:13 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009672854, 8.28306135 ]
  },
  "id_str" : "439804831398912000",
  "text" : "\u00ABEigentlich wollten wir nur in die Stadt einkaufen. Aber dann sind wir in den Kinderkarnevalsumzug geraten und jetzt sind wir betrunken.\u00BB",
  "id" : 439804831398912000,
  "created_at" : "2014-03-01 16:50:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009672854, 8.28306135 ]
  },
  "id_str" : "439802810851680259",
  "text" : "\u00ABNa, auch aus Kastel gefl\u00FCchtet um dem lokalen Aufmarsch der faschistisch-derpokratischen Grundordnung zu entfliehen?\u00BB",
  "id" : 439802810851680259,
  "created_at" : "2014-03-01 16:42:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 45 ],
      "url" : "http:\/\/t.co\/aCyaTKlwbW",
      "expanded_url" : "http:\/\/instagram.com\/p\/lAWhbWhwtV\/",
      "display_url" : "instagram.com\/p\/lAWhbWhwtV\/"
    } ]
  },
  "geo" : { },
  "id_str" : "439788506425331713",
  "text" : "R\u00FCckseite: WS11 - SS13 http:\/\/t.co\/aCyaTKlwbW",
  "id" : 439788506425331713,
  "created_at" : "2014-03-01 15:45:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fressesprecher",
      "screen_name" : "Bediko",
      "indices" : [ 0, 7 ],
      "id_str" : "56530362",
      "id" : 56530362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "439755195623673856",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.008774175, 8.281381223 ]
  },
  "id_str" : "439756279368929280",
  "in_reply_to_user_id" : 56530362,
  "text" : "@Bediko wobei das kommt auch nicht hin. Breiteste Stelle &lt;-&gt; sieht mehr nach was um 2\/3 aus",
  "id" : 439756279368929280,
  "in_reply_to_status_id" : 439755195623673856,
  "created_at" : "2014-03-01 13:37:21 +0000",
  "in_reply_to_screen_name" : "Bediko",
  "in_reply_to_user_id_str" : "56530362",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fressesprecher",
      "screen_name" : "Bediko",
      "indices" : [ 0, 7 ],
      "id_str" : "56530362",
      "id" : 56530362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "439755195623673856",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009132741, 8.2815053313 ]
  },
  "id_str" : "439756014666010624",
  "in_reply_to_user_id" : 56530362,
  "text" : "@Bediko w\u00E4ren also ~13 Gesamtl\u00E4nge wenn meine Vermutung stimmt.",
  "id" : 439756014666010624,
  "in_reply_to_status_id" : 439755195623673856,
  "created_at" : "2014-03-01 13:36:18 +0000",
  "in_reply_to_screen_name" : "Bediko",
  "in_reply_to_user_id_str" : "56530362",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fressesprecher",
      "screen_name" : "Bediko",
      "indices" : [ 0, 7 ],
      "id_str" : "56530362",
      "id" : 56530362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "439754718869737472",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096868563, 8.283106313 ]
  },
  "id_str" : "439755001486127105",
  "in_reply_to_user_id" : 56530362,
  "text" : "@Bediko 10 als L\u00E4nge von breitester Stelle zu Spitze k\u00F6nnte ich mir vorstellen vom Bild her.",
  "id" : 439755001486127105,
  "in_reply_to_status_id" : 439754718869737472,
  "created_at" : "2014-03-01 13:32:17 +0000",
  "in_reply_to_screen_name" : "Bediko",
  "in_reply_to_user_id_str" : "56530362",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fressesprecher",
      "screen_name" : "Bediko",
      "indices" : [ 0, 7 ],
      "id_str" : "56530362",
      "id" : 56530362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "439754114579562496",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097030784, 8.283161233 ]
  },
  "id_str" : "439754480138326016",
  "in_reply_to_user_id" : 56530362,
  "text" : "@Bediko 7\/10 scheint mir aber vom Bild her auch nicht zu stimmen wenn du die Gesamtl\u00E4nge meinst.",
  "id" : 439754480138326016,
  "in_reply_to_status_id" : 439754114579562496,
  "created_at" : "2014-03-01 13:30:12 +0000",
  "in_reply_to_screen_name" : "Bediko",
  "in_reply_to_user_id_str" : "56530362",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fressesprecher",
      "screen_name" : "Bediko",
      "indices" : [ 0, 7 ],
      "id_str" : "56530362",
      "id" : 56530362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "439572020502618112",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096693193, 8.2830421442 ]
  },
  "id_str" : "439572206600093697",
  "in_reply_to_user_id" : 56530362,
  "text" : "@Bediko perfekt, danke. Was ein gute Nacht-Geschenk! Und dir auch eine geruhsame Nacht irgendwann :)",
  "id" : 439572206600093697,
  "in_reply_to_status_id" : 439572020502618112,
  "created_at" : "2014-03-01 01:25:55 +0000",
  "in_reply_to_screen_name" : "Bediko",
  "in_reply_to_user_id_str" : "56530362",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fressesprecher",
      "screen_name" : "Bediko",
      "indices" : [ 0, 7 ],
      "id_str" : "56530362",
      "id" : 56530362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "439570905510215680",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096693193, 8.2830421442 ]
  },
  "id_str" : "439571615589085184",
  "in_reply_to_user_id" : 56530362,
  "text" : "@Bediko 0.35 w\u00E4re vielleicht noch nen Versuch wert. Gehe aber wirklich erstmal schlafen. Bin aber sehr gespannt wohin es sich entwickelt :)",
  "id" : 439571615589085184,
  "in_reply_to_status_id" : 439570905510215680,
  "created_at" : "2014-03-01 01:23:34 +0000",
  "in_reply_to_screen_name" : "Bediko",
  "in_reply_to_user_id_str" : "56530362",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fressesprecher",
      "screen_name" : "Bediko",
      "indices" : [ 0, 7 ],
      "id_str" : "56530362",
      "id" : 56530362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "439570345075306496",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097217877, 8.2829673775 ]
  },
  "id_str" : "439570631861215232",
  "in_reply_to_user_id" : 56530362,
  "text" : "@Bediko ich find das 0.4 Verh\u00E4ltnis etwas besser als das 0.3 und wesentlich besser als 0.5. Aber ich denke da wird es Geschmacksfrage :)",
  "id" : 439570631861215232,
  "in_reply_to_status_id" : 439570345075306496,
  "created_at" : "2014-03-01 01:19:40 +0000",
  "in_reply_to_screen_name" : "Bediko",
  "in_reply_to_user_id_str" : "56530362",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fressesprecher",
      "screen_name" : "Bediko",
      "indices" : [ 0, 7 ],
      "id_str" : "56530362",
      "id" : 56530362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "439569775014858752",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097024936, 8.283131655 ]
  },
  "id_str" : "439570001608318976",
  "in_reply_to_user_id" : 56530362,
  "text" : "@Bediko \u00E4h, passender 5 nat\u00FCrlich. :D",
  "id" : 439570001608318976,
  "in_reply_to_status_id" : 439569775014858752,
  "created_at" : "2014-03-01 01:17:09 +0000",
  "in_reply_to_screen_name" : "Bediko",
  "in_reply_to_user_id_str" : "56530362",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fressesprecher",
      "screen_name" : "Bediko",
      "indices" : [ 0, 7 ],
      "id_str" : "56530362",
      "id" : 56530362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "439569775014858752",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097385096, 8.2828958798 ]
  },
  "id_str" : "439569925083254784",
  "in_reply_to_user_id" : 56530362,
  "text" : "@Bediko stimmt, dann vielleicht doch 5\/12 nur diesmal mit passender 12. ;)",
  "id" : 439569925083254784,
  "in_reply_to_status_id" : 439569775014858752,
  "created_at" : "2014-03-01 01:16:51 +0000",
  "in_reply_to_screen_name" : "Bediko",
  "in_reply_to_user_id_str" : "56530362",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fressesprecher",
      "screen_name" : "Bediko",
      "indices" : [ 0, 7 ],
      "id_str" : "56530362",
      "id" : 56530362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "439569488120643584",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097385096, 8.2828958798 ]
  },
  "id_str" : "439569551794388993",
  "in_reply_to_user_id" : 56530362,
  "text" : "@Bediko ok, so lang kann ich wach bleiben :D",
  "id" : 439569551794388993,
  "in_reply_to_status_id" : 439569488120643584,
  "created_at" : "2014-03-01 01:15:22 +0000",
  "in_reply_to_screen_name" : "Bediko",
  "in_reply_to_user_id_str" : "56530362",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fressesprecher",
      "screen_name" : "Bediko",
      "indices" : [ 0, 7 ],
      "id_str" : "56530362",
      "id" : 56530362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "439568886087036928",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097385096, 8.2828958798 ]
  },
  "id_str" : "439569401466343424",
  "in_reply_to_user_id" : 56530362,
  "text" : "@Bediko stimmt :) Jetzt w\u00E4re ich prinzipiell noch auf 5\/10 gespannt wenn das nicht viel Arbeit macht (will aber selbst erstmal ins Bett. ;))",
  "id" : 439569401466343424,
  "in_reply_to_status_id" : 439568886087036928,
  "created_at" : "2014-03-01 01:14:46 +0000",
  "in_reply_to_screen_name" : "Bediko",
  "in_reply_to_user_id_str" : "56530362",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fressesprecher",
      "screen_name" : "Bediko",
      "indices" : [ 0, 7 ],
      "id_str" : "56530362",
      "id" : 56530362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "439567772297994240",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096393495, 8.2829322116 ]
  },
  "id_str" : "439568713009086464",
  "in_reply_to_user_id" : 56530362,
  "text" : "@Bediko cool, danke. Ist in meinen Augen besser. :)",
  "id" : 439568713009086464,
  "in_reply_to_status_id" : 439567772297994240,
  "created_at" : "2014-03-01 01:12:02 +0000",
  "in_reply_to_screen_name" : "Bediko",
  "in_reply_to_user_id_str" : "56530362",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rike MW",
      "screen_name" : "rike_mw",
      "indices" : [ 0, 8 ],
      "id_str" : "79192038",
      "id" : 79192038
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "439565257271304193",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009672854, 8.28306135 ]
  },
  "id_str" : "439565590303612928",
  "in_reply_to_user_id" : 79192038,
  "text" : "@rike_mw ah, sorry for being unclear in my description. So yes, you need to normalize the distance measure, not the kinetic energy itself :)",
  "id" : 439565590303612928,
  "in_reply_to_status_id" : 439565257271304193,
  "created_at" : "2014-03-01 00:59:38 +0000",
  "in_reply_to_screen_name" : "rike_mw",
  "in_reply_to_user_id_str" : "79192038",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rike MW",
      "screen_name" : "rike_mw",
      "indices" : [ 0, 8 ],
      "id_str" : "79192038",
      "id" : 79192038
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "439564218711683073",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009672854, 8.28306135 ]
  },
  "id_str" : "439564912030138368",
  "in_reply_to_user_id" : 79192038,
  "text" : "@rike_mw yeah, but the distance you measured will be off by a large factor as the tracker thinks it tracked step length over wristflick len.",
  "id" : 439564912030138368,
  "in_reply_to_status_id" : 439564218711683073,
  "created_at" : "2014-03-01 00:56:56 +0000",
  "in_reply_to_screen_name" : "rike_mw",
  "in_reply_to_user_id_str" : "79192038",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fressesprecher",
      "screen_name" : "Bediko",
      "indices" : [ 0, 7 ],
      "id_str" : "56530362",
      "id" : 56530362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "439564266887475200",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009672854, 8.28306135 ]
  },
  "id_str" : "439564405442093057",
  "in_reply_to_user_id" : 56530362,
  "text" : "@Bediko Genau. :)",
  "id" : 439564405442093057,
  "in_reply_to_status_id" : 439564266887475200,
  "created_at" : "2014-03-01 00:54:55 +0000",
  "in_reply_to_screen_name" : "Bediko",
  "in_reply_to_user_id_str" : "56530362",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fressesprecher",
      "screen_name" : "Bediko",
      "indices" : [ 0, 7 ],
      "id_str" : "56530362",
      "id" : 56530362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "439563354382684160",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009672854, 8.28306135 ]
  },
  "id_str" : "439564041653342208",
  "in_reply_to_user_id" : 56530362,
  "text" : "@Bediko ah, ich glaube wir haben aneinander vorbei geredet weil du jetzt f\u00FCr mein Verst\u00E4ndnis L\u00E4nge\/Durchmesser angibst. :)",
  "id" : 439564041653342208,
  "in_reply_to_status_id" : 439563354382684160,
  "created_at" : "2014-03-01 00:53:28 +0000",
  "in_reply_to_screen_name" : "Bediko",
  "in_reply_to_user_id_str" : "56530362",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rike MW",
      "screen_name" : "rike_mw",
      "indices" : [ 0, 8 ],
      "id_str" : "79192038",
      "id" : 79192038
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "439563472704004096",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009672854, 8.28306135 ]
  },
  "id_str" : "439563803517517824",
  "in_reply_to_user_id" : 79192038,
  "text" : "@rike_mw but for that you would need the conversion factor as it\u2019s meant to measure steps and will give ~1m distance per \u201Cstep\u201D",
  "id" : 439563803517517824,
  "in_reply_to_status_id" : 439563472704004096,
  "created_at" : "2014-03-01 00:52:32 +0000",
  "in_reply_to_screen_name" : "rike_mw",
  "in_reply_to_user_id_str" : "79192038",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rike MW",
      "screen_name" : "rike_mw",
      "indices" : [ 0, 8 ],
      "id_str" : "79192038",
      "id" : 79192038
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "439561294237405184",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096629938, 8.2830766093 ]
  },
  "id_str" : "439562432412143616",
  "in_reply_to_user_id" : 79192038,
  "text" : "@rike_mw isn\u2019t that just a stereotype?",
  "id" : 439562432412143616,
  "in_reply_to_status_id" : 439561294237405184,
  "created_at" : "2014-03-01 00:47:05 +0000",
  "in_reply_to_screen_name" : "rike_mw",
  "in_reply_to_user_id_str" : "79192038",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fressesprecher",
      "screen_name" : "Bediko",
      "indices" : [ 0, 7 ],
      "id_str" : "56530362",
      "id" : 56530362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "439560984378609664",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009672854, 8.28306135 ]
  },
  "id_str" : "439561630696103936",
  "in_reply_to_user_id" : 56530362,
  "text" : "@Bediko und jetzt wieder die Durchmesser\/L\u00E4nge-Ratio hochdrehen bitte ;)",
  "id" : 439561630696103936,
  "in_reply_to_status_id" : 439560984378609664,
  "created_at" : "2014-03-01 00:43:54 +0000",
  "in_reply_to_screen_name" : "Bediko",
  "in_reply_to_user_id_str" : "56530362",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rike MW",
      "screen_name" : "rike_mw",
      "indices" : [ 0, 8 ],
      "id_str" : "79192038",
      "id" : 79192038
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "439560114258051072",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096812934, 8.2830863258 ]
  },
  "id_str" : "439560807639433216",
  "in_reply_to_user_id" : 79192038,
  "text" : "@rike_mw yes, combining 3 fun topics\/disciplines in one of the best interdisciplinary works. ;)",
  "id" : 439560807639433216,
  "in_reply_to_status_id" : 439560114258051072,
  "created_at" : "2014-03-01 00:40:37 +0000",
  "in_reply_to_screen_name" : "rike_mw",
  "in_reply_to_user_id_str" : "79192038",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rike MW",
      "screen_name" : "rike_mw",
      "indices" : [ 0, 8 ],
      "id_str" : "79192038",
      "id" : 79192038
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/0e7SlqBEO0",
      "expanded_url" : "https:\/\/twitter.com\/eramirez\/status\/439550645603811329",
      "display_url" : "twitter.com\/eramirez\/statu\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "439559507338067968",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009672854, 8.28306135 ]
  },
  "id_str" : "439559755099820032",
  "in_reply_to_user_id" : 79192038,
  "text" : "@rike_mw just skimmed the comments, but doesn\u2019t look like it so far. But it\u2019s even open science\/data, see https:\/\/t.co\/0e7SlqBEO0",
  "id" : 439559755099820032,
  "in_reply_to_status_id" : 439559507338067968,
  "created_at" : "2014-03-01 00:36:26 +0000",
  "in_reply_to_screen_name" : "rike_mw",
  "in_reply_to_user_id_str" : "79192038",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "439557933555146753",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009672854, 8.28306135 ]
  },
  "id_str" : "439559096938004480",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez for \u2018distance\u2019: own anecdotal evidence say can be quite interesting, but never bothered w\/ systematic data collection so far.",
  "id" : 439559096938004480,
  "in_reply_to_status_id" : 439557933555146753,
  "created_at" : "2014-03-01 00:33:49 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "439557933555146753",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096764475, 8.28312598 ]
  },
  "id_str" : "439558942017212416",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez even more thanks for taking the risk :)",
  "id" : 439558942017212416,
  "in_reply_to_status_id" : 439557933555146753,
  "created_at" : "2014-03-01 00:33:13 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096764475, 8.28312598 ]
  },
  "id_str" : "439558482325692416",
  "text" : "Welcome 21st century: some parts of my timeline are discussing quantified masturbation sessions &amp; others are talking 3D printing butt plugs.",
  "id" : 439558482325692416,
  "created_at" : "2014-03-01 00:31:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "439557344976850945",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096764475, 8.28312598 ]
  },
  "id_str" : "439557798016606208",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez oh thanks! (as evolutionary-biologist-turned-\u2018data scientist\u2019 I feel that link is totally safe for work ;))",
  "id" : 439557798016606208,
  "in_reply_to_status_id" : 439557344976850945,
  "created_at" : "2014-03-01 00:28:40 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "439555914467528705",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009625958, 8.28297026 ]
  },
  "id_str" : "439556458058088448",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez just thinking: with \u201Cdistance\u201D + time you could probably could some cool frequency over single session graphs as well.",
  "id" : 439556458058088448,
  "in_reply_to_status_id" : 439555914467528705,
  "created_at" : "2014-03-01 00:23:20 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "439550645603811329",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009625958, 8.28297026 ]
  },
  "id_str" : "439555633369841664",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez I kinda wish he would have used a wrist-worn activity tracker to measure distance as well!",
  "id" : 439555633369841664,
  "in_reply_to_status_id" : 439550645603811329,
  "created_at" : "2014-03-01 00:20:04 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 3, 12 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "quantifiedself",
      "indices" : [ 122, 137 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/GOIdllaFrS",
      "expanded_url" : "http:\/\/www.reddit.com\/r\/dataisbeautiful\/comments\/1yuyyc\/i_recorded_data_about_my_masturbation_sessions\/",
      "display_url" : "reddit.com\/r\/dataisbeauti\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "439555510531264512",
  "text" : "RT @eramirez: \u201CI recorded data about my masturbation sessions for one year. Here are the results.\u201D http:\/\/t.co\/GOIdllaFrS #quantifiedself",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "quantifiedself",
        "indices" : [ 108, 123 ]
      } ],
      "urls" : [ {
        "indices" : [ 85, 107 ],
        "url" : "http:\/\/t.co\/GOIdllaFrS",
        "expanded_url" : "http:\/\/www.reddit.com\/r\/dataisbeautiful\/comments\/1yuyyc\/i_recorded_data_about_my_masturbation_sessions\/",
        "display_url" : "reddit.com\/r\/dataisbeauti\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "439550645603811329",
    "text" : "\u201CI recorded data about my masturbation sessions for one year. Here are the results.\u201D http:\/\/t.co\/GOIdllaFrS #quantifiedself",
    "id" : 439550645603811329,
    "created_at" : "2014-03-01 00:00:15 +0000",
    "user" : {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "protected" : false,
      "id_str" : "21135674",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/866822214267666432\/IYzsQHYG_normal.jpg",
      "id" : 21135674,
      "verified" : false
    }
  },
  "id" : 439555510531264512,
  "created_at" : "2014-03-01 00:19:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/j4x5lcaTTb",
      "expanded_url" : "http:\/\/www.plosone.org\/article\/info%3Adoi%2F10.1371%2Fjournal.pone.0085437",
      "display_url" : "plosone.org\/article\/info%3\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009625958, 8.28297026 ]
  },
  "id_str" : "439543420911370240",
  "text" : "Accurate and Robust Prediction of Genetic Relationship from Whole-Genome Sequences http:\/\/t.co\/j4x5lcaTTb",
  "id" : 439543420911370240,
  "created_at" : "2014-02-28 23:31:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009625958, 8.28297026 ]
  },
  "id_str" : "439539024823595008",
  "text" : "Q: Welche Motive w\u00FCrden auf dich beim Twittern zutreffen?\n\u2610Eine Beziehung finden\n\u2611n Beziehungen finden\n\u2611Graphentheorie lernen",
  "id" : 439539024823595008,
  "created_at" : "2014-02-28 23:14:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
} ]