Grailbird.data.tweets_2016_02 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Geoff Manaugh",
      "screen_name" : "bldgblog",
      "indices" : [ 3, 12 ],
      "id_str" : "15714547",
      "id" : 15714547
    }, {
      "name" : "William Gibson",
      "screen_name" : "GreatDismal",
      "indices" : [ 76, 88 ],
      "id_str" : "28049003",
      "id" : 28049003
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/lP9av0Rx0Q",
      "expanded_url" : "http:\/\/www.travelandleisure.com\/articles\/digital-maps-skewed-china",
      "display_url" : "travelandleisure.com\/articles\/digit\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "704413811705516032",
  "text" : "RT @bldgblog: On Borges, \"trap streets,\" algorithmic skewing, and shades of @GreatDismal in China: https:\/\/t.co\/lP9av0Rx0Q https:\/\/t.co\/h17\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "William Gibson",
        "screen_name" : "GreatDismal",
        "indices" : [ 62, 74 ],
        "id_str" : "28049003",
        "id" : 28049003
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/bldgblog\/status\/703346376361517057\/photo\/1",
        "indices" : [ 109, 132 ],
        "url" : "https:\/\/t.co\/h17DTGHtj2",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CcLJyjPW0AAbmNd.jpg",
        "id_str" : "703346362113511424",
        "id" : 703346362113511424,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CcLJyjPW0AAbmNd.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 351,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 914,
          "resize" : "fit",
          "w" : 1773
        }, {
          "h" : 914,
          "resize" : "fit",
          "w" : 1773
        }, {
          "h" : 619,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/h17DTGHtj2"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 85, 108 ],
        "url" : "https:\/\/t.co\/lP9av0Rx0Q",
        "expanded_url" : "http:\/\/www.travelandleisure.com\/articles\/digital-maps-skewed-china",
        "display_url" : "travelandleisure.com\/articles\/digit\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "703346376361517057",
    "text" : "On Borges, \"trap streets,\" algorithmic skewing, and shades of @GreatDismal in China: https:\/\/t.co\/lP9av0Rx0Q https:\/\/t.co\/h17DTGHtj2",
    "id" : 703346376361517057,
    "created_at" : "2016-02-26 22:30:18 +0000",
    "user" : {
      "name" : "Geoff Manaugh",
      "screen_name" : "bldgblog",
      "protected" : false,
      "id_str" : "15714547",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/916516599393280000\/A7U7JYYw_normal.jpg",
      "id" : 15714547,
      "verified" : true
    }
  },
  "id" : 704413811705516032,
  "created_at" : "2016-02-29 21:11:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/i7RmBzsfCw",
      "expanded_url" : "http:\/\/quantifiedself.com\/2016\/02\/ilyse-magy-know-thy-cycle-know-thyself\/",
      "display_url" : "quantifiedself.com\/2016\/02\/ilyse-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "704395745860968448",
  "text" : "\u00ABCervical fluid. The stuff they taught you to call discharge, as if your vagina is expelling goo for no good reason\u00BB https:\/\/t.co\/i7RmBzsfCw",
  "id" : 704395745860968448,
  "created_at" : "2016-02-29 20:00:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "phryk",
      "screen_name" : "lephryk",
      "indices" : [ 0, 8 ],
      "id_str" : "211820423",
      "id" : 211820423
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "704384570444095488",
  "geo" : { },
  "id_str" : "704384631282475012",
  "in_reply_to_user_id" : 211820423,
  "text" : "@lephryk dieser, im n\u00E4chsten Jahr ;)",
  "id" : 704384631282475012,
  "in_reply_to_status_id" : 704384570444095488,
  "created_at" : "2016-02-29 19:15:57 +0000",
  "in_reply_to_screen_name" : "lephryk",
  "in_reply_to_user_id_str" : "211820423",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/704368727916224513\/photo\/1",
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/6BNb6Gu7xu",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CcZroELWoAAn3zt.jpg",
      "id_str" : "704368727790362624",
      "id" : 704368727790362624,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CcZroELWoAAn3zt.jpg",
      "sizes" : [ {
        "h" : 680,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/6BNb6Gu7xu"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "704368727916224513",
  "text" : "I reached my daily Move goal every day this month. With this being the second easiest month to achieve that. \uD83D\uDE02 https:\/\/t.co\/6BNb6Gu7xu",
  "id" : 704368727916224513,
  "created_at" : "2016-02-29 18:12:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Titus Brown",
      "screen_name" : "ctitusbrown",
      "indices" : [ 0, 12 ],
      "id_str" : "26616462",
      "id" : 26616462
    }, {
      "name" : "Matt MacManes",
      "screen_name" : "macmanes",
      "indices" : [ 13, 22 ],
      "id_str" : "11824072",
      "id" : 11824072
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "704298661275000833",
  "geo" : { },
  "id_str" : "704303182059540480",
  "in_reply_to_user_id" : 26616462,
  "text" : "@ctitusbrown @macmanes it\u2019s so easy, the higher the number the less you trust.",
  "id" : 704303182059540480,
  "in_reply_to_status_id" : 704298661275000833,
  "created_at" : "2016-02-29 13:52:18 +0000",
  "in_reply_to_screen_name" : "ctitusbrown",
  "in_reply_to_user_id_str" : "26616462",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeroen Bosman",
      "screen_name" : "jeroenbosman",
      "indices" : [ 0, 13 ],
      "id_str" : "9104202",
      "id" : 9104202
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "704295958977355777",
  "geo" : { },
  "id_str" : "704298010763776001",
  "in_reply_to_user_id" : 9104202,
  "text" : "@jeroenbosman I guess in Portland at latest?",
  "id" : 704298010763776001,
  "in_reply_to_status_id" : 704295958977355777,
  "created_at" : "2016-02-29 13:31:45 +0000",
  "in_reply_to_screen_name" : "jeroenbosman",
  "in_reply_to_user_id_str" : "9104202",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nazeefa",
      "screen_name" : "NazeefaFatima",
      "indices" : [ 3, 17 ],
      "id_str" : "37054704",
      "id" : 37054704
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "704271488677978113",
  "text" : "RT @NazeefaFatima: Yay \uD83D\uDC30 | Peter Rabbit to become first children's character to appear on a UK coin, in honour of Beatrix Potter https:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 110, 133 ],
        "url" : "https:\/\/t.co\/27MA8CPFzP",
        "expanded_url" : "http:\/\/www.itv.com\/news\/2016-02-29\/peter-rabbit-to-become-first-childrens-character-to-appear-on-a-uk-coin-in-honour-of-beatrix-potter\/",
        "display_url" : "itv.com\/news\/2016-02-2\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "704262672775311360",
    "text" : "Yay \uD83D\uDC30 | Peter Rabbit to become first children's character to appear on a UK coin, in honour of Beatrix Potter https:\/\/t.co\/27MA8CPFzP",
    "id" : 704262672775311360,
    "created_at" : "2016-02-29 11:11:20 +0000",
    "user" : {
      "name" : "Nazeefa",
      "screen_name" : "NazeefaFatima",
      "protected" : false,
      "id_str" : "37054704",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/930210077885202432\/DY8D8hGM_normal.jpg",
      "id" : 37054704,
      "verified" : false
    }
  },
  "id" : 704271488677978113,
  "created_at" : "2016-02-29 11:46:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "latergram",
      "indices" : [ 11, 21 ]
    } ],
    "urls" : [ {
      "indices" : [ 22, 45 ],
      "url" : "https:\/\/t.co\/IoZfDWgUYk",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BCXfIaDBwmC\/",
      "display_url" : "instagram.com\/p\/BCXfIaDBwmC\/"
    } ]
  },
  "geo" : { },
  "id_str" : "704253180520108033",
  "text" : "Al Mudayna #latergram https:\/\/t.co\/IoZfDWgUYk",
  "id" : 704253180520108033,
  "created_at" : "2016-02-29 10:33:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charlotte Soneson",
      "screen_name" : "CSoneson",
      "indices" : [ 0, 9 ],
      "id_str" : "757327572",
      "id" : 757327572
    }, {
      "name" : "Mick Watson",
      "screen_name" : "BioMickWatson",
      "indices" : [ 10, 24 ],
      "id_str" : "228586748",
      "id" : 228586748
    }, {
      "name" : "Ewan Birney",
      "screen_name" : "ewanbirney",
      "indices" : [ 25, 36 ],
      "id_str" : "183548902",
      "id" : 183548902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "704240299229487104",
  "geo" : { },
  "id_str" : "704246296585048064",
  "in_reply_to_user_id" : 757327572,
  "text" : "@CSoneson @BioMickWatson @ewanbirney good call! same here w\/ ggplot2_1.0.1.",
  "id" : 704246296585048064,
  "in_reply_to_status_id" : 704240299229487104,
  "created_at" : "2016-02-29 10:06:16 +0000",
  "in_reply_to_screen_name" : "CSoneson",
  "in_reply_to_user_id_str" : "757327572",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mick Watson",
      "screen_name" : "BioMickWatson",
      "indices" : [ 0, 14 ],
      "id_str" : "228586748",
      "id" : 228586748
    }, {
      "name" : "Ewan Birney",
      "screen_name" : "ewanbirney",
      "indices" : [ 15, 26 ],
      "id_str" : "183548902",
      "id" : 183548902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "704234134894473216",
  "geo" : { },
  "id_str" : "704236717981757440",
  "in_reply_to_user_id" : 228586748,
  "text" : "@BioMickWatson @ewanbirney I see your problem. You could replace geom_abline w\/ geom_segment(aes(x = 0, y = -1, xend = 25000, yend = 2)) ?",
  "id" : 704236717981757440,
  "in_reply_to_status_id" : 704234134894473216,
  "created_at" : "2016-02-29 09:28:12 +0000",
  "in_reply_to_screen_name" : "BioMickWatson",
  "in_reply_to_user_id_str" : "228586748",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mick Watson",
      "screen_name" : "BioMickWatson",
      "indices" : [ 0, 14 ],
      "id_str" : "228586748",
      "id" : 228586748
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "704231327814569984",
  "geo" : { },
  "id_str" : "704232304743464960",
  "in_reply_to_user_id" : 228586748,
  "text" : "@BioMickWatson as.numeric()?",
  "id" : 704232304743464960,
  "in_reply_to_status_id" : 704231327814569984,
  "created_at" : "2016-02-29 09:10:40 +0000",
  "in_reply_to_screen_name" : "BioMickWatson",
  "in_reply_to_user_id_str" : "228586748",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "latergram",
      "indices" : [ 7, 17 ]
    } ],
    "urls" : [ {
      "indices" : [ 18, 41 ],
      "url" : "https:\/\/t.co\/qSNSRS659e",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BCXVM_9hwpe\/",
      "display_url" : "instagram.com\/p\/BCXVM_9hwpe\/"
    } ]
  },
  "geo" : { },
  "id_str" : "704231347641044992",
  "text" : "Rowing #latergram https:\/\/t.co\/qSNSRS659e",
  "id" : 704231347641044992,
  "created_at" : "2016-02-29 09:06:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Schawinski",
      "screen_name" : "kevinschawinski",
      "indices" : [ 0, 16 ],
      "id_str" : "242844365",
      "id" : 242844365
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "704227855123795968",
  "geo" : { },
  "id_str" : "704228006873718784",
  "in_reply_to_user_id" : 242844365,
  "text" : "@kevinschawinski great, i can do that!",
  "id" : 704228006873718784,
  "in_reply_to_status_id" : 704227855123795968,
  "created_at" : "2016-02-29 08:53:35 +0000",
  "in_reply_to_screen_name" : "kevinschawinski",
  "in_reply_to_user_id_str" : "242844365",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Schawinski",
      "screen_name" : "kevinschawinski",
      "indices" : [ 0, 16 ],
      "id_str" : "242844365",
      "id" : 242844365
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "704221621771497472",
  "geo" : { },
  "id_str" : "704226682065055744",
  "in_reply_to_user_id" : 242844365,
  "text" : "@kevinschawinski triple blind is reviewing a paper you haven\u2019t read, right?",
  "id" : 704226682065055744,
  "in_reply_to_status_id" : 704221621771497472,
  "created_at" : "2016-02-29 08:48:19 +0000",
  "in_reply_to_screen_name" : "kevinschawinski",
  "in_reply_to_user_id_str" : "242844365",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 89 ],
      "url" : "https:\/\/t.co\/86hGrdC1Ru",
      "expanded_url" : "http:\/\/journals.plos.org\/plosone\/article?id=10.1371\/journal.pone.0149794",
      "display_url" : "journals.plos.org\/plosone\/articl\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "704222687623827456",
  "text" : "A Bayesian Perspective on the Reproducibility Project: Psychology https:\/\/t.co\/86hGrdC1Ru",
  "id" : 704222687623827456,
  "created_at" : "2016-02-29 08:32:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 5, 28 ],
      "url" : "https:\/\/t.co\/lT4OPSaeUc",
      "expanded_url" : "http:\/\/whatshouldwecallgradschool.tumblr.com\/post\/140028847279\/when-i-can-no-longer-relate-to-the-incoming-class",
      "display_url" : "whatshouldwecallgradschool.tumblr.com\/post\/140028847\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "704219090118971392",
  "text" : "yep. https:\/\/t.co\/lT4OPSaeUc",
  "id" : 704219090118971392,
  "created_at" : "2016-02-29 08:18:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/704203101717315584\/photo\/1",
      "indices" : [ 35, 58 ],
      "url" : "https:\/\/t.co\/yV0nCz19cc",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CcXU_R3W8AAA-mc.jpg",
      "id_str" : "704203100345790464",
      "id" : 704203100345790464,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CcXU_R3W8AAA-mc.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 272
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 272
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 272
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 272
      } ],
      "display_url" : "pic.twitter.com\/yV0nCz19cc"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "704115610066620417",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11397615430371, 8.753454024642341 ]
  },
  "id_str" : "704203101717315584",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez I\u2019m catching up on it ;) https:\/\/t.co\/yV0nCz19cc",
  "id" : 704203101717315584,
  "in_reply_to_status_id" : 704115610066620417,
  "created_at" : "2016-02-29 07:14:37 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "704078218010165250",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11402393393917, 8.753437311568389 ]
  },
  "id_str" : "704078745133588481",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC same here ;)",
  "id" : 704078745133588481,
  "in_reply_to_status_id" : 704078218010165250,
  "created_at" : "2016-02-28 23:00:28 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "704076007205158912",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1140146485353, 8.753417018340695 ]
  },
  "id_str" : "704076814868746241",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC siblings in arms? :p",
  "id" : 704076814868746241,
  "in_reply_to_status_id" : 704076007205158912,
  "created_at" : "2016-02-28 22:52:48 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mara Averick",
      "screen_name" : "dataandme",
      "indices" : [ 0, 10 ],
      "id_str" : "3230388598",
      "id" : 3230388598
    }, {
      "name" : "NausicaaDistribution",
      "screen_name" : "NausicaaDist",
      "indices" : [ 11, 24 ],
      "id_str" : "41887810",
      "id" : 41887810
    }, {
      "name" : "Steph\u24D0nie Wright",
      "screen_name" : "shefw",
      "indices" : [ 25, 31 ],
      "id_str" : "48636190",
      "id" : 48636190
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "704029828157202432",
  "geo" : { },
  "id_str" : "704070847271673856",
  "in_reply_to_user_id" : 3230388598,
  "text" : "@dataandme @NausicaaDist @shefw the first two are in my office!",
  "id" : 704070847271673856,
  "in_reply_to_status_id" : 704029828157202432,
  "created_at" : "2016-02-28 22:29:05 +0000",
  "in_reply_to_screen_name" : "dataandme",
  "in_reply_to_user_id_str" : "3230388598",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/704070176011067394\/photo\/1",
      "indices" : [ 62, 85 ],
      "url" : "https:\/\/t.co\/XwnWPhDkBQ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CcVcGDnWwAUmPX-.jpg",
      "id_str" : "704070175872696325",
      "id" : 704070175872696325,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CcVcGDnWwAUmPX-.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 272
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 272
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 272
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 272
      } ],
      "display_url" : "pic.twitter.com\/XwnWPhDkBQ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "704070176011067394",
  "text" : "The worst part: that's representative for the last four days. https:\/\/t.co\/XwnWPhDkBQ",
  "id" : 704070176011067394,
  "created_at" : "2016-02-28 22:26:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CERN",
      "screen_name" : "CERN",
      "indices" : [ 14, 19 ],
      "id_str" : "15234407",
      "id" : 15234407
    }, {
      "name" : "Achintya Rao \u2022 \u0C85\u0C9A\u0CBF\u0C82\u0CA4\u0CCD\u0CAF \u0CB0\u0CBE\u0CB5",
      "screen_name" : "RaoOfPhysics",
      "indices" : [ 20, 33 ],
      "id_str" : "67529128",
      "id" : 67529128
    }, {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 34, 48 ],
      "id_str" : "352650591",
      "id" : 352650591
    }, {
      "name" : "Mozilla Science Lab",
      "screen_name" : "MozillaScience",
      "indices" : [ 49, 64 ],
      "id_str" : "1428575976",
      "id" : 1428575976
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "704035404673126400",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.03806239070058, 8.525052588003433 ]
  },
  "id_str" : "704055940945997824",
  "in_reply_to_user_id" : 2396006202,
  "text" : "@petergrabitz @CERN @RaoOfPhysics @Protohedgehog @MozillaScience good to see you guys having fun!",
  "id" : 704055940945997824,
  "in_reply_to_status_id" : 704035404673126400,
  "created_at" : "2016-02-28 21:29:51 +0000",
  "in_reply_to_screen_name" : "PeterRolandG",
  "in_reply_to_user_id_str" : "2396006202",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : ".",
      "screen_name" : "punkish",
      "indices" : [ 0, 8 ],
      "id_str" : "15322269",
      "id" : 15322269
    }, {
      "name" : "Velterop \u24D0 \uD83C\uDDEA\uD83C\uDDFA\uD83D\uDD36",
      "screen_name" : "Villavelius",
      "indices" : [ 9, 21 ],
      "id_str" : "72249574",
      "id" : 72249574
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "704022641632366593",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.03930951971678, 8.461240058911143 ]
  },
  "id_str" : "704055733650898945",
  "in_reply_to_user_id" : 15322269,
  "text" : "@punkish @Villavelius totally :)",
  "id" : 704055733650898945,
  "in_reply_to_status_id" : 704022641632366593,
  "created_at" : "2016-02-28 21:29:02 +0000",
  "in_reply_to_screen_name" : "punkish",
  "in_reply_to_user_id_str" : "15322269",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 69 ],
      "url" : "https:\/\/t.co\/nb7fZmx9Jh",
      "expanded_url" : "https:\/\/twitter.com\/Villavelius\/status\/704010853079719936",
      "display_url" : "twitter.com\/Villavelius\/st\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.4878021683921, -3.589911628517871 ]
  },
  "id_str" : "704012035693137921",
  "text" : "All solutions are wrong, but some are useful. https:\/\/t.co\/nb7fZmx9Jh",
  "id" : 704012035693137921,
  "created_at" : "2016-02-28 18:35:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "futurecommons",
      "indices" : [ 49, 63 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.4885720562057, -3.590859325518295 ]
  },
  "id_str" : "704009592712331264",
  "text" : "Boarding MAD \u2708\uFE0F FRA. Thanks for the great time @ #futurecommons",
  "id" : 704009592712331264,
  "created_at" : "2016-02-28 18:25:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.49201285935984, -3.591258600357539 ]
  },
  "id_str" : "703993668588277761",
  "text" : "Advertising at Madrid Airport promotes colour highlights for your dogs hair. \uD83D\uDC36\uD83D\uDD8C",
  "id" : 703993668588277761,
  "created_at" : "2016-02-28 17:22:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 8, 14 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 38 ],
      "url" : "https:\/\/t.co\/wgLlc7jMvR",
      "expanded_url" : "http:\/\/2.bp.blogspot.com\/-NAoxA_H_kCM\/Ve5C_8Z_TNI\/AAAAAAAABJY\/DuGBph-d1gA\/s1600\/primarycookies_van_hemessen.jpg",
      "display_url" : "2.bp.blogspot.com\/-NAoxA_H_kCM\/V\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.41440575710471, -3.691876294697618 ]
  },
  "id_str" : "703922894871601152",
  "text" : "One for @Lobot https:\/\/t.co\/wgLlc7jMvR",
  "id" : 703922894871601152,
  "created_at" : "2016-02-28 12:41:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 82 ],
      "url" : "https:\/\/t.co\/00Ut39GXMy",
      "expanded_url" : "http:\/\/www.epdlp.com\/cuadro.php?id=1564",
      "display_url" : "epdlp.com\/cuadro.php?id=\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.412978, -3.691783 ]
  },
  "id_str" : "703911519906603008",
  "text" : "Your fetish is not my fetish but your fetish is okay too.  https:\/\/t.co\/00Ut39GXMy",
  "id" : 703911519906603008,
  "created_at" : "2016-02-28 11:55:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 56 ],
      "url" : "https:\/\/t.co\/ZiIlqYcVs1",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BCUqXgxhwqW\/",
      "display_url" : "instagram.com\/p\/BCUqXgxhwqW\/"
    } ]
  },
  "geo" : { },
  "id_str" : "703855675978285056",
  "text" : "Fighting one windmill at a time. https:\/\/t.co\/ZiIlqYcVs1",
  "id" : 703855675978285056,
  "created_at" : "2016-02-28 08:14:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carl Zimmer",
      "screen_name" : "carlzimmer",
      "indices" : [ 3, 14 ],
      "id_str" : "14085070",
      "id" : 14085070
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 57 ],
      "url" : "https:\/\/t.co\/ykTUJJWlFp",
      "expanded_url" : "http:\/\/nyti.ms\/1pfSSAF",
      "display_url" : "nyti.ms\/1pfSSAF"
    } ]
  },
  "geo" : { },
  "id_str" : "703847371810017280",
  "text" : "RT @carlzimmer: The Killing Field https:\/\/t.co\/ykTUJJWlFp",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 18, 41 ],
        "url" : "https:\/\/t.co\/ykTUJJWlFp",
        "expanded_url" : "http:\/\/nyti.ms\/1pfSSAF",
        "display_url" : "nyti.ms\/1pfSSAF"
      } ]
    },
    "geo" : { },
    "id_str" : "703771028422578176",
    "text" : "The Killing Field https:\/\/t.co\/ykTUJJWlFp",
    "id" : 703771028422578176,
    "created_at" : "2016-02-28 02:37:43 +0000",
    "user" : {
      "name" : "Carl Zimmer",
      "screen_name" : "carlzimmer",
      "protected" : false,
      "id_str" : "14085070",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/916034313069715457\/url2G14j_normal.jpg",
      "id" : 14085070,
      "verified" : true
    }
  },
  "id" : 703847371810017280,
  "created_at" : "2016-02-28 07:41:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/703746380259581952\/photo\/1",
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/uzeqE8RfeP",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CcQ1lzMXEAAlfxU.jpg",
      "id_str" : "703746365290123264",
      "id" : 703746365290123264,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CcQ1lzMXEAAlfxU.jpg",
      "sizes" : [ {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1801,
        "resize" : "fit",
        "w" : 1350
      }, {
        "h" : 1801,
        "resize" : "fit",
        "w" : 1350
      } ],
      "display_url" : "pic.twitter.com\/uzeqE8RfeP"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "703746380259581952",
  "text" : "So i guess my neighborhood back home won\u2019t get gentrified that easily. https:\/\/t.co\/uzeqE8RfeP",
  "id" : 703746380259581952,
  "created_at" : "2016-02-28 00:59:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Suhrob Niyozov",
      "screen_name" : "sniyazov",
      "indices" : [ 0, 9 ],
      "id_str" : "96902749",
      "id" : 96902749
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "703689843470147584",
  "geo" : { },
  "id_str" : "703725030862098432",
  "in_reply_to_user_id" : 96902749,
  "text" : "@sniyazov btw. could you send me the link to the comedy club thing? :)",
  "id" : 703725030862098432,
  "in_reply_to_status_id" : 703689843470147584,
  "created_at" : "2016-02-27 23:34:56 +0000",
  "in_reply_to_screen_name" : "sniyazov",
  "in_reply_to_user_id_str" : "96902749",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Oleg Lavrovsky",
      "screen_name" : "loleg",
      "indices" : [ 0, 6 ],
      "id_str" : "5429882",
      "id" : 5429882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "703707283612631040",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.42137975988408, -3.708428243568739 ]
  },
  "id_str" : "703722361598681089",
  "in_reply_to_user_id" : 5429882,
  "text" : "@loleg oh, thanks. :)",
  "id" : 703722361598681089,
  "in_reply_to_status_id" : 703707283612631040,
  "created_at" : "2016-02-27 23:24:20 +0000",
  "in_reply_to_screen_name" : "loleg",
  "in_reply_to_user_id_str" : "5429882",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 46 ],
      "url" : "https:\/\/t.co\/gcruka9kjl",
      "expanded_url" : "http:\/\/bayes.camp",
      "display_url" : "bayes.camp"
    } ]
  },
  "geo" : { },
  "id_str" : "703649386161688577",
  "text" : "Impulsively registered https:\/\/t.co\/gcruka9kjl even though I\u2019ve no idea what to do with it.",
  "id" : 703649386161688577,
  "created_at" : "2016-02-27 18:34:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 67 ],
      "url" : "https:\/\/t.co\/q03lcfzoRT",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BCTKDVWBwpr\/",
      "display_url" : "instagram.com\/p\/BCTKDVWBwpr\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.417974, -3.714302 ]
  },
  "id_str" : "703643876087767040",
  "text" : "Tangled up in Blue @ Royal Palace of Madrid https:\/\/t.co\/q03lcfzoRT",
  "id" : 703643876087767040,
  "created_at" : "2016-02-27 18:12:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "futurecommons",
      "indices" : [ 24, 38 ]
    } ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/cGPy7qqiVg",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BCTBOHbBwk9\/",
      "display_url" : "instagram.com\/p\/BCTBOHbBwk9\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.40853, -3.69401 ]
  },
  "id_str" : "703624456472764417",
  "text" : "The elevator shaft that #futurecommons loved so much. @ Museo Reina Sof\u00EDa https:\/\/t.co\/cGPy7qqiVg",
  "id" : 703624456472764417,
  "created_at" : "2016-02-27 16:55:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/703622897332518912\/photo\/1",
      "indices" : [ 48, 71 ],
      "url" : "https:\/\/t.co\/slgyn1fksC",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CcPFTAvWoAA8nL6.jpg",
      "id_str" : "703622897206730752",
      "id" : 703622897206730752,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CcPFTAvWoAA8nL6.jpg",
      "sizes" : [ {
        "h" : 1122,
        "resize" : "fit",
        "w" : 842
      }, {
        "h" : 1122,
        "resize" : "fit",
        "w" : 842
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1122,
        "resize" : "fit",
        "w" : 842
      } ],
      "display_url" : "pic.twitter.com\/slgyn1fksC"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.421376, -3.708457 ]
  },
  "id_str" : "703622897332518912",
  "text" : "If the Goodreads challenges don't work for you. https:\/\/t.co\/slgyn1fksC",
  "id" : 703622897332518912,
  "created_at" : "2016-02-27 16:49:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FutureCommons",
      "indices" : [ 60, 74 ]
    } ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/DURmL1TWu0",
      "expanded_url" : "https:\/\/twitter.com\/iaravps\/status\/703578006267240448",
      "display_url" : "twitter.com\/iaravps\/status\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.42137545764966, -3.707770862433775 ]
  },
  "id_str" : "703578445641596929",
  "text" : "So glad that this is one of the items that got attention at #FutureCommons https:\/\/t.co\/DURmL1TWu0",
  "id" : 703578445641596929,
  "created_at" : "2016-02-27 13:52:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "the Winnower",
      "screen_name" : "theWinnower",
      "indices" : [ 32, 44 ],
      "id_str" : "748018813",
      "id" : 748018813
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/703573591938437120\/photo\/1",
      "indices" : [ 60, 83 ],
      "url" : "https:\/\/t.co\/Erb9JMcbkG",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CcOYcaSW4AAUHFz.jpg",
      "id_str" : "703573580660006912",
      "id" : 703573580660006912,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CcOYcaSW4AAUHFz.jpg",
      "sizes" : [ {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 2448,
        "resize" : "fit",
        "w" : 3264
      } ],
      "display_url" : "pic.twitter.com\/Erb9JMcbkG"
    } ],
    "hashtags" : [ {
      "text" : "FutureCommons",
      "indices" : [ 45, 59 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.42143501444724, -3.707928298906789 ]
  },
  "id_str" : "703573591938437120",
  "text" : "The Windower, co-created by the @theWinnower #FutureCommons https:\/\/t.co\/Erb9JMcbkG",
  "id" : 703573591938437120,
  "created_at" : "2016-02-27 13:33:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FutureCommons",
      "indices" : [ 52, 66 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.42141516542134, -3.707973560109722 ]
  },
  "id_str" : "703532899941875712",
  "text" : "\u00ABFood is better when it\u2019s shared. So is knowledge.\u00BB #FutureCommons",
  "id" : 703532899941875712,
  "created_at" : "2016-02-27 10:51:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Iara VPS",
      "screen_name" : "iaravps",
      "indices" : [ 3, 11 ],
      "id_str" : "173881525",
      "id" : 173881525
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FutureCommons",
      "indices" : [ 27, 41 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "703528478700871680",
  "text" : "RT @iaravps: Just heard at #FutureCommons: there should be continuous questioning of what the commons are. Basically the opposite of Fight \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "FutureCommons",
        "indices" : [ 14, 28 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "703527593623085056",
    "text" : "Just heard at #FutureCommons: there should be continuous questioning of what the commons are. Basically the opposite of Fight Club",
    "id" : 703527593623085056,
    "created_at" : "2016-02-27 10:30:23 +0000",
    "user" : {
      "name" : "Iara VPS",
      "screen_name" : "iaravps",
      "protected" : false,
      "id_str" : "173881525",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/927263024678866944\/jbPg0pRm_normal.jpg",
      "id" : 173881525,
      "verified" : false
    }
  },
  "id" : 703528478700871680,
  "created_at" : "2016-02-27 10:33:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FutureCommons",
      "indices" : [ 68, 82 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.42154962914981, -3.707845817796236 ]
  },
  "id_str" : "703527661721817088",
  "text" : "Doing an impromptu theatrical performance to present our results at #FutureCommons",
  "id" : 703527661721817088,
  "created_at" : "2016-02-27 10:30:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FutureCommons",
      "indices" : [ 111, 125 ]
    } ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/t700XnJQ5L",
      "expanded_url" : "https:\/\/en.wikipedia.org\/wiki\/I_know_it_when_I_see_it",
      "display_url" : "en.wikipedia.org\/wiki\/I_know_it\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "703511300366848000",
  "text" : "Trying to define what the commons are. So far we\u2019re down to \u201EI know it when I see it.\u201C https:\/\/t.co\/t700XnJQ5L #FutureCommons",
  "id" : 703511300366848000,
  "created_at" : "2016-02-27 09:25:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CircusMario",
      "screen_name" : "MarioBecroft",
      "indices" : [ 69, 82 ],
      "id_str" : "1376327474",
      "id" : 1376327474
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/nEGwuJqSGv",
      "expanded_url" : "http:\/\/gedankenstuecke.github.io\/visualizing-code\/",
      "display_url" : "gedankenstuecke.github.io\/visualizing-co\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "703499874034192384",
  "text" : "Added scheme to the list of visualized programming languages. Thanks @MarioBecroft https:\/\/t.co\/nEGwuJqSGv",
  "id" : 703499874034192384,
  "created_at" : "2016-02-27 08:40:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Suhrob Niyozov",
      "screen_name" : "sniyazov",
      "indices" : [ 3, 12 ],
      "id_str" : "96902749",
      "id" : 96902749
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/sniyazov\/status\/703477316798779392\/photo\/1",
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/KCWfogg7vB",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CcNA3oYW8AA_zi4.jpg",
      "id_str" : "703477291276496896",
      "id" : 703477291276496896,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CcNA3oYW8AA_zi4.jpg",
      "sizes" : [ {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 1280
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 1280
      } ],
      "display_url" : "pic.twitter.com\/KCWfogg7vB"
    } ],
    "hashtags" : [ {
      "text" : "FutureCommons",
      "indices" : [ 57, 71 ]
    }, {
      "text" : "FCviz",
      "indices" : [ 72, 78 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "703489982749679616",
  "text" : "RT @sniyazov: The most art object in museum was elevator #FutureCommons #FCviz https:\/\/t.co\/KCWfogg7vB",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/sniyazov\/status\/703477316798779392\/photo\/1",
        "indices" : [ 65, 88 ],
        "url" : "https:\/\/t.co\/KCWfogg7vB",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CcNA3oYW8AA_zi4.jpg",
        "id_str" : "703477291276496896",
        "id" : 703477291276496896,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CcNA3oYW8AA_zi4.jpg",
        "sizes" : [ {
          "h" : 900,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 960,
          "resize" : "fit",
          "w" : 1280
        }, {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 960,
          "resize" : "fit",
          "w" : 1280
        } ],
        "display_url" : "pic.twitter.com\/KCWfogg7vB"
      } ],
      "hashtags" : [ {
        "text" : "FutureCommons",
        "indices" : [ 43, 57 ]
      }, {
        "text" : "FCviz",
        "indices" : [ 58, 64 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "703477316798779392",
    "text" : "The most art object in museum was elevator #FutureCommons #FCviz https:\/\/t.co\/KCWfogg7vB",
    "id" : 703477316798779392,
    "created_at" : "2016-02-27 07:10:36 +0000",
    "user" : {
      "name" : "Suhrob Niyozov",
      "screen_name" : "sniyazov",
      "protected" : false,
      "id_str" : "96902749",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/637192146747916288\/VGaAOSJZ_normal.jpg",
      "id" : 96902749,
      "verified" : false
    }
  },
  "id" : 703489982749679616,
  "created_at" : "2016-02-27 08:00:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    }, {
      "name" : "Christina Farr",
      "screen_name" : "chrissyfarr",
      "indices" : [ 10, 22 ],
      "id_str" : "211583400",
      "id" : 211583400
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "703397249842188288",
  "geo" : { },
  "id_str" : "703397357107486720",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez @chrissyfarr not really easier, but gives you rare conditions w\/o clear SNPs so far!",
  "id" : 703397357107486720,
  "in_reply_to_status_id" : 703397249842188288,
  "created_at" : "2016-02-27 01:52:53 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    }, {
      "name" : "Christina Farr",
      "screen_name" : "chrissyfarr",
      "indices" : [ 10, 22 ],
      "id_str" : "211583400",
      "id" : 211583400
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "703396882144342016",
  "geo" : { },
  "id_str" : "703397059496382464",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez @chrissyfarr yes, for known variants that would work. but asking about \u201Edo you have a rare condition\u201C would be interesting as well",
  "id" : 703397059496382464,
  "in_reply_to_status_id" : 703396882144342016,
  "created_at" : "2016-02-27 01:51:42 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    }, {
      "name" : "Christina Farr",
      "screen_name" : "chrissyfarr",
      "indices" : [ 10, 22 ],
      "id_str" : "211583400",
      "id" : 211583400
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "703344823697166336",
  "geo" : { },
  "id_str" : "703396613155373056",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez @chrissyfarr we should somehow mine this w\/ openSNP, though not sure on how to do it best so far. :)",
  "id" : 703396613155373056,
  "in_reply_to_status_id" : 703344823697166336,
  "created_at" : "2016-02-27 01:49:55 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.40834319147189, -3.693242927206069 ]
  },
  "id_str" : "703306672333258752",
  "text" : "Guernica \uD83D\uDC40 \uD83D\uDE31 Made the most important part of my Madrid visit.",
  "id" : 703306672333258752,
  "created_at" : "2016-02-26 19:52:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/703252605217153024\/photo\/1",
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/uQGoHnJsc7",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CcJ0g91WAAIPLcx.jpg",
      "id_str" : "703252601526157314",
      "id" : 703252601526157314,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CcJ0g91WAAIPLcx.jpg",
      "sizes" : [ {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 2448,
        "resize" : "fit",
        "w" : 3264
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/uQGoHnJsc7"
    } ],
    "hashtags" : [ {
      "text" : "FutureCommons",
      "indices" : [ 65, 79 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.4214570159124, -3.707930531784837 ]
  },
  "id_str" : "703252605217153024",
  "text" : "Open Curation: \u00ABIt\u2019s like Pinterest, but for Scholarly Commons.\u00BB #FutureCommons https:\/\/t.co\/uQGoHnJsc7",
  "id" : 703252605217153024,
  "created_at" : "2016-02-26 16:17:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FutureCommons",
      "indices" : [ 126, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.42137199271756, -3.707888181222208 ]
  },
  "id_str" : "703250367342059521",
  "text" : "Talked about whether for-profit actors can be benevolent to the commons. Wish we would have called it the Commonest Manifesto #FutureCommons",
  "id" : 703250367342059521,
  "created_at" : "2016-02-26 16:08:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/703228466624393216\/photo\/1",
      "indices" : [ 29, 52 ],
      "url" : "https:\/\/t.co\/RPjwQvGndP",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CcJej9EW4AAIkGy.jpg",
      "id_str" : "703228463604490240",
      "id" : 703228463604490240,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CcJej9EW4AAIkGy.jpg",
      "sizes" : [ {
        "h" : 2448,
        "resize" : "fit",
        "w" : 3264
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/RPjwQvGndP"
    } ],
    "hashtags" : [ {
      "text" : "FutureCommons",
      "indices" : [ 14, 28 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.42138804795232, -3.707995538683581 ]
  },
  "id_str" : "703228466624393216",
  "text" : "Candy Crisis! #FutureCommons https:\/\/t.co\/RPjwQvGndP",
  "id" : 703228466624393216,
  "created_at" : "2016-02-26 14:41:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/703221220205060096\/photo\/1",
      "indices" : [ 39, 62 ],
      "url" : "https:\/\/t.co\/pXaStSJEe9",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CcJX97EWIAAT-IR.jpg",
      "id_str" : "703221213162774528",
      "id" : 703221213162774528,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CcJX97EWIAAT-IR.jpg",
      "sizes" : [ {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 3264,
        "resize" : "fit",
        "w" : 2448
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      } ],
      "display_url" : "pic.twitter.com\/pXaStSJEe9"
    } ],
    "hashtags" : [ {
      "text" : "FutureCommons",
      "indices" : [ 24, 38 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.42149411049247, -3.70798334456643 ]
  },
  "id_str" : "703221220205060096",
  "text" : "The Status of Open Data #FutureCommons https:\/\/t.co\/pXaStSJEe9",
  "id" : 703221220205060096,
  "created_at" : "2016-02-26 14:12:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "opencon",
      "indices" : [ 27, 35 ]
    } ],
    "urls" : [ {
      "indices" : [ 44, 67 ],
      "url" : "https:\/\/t.co\/aGDmRupfJV",
      "expanded_url" : "https:\/\/twitter.com\/sniyazov\/status\/703187280039649281",
      "display_url" : "twitter.com\/sniyazov\/statu\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.42163558174222, -3.708112651878706 ]
  },
  "id_str" : "703197151308947456",
  "text" : "Pre-lunch photo op for the #opencon alumni. https:\/\/t.co\/aGDmRupfJV",
  "id" : 703197151308947456,
  "created_at" : "2016-02-26 12:37:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FutureCommons",
      "indices" : [ 91, 105 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.42140897317662, -3.707928808386882 ]
  },
  "id_str" : "703186318348517376",
  "text" : "Discussing whether the commons should be structured like the liquid democracy of Wolfpacks.#FutureCommons",
  "id" : 703186318348517376,
  "created_at" : "2016-02-26 11:54:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/703183685932023810\/photo\/1",
      "indices" : [ 40, 63 ],
      "url" : "https:\/\/t.co\/u2wjITiv79",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CcI1zpYUcAIzf-3.jpg",
      "id_str" : "703183653220675586",
      "id" : 703183653220675586,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CcI1zpYUcAIzf-3.jpg",
      "sizes" : [ {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 3264,
        "resize" : "fit",
        "w" : 2448
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      } ],
      "display_url" : "pic.twitter.com\/u2wjITiv79"
    } ],
    "hashtags" : [ {
      "text" : "FutureCommons",
      "indices" : [ 25, 39 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.42145396866153, -3.707945607761947 ]
  },
  "id_str" : "703183685932023810",
  "text" : "Choose your personality. #FutureCommons https:\/\/t.co\/u2wjITiv79",
  "id" : 703183685932023810,
  "created_at" : "2016-02-26 11:43:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Cock",
      "screen_name" : "pjacock",
      "indices" : [ 0, 8 ],
      "id_str" : "58756672",
      "id" : 58756672
    }, {
      "name" : "Torsten Seemann",
      "screen_name" : "torstenseemann",
      "indices" : [ 9, 24 ],
      "id_str" : "42558652",
      "id" : 42558652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "703176527240757249",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.42145396866153, -3.707945607761947 ]
  },
  "id_str" : "703183348844204032",
  "in_reply_to_user_id" : 58756672,
  "text" : "@pjacock @torstenseemann yes, everyone would benefit.",
  "id" : 703183348844204032,
  "in_reply_to_status_id" : 703176527240757249,
  "created_at" : "2016-02-26 11:42:29 +0000",
  "in_reply_to_screen_name" : "pjacock",
  "in_reply_to_user_id_str" : "58756672",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Cock",
      "screen_name" : "pjacock",
      "indices" : [ 0, 8 ],
      "id_str" : "58756672",
      "id" : 58756672
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "703155075556900865",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.42142021862082, -3.707790895840843 ]
  },
  "id_str" : "703161411954806784",
  "in_reply_to_user_id" : 58756672,
  "text" : "@pjacock yes, doesn\u2019t solve the general problem of funding for $$$ projects, but still would make life easier for many ppl.",
  "id" : 703161411954806784,
  "in_reply_to_status_id" : 703155075556900865,
  "created_at" : "2016-02-26 10:15:19 +0000",
  "in_reply_to_screen_name" : "pjacock",
  "in_reply_to_user_id_str" : "58756672",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/703154206094467074\/photo\/1",
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/O5hytKV1Tb",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CcIbBMnUYAATQJj.jpg",
      "id_str" : "703154199203176448",
      "id" : 703154199203176448,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CcIbBMnUYAATQJj.jpg",
      "sizes" : [ {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 3264,
        "resize" : "fit",
        "w" : 2448
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      } ],
      "display_url" : "pic.twitter.com\/O5hytKV1Tb"
    } ],
    "hashtags" : [ {
      "text" : "FutureCommons",
      "indices" : [ 58, 72 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.42137295392867, -3.707838367099374 ]
  },
  "id_str" : "703154206094467074",
  "text" : "The way to rebuild academia and scholarship? Basic income #FutureCommons https:\/\/t.co\/O5hytKV1Tb",
  "id" : 703154206094467074,
  "created_at" : "2016-02-26 09:46:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.42138861187011, -3.707995942797846 ]
  },
  "id_str" : "703150236693172225",
  "text" : "\u00ABI don\u2019t believe in soap boxes.\u00BB \u2014 \u00ABAnd yet they exist!\u00BB",
  "id" : 703150236693172225,
  "created_at" : "2016-02-26 09:30:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/703149327502344192\/photo\/1",
      "indices" : [ 42, 65 ],
      "url" : "https:\/\/t.co\/dVJsl86y8U",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CcIWkiVUcAUwIq_.jpg",
      "id_str" : "703149308770545669",
      "id" : 703149308770545669,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CcIWkiVUcAUwIq_.jpg",
      "sizes" : [ {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 3264,
        "resize" : "fit",
        "w" : 2448
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      } ],
      "display_url" : "pic.twitter.com\/dVJsl86y8U"
    } ],
    "hashtags" : [ {
      "text" : "FutureCommons",
      "indices" : [ 27, 41 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.42147334585258, -3.708024155663095 ]
  },
  "id_str" : "703149327502344192",
  "text" : "Let\u2019s talk citizen science #FutureCommons https:\/\/t.co\/dVJsl86y8U",
  "id" : 703149327502344192,
  "created_at" : "2016-02-26 09:27:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 38 ],
      "url" : "https:\/\/t.co\/7ruhP8zEvQ",
      "expanded_url" : "https:\/\/twitter.com\/memartone\/status\/703146108604710912",
      "display_url" : "twitter.com\/memartone\/stat\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.42140862281114, -3.707962206411579 ]
  },
  "id_str" : "703148290431275008",
  "text" : "So much fun! \uD83D\uDC83 https:\/\/t.co\/7ruhP8zEvQ",
  "id" : 703148290431275008,
  "created_at" : "2016-02-26 09:23:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "futurecommons",
      "indices" : [ 47, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/uRC7Vql384",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BCPnsS2Bwit\/",
      "display_url" : "instagram.com\/p\/BCPnsS2Bwit\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.4215393, -3.7081757 ]
  },
  "id_str" : "703146106167779328",
  "text" : "Kicking IP\/Copyright when it's already down at #futurecommons @ Hotel Emperador https:\/\/t.co\/uRC7Vql384",
  "id" : 703146106167779328,
  "created_at" : "2016-02-26 09:14:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CircusMario",
      "screen_name" : "MarioBecroft",
      "indices" : [ 0, 13 ],
      "id_str" : "1376327474",
      "id" : 1376327474
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "703129000168681473",
  "geo" : { },
  "id_str" : "703129201700777984",
  "in_reply_to_user_id" : 1376327474,
  "text" : "@MarioBecroft I\u2019d say you can clearly see that scheme is trying to drown you in brackets. But it\u2019s clearly balanced. ;-)",
  "id" : 703129201700777984,
  "in_reply_to_status_id" : 703129000168681473,
  "created_at" : "2016-02-26 08:07:19 +0000",
  "in_reply_to_screen_name" : "MarioBecroft",
  "in_reply_to_user_id_str" : "1376327474",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 87 ],
      "url" : "https:\/\/t.co\/20GBN45FVo",
      "expanded_url" : "https:\/\/twitter.com\/OBF_BOSC\/status\/703047366446690304",
      "display_url" : "twitter.com\/OBF_BOSC\/statu\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.42171382173206, -3.708192024969049 ]
  },
  "id_str" : "703118788879716353",
  "text" : "Read about one of the nicest academic things I\u2019ve ever been to: https:\/\/t.co\/20GBN45FVo",
  "id" : 703118788879716353,
  "created_at" : "2016-02-26 07:25:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CircusMario",
      "screen_name" : "MarioBecroft",
      "indices" : [ 0, 13 ],
      "id_str" : "1376327474",
      "id" : 1376327474
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/703018961265254401\/photo\/1",
      "indices" : [ 29, 52 ],
      "url" : "https:\/\/t.co\/jrpbFOdt9g",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CcGgBHFUUAAyRaS.jpg",
      "id_str" : "703018957788172288",
      "id" : 703018957788172288,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CcGgBHFUUAAyRaS.jpg",
      "sizes" : [ {
        "h" : 680,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1000,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 1000,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 1000,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/jrpbFOdt9g"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "702609627154817024",
  "geo" : { },
  "id_str" : "703018961265254401",
  "in_reply_to_user_id" : 1376327474,
  "text" : "@MarioBecroft here you go :) https:\/\/t.co\/jrpbFOdt9g",
  "id" : 703018961265254401,
  "in_reply_to_status_id" : 702609627154817024,
  "created_at" : "2016-02-26 00:49:16 +0000",
  "in_reply_to_screen_name" : "MarioBecroft",
  "in_reply_to_user_id_str" : "1376327474",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/NZSLjuUmpT",
      "expanded_url" : "http:\/\/www.newyorker.com\/culture\/cultural-comment\/straightened-out-croissants-and-the-decline-of-civilization?mbid=social_twitter",
      "display_url" : "newyorker.com\/culture\/cultur\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "703014753870942210",
  "text" : "the big issues of our time: Straightened-Out Croissants and the Decline of Civilization https:\/\/t.co\/NZSLjuUmpT",
  "id" : 703014753870942210,
  "created_at" : "2016-02-26 00:32:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anarchieprojekte",
      "screen_name" : "la_flora_negra",
      "indices" : [ 0, 15 ],
      "id_str" : "2269700387",
      "id" : 2269700387
    }, {
      "name" : "\u2605 cy\u03F8\u00E9r-\u03BCw\u212E \u2605",
      "screen_name" : "luebbermann",
      "indices" : [ 16, 28 ],
      "id_str" : "38845373",
      "id" : 38845373
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "702963737364471808",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.42149288633398, -3.707921863698169 ]
  },
  "id_str" : "702964599461715968",
  "in_reply_to_user_id" : 2269700387,
  "text" : "@la_flora_negra @luebbermann yep, sagen du kommst nur wenn sie die Geschlechter-Ratio ausgleichen. Im Idealfall jemanden vorschlagen.",
  "id" : 702964599461715968,
  "in_reply_to_status_id" : 702963737364471808,
  "created_at" : "2016-02-25 21:13:15 +0000",
  "in_reply_to_screen_name" : "la_flora_negra",
  "in_reply_to_user_id_str" : "2269700387",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FutureCommons",
      "indices" : [ 4, 18 ]
    } ],
    "urls" : [ {
      "indices" : [ 46, 69 ],
      "url" : "https:\/\/t.co\/mnNARnpqJl",
      "expanded_url" : "https:\/\/twitter.com\/marcinignac\/status\/702795297848741889",
      "display_url" : "twitter.com\/marcinignac\/st\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.4214870771373, -3.708404370071845 ]
  },
  "id_str" : "702958598167642112",
  "text" : "The #FutureCommons are doing diversity right. https:\/\/t.co\/mnNARnpqJl",
  "id" : 702958598167642112,
  "created_at" : "2016-02-25 20:49:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Eisen",
      "screen_name" : "mbeisen",
      "indices" : [ 74, 82 ],
      "id_str" : "19843630",
      "id" : 19843630
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FutureCommons",
      "indices" : [ 30, 44 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.4217905288461, -3.70822829144457 ]
  },
  "id_str" : "702947192986857473",
  "text" : "Not 100% sure, but I feel the #FutureCommons intro video somehow compared @mbeisen to The Hulk. \uD83D\uDE02",
  "id" : 702947192986857473,
  "created_at" : "2016-02-25 20:04:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FutureCommons",
      "indices" : [ 76, 90 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.42162903507987, -3.708111743793804 ]
  },
  "id_str" : "702929623005466624",
  "text" : "We are joined by one of the organizers of the 2003 Summit of Micronations \uD83D\uDC96 #FutureCommons",
  "id" : 702929623005466624,
  "created_at" : "2016-02-25 18:54:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hans Mentz, a.D.",
      "screen_name" : "humorkritik",
      "indices" : [ 0, 12 ],
      "id_str" : "2196110178",
      "id" : 2196110178
    }, {
      "name" : "PeerJ - the journal",
      "screen_name" : "thePeerJ",
      "indices" : [ 13, 22 ],
      "id_str" : "402875257",
      "id" : 402875257
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "702910448476286976",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.42151107435411, -3.708043985894445 ]
  },
  "id_str" : "702912948046598144",
  "in_reply_to_user_id" : 2196110178,
  "text" : "@humorkritik @thePeerJ \uD83D\uDC4D",
  "id" : 702912948046598144,
  "in_reply_to_status_id" : 702910448476286976,
  "created_at" : "2016-02-25 17:48:00 +0000",
  "in_reply_to_screen_name" : "humorkritik",
  "in_reply_to_user_id_str" : "2196110178",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/LUJEE3IhFE",
      "expanded_url" : "https:\/\/twitter.com\/thePeerJ\/status\/702908479078404098",
      "display_url" : "twitter.com\/thePeerJ\/statu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "702909392082112512",
  "text" : "Can you guess where the authors are from, just by looking at the screenshot posted here? https:\/\/t.co\/LUJEE3IhFE",
  "id" : 702909392082112512,
  "created_at" : "2016-02-25 17:33:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 0, 9 ],
      "id_str" : "14245811",
      "id" : 14245811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "702901304373473280",
  "geo" : { },
  "id_str" : "702901502462009344",
  "in_reply_to_user_id" : 14245811,
  "text" : "@wilbanks can\u2019t I just swipe my bloody thumb over my iPhone screen? :D",
  "id" : 702901502462009344,
  "in_reply_to_status_id" : 702901304373473280,
  "created_at" : "2016-02-25 17:02:32 +0000",
  "in_reply_to_screen_name" : "wilbanks",
  "in_reply_to_user_id_str" : "14245811",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 0, 9 ],
      "id_str" : "14245811",
      "id" : 14245811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "702878986368524288",
  "geo" : { },
  "id_str" : "702898829666942979",
  "in_reply_to_user_id" : 14245811,
  "text" : "@wilbanks sworn oath and signed contract with blood?",
  "id" : 702898829666942979,
  "in_reply_to_status_id" : 702878986368524288,
  "created_at" : "2016-02-25 16:51:54 +0000",
  "in_reply_to_screen_name" : "wilbanks",
  "in_reply_to_user_id_str" : "14245811",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "702882669890248704",
  "text" : "Who would have guessed that the Parque de la Monta\u00F1a has its name for a good reason? Hardest 5k in a long time. \uD83C\uDFC3\uD83D\uDE30",
  "id" : 702882669890248704,
  "created_at" : "2016-02-25 15:47:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.47720551268466, -3.598933520106921 ]
  },
  "id_str" : "702861111167733760",
  "text" : "Oh hai, Madrid. \uD83D\uDEEC Good thing I brought light running wear and \uD83D\uDD76. \u2600\uFE0F",
  "id" : 702861111167733760,
  "created_at" : "2016-02-25 14:22:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "702804710001086465",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.05024205710868, 8.584443518141084 ]
  },
  "id_str" : "702805361837924352",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot orbital truckers are the people on the ISS?",
  "id" : 702805361837924352,
  "in_reply_to_status_id" : 702804710001086465,
  "created_at" : "2016-02-25 10:40:30 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "702798011236274177",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.05029523314968, 8.5846489445917 ]
  },
  "id_str" : "702804152360026112",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot even though you already told me about this I got it wrong at first, c.f. orbital mechanics, quantum mechanics, \u2026",
  "id" : 702804152360026112,
  "in_reply_to_status_id" : 702798011236274177,
  "created_at" : "2016-02-25 10:35:42 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.05027826145834, 8.58416026929584 ]
  },
  "id_str" : "702801109866438657",
  "text" : "Now: FRA \u2708\uFE0F MAD.",
  "id" : 702801109866438657,
  "created_at" : "2016-02-25 10:23:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 89 ],
      "url" : "https:\/\/t.co\/D0fk825ISY",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=NciG8qAphUM",
      "display_url" : "youtube.com\/watch?v=NciG8q\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "702781351435575296",
  "text" : "poking the iris really seems to be a trope for Frightened Rabbit. https:\/\/t.co\/D0fk825ISY",
  "id" : 702781351435575296,
  "created_at" : "2016-02-25 09:05:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "702772969978912768",
  "text" : "Python-Web: Do you have an idea which is the latest Anaconda version to be supporting Mac OS 10.6.8?",
  "id" : 702772969978912768,
  "created_at" : "2016-02-25 08:31:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 41 ],
      "url" : "https:\/\/t.co\/2m6yraoO0t",
      "expanded_url" : "http:\/\/whatshouldwecallgradschool.tumblr.com\/post\/139910077392\/grad-school-taxes",
      "display_url" : "whatshouldwecallgradschool.tumblr.com\/post\/139910077\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "702765465924456448",
  "text" : "too close to home https:\/\/t.co\/2m6yraoO0t",
  "id" : 702765465924456448,
  "created_at" : "2016-02-25 08:01:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "702613026105483266",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11402233274143, 8.753435266420832 ]
  },
  "id_str" : "702617906190876672",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez once we\u2019re done with our PhDs: Dr Ramirez &amp; Dr Greshake, joining up for \uD83D\uDC27\uD83C\uDFCB.",
  "id" : 702617906190876672,
  "in_reply_to_status_id" : 702613026105483266,
  "created_at" : "2016-02-24 22:15:37 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/nFWynv0d6Y",
      "expanded_url" : "https:\/\/m.youtube.com\/watch?v=ZsT9i99yFeY",
      "display_url" : "m.youtube.com\/watch?v=ZsT9i9\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "702610595250466816",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.10964685669131, 8.756976261607466 ]
  },
  "id_str" : "702612453826433024",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez \u2018did you know that waggling burns thrice the calories of running?!\u2019 https:\/\/t.co\/nFWynv0d6Y",
  "id" : 702612453826433024,
  "in_reply_to_status_id" : 702610595250466816,
  "created_at" : "2016-02-24 21:53:57 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 72 ],
      "url" : "https:\/\/t.co\/nFWynv0d6Y",
      "expanded_url" : "https:\/\/m.youtube.com\/watch?v=ZsT9i99yFeY",
      "display_url" : "m.youtube.com\/watch?v=ZsT9i9\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "702607471853047808",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1096473899329, 8.756973785787073 ]
  },
  "id_str" : "702611811976257536",
  "in_reply_to_user_id" : 14286491,
  "text" : "They even have videos of the \uD83D\uDC27 on the treadmill! https:\/\/t.co\/nFWynv0d6Y",
  "id" : 702611811976257536,
  "in_reply_to_status_id" : 702607471853047808,
  "created_at" : "2016-02-24 21:51:24 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "702610019066388480",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.10964573283665, 8.756979912638178 ]
  },
  "id_str" : "702610227854704640",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez may I be the Chief Penguin Officer?",
  "id" : 702610227854704640,
  "in_reply_to_status_id" : 702610019066388480,
  "created_at" : "2016-02-24 21:45:06 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CircusMario",
      "screen_name" : "MarioBecroft",
      "indices" : [ 0, 13 ],
      "id_str" : "1376327474",
      "id" : 1376327474
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "702609627154817024",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.10964573283665, 8.756979912638178 ]
  },
  "id_str" : "702610118312124416",
  "in_reply_to_user_id" : 1376327474,
  "text" : "@MarioBecroft will give it a try, thanks :)",
  "id" : 702610118312124416,
  "in_reply_to_status_id" : 702609627154817024,
  "created_at" : "2016-02-24 21:44:40 +0000",
  "in_reply_to_screen_name" : "MarioBecroft",
  "in_reply_to_user_id_str" : "1376327474",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Iara VPS",
      "screen_name" : "iaravps",
      "indices" : [ 0, 8 ],
      "id_str" : "173881525",
      "id" : 173881525
    }, {
      "name" : "the Winnower",
      "screen_name" : "theWinnower",
      "indices" : [ 9, 21 ],
      "id_str" : "748018813",
      "id" : 748018813
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "702601885048561664",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.10962139369106, 8.75695060423593 ]
  },
  "id_str" : "702609490504458240",
  "in_reply_to_user_id" : 173881525,
  "text" : "@iaravps @theWinnower oh, looking forward to meet again! :)",
  "id" : 702609490504458240,
  "in_reply_to_status_id" : 702601885048561664,
  "created_at" : "2016-02-24 21:42:11 +0000",
  "in_reply_to_screen_name" : "iaravps",
  "in_reply_to_user_id_str" : "173881525",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 88 ],
      "url" : "https:\/\/t.co\/XQajjGnADc",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/702607471853047808",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "702607471853047808",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.10964746411835, 8.75697436481126 ]
  },
  "id_str" : "702608140857163776",
  "in_reply_to_user_id" : 14286491,
  "text" : "@eramirez you might want to read about the quantified penguin \uD83D\uDC27\uD83D\uDE0A https:\/\/t.co\/XQajjGnADc",
  "id" : 702608140857163776,
  "in_reply_to_status_id" : 702607471853047808,
  "created_at" : "2016-02-24 21:36:49 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/zUH65LQP4E",
      "expanded_url" : "https:\/\/twitter.com\/PLOSONE\/status\/702595874820530177",
      "display_url" : "twitter.com\/PLOSONE\/status\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.10960461556676, 8.756719338138364 ]
  },
  "id_str" : "702607471853047808",
  "text" : "Sometimes I envy the people who do fieldwork for their research topics. https:\/\/t.co\/zUH65LQP4E",
  "id" : 702607471853047808,
  "created_at" : "2016-02-24 21:34:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "maljal",
      "screen_name" : "maljal",
      "indices" : [ 3, 10 ],
      "id_str" : "18524740",
      "id" : 18524740
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "702607020160061445",
  "text" : "RT @maljal: A real librarian!!!!! The first time in history-- and it is a woman! I never thought I would see the day.  https:\/\/t.co\/46YNumY\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 107, 130 ],
        "url" : "https:\/\/t.co\/46YNumYQUM",
        "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/702538842671177728",
        "display_url" : "twitter.com\/WhiteHouse\/sta\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "702564482418139136",
    "text" : "A real librarian!!!!! The first time in history-- and it is a woman! I never thought I would see the day.  https:\/\/t.co\/46YNumYQUM",
    "id" : 702564482418139136,
    "created_at" : "2016-02-24 18:43:20 +0000",
    "user" : {
      "name" : "maljal",
      "screen_name" : "maljal",
      "protected" : false,
      "id_str" : "18524740",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2986715710\/ef8f9ebcb3bc01393dc594b41a7dd147_normal.jpeg",
      "id" : 18524740,
      "verified" : false
    }
  },
  "id" : 702607020160061445,
  "created_at" : "2016-02-24 21:32:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CircusMario",
      "screen_name" : "MarioBecroft",
      "indices" : [ 0, 13 ],
      "id_str" : "1376327474",
      "id" : 1376327474
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "702605038221291520",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.10963538164837, 8.75693218298584 ]
  },
  "id_str" : "702606695621660672",
  "in_reply_to_user_id" : 1376327474,
  "text" : "@MarioBecroft yes, with Python it\u2019s relatively easy to get people to a point that it\u2019s immediately useful to them, thanks to comm\/Libs.",
  "id" : 702606695621660672,
  "in_reply_to_status_id" : 702605038221291520,
  "created_at" : "2016-02-24 21:31:04 +0000",
  "in_reply_to_screen_name" : "MarioBecroft",
  "in_reply_to_user_id_str" : "1376327474",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CircusMario",
      "screen_name" : "MarioBecroft",
      "indices" : [ 0, 13 ],
      "id_str" : "1376327474",
      "id" : 1376327474
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "702599772650123264",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.10965059840036, 8.756978633736948 ]
  },
  "id_str" : "702603732375248896",
  "in_reply_to_user_id" : 1376327474,
  "text" : "@MarioBecroft \u2026target audience here were people who want some data analysis, so keeping it simple (especially for 2 days) seems warranted.",
  "id" : 702603732375248896,
  "in_reply_to_status_id" : 702599772650123264,
  "created_at" : "2016-02-24 21:19:18 +0000",
  "in_reply_to_screen_name" : "MarioBecroft",
  "in_reply_to_user_id_str" : "1376327474",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CircusMario",
      "screen_name" : "MarioBecroft",
      "indices" : [ 0, 13 ],
      "id_str" : "1376327474",
      "id" : 1376327474
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "702599772650123264",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.10964805186492, 8.756977652614335 ]
  },
  "id_str" : "702603483120332800",
  "in_reply_to_user_id" : 1376327474,
  "text" : "@MarioBecroft if you have some code example I should use I\u2019m happy to viz it! For teaching I see your point, but\u2026",
  "id" : 702603483120332800,
  "in_reply_to_status_id" : 702599772650123264,
  "created_at" : "2016-02-24 21:18:18 +0000",
  "in_reply_to_screen_name" : "MarioBecroft",
  "in_reply_to_user_id_str" : "1376327474",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam J Calhoun",
      "screen_name" : "neuroecology",
      "indices" : [ 73, 86 ],
      "id_str" : "636023721",
      "id" : 636023721
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/nEGwuJqSGv",
      "expanded_url" : "http:\/\/gedankenstuecke.github.io\/visualizing-code\/",
      "display_url" : "gedankenstuecke.github.io\/visualizing-co\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.10961596716195, 8.756965623612517 ]
  },
  "id_str" : "702575566050959360",
  "text" : "ICYMI, for the US-TZ people here: Inspired by \u201EPunctuation in Novels\u201C by @neuroecology I did \u201EPunctuation in Code\u201C: https:\/\/t.co\/nEGwuJqSGv",
  "id" : 702575566050959360,
  "created_at" : "2016-02-24 19:27:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11401464469736, 8.753416202305756 ]
  },
  "id_str" : "702567238944088065",
  "text" : "So far: every single time I told conference organizers I won\u2019t join their all-male panel they magically found women to join the panel. \uD83E\uDD84",
  "id" : 702567238944088065,
  "created_at" : "2016-02-24 18:54:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam J Calhoun",
      "screen_name" : "neuroecology",
      "indices" : [ 0, 13 ],
      "id_str" : "636023721",
      "id" : 636023721
    }, {
      "name" : "Dr. Donut \u2615\uFE0F",
      "screen_name" : "BEBischof",
      "indices" : [ 14, 24 ],
      "id_str" : "223231567",
      "id" : 223231567
    }, {
      "name" : "Philip Bump",
      "screen_name" : "pbump",
      "indices" : [ 25, 31 ],
      "id_str" : "950531",
      "id" : 950531
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "702556094279897089",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11401386724529, 8.753414079962779 ]
  },
  "id_str" : "702556381996568582",
  "in_reply_to_user_id" : 636023721,
  "text" : "@neuroecology @BEBischof @pbump cool, I\u2019m currently on my way to a concert anyhow, so I can\u2019t code much as well :D",
  "id" : 702556381996568582,
  "in_reply_to_status_id" : 702556094279897089,
  "created_at" : "2016-02-24 18:11:08 +0000",
  "in_reply_to_screen_name" : "neuroecology",
  "in_reply_to_user_id_str" : "636023721",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "702538896463126528",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.10825939946818, 8.775535784669943 ]
  },
  "id_str" : "702539267206201344",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez too bad I don\u2019t use gdocs so often :(",
  "id" : 702539267206201344,
  "in_reply_to_status_id" : 702538896463126528,
  "created_at" : "2016-02-24 17:03:08 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "702537750776381441",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.10813429956335, 8.775101099171465 ]
  },
  "id_str" : "702538831078281219",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez Google docs allows roll back of versions doesn\u2019t it? :)",
  "id" : 702538831078281219,
  "in_reply_to_status_id" : 702537750776381441,
  "created_at" : "2016-02-24 17:01:24 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "702537008795639808",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.10808421769189, 8.766212761410294 ]
  },
  "id_str" : "702537185766076418",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez \uD83D\uDC4D give it a try!",
  "id" : 702537185766076418,
  "in_reply_to_status_id" : 702537008795639808,
  "created_at" : "2016-02-24 16:54:52 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "702535902321455104",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.10888519235897, 8.763446230449492 ]
  },
  "id_str" : "702536758341341184",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez talking about human language or your R scripts? :D",
  "id" : 702536758341341184,
  "in_reply_to_status_id" : 702535902321455104,
  "created_at" : "2016-02-24 16:53:10 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Randy Olson",
      "screen_name" : "randal_olson",
      "indices" : [ 3, 16 ],
      "id_str" : "49413866",
      "id" : 49413866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "dataviz",
      "indices" : [ 96, 104 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/8CilkQyYz9",
      "expanded_url" : "http:\/\/gedankenstuecke.github.io\/visualizing-code\/",
      "display_url" : "gedankenstuecke.github.io\/visualizing-co\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "702532670694232065",
  "text" : "RT @randal_olson: Visualizing code: Only the punctuation.\n\nGuess the language for each of these #dataviz.\n\nhttps:\/\/t.co\/8CilkQyYz9 https:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/randal_olson\/status\/702522258342993920\/photo\/1",
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/W8gvmwzEI5",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cb_cRYBWwAI8Ymn.jpg",
        "id_str" : "702522257957109762",
        "id" : 702522257957109762,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cb_cRYBWwAI8Ymn.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/W8gvmwzEI5"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/randal_olson\/status\/702522258342993920\/photo\/1",
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/W8gvmwzEI5",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cb_cRXkXIAALSx1.jpg",
        "id_str" : "702522257835499520",
        "id" : 702522257835499520,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cb_cRXkXIAALSx1.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/W8gvmwzEI5"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/randal_olson\/status\/702522258342993920\/photo\/1",
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/W8gvmwzEI5",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cb_cRXiWIAAs3qx.jpg",
        "id_str" : "702522257827045376",
        "id" : 702522257827045376,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cb_cRXiWIAAs3qx.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/W8gvmwzEI5"
      } ],
      "hashtags" : [ {
        "text" : "dataviz",
        "indices" : [ 78, 86 ]
      } ],
      "urls" : [ {
        "indices" : [ 89, 112 ],
        "url" : "https:\/\/t.co\/8CilkQyYz9",
        "expanded_url" : "http:\/\/gedankenstuecke.github.io\/visualizing-code\/",
        "display_url" : "gedankenstuecke.github.io\/visualizing-co\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "702522258342993920",
    "text" : "Visualizing code: Only the punctuation.\n\nGuess the language for each of these #dataviz.\n\nhttps:\/\/t.co\/8CilkQyYz9 https:\/\/t.co\/W8gvmwzEI5",
    "id" : 702522258342993920,
    "created_at" : "2016-02-24 15:55:33 +0000",
    "user" : {
      "name" : "Randy Olson",
      "screen_name" : "randal_olson",
      "protected" : false,
      "id_str" : "49413866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/770816518988959744\/Ma530Li__normal.jpg",
      "id" : 49413866,
      "verified" : false
    }
  },
  "id" : 702532670694232065,
  "created_at" : "2016-02-24 16:36:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Donut \u2615\uFE0F",
      "screen_name" : "BEBischof",
      "indices" : [ 0, 10 ],
      "id_str" : "223231567",
      "id" : 223231567
    }, {
      "name" : "Philip Bump",
      "screen_name" : "pbump",
      "indices" : [ 11, 17 ],
      "id_str" : "950531",
      "id" : 950531
    }, {
      "name" : "Adam J Calhoun",
      "screen_name" : "neuroecology",
      "indices" : [ 30, 43 ],
      "id_str" : "636023721",
      "id" : 636023721
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "702524340382773250",
  "geo" : { },
  "id_str" : "702531575024640002",
  "in_reply_to_user_id" : 223231567,
  "text" : "@BEBischof @pbump sure, maybe @neuroecology has the code he used for me? :)",
  "id" : 702531575024640002,
  "in_reply_to_status_id" : 702524340382773250,
  "created_at" : "2016-02-24 16:32:34 +0000",
  "in_reply_to_screen_name" : "BEBischof",
  "in_reply_to_user_id_str" : "223231567",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "S\u033Ce\u0325b\u0353a\u0330s\u032Cti\u035Aa\u0349n\u034E M\u031Fo\u034Drr\u033B",
      "screen_name" : "blinry",
      "indices" : [ 0, 7 ],
      "id_str" : "53749209",
      "id" : 53749209
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 72 ],
      "url" : "https:\/\/t.co\/nEGwuJqSGv",
      "expanded_url" : "http:\/\/gedankenstuecke.github.io\/visualizing-code\/",
      "display_url" : "gedankenstuecke.github.io\/visualizing-co\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "702503540179210240",
  "geo" : { },
  "id_str" : "702504907316789248",
  "in_reply_to_user_id" : 53749209,
  "text" : "@blinry yes, makes Perl look nice. Added them to https:\/\/t.co\/nEGwuJqSGv :)",
  "id" : 702504907316789248,
  "in_reply_to_status_id" : 702503540179210240,
  "created_at" : "2016-02-24 14:46:36 +0000",
  "in_reply_to_screen_name" : "blinry",
  "in_reply_to_user_id_str" : "53749209",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "S\u033Ce\u0325b\u0353a\u0330s\u032Cti\u035Aa\u0349n\u034E M\u031Fo\u034Drr\u033B",
      "screen_name" : "blinry",
      "indices" : [ 0, 7 ],
      "id_str" : "53749209",
      "id" : 53749209
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/702502081651941376\/photo\/1",
      "indices" : [ 29, 52 ],
      "url" : "https:\/\/t.co\/W1NtDH37mC",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cb_J60SWwAECL4H.jpg",
      "id_str" : "702502079198314497",
      "id" : 702502079198314497,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cb_J60SWwAECL4H.jpg",
      "sizes" : [ {
        "h" : 680,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1000,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 1000,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 1000,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/W1NtDH37mC"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "702501773257396224",
  "geo" : { },
  "id_str" : "702502081651941376",
  "in_reply_to_user_id" : 53749209,
  "text" : "@blinry and there you go. :) https:\/\/t.co\/W1NtDH37mC",
  "id" : 702502081651941376,
  "in_reply_to_status_id" : 702501773257396224,
  "created_at" : "2016-02-24 14:35:22 +0000",
  "in_reply_to_screen_name" : "blinry",
  "in_reply_to_user_id_str" : "53749209",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "S\u033Ce\u0325b\u0353a\u0330s\u032Cti\u035Aa\u0349n\u034E M\u031Fo\u034Drr\u033B",
      "screen_name" : "blinry",
      "indices" : [ 0, 7 ],
      "id_str" : "53749209",
      "id" : 53749209
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "702499847157518336",
  "geo" : { },
  "id_str" : "702500982312321024",
  "in_reply_to_user_id" : 53749209,
  "text" : "@blinry unfortunately it has &lt;100 punctuation symbols, so can\u2019t do the plot :p",
  "id" : 702500982312321024,
  "in_reply_to_status_id" : 702499847157518336,
  "created_at" : "2016-02-24 14:31:00 +0000",
  "in_reply_to_screen_name" : "blinry",
  "in_reply_to_user_id_str" : "53749209",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/702497843274227712\/photo\/1",
      "indices" : [ 47, 70 ],
      "url" : "https:\/\/t.co\/bHsR4sOyfS",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cb_GEG-UYAEUkhA.jpg",
      "id_str" : "702497840786857985",
      "id" : 702497840786857985,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cb_GEG-UYAEUkhA.jpg",
      "sizes" : [ {
        "h" : 680,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1000,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 1000,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 1000,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/bHsR4sOyfS"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "702477578234433536",
  "geo" : { },
  "id_str" : "702497843274227712",
  "in_reply_to_user_id" : 14286491,
  "text" : "Addendum to my Punctuation in Code: Brainfuck. https:\/\/t.co\/bHsR4sOyfS",
  "id" : 702497843274227712,
  "in_reply_to_status_id" : 702477578234433536,
  "created_at" : "2016-02-24 14:18:32 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam J Calhoun",
      "screen_name" : "neuroecology",
      "indices" : [ 0, 13 ],
      "id_str" : "636023721",
      "id" : 636023721
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "702482965427830784",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17215247756558, 8.627709926688683 ]
  },
  "id_str" : "702485218461143040",
  "in_reply_to_user_id" : 636023721,
  "text" : "@neuroecology thanks! Really like your work :)",
  "id" : 702485218461143040,
  "in_reply_to_status_id" : 702482965427830784,
  "created_at" : "2016-02-24 13:28:22 +0000",
  "in_reply_to_screen_name" : "neuroecology",
  "in_reply_to_user_id_str" : "636023721",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam J Calhoun",
      "screen_name" : "neuroecology",
      "indices" : [ 39, 52 ],
      "id_str" : "636023721",
      "id" : 636023721
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/nEGwuJqSGv",
      "expanded_url" : "http:\/\/gedankenstuecke.github.io\/visualizing-code\/",
      "display_url" : "gedankenstuecke.github.io\/visualizing-co\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "702477578234433536",
  "text" : "Inspired by \u201EPunctuation in Novels\u201C by @neuroecology I did \u201EPunctuation in Code\u201C: https:\/\/t.co\/nEGwuJqSGv",
  "id" : 702477578234433536,
  "created_at" : "2016-02-24 12:58:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "702441683066159104",
  "text" : "Local green party is campaigning with the slogan \u2018innovation instead of stasis\u2019. Funny, coming from the party that tried banning GM insulin\u2026",
  "id" : 702441683066159104,
  "created_at" : "2016-02-24 10:35:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bob O'Hara",
      "screen_name" : "BobOHara",
      "indices" : [ 0, 9 ],
      "id_str" : "19146944",
      "id" : 19146944
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "702435260164927491",
  "geo" : { },
  "id_str" : "702435340162867200",
  "in_reply_to_user_id" : 19146944,
  "text" : "@BobOHara at least i\u2019m provided with coffee!",
  "id" : 702435340162867200,
  "in_reply_to_status_id" : 702435260164927491,
  "created_at" : "2016-02-24 10:10:10 +0000",
  "in_reply_to_screen_name" : "BobOHara",
  "in_reply_to_user_id_str" : "19146944",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/WMFSoN2t5y",
      "expanded_url" : "https:\/\/33.media.tumblr.com\/fa9ffc315c829aadcb232e9fa516d332\/tumblr_inline_npcd0cLBRb1sgagtk_500.gif",
      "display_url" : "33.media.tumblr.com\/fa9ffc315c829a\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "702418738700787713",
  "text" : "having root privileges sounded like fun and a good way to get more things done\u2026 https:\/\/t.co\/WMFSoN2t5y",
  "id" : 702418738700787713,
  "created_at" : "2016-02-24 09:04:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Haaretz.com",
      "screen_name" : "haaretzcom",
      "indices" : [ 3, 14 ],
      "id_str" : "24506246",
      "id" : 24506246
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/YBZeT1w1bF",
      "expanded_url" : "http:\/\/dlvr.it\/KbNG19",
      "display_url" : "dlvr.it\/KbNG19"
    } ]
  },
  "geo" : { },
  "id_str" : "702270864256061440",
  "text" : "RT @haaretzcom: \u2018Batwoman\u2019 of Tel Aviv sets up impromptu shelter for wounded fruit bats in her home https:\/\/t.co\/YBZeT1w1bF https:\/\/t.co\/kM\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dlvrit.com\/\" rel=\"nofollow\"\u003Edlvr.it\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/haaretzcom\/status\/702261423431233537\/photo\/1",
        "indices" : [ 108, 131 ],
        "url" : "https:\/\/t.co\/kMGK5D8C6I",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cb7vCzSUcAAdDzq.jpg",
        "id_str" : "702261423322198016",
        "id" : 702261423322198016,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cb7vCzSUcAAdDzq.jpg",
        "sizes" : [ {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 357,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/kMGK5D8C6I"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 84, 107 ],
        "url" : "https:\/\/t.co\/YBZeT1w1bF",
        "expanded_url" : "http:\/\/dlvr.it\/KbNG19",
        "display_url" : "dlvr.it\/KbNG19"
      } ]
    },
    "geo" : { },
    "id_str" : "702261423431233537",
    "text" : "\u2018Batwoman\u2019 of Tel Aviv sets up impromptu shelter for wounded fruit bats in her home https:\/\/t.co\/YBZeT1w1bF https:\/\/t.co\/kMGK5D8C6I",
    "id" : 702261423431233537,
    "created_at" : "2016-02-23 22:39:05 +0000",
    "user" : {
      "name" : "Haaretz.com",
      "screen_name" : "haaretzcom",
      "protected" : false,
      "id_str" : "24506246",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/669523420774858753\/Q3O8r8FJ_normal.png",
      "id" : 24506246,
      "verified" : true
    }
  },
  "id" : 702270864256061440,
  "created_at" : "2016-02-23 23:16:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "talia jane (@jack loves white supremacy & nazis)",
      "screen_name" : "itsa_talia",
      "indices" : [ 3, 14 ],
      "id_str" : "173774813",
      "id" : 173774813
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 62 ],
      "url" : "https:\/\/t.co\/lSxltnount",
      "expanded_url" : "https:\/\/medium.com\/@taliajane\/an-open-letter-to-you-69ed3f150540#.2gqxc8o24",
      "display_url" : "medium.com\/@taliajane\/an-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "702269794880507904",
  "text" : "RT @itsa_talia: An Open Letter To You:\nhttps:\/\/t.co\/lSxltnount",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 23, 46 ],
        "url" : "https:\/\/t.co\/lSxltnount",
        "expanded_url" : "https:\/\/medium.com\/@taliajane\/an-open-letter-to-you-69ed3f150540#.2gqxc8o24",
        "display_url" : "medium.com\/@taliajane\/an-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "702256031154343936",
    "text" : "An Open Letter To You:\nhttps:\/\/t.co\/lSxltnount",
    "id" : 702256031154343936,
    "created_at" : "2016-02-23 22:17:39 +0000",
    "user" : {
      "name" : "talia jane (@jack loves white supremacy & nazis)",
      "screen_name" : "itsa_talia",
      "protected" : false,
      "id_str" : "173774813",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/918893573780725765\/kzG7KRyx_normal.jpg",
      "id" : 173774813,
      "verified" : false
    }
  },
  "id" : 702269794880507904,
  "created_at" : "2016-02-23 23:12:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "botally",
      "indices" : [ 8, 16 ]
    } ],
    "urls" : [ {
      "indices" : [ 17, 40 ],
      "url" : "https:\/\/t.co\/Ta1nSIgRUl",
      "expanded_url" : "https:\/\/twitter.com\/zephoria\/status\/702215461736468481",
      "display_url" : "twitter.com\/zephoria\/statu\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0609478080716, 8.818663986481008 ]
  },
  "id_str" : "702255483558764548",
  "text" : "One for #botally https:\/\/t.co\/Ta1nSIgRUl",
  "id" : 702255483558764548,
  "created_at" : "2016-02-23 22:15:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael R. Crusoe",
      "screen_name" : "biocrusoe",
      "indices" : [ 0, 10 ],
      "id_str" : "17645638",
      "id" : 17645638
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "702152811270828032",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06124418778589, 8.81869746473569 ]
  },
  "id_str" : "702196924288520192",
  "in_reply_to_user_id" : 17645638,
  "text" : "@biocrusoe congratulations, that\u2019s great news!",
  "id" : 702196924288520192,
  "in_reply_to_status_id" : 702152811270828032,
  "created_at" : "2016-02-23 18:22:47 +0000",
  "in_reply_to_screen_name" : "biocrusoe",
  "in_reply_to_user_id_str" : "17645638",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 33 ],
      "url" : "https:\/\/t.co\/682wavYslD",
      "expanded_url" : "http:\/\/cdn.makeagif.com\/media\/9-30-2015\/4KuYfG.gif",
      "display_url" : "cdn.makeagif.com\/media\/9-30-201\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "702175076091822080",
  "text" : "Docker\u2026 \uD83D\uDC33 https:\/\/t.co\/682wavYslD",
  "id" : 702175076091822080,
  "created_at" : "2016-02-23 16:55:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "702152179096748032",
  "geo" : { },
  "id_str" : "702152231911555072",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez that\u2019s fine by me as well, I maybe should do the same :D",
  "id" : 702152231911555072,
  "in_reply_to_status_id" : 702152179096748032,
  "created_at" : "2016-02-23 15:25:12 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "702152052743368704",
  "geo" : { },
  "id_str" : "702152180401381376",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez great!",
  "id" : 702152180401381376,
  "in_reply_to_status_id" : 702152052743368704,
  "created_at" : "2016-02-23 15:24:59 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "702150936714608640",
  "geo" : { },
  "id_str" : "702151976373645312",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez this i never did actually, would love an example!",
  "id" : 702151976373645312,
  "in_reply_to_status_id" : 702150936714608640,
  "created_at" : "2016-02-23 15:24:11 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "702150186844291072",
  "geo" : { },
  "id_str" : "702151938725572612",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez it could be a QS-productivity boost for both of us :D",
  "id" : 702151938725572612,
  "in_reply_to_status_id" : 702150186844291072,
  "created_at" : "2016-02-23 15:24:02 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "702143883191291904",
  "geo" : { },
  "id_str" : "702150065520041985",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez well done! So it\u2019s my turn again? :D",
  "id" : 702150065520041985,
  "in_reply_to_status_id" : 702143883191291904,
  "created_at" : "2016-02-23 15:16:35 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mohamed Noor",
      "screen_name" : "mafnoor",
      "indices" : [ 3, 11 ],
      "id_str" : "24001758",
      "id" : 24001758
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/hQe8jd24qI",
      "expanded_url" : "http:\/\/science-and-food.blogspot.com\/2016\/02\/dear-reviewer-2.html",
      "display_url" : "science-and-food.blogspot.com\/2016\/02\/dear-r\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "702096767903518720",
  "text" : "RT @mafnoor: An open letter to \"reviewer 2\" (for manuscripts and grant proposals): https:\/\/t.co\/hQe8jd24qI",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 70, 93 ],
        "url" : "https:\/\/t.co\/hQe8jd24qI",
        "expanded_url" : "http:\/\/science-and-food.blogspot.com\/2016\/02\/dear-reviewer-2.html",
        "display_url" : "science-and-food.blogspot.com\/2016\/02\/dear-r\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "701404080518918146",
    "text" : "An open letter to \"reviewer 2\" (for manuscripts and grant proposals): https:\/\/t.co\/hQe8jd24qI",
    "id" : 701404080518918146,
    "created_at" : "2016-02-21 13:52:18 +0000",
    "user" : {
      "name" : "Mohamed Noor",
      "screen_name" : "mafnoor",
      "protected" : false,
      "id_str" : "24001758",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/189406342\/noor_normal.jpg",
      "id" : 24001758,
      "verified" : false
    }
  },
  "id" : 702096767903518720,
  "created_at" : "2016-02-23 11:44:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 62 ],
      "url" : "https:\/\/t.co\/QEfBzV7CCh",
      "expanded_url" : "http:\/\/i.imgur.com\/1DRSNpP.gifv",
      "display_url" : "i.imgur.com\/1DRSNpP.gifv"
    } ]
  },
  "geo" : { },
  "id_str" : "702084719815630848",
  "text" : "what I hoped for when I got my Roomba. https:\/\/t.co\/QEfBzV7CCh",
  "id" : 702084719815630848,
  "created_at" : "2016-02-23 10:56:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "702079281640378368",
  "text" : "Give it a couple of more days teaching Python 3 and I\u2019ll finally be in the habit of using print().",
  "id" : 702079281640378368,
  "created_at" : "2016-02-23 10:35:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Oddur Vilhelmsson",
      "screen_name" : "OddurV",
      "indices" : [ 3, 10 ],
      "id_str" : "1280137776",
      "id" : 1280137776
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/23bEwuUhBk",
      "expanded_url" : "http:\/\/www.eag.eu.com\/jobs\/107adb5130da8694866ae5e7b921ed26.pdf",
      "display_url" : "eag.eu.com\/jobs\/107adb513\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "702042879221493760",
  "text" : "RT @OddurV: One week left till the deadline! Arctic Micro PhD studentship in Akureyri, Iceland. https:\/\/t.co\/23bEwuUhBk",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 84, 107 ],
        "url" : "https:\/\/t.co\/23bEwuUhBk",
        "expanded_url" : "http:\/\/www.eag.eu.com\/jobs\/107adb5130da8694866ae5e7b921ed26.pdf",
        "display_url" : "eag.eu.com\/jobs\/107adb513\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "702031606551285761",
    "text" : "One week left till the deadline! Arctic Micro PhD studentship in Akureyri, Iceland. https:\/\/t.co\/23bEwuUhBk",
    "id" : 702031606551285761,
    "created_at" : "2016-02-23 07:25:52 +0000",
    "user" : {
      "name" : "Oddur Vilhelmsson",
      "screen_name" : "OddurV",
      "protected" : false,
      "id_str" : "1280137776",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3404925242\/526d7f7f8e7ecc04c705fc50f257c55e_normal.jpeg",
      "id" : 1280137776,
      "verified" : false
    }
  },
  "id" : 702042879221493760,
  "created_at" : "2016-02-23 08:10:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/h91MZ7PLpP",
      "expanded_url" : "http:\/\/phenomena.nationalgeographic.com\/2016\/02\/22\/flies-could-falsely-place-someone-at-a-crime-scene\/",
      "display_url" : "phenomena.nationalgeographic.com\/2016\/02\/22\/fli\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "702036014106329088",
  "text" : "\u00ABWhat you draw more flies with, it turns out, is semen. It\u2019s the crack cocaine of the fly world.\u00BB https:\/\/t.co\/h91MZ7PLpP",
  "id" : 702036014106329088,
  "created_at" : "2016-02-23 07:43:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/Y2Rot4LrlH",
      "expanded_url" : "http:\/\/www.king-royal-design.com\/wp-content\/uploads\/2011\/10\/i-m-sorry-dave-e1369058177230.jpg",
      "display_url" : "king-royal-design.com\/wp-content\/upl\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "701919908020539392",
  "geo" : { },
  "id_str" : "701920972882968576",
  "in_reply_to_user_id" : 14286491,
  "text" : "What your IoT-Fridge will answer if you request dessert, all because the damn toothbrush did rat you out. https:\/\/t.co\/Y2Rot4LrlH",
  "id" : 701920972882968576,
  "in_reply_to_status_id" : 701919908020539392,
  "created_at" : "2016-02-23 00:06:15 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 66 ],
      "url" : "https:\/\/t.co\/XANqfMPlEW",
      "expanded_url" : "http:\/\/www.theverge.com\/2016\/2\/22\/11095502\/oral-b-genius-toothbrush-smartphone-app-mirror-mount?utm_campaign=theverge&utm_content=chorus&utm_medium=social&utm_source=twitter",
      "display_url" : "theverge.com\/2016\/2\/22\/1109\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "701919908020539392",
  "text" : "Why isn\u2019t this called the Bluetoothbrush?! https:\/\/t.co\/XANqfMPlEW",
  "id" : 701919908020539392,
  "created_at" : "2016-02-23 00:02:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Loman",
      "screen_name" : "pathogenomenick",
      "indices" : [ 0, 16 ],
      "id_str" : "85906238",
      "id" : 85906238
    }, {
      "name" : "Adam Phillippy",
      "screen_name" : "aphillippy",
      "indices" : [ 17, 28 ],
      "id_str" : "52133120",
      "id" : 52133120
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "701777718912950272",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11395110308461, 8.753397086768523 ]
  },
  "id_str" : "701908321503207425",
  "in_reply_to_user_id" : 85906238,
  "text" : "@pathogenomenick @aphillippy what was the issue? :)",
  "id" : 701908321503207425,
  "in_reply_to_status_id" : 701777718912950272,
  "created_at" : "2016-02-22 23:15:59 +0000",
  "in_reply_to_screen_name" : "pathogenomenick",
  "in_reply_to_user_id_str" : "85906238",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 56 ],
      "url" : "https:\/\/t.co\/NlfSDtMsXk",
      "expanded_url" : "http:\/\/shitmyreviewerssay.tumblr.com\/post\/139606205109\/this-paper-reads-like-a-womans-diary-not-like-a",
      "display_url" : "shitmyreviewerssay.tumblr.com\/post\/139606205\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "701879598192066560",
  "text" : "thanks for anonymous peer review https:\/\/t.co\/NlfSDtMsXk",
  "id" : 701879598192066560,
  "created_at" : "2016-02-22 21:21:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 72 ],
      "url" : "https:\/\/t.co\/ypBQtQuAhp",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=DRauXXz6t0Y",
      "display_url" : "youtube.com\/watch?v=DRauXX\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "701867244763095043",
  "text" : "i knew US abortion laws sucked, but that much? \uD83D\uDE22 https:\/\/t.co\/ypBQtQuAhp",
  "id" : 701867244763095043,
  "created_at" : "2016-02-22 20:32:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "openscience",
      "indices" : [ 4, 16 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17365538562844, 8.629601035968008 ]
  },
  "id_str" : "701838097609318401",
  "text" : "Hey #openscience crowd: who of you will be in Madrid this weekend?",
  "id" : 701838097609318401,
  "created_at" : "2016-02-22 18:36:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "701798436392329217",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17877745945996, 8.614597522975306 ]
  },
  "id_str" : "701819830597525504",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot not on the vomit comet!",
  "id" : 701819830597525504,
  "in_reply_to_status_id" : 701798436392329217,
  "created_at" : "2016-02-22 17:24:21 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 45 ],
      "url" : "https:\/\/t.co\/WhrpfiN0IN",
      "expanded_url" : "http:\/\/i2.mirror.co.uk\/incoming\/article4691481.ece\/ALTERNATES\/s1227b\/MAIN-Jumping-Dog.jpg",
      "display_url" : "i2.mirror.co.uk\/incoming\/artic\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "701795967599833089",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17249991460889, 8.627529360146823 ]
  },
  "id_str" : "701796915034329088",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot only like this https:\/\/t.co\/WhrpfiN0IN",
  "id" : 701796915034329088,
  "in_reply_to_status_id" : 701795967599833089,
  "created_at" : "2016-02-22 15:53:17 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "701774385766658048",
  "geo" : { },
  "id_str" : "701795255855751170",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot that classification put you on the no-fly list right away.",
  "id" : 701795255855751170,
  "in_reply_to_status_id" : 701774385766658048,
  "created_at" : "2016-02-22 15:46:42 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mick Watson",
      "screen_name" : "BioMickWatson",
      "indices" : [ 0, 14 ],
      "id_str" : "228586748",
      "id" : 228586748
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "701735258895597568",
  "geo" : { },
  "id_str" : "701743681024499712",
  "in_reply_to_user_id" : 228586748,
  "text" : "@BioMickWatson at least it\u2019s not use strict; ;)",
  "id" : 701743681024499712,
  "in_reply_to_status_id" : 701735258895597568,
  "created_at" : "2016-02-22 12:21:45 +0000",
  "in_reply_to_screen_name" : "BioMickWatson",
  "in_reply_to_user_id_str" : "228586748",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mathilde Cordellier",
      "screen_name" : "m_cordellier",
      "indices" : [ 0, 13 ],
      "id_str" : "3373710875",
      "id" : 3373710875
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "701741913532186624",
  "geo" : { },
  "id_str" : "701742060710178816",
  "in_reply_to_user_id" : 3373710875,
  "text" : "@m_cordellier we weren\u2019t that bad, were we?",
  "id" : 701742060710178816,
  "in_reply_to_status_id" : 701741913532186624,
  "created_at" : "2016-02-22 12:15:19 +0000",
  "in_reply_to_screen_name" : "m_cordellier",
  "in_reply_to_user_id_str" : "3373710875",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/YyMyiPH2XN",
      "expanded_url" : "https:\/\/twitter.com\/JennyRohn\/status\/701691911053164546",
      "display_url" : "twitter.com\/JennyRohn\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "701741818686414848",
  "text" : "\u00ABdetained on account of having insuffic. personal funds to pay for a course that I hadn\u2019t even been accepted into.\u00BB https:\/\/t.co\/YyMyiPH2XN",
  "id" : 701741818686414848,
  "created_at" : "2016-02-22 12:14:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17902603827857, 8.625941276672046 ]
  },
  "id_str" : "701734696359698433",
  "text" : "Status teaching Python: unlike teaching Perl no one started crying so far. That\u2019s good, right?",
  "id" : 701734696359698433,
  "created_at" : "2016-02-22 11:46:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "beau",
      "screen_name" : "beaugunderson",
      "indices" : [ 0, 14 ],
      "id_str" : "5746882",
      "id" : 5746882
    }, {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 15, 24 ],
      "id_str" : "21135674",
      "id" : 21135674
    }, {
      "name" : "Zenobase",
      "screen_name" : "zenobase",
      "indices" : [ 25, 34 ],
      "id_str" : "556162919",
      "id" : 556162919
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "701496214248796161",
  "geo" : { },
  "id_str" : "701496360290406400",
  "in_reply_to_user_id" : 5746882,
  "text" : "@beaugunderson @eramirez @zenobase I\u2019m largely in it to have my stuff in one place and want to be able to query it easily.",
  "id" : 701496360290406400,
  "in_reply_to_status_id" : 701496214248796161,
  "created_at" : "2016-02-21 19:59:00 +0000",
  "in_reply_to_screen_name" : "beaugunderson",
  "in_reply_to_user_id_str" : "5746882",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "beau",
      "screen_name" : "beaugunderson",
      "indices" : [ 0, 14 ],
      "id_str" : "5746882",
      "id" : 5746882
    }, {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 15, 24 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "701495888208736256",
  "geo" : { },
  "id_str" : "701495973231595520",
  "in_reply_to_user_id" : 5746882,
  "text" : "@beaugunderson @eramirez anything you can particularly recommend?",
  "id" : 701495973231595520,
  "in_reply_to_status_id" : 701495888208736256,
  "created_at" : "2016-02-21 19:57:27 +0000",
  "in_reply_to_screen_name" : "beaugunderson",
  "in_reply_to_user_id_str" : "5746882",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    }, {
      "name" : "Validic",
      "screen_name" : "validic",
      "indices" : [ 10, 18 ],
      "id_str" : "606326027",
      "id" : 606326027
    }, {
      "name" : "Open mHealth",
      "screen_name" : "OpenmHealth",
      "indices" : [ 19, 31 ],
      "id_str" : "380396780",
      "id" : 380396780
    }, {
      "name" : "Fluxtream",
      "screen_name" : "fluxtream",
      "indices" : [ 32, 42 ],
      "id_str" : "414687137",
      "id" : 414687137
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "701495305720635392",
  "geo" : { },
  "id_str" : "701495384179417089",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez @validic @OpenmHealth @fluxtream not yet, thanks!",
  "id" : 701495384179417089,
  "in_reply_to_status_id" : 701495305720635392,
  "created_at" : "2016-02-21 19:55:07 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uD83D\uDCABKelsey Merkley \uD83D\uDCAB",
      "screen_name" : "bella_velo",
      "indices" : [ 0, 11 ],
      "id_str" : "6745972",
      "id" : 6745972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "701483545781526532",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11401390164031, 8.753415237369104 ]
  },
  "id_str" : "701493275916685313",
  "in_reply_to_user_id" : 6745972,
  "text" : "@bella_velo word!",
  "id" : 701493275916685313,
  "in_reply_to_status_id" : 701483545781526532,
  "created_at" : "2016-02-21 19:46:44 +0000",
  "in_reply_to_screen_name" : "bella_velo",
  "in_reply_to_user_id_str" : "6745972",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/701473985662423040\/photo\/1",
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/CGEvp1O8qM",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cbwi35AW4AYYjwh.jpg",
      "id_str" : "701473985553424390",
      "id" : 701473985553424390,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cbwi35AW4AYYjwh.jpg",
      "sizes" : [ {
        "h" : 400,
        "resize" : "fit",
        "w" : 266
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 266
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 266
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 266
      } ],
      "display_url" : "pic.twitter.com\/CGEvp1O8qM"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/4sPwe7hCBv",
      "expanded_url" : "http:\/\/amzn.to\/1SKEQTM",
      "display_url" : "amzn.to\/1SKEQTM"
    } ]
  },
  "geo" : { },
  "id_str" : "701473985662423040",
  "text" : "nice example of verbal shock &amp; awe to silence people who clearly overstepped. https:\/\/t.co\/4sPwe7hCBv https:\/\/t.co\/CGEvp1O8qM",
  "id" : 701473985662423040,
  "created_at" : "2016-02-21 18:30:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "The_Smoking_GNU",
      "indices" : [ 0, 16 ],
      "id_str" : "14535787",
      "id" : 14535787
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "701449577346502656",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11400151805898, 8.753429210925527 ]
  },
  "id_str" : "701451744568614915",
  "in_reply_to_user_id" : 14535787,
  "text" : "@The_Smoking_GNU cool, den ganzen M\u00E4rz \u00FCber bin ich sogar hier bislang, also falls du Lust hast k\u00F6nnten wir Twitter-Treffen :D",
  "id" : 701451744568614915,
  "in_reply_to_status_id" : 701449577346502656,
  "created_at" : "2016-02-21 17:01:42 +0000",
  "in_reply_to_screen_name" : "The_Smoking_GNU",
  "in_reply_to_user_id_str" : "14535787",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "The_Smoking_GNU",
      "indices" : [ 0, 16 ],
      "id_str" : "14535787",
      "id" : 14535787
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "701449101263638528",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11404383445736, 8.753436270220593 ]
  },
  "id_str" : "701449191726387204",
  "in_reply_to_user_id" : 14535787,
  "text" : "@The_Smoking_GNU magst du nicht mal wieder hier in der Gegend backen? :D",
  "id" : 701449191726387204,
  "in_reply_to_status_id" : 701449101263638528,
  "created_at" : "2016-02-21 16:51:34 +0000",
  "in_reply_to_screen_name" : "The_Smoking_GNU",
  "in_reply_to_user_id_str" : "14535787",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "The_Smoking_GNU",
      "indices" : [ 0, 16 ],
      "id_str" : "14535787",
      "id" : 14535787
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "701448302814953472",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11403870320315, 8.753445833476096 ]
  },
  "id_str" : "701448612711153664",
  "in_reply_to_user_id" : 14535787,
  "text" : "@The_Smoking_GNU wo kann ich probieren kommen? :&gt;",
  "id" : 701448612711153664,
  "in_reply_to_status_id" : 701448302814953472,
  "created_at" : "2016-02-21 16:49:16 +0000",
  "in_reply_to_screen_name" : "The_Smoking_GNU",
  "in_reply_to_user_id_str" : "14535787",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "quantifiedself",
      "indices" : [ 125, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "701435493888749570",
  "text" : "I vaguely remember there being some API solutions for merging your QS data sources into a unified data stream. Any pointers? #quantifiedself",
  "id" : 701435493888749570,
  "created_at" : "2016-02-21 15:57:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "701337579304529920",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0607925197016, 8.818513607742648 ]
  },
  "id_str" : "701346708362551296",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer where jump scares come to life!",
  "id" : 701346708362551296,
  "in_reply_to_status_id" : 701337579304529920,
  "created_at" : "2016-02-21 10:04:20 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "svavarknuturontour2016",
      "indices" : [ 27, 50 ]
    }, {
      "text" : "svavarknutour2016",
      "indices" : [ 62, 80 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00412092998065, 8.269005413361361 ]
  },
  "id_str" : "701173798893182976",
  "text" : "And who decided to make it #svavarknuturontour2016 instead of #svavarknutour2016?",
  "id" : 701173798893182976,
  "created_at" : "2016-02-20 22:37:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "F\u00FCxin",
      "screen_name" : "foxeen",
      "indices" : [ 0, 7 ],
      "id_str" : "46904555",
      "id" : 46904555
    }, {
      "name" : "Svavar Kn\u00FAtur",
      "screen_name" : "SvavarKnutur",
      "indices" : [ 8, 21 ],
      "id_str" : "74624782",
      "id" : 74624782
    }, {
      "name" : "Jon Gnarr",
      "screen_name" : "Jon_Gnarr",
      "indices" : [ 22, 32 ],
      "id_str" : "304395437",
      "id" : 304395437
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "701166870146191362",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00393421542829, 8.269142924428216 ]
  },
  "id_str" : "701172356895666177",
  "in_reply_to_user_id" : 46904555,
  "text" : "@foxeen @SvavarKnutur @Jon_Gnarr totally worth it :)",
  "id" : 701172356895666177,
  "in_reply_to_status_id" : 701166870146191362,
  "created_at" : "2016-02-20 22:31:31 +0000",
  "in_reply_to_screen_name" : "foxeen",
  "in_reply_to_user_id_str" : "46904555",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "701168391843934215",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00399809159327, 8.2690020648975 ]
  },
  "id_str" : "701168864974000132",
  "in_reply_to_user_id" : 14286491,
  "text" : "tl;dr: \n\uD83C\uDF0B\u274C\n\u2668\uFE0F\u2705",
  "id" : 701168864974000132,
  "in_reply_to_status_id" : 701168391843934215,
  "created_at" : "2016-02-20 22:17:39 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Svavar Kn\u00FAtur",
      "screen_name" : "SvavarKnutur",
      "indices" : [ 17, 30 ],
      "id_str" : "74624782",
      "id" : 74624782
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00400601135495, 8.269124348875204 ]
  },
  "id_str" : "701168391843934215",
  "text" : "Of course, _now_ @SvavarKnutur is handing out all the advice on outdoor sex in Iceland. Well, guess some mistakes you have to do on your own",
  "id" : 701168391843934215,
  "created_at" : "2016-02-20 22:15:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "F\u00FCxin",
      "screen_name" : "foxeen",
      "indices" : [ 0, 7 ],
      "id_str" : "46904555",
      "id" : 46904555
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "svavarknuturontour2016",
      "indices" : [ 12, 35 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "701163174947586048",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00399014671866, 8.269000933392785 ]
  },
  "id_str" : "701164035799130112",
  "in_reply_to_user_id" : 46904555,
  "text" : "@foxeen see #svavarknuturontour2016 ;)",
  "id" : 701164035799130112,
  "in_reply_to_status_id" : 701163174947586048,
  "created_at" : "2016-02-20 21:58:27 +0000",
  "in_reply_to_screen_name" : "foxeen",
  "in_reply_to_user_id_str" : "46904555",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Schawinski",
      "screen_name" : "kevinschawinski",
      "indices" : [ 0, 16 ],
      "id_str" : "242844365",
      "id" : 242844365
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "701161853657993216",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00399551951237, 8.26900057060691 ]
  },
  "id_str" : "701163007263510528",
  "in_reply_to_user_id" : 242844365,
  "text" : "@kevinschawinski no more sequels pls!",
  "id" : 701163007263510528,
  "in_reply_to_status_id" : 701161853657993216,
  "created_at" : "2016-02-20 21:54:22 +0000",
  "in_reply_to_screen_name" : "kevinschawinski",
  "in_reply_to_user_id_str" : "242844365",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Egle Ramanauskaite \u2623",
      "screen_name" : "Seplute",
      "indices" : [ 0, 8 ],
      "id_str" : "188833865",
      "id" : 188833865
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "701161768081563648",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00399755008784, 8.269000207105911 ]
  },
  "id_str" : "701162631600726018",
  "in_reply_to_user_id" : 188833865,
  "text" : "@Seplute your human computation is spot on!",
  "id" : 701162631600726018,
  "in_reply_to_status_id" : 701161768081563648,
  "created_at" : "2016-02-20 21:52:53 +0000",
  "in_reply_to_screen_name" : "Seplute",
  "in_reply_to_user_id_str" : "188833865",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00412155717459, 8.269003072406255 ]
  },
  "id_str" : "701161607490052096",
  "text" : "\u00ABPope Benedict looked like the illegitimate child of Nosferatu and the Emperor from Star Wars.\u00BB",
  "id" : 701161607490052096,
  "created_at" : "2016-02-20 21:48:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Svavar Kn\u00FAtur",
      "screen_name" : "SvavarKnutur",
      "indices" : [ 105, 118 ],
      "id_str" : "74624782",
      "id" : 74624782
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00399955245999, 8.269000053259129 ]
  },
  "id_str" : "701160220664397825",
  "text" : "\u00ABIt\u2019s unfair of songwriters to take advantage of the fact that teenagers hear music for the first time.\u00BB @SvavarKnutur on those 4 chords.",
  "id" : 701160220664397825,
  "created_at" : "2016-02-20 21:43:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Abby Cabunoc Mayes",
      "screen_name" : "abbycabs",
      "indices" : [ 0, 9 ],
      "id_str" : "395367768",
      "id" : 395367768
    }, {
      "name" : "\u24EA Rik Smith-Unna \uD83C\uDDF0\uD83C\uDDEA",
      "screen_name" : "blahah404",
      "indices" : [ 10, 20 ],
      "id_str" : "99173786",
      "id" : 99173786
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "701157805571629057",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00399878717998, 8.269000121893994 ]
  },
  "id_str" : "701158380312907777",
  "in_reply_to_user_id" : 395367768,
  "text" : "@abbycabs @blahah404 ok, now I know it\u2019s safe for me to come and visit \uD83D\uDE00",
  "id" : 701158380312907777,
  "in_reply_to_status_id" : 701157805571629057,
  "created_at" : "2016-02-20 21:35:59 +0000",
  "in_reply_to_screen_name" : "abbycabs",
  "in_reply_to_user_id_str" : "395367768",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Egle Ramanauskaite \u2623",
      "screen_name" : "Seplute",
      "indices" : [ 0, 8 ],
      "id_str" : "188833865",
      "id" : 188833865
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "701156668969721858",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00411699196041, 8.269004168417593 ]
  },
  "id_str" : "701157952338714624",
  "in_reply_to_user_id" : 188833865,
  "text" : "@Seplute \uD83D\uDC96\uD83D\uDE02",
  "id" : 701157952338714624,
  "in_reply_to_status_id" : 701156668969721858,
  "created_at" : "2016-02-20 21:34:17 +0000",
  "in_reply_to_screen_name" : "Seplute",
  "in_reply_to_user_id_str" : "188833865",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/cwyNuL21qi",
      "expanded_url" : "http:\/\/gedankenstuecke.github.io\/visualize-geolocations\/",
      "display_url" : "gedankenstuecke.github.io\/visualize-geol\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "701154343609827328",
  "text" : "ICYMI, I wrote about geo-visualization: Visualizing Yourself through Space &amp; Time https:\/\/t.co\/cwyNuL21qi",
  "id" : 701154343609827328,
  "created_at" : "2016-02-20 21:19:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uD83D\uDCABKelsey Merkley \uD83D\uDCAB",
      "screen_name" : "bella_velo",
      "indices" : [ 0, 11 ],
      "id_str" : "6745972",
      "id" : 6745972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "701138417715904512",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0040064582227, 8.269000866571387 ]
  },
  "id_str" : "701138886827888641",
  "in_reply_to_user_id" : 6745972,
  "text" : "@bella_velo almost?! \uD83D\uDE09",
  "id" : 701138886827888641,
  "in_reply_to_status_id" : 701138417715904512,
  "created_at" : "2016-02-20 20:18:31 +0000",
  "in_reply_to_screen_name" : "bella_velo",
  "in_reply_to_user_id_str" : "6745972",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DNAdigest.org",
      "screen_name" : "DNADigest",
      "indices" : [ 3, 13 ],
      "id_str" : "334912047",
      "id" : 334912047
    }, {
      "name" : "DNA Testing Choice",
      "screen_name" : "DNATestingChce",
      "indices" : [ 42, 57 ],
      "id_str" : "2494290961",
      "id" : 2494290961
    }, {
      "name" : "OpenSNP",
      "screen_name" : "OpenSNP",
      "indices" : [ 109, 117 ],
      "id_str" : "186279960",
      "id" : 186279960
    }, {
      "name" : "Repositive.io",
      "screen_name" : "repositiveio",
      "indices" : [ 118, 131 ],
      "id_str" : "3059929578",
      "id" : 3059929578
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "genetic",
      "indices" : [ 94, 102 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "701133183467782144",
  "text" : "RT @DNADigest: Where would the founder of @DNATestingChce, a DNA test reviews site, share his #genetic data? @OpenSNP @repositiveio https:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "DNA Testing Choice",
        "screen_name" : "DNATestingChce",
        "indices" : [ 27, 42 ],
        "id_str" : "2494290961",
        "id" : 2494290961
      }, {
        "name" : "OpenSNP",
        "screen_name" : "OpenSNP",
        "indices" : [ 94, 102 ],
        "id_str" : "186279960",
        "id" : 186279960
      }, {
        "name" : "Repositive.io",
        "screen_name" : "repositiveio",
        "indices" : [ 103, 116 ],
        "id_str" : "3059929578",
        "id" : 3059929578
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "genetic",
        "indices" : [ 79, 87 ]
      } ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/roLGQsXWIq",
        "expanded_url" : "http:\/\/buff.ly\/240ONQH",
        "display_url" : "buff.ly\/240ONQH"
      } ]
    },
    "geo" : { },
    "id_str" : "700637470547791872",
    "text" : "Where would the founder of @DNATestingChce, a DNA test reviews site, share his #genetic data? @OpenSNP @repositiveio https:\/\/t.co\/roLGQsXWIq",
    "id" : 700637470547791872,
    "created_at" : "2016-02-19 11:06:04 +0000",
    "user" : {
      "name" : "DNAdigest.org",
      "screen_name" : "DNADigest",
      "protected" : false,
      "id_str" : "334912047",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/430707142232772608\/Vmx-V5fY_normal.png",
      "id" : 334912047,
      "verified" : false
    }
  },
  "id" : 701133183467782144,
  "created_at" : "2016-02-20 19:55:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Svavar Kn\u00FAtur",
      "screen_name" : "SvavarKnutur",
      "indices" : [ 35, 48 ],
      "id_str" : "74624782",
      "id" : 74624782
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00409827269888, 8.268990160408913 ]
  },
  "id_str" : "701126997083291649",
  "text" : "Head to the concert venue and meet @SvavarKnutur outside, commenting on the weather being very Icelandic today. \uD83D\uDE02",
  "id" : 701126997083291649,
  "created_at" : "2016-02-20 19:31:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marino van Zelst",
      "screen_name" : "mzelst",
      "indices" : [ 0, 7 ],
      "id_str" : "98975049",
      "id" : 98975049
    }, {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 8, 22 ],
      "id_str" : "352650591",
      "id" : 352650591
    }, {
      "name" : "\u24EA Chris Hartgerink",
      "screen_name" : "chartgerink",
      "indices" : [ 23, 35 ],
      "id_str" : "439273539",
      "id" : 439273539
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "701062458744684544",
  "geo" : { },
  "id_str" : "701063216672219138",
  "in_reply_to_user_id" : 98975049,
  "text" : "@mzelst @Protohedgehog @chartgerink sure, happy to help!",
  "id" : 701063216672219138,
  "in_reply_to_status_id" : 701062458744684544,
  "created_at" : "2016-02-20 15:17:50 +0000",
  "in_reply_to_screen_name" : "mzelst",
  "in_reply_to_user_id_str" : "98975049",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marino van Zelst",
      "screen_name" : "mzelst",
      "indices" : [ 0, 7 ],
      "id_str" : "98975049",
      "id" : 98975049
    }, {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 8, 22 ],
      "id_str" : "352650591",
      "id" : 352650591
    }, {
      "name" : "\u24EA Chris Hartgerink",
      "screen_name" : "chartgerink",
      "indices" : [ 23, 35 ],
      "id_str" : "439273539",
      "id" : 439273539
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "701058510763773952",
  "geo" : { },
  "id_str" : "701060059569266688",
  "in_reply_to_user_id" : 98975049,
  "text" : "@mzelst @Protohedgehog @chartgerink as I had the stupid idea: would be willing to help classifying those :D",
  "id" : 701060059569266688,
  "in_reply_to_status_id" : 701058510763773952,
  "created_at" : "2016-02-20 15:05:17 +0000",
  "in_reply_to_screen_name" : "mzelst",
  "in_reply_to_user_id_str" : "98975049",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marino van Zelst",
      "screen_name" : "mzelst",
      "indices" : [ 0, 7 ],
      "id_str" : "98975049",
      "id" : 98975049
    }, {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 8, 22 ],
      "id_str" : "352650591",
      "id" : 352650591
    }, {
      "name" : "\u24EA Chris Hartgerink",
      "screen_name" : "chartgerink",
      "indices" : [ 23, 35 ],
      "id_str" : "439273539",
      "id" : 439273539
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "701058510763773952",
  "geo" : { },
  "id_str" : "701059225783508992",
  "in_reply_to_user_id" : 98975049,
  "text" : "@mzelst @Protohedgehog @chartgerink I see, just checked the anonymized data, 662 cases where you to agree it\u2019s a request but no URL. :(",
  "id" : 701059225783508992,
  "in_reply_to_status_id" : 701058510763773952,
  "created_at" : "2016-02-20 15:01:59 +0000",
  "in_reply_to_screen_name" : "mzelst",
  "in_reply_to_user_id_str" : "98975049",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marino van Zelst",
      "screen_name" : "mzelst",
      "indices" : [ 0, 7 ],
      "id_str" : "98975049",
      "id" : 98975049
    }, {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 8, 22 ],
      "id_str" : "352650591",
      "id" : 352650591
    }, {
      "name" : "\u24EA Chris Hartgerink",
      "screen_name" : "chartgerink",
      "indices" : [ 23, 35 ],
      "id_str" : "439273539",
      "id" : 439273539
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "701057695474909184",
  "geo" : { },
  "id_str" : "701058094974033924",
  "in_reply_to_user_id" : 98975049,
  "text" : "@mzelst @Protohedgehog @chartgerink totally get it, but journal\/publisher should be relatively easy to automate using the URLs?",
  "id" : 701058094974033924,
  "in_reply_to_status_id" : 701057695474909184,
  "created_at" : "2016-02-20 14:57:29 +0000",
  "in_reply_to_screen_name" : "mzelst",
  "in_reply_to_user_id_str" : "98975049",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 0, 14 ],
      "id_str" : "352650591",
      "id" : 352650591
    }, {
      "name" : "Marino van Zelst",
      "screen_name" : "mzelst",
      "indices" : [ 15, 22 ],
      "id_str" : "98975049",
      "id" : 98975049
    }, {
      "name" : "\u24EA Chris Hartgerink",
      "screen_name" : "chartgerink",
      "indices" : [ 23, 35 ],
      "id_str" : "439273539",
      "id" : 439273539
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "701055279635496960",
  "geo" : { },
  "id_str" : "701056741094637569",
  "in_reply_to_user_id" : 352650591,
  "text" : "@Protohedgehog @mzelst @chartgerink nice, could you see any trend in which journals\/publishers most often requested? :)",
  "id" : 701056741094637569,
  "in_reply_to_status_id" : 701055279635496960,
  "created_at" : "2016-02-20 14:52:06 +0000",
  "in_reply_to_screen_name" : "Protohedgehog",
  "in_reply_to_user_id_str" : "352650591",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael R. Crusoe",
      "screen_name" : "biocrusoe",
      "indices" : [ 0, 10 ],
      "id_str" : "17645638",
      "id" : 17645638
    }, {
      "name" : "Mozilla Science Lab",
      "screen_name" : "MozillaScience",
      "indices" : [ 51, 66 ],
      "id_str" : "1428575976",
      "id" : 1428575976
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "701050088173531136",
  "geo" : { },
  "id_str" : "701053171481890816",
  "in_reply_to_user_id" : 17645638,
  "text" : "@biocrusoe yes, that\u2019s why I love the efforts that @MozillaScience is putting into training!",
  "id" : 701053171481890816,
  "in_reply_to_status_id" : 701050088173531136,
  "created_at" : "2016-02-20 14:37:55 +0000",
  "in_reply_to_screen_name" : "biocrusoe",
  "in_reply_to_user_id_str" : "17645638",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Titus Brown",
      "screen_name" : "ctitusbrown",
      "indices" : [ 0, 12 ],
      "id_str" : "26616462",
      "id" : 26616462
    }, {
      "name" : "Michael R. Crusoe",
      "screen_name" : "biocrusoe",
      "indices" : [ 13, 23 ],
      "id_str" : "17645638",
      "id" : 17645638
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "701052159765250048",
  "geo" : { },
  "id_str" : "701052447108763648",
  "in_reply_to_user_id" : 26616462,
  "text" : "@ctitusbrown @biocrusoe I think much of it is very informal and not codified, so a similar problem of missing out on lessons.",
  "id" : 701052447108763648,
  "in_reply_to_status_id" : 701052159765250048,
  "created_at" : "2016-02-20 14:35:02 +0000",
  "in_reply_to_screen_name" : "ctitusbrown",
  "in_reply_to_user_id_str" : "26616462",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael R. Crusoe",
      "screen_name" : "biocrusoe",
      "indices" : [ 0, 10 ],
      "id_str" : "17645638",
      "id" : 17645638
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "701047934729789440",
  "geo" : { },
  "id_str" : "701048953572298752",
  "in_reply_to_user_id" : 17645638,
  "text" : "@biocrusoe in so many respects it\u2019s not even a thing for traditional people in academia\u2026 :(",
  "id" : 701048953572298752,
  "in_reply_to_status_id" : 701047934729789440,
  "created_at" : "2016-02-20 14:21:10 +0000",
  "in_reply_to_screen_name" : "biocrusoe",
  "in_reply_to_user_id_str" : "17645638",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael R. Crusoe",
      "screen_name" : "biocrusoe",
      "indices" : [ 3, 13 ],
      "id_str" : "17645638",
      "id" : 17645638
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "701048845711630338",
  "text" : "RT @biocrusoe: Career coaching for non-traditional people in academia; is this a thing?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "701047934729789440",
    "text" : "Career coaching for non-traditional people in academia; is this a thing?",
    "id" : 701047934729789440,
    "created_at" : "2016-02-20 14:17:07 +0000",
    "user" : {
      "name" : "Michael R. Crusoe",
      "screen_name" : "biocrusoe",
      "protected" : false,
      "id_str" : "17645638",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/485998749311721472\/0yX4CFRV_normal.jpeg",
      "id" : 17645638,
      "verified" : false
    }
  },
  "id" : 701048845711630338,
  "created_at" : "2016-02-20 14:20:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Schawinski",
      "screen_name" : "kevinschawinski",
      "indices" : [ 0, 16 ],
      "id_str" : "242844365",
      "id" : 242844365
    }, {
      "name" : "23andMe",
      "screen_name" : "23andMe",
      "indices" : [ 17, 25 ],
      "id_str" : "14738561",
      "id" : 14738561
    }, {
      "name" : "Ernst Hafen",
      "screen_name" : "ehafen",
      "indices" : [ 26, 33 ],
      "id_str" : "159891548",
      "id" : 159891548
    }, {
      "name" : "Effy Vayena",
      "screen_name" : "EffyVayena",
      "indices" : [ 34, 45 ],
      "id_str" : "397518511",
      "id" : 397518511
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "701044223945080832",
  "geo" : { },
  "id_str" : "701044614569054208",
  "in_reply_to_user_id" : 242844365,
  "text" : "@kevinschawinski @23andMe @ehafen @EffyVayena awesome, let me know how it goes!",
  "id" : 701044614569054208,
  "in_reply_to_status_id" : 701044223945080832,
  "created_at" : "2016-02-20 14:03:55 +0000",
  "in_reply_to_screen_name" : "kevinschawinski",
  "in_reply_to_user_id_str" : "242844365",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jon hendren, pleasant genious with a heart of gold",
      "screen_name" : "fart",
      "indices" : [ 3, 8 ],
      "id_str" : "14166714",
      "id" : 14166714
    }, {
      "name" : "talia jane (@jack loves white supremacy & nazis)",
      "screen_name" : "itsa_talia",
      "indices" : [ 20, 31 ],
      "id_str" : "173774813",
      "id" : 173774813
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "701044193708351488",
  "text" : "RT @fart: my friend @itsa_talia wrote a letter to her CEO at Yelp asking for a living wage for employees. so he fired her. https:\/\/t.co\/tmK\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "talia jane (@jack loves white supremacy & nazis)",
        "screen_name" : "itsa_talia",
        "indices" : [ 10, 21 ],
        "id_str" : "173774813",
        "id" : 173774813
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/tmK0JVB5yh",
        "expanded_url" : "https:\/\/medium.com\/@taliajane\/an-open-letter-to-my-ceo-fb73df021e7a#.dpesmp4rf",
        "display_url" : "medium.com\/@taliajane\/an-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "700850837887660033",
    "text" : "my friend @itsa_talia wrote a letter to her CEO at Yelp asking for a living wage for employees. so he fired her. https:\/\/t.co\/tmK0JVB5yh",
    "id" : 700850837887660033,
    "created_at" : "2016-02-20 01:13:55 +0000",
    "user" : {
      "name" : "jon hendren, pleasant genious with a heart of gold",
      "screen_name" : "fart",
      "protected" : false,
      "id_str" : "14166714",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/630260024602816513\/Sz3ovdo3_normal.jpg",
      "id" : 14166714,
      "verified" : true
    }
  },
  "id" : 701044193708351488,
  "created_at" : "2016-02-20 14:02:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "701031559869009920",
  "geo" : { },
  "id_str" : "701031625287671815",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer AUS, you\u2019ve got to love it! :D",
  "id" : 701031625287671815,
  "in_reply_to_status_id" : 701031559869009920,
  "created_at" : "2016-02-20 13:12:18 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 75, 84 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "quantifiedself",
      "indices" : [ 97, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/cwyNuL21qi",
      "expanded_url" : "http:\/\/gedankenstuecke.github.io\/visualize-geolocations\/",
      "display_url" : "gedankenstuecke.github.io\/visualize-geol\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "701031434933374985",
  "text" : "I\u2019ve written up a bit on how to visualize your Twitter\/Swarm data. I blame @eramirez, your turn. #quantifiedself https:\/\/t.co\/cwyNuL21qi",
  "id" : 701031434933374985,
  "created_at" : "2016-02-20 13:11:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "700996087495036929",
  "geo" : { },
  "id_str" : "701005396257992705",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer is it poisonous or venomous? :D",
  "id" : 701005396257992705,
  "in_reply_to_status_id" : 700996087495036929,
  "created_at" : "2016-02-20 11:28:05 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Weber",
      "screen_name" : "scy",
      "indices" : [ 0, 4 ],
      "id_str" : "8308632",
      "id" : 8308632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "700992673033932801",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11404846043467, 8.753459155535179 ]
  },
  "id_str" : "700993037795794944",
  "in_reply_to_user_id" : 8308632,
  "text" : "@scy klar, wenn du daf\u00FCr nicht mehr so tust als w\u00E4re Feminismus daf\u00FCr da um Frauen aufzurei\u00DFen.",
  "id" : 700993037795794944,
  "in_reply_to_status_id" : 700992673033932801,
  "created_at" : "2016-02-20 10:38:58 +0000",
  "in_reply_to_screen_name" : "scy",
  "in_reply_to_user_id_str" : "8308632",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Weber",
      "screen_name" : "scy",
      "indices" : [ 0, 4 ],
      "id_str" : "8308632",
      "id" : 8308632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "700991464524931074",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11403578135479, 8.753330296804076 ]
  },
  "id_str" : "700991604233019392",
  "in_reply_to_user_id" : 8308632,
  "text" : "@scy cool, Mr. Dudebro.",
  "id" : 700991604233019392,
  "in_reply_to_status_id" : 700991464524931074,
  "created_at" : "2016-02-20 10:33:16 +0000",
  "in_reply_to_screen_name" : "scy",
  "in_reply_to_user_id_str" : "8308632",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Weber",
      "screen_name" : "scy",
      "indices" : [ 0, 4 ],
      "id_str" : "8308632",
      "id" : 8308632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "700847950302474241",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11402917285887, 8.753420920651902 ]
  },
  "id_str" : "700991057526464513",
  "in_reply_to_user_id" : 8308632,
  "text" : "@scy ist das die deutsche Version von \u2018Bitches Love Feminism\u2019? m(",
  "id" : 700991057526464513,
  "in_reply_to_status_id" : 700847950302474241,
  "created_at" : "2016-02-20 10:31:06 +0000",
  "in_reply_to_screen_name" : "scy",
  "in_reply_to_user_id_str" : "8308632",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nazeefa",
      "screen_name" : "NazeefaFatima",
      "indices" : [ 3, 17 ],
      "id_str" : "37054704",
      "id" : 37054704
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "700954416673910784",
  "text" : "RT @NazeefaFatima: lol just noticed, the article was published in 2008! BORING!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "700927144080371712",
    "geo" : { },
    "id_str" : "700933688020889600",
    "in_reply_to_user_id" : 37054704,
    "text" : "lol just noticed, the article was published in 2008! BORING!",
    "id" : 700933688020889600,
    "in_reply_to_status_id" : 700927144080371712,
    "created_at" : "2016-02-20 06:43:08 +0000",
    "in_reply_to_screen_name" : "NazeefaFatima",
    "in_reply_to_user_id_str" : "37054704",
    "user" : {
      "name" : "Nazeefa",
      "screen_name" : "NazeefaFatima",
      "protected" : false,
      "id_str" : "37054704",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/930210077885202432\/DY8D8hGM_normal.jpg",
      "id" : 37054704,
      "verified" : false
    }
  },
  "id" : 700954416673910784,
  "created_at" : "2016-02-20 08:05:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nazeefa",
      "screen_name" : "NazeefaFatima",
      "indices" : [ 3, 17 ],
      "id_str" : "37054704",
      "id" : 37054704
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "singlelife",
      "indices" : [ 122, 133 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/DIYTA9fvRy",
      "expanded_url" : "http:\/\/www.reuters.com\/article\/us-housework-husbands-idUSN0441782220080404",
      "display_url" : "reuters.com\/article\/us-hou\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "700954323610640384",
  "text" : "RT @NazeefaFatima: \uD83D\uDE01\uD83D\uDE2A Having a husband creates seven hours of extra housework a week for women !! https:\/\/t.co\/DIYTA9fvRy #singlelife #fore\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Ladan Doroud",
        "screen_name" : "ldoroud",
        "indices" : [ 132, 140 ],
        "id_str" : "258971278",
        "id" : 258971278
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "singlelife",
        "indices" : [ 103, 114 ]
      }, {
        "text" : "foreveralone",
        "indices" : [ 115, 128 ]
      } ],
      "urls" : [ {
        "indices" : [ 79, 102 ],
        "url" : "https:\/\/t.co\/DIYTA9fvRy",
        "expanded_url" : "http:\/\/www.reuters.com\/article\/us-housework-husbands-idUSN0441782220080404",
        "display_url" : "reuters.com\/article\/us-hou\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "700927144080371712",
    "text" : "\uD83D\uDE01\uD83D\uDE2A Having a husband creates seven hours of extra housework a week for women !! https:\/\/t.co\/DIYTA9fvRy #singlelife #foreveralone HT @ldoroud",
    "id" : 700927144080371712,
    "created_at" : "2016-02-20 06:17:08 +0000",
    "user" : {
      "name" : "Nazeefa",
      "screen_name" : "NazeefaFatima",
      "protected" : false,
      "id_str" : "37054704",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/930210077885202432\/DY8D8hGM_normal.jpg",
      "id" : 37054704,
      "verified" : false
    }
  },
  "id" : 700954323610640384,
  "created_at" : "2016-02-20 08:05:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "beau",
      "screen_name" : "beaugunderson",
      "indices" : [ 0, 14 ],
      "id_str" : "5746882",
      "id" : 5746882
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 15, 28 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "700913853782106112",
  "geo" : { },
  "id_str" : "700953858013532161",
  "in_reply_to_user_id" : 5746882,
  "text" : "@beaugunderson @PhilippBayer thanks, I love those contributions. Also fixing our bad english is much appreciated when you stumble over it :D",
  "id" : 700953858013532161,
  "in_reply_to_status_id" : 700913853782106112,
  "created_at" : "2016-02-20 08:03:17 +0000",
  "in_reply_to_screen_name" : "beaugunderson",
  "in_reply_to_user_id_str" : "5746882",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/ot1GQmvqBk",
      "expanded_url" : "https:\/\/twitter.com\/eramirez\/status\/700825685699403776",
      "display_url" : "twitter.com\/eramirez\/statu\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11405077713151, 8.753428838238055 ]
  },
  "id_str" : "700950288061038592",
  "text" : "\u00ABthis dismissal of our humanity by a journalist amplifies our daily risk of harm.\u00BB https:\/\/t.co\/ot1GQmvqBk",
  "id" : 700950288061038592,
  "created_at" : "2016-02-20 07:49:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "700851552408342529",
  "geo" : { },
  "id_str" : "700851662865436673",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez thanks, oh QS grandmaster! \uD83D\uDE1B",
  "id" : 700851662865436673,
  "in_reply_to_status_id" : 700851552408342529,
  "created_at" : "2016-02-20 01:17:12 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "700850248579551232",
  "geo" : { },
  "id_str" : "700851474885115904",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez yes, but I will try to get some \uD83D\uDCA4 first \uD83D\uDE09",
  "id" : 700851474885115904,
  "in_reply_to_status_id" : 700850248579551232,
  "created_at" : "2016-02-20 01:16:27 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "700849973651374080",
  "geo" : { },
  "id_str" : "700850143092994048",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez yes! I have a huge backlog of things I\u2019d like to talk a bit more about",
  "id" : 700850143092994048,
  "in_reply_to_status_id" : 700849973651374080,
  "created_at" : "2016-02-20 01:11:09 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/BAsoEXU9XB",
      "expanded_url" : "http:\/\/gedankenstuecke.github.io\/",
      "display_url" : "gedankenstuecke.github.io"
    } ]
  },
  "geo" : { },
  "id_str" : "700845573834981376",
  "text" : "Went from super tired to being unable to fall asleep. At least I used the time to get rid of aboutme, using Jekyll. https:\/\/t.co\/BAsoEXU9XB",
  "id" : 700845573834981376,
  "created_at" : "2016-02-20 00:53:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fressesprecher",
      "screen_name" : "Bediko",
      "indices" : [ 0, 7 ],
      "id_str" : "56530362",
      "id" : 56530362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "700690033733410816",
  "geo" : { },
  "id_str" : "700690198406025216",
  "in_reply_to_user_id" : 56530362,
  "text" : "@Bediko mir auch o_O",
  "id" : 700690198406025216,
  "in_reply_to_status_id" : 700690033733410816,
  "created_at" : "2016-02-19 14:35:36 +0000",
  "in_reply_to_screen_name" : "Bediko",
  "in_reply_to_user_id_str" : "56530362",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Titus Brown",
      "screen_name" : "ctitusbrown",
      "indices" : [ 0, 12 ],
      "id_str" : "26616462",
      "id" : 26616462
    }, {
      "name" : "Trialect",
      "screen_name" : "Trialect",
      "indices" : [ 13, 22 ],
      "id_str" : "1360557960",
      "id" : 1360557960
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "700687336313466881",
  "geo" : { },
  "id_str" : "700687456706936832",
  "in_reply_to_user_id" : 26616462,
  "text" : "@ctitusbrown @Trialect yes, same  here. And no idea what this is.",
  "id" : 700687456706936832,
  "in_reply_to_status_id" : 700687336313466881,
  "created_at" : "2016-02-19 14:24:42 +0000",
  "in_reply_to_screen_name" : "ctitusbrown",
  "in_reply_to_user_id_str" : "26616462",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 73 ],
      "url" : "https:\/\/t.co\/m39SQiRdRn",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=kDAKBzFFa6U",
      "display_url" : "youtube.com\/watch?v=kDAKBz\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "700646887032885249",
  "text" : "the axis of awesome, staying true to their name \uD83D\uDC96 https:\/\/t.co\/m39SQiRdRn",
  "id" : 700646887032885249,
  "created_at" : "2016-02-19 11:43:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 14, 26 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "700646556920209409",
  "geo" : { },
  "id_str" : "700646718535172096",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @helgerausch our cluster has shared directories all around, so I have one for the work-environment &amp; local on my notebook.",
  "id" : 700646718535172096,
  "in_reply_to_status_id" : 700646556920209409,
  "created_at" : "2016-02-19 11:42:49 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 14, 26 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "700643772225363968",
  "geo" : { },
  "id_str" : "700644570162290689",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @helgerausch I\u2019m using per-directory histories, helps with that :)",
  "id" : 700644570162290689,
  "in_reply_to_status_id" : 700643772225363968,
  "created_at" : "2016-02-19 11:34:17 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "700640037138894849",
  "geo" : { },
  "id_str" : "700644482631335937",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer ah, i got two because of my weird status: one student ID, one staff ID.",
  "id" : 700644482631335937,
  "in_reply_to_status_id" : 700640037138894849,
  "created_at" : "2016-02-19 11:33:56 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "700634308453609472",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17840848381402, 8.625744829414037 ]
  },
  "id_str" : "700637423957454852",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer that\u2019s why I have 2 of those keycards :D",
  "id" : 700637423957454852,
  "in_reply_to_status_id" : 700634308453609472,
  "created_at" : "2016-02-19 11:05:53 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 67 ],
      "url" : "https:\/\/t.co\/bNoDtCrjw4",
      "expanded_url" : "http:\/\/andromedayelton.com\/2016\/02\/18\/analyzing-the-ruby-community-conduct-guideline\/",
      "display_url" : "andromedayelton.com\/2016\/02\/18\/ana\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "700633145297637379",
  "text" : "Analyzing the terrible Ruby Code of Conduct https:\/\/t.co\/bNoDtCrjw4",
  "id" : 700633145297637379,
  "created_at" : "2016-02-19 10:48:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 47 ],
      "url" : "https:\/\/t.co\/FhyKLfsdCe",
      "expanded_url" : "http:\/\/boingboing.net\/2016\/02\/18\/tiny-snail-swims-like-a-bee-fl.html",
      "display_url" : "boingboing.net\/2016\/02\/18\/tin\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "700629025182449664",
  "text" : "underwater snail flight https:\/\/t.co\/FhyKLfsdCe",
  "id" : 700629025182449664,
  "created_at" : "2016-02-19 10:32:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 13, 26 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "700581036292444161",
  "geo" : { },
  "id_str" : "700622884637696000",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch @PhilippBayer people look at me funny when I suggest using awk for a given task :D",
  "id" : 700622884637696000,
  "in_reply_to_status_id" : 700581036292444161,
  "created_at" : "2016-02-19 10:08:07 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 69 ],
      "url" : "https:\/\/t.co\/0DfpyAxO2R",
      "expanded_url" : "http:\/\/rack.0.mshcdn.com\/media\/ZgkyMDEzLzA4LzA1L2QwL2JyYWRwaXR0LmJjMmQyLmdpZgpwCXRodW1iCTg1MHg4NTA-CmUJanBn\/47ac6804\/968\/brad-pitt.jpg",
      "display_url" : "rack.0.mshcdn.com\/media\/ZgkyMDEz\u2026"
    }, {
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/A38S8k2xef",
      "expanded_url" : "https:\/\/twitter.com\/rauchg\/status\/700428162191101952",
      "display_url" : "twitter.com\/rauchg\/status\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "700602895201411072",
  "text" : "Inline, animated gifs in your terminal? Sold! https:\/\/t.co\/0DfpyAxO2R https:\/\/t.co\/A38S8k2xef",
  "id" : 700602895201411072,
  "created_at" : "2016-02-19 08:48:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "scott",
      "screen_name" : "sckottie",
      "indices" : [ 3, 12 ],
      "id_str" : "103004948",
      "id" : 103004948
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "700475286513721345",
  "text" : "RT @sckottie: anyone know anyone at NCBI Entrez team?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "700473281816625152",
    "text" : "anyone know anyone at NCBI Entrez team?",
    "id" : 700473281816625152,
    "created_at" : "2016-02-19 00:13:39 +0000",
    "user" : {
      "name" : "scott",
      "screen_name" : "sckottie",
      "protected" : false,
      "id_str" : "103004948",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/806575041135726593\/tnm7p6Zp_normal.jpg",
      "id" : 103004948,
      "verified" : false
    }
  },
  "id" : 700475286513721345,
  "created_at" : "2016-02-19 00:21:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mrgunn",
      "screen_name" : "mrgunn",
      "indices" : [ 0, 7 ],
      "id_str" : "15237935",
      "id" : 15237935
    }, {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 8, 17 ],
      "id_str" : "14245811",
      "id" : 14245811
    }, {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 18, 27 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "700470378460676096",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0608010815543, 8.818657104426244 ]
  },
  "id_str" : "700470718312669184",
  "in_reply_to_user_id" : 15237935,
  "text" : "@mrgunn @wilbanks @eramirez by now it assumes the # of correct answers is just a function of how close to SF you live ;)",
  "id" : 700470718312669184,
  "in_reply_to_status_id" : 700470378460676096,
  "created_at" : "2016-02-19 00:03:28 +0000",
  "in_reply_to_screen_name" : "mrgunn",
  "in_reply_to_user_id_str" : "15237935",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 0, 9 ],
      "id_str" : "14245811",
      "id" : 14245811
    }, {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 10, 19 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "700468327441899520",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.060835836251, 8.818400334317134 ]
  },
  "id_str" : "700470476238409729",
  "in_reply_to_user_id" : 14245811,
  "text" : "@wilbanks @eramirez makes me wish that all these companies fail even faster than they will anyhow.",
  "id" : 700470476238409729,
  "in_reply_to_status_id" : 700468327441899520,
  "created_at" : "2016-02-19 00:02:30 +0000",
  "in_reply_to_screen_name" : "wilbanks",
  "in_reply_to_user_id_str" : "14245811",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "700467576556490753",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0607642487335, 8.818421840782714 ]
  },
  "id_str" : "700467990790336512",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez only got Graham and the Tinder one right.",
  "id" : 700467990790336512,
  "in_reply_to_status_id" : 700467576556490753,
  "created_at" : "2016-02-18 23:52:37 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/f9UrO6zome",
      "expanded_url" : "https:\/\/twitter.com\/genetics_blog\/status\/700345697078480896",
      "display_url" : "twitter.com\/genetics_blog\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0607642487335, 8.818421840782714 ]
  },
  "id_str" : "700467790449418240",
  "text" : "Pascal -&gt; Perl -&gt; PHP, after that you might want to quit programming forever. https:\/\/t.co\/f9UrO6zome",
  "id" : 700467790449418240,
  "created_at" : "2016-02-18 23:51:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/YHYOTbydIa",
      "expanded_url" : "https:\/\/twitter.com\/juliacarriew\/status\/700432046766845953",
      "display_url" : "twitter.com\/juliacarriew\/s\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06096114607539, 8.818602434605372 ]
  },
  "id_str" : "700466499794776064",
  "text" : "2\/8, basically as good as chance. Advanced enough awfulness is indistinguishable from satire. https:\/\/t.co\/YHYOTbydIa",
  "id" : 700466499794776064,
  "created_at" : "2016-02-18 23:46:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06092374111628, 8.818442594360574 ]
  },
  "id_str" : "700441881163993088",
  "text" : "\u00ABFrom a certain angle the architecture looks very much like the house of Usher.\u00BB Tempted to answer \u2018Dunno, I don\u2019t watch MTV Cribs\u2019.",
  "id" : 700441881163993088,
  "created_at" : "2016-02-18 22:08:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "beau",
      "screen_name" : "beaugunderson",
      "indices" : [ 0, 14 ],
      "id_str" : "5746882",
      "id" : 5746882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "700438593488101376",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0609789411659, 8.818562465382277 ]
  },
  "id_str" : "700439041012006917",
  "in_reply_to_user_id" : 5746882,
  "text" : "@beaugunderson aye, that\u2019s why I do both.",
  "id" : 700439041012006917,
  "in_reply_to_status_id" : 700438593488101376,
  "created_at" : "2016-02-18 21:57:35 +0000",
  "in_reply_to_screen_name" : "beaugunderson",
  "in_reply_to_user_id_str" : "5746882",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 66 ],
      "url" : "https:\/\/t.co\/tZkv29UupB",
      "expanded_url" : "https:\/\/twitter.com\/rasbt\/status\/700084383974367233",
      "display_url" : "twitter.com\/rasbt\/status\/7\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06079345844306, 8.818626178715975 ]
  },
  "id_str" : "700434759252574209",
  "text" : "I should put this up in my office as well. https:\/\/t.co\/tZkv29UupB",
  "id" : 700434759252574209,
  "created_at" : "2016-02-18 21:40:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "li5a",
      "screen_name" : "li5a",
      "indices" : [ 0, 5 ],
      "id_str" : "11712822",
      "id" : 11712822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "700369648055885824",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17661016387008, 8.63007672620801 ]
  },
  "id_str" : "700376313266364416",
  "in_reply_to_user_id" : 11712822,
  "text" : "@li5a I thought &lt;table&gt; and didn\u2019t get me being wrong at first, because those collapse just as easily. m)",
  "id" : 700376313266364416,
  "in_reply_to_status_id" : 700369648055885824,
  "created_at" : "2016-02-18 17:48:20 +0000",
  "in_reply_to_screen_name" : "li5a",
  "in_reply_to_user_id_str" : "11712822",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 75 ],
      "url" : "https:\/\/t.co\/xZodqt8gim",
      "expanded_url" : "https:\/\/student.societyforscience.org\/article\/roadkill-learning-dead",
      "display_url" : "student.societyforscience.org\/article\/roadki\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "700348916080967685",
  "text" : "Project Splatter et al.: How to learn from roadkill https:\/\/t.co\/xZodqt8gim",
  "id" : 700348916080967685,
  "created_at" : "2016-02-18 15:59:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/vcPmHZr3OH",
      "expanded_url" : "https:\/\/twitter.com\/ThePoke\/status\/700334111626383360",
      "display_url" : "twitter.com\/ThePoke\/status\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "700347104854728704",
  "text" : "What I will use from now on when asked to spell my last name (i.e. every single time I say it). https:\/\/t.co\/vcPmHZr3OH",
  "id" : 700347104854728704,
  "created_at" : "2016-02-18 15:52:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 0, 9 ],
      "id_str" : "14245811",
      "id" : 14245811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "700333203081584640",
  "geo" : { },
  "id_str" : "700345755756818433",
  "in_reply_to_user_id" : 14245811,
  "text" : "@wilbanks \u201Eyou know how some of you never want to share toys with others, even though you don\u2019t play with them? same difference!\u201C",
  "id" : 700345755756818433,
  "in_reply_to_status_id" : 700333203081584640,
  "created_at" : "2016-02-18 15:46:54 +0000",
  "in_reply_to_screen_name" : "wilbanks",
  "in_reply_to_user_id_str" : "14245811",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 76 ],
      "url" : "https:\/\/t.co\/xA3i7E1gu5",
      "expanded_url" : "http:\/\/i.imgur.com\/yuaiYSt.gifv",
      "display_url" : "i.imgur.com\/yuaiYSt.gifv"
    } ]
  },
  "geo" : { },
  "id_str" : "700343383554985984",
  "text" : "coming into the office and everyone wants your help. https:\/\/t.co\/xA3i7E1gu5",
  "id" : 700343383554985984,
  "created_at" : "2016-02-18 15:37:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mathilde Cordellier",
      "screen_name" : "m_cordellier",
      "indices" : [ 0, 13 ],
      "id_str" : "3373710875",
      "id" : 3373710875
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "700321966918647808",
  "geo" : { },
  "id_str" : "700343032319754240",
  "in_reply_to_user_id" : 3373710875,
  "text" : "@m_cordellier \uD83D\uDC3F? ;)",
  "id" : 700343032319754240,
  "in_reply_to_status_id" : 700321966918647808,
  "created_at" : "2016-02-18 15:36:05 +0000",
  "in_reply_to_screen_name" : "m_cordellier",
  "in_reply_to_user_id_str" : "3373710875",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "J. Colomb, @pen",
      "screen_name" : "j_colomb",
      "indices" : [ 0, 9 ],
      "id_str" : "9437692",
      "id" : 9437692
    }, {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 10, 24 ],
      "id_str" : "352650591",
      "id" : 352650591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "700310504380723200",
  "geo" : { },
  "id_str" : "700324022605783042",
  "in_reply_to_user_id" : 9437692,
  "text" : "@j_colomb @Protohedgehog @petergrabitz can\u2019t tell yet, will let you know more soon!",
  "id" : 700324022605783042,
  "in_reply_to_status_id" : 700310504380723200,
  "created_at" : "2016-02-18 14:20:33 +0000",
  "in_reply_to_screen_name" : "j_colomb",
  "in_reply_to_user_id_str" : "9437692",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chocho Zhang",
      "screen_name" : "chocho_z",
      "indices" : [ 0, 9 ],
      "id_str" : "3221119766",
      "id" : 3221119766
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "700302994517065728",
  "geo" : { },
  "id_str" : "700303646697857024",
  "in_reply_to_user_id" : 3221119766,
  "text" : "@chocho_z can nature invite me? :p",
  "id" : 700303646697857024,
  "in_reply_to_status_id" : 700302994517065728,
  "created_at" : "2016-02-18 12:59:35 +0000",
  "in_reply_to_screen_name" : "chocho_z",
  "in_reply_to_user_id_str" : "3221119766",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chocho Zhang",
      "screen_name" : "chocho_z",
      "indices" : [ 0, 9 ],
      "id_str" : "3221119766",
      "id" : 3221119766
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "700276311965577216",
  "geo" : { },
  "id_str" : "700292450020126720",
  "in_reply_to_user_id" : 3221119766,
  "text" : "@chocho_z can I also just come for a visit? :P",
  "id" : 700292450020126720,
  "in_reply_to_status_id" : 700276311965577216,
  "created_at" : "2016-02-18 12:15:05 +0000",
  "in_reply_to_screen_name" : "chocho_z",
  "in_reply_to_user_id_str" : "3221119766",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uD83D\uDD25\uD83D\uDC1C\uD83D\uDC78\uD83C\uDFFC",
      "screen_name" : "fireantprincess",
      "indices" : [ 0, 16 ],
      "id_str" : "77216385",
      "id" : 77216385
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "700277546802356226",
  "geo" : { },
  "id_str" : "700292361956540416",
  "in_reply_to_user_id" : 77216385,
  "text" : "@fireantprincess das hat auf jeden Fall priority :)",
  "id" : 700292361956540416,
  "in_reply_to_status_id" : 700277546802356226,
  "created_at" : "2016-02-18 12:14:44 +0000",
  "in_reply_to_screen_name" : "fireantprincess",
  "in_reply_to_user_id_str" : "77216385",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 0, 14 ],
      "id_str" : "352650591",
      "id" : 352650591
    }, {
      "name" : "J. Colomb, @pen",
      "screen_name" : "j_colomb",
      "indices" : [ 15, 24 ],
      "id_str" : "9437692",
      "id" : 9437692
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "700277889372200960",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.16685090677105, 8.624109077144416 ]
  },
  "id_str" : "700279868735561728",
  "in_reply_to_user_id" : 352650591,
  "text" : "@Protohedgehog @j_colomb @petergrabitz no time for that I guess. :D",
  "id" : 700279868735561728,
  "in_reply_to_status_id" : 700277889372200960,
  "created_at" : "2016-02-18 11:25:05 +0000",
  "in_reply_to_screen_name" : "Protohedgehog",
  "in_reply_to_user_id_str" : "352650591",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "annakrystalli",
      "screen_name" : "annakrystalli",
      "indices" : [ 0, 14 ],
      "id_str" : "15090415",
      "id" : 15090415
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "700278388406222848",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.16808174370484, 8.624270589823908 ]
  },
  "id_str" : "700279798657056770",
  "in_reply_to_user_id" : 15090415,
  "text" : "@annakrystalli damn, if I had know I would have stayed a day more. My plane is going out on 9am on 16th. :(",
  "id" : 700279798657056770,
  "in_reply_to_status_id" : 700278388406222848,
  "created_at" : "2016-02-18 11:24:49 +0000",
  "in_reply_to_screen_name" : "annakrystalli",
  "in_reply_to_user_id_str" : "15090415",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uD83D\uDD25\uD83D\uDC1C\uD83D\uDC78\uD83C\uDFFC",
      "screen_name" : "fireantprincess",
      "indices" : [ 0, 16 ],
      "id_str" : "77216385",
      "id" : 77216385
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "700273982893899776",
  "geo" : { },
  "id_str" : "700275807701356544",
  "in_reply_to_user_id" : 77216385,
  "text" : "@fireantprincess yay, das w\u00E4re super, wir haben uns viel zu lange nicht gesehen. \uD83D\uDC93",
  "id" : 700275807701356544,
  "in_reply_to_status_id" : 700273982893899776,
  "created_at" : "2016-02-18 11:08:57 +0000",
  "in_reply_to_screen_name" : "fireantprincess",
  "in_reply_to_user_id_str" : "77216385",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "700273563597717505",
  "geo" : { },
  "id_str" : "700273647282479104",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich erinnere mich mal rechtzeitig dran :)",
  "id" : 700273647282479104,
  "in_reply_to_status_id" : 700273563597717505,
  "created_at" : "2016-02-18 11:00:22 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 108, 121 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/Rz6XAlzHqx",
      "expanded_url" : "https:\/\/hynek.me\/articles\/python3-2016\/",
      "display_url" : "hynek.me\/articles\/pytho\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "700273483494912000",
  "text" : "Interesting as I\u2019m just putting together a small course on Python: Python 3 in 2016 https:\/\/t.co\/Rz6XAlzHqx @PhilippBayer",
  "id" : 700273483494912000,
  "created_at" : "2016-02-18 10:59:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    }, {
      "name" : "Helmholtz",
      "screen_name" : "helmholtz_de",
      "indices" : [ 37, 50 ],
      "id_str" : "95856748",
      "id" : 95856748
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "700271058432172032",
  "geo" : { },
  "id_str" : "700271379791396865",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich whops, das gebe ich mal an @helmholtz_de weiter \uD83D\uDE09",
  "id" : 700271379791396865,
  "in_reply_to_status_id" : 700271058432172032,
  "created_at" : "2016-02-18 10:51:22 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 0, 14 ],
      "id_str" : "352650591",
      "id" : 352650591
    }, {
      "name" : "J. Colomb, @pen",
      "screen_name" : "j_colomb",
      "indices" : [ 15, 24 ],
      "id_str" : "9437692",
      "id" : 9437692
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "700270790651076608",
  "geo" : { },
  "id_str" : "700270969231904768",
  "in_reply_to_user_id" : 352650591,
  "text" : "@Protohedgehog @j_colomb @petergrabitz \u201Ein town, one night only, the infamous Mark Zuckerberg of Open Source Genetics!\u201C",
  "id" : 700270969231904768,
  "in_reply_to_status_id" : 700270790651076608,
  "created_at" : "2016-02-18 10:49:44 +0000",
  "in_reply_to_screen_name" : "Protohedgehog",
  "in_reply_to_user_id_str" : "352650591",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/vRzhm8FHnt",
      "expanded_url" : "http:\/\/www.helmholtz.de\/ueber_uns\/presse_und_medien\/veranstaltungen\/fokushelmholtz\/schneller_hoeher_weiter_der_drang_nach_dem_perfekten_sein\/",
      "display_url" : "helmholtz.de\/ueber_uns\/pres\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "700270282108485632",
  "text" : "So, Berlin, I\u2019ll be in town on March 15th for this (German language) event. Anyone wanna meet up (afterwards)? https:\/\/t.co\/vRzhm8FHnt",
  "id" : 700270282108485632,
  "created_at" : "2016-02-18 10:47:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 57 ],
      "url" : "https:\/\/t.co\/DM0Tdof5Gx",
      "expanded_url" : "http:\/\/www.nytimes.com\/2016\/02\/18\/world\/asia\/china-fast-telescope-guizhou-relocation.html?_r=0",
      "display_url" : "nytimes.com\/2016\/02\/18\/wor\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "700267331071696896",
  "text" : "So China wants to dwarf Arecibo \uD83D\uDE2F https:\/\/t.co\/DM0Tdof5Gx",
  "id" : 700267331071696896,
  "created_at" : "2016-02-18 10:35:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "700263469921267712",
  "text" : "and one more travel grant application sent out. \\o\/",
  "id" : 700263469921267712,
  "created_at" : "2016-02-18 10:19:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "allele: cinnamon winter types",
      "screen_name" : "queertypes",
      "indices" : [ 3, 14 ],
      "id_str" : "284446453",
      "id" : 284446453
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "700098428836188160",
  "text" : "RT @queertypes: The irony:\n\nRuby leadership: \"We'll adopt this pgsql draft. It looks nice.\"\n\nPGSQL: \"On second thought, let's pay experts t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "699973968552337408",
    "geo" : { },
    "id_str" : "699976260433215489",
    "in_reply_to_user_id" : 284446453,
    "text" : "The irony:\n\nRuby leadership: \"We'll adopt this pgsql draft. It looks nice.\"\n\nPGSQL: \"On second thought, let's pay experts to help us w\/ CoC\"",
    "id" : 699976260433215489,
    "in_reply_to_status_id" : 699973968552337408,
    "created_at" : "2016-02-17 15:18:40 +0000",
    "in_reply_to_screen_name" : "queertypes",
    "in_reply_to_user_id_str" : "284446453",
    "user" : {
      "name" : "allele: cinnamon winter types",
      "screen_name" : "queertypes",
      "protected" : false,
      "id_str" : "284446453",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/930708196485935104\/ZPrFDhph_normal.jpg",
      "id" : 284446453,
      "verified" : false
    }
  },
  "id" : 700098428836188160,
  "created_at" : "2016-02-17 23:24:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mrgunn",
      "screen_name" : "mrgunn",
      "indices" : [ 0, 7 ],
      "id_str" : "15237935",
      "id" : 15237935
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "700089504422440965",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11402117411696, 8.753410090302225 ]
  },
  "id_str" : "700089871336153089",
  "in_reply_to_user_id" : 15237935,
  "text" : "@mrgunn as it stands now in so many instances you just pay for the branding and there's zero other service provided.",
  "id" : 700089871336153089,
  "in_reply_to_status_id" : 700089504422440965,
  "created_at" : "2016-02-17 22:50:07 +0000",
  "in_reply_to_screen_name" : "mrgunn",
  "in_reply_to_user_id_str" : "15237935",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mrgunn",
      "screen_name" : "mrgunn",
      "indices" : [ 0, 7 ],
      "id_str" : "15237935",
      "id" : 15237935
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "700088608082907137",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11402301651885, 8.753413755968193 ]
  },
  "id_str" : "700089130164813825",
  "in_reply_to_user_id" : 15237935,
  "text" : "@mrgunn last time I checked there were tons of non-OA publishers that didn't provide any CE.",
  "id" : 700089130164813825,
  "in_reply_to_status_id" : 700088608082907137,
  "created_at" : "2016-02-17 22:47:10 +0000",
  "in_reply_to_screen_name" : "mrgunn",
  "in_reply_to_user_id_str" : "15237935",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "My Cousin Amygdala",
      "screen_name" : "CousinAmygdala",
      "indices" : [ 0, 15 ],
      "id_str" : "1733777587",
      "id" : 1733777587
    }, {
      "name" : "mrgunn",
      "screen_name" : "mrgunn",
      "indices" : [ 16, 23 ],
      "id_str" : "15237935",
      "id" : 15237935
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "700088128393060352",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11402301651885, 8.753413755968193 ]
  },
  "id_str" : "700088435055452161",
  "in_reply_to_user_id" : 1733777587,
  "text" : "@CousinAmygdala @mrgunn lol, that must be one of the worst reasons to keep scientific publishers around :D",
  "id" : 700088435055452161,
  "in_reply_to_status_id" : 700088128393060352,
  "created_at" : "2016-02-17 22:44:24 +0000",
  "in_reply_to_screen_name" : "CousinAmygdala",
  "in_reply_to_user_id_str" : "1733777587",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mrgunn",
      "screen_name" : "mrgunn",
      "indices" : [ 0, 7 ],
      "id_str" : "15237935",
      "id" : 15237935
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "700086188925816832",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11402301651885, 8.753413755968193 ]
  },
  "id_str" : "700087898805301248",
  "in_reply_to_user_id" : 15237935,
  "text" : "@mrgunn what professional services would that be?",
  "id" : 700087898805301248,
  "in_reply_to_status_id" : 700086188925816832,
  "created_at" : "2016-02-17 22:42:16 +0000",
  "in_reply_to_screen_name" : "mrgunn",
  "in_reply_to_user_id_str" : "15237935",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "700086535987838978",
  "text" : "I really should have read the brew message a bit more closely. I think I\u2019m now accidentally compiling haskell m)",
  "id" : 700086535987838978,
  "created_at" : "2016-02-17 22:36:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 121, 144 ],
      "url" : "https:\/\/t.co\/rgf0BPyQlC",
      "expanded_url" : "https:\/\/thescienceweb.wordpress.com\/2016\/02\/17\/preprints-definitely-shit-say-publishers\/",
      "display_url" : "thescienceweb.wordpress.com\/2016\/02\/17\/pre\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "700067498503360513",
  "text" : "Academic publishing \u00ABa system so perfectly controlling &amp; exploitative that even the Catholic church have praised it\u00BB https:\/\/t.co\/rgf0BPyQlC",
  "id" : 700067498503360513,
  "created_at" : "2016-02-17 21:21:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "700057306390786048",
  "text" : "Vegan Malabi is a full dinner, right?",
  "id" : 700057306390786048,
  "created_at" : "2016-02-17 20:40:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Brechler",
      "screen_name" : "gutsle",
      "indices" : [ 0, 7 ],
      "id_str" : "837535866",
      "id" : 837535866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "699999659381649409",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17533380766393, 8.628544408657715 ]
  },
  "id_str" : "700030381316313088",
  "in_reply_to_user_id" : 837535866,
  "text" : "@gutsle der gl\u00E4serne Volksempf\u00E4nger?",
  "id" : 700030381316313088,
  "in_reply_to_status_id" : 699999659381649409,
  "created_at" : "2016-02-17 18:53:43 +0000",
  "in_reply_to_screen_name" : "gutsle",
  "in_reply_to_user_id_str" : "837535866",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Brechler",
      "screen_name" : "plaetzchen",
      "indices" : [ 12, 23 ],
      "id_str" : "14305613",
      "id" : 14305613
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 24, 30 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 65 ],
      "url" : "https:\/\/t.co\/apGqRhA5dS",
      "expanded_url" : "https:\/\/twitter.com\/mozillafestival\/status\/699994857079709696",
      "display_url" : "twitter.com\/mozillafestiva\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17588987618061, 8.631651150107134 ]
  },
  "id_str" : "700029984077910018",
  "text" : "Absolutely! @plaetzchen @Lobot you\u2019re in? https:\/\/t.co\/apGqRhA5dS",
  "id" : 700029984077910018,
  "created_at" : "2016-02-17 18:52:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Stajich",
      "screen_name" : "hyphaltip",
      "indices" : [ 0, 10 ],
      "id_str" : "14324284",
      "id" : 14324284
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "700016970716942336",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17660675101169, 8.630072403615836 ]
  },
  "id_str" : "700017782545629184",
  "in_reply_to_user_id" : 14324284,
  "text" : "@hyphaltip and of course it\u2019s all GMO free I assume?",
  "id" : 700017782545629184,
  "in_reply_to_status_id" : 700016970716942336,
  "created_at" : "2016-02-17 18:03:39 +0000",
  "in_reply_to_screen_name" : "hyphaltip",
  "in_reply_to_user_id_str" : "14324284",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Turner",
      "screen_name" : "genetics_blog",
      "indices" : [ 0, 14 ],
      "id_str" : "923639552874557440",
      "id" : 923639552874557440
    }, {
      "name" : "E. Ari\u00F1o de la Rubia",
      "screen_name" : "earino",
      "indices" : [ 38, 45 ],
      "id_str" : "4022411",
      "id" : 4022411
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "699956243029430272",
  "geo" : { },
  "id_str" : "699956852025597952",
  "in_reply_to_user_id" : 20444825,
  "text" : "@genetics_blog I like the idea, maybe @earino can extend his idea to that? :)",
  "id" : 699956852025597952,
  "in_reply_to_status_id" : 699956243029430272,
  "created_at" : "2016-02-17 14:01:32 +0000",
  "in_reply_to_screen_name" : "strnr",
  "in_reply_to_user_id_str" : "20444825",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Turner",
      "screen_name" : "genetics_blog",
      "indices" : [ 0, 14 ],
      "id_str" : "923639552874557440",
      "id" : 923639552874557440
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 38 ],
      "url" : "https:\/\/t.co\/DpweBjikgl",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/699156065917792256",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "699955172253036544",
  "geo" : { },
  "id_str" : "699955990586900480",
  "in_reply_to_user_id" : 20444825,
  "text" : "@genetics_blog https:\/\/t.co\/DpweBjikgl :)",
  "id" : 699955990586900480,
  "in_reply_to_status_id" : 699955172253036544,
  "created_at" : "2016-02-17 13:58:07 +0000",
  "in_reply_to_screen_name" : "strnr",
  "in_reply_to_user_id_str" : "20444825",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 56 ],
      "url" : "https:\/\/t.co\/9pNvtoPeem",
      "expanded_url" : "https:\/\/media.giphy.com\/media\/l41lPaVXzvGGMuAQ8\/giphy.gif",
      "display_url" : "media.giphy.com\/media\/l41lPaVX\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "699948212761862144",
  "text" : "describe science in a single gif https:\/\/t.co\/9pNvtoPeem",
  "id" : 699948212761862144,
  "created_at" : "2016-02-17 13:27:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Heather L. Wiencko",
      "screen_name" : "HLWiencko",
      "indices" : [ 3, 13 ],
      "id_str" : "2657942712",
      "id" : 2657942712
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 15, 31 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "699917714043887616",
  "text" : "RT @HLWiencko: @gedankenstuecke Reminds me of Google\u2019s Summer of Code, which I can only assume precedes the Autumn of Bugfixes.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 0, 16 ],
        "id_str" : "14286491",
        "id" : 14286491
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "699914077192245248",
    "geo" : { },
    "id_str" : "699917492450430977",
    "in_reply_to_user_id" : 14286491,
    "text" : "@gedankenstuecke Reminds me of Google\u2019s Summer of Code, which I can only assume precedes the Autumn of Bugfixes.",
    "id" : 699917492450430977,
    "in_reply_to_status_id" : 699914077192245248,
    "created_at" : "2016-02-17 11:25:08 +0000",
    "in_reply_to_screen_name" : "gedankenstuecke",
    "in_reply_to_user_id_str" : "14286491",
    "user" : {
      "name" : "Heather L. Wiencko",
      "screen_name" : "HLWiencko",
      "protected" : false,
      "id_str" : "2657942712",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/490274907117215746\/GBit7UNq_normal.jpeg",
      "id" : 2657942712,
      "verified" : false
    }
  },
  "id" : 699917714043887616,
  "created_at" : "2016-02-17 11:26:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Stajich",
      "screen_name" : "hyphaltip",
      "indices" : [ 0, 10 ],
      "id_str" : "14324284",
      "id" : 14324284
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "699884135284736001",
  "geo" : { },
  "id_str" : "699914292498456576",
  "in_reply_to_user_id" : 14324284,
  "text" : "@hyphaltip hand-picked bases are just the best for our artisanal genomes!",
  "id" : 699914292498456576,
  "in_reply_to_status_id" : 699884135284736001,
  "created_at" : "2016-02-17 11:12:25 +0000",
  "in_reply_to_screen_name" : "hyphaltip",
  "in_reply_to_user_id_str" : "14324284",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Goethe-Universit\u00E4t",
      "screen_name" : "goetheuni",
      "indices" : [ 7, 17 ],
      "id_str" : "38180826",
      "id" : 38180826
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "699914077192245248",
  "text" : "So the @goetheuni is doing a \u2018Summer of Knowledge\u2019. Guess that\u2019s as opposed to our \u2018Winter of Cluelessness\u2019?",
  "id" : 699914077192245248,
  "created_at" : "2016-02-17 11:11:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 55 ],
      "url" : "https:\/\/t.co\/SH2SPYXu06",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BB4oYc5BwoL\/",
      "display_url" : "instagram.com\/p\/BB4oYc5BwoL\/"
    } ]
  },
  "geo" : { },
  "id_str" : "699910660868730880",
  "text" : "Lobbying for the avocado emoji. https:\/\/t.co\/SH2SPYXu06",
  "id" : 699910660868730880,
  "created_at" : "2016-02-17 10:57:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael R. Crusoe",
      "screen_name" : "biocrusoe",
      "indices" : [ 3, 13 ],
      "id_str" : "17645638",
      "id" : 17645638
    }, {
      "name" : "DebianMed",
      "screen_name" : "DebianMed",
      "indices" : [ 96, 106 ],
      "id_str" : "282059234",
      "id" : 282059234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "699888229592535040",
  "text" : "RT @biocrusoe: Attention students: want to work on a nifty bioinformatics project and get paid? @DebianMed is sponsoring https:\/\/t.co\/9DzgV\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "DebianMed",
        "screen_name" : "DebianMed",
        "indices" : [ 81, 91 ],
        "id_str" : "282059234",
        "id" : 282059234
      }, {
        "name" : "Summer of Code",
        "screen_name" : "gsoc",
        "indices" : [ 134, 139 ],
        "id_str" : "22564445",
        "id" : 22564445
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 106, 129 ],
        "url" : "https:\/\/t.co\/9DzgVmVEuJ",
        "expanded_url" : "https:\/\/wiki.debian.org\/SummerOfCode2016\/Projects\/BioToolsTesting",
        "display_url" : "wiki.debian.org\/SummerOfCode20\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "699698885082640384",
    "text" : "Attention students: want to work on a nifty bioinformatics project and get paid? @DebianMed is sponsoring https:\/\/t.co\/9DzgVmVEuJ for @gsoc",
    "id" : 699698885082640384,
    "created_at" : "2016-02-16 20:56:28 +0000",
    "user" : {
      "name" : "Michael R. Crusoe",
      "screen_name" : "biocrusoe",
      "protected" : false,
      "id_str" : "17645638",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/485998749311721472\/0yX4CFRV_normal.jpeg",
      "id" : 17645638,
      "verified" : false
    }
  },
  "id" : 699888229592535040,
  "created_at" : "2016-02-17 09:28:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "699886093701763072",
  "geo" : { },
  "id_str" : "699886296882409472",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer oh sweet Weinfest :D",
  "id" : 699886296882409472,
  "in_reply_to_status_id" : 699886093701763072,
  "created_at" : "2016-02-17 09:21:11 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "699882963614314496",
  "geo" : { },
  "id_str" : "699885518562160640",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer I always thought this is how people travel on the Mosel :D",
  "id" : 699885518562160640,
  "in_reply_to_status_id" : 699882963614314496,
  "created_at" : "2016-02-17 09:18:05 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 72 ],
      "url" : "https:\/\/t.co\/wTp8AzATZc",
      "expanded_url" : "https:\/\/lucyluhan.files.wordpress.com\/2014\/10\/car-and-wild-boar.jpg",
      "display_url" : "lucyluhan.files.wordpress.com\/2014\/10\/car-an\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "699882198665547776",
  "geo" : { },
  "id_str" : "699882537531867136",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer damn, over here all you can get is https:\/\/t.co\/wTp8AzATZc",
  "id" : 699882537531867136,
  "in_reply_to_status_id" : 699882198665547776,
  "created_at" : "2016-02-17 09:06:14 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 18, 31 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 73 ],
      "url" : "https:\/\/t.co\/fwnoAe18eT",
      "expanded_url" : "https:\/\/twitter.com\/JohnDonoghue64\/status\/699307977942106113",
      "display_url" : "twitter.com\/JohnDonoghue64\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "699882034915905536",
  "text" : "I bet this is how @PhilippBayer commutes to work. https:\/\/t.co\/fwnoAe18eT",
  "id" : 699882034915905536,
  "created_at" : "2016-02-17 09:04:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 39 ],
      "url" : "https:\/\/t.co\/N7GgTR9Jkg",
      "expanded_url" : "https:\/\/twitter.com\/nrrrdcore\/status\/699773199496556544",
      "display_url" : "twitter.com\/nrrrdcore\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "699878556919320576",
  "text" : "grad school 101 https:\/\/t.co\/N7GgTR9Jkg",
  "id" : 699878556919320576,
  "created_at" : "2016-02-17 08:50:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "699878123249266688",
  "text" : "Is there a ways to automatically move the Dock position on Mac OS when you attach an external display? i.e. bottom -&gt; left?",
  "id" : 699878123249266688,
  "created_at" : "2016-02-17 08:48:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 46 ],
      "url" : "https:\/\/t.co\/CDYupu6dFc",
      "expanded_url" : "http:\/\/www.dianasjewels.net\/Necklaces\/dim0808292.jpg",
      "display_url" : "dianasjewels.net\/Necklaces\/dim0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "699705898718097408",
  "text" : "Related: Ruby on Wales https:\/\/t.co\/CDYupu6dFc",
  "id" : 699705898718097408,
  "created_at" : "2016-02-16 21:24:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 0, 9 ],
      "id_str" : "14245811",
      "id" : 14245811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "699646796189057026",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11404398168848, 8.753438880155766 ]
  },
  "id_str" : "699692316899020800",
  "in_reply_to_user_id" : 14245811,
  "text" : "@wilbanks congrats!",
  "id" : 699692316899020800,
  "in_reply_to_status_id" : 699646796189057026,
  "created_at" : "2016-02-16 20:30:22 +0000",
  "in_reply_to_screen_name" : "wilbanks",
  "in_reply_to_user_id_str" : "14245811",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "699584566126841856",
  "geo" : { },
  "id_str" : "699589911435935745",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch also: tried setting up the automatic build :)",
  "id" : 699589911435935745,
  "in_reply_to_status_id" : 699584566126841856,
  "created_at" : "2016-02-16 13:43:27 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "699584566126841856",
  "geo" : { },
  "id_str" : "699588086414626816",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch mh, somehow the new rake task doesn\u2019t show up on the prod system.",
  "id" : 699588086414626816,
  "in_reply_to_status_id" : 699584566126841856,
  "created_at" : "2016-02-16 13:36:12 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "699583910326509568",
  "geo" : { },
  "id_str" : "699584046683328513",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch so now i can clone the repo into one of our machines and give it a test run? :D",
  "id" : 699584046683328513,
  "in_reply_to_status_id" : 699583910326509568,
  "created_at" : "2016-02-16 13:20:09 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "699583134535413760",
  "geo" : { },
  "id_str" : "699583432360333312",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch did I solve all the docker riddles in the correct way by now? :D",
  "id" : 699583432360333312,
  "in_reply_to_status_id" : 699583134535413760,
  "created_at" : "2016-02-16 13:17:42 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 55, 67 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 54 ],
      "url" : "https:\/\/t.co\/OQLhkfktl8",
      "expanded_url" : "https:\/\/twitter.com\/rubyonwhales",
      "display_url" : "twitter.com\/rubyonwhales"
    } ]
  },
  "in_reply_to_status_id_str" : "699582865063940097",
  "geo" : { },
  "id_str" : "699583084870639616",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot not too unlikely, given https:\/\/t.co\/OQLhkfktl8 @helgerausch",
  "id" : 699583084870639616,
  "in_reply_to_status_id" : 699582865063940097,
  "created_at" : "2016-02-16 13:16:19 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 5, 17 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "699581591530696704",
  "text" : "Yay, @helgerausch is an awesome teacher when it comes to \uD83D\uDC8E\uD83D\uDD34 and \uD83D\uDC33. \uD83D\uDC96",
  "id" : 699581591530696704,
  "created_at" : "2016-02-16 13:10:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "not best practice",
      "screen_name" : "moeffju",
      "indices" : [ 0, 8 ],
      "id_str" : "5618832",
      "id" : 5618832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "699578430510211073",
  "geo" : { },
  "id_str" : "699578523300864001",
  "in_reply_to_user_id" : 5618832,
  "text" : "@moeffju Even better: Python 3\u00B11",
  "id" : 699578523300864001,
  "in_reply_to_status_id" : 699578430510211073,
  "created_at" : "2016-02-16 12:58:12 +0000",
  "in_reply_to_screen_name" : "moeffju",
  "in_reply_to_user_id_str" : "5618832",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marcel Salathe",
      "screen_name" : "marcelsalathe",
      "indices" : [ 0, 14 ],
      "id_str" : "14177696",
      "id" : 14177696
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "699568310560563200",
  "geo" : { },
  "id_str" : "699576681393221633",
  "in_reply_to_user_id" : 14177696,
  "text" : "@marcelsalathe I actually just thought about switching between 0 \u2194\uFE0F 1. Still, R is nice ;)",
  "id" : 699576681393221633,
  "in_reply_to_status_id" : 699568310560563200,
  "created_at" : "2016-02-16 12:50:53 +0000",
  "in_reply_to_screen_name" : "marcelsalathe",
  "in_reply_to_user_id_str" : "14177696",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marcel Salathe",
      "screen_name" : "marcelsalathe",
      "indices" : [ 0, 14 ],
      "id_str" : "14177696",
      "id" : 14177696
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "699565958113800192",
  "geo" : { },
  "id_str" : "699567460354134016",
  "in_reply_to_user_id" : 14177696,
  "text" : "@marcelsalathe i speak both on a daily basis and it confuses me every single day. :D",
  "id" : 699567460354134016,
  "in_reply_to_status_id" : 699565958113800192,
  "created_at" : "2016-02-16 12:14:14 +0000",
  "in_reply_to_screen_name" : "marcelsalathe",
  "in_reply_to_user_id_str" : "14177696",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "699561421764308992",
  "text" : "\u00ABI\u2019m writing my own version of Python now. Python 4. It\u2019s basically Python 2 but with one-based indexing.\u00BB",
  "id" : 699561421764308992,
  "created_at" : "2016-02-16 11:50:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "699517979957010432",
  "geo" : { },
  "id_str" : "699518670549217280",
  "in_reply_to_user_id" : 448328735,
  "text" : "@VetoSeb nope :)",
  "id" : 699518670549217280,
  "in_reply_to_status_id" : 699517979957010432,
  "created_at" : "2016-02-16 09:00:22 +0000",
  "in_reply_to_screen_name" : "SebInAction",
  "in_reply_to_user_id_str" : "448328735",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert",
      "screen_name" : "kventil",
      "indices" : [ 0, 8 ],
      "id_str" : "7431192",
      "id" : 7431192
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "699510542625591296",
  "geo" : { },
  "id_str" : "699510847928954881",
  "in_reply_to_user_id" : 7431192,
  "text" : "@kventil I\u2019d be more interested in the gene for overselling stuff on stage.",
  "id" : 699510847928954881,
  "in_reply_to_status_id" : 699510542625591296,
  "created_at" : "2016-02-16 08:29:17 +0000",
  "in_reply_to_screen_name" : "kventil",
  "in_reply_to_user_id_str" : "7431192",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "699500466867200001",
  "geo" : { },
  "id_str" : "699509778255638528",
  "in_reply_to_user_id" : 448328735,
  "text" : "@VetoSeb ich bin gespannt wie es l\u00E4uft. :D",
  "id" : 699509778255638528,
  "in_reply_to_status_id" : 699500466867200001,
  "created_at" : "2016-02-16 08:25:02 +0000",
  "in_reply_to_screen_name" : "SebInAction",
  "in_reply_to_user_id_str" : "448328735",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ali",
      "screen_name" : "zoonpolitikon",
      "indices" : [ 0, 14 ],
      "id_str" : "13040652",
      "id" : 13040652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "699509458184114177",
  "geo" : { },
  "id_str" : "699509617240469504",
  "in_reply_to_user_id" : 13040652,
  "text" : "@zoonpolitikon i\u2019m amazed of what the \u2018quality\u2019 of TED",
  "id" : 699509617240469504,
  "in_reply_to_status_id" : 699509458184114177,
  "created_at" : "2016-02-16 08:24:23 +0000",
  "in_reply_to_screen_name" : "zoonpolitikon",
  "in_reply_to_user_id_str" : "13040652",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/LcizMLQPR3",
      "expanded_url" : "https:\/\/twitter.com\/ExponentialMed\/status\/699410406243106816",
      "display_url" : "twitter.com\/ExponentialMed\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "699507347186651136",
  "text" : "amazing, doing machine learning on genomes can even predict how you wear your beard! https:\/\/t.co\/LcizMLQPR3",
  "id" : 699507347186651136,
  "created_at" : "2016-02-16 08:15:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 10, 16 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "699503176177885184",
  "geo" : { },
  "id_str" : "699503899997315073",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon @Lobot well, if you prefer to eat American style go for adding it ;)",
  "id" : 699503899997315073,
  "in_reply_to_status_id" : 699503176177885184,
  "created_at" : "2016-02-16 08:01:40 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 10, 16 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "699502559560667136",
  "geo" : { },
  "id_str" : "699502684433485824",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon @Lobot whops, I knew there was a reason I hadn\u2019t told you about the Sporkful earlier.",
  "id" : 699502684433485824,
  "in_reply_to_status_id" : 699502559560667136,
  "created_at" : "2016-02-16 07:56:50 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 32 ],
      "url" : "https:\/\/t.co\/B92X9bz6ez",
      "expanded_url" : "https:\/\/nppa.org\/page\/5617",
      "display_url" : "nppa.org\/page\/5617"
    }, {
      "indices" : [ 37, 60 ],
      "url" : "https:\/\/t.co\/nsG6S6B6FQ",
      "expanded_url" : "http:\/\/www.wikihow.com\/Write-a-DMCA-Take-Down-Request",
      "display_url" : "wikihow.com\/Write-a-DMCA-T\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "699499344186249216",
  "geo" : { },
  "id_str" : "699499801340198912",
  "in_reply_to_user_id" : 448328735,
  "text" : "@VetoSeb https:\/\/t.co\/B92X9bz6ez und https:\/\/t.co\/nsG6S6B6FQ ?",
  "id" : 699499801340198912,
  "in_reply_to_status_id" : 699499344186249216,
  "created_at" : "2016-02-16 07:45:23 +0000",
  "in_reply_to_screen_name" : "SebInAction",
  "in_reply_to_user_id_str" : "448328735",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 35, 44 ],
      "id_str" : "14861745",
      "id" : 14861745
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 45, 51 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 76 ],
      "url" : "https:\/\/t.co\/HUUfKVRPEx",
      "expanded_url" : "http:\/\/www.sporkful.com\/pho-the-love-of-slurping-noodles\/",
      "display_url" : "sporkful.com\/pho-the-love-o\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "699497168571396096",
  "text" : "There's a sporkful episode on Pho! @Senficon @Lobot  https:\/\/t.co\/HUUfKVRPEx",
  "id" : 699497168571396096,
  "created_at" : "2016-02-16 07:34:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/9WMm2RLdku",
      "expanded_url" : "https:\/\/twitter.com\/replicatedtypo\/status\/699357190033956864",
      "display_url" : "twitter.com\/replicatedtypo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "699358608849563648",
  "text" : "\u00ABA really common kind of reaction to all the silent words is \"Bullshit!\u201C\u00BB https:\/\/t.co\/9WMm2RLdku",
  "id" : 699358608849563648,
  "created_at" : "2016-02-15 22:24:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "The_Smoking_GNU",
      "indices" : [ 0, 16 ],
      "id_str" : "14535787",
      "id" : 14535787
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "699351849040789504",
  "geo" : { },
  "id_str" : "699352047984996353",
  "in_reply_to_user_id" : 14535787,
  "text" : "@The_Smoking_GNU no pressure. also I might have liked it because I\u2019m a fungi person ;)",
  "id" : 699352047984996353,
  "in_reply_to_status_id" : 699351849040789504,
  "created_at" : "2016-02-15 21:58:16 +0000",
  "in_reply_to_screen_name" : "The_Smoking_GNU",
  "in_reply_to_user_id_str" : "14535787",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "The_Smoking_GNU",
      "indices" : [ 0, 16 ],
      "id_str" : "14535787",
      "id" : 14535787
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "699351107789783040",
  "geo" : { },
  "id_str" : "699351304955695104",
  "in_reply_to_user_id" : 14535787,
  "text" : "@The_Smoking_GNU i think it\u2019s pretty interesting as it follows the \u201Escience\u201C spread &amp; reported by IFLS and others.",
  "id" : 699351304955695104,
  "in_reply_to_status_id" : 699351107789783040,
  "created_at" : "2016-02-15 21:55:19 +0000",
  "in_reply_to_screen_name" : "The_Smoking_GNU",
  "in_reply_to_user_id_str" : "14535787",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "699349056557023232",
  "geo" : { },
  "id_str" : "699349307099607040",
  "in_reply_to_user_id" : 14286491,
  "text" : "Given all the microbiome hype it will probably soon be vice versa, doing the microbic horoscope.",
  "id" : 699349307099607040,
  "in_reply_to_status_id" : 699349056557023232,
  "created_at" : "2016-02-15 21:47:22 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "699349056557023232",
  "text" : "\u00ABMoney and the Microbiome: How Wealth Affects Gut Bacteria\u00BB subject of the email newsletter of a DTC microbiome sequencing company.",
  "id" : 699349056557023232,
  "created_at" : "2016-02-15 21:46:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/psUYS4CmVW",
      "expanded_url" : "https:\/\/medium.com\/life-tips\/vcs-don-t-compare-me-to-your-wife-just-don-t-9dc2c8c1ac93#.4739zsyx9",
      "display_url" : "medium.com\/life-tips\/vcs-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "699347877538197504",
  "text" : "\u00ABIf there aren\u2019t any women pitching you, it\u2019s not a pipeline problem. The problem is literally you.\u00BB https:\/\/t.co\/psUYS4CmVW",
  "id" : 699347877538197504,
  "created_at" : "2016-02-15 21:41:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 87 ],
      "url" : "https:\/\/t.co\/trVOh7dl2q",
      "expanded_url" : "http:\/\/blogs.discovermagazine.com\/science-sushi\/2016\/02\/14\/hawaii-orgasm-mushroom\/",
      "display_url" : "blogs.discovermagazine.com\/science-sushi\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "699344804514287616",
  "text" : "Sniffing Out The Truth About Hawai\u2018i\u2019s Orgasm-Inducing Mushroom https:\/\/t.co\/trVOh7dl2q",
  "id" : 699344804514287616,
  "created_at" : "2016-02-15 21:29:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u24EA Rik Smith-Unna \uD83C\uDDF0\uD83C\uDDEA",
      "screen_name" : "blahah404",
      "indices" : [ 0, 10 ],
      "id_str" : "99173786",
      "id" : 99173786
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 90 ],
      "url" : "https:\/\/t.co\/xtBUuXEVIa",
      "expanded_url" : "https:\/\/media0.giphy.com\/media\/HmN8Ow5PZxYic\/200.gif",
      "display_url" : "media0.giphy.com\/media\/HmN8Ow5P\u2026"
    }, {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/h4ugXzvNQJ",
      "expanded_url" : "http:\/\/i.imgur.com\/5WDZH3Y.gif",
      "display_url" : "i.imgur.com\/5WDZH3Y.gif"
    } ]
  },
  "in_reply_to_status_id_str" : "699340849730162688",
  "geo" : { },
  "id_str" : "699341258892955648",
  "in_reply_to_user_id" : 99173786,
  "text" : "@blahah404 yeah, totally unnecessary. Lately i\u2019m feeling less like https:\/\/t.co\/xtBUuXEVIa and more like https:\/\/t.co\/h4ugXzvNQJ",
  "id" : 699341258892955648,
  "in_reply_to_status_id" : 699340849730162688,
  "created_at" : "2016-02-15 21:15:23 +0000",
  "in_reply_to_screen_name" : "blahah404",
  "in_reply_to_user_id_str" : "99173786",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u24EA Rik Smith-Unna \uD83C\uDDF0\uD83C\uDDEA",
      "screen_name" : "blahah404",
      "indices" : [ 0, 10 ],
      "id_str" : "99173786",
      "id" : 99173786
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "699340478039326720",
  "geo" : { },
  "id_str" : "699340676035690496",
  "in_reply_to_user_id" : 99173786,
  "text" : "@blahah404 ever since we switched the deployment of openSNP to Docker I a) have no clue what\u2019s happening b) feel very old all of a sudden.",
  "id" : 699340676035690496,
  "in_reply_to_status_id" : 699340478039326720,
  "created_at" : "2016-02-15 21:13:04 +0000",
  "in_reply_to_screen_name" : "blahah404",
  "in_reply_to_user_id_str" : "99173786",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "699340259478339584",
  "text" : "My personal &amp; modern re-interpretation of \u201CThe Neverending Story\u201D: Bastian meets &amp; tries to understand Docker. \uD83D\uDC33",
  "id" : 699340259478339584,
  "created_at" : "2016-02-15 21:11:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 85 ],
      "url" : "https:\/\/t.co\/tDoja6HAJg",
      "expanded_url" : "https:\/\/medium.com\/@neuroecology\/punctuation-in-novels-8f316d542ec4#.9hv9rja1d",
      "display_url" : "medium.com\/@neuroecology\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "699327691263209473",
  "text" : "The Data Science of Punctuation in Novels, i.e. spot McCarthy https:\/\/t.co\/tDoja6HAJg",
  "id" : 699327691263209473,
  "created_at" : "2016-02-15 20:21:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karin Lagesen",
      "screen_name" : "karinlag",
      "indices" : [ 0, 9 ],
      "id_str" : "571902552",
      "id" : 571902552
    }, {
      "name" : "Nazeefa",
      "screen_name" : "NazeefaFatima",
      "indices" : [ 10, 24 ],
      "id_str" : "37054704",
      "id" : 37054704
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "699322717695299589",
  "geo" : { },
  "id_str" : "699323296513421315",
  "in_reply_to_user_id" : 571902552,
  "text" : "@karinlag @NazeefaFatima i know, just as tired of \u201ENGS\u201C for what\u2019s basically 10 y\/o news. Trying conscious efforts to switch 2 \u201Esecond gen\u201C.",
  "id" : 699323296513421315,
  "in_reply_to_status_id" : 699322717695299589,
  "created_at" : "2016-02-15 20:04:01 +0000",
  "in_reply_to_screen_name" : "karinlag",
  "in_reply_to_user_id_str" : "571902552",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karin Lagesen",
      "screen_name" : "karinlag",
      "indices" : [ 0, 9 ],
      "id_str" : "571902552",
      "id" : 571902552
    }, {
      "name" : "Nazeefa",
      "screen_name" : "NazeefaFatima",
      "indices" : [ 10, 24 ],
      "id_str" : "37054704",
      "id" : 37054704
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "699252771451748353",
  "geo" : { },
  "id_str" : "699321766636867584",
  "in_reply_to_user_id" : 571902552,
  "text" : "@karinlag @NazeefaFatima i like \u201Esecond generation sequencing\u201C, allows to easily upgrade to n+1 generation sequencing.",
  "id" : 699321766636867584,
  "in_reply_to_status_id" : 699252771451748353,
  "created_at" : "2016-02-15 19:57:56 +0000",
  "in_reply_to_screen_name" : "karinlag",
  "in_reply_to_user_id_str" : "571902552",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christie Bahlai",
      "screen_name" : "cbahlai",
      "indices" : [ 0, 8 ],
      "id_str" : "958649520",
      "id" : 958649520
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "699281793191710720",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11371702629442, 8.753781658273448 ]
  },
  "id_str" : "699281915711524865",
  "in_reply_to_user_id" : 958649520,
  "text" : "@cbahlai must be one of those cases where the locals are already adapted to it.",
  "id" : 699281915711524865,
  "in_reply_to_status_id" : 699281793191710720,
  "created_at" : "2016-02-15 17:19:35 +0000",
  "in_reply_to_screen_name" : "cbahlai",
  "in_reply_to_user_id_str" : "958649520",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christie Bahlai",
      "screen_name" : "cbahlai",
      "indices" : [ 0, 8 ],
      "id_str" : "958649520",
      "id" : 958649520
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "699252254138884098",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11404361035417, 8.753438396311932 ]
  },
  "id_str" : "699281353129521152",
  "in_reply_to_user_id" : 958649520,
  "text" : "@cbahlai wow, apparently I got off really easy on that one!",
  "id" : 699281353129521152,
  "in_reply_to_status_id" : 699252254138884098,
  "created_at" : "2016-02-15 17:17:21 +0000",
  "in_reply_to_screen_name" : "cbahlai",
  "in_reply_to_user_id_str" : "958649520",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "699215908040880128",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17248230224626, 8.627522801070835 ]
  },
  "id_str" : "699216270512807937",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer it\u2019s the smoothing. It\u2019s where the DB was down and 0 new entries.",
  "id" : 699216270512807937,
  "in_reply_to_status_id" : 699215908040880128,
  "created_at" : "2016-02-15 12:58:44 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 14, 26 ],
      "id_str" : "52747896",
      "id" : 52747896
    }, {
      "name" : "Dawn Field",
      "screen_name" : "fiedawn",
      "indices" : [ 27, 35 ],
      "id_str" : "18589743",
      "id" : 18589743
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "699215029325791232",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17248230224626, 8.627522801070835 ]
  },
  "id_str" : "699216192964333568",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @helgerausch @fiedawn yep, could we automate it?",
  "id" : 699216192964333568,
  "in_reply_to_status_id" : 699215029325791232,
  "created_at" : "2016-02-15 12:58:25 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    }, {
      "name" : "Dawn Field",
      "screen_name" : "fiedawn",
      "indices" : [ 13, 21 ],
      "id_str" : "18589743",
      "id" : 18589743
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "699214274539950080",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17247801307115, 8.62752929396758 ]
  },
  "id_str" : "699214911113687040",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch @fiedawn yes, good idea. And maybe put the graphs on the site :)",
  "id" : 699214911113687040,
  "in_reply_to_status_id" : 699214274539950080,
  "created_at" : "2016-02-15 12:53:20 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dawn Field",
      "screen_name" : "fiedawn",
      "indices" : [ 45, 53 ],
      "id_str" : "18589743",
      "id" : 18589743
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/699187300664766465\/photo\/1",
      "indices" : [ 54, 77 ],
      "url" : "https:\/\/t.co\/EEoMEzW0UT",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CbQDJLEWAAAVLNk.png",
      "id_str" : "699187298273984512",
      "id" : 699187298273984512,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CbQDJLEWAAAVLNk.png",
      "sizes" : [ {
        "h" : 680,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 2098,
        "resize" : "fit",
        "w" : 2097
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 2047
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 1199
      } ],
      "display_url" : "pic.twitter.com\/EEoMEzW0UT"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "699187300664766465",
  "text" : "openSNP user and data set numbers over time. @fiedawn https:\/\/t.co\/EEoMEzW0UT",
  "id" : 699187300664766465,
  "created_at" : "2016-02-15 11:03:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "699172281206116352",
  "geo" : { },
  "id_str" : "699173908109459456",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot yes, he likes to be tied to a gas stove running full blast iirc.",
  "id" : 699173908109459456,
  "in_reply_to_status_id" : 699172281206116352,
  "created_at" : "2016-02-15 10:10:24 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/uZ9LtgmXkq",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/699169778431324160",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "699169778431324160",
  "geo" : { },
  "id_str" : "699170659184873472",
  "in_reply_to_user_id" : 14286491,
  "text" : "best way to use your twitter-archive: find GIFs you created 3 years ago. https:\/\/t.co\/uZ9LtgmXkq",
  "id" : 699170659184873472,
  "in_reply_to_status_id" : 699169778431324160,
  "created_at" : "2016-02-15 09:57:29 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "699170159706181632",
  "geo" : { },
  "id_str" : "699170416762449920",
  "in_reply_to_user_id" : 448328735,
  "text" : "@VetoSeb ich w\u00FCrde sehr lachen, aber ich bin ja auch b\u00F6sartig ;)",
  "id" : 699170416762449920,
  "in_reply_to_status_id" : 699170159706181632,
  "created_at" : "2016-02-15 09:56:31 +0000",
  "in_reply_to_screen_name" : "SebInAction",
  "in_reply_to_user_id_str" : "448328735",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "699167593974726657",
  "geo" : { },
  "id_str" : "699169894810705920",
  "in_reply_to_user_id" : 448328735,
  "text" : "@VetoSeb notfalls eine DMCA take-down schicken? Ist doch ganz piratig :D",
  "id" : 699169894810705920,
  "in_reply_to_status_id" : 699167593974726657,
  "created_at" : "2016-02-15 09:54:27 +0000",
  "in_reply_to_screen_name" : "SebInAction",
  "in_reply_to_user_id_str" : "448328735",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 83 ],
      "url" : "https:\/\/t.co\/t6UvmNxHs7",
      "expanded_url" : "http:\/\/imgur.com\/6L3oZSe",
      "display_url" : "imgur.com\/6L3oZSe"
    } ]
  },
  "in_reply_to_status_id_str" : "699166673597759488",
  "geo" : { },
  "id_str" : "699169778431324160",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot I do, but it\u2019s first date, second date, tomato date. https:\/\/t.co\/t6UvmNxHs7",
  "id" : 699169778431324160,
  "in_reply_to_status_id" : 699166673597759488,
  "created_at" : "2016-02-15 09:53:59 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 80 ],
      "url" : "https:\/\/t.co\/V1hYWZ4dfG",
      "expanded_url" : "http:\/\/www.pri.org\/stories\/2016-02-14\/there-such-thing-octopus-sign-language",
      "display_url" : "pri.org\/stories\/2016-0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "699166599085957120",
  "text" : "Now I know what language to learn next: \uD83D\uDC19 sign language! https:\/\/t.co\/V1hYWZ4dfG",
  "id" : 699166599085957120,
  "created_at" : "2016-02-15 09:41:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 74 ],
      "url" : "https:\/\/t.co\/HgmYUW3kUb",
      "expanded_url" : "http:\/\/mindgruve.com\/wp\/wp-content\/uploads\/2013\/02\/Screen-shot-2013-02-15-at-12.22.20-PM.png",
      "display_url" : "mindgruve.com\/wp\/wp-content\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "699165965544747009",
  "text" : "Sweet, openSNP got its 2,500th data set yesterday. https:\/\/t.co\/HgmYUW3kUb",
  "id" : 699165965544747009,
  "created_at" : "2016-02-15 09:38:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "699146768752185344",
  "geo" : { },
  "id_str" : "699165143687680000",
  "in_reply_to_user_id" : 448328735,
  "text" : "@VetoSeb verlang das Entfernen deines geistigen Eigentums :D",
  "id" : 699165143687680000,
  "in_reply_to_status_id" : 699146768752185344,
  "created_at" : "2016-02-15 09:35:34 +0000",
  "in_reply_to_screen_name" : "SebInAction",
  "in_reply_to_user_id_str" : "448328735",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Girls Who Code",
      "screen_name" : "GirlsWhoCode",
      "indices" : [ 64, 77 ],
      "id_str" : "430995737",
      "id" : 430995737
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/cato4qHAt8",
      "expanded_url" : "https:\/\/twitter.com\/earino\/status\/698981311738851329",
      "display_url" : "twitter.com\/earino\/status\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "699156065917792256",
  "text" : "Statistics nerds: Get your Anscombe\u2019s Quartet shirt and support @GirlsWhoCode! https:\/\/t.co\/cato4qHAt8",
  "id" : 699156065917792256,
  "created_at" : "2016-02-15 08:59:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "699155562349641728",
  "text" : "Using Siri to take down my shopping list maybe wasn\u2019t the best idea. Or I just forgot why I\u2019d need 400 tomatoes.",
  "id" : 699155562349641728,
  "created_at" : "2016-02-15 08:57:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 3, 16 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/PhilippBayer\/status\/699123465912131584\/photo\/1",
      "indices" : [ 22, 45 ],
      "url" : "https:\/\/t.co\/fJWwK46VGQ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CbPJFj_UYAA25kp.png",
      "id_str" : "699123464569905152",
      "id" : 699123464569905152,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CbPJFj_UYAA25kp.png",
      "sizes" : [ {
        "h" : 192,
        "resize" : "fit",
        "w" : 396
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 192,
        "resize" : "fit",
        "w" : 396
      }, {
        "h" : 192,
        "resize" : "fit",
        "w" : 396
      }, {
        "h" : 192,
        "resize" : "fit",
        "w" : 396
      } ],
      "display_url" : "pic.twitter.com\/fJWwK46VGQ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "699154503673765889",
  "text" : "RT @PhilippBayer: \\o\/ https:\/\/t.co\/fJWwK46VGQ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/PhilippBayer\/status\/699123465912131584\/photo\/1",
        "indices" : [ 4, 27 ],
        "url" : "https:\/\/t.co\/fJWwK46VGQ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CbPJFj_UYAA25kp.png",
        "id_str" : "699123464569905152",
        "id" : 699123464569905152,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CbPJFj_UYAA25kp.png",
        "sizes" : [ {
          "h" : 192,
          "resize" : "fit",
          "w" : 396
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 192,
          "resize" : "fit",
          "w" : 396
        }, {
          "h" : 192,
          "resize" : "fit",
          "w" : 396
        }, {
          "h" : 192,
          "resize" : "fit",
          "w" : 396
        } ],
        "display_url" : "pic.twitter.com\/fJWwK46VGQ"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "699123465912131584",
    "text" : "\\o\/ https:\/\/t.co\/fJWwK46VGQ",
    "id" : 699123465912131584,
    "created_at" : "2016-02-15 06:49:58 +0000",
    "user" : {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "protected" : false,
      "id_str" : "121777206",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2013711027\/IMG_1088_normal.png",
      "id" : 121777206,
      "verified" : false
    }
  },
  "id" : 699154503673765889,
  "created_at" : "2016-02-15 08:53:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "A. History",
      "screen_name" : "AhistoricalPics",
      "indices" : [ 3, 19 ],
      "id_str" : "2277140276",
      "id" : 2277140276
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/oldpicsarchive\/status\/699100588907352064\/photo\/1",
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/IaB7k3Mtzk",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CbO0SBDWAAE8q5j.jpg",
      "id_str" : "699100588785664001",
      "id" : 699100588785664001,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CbO0SBDWAAE8q5j.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/IaB7k3Mtzk"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "699153776364691457",
  "text" : "RT @AhistoricalPics: Device to keep wearer from retweeting mislabeled historical photographs, 1896 https:\/\/t.co\/IaB7k3Mtzk",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/oldpicsarchive\/status\/699100588907352064\/photo\/1",
        "indices" : [ 78, 101 ],
        "url" : "https:\/\/t.co\/IaB7k3Mtzk",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CbO0SBDWAAE8q5j.jpg",
        "id_str" : "699100588785664001",
        "id" : 699100588785664001,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CbO0SBDWAAE8q5j.jpg",
        "sizes" : [ {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/IaB7k3Mtzk"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "699104398538989568",
    "text" : "Device to keep wearer from retweeting mislabeled historical photographs, 1896 https:\/\/t.co\/IaB7k3Mtzk",
    "id" : 699104398538989568,
    "created_at" : "2016-02-15 05:34:12 +0000",
    "user" : {
      "name" : "A. History",
      "screen_name" : "AhistoricalPics",
      "protected" : false,
      "id_str" : "2277140276",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/419701923944480769\/AzrkOS2P_normal.jpeg",
      "id" : 2277140276,
      "verified" : false
    }
  },
  "id" : 699153776364691457,
  "created_at" : "2016-02-15 08:50:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "699089669149995009",
  "geo" : { },
  "id_str" : "699153340647796736",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer no pressure!",
  "id" : 699153340647796736,
  "in_reply_to_status_id" : 699089669149995009,
  "created_at" : "2016-02-15 08:48:40 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "E. Ari\u00F1o de la Rubia",
      "screen_name" : "earino",
      "indices" : [ 0, 7 ],
      "id_str" : "4022411",
      "id" : 4022411
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "698987434319572992",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06094032059934, 8.818647154432519 ]
  },
  "id_str" : "699000822462615552",
  "in_reply_to_user_id" : 4022411,
  "text" : "@earino done and done!",
  "id" : 699000822462615552,
  "in_reply_to_status_id" : 698987434319572992,
  "created_at" : "2016-02-14 22:42:37 +0000",
  "in_reply_to_screen_name" : "earino",
  "in_reply_to_user_id_str" : "4022411",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "E. Ari\u00F1o de la Rubia",
      "screen_name" : "earino",
      "indices" : [ 0, 7 ],
      "id_str" : "4022411",
      "id" : 4022411
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "698986649191972864",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06102030740572, 8.818808863314258 ]
  },
  "id_str" : "698986913701699591",
  "in_reply_to_user_id" : 4022411,
  "text" : "@earino that\u2019s awesome! \uD83D\uDC4D",
  "id" : 698986913701699591,
  "in_reply_to_status_id" : 698986649191972864,
  "created_at" : "2016-02-14 21:47:21 +0000",
  "in_reply_to_screen_name" : "earino",
  "in_reply_to_user_id_str" : "4022411",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 44 ],
      "url" : "https:\/\/t.co\/22TCpqi3L8",
      "expanded_url" : "https:\/\/twitter.com\/earino\/status\/698962375878119424",
      "display_url" : "twitter.com\/earino\/status\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06086097524762, 8.818791147194675 ]
  },
  "id_str" : "698985740076711936",
  "text" : "Where can I buy one? https:\/\/t.co\/22TCpqi3L8",
  "id" : 698985740076711936,
  "created_at" : "2016-02-14 21:42:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 74 ],
      "url" : "https:\/\/t.co\/uM1FheGwCP",
      "expanded_url" : "http:\/\/www.vox.com\/2016\/2\/12\/10972140\/fruits-vegetables-taste-better-europe",
      "display_url" : "vox.com\/2016\/2\/12\/1097\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "698889930832015363",
  "text" : "\u00ABWhy fruits and vegetables taste better in Europe\u00BB https:\/\/t.co\/uM1FheGwCP",
  "id" : 698889930832015363,
  "created_at" : "2016-02-14 15:21:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/NZlx6juWN0",
      "expanded_url" : "http:\/\/feedproxy.google.com\/~r\/plosone\/PLoSONE\/~3\/yIyP0AJeQvc\/info%3Adoi%2F10.1371%2Fjournal.pone.0148054",
      "display_url" : "feedproxy.google.com\/~r\/plosone\/PLo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "698887028809797632",
  "text" : "Procrastination, Distress and Life Satisfaction across the Age Range \u2013 A German Representative Community Study https:\/\/t.co\/NZlx6juWN0",
  "id" : 698887028809797632,
  "created_at" : "2016-02-14 15:10:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/1233MSgQmq",
      "expanded_url" : "http:\/\/i.imgur.com\/0baedHV.jpg",
      "display_url" : "i.imgur.com\/0baedHV.jpg"
    } ]
  },
  "geo" : { },
  "id_str" : "698854929897824256",
  "text" : "Asked to enter my motto to be shown during an opening reception. Must resist choosing \u201EE Pluribus Anus\u201C. https:\/\/t.co\/1233MSgQmq",
  "id" : 698854929897824256,
  "created_at" : "2016-02-14 13:02:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 68 ],
      "url" : "https:\/\/t.co\/4xDHh152RE",
      "expanded_url" : "https:\/\/twitter.com\/Rocket_Woman1\/status\/697797166052429824",
      "display_url" : "twitter.com\/Rocket_Woman1\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11404490326965, 8.753434836054863 ]
  },
  "id_str" : "698845381174652928",
  "text" : "Those graphs show a depressing status quo :\/ https:\/\/t.co\/4xDHh152RE",
  "id" : 698845381174652928,
  "created_at" : "2016-02-14 12:24:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "diybio",
      "indices" : [ 77, 84 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/QBGnOW9sln",
      "expanded_url" : "http:\/\/feeds.plos.org\/~r\/plosone\/PLoSONE\/~3\/URVhuxatIng\/info%3Adoi%2F10.1371%2Fjournal.pone.0149150",
      "display_url" : "feeds.plos.org\/~r\/plosone\/PLo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "698844110690639874",
  "text" : "\u00ABA Rapid and Low-Cost PCR Thermal Cycler for Infectious Disease Diagnostics\u00BB #diybio  https:\/\/t.co\/QBGnOW9sln",
  "id" : 698844110690639874,
  "created_at" : "2016-02-14 12:19:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u24EA Rik Smith-Unna \uD83C\uDDF0\uD83C\uDDEA",
      "screen_name" : "blahah404",
      "indices" : [ 0, 10 ],
      "id_str" : "99173786",
      "id" : 99173786
    }, {
      "name" : "Guardian Science",
      "screen_name" : "guardianscience",
      "indices" : [ 11, 27 ],
      "id_str" : "21581503",
      "id" : 21581503
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "698790535394390016",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17655037978601, 8.629998708158055 ]
  },
  "id_str" : "698795738906681344",
  "in_reply_to_user_id" : 99173786,
  "text" : "@blahah404 @guardianscience did they do a mean stroganoff as well? \u2026",
  "id" : 698795738906681344,
  "in_reply_to_status_id" : 698790535394390016,
  "created_at" : "2016-02-14 09:07:41 +0000",
  "in_reply_to_screen_name" : "blahah404",
  "in_reply_to_user_id_str" : "99173786",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 40 ],
      "url" : "https:\/\/t.co\/0DzgfaXzLP",
      "expanded_url" : "http:\/\/blogs.uw.edu\/ajko\/2016\/02\/13\/fifty-privileges\/",
      "display_url" : "blogs.uw.edu\/ajko\/2016\/02\/1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "698672317694681088",
  "text" : "Fifty privileges https:\/\/t.co\/0DzgfaXzLP (sry, lost the via)",
  "id" : 698672317694681088,
  "created_at" : "2016-02-14 00:57:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "698643316469055489",
  "text" : "now watching: West Wing S05E17 \u2013 The Supremes.",
  "id" : 698643316469055489,
  "created_at" : "2016-02-13 23:02:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "malech maltz",
      "screen_name" : "malech",
      "indices" : [ 0, 7 ],
      "id_str" : "784085846391713793",
      "id" : 784085846391713793
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "698636627934060544",
  "text" : "@malech bgreshake@gmail.com, bitte mit datum :3",
  "id" : 698636627934060544,
  "created_at" : "2016-02-13 22:35:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "malech maltz",
      "screen_name" : "malech",
      "indices" : [ 0, 7 ],
      "id_str" : "784085846391713793",
      "id" : 784085846391713793
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "698636243840692224",
  "text" : "@malech o\/",
  "id" : 698636243840692224,
  "created_at" : "2016-02-13 22:33:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 44 ],
      "url" : "https:\/\/t.co\/C8qosQKHE5",
      "expanded_url" : "https:\/\/twitter.com\/TheBloodVoyage\/status\/698612040978583552",
      "display_url" : "twitter.com\/TheBloodVoyage\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11403376927183, 8.753438247490417 ]
  },
  "id_str" : "698614498085707776",
  "text" : "A bear enters a bar\u2026 https:\/\/t.co\/C8qosQKHE5",
  "id" : 698614498085707776,
  "created_at" : "2016-02-13 21:07:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/698605316079013888\/photo\/1",
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/5ysKAMOFit",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CbHx1VqWwAEkV_w.jpg",
      "id_str" : "698605315869294593",
      "id" : 698605315869294593,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CbHx1VqWwAEkV_w.jpg",
      "sizes" : [ {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 1323,
        "resize" : "fit",
        "w" : 992
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1323,
        "resize" : "fit",
        "w" : 992
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      } ],
      "display_url" : "pic.twitter.com\/5ysKAMOFit"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.114016, 8.753452 ]
  },
  "id_str" : "698605316079013888",
  "text" : "I always felt consumerism was somewhat alien, but I think our shopping center is overdoing it. https:\/\/t.co\/5ysKAMOFit",
  "id" : 698605316079013888,
  "created_at" : "2016-02-13 20:31:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "698590240877842432",
  "geo" : { },
  "id_str" : "698592906987364352",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez whut?! all the best for it!",
  "id" : 698592906987364352,
  "in_reply_to_status_id" : 698590240877842432,
  "created_at" : "2016-02-13 19:41:42 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/n2A6payVmS",
      "expanded_url" : "https:\/\/twitter.com\/JBYoder\/status\/698576599017349124",
      "display_url" : "twitter.com\/JBYoder\/status\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "698579748545544192",
  "text" : "let me rephrase that figure caption: so cute, too bad they won\u2019t live. https:\/\/t.co\/n2A6payVmS",
  "id" : 698579748545544192,
  "created_at" : "2016-02-13 18:49:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luke Jeffcetera",
      "screen_name" : "puke_",
      "indices" : [ 3, 9 ],
      "id_str" : "18011274",
      "id" : 18011274
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/puke_\/status\/698449540207157248\/photo\/1",
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/dmsQq4hHKM",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CbFkJfoVIAAJSoE.jpg",
      "id_str" : "698449531491393536",
      "id" : 698449531491393536,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CbFkJfoVIAAJSoE.jpg",
      "sizes" : [ {
        "h" : 631,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 447,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 631,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 631,
        "resize" : "fit",
        "w" : 960
      } ],
      "display_url" : "pic.twitter.com\/dmsQq4hHKM"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "698565414180298752",
  "text" : "RT @puke_: Erryone carrying on about back to the future but tomorrow we receive Pris https:\/\/t.co\/dmsQq4hHKM",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/puke_\/status\/698449540207157248\/photo\/1",
        "indices" : [ 74, 97 ],
        "url" : "https:\/\/t.co\/dmsQq4hHKM",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CbFkJfoVIAAJSoE.jpg",
        "id_str" : "698449531491393536",
        "id" : 698449531491393536,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CbFkJfoVIAAJSoE.jpg",
        "sizes" : [ {
          "h" : 631,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 447,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 631,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 631,
          "resize" : "fit",
          "w" : 960
        } ],
        "display_url" : "pic.twitter.com\/dmsQq4hHKM"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "698449540207157248",
    "text" : "Erryone carrying on about back to the future but tomorrow we receive Pris https:\/\/t.co\/dmsQq4hHKM",
    "id" : 698449540207157248,
    "created_at" : "2016-02-13 10:12:01 +0000",
    "user" : {
      "name" : "Luke Jeffcetera",
      "screen_name" : "puke_",
      "protected" : false,
      "id_str" : "18011274",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/759380911838208000\/xuRHqwz5_normal.jpg",
      "id" : 18011274,
      "verified" : false
    }
  },
  "id" : 698565414180298752,
  "created_at" : "2016-02-13 17:52:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "beau",
      "screen_name" : "beaugunderson",
      "indices" : [ 0, 14 ],
      "id_str" : "5746882",
      "id" : 5746882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "698541420831854593",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11404540601594, 8.753447768927158 ]
  },
  "id_str" : "698541584774754304",
  "in_reply_to_user_id" : 5746882,
  "text" : "@beaugunderson indeed you are among the first 100! I just browsed through our early data sets yesterday :)",
  "id" : 698541584774754304,
  "in_reply_to_status_id" : 698541420831854593,
  "created_at" : "2016-02-13 16:17:46 +0000",
  "in_reply_to_screen_name" : "beaugunderson",
  "in_reply_to_user_id_str" : "5746882",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "chrysalis",
      "screen_name" : "thricedotted",
      "indices" : [ 3, 16 ],
      "id_str" : "887397150",
      "id" : 887397150
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 65 ],
      "url" : "https:\/\/t.co\/Sc6rjV7fGW",
      "expanded_url" : "https:\/\/twitter.com\/destroy_yrself\/status\/698205273949913089",
      "display_url" : "twitter.com\/destroy_yrself\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "698539662210699264",
  "text" : "RT @thricedotted: YO THIS THREAD IS \uD83D\uDD25\uD83D\uDD25\uD83D\uDD25\uD83D\uDD25\uD83D\uDD25 https:\/\/t.co\/Sc6rjV7fGW",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 24, 47 ],
        "url" : "https:\/\/t.co\/Sc6rjV7fGW",
        "expanded_url" : "https:\/\/twitter.com\/destroy_yrself\/status\/698205273949913089",
        "display_url" : "twitter.com\/destroy_yrself\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "698323996039712768",
    "text" : "YO THIS THREAD IS \uD83D\uDD25\uD83D\uDD25\uD83D\uDD25\uD83D\uDD25\uD83D\uDD25 https:\/\/t.co\/Sc6rjV7fGW",
    "id" : 698323996039712768,
    "created_at" : "2016-02-13 01:53:09 +0000",
    "user" : {
      "name" : "chrysalis",
      "screen_name" : "thricedotted",
      "protected" : false,
      "id_str" : "887397150",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/809233487928508416\/uSvFX63Z_normal.jpg",
      "id" : 887397150,
      "verified" : false
    }
  },
  "id" : 698539662210699264,
  "created_at" : "2016-02-13 16:10:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "698530059879985152",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11404219463899, 8.753437180580026 ]
  },
  "id_str" : "698530195972689920",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez too bad. I think I won\u2019t make it either. Too many other conference plans already :(",
  "id" : 698530195972689920,
  "in_reply_to_status_id" : 698530059879985152,
  "created_at" : "2016-02-13 15:32:31 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeroen Bosman",
      "screen_name" : "jeroenbosman",
      "indices" : [ 0, 13 ],
      "id_str" : "9104202",
      "id" : 9104202
    }, {
      "name" : "Robin Champieux",
      "screen_name" : "rchampieux",
      "indices" : [ 14, 25 ],
      "id_str" : "20653310",
      "id" : 20653310
    }, {
      "name" : "Bi\u24D0nca Kramer",
      "screen_name" : "MsPhelps",
      "indices" : [ 26, 35 ],
      "id_str" : "22963112",
      "id" : 22963112
    }, {
      "name" : "Fiona Murphy",
      "screen_name" : "DrFionaLM",
      "indices" : [ 36, 46 ],
      "id_str" : "20386697",
      "id" : 20386697
    }, {
      "name" : "Neil B Christensen",
      "screen_name" : "neilblairc",
      "indices" : [ 47, 58 ],
      "id_str" : "15187400",
      "id" : 15187400
    }, {
      "name" : "Bethany Nowviskie",
      "screen_name" : "nowviskie",
      "indices" : [ 59, 69 ],
      "id_str" : "14221013",
      "id" : 14221013
    }, {
      "name" : "amy buckland",
      "screen_name" : "jambina",
      "indices" : [ 70, 78 ],
      "id_str" : "11383102",
      "id" : 11383102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "698483700548427776",
  "geo" : { },
  "id_str" : "698515192200740865",
  "in_reply_to_user_id" : 9104202,
  "text" : "@jeroenbosman @rchampieux @MsPhelps @DrFionaLM @neilblairc @nowviskie @jambina great, thanks! :)",
  "id" : 698515192200740865,
  "in_reply_to_status_id" : 698483700548427776,
  "created_at" : "2016-02-13 14:32:54 +0000",
  "in_reply_to_screen_name" : "jeroenbosman",
  "in_reply_to_user_id_str" : "9104202",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/ECUFSSrsZz",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/G9oBXJBwgU\/",
      "display_url" : "instagram.com\/p\/G9oBXJBwgU\/"
    } ]
  },
  "geo" : { },
  "id_str" : "698512423871975424",
  "text" : "4 years ago on this day: first 100 data sets on openSNP. May have been a bit overoptimistic back then. https:\/\/t.co\/ECUFSSrsZz",
  "id" : 698512423871975424,
  "created_at" : "2016-02-13 14:21:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "698411347915120640",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11404567840009, 8.753442027348228 ]
  },
  "id_str" : "698415812361785344",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez thanks! Will you be there?",
  "id" : 698415812361785344,
  "in_reply_to_status_id" : 698411347915120640,
  "created_at" : "2016-02-13 07:58:00 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Biotweeps - Brit",
      "screen_name" : "biotweeps",
      "indices" : [ 0, 10 ],
      "id_str" : "2561407350",
      "id" : 2561407350
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 41 ],
      "url" : "https:\/\/t.co\/d9gmCY9z7C",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/665482858539130880",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "698176093191303168",
  "geo" : { },
  "id_str" : "698178736471044096",
  "in_reply_to_user_id" : 2561407350,
  "text" : "@biotweeps indeed https:\/\/t.co\/d9gmCY9z7C",
  "id" : 698178736471044096,
  "in_reply_to_status_id" : 698176093191303168,
  "created_at" : "2016-02-12 16:15:56 +0000",
  "in_reply_to_screen_name" : "biotweeps",
  "in_reply_to_user_id_str" : "2561407350",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 76 ],
      "url" : "https:\/\/t.co\/SWduzLb64f",
      "expanded_url" : "http:\/\/reddit.com\/r\/gifs\/comments\/34zaxm\/hell_never_be_dry_again\/",
      "display_url" : "reddit.com\/r\/gifs\/comment\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "698176492757450754",
  "text" : "@stopifnot this is a skill i\u2019m also still lacking ;) https:\/\/t.co\/SWduzLb64f",
  "id" : 698176492757450754,
  "created_at" : "2016-02-12 16:07:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "698172130513580033",
  "text" : "@stopifnot more fitting than the waterproofness ;)",
  "id" : 698172130513580033,
  "created_at" : "2016-02-12 15:49:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Martin Ballaschk",
      "screen_name" : "ballaschk",
      "indices" : [ 0, 10 ],
      "id_str" : "29082973",
      "id" : 29082973
    }, {
      "name" : "Caspar C. Mierau",
      "screen_name" : "leitmedium",
      "indices" : [ 11, 22 ],
      "id_str" : "58569837",
      "id" : 58569837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "698154819354259456",
  "geo" : { },
  "id_str" : "698154943430193152",
  "in_reply_to_user_id" : 29082973,
  "text" : "@ballaschk @leitmedium ja, in dem Fall kann man mein OA machen weil man mit dem falschen Publisher ver\u00F6ffentlicht hat.",
  "id" : 698154943430193152,
  "in_reply_to_status_id" : 698154819354259456,
  "created_at" : "2016-02-12 14:41:24 +0000",
  "in_reply_to_screen_name" : "ballaschk",
  "in_reply_to_user_id_str" : "29082973",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Martin Ballaschk",
      "screen_name" : "ballaschk",
      "indices" : [ 0, 10 ],
      "id_str" : "29082973",
      "id" : 29082973
    }, {
      "name" : "Caspar C. Mierau",
      "screen_name" : "leitmedium",
      "indices" : [ 11, 22 ],
      "id_str" : "58569837",
      "id" : 58569837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "698152299936509952",
  "geo" : { },
  "id_str" : "698154205408837632",
  "in_reply_to_user_id" : 29082973,
  "text" : "@ballaschk @leitmedium auch bei green OA kann man ja CC-BY setzen?",
  "id" : 698154205408837632,
  "in_reply_to_status_id" : 698152299936509952,
  "created_at" : "2016-02-12 14:38:28 +0000",
  "in_reply_to_screen_name" : "ballaschk",
  "in_reply_to_user_id_str" : "29082973",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Martin Ballaschk",
      "screen_name" : "ballaschk",
      "indices" : [ 0, 10 ],
      "id_str" : "29082973",
      "id" : 29082973
    }, {
      "name" : "Caspar C. Mierau",
      "screen_name" : "leitmedium",
      "indices" : [ 11, 22 ],
      "id_str" : "58569837",
      "id" : 58569837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "698149762667823105",
  "geo" : { },
  "id_str" : "698150515218247680",
  "in_reply_to_user_id" : 29082973,
  "text" : "@ballaschk @leitmedium ich w\u00FCrde behaupten OA ist heute == \u201Elibre\u201C, siehe Budapest OA Initiative, Bethesda Statement, Berlin Declaration\u2026",
  "id" : 698150515218247680,
  "in_reply_to_status_id" : 698149762667823105,
  "created_at" : "2016-02-12 14:23:48 +0000",
  "in_reply_to_screen_name" : "ballaschk",
  "in_reply_to_user_id_str" : "29082973",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Martin Ballaschk",
      "screen_name" : "ballaschk",
      "indices" : [ 0, 10 ],
      "id_str" : "29082973",
      "id" : 29082973
    }, {
      "name" : "Caspar C. Mierau",
      "screen_name" : "leitmedium",
      "indices" : [ 11, 22 ],
      "id_str" : "58569837",
      "id" : 58569837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "698148645305241606",
  "geo" : { },
  "id_str" : "698149442969591808",
  "in_reply_to_user_id" : 29082973,
  "text" : "@ballaschk @leitmedium und deshalb ist CC-BY-NC-ND _kein_ Open Access, egal was Wiley behauptet\u2026",
  "id" : 698149442969591808,
  "in_reply_to_status_id" : 698148645305241606,
  "created_at" : "2016-02-12 14:19:32 +0000",
  "in_reply_to_screen_name" : "ballaschk",
  "in_reply_to_user_id_str" : "29082973",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/9b5zuziOPL",
      "expanded_url" : "https:\/\/twitter.com\/mims\/status\/698098846375636992",
      "display_url" : "twitter.com\/mims\/status\/69\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "698147772755791872",
  "text" : "What happens if you put the mindset of a Silicon Valley VC into a Markov-Bot? https:\/\/t.co\/9b5zuziOPL",
  "id" : 698147772755791872,
  "created_at" : "2016-02-12 14:12:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "698143413984743425",
  "geo" : { },
  "id_str" : "698143698039734272",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot vielleicht weil der Tweet ein Facebook-Post ist? ;)",
  "id" : 698143698039734272,
  "in_reply_to_status_id" : 698143413984743425,
  "created_at" : "2016-02-12 13:56:43 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Madeleine Price Ball",
      "screen_name" : "madprime",
      "indices" : [ 41, 50 ],
      "id_str" : "71557700",
      "id" : 71557700
    }, {
      "name" : "Steven Keating",
      "screen_name" : "stevenkeating",
      "indices" : [ 51, 65 ],
      "id_str" : "19216179",
      "id" : 19216179
    }, {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 72, 81 ],
      "id_str" : "14245811",
      "id" : 14245811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/9UnsoJKqW9",
      "expanded_url" : "https:\/\/backchannel.com\/our-medical-data-must-become-free-f6d533db6bed#.k26u5lawz",
      "display_url" : "backchannel.com\/our-medical-da\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "698141101694259200",
  "text" : "Our Medical Data Must Become Free, feat. @madprime,@stevenkeating &amp; @wilbanks https:\/\/t.co\/9UnsoJKqW9",
  "id" : 698141101694259200,
  "created_at" : "2016-02-12 13:46:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/82sZnLnic1",
      "expanded_url" : "https:\/\/www.theguardian.com\/science\/the-lay-scientist\/2016\/feb\/12\/is-bb-8-a-woman-artificial-intelligence-gender-identity",
      "display_url" : "theguardian.com\/science\/the-la\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "698138027684732928",
  "text" : "\u00ABwhy are we so determined to assign gender to AI?\u00BB uh, or you know, to humans\u2026  https:\/\/t.co\/82sZnLnic1",
  "id" : 698138027684732928,
  "created_at" : "2016-02-12 13:34:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "698130045035024384",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17289707619302, 8.627677273441064 ]
  },
  "id_str" : "698130863469502464",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot you\u2019ve seen me after a long bath ;)",
  "id" : 698130863469502464,
  "in_reply_to_status_id" : 698130045035024384,
  "created_at" : "2016-02-12 13:05:43 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angel Pizarro",
      "screen_name" : "delagoya",
      "indices" : [ 0, 9 ],
      "id_str" : "6977272",
      "id" : 6977272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "698125760993894400",
  "geo" : { },
  "id_str" : "698126257033236480",
  "in_reply_to_user_id" : 6977272,
  "text" : "@delagoya look into my sad puppy eyes ;)",
  "id" : 698126257033236480,
  "in_reply_to_status_id" : 698125760993894400,
  "created_at" : "2016-02-12 12:47:24 +0000",
  "in_reply_to_screen_name" : "delagoya",
  "in_reply_to_user_id_str" : "6977272",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert",
      "screen_name" : "kventil",
      "indices" : [ 0, 8 ],
      "id_str" : "7431192",
      "id" : 7431192
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "698121537115836416",
  "geo" : { },
  "id_str" : "698121667999068160",
  "in_reply_to_user_id" : 7431192,
  "text" : "@kventil wuff! \uD83D\uDC36",
  "id" : 698121667999068160,
  "in_reply_to_status_id" : 698121537115836416,
  "created_at" : "2016-02-12 12:29:10 +0000",
  "in_reply_to_screen_name" : "kventil",
  "in_reply_to_user_id_str" : "7431192",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/698121440663568384\/photo\/1",
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/8qo6LkDrXm",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CbA5v8-WwAA3KAQ.png",
      "id_str" : "698121438226726912",
      "id" : 698121438226726912,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CbA5v8-WwAA3KAQ.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 591
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 591
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 591
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 591
      } ],
      "display_url" : "pic.twitter.com\/8qo6LkDrXm"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/eWGxVuZzPL",
      "expanded_url" : "https:\/\/www.what-dog.net",
      "display_url" : "what-dog.net"
    } ]
  },
  "geo" : { },
  "id_str" : "698121440663568384",
  "text" : "\u00ABStrong muscular body, smart\u2026\u00BB This totally sounds like me! \u00AB\u2026waterproof coat\u00BB wait, what? https:\/\/t.co\/eWGxVuZzPL https:\/\/t.co\/8qo6LkDrXm",
  "id" : 698121440663568384,
  "created_at" : "2016-02-12 12:28:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DarwinDay",
      "indices" : [ 6, 16 ]
    } ],
    "urls" : [ {
      "indices" : [ 18, 41 ],
      "url" : "https:\/\/t.co\/OijENZA2WX",
      "expanded_url" : "https:\/\/twitter.com\/TheBloodVoyage\/status\/698008077979635712",
      "display_url" : "twitter.com\/TheBloodVoyage\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "698082489710071808",
  "text" : "Happy #DarwinDay! https:\/\/t.co\/OijENZA2WX",
  "id" : 698082489710071808,
  "created_at" : "2016-02-12 09:53:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "herr_schrat",
      "screen_name" : "herr_schrat",
      "indices" : [ 0, 12 ],
      "id_str" : "16066591",
      "id" : 16066591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "698075169512931328",
  "geo" : { },
  "id_str" : "698075318268125184",
  "in_reply_to_user_id" : 16066591,
  "text" : "@herr_schrat wenn du dich bewirbst ist das wie mit den atheists in foxholes \uD83D\uDE09",
  "id" : 698075318268125184,
  "in_reply_to_status_id" : 698075169512931328,
  "created_at" : "2016-02-12 09:25:00 +0000",
  "in_reply_to_screen_name" : "herr_schrat",
  "in_reply_to_user_id_str" : "16066591",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "herr_schrat",
      "screen_name" : "herr_schrat",
      "indices" : [ 0, 12 ],
      "id_str" : "16066591",
      "id" : 16066591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "698071704606736384",
  "geo" : { },
  "id_str" : "698074972632260609",
  "in_reply_to_user_id" : 16066591,
  "text" : "@herr_schrat \uD83D\uDE4F",
  "id" : 698074972632260609,
  "in_reply_to_status_id" : 698071704606736384,
  "created_at" : "2016-02-12 09:23:37 +0000",
  "in_reply_to_screen_name" : "herr_schrat",
  "in_reply_to_user_id_str" : "16066591",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 78 ],
      "url" : "https:\/\/t.co\/gNs0uQmhbU",
      "expanded_url" : "https:\/\/medium.com\/quality-works\/an-inquiry-into-this-lego-star-wars-dinosaur-d47d3a64c3b7#.vtk162dyx",
      "display_url" : "medium.com\/quality-works\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "698057447601209349",
  "text" : "What small details make an ordinary toy extraordinary? https:\/\/t.co\/gNs0uQmhbU",
  "id" : 698057447601209349,
  "created_at" : "2016-02-12 08:13:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nazeefa",
      "screen_name" : "NazeefaFatima",
      "indices" : [ 0, 14 ],
      "id_str" : "37054704",
      "id" : 37054704
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "697971113901629440",
  "geo" : { },
  "id_str" : "698056021516877825",
  "in_reply_to_user_id" : 37054704,
  "text" : "@NazeefaFatima \uD83D\uDC4D",
  "id" : 698056021516877825,
  "in_reply_to_status_id" : 697971113901629440,
  "created_at" : "2016-02-12 08:08:19 +0000",
  "in_reply_to_screen_name" : "NazeefaFatima",
  "in_reply_to_user_id_str" : "37054704",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/OwSCfoUdYA",
      "expanded_url" : "https:\/\/backchannel.com\/war-stories-the-reality-of-aaa-games-development-a70178d7cf1c#.33172norz",
      "display_url" : "backchannel.com\/war-stories-th\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "698054161158553600",
  "text" : "not only game design \u00AB\u2026your ownership evaporates in the sun. And without ownership, there\u2019s no motivation.\u00BB https:\/\/t.co\/OwSCfoUdYA",
  "id" : 698054161158553600,
  "created_at" : "2016-02-12 08:00:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erin Ryan",
      "screen_name" : "erinleeryan",
      "indices" : [ 3, 15 ],
      "id_str" : "68286225",
      "id" : 68286225
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WomenInSTEM",
      "indices" : [ 66, 78 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "698051326543003649",
  "text" : "RT @erinleeryan: And trust me y'all: I notice that as a member of #WomenInSTEM that it's the one woman getting the crap piled while dudes a\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WomenInSTEM",
        "indices" : [ 49, 61 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "697959232033923072",
    "geo" : { },
    "id_str" : "697959502512025600",
    "in_reply_to_user_id" : 68286225,
    "text" : "And trust me y'all: I notice that as a member of #WomenInSTEM that it's the one woman getting the crap piled while dudes are clean.",
    "id" : 697959502512025600,
    "in_reply_to_status_id" : 697959232033923072,
    "created_at" : "2016-02-12 01:44:47 +0000",
    "in_reply_to_screen_name" : "erinleeryan",
    "in_reply_to_user_id_str" : "68286225",
    "user" : {
      "name" : "Erin Ryan",
      "screen_name" : "erinleeryan",
      "protected" : false,
      "id_str" : "68286225",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2743013034\/b0c5b5a2c9afe771a50a0e0c46c84b7a_normal.png",
      "id" : 68286225,
      "verified" : false
    }
  },
  "id" : 698051326543003649,
  "created_at" : "2016-02-12 07:49:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erin Ryan",
      "screen_name" : "erinleeryan",
      "indices" : [ 3, 15 ],
      "id_str" : "68286225",
      "id" : 68286225
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "698051313586798592",
  "text" : "RT @erinleeryan: Ppl who have been angry at me abt embargo? Has not also focused their ire at other person who tweeted cake. Or prof that s\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "697958823403896833",
    "geo" : { },
    "id_str" : "697959232033923072",
    "in_reply_to_user_id" : 68286225,
    "text" : "Ppl who have been angry at me abt embargo? Has not also focused their ire at other person who tweeted cake. Or prof that sent email last wk",
    "id" : 697959232033923072,
    "in_reply_to_status_id" : 697958823403896833,
    "created_at" : "2016-02-12 01:43:43 +0000",
    "in_reply_to_screen_name" : "erinleeryan",
    "in_reply_to_user_id_str" : "68286225",
    "user" : {
      "name" : "Erin Ryan",
      "screen_name" : "erinleeryan",
      "protected" : false,
      "id_str" : "68286225",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2743013034\/b0c5b5a2c9afe771a50a0e0c46c84b7a_normal.png",
      "id" : 68286225,
      "verified" : false
    }
  },
  "id" : 698051313586798592,
  "created_at" : "2016-02-12 07:49:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "malech maltz",
      "screen_name" : "malech",
      "indices" : [ 0, 7 ],
      "id_str" : "784085846391713793",
      "id" : 784085846391713793
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 8, 14 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17157133973134, 8.627704260679897 ]
  },
  "id_str" : "698049589375561729",
  "text" : "@malech @Lobot nope.",
  "id" : 698049589375561729,
  "created_at" : "2016-02-12 07:42:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "697921358001369089",
  "geo" : { },
  "id_str" : "697921412540006402",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez thanks so much! :)",
  "id" : 697921412540006402,
  "in_reply_to_status_id" : 697921358001369089,
  "created_at" : "2016-02-11 23:13:26 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erin Ryan",
      "screen_name" : "erinleeryan",
      "indices" : [ 103, 115 ],
      "id_str" : "68286225",
      "id" : 68286225
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/uxStDjbdyx",
      "expanded_url" : "https:\/\/www.washingtonpost.com\/news\/speaking-of-science\/wp\/2016\/02\/11\/todays-massive-gravitational-wave-news-was-broken-by-a-sheet-cake-really\/?postshare=2021455219540757&tid=ss_tw-bottom",
      "display_url" : "washingtonpost.com\/news\/speaking-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "697899514116644864",
  "text" : "\u00ABThis is the 2nd time I've wound up\u00A0tweeting a cake before an embargo!\u00BB \uD83C\uDF70\uD83D\uDC96 My science hero of the day: @erinleeryan https:\/\/t.co\/uxStDjbdyx",
  "id" : 697899514116644864,
  "created_at" : "2016-02-11 21:46:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 70 ],
      "url" : "https:\/\/t.co\/afMY8LdMan",
      "expanded_url" : "http:\/\/www.stereoboard.com\/content\/view\/196488\/9",
      "display_url" : "stereoboard.com\/content\/view\/1\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.107507, 8.7706 ]
  },
  "id_str" : "697889663290363904",
  "text" : "Ho hey, what's been taking you nearly 4 years? https:\/\/t.co\/afMY8LdMan",
  "id" : 697889663290363904,
  "created_at" : "2016-02-11 21:07:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 46 ],
      "url" : "https:\/\/t.co\/JVgbwYQRYV",
      "expanded_url" : "https:\/\/twitter.com\/mbeisen\/status\/697854177666412544",
      "display_url" : "twitter.com\/mbeisen\/status\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11404674762152, 8.753447905823496 ]
  },
  "id_str" : "697866125762289665",
  "text" : "The Internet of Stings https:\/\/t.co\/JVgbwYQRYV",
  "id" : 697866125762289665,
  "created_at" : "2016-02-11 19:33:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 141 ],
      "url" : "https:\/\/t.co\/QDvjeoOoe3",
      "expanded_url" : "https:\/\/github.com\/openSNP\/snpr\/issues\/252",
      "display_url" : "github.com\/openSNP\/snpr\/i\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11373472494522, 8.753634308792796 ]
  },
  "id_str" : "697862386645127172",
  "text" : "US crowd: Fitbit will soon switch their API to Oauth2 &amp; openSNP still needs to do it. Help is deeply appreciated! https:\/\/t.co\/QDvjeoOoe3",
  "id" : 697862386645127172,
  "created_at" : "2016-02-11 19:18:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nazeefa",
      "screen_name" : "NazeefaFatima",
      "indices" : [ 3, 17 ],
      "id_str" : "37054704",
      "id" : 37054704
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WomenInSTEM",
      "indices" : [ 81, 93 ]
    }, {
      "text" : "Womeninbioinformatics",
      "indices" : [ 94, 116 ]
    }, {
      "text" : "bioinformatics",
      "indices" : [ 117, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "697786141806878720",
  "text" : "RT @NazeefaFatima: Happy 1st International Day of Women and Girls in Science!! \uD83D\uDE0A #WomenInSTEM #Womeninbioinformatics #bioinformatics https:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/NazeefaFatima\/status\/697763906996060160\/photo\/1",
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/GSgjX6zAXg",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Ca70kicXIAEOrgT.jpg",
        "id_str" : "697763900847235073",
        "id" : 697763900847235073,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ca70kicXIAEOrgT.jpg",
        "sizes" : [ {
          "h" : 720,
          "resize" : "fit",
          "w" : 720
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 720
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 720
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/GSgjX6zAXg"
      } ],
      "hashtags" : [ {
        "text" : "WomenInSTEM",
        "indices" : [ 62, 74 ]
      }, {
        "text" : "Womeninbioinformatics",
        "indices" : [ 75, 97 ]
      }, {
        "text" : "bioinformatics",
        "indices" : [ 98, 113 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "697763906996060160",
    "text" : "Happy 1st International Day of Women and Girls in Science!! \uD83D\uDE0A #WomenInSTEM #Womeninbioinformatics #bioinformatics https:\/\/t.co\/GSgjX6zAXg",
    "id" : 697763906996060160,
    "created_at" : "2016-02-11 12:47:33 +0000",
    "user" : {
      "name" : "Nazeefa",
      "screen_name" : "NazeefaFatima",
      "protected" : false,
      "id_str" : "37054704",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/930210077885202432\/DY8D8hGM_normal.jpg",
      "id" : 37054704,
      "verified" : false
    }
  },
  "id" : 697786141806878720,
  "created_at" : "2016-02-11 14:15:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/QDvjeoOoe3",
      "expanded_url" : "https:\/\/github.com\/openSNP\/snpr\/issues\/252",
      "display_url" : "github.com\/openSNP\/snpr\/i\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "697722808806350848",
  "text" : "Fitbit will soon switch their API to Oauth2 and openSNP still needs to make the switch. Help is deeply appreciated! https:\/\/t.co\/QDvjeoOoe3",
  "id" : 697722808806350848,
  "created_at" : "2016-02-11 10:04:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonas",
      "screen_name" : "lsanoj",
      "indices" : [ 0, 7 ],
      "id_str" : "18918915",
      "id" : 18918915
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 73 ],
      "url" : "https:\/\/t.co\/dB0DJt6TSt",
      "expanded_url" : "http:\/\/www.cokelogic.com\/temp\/Steve-X-Ray.jpg",
      "display_url" : "cokelogic.com\/temp\/Steve-X-R\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "697572973662887936",
  "geo" : { },
  "id_str" : "697573498835828736",
  "in_reply_to_user_id" : 18918915,
  "text" : "@lsanoj da bin ich wohl mit der Maus ausgerutscht https:\/\/t.co\/dB0DJt6TSt",
  "id" : 697573498835828736,
  "in_reply_to_status_id" : 697572973662887936,
  "created_at" : "2016-02-11 00:10:57 +0000",
  "in_reply_to_screen_name" : "lsanoj",
  "in_reply_to_user_id_str" : "18918915",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bede Constantinides",
      "screen_name" : "beconstant",
      "indices" : [ 0, 11 ],
      "id_str" : "112876914",
      "id" : 112876914
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "697573294137024512",
  "geo" : { },
  "id_str" : "697573438446247936",
  "in_reply_to_user_id" : 112876914,
  "text" : "@beconstant aye, but totally agree on your points, interesting topic in itself :)",
  "id" : 697573438446247936,
  "in_reply_to_status_id" : 697573294137024512,
  "created_at" : "2016-02-11 00:10:42 +0000",
  "in_reply_to_screen_name" : "beconstant",
  "in_reply_to_user_id_str" : "112876914",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 7, 30 ],
      "url" : "https:\/\/t.co\/M8cciZVz74",
      "expanded_url" : "https:\/\/twitter.com\/SteveStuWill\/status\/697569979982458880",
      "display_url" : "twitter.com\/SteveStuWill\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "697570813369847808",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot https:\/\/t.co\/M8cciZVz74",
  "id" : 697570813369847808,
  "created_at" : "2016-02-11 00:00:16 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bede Constantinides",
      "screen_name" : "beconstant",
      "indices" : [ 0, 11 ],
      "id_str" : "112876914",
      "id" : 112876914
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "697569946465890305",
  "geo" : { },
  "id_str" : "697570149994467330",
  "in_reply_to_user_id" : 112876914,
  "text" : "@beconstant i mean the shorter the trip the more time you spend getting to cruising speed, at least proportionally.",
  "id" : 697570149994467330,
  "in_reply_to_status_id" : 697569946465890305,
  "created_at" : "2016-02-10 23:57:38 +0000",
  "in_reply_to_screen_name" : "beconstant",
  "in_reply_to_user_id_str" : "112876914",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 68 ],
      "url" : "https:\/\/t.co\/EaJS6L7wrU",
      "expanded_url" : "http:\/\/www.smbc-comics.com\/index.php?id=4015",
      "display_url" : "smbc-comics.com\/index.php?id=4\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "697569453949775872",
  "text" : "I always felt philosophy was my true calling https:\/\/t.co\/EaJS6L7wrU",
  "id" : 697569453949775872,
  "created_at" : "2016-02-10 23:54:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/W0LrnQNIqC",
      "expanded_url" : "http:\/\/journals.plos.org\/plosone\/article?id=10.1371\/journal.pone.0148913",
      "display_url" : "journals.plos.org\/plosone\/articl\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "697568135700946944",
  "text" : "\u00ABFurther We Travel the Faster We Go\u00BB Did I miss something or is this rather obvious? https:\/\/t.co\/W0LrnQNIqC",
  "id" : 697568135700946944,
  "created_at" : "2016-02-10 23:49:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 73 ],
      "url" : "https:\/\/t.co\/eDx6m0SOpq",
      "expanded_url" : "https:\/\/www.washingtonpost.com\/news\/speaking-of-science\/wp\/2016\/02\/10\/the-shifting-tide-of-sexual-harassment-in-science\/?postshare=9591455135446240&tid=ss_tw",
      "display_url" : "washingtonpost.com\/news\/speaking-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "697528353587359744",
  "text" : "The shifting tide of sexual harassment in science https:\/\/t.co\/eDx6m0SOpq",
  "id" : 697528353587359744,
  "created_at" : "2016-02-10 21:11:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Loman",
      "screen_name" : "pathogenomenick",
      "indices" : [ 0, 16 ],
      "id_str" : "85906238",
      "id" : 85906238
    }, {
      "name" : "Jason Chin",
      "screen_name" : "infoecho",
      "indices" : [ 17, 26 ],
      "id_str" : "29575969",
      "id" : 29575969
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "697492170316640256",
  "geo" : { },
  "id_str" : "697508583982899200",
  "in_reply_to_user_id" : 85906238,
  "text" : "@pathogenomenick @infoecho is the gray thing in the back a MinION or a battery pack? ;)",
  "id" : 697508583982899200,
  "in_reply_to_status_id" : 697492170316640256,
  "created_at" : "2016-02-10 19:53:00 +0000",
  "in_reply_to_screen_name" : "pathogenomenick",
  "in_reply_to_user_id_str" : "85906238",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 37 ],
      "url" : "https:\/\/t.co\/CBLqiYAtWO",
      "expanded_url" : "http:\/\/whatshouldwecallgradschool.tumblr.com\/post\/139008806134\/getting-stuff-done",
      "display_url" : "whatshouldwecallgradschool.tumblr.com\/post\/139008806\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "697453810248241153",
  "text" : "100% accurate https:\/\/t.co\/CBLqiYAtWO",
  "id" : 697453810248241153,
  "created_at" : "2016-02-10 16:15:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kaitlin Thaney \uD83D\uDC81\uD83C\uDFFB",
      "screen_name" : "kaythaney",
      "indices" : [ 3, 13 ],
      "id_str" : "22839233",
      "id" : 22839233
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "697430757581701120",
  "text" : "RT @kaythaney: We led a Working Open wkshp last week in Berlin. Some great resources, exercises + session transcriptions here: https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 112, 135 ],
        "url" : "https:\/\/t.co\/k8DBZGL7qT",
        "expanded_url" : "http:\/\/mozillascience.github.io\/working-open-workshop\/index.html",
        "display_url" : "mozillascience.github.io\/working-open-w\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "697424873984020480",
    "text" : "We led a Working Open wkshp last week in Berlin. Some great resources, exercises + session transcriptions here: https:\/\/t.co\/k8DBZGL7qT",
    "id" : 697424873984020480,
    "created_at" : "2016-02-10 14:20:22 +0000",
    "user" : {
      "name" : "Kaitlin Thaney \uD83D\uDC81\uD83C\uDFFB",
      "screen_name" : "kaythaney",
      "protected" : false,
      "id_str" : "22839233",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/932288468029509632\/_I0e0wgc_normal.jpg",
      "id" : 22839233,
      "verified" : false
    }
  },
  "id" : 697430757581701120,
  "created_at" : "2016-02-10 14:43:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mick Watson",
      "screen_name" : "BioMickWatson",
      "indices" : [ 0, 14 ],
      "id_str" : "228586748",
      "id" : 228586748
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "697418080511725569",
  "geo" : { },
  "id_str" : "697430074266669056",
  "in_reply_to_user_id" : 228586748,
  "text" : "@BioMickWatson didn\u2019t know you were inviting me!",
  "id" : 697430074266669056,
  "in_reply_to_status_id" : 697418080511725569,
  "created_at" : "2016-02-10 14:41:01 +0000",
  "in_reply_to_screen_name" : "BioMickWatson",
  "in_reply_to_user_id_str" : "228586748",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "quantifiedself",
      "indices" : [ 75, 90 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "697394182835609600",
  "text" : "Is there already a Ruby gem that enables communication with many different #quantifiedself resources?",
  "id" : 697394182835609600,
  "created_at" : "2016-02-10 12:18:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 54 ],
      "url" : "https:\/\/t.co\/KucfaidMXy",
      "expanded_url" : "http:\/\/bigthink.com\/neurobonkers\/a-pirate-bay-for-science",
      "display_url" : "bigthink.com\/neurobonkers\/a\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "697393469065732096",
  "text" : "Meet the Robin Hood of Science https:\/\/t.co\/KucfaidMXy",
  "id" : 697393469065732096,
  "created_at" : "2016-02-10 12:15:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/x6wRfsibWz",
      "expanded_url" : "https:\/\/ak-hdl.buzzfed.com\/static\/enhanced\/webdr03\/2013\/1\/22\/18\/anigif_enhanced-buzz-32048-1358898498-3.gif",
      "display_url" : "ak-hdl.buzzfed.com\/static\/enhance\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "697350117653901312",
  "text" : "Because, which lecture couldn\u2019t be improved by a gif of a dog eating pie? https:\/\/t.co\/x6wRfsibWz",
  "id" : 697350117653901312,
  "created_at" : "2016-02-10 09:23:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 49 ],
      "url" : "https:\/\/t.co\/sU3Dmw0q1Z",
      "expanded_url" : "https:\/\/github.com\/gedankenstuecke\/OSRR_course\/commit\/5a5ab737473e0d4e4132593fc511fdb5d122dd6d",
      "display_url" : "github.com\/gedankenstueck\u2026"
    }, {
      "indices" : [ 50, 73 ],
      "url" : "https:\/\/t.co\/rbRTbQsNi2",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/697179080366620672",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "697179080366620672",
  "geo" : { },
  "id_str" : "697349835628875776",
  "in_reply_to_user_id" : 14286491,
  "text" : "made good on that promise https:\/\/t.co\/sU3Dmw0q1Z https:\/\/t.co\/rbRTbQsNi2",
  "id" : 697349835628875776,
  "in_reply_to_status_id" : 697179080366620672,
  "created_at" : "2016-02-10 09:22:11 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mathias Schindler",
      "screen_name" : "presroi",
      "indices" : [ 0, 8 ],
      "id_str" : "20447568",
      "id" : 20447568
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 9, 18 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 63 ],
      "url" : "https:\/\/t.co\/d9gmCY9z7C",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/665482858539130880",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "697346891609174016",
  "geo" : { },
  "id_str" : "697347476731400192",
  "in_reply_to_user_id" : 20447568,
  "text" : "@presroi @Senficon tell me  about it ;) https:\/\/t.co\/d9gmCY9z7C",
  "id" : 697347476731400192,
  "in_reply_to_status_id" : 697346891609174016,
  "created_at" : "2016-02-10 09:12:49 +0000",
  "in_reply_to_screen_name" : "presroi",
  "in_reply_to_user_id_str" : "20447568",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/VTi1RDn7gD",
      "expanded_url" : "https:\/\/twitter.com\/Senficon\/status\/697328416266264576",
      "display_url" : "twitter.com\/Senficon\/statu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "697346057550827520",
  "text" : "Someone write a dystopian SF novel where people are hunted because of the \u00A9\uFE0F-infringements they\u2019ve inked onto them. https:\/\/t.co\/VTi1RDn7gD",
  "id" : 697346057550827520,
  "created_at" : "2016-02-10 09:07:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cormac R. McDarwin",
      "screen_name" : "TheBloodVoyage",
      "indices" : [ 7, 22 ],
      "id_str" : "4825733537",
      "id" : 4825733537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "697344888434749440",
  "text" : "By now @TheBloodVoyage is getting retweeted by some South American Twitter bots because it mentions some landmarks m)",
  "id" : 697344888434749440,
  "created_at" : "2016-02-10 09:02:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 76 ],
      "url" : "https:\/\/t.co\/t8QnHGULjg",
      "expanded_url" : "http:\/\/i.imgur.com\/DYROraP.gifv",
      "display_url" : "i.imgur.com\/DYROraP.gifv"
    } ]
  },
  "geo" : { },
  "id_str" : "697211879601672192",
  "text" : "Jumping up and down the floor, my head is an animal\u2026 https:\/\/t.co\/t8QnHGULjg",
  "id" : 697211879601672192,
  "created_at" : "2016-02-10 00:14:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "werwitwe",
      "screen_name" : "nachtrabend",
      "indices" : [ 0, 12 ],
      "id_str" : "1393009718",
      "id" : 1393009718
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "697188927648743425",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06101773590786, 8.818584065892564 ]
  },
  "id_str" : "697192047644667904",
  "in_reply_to_user_id" : 1393009718,
  "text" : "@nachtrabend vielen vielen Dank \u2764\uFE0F",
  "id" : 697192047644667904,
  "in_reply_to_status_id" : 697188927648743425,
  "created_at" : "2016-02-09 22:55:12 +0000",
  "in_reply_to_screen_name" : "nachtrabend",
  "in_reply_to_user_id_str" : "1393009718",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christie Bahlai",
      "screen_name" : "cbahlai",
      "indices" : [ 3, 11 ],
      "id_str" : "958649520",
      "id" : 958649520
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 13, 29 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "697179143184740356",
  "text" : "RT @cbahlai: @gedankenstuecke What? it's 11.6734+\/-12.45021% more scienceier than a 2D pie chart. ;)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 0, 16 ],
        "id_str" : "14286491",
        "id" : 14286491
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "697177993614123009",
    "geo" : { },
    "id_str" : "697178544007467013",
    "in_reply_to_user_id" : 14286491,
    "text" : "@gedankenstuecke What? it's 11.6734+\/-12.45021% more scienceier than a 2D pie chart. ;)",
    "id" : 697178544007467013,
    "in_reply_to_status_id" : 697177993614123009,
    "created_at" : "2016-02-09 22:01:32 +0000",
    "in_reply_to_screen_name" : "gedankenstuecke",
    "in_reply_to_user_id_str" : "14286491",
    "user" : {
      "name" : "Christie Bahlai",
      "screen_name" : "cbahlai",
      "protected" : false,
      "id_str" : "958649520",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/705843854973530112\/S992pAjY_normal.jpg",
      "id" : 958649520,
      "verified" : false
    }
  },
  "id" : 697179143184740356,
  "created_at" : "2016-02-09 22:03:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christie Bahlai",
      "screen_name" : "cbahlai",
      "indices" : [ 0, 8 ],
      "id_str" : "958649520",
      "id" : 958649520
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "697178544007467013",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06098621995194, 8.818308971830474 ]
  },
  "id_str" : "697179080366620672",
  "in_reply_to_user_id" : 958649520,
  "text" : "@cbahlai I will write \u2018No 3D pies\u2019 into the OSRR lecture on data viz. only exception: the 3D pie is tasty and delivered to my door. ;)",
  "id" : 697179080366620672,
  "in_reply_to_status_id" : 697178544007467013,
  "created_at" : "2016-02-09 22:03:40 +0000",
  "in_reply_to_screen_name" : "cbahlai",
  "in_reply_to_user_id_str" : "958649520",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 67 ],
      "url" : "https:\/\/t.co\/luwXHfEZIa",
      "expanded_url" : "https:\/\/twitter.com\/thePeerJ\/status\/696997255744765952",
      "display_url" : "twitter.com\/thePeerJ\/statu\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06072910507215, 8.818368064247833 ]
  },
  "id_str" : "697177993614123009",
  "text" : "Key Figure Error #1: Goddamn 3D pie charts. https:\/\/t.co\/luwXHfEZIa",
  "id" : 697177993614123009,
  "created_at" : "2016-02-09 21:59:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Janet D. Stemwedel",
      "screen_name" : "docfreeride",
      "indices" : [ 3, 15 ],
      "id_str" : "17175139",
      "id" : 17175139
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/bNyZvQJPEz",
      "expanded_url" : "http:\/\/www.sciencemag.org\/news\/2016\/02\/sexual-misconduct-case-has-rocked-anthropology",
      "display_url" : "sciencemag.org\/news\/2016\/02\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "697168720603561984",
  "text" : "RT @docfreeride: In case you thought it was just astronomy, or biology, or philosophy\u2026 https:\/\/t.co\/bNyZvQJPEz",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 70, 93 ],
        "url" : "https:\/\/t.co\/bNyZvQJPEz",
        "expanded_url" : "http:\/\/www.sciencemag.org\/news\/2016\/02\/sexual-misconduct-case-has-rocked-anthropology",
        "display_url" : "sciencemag.org\/news\/2016\/02\/s\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "697111248408694784",
    "text" : "In case you thought it was just astronomy, or biology, or philosophy\u2026 https:\/\/t.co\/bNyZvQJPEz",
    "id" : 697111248408694784,
    "created_at" : "2016-02-09 17:34:07 +0000",
    "user" : {
      "name" : "Janet D. Stemwedel",
      "screen_name" : "docfreeride",
      "protected" : false,
      "id_str" : "17175139",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2750509030\/a5f3cdbcdf6ed45f411f87cfc4e33736_normal.jpeg",
      "id" : 17175139,
      "verified" : true
    }
  },
  "id" : 697168720603561984,
  "created_at" : "2016-02-09 21:22:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shaun Jackman",
      "screen_name" : "sjackman",
      "indices" : [ 3, 12 ],
      "id_str" : "8779352",
      "id" : 8779352
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "697122860679241729",
  "text" : "RT @sjackman: I only ever accidentally press \u2318Q to quit Chrome and lose all my tabs. I just discovered \"Hold \u2318Q to Quit\" setting. https:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/esuAQkUjFp",
        "expanded_url" : "http:\/\/lifehacker.com\/5784153\/how-to-bring-back-the-hold-q-to-quit-prompt-in-google-chrome",
        "display_url" : "lifehacker.com\/5784153\/how-to\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "697114146756624384",
    "text" : "I only ever accidentally press \u2318Q to quit Chrome and lose all my tabs. I just discovered \"Hold \u2318Q to Quit\" setting. https:\/\/t.co\/esuAQkUjFp",
    "id" : 697114146756624384,
    "created_at" : "2016-02-09 17:45:38 +0000",
    "user" : {
      "name" : "Shaun Jackman",
      "screen_name" : "sjackman",
      "protected" : false,
      "id_str" : "8779352",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/751888643460063232\/MfIOaNw2_normal.jpg",
      "id" : 8779352,
      "verified" : false
    }
  },
  "id" : 697122860679241729,
  "created_at" : "2016-02-09 18:20:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steph\u24D0nie Wright",
      "screen_name" : "shefw",
      "indices" : [ 0, 6 ],
      "id_str" : "48636190",
      "id" : 48636190
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "697106146121744384",
  "geo" : { },
  "id_str" : "697106906800902144",
  "in_reply_to_user_id" : 48636190,
  "text" : "@shefw thanks \uD83C\uDF89",
  "id" : 697106906800902144,
  "in_reply_to_status_id" : 697106146121744384,
  "created_at" : "2016-02-09 17:16:52 +0000",
  "in_reply_to_screen_name" : "shefw",
  "in_reply_to_user_id_str" : "48636190",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael R. Crusoe",
      "screen_name" : "biocrusoe",
      "indices" : [ 0, 10 ],
      "id_str" : "17645638",
      "id" : 17645638
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 17, 26 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "697089128744284160",
  "geo" : { },
  "id_str" : "697094583155605508",
  "in_reply_to_user_id" : 17645638,
  "text" : "@biocrusoe maybe @Senficon has some tips or know people who have some.",
  "id" : 697094583155605508,
  "in_reply_to_status_id" : 697089128744284160,
  "created_at" : "2016-02-09 16:27:54 +0000",
  "in_reply_to_screen_name" : "biocrusoe",
  "in_reply_to_user_id_str" : "17645638",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Abby Cabunoc Mayes",
      "screen_name" : "abbycabs",
      "indices" : [ 0, 9 ],
      "id_str" : "395367768",
      "id" : 395367768
    }, {
      "name" : "Kaitlin Thaney \uD83D\uDC81\uD83C\uDFFB",
      "screen_name" : "kaythaney",
      "indices" : [ 10, 20 ],
      "id_str" : "22839233",
      "id" : 22839233
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/Y2E9VbubKB",
      "expanded_url" : "https:\/\/www.etsy.com\/listing\/190446575\/human-chromosome-rings-in-silver?ref=listing-shop-header-3",
      "display_url" : "etsy.com\/listing\/190446\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "697084912864772097",
  "geo" : { },
  "id_str" : "697093685004103680",
  "in_reply_to_user_id" : 395367768,
  "text" : "@abbycabs @kaythaney btw, the ring the two of you photographed can be found here https:\/\/t.co\/Y2E9VbubKB",
  "id" : 697093685004103680,
  "in_reply_to_status_id" : 697084912864772097,
  "created_at" : "2016-02-09 16:24:20 +0000",
  "in_reply_to_screen_name" : "abbycabs",
  "in_reply_to_user_id_str" : "395367768",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Abby Cabunoc Mayes",
      "screen_name" : "abbycabs",
      "indices" : [ 0, 9 ],
      "id_str" : "395367768",
      "id" : 395367768
    }, {
      "name" : "Kaitlin Thaney \uD83D\uDC81\uD83C\uDFFB",
      "screen_name" : "kaythaney",
      "indices" : [ 10, 20 ],
      "id_str" : "22839233",
      "id" : 22839233
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "697084912864772097",
  "geo" : { },
  "id_str" : "697093398029856768",
  "in_reply_to_user_id" : 395367768,
  "text" : "@abbycabs @kaythaney looks great! \uD83D\uDC96",
  "id" : 697093398029856768,
  "in_reply_to_status_id" : 697084912864772097,
  "created_at" : "2016-02-09 16:23:12 +0000",
  "in_reply_to_screen_name" : "abbycabs",
  "in_reply_to_user_id_str" : "395367768",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Conner Habib",
      "screen_name" : "ConnerHabib",
      "indices" : [ 0, 12 ],
      "id_str" : "27513314",
      "id" : 27513314
    }, {
      "name" : "Will Canine",
      "screen_name" : "willcanine",
      "indices" : [ 13, 24 ],
      "id_str" : "35675002",
      "id" : 35675002
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "697066704573059072",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17211969568903, 8.627706201977208 ]
  },
  "id_str" : "697066793064595456",
  "in_reply_to_user_id" : 27513314,
  "text" : "@ConnerHabib @willcanine i got the hardcover one :)",
  "id" : 697066793064595456,
  "in_reply_to_status_id" : 697066704573059072,
  "created_at" : "2016-02-09 14:37:28 +0000",
  "in_reply_to_screen_name" : "ConnerHabib",
  "in_reply_to_user_id_str" : "27513314",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 69 ],
      "url" : "https:\/\/t.co\/KmnBBcQzvf",
      "expanded_url" : "http:\/\/imgur.com\/P1Q0VrO",
      "display_url" : "imgur.com\/P1Q0VrO"
    } ]
  },
  "in_reply_to_status_id_str" : "697048954161205249",
  "geo" : { },
  "id_str" : "697049884164288512",
  "in_reply_to_user_id" : 14286491,
  "text" : "How I assume the k\u0101k\u0101p\u014D are feeling right now https:\/\/t.co\/KmnBBcQzvf",
  "id" : 697049884164288512,
  "in_reply_to_status_id" : 697048954161205249,
  "created_at" : "2016-02-09 13:30:17 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 58, 67 ],
      "id_str" : "14861745",
      "id" : 14861745
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 68, 74 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/daidnooWIS",
      "expanded_url" : "http:\/\/www.engadget.com\/2016\/02\/05\/scientists-want-to-sequence-entire-kakapo-population\/",
      "display_url" : "engadget.com\/2016\/02\/05\/sci\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "697048954161205249",
  "text" : "That\u2019s a fun project: Sequencing every single k\u0101k\u0101p\u014D! \/cc @Senficon @Lobot https:\/\/t.co\/daidnooWIS",
  "id" : 697048954161205249,
  "created_at" : "2016-02-09 13:26:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Will Canine",
      "screen_name" : "willcanine",
      "indices" : [ 0, 11 ],
      "id_str" : "35675002",
      "id" : 35675002
    }, {
      "name" : "Conner Habib",
      "screen_name" : "ConnerHabib",
      "indices" : [ 12, 24 ],
      "id_str" : "27513314",
      "id" : 27513314
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "697045947507937280",
  "geo" : { },
  "id_str" : "697046374538412033",
  "in_reply_to_user_id" : 35675002,
  "text" : "@willcanine @ConnerHabib i haven\u2019t read this, so hard to say :)",
  "id" : 697046374538412033,
  "in_reply_to_status_id" : 697045947507937280,
  "created_at" : "2016-02-09 13:16:20 +0000",
  "in_reply_to_screen_name" : "willcanine",
  "in_reply_to_user_id_str" : "35675002",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Will Canine",
      "screen_name" : "willcanine",
      "indices" : [ 0, 11 ],
      "id_str" : "35675002",
      "id" : 35675002
    }, {
      "name" : "Conner Habib",
      "screen_name" : "ConnerHabib",
      "indices" : [ 12, 24 ],
      "id_str" : "27513314",
      "id" : 27513314
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "697045077466746880",
  "geo" : { },
  "id_str" : "697045400625225729",
  "in_reply_to_user_id" : 35675002,
  "text" : "@willcanine @ConnerHabib yes, try grabbing a second hand copy if you can, it\u2019s out of print iirc.",
  "id" : 697045400625225729,
  "in_reply_to_status_id" : 697045077466746880,
  "created_at" : "2016-02-09 13:12:28 +0000",
  "in_reply_to_screen_name" : "willcanine",
  "in_reply_to_user_id_str" : "35675002",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pushbullet",
      "screen_name" : "pushbullet",
      "indices" : [ 23, 34 ],
      "id_str" : "879114595",
      "id" : 879114595
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "697027276001689600",
  "text" : "is there any CLI-based @pushbullet receiver for MacOS? Want to listen for new ones and then trigger my blink(1).",
  "id" : 697027276001689600,
  "created_at" : "2016-02-09 12:00:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 37 ],
      "url" : "https:\/\/t.co\/R7XegtQdNX",
      "expanded_url" : "https:\/\/twitter.com\/bortofdarkness\/status\/696921020054302720",
      "display_url" : "twitter.com\/bortofdarkness\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17227448711595, 8.627646443071368 ]
  },
  "id_str" : "697002648608882688",
  "text" : "mind blown m) https:\/\/t.co\/R7XegtQdNX",
  "id" : 697002648608882688,
  "created_at" : "2016-02-09 10:22:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "696996876428689408",
  "text" : "While preparing a talk-repo for openSNP couldn\u2019t find any slides for 2013. Calendar empty too. Seems I didn\u2019t give any talks for a year?! \uD83D\uDE31",
  "id" : 696996876428689408,
  "created_at" : "2016-02-09 09:59:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : ".",
      "screen_name" : "punkish",
      "indices" : [ 0, 8 ],
      "id_str" : "15322269",
      "id" : 15322269
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "696991640481878017",
  "geo" : { },
  "id_str" : "696991759272960000",
  "in_reply_to_user_id" : 15322269,
  "text" : "@punkish yes, I was and am, but the contract would have ended soon.",
  "id" : 696991759272960000,
  "in_reply_to_status_id" : 696991640481878017,
  "created_at" : "2016-02-09 09:39:19 +0000",
  "in_reply_to_screen_name" : "punkish",
  "in_reply_to_user_id_str" : "15322269",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "696988937810808832",
  "geo" : { },
  "id_str" : "696989712087650304",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot  one more year to figure out how to be unemployed then! \u00AF\\_(\u30C4)_\/\u00AF",
  "id" : 696989712087650304,
  "in_reply_to_status_id" : 696988937810808832,
  "created_at" : "2016-02-09 09:31:11 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Head",
      "screen_name" : "betatim",
      "indices" : [ 0, 8 ],
      "id_str" : "18881614",
      "id" : 18881614
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "696973441073836033",
  "geo" : { },
  "id_str" : "696973572317777920",
  "in_reply_to_user_id" : 18881614,
  "text" : "@betatim finish my PhD, but w\/ a contract as opposed w\/o :D",
  "id" : 696973572317777920,
  "in_reply_to_status_id" : 696973441073836033,
  "created_at" : "2016-02-09 08:27:03 +0000",
  "in_reply_to_screen_name" : "betatim",
  "in_reply_to_user_id_str" : "18881614",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "696972466007207937",
  "text" : "guess who _won\u2019t_ be unemployed come May. \\o\/",
  "id" : 696972466007207937,
  "created_at" : "2016-02-09 08:22:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 52 ],
      "url" : "https:\/\/t.co\/tiVHmBCiub",
      "expanded_url" : "http:\/\/www.theallusionist.org\/allusionist\/wltm-ii",
      "display_url" : "theallusionist.org\/allusionist\/wl\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "696967805959274497",
  "text" : "data mining your way to love https:\/\/t.co\/tiVHmBCiub",
  "id" : 696967805959274497,
  "created_at" : "2016-02-09 08:04:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Conner Habib",
      "screen_name" : "ConnerHabib",
      "indices" : [ 0, 12 ],
      "id_str" : "27513314",
      "id" : 27513314
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "696840511420694528",
  "geo" : { },
  "id_str" : "696840715997990912",
  "in_reply_to_user_id" : 27513314,
  "text" : "@ConnerHabib you just became even cooler in my eyes \uD83D\uDE02",
  "id" : 696840715997990912,
  "in_reply_to_status_id" : 696840511420694528,
  "created_at" : "2016-02-08 23:39:08 +0000",
  "in_reply_to_screen_name" : "ConnerHabib",
  "in_reply_to_user_id_str" : "27513314",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Conner Habib",
      "screen_name" : "ConnerHabib",
      "indices" : [ 10, 22 ],
      "id_str" : "27513314",
      "id" : 27513314
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "696821255866028033",
  "geo" : { },
  "id_str" : "696838807501537281",
  "in_reply_to_user_id" : 14286491,
  "text" : "Thanks to @ConnerHabib for motivating me to read a bit more of Lynn\u2019s work recently.",
  "id" : 696838807501537281,
  "in_reply_to_status_id" : 696821255866028033,
  "created_at" : "2016-02-08 23:31:33 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/696821255866028033\/photo\/1",
      "indices" : [ 42, 65 ],
      "url" : "https:\/\/t.co\/Z8QO8v1JYS",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CaubPNGW4AADnZF.jpg",
      "id_str" : "696821252875542528",
      "id" : 696821252875542528,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CaubPNGW4AADnZF.jpg",
      "sizes" : [ {
        "h" : 2448,
        "resize" : "fit",
        "w" : 3264
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/Z8QO8v1JYS"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11404425511157, 8.753446865877383 ]
  },
  "id_str" : "696821255866028033",
  "text" : "Found in Lynn Margulis\u2019 \u00ABWhat is Life?\u00BB \uD83D\uDC96 https:\/\/t.co\/Z8QO8v1JYS",
  "id" : 696821255866028033,
  "created_at" : "2016-02-08 22:21:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/NMWO0lD1jG",
      "expanded_url" : "https:\/\/twitter.com\/sarahkendzior\/status\/696465743198597120",
      "display_url" : "twitter.com\/sarahkendzior\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "696811588569931776",
  "text" : "\u00ABFully 50% of the potential userbase is subject near-certain harassment and abuse if they reveal their gender.\u00BB https:\/\/t.co\/NMWO0lD1jG",
  "id" : 696811588569931776,
  "created_at" : "2016-02-08 21:43:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/ncHAzE05rn",
      "expanded_url" : "http:\/\/i.imgur.com\/x1rM5B4.png",
      "display_url" : "i.imgur.com\/x1rM5B4.png"
    } ]
  },
  "in_reply_to_status_id_str" : "696804009961779200",
  "geo" : { },
  "id_str" : "696806185169764353",
  "in_reply_to_user_id" : 14286491,
  "text" : "\u00ABFlorida Man uncovers the evil conspiracy of a president who wants \u201Echange\u201C, while all others missed subtle signs.\u00BB https:\/\/t.co\/ncHAzE05rn",
  "id" : 696806185169764353,
  "in_reply_to_status_id" : 696804009961779200,
  "created_at" : "2016-02-08 21:21:55 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/LXYWAmntNg",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=U_Gg6ggghoI&feature=youtu.be&app=desktop",
      "display_url" : "youtube.com\/watch?v=U_Gg6g\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "696804009961779200",
  "text" : "The best thing is you could watch this clip on YouTubeRepeat and you wouldn\u2019t really notice when it restarts. https:\/\/t.co\/LXYWAmntNg",
  "id" : 696804009961779200,
  "created_at" : "2016-02-08 21:13:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mozilla Science Lab",
      "screen_name" : "MozillaScience",
      "indices" : [ 3, 18 ],
      "id_str" : "1428575976",
      "id" : 1428575976
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "openscience",
      "indices" : [ 80, 92 ]
    }, {
      "text" : "mslparty",
      "indices" : [ 93, 102 ]
    }, {
      "text" : "MozWOW",
      "indices" : [ 103, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/XM7CmB1xRT",
      "expanded_url" : "https:\/\/mozillascience.org\/wow-wrap-up",
      "display_url" : "mozillascience.org\/wow-wrap-up"
    } ]
  },
  "geo" : { },
  "id_str" : "696798765194350592",
  "text" : "RT @MozillaScience: Wrap-up post on last week's Working Open Workshop in Berlin #openscience #mslparty #MozWOW : https:\/\/t.co\/XM7CmB1xRT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "openscience",
        "indices" : [ 60, 72 ]
      }, {
        "text" : "mslparty",
        "indices" : [ 73, 82 ]
      }, {
        "text" : "MozWOW",
        "indices" : [ 83, 90 ]
      } ],
      "urls" : [ {
        "indices" : [ 93, 116 ],
        "url" : "https:\/\/t.co\/XM7CmB1xRT",
        "expanded_url" : "https:\/\/mozillascience.org\/wow-wrap-up",
        "display_url" : "mozillascience.org\/wow-wrap-up"
      } ]
    },
    "geo" : { },
    "id_str" : "696793115588501505",
    "text" : "Wrap-up post on last week's Working Open Workshop in Berlin #openscience #mslparty #MozWOW : https:\/\/t.co\/XM7CmB1xRT",
    "id" : 696793115588501505,
    "created_at" : "2016-02-08 20:29:59 +0000",
    "user" : {
      "name" : "Mozilla Science Lab",
      "screen_name" : "MozillaScience",
      "protected" : false,
      "id_str" : "1428575976",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/687287790049034240\/lwIk-ZQT_normal.png",
      "id" : 1428575976,
      "verified" : false
    }
  },
  "id" : 696798765194350592,
  "created_at" : "2016-02-08 20:52:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11404338976477, 8.753437036294278 ]
  },
  "id_str" : "696790123829161984",
  "text" : "\u00ABThe angst of facing mortality has no remedy in probability.\u00BB Except for the 5% or so where it works just fine?",
  "id" : 696790123829161984,
  "created_at" : "2016-02-08 20:18:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 62 ],
      "url" : "https:\/\/t.co\/GXFAS7z3Gj",
      "expanded_url" : "https:\/\/m.flickr.com\/#\/photos\/139954518@N06\/24224058433\/in\/set-72157662003654193\/",
      "display_url" : "m.flickr.com\/#\/photos\/13995\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "696759461894033408",
  "text" : "Me, getting enraged over closed data.  https:\/\/t.co\/GXFAS7z3Gj",
  "id" : 696759461894033408,
  "created_at" : "2016-02-08 18:16:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "annakrystalli",
      "screen_name" : "annakrystalli",
      "indices" : [ 0, 14 ],
      "id_str" : "15090415",
      "id" : 15090415
    }, {
      "name" : "Mozilla Science Lab",
      "screen_name" : "MozillaScience",
      "indices" : [ 15, 30 ],
      "id_str" : "1428575976",
      "id" : 1428575976
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "696758281583390721",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17658820351951, 8.630041200757274 ]
  },
  "id_str" : "696758626384547840",
  "in_reply_to_user_id" : 15090415,
  "text" : "@annakrystalli @MozillaScience +1",
  "id" : 696758626384547840,
  "in_reply_to_status_id" : 696758281583390721,
  "created_at" : "2016-02-08 18:12:56 +0000",
  "in_reply_to_screen_name" : "annakrystalli",
  "in_reply_to_user_id_str" : "15090415",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "badass woman alert",
      "screen_name" : "badass_w",
      "indices" : [ 3, 12 ],
      "id_str" : "2283620132",
      "id" : 2283620132
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/Cue90C4YMQ",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=0ze4AH_5kJw",
      "display_url" : "youtube.com\/watch?v=0ze4AH\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "696752757257146368",
  "text" : "RT @badass_w: These women are fighting street harassers by using confetti guns and punk rock music  https:\/\/t.co\/Cue90C4YMQ https:\/\/t.co\/Gw\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/badass_w\/status\/696741950381256704\/photo\/1",
        "indices" : [ 110, 133 ],
        "url" : "https:\/\/t.co\/GwPhbJjkME",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CatTFiRW8AA8wwN.png",
        "id_str" : "696741921922936832",
        "id" : 696741921922936832,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CatTFiRW8AA8wwN.png",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 349,
          "resize" : "fit",
          "w" : 655
        }, {
          "h" : 349,
          "resize" : "fit",
          "w" : 655
        }, {
          "h" : 349,
          "resize" : "fit",
          "w" : 655
        }, {
          "h" : 349,
          "resize" : "fit",
          "w" : 655
        } ],
        "display_url" : "pic.twitter.com\/GwPhbJjkME"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 86, 109 ],
        "url" : "https:\/\/t.co\/Cue90C4YMQ",
        "expanded_url" : "https:\/\/www.youtube.com\/watch?v=0ze4AH_5kJw",
        "display_url" : "youtube.com\/watch?v=0ze4AH\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "696741950381256704",
    "text" : "These women are fighting street harassers by using confetti guns and punk rock music  https:\/\/t.co\/Cue90C4YMQ https:\/\/t.co\/GwPhbJjkME",
    "id" : 696741950381256704,
    "created_at" : "2016-02-08 17:06:40 +0000",
    "user" : {
      "name" : "badass woman alert",
      "screen_name" : "badass_w",
      "protected" : false,
      "id_str" : "2283620132",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/591354105559445504\/FwiJhIiy_normal.jpg",
      "id" : 2283620132,
      "verified" : false
    }
  },
  "id" : 696752757257146368,
  "created_at" : "2016-02-08 17:49:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/696745081429172224\/photo\/1",
      "indices" : [ 8, 31 ],
      "url" : "https:\/\/t.co\/MFyZxuMMrl",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CatV9bzWIAIBVwf.jpg",
      "id_str" : "696745081282371586",
      "id" : 696745081282371586,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CatV9bzWIAIBVwf.jpg",
      "sizes" : [ {
        "h" : 1053,
        "resize" : "fit",
        "w" : 1404
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1053,
        "resize" : "fit",
        "w" : 1404
      } ],
      "display_url" : "pic.twitter.com\/MFyZxuMMrl"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "696745081429172224",
  "text" : "CAT-4.5 https:\/\/t.co\/MFyZxuMMrl",
  "id" : 696745081429172224,
  "created_at" : "2016-02-08 17:19:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/91bDtuCq4n",
      "expanded_url" : "http:\/\/www.reactiongifs.com\/r\/tupper.gif",
      "display_url" : "reactiongifs.com\/r\/tupper.gif"
    } ]
  },
  "geo" : { },
  "id_str" : "696723708015149056",
  "text" : "the moment you recognize the wildcard in your rm command also matches all the stuff you wanted to keep\u2026 https:\/\/t.co\/91bDtuCq4n",
  "id" : 696723708015149056,
  "created_at" : "2016-02-08 15:54:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mick Watson",
      "screen_name" : "BioMickWatson",
      "indices" : [ 0, 14 ],
      "id_str" : "228586748",
      "id" : 228586748
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "696713105670344706",
  "geo" : { },
  "id_str" : "696713614737203200",
  "in_reply_to_user_id" : 228586748,
  "text" : "@BioMickWatson just think how confusing the whole independence thing was for us.",
  "id" : 696713614737203200,
  "in_reply_to_status_id" : 696713105670344706,
  "created_at" : "2016-02-08 15:14:04 +0000",
  "in_reply_to_screen_name" : "BioMickWatson",
  "in_reply_to_user_id_str" : "228586748",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 94, 107 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 89 ],
      "url" : "https:\/\/t.co\/gWSvBE2TOB",
      "expanded_url" : "http:\/\/www.nytimes.com\/interactive\/2016\/02\/07\/opinion\/what-74-years-of-times-crosswords-say-about-the-words-we-use.html?action=click&pgtype=Homepage&clickSource=story-heading&module=opinion-c-col-left-region&region=opinion-c-col-left-region&WT.nav=opinion-c-col-left-region&_r=0",
      "display_url" : "nytimes.com\/interactive\/20\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "696713277888401409",
  "text" : "What 74 Years of Crossword History\u2070Says About the Language We Use https:\/\/t.co\/gWSvBE2TOB \/cc @PhilippBayer",
  "id" : 696713277888401409,
  "created_at" : "2016-02-08 15:12:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Weigel Lab",
      "screen_name" : "PlantEvolution",
      "indices" : [ 0, 15 ],
      "id_str" : "100068931",
      "id" : 100068931
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "696712050404388864",
  "in_reply_to_user_id" : 100068931,
  "text" : "@PlantEvolution Congratulations!",
  "id" : 696712050404388864,
  "created_at" : "2016-02-08 15:07:51 +0000",
  "in_reply_to_screen_name" : "PlantEvolution",
  "in_reply_to_user_id_str" : "100068931",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "openSNP team",
      "screen_name" : "openSNPorg",
      "indices" : [ 26, 37 ],
      "id_str" : "380205172",
      "id" : 380205172
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/JziIW5sPvI",
      "expanded_url" : "https:\/\/github.com\/openSNP\/snpr\/blob\/master\/CODE_OF_CONDUCT.md",
      "display_url" : "github.com\/openSNP\/snpr\/b\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "696705498452725761",
  "text" : "ICYMI during the weekend: @openSNPorg now has a code of conduct, found at https:\/\/t.co\/JziIW5sPvI",
  "id" : 696705498452725761,
  "created_at" : "2016-02-08 14:41:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 87 ],
      "url" : "https:\/\/t.co\/FmsBB4vuHv",
      "expanded_url" : "https:\/\/twitter.com\/cindywu\/status\/696555536649711616",
      "display_url" : "twitter.com\/cindywu\/status\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "696703799931621376",
  "text" : "Just refuse to review for outlets that won\u2019t permit emoji. \u270B\uD83C\uDFFD\u26D4\uFE0F https:\/\/t.co\/FmsBB4vuHv",
  "id" : 696703799931621376,
  "created_at" : "2016-02-08 14:35:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 87 ],
      "url" : "https:\/\/t.co\/ImTRoGG0xH",
      "expanded_url" : "https:\/\/broadly.vice.com\/en_us\/article\/creating-while-female-how-women-artists-deal-with-online-abuse",
      "display_url" : "broadly.vice.com\/en_us\/article\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "696691553222422528",
  "text" : "Creating While Female: How Women Artists Deal with Online Abuse https:\/\/t.co\/ImTRoGG0xH",
  "id" : 696691553222422528,
  "created_at" : "2016-02-08 13:46:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Atossa Araxia Abrahamian",
      "screen_name" : "atossaaraxia",
      "indices" : [ 3, 16 ],
      "id_str" : "228437800",
      "id" : 228437800
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 83 ],
      "url" : "https:\/\/t.co\/vdA9yPp7VJ",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=SmkN56_Vj9Y",
      "display_url" : "youtube.com\/watch?v=SmkN56\u2026"
    }, {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/AFvknqIZZ8",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=SLiFd7fx8kM",
      "display_url" : "youtube.com\/watch?v=SLiFd7\u2026"
    }, {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/9jXxMvGg03",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=occPOuzLZuU",
      "display_url" : "youtube.com\/watch?v=occPOu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "696670812951203840",
  "text" : "RT @atossaaraxia: dylan three ways (jeff buckley's is best)\nhttps:\/\/t.co\/vdA9yPp7VJ\nhttps:\/\/t.co\/AFvknqIZZ8\nhttps:\/\/t.co\/9jXxMvGg03",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 42, 65 ],
        "url" : "https:\/\/t.co\/vdA9yPp7VJ",
        "expanded_url" : "https:\/\/www.youtube.com\/watch?v=SmkN56_Vj9Y",
        "display_url" : "youtube.com\/watch?v=SmkN56\u2026"
      }, {
        "indices" : [ 66, 89 ],
        "url" : "https:\/\/t.co\/AFvknqIZZ8",
        "expanded_url" : "https:\/\/www.youtube.com\/watch?v=SLiFd7fx8kM",
        "display_url" : "youtube.com\/watch?v=SLiFd7\u2026"
      }, {
        "indices" : [ 90, 113 ],
        "url" : "https:\/\/t.co\/9jXxMvGg03",
        "expanded_url" : "https:\/\/www.youtube.com\/watch?v=occPOuzLZuU",
        "display_url" : "youtube.com\/watch?v=occPOu\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "694960034573373441",
    "text" : "dylan three ways (jeff buckley's is best)\nhttps:\/\/t.co\/vdA9yPp7VJ\nhttps:\/\/t.co\/AFvknqIZZ8\nhttps:\/\/t.co\/9jXxMvGg03",
    "id" : 694960034573373441,
    "created_at" : "2016-02-03 19:05:58 +0000",
    "user" : {
      "name" : "Atossa Araxia Abrahamian",
      "screen_name" : "atossaaraxia",
      "protected" : false,
      "id_str" : "228437800",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/707884522738728960\/VqnZwF27_normal.jpg",
      "id" : 228437800,
      "verified" : true
    }
  },
  "id" : 696670812951203840,
  "created_at" : "2016-02-08 12:23:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 65 ],
      "url" : "https:\/\/t.co\/rqy6SG7eVn",
      "expanded_url" : "https:\/\/twitter.com\/BrilliantMaps\/status\/696074413452623872",
      "display_url" : "twitter.com\/BrilliantMaps\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "696663271936540672",
  "text" : "I think the correct answer is \u201Eadorable\u201C! https:\/\/t.co\/rqy6SG7eVn",
  "id" : 696663271936540672,
  "created_at" : "2016-02-08 11:54:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 62 ],
      "url" : "https:\/\/t.co\/hkGJmsKlMn",
      "expanded_url" : "http:\/\/i.imgur.com\/hDlG7lR.gifv",
      "display_url" : "i.imgur.com\/hDlG7lR.gifv"
    } ]
  },
  "geo" : { },
  "id_str" : "696611275888062464",
  "text" : "\u00B1 what happens when i\u2019m trying to work https:\/\/t.co\/hkGJmsKlMn",
  "id" : 696611275888062464,
  "created_at" : "2016-02-08 08:27:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Austin Richardson",
      "screen_name" : "heyaudy",
      "indices" : [ 0, 8 ],
      "id_str" : "14534523",
      "id" : 14534523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "696403230981361664",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1090194487786, 8.757144498058056 ]
  },
  "id_str" : "696403306453852160",
  "in_reply_to_user_id" : 14534523,
  "text" : "@heyaudy yep! :)",
  "id" : 696403306453852160,
  "in_reply_to_status_id" : 696403230981361664,
  "created_at" : "2016-02-07 18:41:01 +0000",
  "in_reply_to_screen_name" : "heyaudy",
  "in_reply_to_user_id_str" : "14534523",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Austin Richardson",
      "screen_name" : "heyaudy",
      "indices" : [ 0, 8 ],
      "id_str" : "14534523",
      "id" : 14534523
    }, {
      "name" : "Cormac R. McDarwin",
      "screen_name" : "TheBloodVoyage",
      "indices" : [ 22, 37 ],
      "id_str" : "4825733537",
      "id" : 4825733537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "696389869820489728",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.10902307795131, 8.757236413354066 ]
  },
  "id_str" : "696399186359685120",
  "in_reply_to_user_id" : 14534523,
  "text" : "@heyaudy does it have @TheBloodVoyage? :)",
  "id" : 696399186359685120,
  "in_reply_to_status_id" : 696389869820489728,
  "created_at" : "2016-02-07 18:24:39 +0000",
  "in_reply_to_screen_name" : "heyaudy",
  "in_reply_to_user_id_str" : "14534523",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Eisen",
      "screen_name" : "mbeisen",
      "indices" : [ 0, 8 ],
      "id_str" : "19843630",
      "id" : 19843630
    }, {
      "name" : "Nazeefa",
      "screen_name" : "NazeefaFatima",
      "indices" : [ 9, 23 ],
      "id_str" : "37054704",
      "id" : 37054704
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "696195340957921281",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.04114624062991, 8.557982000341587 ]
  },
  "id_str" : "696348941957386241",
  "in_reply_to_user_id" : 19843630,
  "text" : "@mbeisen @NazeefaFatima do a \u201CHeroes of $topic\u201D-piece in Cell.",
  "id" : 696348941957386241,
  "in_reply_to_status_id" : 696195340957921281,
  "created_at" : "2016-02-07 15:04:59 +0000",
  "in_reply_to_screen_name" : "mbeisen",
  "in_reply_to_user_id_str" : "19843630",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mozilla Science Lab",
      "screen_name" : "MozillaScience",
      "indices" : [ 56, 71 ],
      "id_str" : "1428575976",
      "id" : 1428575976
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mozwow",
      "indices" : [ 76, 83 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.55332341143171, 13.28926060167409 ]
  },
  "id_str" : "696331980686913536",
  "text" : "Goodbye Berlin, see you in March. Thanks to everyone at @MozillaScience and #mozwow for making this a great weekend.",
  "id" : 696331980686913536,
  "created_at" : "2016-02-07 13:57:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark D. Scherz",
      "screen_name" : "MarkScherz",
      "indices" : [ 0, 11 ],
      "id_str" : "23521469",
      "id" : 23521469
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "696281929365241856",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.56183858446703, 13.33205127946575 ]
  },
  "id_str" : "696301540831858688",
  "in_reply_to_user_id" : 23521469,
  "text" : "@MarkScherz yes, absolutely.",
  "id" : 696301540831858688,
  "in_reply_to_status_id" : 696281929365241856,
  "created_at" : "2016-02-07 11:56:38 +0000",
  "in_reply_to_screen_name" : "MarkScherz",
  "in_reply_to_user_id_str" : "23521469",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Head",
      "screen_name" : "betatim",
      "indices" : [ 0, 8 ],
      "id_str" : "18881614",
      "id" : 18881614
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "696294330793902080",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.54817025538333, 13.35608958893176 ]
  },
  "id_str" : "696294850174566400",
  "in_reply_to_user_id" : 18881614,
  "text" : "@betatim (I also forgot to bring my running shoes ;))",
  "id" : 696294850174566400,
  "in_reply_to_status_id" : 696294330793902080,
  "created_at" : "2016-02-07 11:30:03 +0000",
  "in_reply_to_screen_name" : "betatim",
  "in_reply_to_user_id_str" : "18881614",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Abby Cabunoc Mayes",
      "screen_name" : "abbycabs",
      "indices" : [ 0, 9 ],
      "id_str" : "395367768",
      "id" : 395367768
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "696294115047247872",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.54804136207969, 13.35632457729345 ]
  },
  "id_str" : "696294738446696448",
  "in_reply_to_user_id" : 395367768,
  "text" : "@abbycabs that would be great!",
  "id" : 696294738446696448,
  "in_reply_to_status_id" : 696294115047247872,
  "created_at" : "2016-02-07 11:29:36 +0000",
  "in_reply_to_screen_name" : "abbycabs",
  "in_reply_to_user_id_str" : "395367768",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Head",
      "screen_name" : "betatim",
      "indices" : [ 0, 8 ],
      "id_str" : "18881614",
      "id" : 18881614
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "696294330793902080",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.54770373832378, 13.35690192243055 ]
  },
  "id_str" : "696294693420797953",
  "in_reply_to_user_id" : 18881614,
  "text" : "@betatim Streber would be right if we had done all of this 4 years back when we started :D",
  "id" : 696294693420797953,
  "in_reply_to_status_id" : 696294330793902080,
  "created_at" : "2016-02-07 11:29:26 +0000",
  "in_reply_to_screen_name" : "betatim",
  "in_reply_to_user_id_str" : "18881614",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Abby Cabunoc Mayes",
      "screen_name" : "abbycabs",
      "indices" : [ 0, 9 ],
      "id_str" : "395367768",
      "id" : 395367768
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "696293050100903936",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.54902414545685, 13.36124542684557 ]
  },
  "id_str" : "696293351038054400",
  "in_reply_to_user_id" : 395367768,
  "text" : "@abbycabs I know. But getting a clear path forward is harder now that you\u2019re not on a blank slate :)",
  "id" : 696293351038054400,
  "in_reply_to_status_id" : 696293050100903936,
  "created_at" : "2016-02-07 11:24:06 +0000",
  "in_reply_to_screen_name" : "abbycabs",
  "in_reply_to_user_id_str" : "395367768",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Abby Cabunoc Mayes",
      "screen_name" : "abbycabs",
      "indices" : [ 0, 9 ],
      "id_str" : "395367768",
      "id" : 395367768
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "696292743514038272",
  "geo" : { },
  "id_str" : "696292865417355264",
  "in_reply_to_user_id" : 395367768,
  "text" : "@abbycabs only thing missing is the roadmap, but that takes a bit more time given that we\u2019re a couple of years in already :D",
  "id" : 696292865417355264,
  "in_reply_to_status_id" : 696292743514038272,
  "created_at" : "2016-02-07 11:22:10 +0000",
  "in_reply_to_screen_name" : "abbycabs",
  "in_reply_to_user_id_str" : "395367768",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Schawinski",
      "screen_name" : "kevinschawinski",
      "indices" : [ 0, 16 ],
      "id_str" : "242844365",
      "id" : 242844365
    }, {
      "name" : "Mozilla Science Lab",
      "screen_name" : "MozillaScience",
      "indices" : [ 38, 53 ],
      "id_str" : "1428575976",
      "id" : 1428575976
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "696287722521128964",
  "geo" : { },
  "id_str" : "696288303797116928",
  "in_reply_to_user_id" : 242844365,
  "text" : "@kevinschawinski maybe after the next @MozillaScience event?",
  "id" : 696288303797116928,
  "in_reply_to_status_id" : 696287722521128964,
  "created_at" : "2016-02-07 11:04:02 +0000",
  "in_reply_to_screen_name" : "kevinschawinski",
  "in_reply_to_user_id_str" : "242844365",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mozwow",
      "indices" : [ 37, 44 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "696285983885676545",
  "text" : "Finished nearly all my homework from #mozwow. openSNP now with Code of Conduct, better README, having CONTRIBUTING + INSTALL and humanstxt.",
  "id" : 696285983885676545,
  "created_at" : "2016-02-07 10:54:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sujai Kumar",
      "screen_name" : "sujaik",
      "indices" : [ 0, 7 ],
      "id_str" : "33651124",
      "id" : 33651124
    }, {
      "name" : "Alejandro Sanchez",
      "screen_name" : "arroboso",
      "indices" : [ 8, 17 ],
      "id_str" : "2278617572",
      "id" : 2278617572
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "696068546875547648",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.53593801059996, 13.37625967339927 ]
  },
  "id_str" : "696127458345615365",
  "in_reply_to_user_id" : 33651124,
  "text" : "@sujaik @arroboso yes, thanks for pointing that out. It\u2019s a huge problem if you don\u2019t do it!",
  "id" : 696127458345615365,
  "in_reply_to_status_id" : 696068546875547648,
  "created_at" : "2016-02-07 00:24:54 +0000",
  "in_reply_to_screen_name" : "sujaik",
  "in_reply_to_user_id_str" : "33651124",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mozwow",
      "indices" : [ 42, 49 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.52387701770648, 13.40264593248819 ]
  },
  "id_str" : "696121920270569476",
  "text" : "I don\u2019t say this lightly, but the awesome #mozwow crowd made even Berlin tolerable to me.",
  "id" : 696121920270569476,
  "created_at" : "2016-02-07 00:02:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "nikki forebber",
      "screen_name" : "antischokke",
      "indices" : [ 0, 12 ],
      "id_str" : "2813661",
      "id" : 2813661
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 107, 120 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "696033612194562048",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.53688645493721, 13.37824700868675 ]
  },
  "id_str" : "696034557745893376",
  "in_reply_to_user_id" : 2813661,
  "text" : "@antischokke manche Leute sollen in dem Ding ja fast ihre gesamte Studienzeit durchgebracht haben, calling @PhilippBayer ;)",
  "id" : 696034557745893376,
  "in_reply_to_status_id" : 696033612194562048,
  "created_at" : "2016-02-06 18:15:44 +0000",
  "in_reply_to_screen_name" : "antischokke",
  "in_reply_to_user_id_str" : "2813661",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 67 ],
      "url" : "https:\/\/t.co\/0C3ACvuvzH",
      "expanded_url" : "https:\/\/twitter.com\/pathogenomenick\/status\/696030479275917313",
      "display_url" : "twitter.com\/pathogenomenic\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.53688904025531, 13.37831163316804 ]
  },
  "id_str" : "696033393398644736",
  "text" : "Take-off was done using standard parameters https:\/\/t.co\/0C3ACvuvzH",
  "id" : 696033393398644736,
  "created_at" : "2016-02-06 18:11:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Beyonc\u00E9\u2728",
      "screen_name" : "Miss_Ethiopiaa",
      "indices" : [ 3, 18 ],
      "id_str" : "1360598958",
      "id" : 1360598958
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Miss_Ethiopiaa\/status\/684169790580211712\/photo\/1",
      "indices" : [ 59, 82 ],
      "url" : "https:\/\/t.co\/wj7asG2OXn",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CX6oy2EUAAAuNAl.jpg",
      "id_str" : "684169784867422208",
      "id" : 684169784867422208,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CX6oy2EUAAAuNAl.jpg",
      "sizes" : [ {
        "h" : 328,
        "resize" : "fit",
        "w" : 588
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 328,
        "resize" : "fit",
        "w" : 588
      }, {
        "h" : 328,
        "resize" : "fit",
        "w" : 588
      }, {
        "h" : 328,
        "resize" : "fit",
        "w" : 588
      } ],
      "display_url" : "pic.twitter.com\/wj7asG2OXn"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/Miss_Ethiopiaa\/status\/684169790580211712\/photo\/1",
      "indices" : [ 59, 82 ],
      "url" : "https:\/\/t.co\/wj7asG2OXn",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CX6oy2YUEAAiHrA.jpg",
      "id_str" : "684169784951312384",
      "id" : 684169784951312384,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CX6oy2YUEAAiHrA.jpg",
      "sizes" : [ {
        "h" : 381,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 392,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 392,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 392,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/wj7asG2OXn"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/Miss_Ethiopiaa\/status\/684169790580211712\/photo\/1",
      "indices" : [ 59, 82 ],
      "url" : "https:\/\/t.co\/wj7asG2OXn",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CX6oy2gU0AAuD9O.jpg",
      "id_str" : "684169784984915968",
      "id" : 684169784984915968,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CX6oy2gU0AAuD9O.jpg",
      "sizes" : [ {
        "h" : 263,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 263,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 263,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 263,
        "resize" : "fit",
        "w" : 500
      } ],
      "display_url" : "pic.twitter.com\/wj7asG2OXn"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/Miss_Ethiopiaa\/status\/684169790580211712\/photo\/1",
      "indices" : [ 59, 82 ],
      "url" : "https:\/\/t.co\/wj7asG2OXn",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CX6oy3PUEAkztmS.jpg",
      "id_str" : "684169785181999113",
      "id" : 684169785181999113,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CX6oy3PUEAkztmS.jpg",
      "sizes" : [ {
        "h" : 263,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 263,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 263,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 263,
        "resize" : "fit",
        "w" : 500
      } ],
      "display_url" : "pic.twitter.com\/wj7asG2OXn"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "696029040931639296",
  "text" : "RT @Miss_Ethiopiaa: \"Well actually....\": a thrilling novel https:\/\/t.co\/wj7asG2OXn",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Miss_Ethiopiaa\/status\/684169790580211712\/photo\/1",
        "indices" : [ 39, 62 ],
        "url" : "https:\/\/t.co\/wj7asG2OXn",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CX6oy2EUAAAuNAl.jpg",
        "id_str" : "684169784867422208",
        "id" : 684169784867422208,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CX6oy2EUAAAuNAl.jpg",
        "sizes" : [ {
          "h" : 328,
          "resize" : "fit",
          "w" : 588
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 328,
          "resize" : "fit",
          "w" : 588
        }, {
          "h" : 328,
          "resize" : "fit",
          "w" : 588
        }, {
          "h" : 328,
          "resize" : "fit",
          "w" : 588
        } ],
        "display_url" : "pic.twitter.com\/wj7asG2OXn"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/Miss_Ethiopiaa\/status\/684169790580211712\/photo\/1",
        "indices" : [ 39, 62 ],
        "url" : "https:\/\/t.co\/wj7asG2OXn",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CX6oy2YUEAAiHrA.jpg",
        "id_str" : "684169784951312384",
        "id" : 684169784951312384,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CX6oy2YUEAAiHrA.jpg",
        "sizes" : [ {
          "h" : 381,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 392,
          "resize" : "fit",
          "w" : 700
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 392,
          "resize" : "fit",
          "w" : 700
        }, {
          "h" : 392,
          "resize" : "fit",
          "w" : 700
        } ],
        "display_url" : "pic.twitter.com\/wj7asG2OXn"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/Miss_Ethiopiaa\/status\/684169790580211712\/photo\/1",
        "indices" : [ 39, 62 ],
        "url" : "https:\/\/t.co\/wj7asG2OXn",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CX6oy2gU0AAuD9O.jpg",
        "id_str" : "684169784984915968",
        "id" : 684169784984915968,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CX6oy2gU0AAuD9O.jpg",
        "sizes" : [ {
          "h" : 263,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 263,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 263,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 263,
          "resize" : "fit",
          "w" : 500
        } ],
        "display_url" : "pic.twitter.com\/wj7asG2OXn"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/Miss_Ethiopiaa\/status\/684169790580211712\/photo\/1",
        "indices" : [ 39, 62 ],
        "url" : "https:\/\/t.co\/wj7asG2OXn",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CX6oy3PUEAkztmS.jpg",
        "id_str" : "684169785181999113",
        "id" : 684169785181999113,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CX6oy3PUEAkztmS.jpg",
        "sizes" : [ {
          "h" : 263,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 263,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 263,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 263,
          "resize" : "fit",
          "w" : 500
        } ],
        "display_url" : "pic.twitter.com\/wj7asG2OXn"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "684169790580211712",
    "text" : "\"Well actually....\": a thrilling novel https:\/\/t.co\/wj7asG2OXn",
    "id" : 684169790580211712,
    "created_at" : "2016-01-05 00:29:23 +0000",
    "user" : {
      "name" : "Beyonc\u00E9\u2728",
      "screen_name" : "Miss_Ethiopiaa",
      "protected" : false,
      "id_str" : "1360598958",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/930443972899635200\/reqgztfA_normal.jpg",
      "id" : 1360598958,
      "verified" : false
    }
  },
  "id" : 696029040931639296,
  "created_at" : "2016-02-06 17:53:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u24EA Rik Smith-Unna \uD83C\uDDF0\uD83C\uDDEA",
      "screen_name" : "blahah404",
      "indices" : [ 0, 10 ],
      "id_str" : "99173786",
      "id" : 99173786
    }, {
      "name" : "Abby Cabunoc Mayes",
      "screen_name" : "abbycabs",
      "indices" : [ 11, 20 ],
      "id_str" : "395367768",
      "id" : 395367768
    }, {
      "name" : "Zeb",
      "screen_name" : "treblesteph",
      "indices" : [ 21, 33 ],
      "id_str" : "316299043",
      "id" : 316299043
    }, {
      "name" : "Joseph Klee",
      "screen_name" : "joeyklee",
      "indices" : [ 34, 43 ],
      "id_str" : "50061892",
      "id" : 50061892
    }, {
      "name" : "Christie Bahlai",
      "screen_name" : "cbahlai",
      "indices" : [ 44, 52 ],
      "id_str" : "958649520",
      "id" : 958649520
    }, {
      "name" : "annakrystalli",
      "screen_name" : "annakrystalli",
      "indices" : [ 53, 67 ],
      "id_str" : "15090415",
      "id" : 15090415
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "696028690061398017",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.53690268311287, 13.37837679258462 ]
  },
  "id_str" : "696028902158954497",
  "in_reply_to_user_id" : 99173786,
  "text" : "@blahah404 @abbycabs @treblesteph @joeyklee @cbahlai @annakrystalli hope near Naturkundemuseum, any recommendations where to go for dinner?",
  "id" : 696028902158954497,
  "in_reply_to_status_id" : 696028690061398017,
  "created_at" : "2016-02-06 17:53:16 +0000",
  "in_reply_to_screen_name" : "blahah404",
  "in_reply_to_user_id_str" : "99173786",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u24EA Rik Smith-Unna \uD83C\uDDF0\uD83C\uDDEA",
      "screen_name" : "blahah404",
      "indices" : [ 0, 10 ],
      "id_str" : "99173786",
      "id" : 99173786
    }, {
      "name" : "Abby Cabunoc Mayes",
      "screen_name" : "abbycabs",
      "indices" : [ 11, 20 ],
      "id_str" : "395367768",
      "id" : 395367768
    }, {
      "name" : "Zeb",
      "screen_name" : "treblesteph",
      "indices" : [ 21, 33 ],
      "id_str" : "316299043",
      "id" : 316299043
    }, {
      "name" : "Joseph Klee",
      "screen_name" : "joeyklee",
      "indices" : [ 34, 43 ],
      "id_str" : "50061892",
      "id" : 50061892
    }, {
      "name" : "Christie Bahlai",
      "screen_name" : "cbahlai",
      "indices" : [ 44, 52 ],
      "id_str" : "958649520",
      "id" : 958649520
    }, {
      "name" : "annakrystalli",
      "screen_name" : "annakrystalli",
      "indices" : [ 65, 79 ],
      "id_str" : "15090415",
      "id" : 15090415
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "696016872282652672",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.53693115939063, 13.37840741001508 ]
  },
  "id_str" : "696022346277261313",
  "in_reply_to_user_id" : 99173786,
  "text" : "@blahah404 @abbycabs @treblesteph @joeyklee @cbahlai and I think @annakrystalli is also still out there iirc.",
  "id" : 696022346277261313,
  "in_reply_to_status_id" : 696016872282652672,
  "created_at" : "2016-02-06 17:27:13 +0000",
  "in_reply_to_screen_name" : "blahah404",
  "in_reply_to_user_id_str" : "99173786",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Abby Cabunoc Mayes",
      "screen_name" : "abbycabs",
      "indices" : [ 0, 9 ],
      "id_str" : "395367768",
      "id" : 395367768
    }, {
      "name" : "\u24EA Rik Smith-Unna \uD83C\uDDF0\uD83C\uDDEA",
      "screen_name" : "blahah404",
      "indices" : [ 39, 49 ],
      "id_str" : "99173786",
      "id" : 99173786
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mozwow",
      "indices" : [ 68, 75 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "696005372465831937",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.53694934111994, 13.37840204908299 ]
  },
  "id_str" : "696015398718857216",
  "in_reply_to_user_id" : 395367768,
  "text" : "@abbycabs no plans so far, waiting for @blahah404 to make a move :D #mozwow",
  "id" : 696015398718857216,
  "in_reply_to_status_id" : 696005372465831937,
  "created_at" : "2016-02-06 16:59:37 +0000",
  "in_reply_to_screen_name" : "abbycabs",
  "in_reply_to_user_id_str" : "395367768",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Wilkins",
      "screen_name" : "jonfwilkins",
      "indices" : [ 3, 15 ],
      "id_str" : "214099847",
      "id" : 214099847
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "696000632117948416",
  "text" : "RT @jonfwilkins: Yesterday's post on Jason Leib and why it's okay to consider unproven allegations in faculty hiring decisions https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 110, 133 ],
        "url" : "https:\/\/t.co\/YwBfXflmRn",
        "expanded_url" : "http:\/\/jonfwilkins.com\/2016\/02\/innocent-until-proven-guilty-is-nonsense-for-faculty-hiring\/",
        "display_url" : "jonfwilkins.com\/2016\/02\/innoce\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "695992323780579328",
    "text" : "Yesterday's post on Jason Leib and why it's okay to consider unproven allegations in faculty hiring decisions https:\/\/t.co\/YwBfXflmRn",
    "id" : 695992323780579328,
    "created_at" : "2016-02-06 15:27:55 +0000",
    "user" : {
      "name" : "Jon Wilkins",
      "screen_name" : "jonfwilkins",
      "protected" : false,
      "id_str" : "214099847",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1279449740\/Dev2DEC_normal.jpg",
      "id" : 214099847,
      "verified" : false
    }
  },
  "id" : 696000632117948416,
  "created_at" : "2016-02-06 16:00:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Schawinski",
      "screen_name" : "kevinschawinski",
      "indices" : [ 0, 16 ],
      "id_str" : "242844365",
      "id" : 242844365
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "695989420391079936",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.53686843395488, 13.37827492856637 ]
  },
  "id_str" : "696000008798277632",
  "in_reply_to_user_id" : 242844365,
  "text" : "@kevinschawinski ~ one regular day before heading to bed. That's ~7am to ~1am, bit shorter when doing sports and using lots of HR monitoring",
  "id" : 696000008798277632,
  "in_reply_to_status_id" : 695989420391079936,
  "created_at" : "2016-02-06 15:58:27 +0000",
  "in_reply_to_screen_name" : "kevinschawinski",
  "in_reply_to_user_id_str" : "242844365",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.52213905812142, 13.38788387031944 ]
  },
  "id_str" : "695991299787333636",
  "text" : "\u00ABI just passed the holocaust memorial and had to think of you\u2026\u00BB Questionable conversation opener for 500.",
  "id" : 695991299787333636,
  "created_at" : "2016-02-06 15:23:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u24EA Rik Smith-Unna \uD83C\uDDF0\uD83C\uDDEA",
      "screen_name" : "blahah404",
      "indices" : [ 0, 10 ],
      "id_str" : "99173786",
      "id" : 99173786
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "695959296513830912",
  "geo" : { },
  "id_str" : "695959391518986240",
  "in_reply_to_user_id" : 99173786,
  "text" : "@blahah404 I just went for the vegan brownies, so that worked out ;)",
  "id" : 695959391518986240,
  "in_reply_to_status_id" : 695959296513830912,
  "created_at" : "2016-02-06 13:17:03 +0000",
  "in_reply_to_screen_name" : "blahah404",
  "in_reply_to_user_id_str" : "99173786",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u24EA Rik Smith-Unna \uD83C\uDDF0\uD83C\uDDEA",
      "screen_name" : "blahah404",
      "indices" : [ 0, 10 ],
      "id_str" : "99173786",
      "id" : 99173786
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "695713316849786880",
  "geo" : { },
  "id_str" : "695940322438811648",
  "in_reply_to_user_id" : 99173786,
  "text" : "@blahah404 did you eat lunch for the two of us? ;)",
  "id" : 695940322438811648,
  "in_reply_to_status_id" : 695713316849786880,
  "created_at" : "2016-02-06 12:01:17 +0000",
  "in_reply_to_screen_name" : "blahah404",
  "in_reply_to_user_id_str" : "99173786",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mozWOW",
      "indices" : [ 72, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/2q7fWiE2Fr",
      "expanded_url" : "https:\/\/github.com\/gedankenstuecke\/snpr\/blob\/master\/code_of_conduct.md",
      "display_url" : "github.com\/gedankenstueck\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "695888939727642624",
  "text" : "Merged &amp; online since ~30 minutes: The code of conduct for openSNP. #mozWOW. https:\/\/t.co\/2q7fWiE2Fr",
  "id" : 695888939727642624,
  "created_at" : "2016-02-06 08:37:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chocho Zhang",
      "screen_name" : "chocho_z",
      "indices" : [ 0, 9 ],
      "id_str" : "3221119766",
      "id" : 3221119766
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "695888064736940038",
  "geo" : { },
  "id_str" : "695888187567304704",
  "in_reply_to_user_id" : 3221119766,
  "text" : "@chocho_z that\u2019s less cool :(",
  "id" : 695888187567304704,
  "in_reply_to_status_id" : 695888064736940038,
  "created_at" : "2016-02-06 08:34:07 +0000",
  "in_reply_to_screen_name" : "chocho_z",
  "in_reply_to_user_id_str" : "3221119766",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chocho Zhang",
      "screen_name" : "chocho_z",
      "indices" : [ 0, 9 ],
      "id_str" : "3221119766",
      "id" : 3221119766
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "695820920930185217",
  "geo" : { },
  "id_str" : "695887485210116096",
  "in_reply_to_user_id" : 3221119766,
  "text" : "@chocho_z yay, you\u2019ve made it!",
  "id" : 695887485210116096,
  "in_reply_to_status_id" : 695820920930185217,
  "created_at" : "2016-02-06 08:31:20 +0000",
  "in_reply_to_screen_name" : "chocho_z",
  "in_reply_to_user_id_str" : "3221119766",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/PLlpIvINMw",
      "expanded_url" : "https:\/\/twitter.com\/tonyR_H\/status\/695878214632218625",
      "display_url" : "twitter.com\/tonyR_H\/status\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "695884763400380418",
  "text" : "nice! though I still prefer to think of Assange as that asshole couchsurfer that doesn\u2019t leave. https:\/\/t.co\/PLlpIvINMw",
  "id" : 695884763400380418,
  "created_at" : "2016-02-06 08:20:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 43 ],
      "url" : "https:\/\/t.co\/Lrj4D08YS8",
      "expanded_url" : "https:\/\/twitter.com\/Skepticscalpel\/status\/695729561489772544",
      "display_url" : "twitter.com\/Skepticscalpel\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "695884229687832576",
  "text" : "that\u2019s so unfair :\/ https:\/\/t.co\/Lrj4D08YS8",
  "id" : 695884229687832576,
  "created_at" : "2016-02-06 08:18:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u24EA Rik Smith-Unna \uD83C\uDDF0\uD83C\uDDEA",
      "screen_name" : "blahah404",
      "indices" : [ 0, 10 ],
      "id_str" : "99173786",
      "id" : 99173786
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "695713316849786880",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.50106717961829, 13.41725031782069 ]
  },
  "id_str" : "695714316792827905",
  "in_reply_to_user_id" : 99173786,
  "text" : "@blahah404 that\u2019s fine. I\u2019m more into sweet stuff anyhow ;)",
  "id" : 695714316792827905,
  "in_reply_to_status_id" : 695713316849786880,
  "created_at" : "2016-02-05 21:03:13 +0000",
  "in_reply_to_screen_name" : "blahah404",
  "in_reply_to_user_id_str" : "99173786",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u24EA Rik Smith-Unna \uD83C\uDDF0\uD83C\uDDEA",
      "screen_name" : "blahah404",
      "indices" : [ 33, 43 ],
      "id_str" : "99173786",
      "id" : 99173786
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/695705709334364161\/photo\/1",
      "indices" : [ 45, 68 ],
      "url" : "https:\/\/t.co\/Kxl4xpTs4W",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CaekpPrWIAAuYaL.jpg",
      "id_str" : "695705695941959680",
      "id" : 695705695941959680,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CaekpPrWIAAuYaL.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      } ],
      "display_url" : "pic.twitter.com\/Kxl4xpTs4W"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.50222834722607, 13.41141640319528 ]
  },
  "id_str" : "695705709334364161",
  "text" : "I might have eaten your dessert, @blahah404. https:\/\/t.co\/Kxl4xpTs4W",
  "id" : 695705709334364161,
  "created_at" : "2016-02-05 20:29:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.5020746177638, 13.4112862059937 ]
  },
  "id_str" : "695699517493133313",
  "text" : "\u00ABWe\u2019re close, we\u2019ll get to the bottom of particle physics tonight!\u00BB \u2014 \u00ABI\u2019m sure the truth will be on the bottom of this glass.\u00BB",
  "id" : 695699517493133313,
  "created_at" : "2016-02-05 20:04:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/695672425338556417\/photo\/1",
      "indices" : [ 21, 44 ],
      "url" : "https:\/\/t.co\/jtpCPUTY8c",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CaeGXITWwAAmTMb.jpg",
      "id_str" : "695672399375810560",
      "id" : 695672399375810560,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CaeGXITWwAAmTMb.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/jtpCPUTY8c"
    } ],
    "hashtags" : [ {
      "text" : "mozWOW",
      "indices" : [ 13, 20 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.50204348549646, 13.4112922618951 ]
  },
  "id_str" : "695672425338556417",
  "text" : "Bathroom art #mozWOW https:\/\/t.co\/jtpCPUTY8c",
  "id" : 695672425338556417,
  "created_at" : "2016-02-05 18:16:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mozwow",
      "indices" : [ 10, 17 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/J3lV4u9AYF",
      "expanded_url" : "https:\/\/github.com\/gedankenstuecke\/snpr\/issues?q=is%3Aissue+is%3Aopen+label%3Aeasy-first-bugs",
      "display_url" : "github.com\/gedankenstueck\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "695648637116932096",
  "text" : "Following #mozwow I added a new bug category to our GitHub. Feel free to add to it. https:\/\/t.co\/J3lV4u9AYF",
  "id" : 695648637116932096,
  "created_at" : "2016-02-05 16:42:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Head",
      "screen_name" : "betatim",
      "indices" : [ 0, 8 ],
      "id_str" : "18881614",
      "id" : 18881614
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rainmakingloft",
      "indices" : [ 60, 75 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "695315996886827010",
  "geo" : { },
  "id_str" : "695644354053021697",
  "in_reply_to_user_id" : 18881614,
  "text" : "@betatim @LoftBerlin I think it counted up since yesterday? #rainmakingloft",
  "id" : 695644354053021697,
  "in_reply_to_status_id" : 695315996886827010,
  "created_at" : "2016-02-05 16:25:13 +0000",
  "in_reply_to_screen_name" : "betatim",
  "in_reply_to_user_id_str" : "18881614",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mozwow",
      "indices" : [ 41, 48 ]
    } ],
    "urls" : [ {
      "indices" : [ 49, 72 ],
      "url" : "https:\/\/t.co\/G4Milfpk0a",
      "expanded_url" : "https:\/\/twitter.com\/BrianMBot\/status\/695628406810136577",
      "display_url" : "twitter.com\/BrianMBot\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "695643258706382848",
  "text" : "The creed of the open science community. #mozwow https:\/\/t.co\/G4Milfpk0a",
  "id" : 695643258706382848,
  "created_at" : "2016-02-05 16:20:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 7, 30 ],
      "url" : "https:\/\/t.co\/ghElIDiMtk",
      "expanded_url" : "http:\/\/1.bp.blogspot.com\/--My0-QHsUyI\/UC_Ej3XffRI\/AAAAAAAAElA\/oJ7OUfXFM5E\/s1600\/fuck-the-police-dog-on-top-of-truck.png",
      "display_url" : "1.bp.blogspot.com\/--My0-QHsUyI\/U\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "695641789030596608",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.50559086700891, 13.39339950845646 ]
  },
  "id_str" : "695642087786676225",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot https:\/\/t.co\/ghElIDiMtk",
  "id" : 695642087786676225,
  "in_reply_to_status_id" : 695641789030596608,
  "created_at" : "2016-02-05 16:16:12 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "695632694533865472",
  "geo" : { },
  "id_str" : "695632887056617473",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot I think I failed obedience class\u2026",
  "id" : 695632887056617473,
  "in_reply_to_status_id" : 695632694533865472,
  "created_at" : "2016-02-05 15:39:39 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 3, 9 ],
      "id_str" : "1492631",
      "id" : 1492631
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 11, 27 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 51 ],
      "url" : "https:\/\/t.co\/9H9BjKOdld",
      "expanded_url" : "https:\/\/twitter.com\/dog_rates\/status\/695629776980148225",
      "display_url" : "twitter.com\/dog_rates\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "695632771692281857",
  "text" : "RT @Lobot: @gedankenstuecke https:\/\/t.co\/9H9BjKOdld",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 0, 16 ],
        "id_str" : "14286491",
        "id" : 14286491
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 17, 40 ],
        "url" : "https:\/\/t.co\/9H9BjKOdld",
        "expanded_url" : "https:\/\/twitter.com\/dog_rates\/status\/695629776980148225",
        "display_url" : "twitter.com\/dog_rates\/stat\u2026"
      } ]
    },
    "in_reply_to_status_id_str" : "695612209813196800",
    "geo" : { },
    "id_str" : "695632694533865472",
    "in_reply_to_user_id" : 14286491,
    "text" : "@gedankenstuecke https:\/\/t.co\/9H9BjKOdld",
    "id" : 695632694533865472,
    "in_reply_to_status_id" : 695612209813196800,
    "created_at" : "2016-02-05 15:38:53 +0000",
    "in_reply_to_screen_name" : "gedankenstuecke",
    "in_reply_to_user_id_str" : "14286491",
    "user" : {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "protected" : false,
      "id_str" : "1492631",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/783617256173494272\/7QL2FeUx_normal.jpg",
      "id" : 1492631,
      "verified" : false
    }
  },
  "id" : 695632771692281857,
  "created_at" : "2016-02-05 15:39:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mozwow",
      "indices" : [ 109, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 48, 71 ],
      "url" : "https:\/\/t.co\/UuIyKioFks",
      "expanded_url" : "https:\/\/github.com\/gedankenstuecke\/snpr\/pull\/240",
      "display_url" : "github.com\/gedankenstueck\u2026"
    }, {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/MUXcVlgK6q",
      "expanded_url" : "https:\/\/github.com\/fathomlabs\/business_cards\/pull\/2",
      "display_url" : "github.com\/fathomlabs\/bus\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "695627188503232512",
  "text" : "the outcome of our crossed git-streams part 1\/2 https:\/\/t.co\/UuIyKioFks and part 2\/2 https:\/\/t.co\/MUXcVlgK6q #mozwow",
  "id" : 695627188503232512,
  "created_at" : "2016-02-05 15:17:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mozwow",
      "indices" : [ 50, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 26, 49 ],
      "url" : "https:\/\/t.co\/DFfF7ZqbAw",
      "expanded_url" : "http:\/\/cdn.makeagif.com\/media\/5-31-2015\/oIxPiv.gif",
      "display_url" : "cdn.makeagif.com\/media\/5-31-201\u2026"
    }, {
      "indices" : [ 60, 83 ],
      "url" : "https:\/\/t.co\/htMXiHRlBP",
      "expanded_url" : "https:\/\/twitter.com\/cbahlai\/status\/695616781126393857",
      "display_url" : "twitter.com\/cbahlai\/status\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "695621578491559936",
  "text" : "Crossing the git-streams! https:\/\/t.co\/DFfF7ZqbAw #mozwow   https:\/\/t.co\/htMXiHRlBP",
  "id" : 695621578491559936,
  "created_at" : "2016-02-05 14:54:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "695612209813196800",
  "text" : "\u00ABAquaculture 2016 Dr.greshake Honorable Speaker\u00BB lolnope.jpg",
  "id" : 695612209813196800,
  "created_at" : "2016-02-05 14:17:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "695581692636098560",
  "text" : "\u00ABI\u2019m amazed by people who are proficient in R in the same way proficient Excel users amaze me.\u00BB",
  "id" : 695581692636098560,
  "created_at" : "2016-02-05 12:16:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 20, 29 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/695571838009786369\/photo\/1",
      "indices" : [ 50, 73 ],
      "url" : "https:\/\/t.co\/9Ut39pXEdK",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cacq5fEWAAIKC73.jpg",
      "id_str" : "695571834532659202",
      "id" : 695571834532659202,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cacq5fEWAAIKC73.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/9Ut39pXEdK"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.50559873923733, 13.3933006031933 ]
  },
  "id_str" : "695571838009786369",
  "text" : "Fitting, given that @Senficon was here yesterday. https:\/\/t.co\/9Ut39pXEdK",
  "id" : 695571838009786369,
  "created_at" : "2016-02-05 11:37:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "695551679186538496",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.50559132992058, 13.39336570456259 ]
  },
  "id_str" : "695552346659647488",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot eine Bohrmaschine f\u00FCr Ameisen?",
  "id" : 695552346659647488,
  "in_reply_to_status_id" : 695551679186538496,
  "created_at" : "2016-02-05 10:19:36 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mozWOW",
      "indices" : [ 110, 117 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "695549483837485056",
  "text" : "Q: Is having a CONTRIBUTING.md useful when I\u2019m the sole contributor? A: Start light and improve incrementally #mozWOW",
  "id" : 695549483837485056,
  "created_at" : "2016-02-05 10:08:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 46 ],
      "url" : "https:\/\/t.co\/WSnvn97UxQ",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=1gIH94st0mY",
      "display_url" : "youtube.com\/watch?v=1gIH94\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "695536456174014464",
  "geo" : { },
  "id_str" : "695544510626078720",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot Z\u00E4hlt das auch? https:\/\/t.co\/WSnvn97UxQ",
  "id" : 695544510626078720,
  "in_reply_to_status_id" : 695536456174014464,
  "created_at" : "2016-02-05 09:48:28 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mozwow",
      "indices" : [ 34, 41 ]
    } ],
    "urls" : [ {
      "indices" : [ 42, 65 ],
      "url" : "https:\/\/t.co\/hXl5nNhSNQ",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BBZlP2nhwjI\/",
      "display_url" : "instagram.com\/p\/BBZlP2nhwjI\/"
    } ]
  },
  "geo" : { },
  "id_str" : "695540907156836352",
  "text" : "The lichenologist in me approves! #mozwow https:\/\/t.co\/hXl5nNhSNQ",
  "id" : 695540907156836352,
  "created_at" : "2016-02-05 09:34:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mozwow",
      "indices" : [ 20, 27 ]
    } ],
    "urls" : [ {
      "indices" : [ 49, 72 ],
      "url" : "https:\/\/t.co\/auMGArlGtB",
      "expanded_url" : "http:\/\/mozillascience.github.io\/working-open-workshop\/code_of_conduct\/",
      "display_url" : "mozillascience.github.io\/working-open-w\u2026"
    }, {
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/onpsRFlBaI",
      "expanded_url" : "https:\/\/twitter.com\/cbahlai\/status\/695528451978170368",
      "display_url" : "twitter.com\/cbahlai\/status\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "695533961678884864",
  "text" : "That was great fun! #mozwow Also yay for the CoC https:\/\/t.co\/auMGArlGtB https:\/\/t.co\/onpsRFlBaI",
  "id" : 695533961678884864,
  "created_at" : "2016-02-05 09:06:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mozWOW",
      "indices" : [ 24, 31 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.50557751020603, 13.39356308738904 ]
  },
  "id_str" : "695515605299027968",
  "text" : "Up early and already at #mozWOW.",
  "id" : 695515605299027968,
  "created_at" : "2016-02-05 07:53:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u24EA Rik Smith-Unna \uD83C\uDDF0\uD83C\uDDEA",
      "screen_name" : "blahah404",
      "indices" : [ 0, 10 ],
      "id_str" : "99173786",
      "id" : 99173786
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "695392361409437698",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.53687665711231, 13.37833132071505 ]
  },
  "id_str" : "695392668763828224",
  "in_reply_to_user_id" : 99173786,
  "text" : "@blahah404 thank you, hope we have more time to chat tomorrow\/saturday! :)",
  "id" : 695392668763828224,
  "in_reply_to_status_id" : 695392361409437698,
  "created_at" : "2016-02-04 23:45:06 +0000",
  "in_reply_to_screen_name" : "blahah404",
  "in_reply_to_user_id_str" : "99173786",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u24EA Rik Smith-Unna \uD83C\uDDF0\uD83C\uDDEA",
      "screen_name" : "blahah404",
      "indices" : [ 60, 70 ],
      "id_str" : "99173786",
      "id" : 99173786
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MozSci",
      "indices" : [ 45, 52 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.53686589029529, 13.37818180795951 ]
  },
  "id_str" : "695391585916231680",
  "text" : "Thanks for an awesome evening to everyone at #MozSci and to @blahah404 in particular! \uD83D\uDC4D\uD83D\uDC4D\uD83D\uDC4D",
  "id" : 695391585916231680,
  "created_at" : "2016-02-04 23:40:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Brechler",
      "screen_name" : "gutsle",
      "indices" : [ 0, 7 ],
      "id_str" : "837535866",
      "id" : 837535866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "695325432477040640",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.50560327329595, 13.39349226935826 ]
  },
  "id_str" : "695325584671531008",
  "in_reply_to_user_id" : 837535866,
  "text" : "@gutsle ist eingepackt :)",
  "id" : 695325584671531008,
  "in_reply_to_status_id" : 695325432477040640,
  "created_at" : "2016-02-04 19:18:32 +0000",
  "in_reply_to_screen_name" : "gutsle",
  "in_reply_to_user_id_str" : "837535866",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexandra Swanson",
      "screen_name" : "alicatzoo",
      "indices" : [ 9, 19 ],
      "id_str" : "2814885498",
      "id" : 2814885498
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MozSci",
      "indices" : [ 64, 71 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.50558675190766, 13.39354053823231 ]
  },
  "id_str" : "695316688460472320",
  "text" : "Up next: @alicatzoo, talking about Citizen Science and Ecology. #MozSci",
  "id" : 695316688460472320,
  "created_at" : "2016-02-04 18:43:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mozsci",
      "indices" : [ 79, 86 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.50560565836894, 13.39342943278523 ]
  },
  "id_str" : "695315760160313344",
  "text" : "\u00ABThe article is the unit of research\u00BB I think soon it will be the data itself. #mozsci",
  "id" : 695315760160313344,
  "created_at" : "2016-02-04 18:39:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/695311669552140289\/photo\/1",
      "indices" : [ 28, 51 ],
      "url" : "https:\/\/t.co\/y5jmNG0840",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CaY-RxfWAAANGe_.jpg",
      "id_str" : "695311667538821120",
      "id" : 695311667538821120,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CaY-RxfWAAANGe_.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      } ],
      "display_url" : "pic.twitter.com\/y5jmNG0840"
    } ],
    "hashtags" : [ {
      "text" : "MozSci",
      "indices" : [ 20, 27 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.50562127472561, 13.39346740625398 ]
  },
  "id_str" : "695311669552140289",
  "text" : "Meet the sciencefox #MozSci https:\/\/t.co\/y5jmNG0840",
  "id" : 695311669552140289,
  "created_at" : "2016-02-04 18:23:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/695310565149954048\/photo\/1",
      "indices" : [ 52, 75 ],
      "url" : "https:\/\/t.co\/Rn8iVzCqKg",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CaY9RflW4AAMPj7.jpg",
      "id_str" : "695310563220578304",
      "id" : 695310563220578304,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CaY9RflW4AAMPj7.jpg",
      "sizes" : [ {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/Rn8iVzCqKg"
    } ],
    "hashtags" : [ {
      "text" : "MozSci",
      "indices" : [ 4, 11 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.50558790786393, 13.39336682825151 ]
  },
  "id_str" : "695310565149954048",
  "text" : "The #MozSci open science meetup is pretty packed. \uD83D\uDC4D https:\/\/t.co\/Rn8iVzCqKg",
  "id" : 695310565149954048,
  "created_at" : "2016-02-04 18:18:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "695299223026270208",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.50559852060211, 13.39340039936672 ]
  },
  "id_str" : "695310172848259078",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot trust me, those are 18 parsecs.",
  "id" : 695310172848259078,
  "in_reply_to_status_id" : 695299223026270208,
  "created_at" : "2016-02-04 18:17:18 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 121, 144 ],
      "url" : "https:\/\/t.co\/iaP0YpUdpq",
      "expanded_url" : "https:\/\/twitter.com\/eltonjohn\/status\/695297943226695680",
      "display_url" : "twitter.com\/eltonjohn\/stat\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.53690900227135, 13.37837545177461 ]
  },
  "id_str" : "695298643780321282",
  "text" : "Giving \"52 years\" for penis length? Bet Han Solo entered that phenotype &amp; \"Doing the Kessel run\" was code after all. https:\/\/t.co\/iaP0YpUdpq",
  "id" : 695298643780321282,
  "created_at" : "2016-02-04 17:31:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Pardy",
      "screen_name" : "BrianPardy",
      "indices" : [ 0, 11 ],
      "id_str" : "611699110",
      "id" : 611699110
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "695268150670147584",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.53697608590589, 13.37851302558086 ]
  },
  "id_str" : "695274384425115648",
  "in_reply_to_user_id" : 611699110,
  "text" : "@BrianPardy I think there will be enough people for that :)",
  "id" : 695274384425115648,
  "in_reply_to_status_id" : 695268150670147584,
  "created_at" : "2016-02-04 15:55:05 +0000",
  "in_reply_to_screen_name" : "BrianPardy",
  "in_reply_to_user_id_str" : "611699110",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Pardy",
      "screen_name" : "BrianPardy",
      "indices" : [ 0, 11 ],
      "id_str" : "611699110",
      "id" : 611699110
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "695265479976423424",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.52886393335719, 13.38528655321494 ]
  },
  "id_str" : "695267780271194114",
  "in_reply_to_user_id" : 611699110,
  "text" : "@BrianPardy thanks for taking the time, it\u2019s super valuable for us!",
  "id" : 695267780271194114,
  "in_reply_to_status_id" : 695265479976423424,
  "created_at" : "2016-02-04 15:28:50 +0000",
  "in_reply_to_screen_name" : "BrianPardy",
  "in_reply_to_user_id_str" : "611699110",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daan Speth",
      "screen_name" : "daanspeth",
      "indices" : [ 0, 10 ],
      "id_str" : "1536778088",
      "id" : 1536778088
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "695256955225534464",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.52680918738938, 13.38718121921046 ]
  },
  "id_str" : "695265004161998848",
  "in_reply_to_user_id" : 1536778088,
  "text" : "@daanspeth yes, please :)",
  "id" : 695265004161998848,
  "in_reply_to_status_id" : 695256955225534464,
  "created_at" : "2016-02-04 15:17:49 +0000",
  "in_reply_to_screen_name" : "daanspeth",
  "in_reply_to_user_id_str" : "1536778088",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 57 ],
      "url" : "https:\/\/t.co\/QMHL0N1WGK",
      "expanded_url" : "https:\/\/twitter.com\/twisteddoodles\/status\/695216901081976832",
      "display_url" : "twitter.com\/twisteddoodles\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.52691129537293, 13.38720100165272 ]
  },
  "id_str" : "695264745776103425",
  "text" : "Depending on your chance to fail. https:\/\/t.co\/QMHL0N1WGK",
  "id" : 695264745776103425,
  "created_at" : "2016-02-04 15:16:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FORCE2016",
      "indices" : [ 39, 49 ]
    } ],
    "urls" : [ {
      "indices" : [ 63, 86 ],
      "url" : "https:\/\/t.co\/tSoVIEtFPQ",
      "expanded_url" : "https:\/\/www.force11.org\/meetings\/force2016\/program\/agenda",
      "display_url" : "force11.org\/meetings\/force\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.53698, 13.378191 ]
  },
  "id_str" : "695246762274062336",
  "text" : "More good news are in: I will speak at #FORCE2016 in Portland. https:\/\/t.co\/tSoVIEtFPQ",
  "id" : 695246762274062336,
  "created_at" : "2016-02-04 14:05:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 13, 26 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "MailChimp",
      "screen_name" : "MailChimp",
      "indices" : [ 27, 37 ],
      "id_str" : "14377870",
      "id" : 14377870
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "695234537190772736",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.5534739173731, 13.29227038395838 ]
  },
  "id_str" : "695234932180934656",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch @PhilippBayer @MailChimp ok, in that case we can stick to doing it ourselves. Especially given our frequency ;)",
  "id" : 695234932180934656,
  "in_reply_to_status_id" : 695234537190772736,
  "created_at" : "2016-02-04 13:18:19 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.55426807933577, 13.289374130588 ]
  },
  "id_str" : "695233237422051329",
  "text" : "Hey Berlin. \uD83D\uDEEC",
  "id" : 695233237422051329,
  "created_at" : "2016-02-04 13:11:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 14, 26 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "695224949359808512",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.55428947874582, 13.28921066311628 ]
  },
  "id_str" : "695232896009900032",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @helgerausch thanks, worked \uD83D\uDC4D",
  "id" : 695232896009900032,
  "in_reply_to_status_id" : 695224949359808512,
  "created_at" : "2016-02-04 13:10:13 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 13, 26 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "MailChimp",
      "screen_name" : "MailChimp",
      "indices" : [ 27, 37 ],
      "id_str" : "14377870",
      "id" : 14377870
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "695223930609496065",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.55429016398821, 13.2891989539246 ]
  },
  "id_str" : "695232849780334592",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch @PhilippBayer @MailChimp yes, would be useful to set this up I think :)",
  "id" : 695232849780334592,
  "in_reply_to_status_id" : 695223930609496065,
  "created_at" : "2016-02-04 13:10:02 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/695199192734683136\/photo\/1",
      "indices" : [ 2, 25 ],
      "url" : "https:\/\/t.co\/YGvfTLPAaB",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CaXX-xeWQAAaLvH.jpg",
      "id_str" : "695199190931095552",
      "id" : 695199190931095552,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CaXX-xeWQAAaLvH.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      } ],
      "display_url" : "pic.twitter.com\/YGvfTLPAaB"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.04701051445618, 8.567806045220575 ]
  },
  "id_str" : "695199192734683136",
  "text" : "\u2026 https:\/\/t.co\/YGvfTLPAaB",
  "id" : 695199192734683136,
  "created_at" : "2016-02-04 10:56:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "695197974218022912",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.04704569630231, 8.567789648380172 ]
  },
  "id_str" : "695198278988754944",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot awww, though usually the only thing I bring back from Berlin is some more psychological damage\u2026",
  "id" : 695198278988754944,
  "in_reply_to_status_id" : 695197974218022912,
  "created_at" : "2016-02-04 10:52:40 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mozscience",
      "indices" : [ 18, 29 ]
    }, {
      "text" : "mozWOW",
      "indices" : [ 34, 41 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.04699121237741, 8.567692353130603 ]
  },
  "id_str" : "695196759992176640",
  "text" : "Off to Berlin for #mozscience and #mozWOW. \u2708\uFE0F",
  "id" : 695196759992176640,
  "created_at" : "2016-02-04 10:46:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/2SRDZ9kfb6",
      "expanded_url" : "https:\/\/twitter.com\/MozillaScience\/status\/695166754184679424",
      "display_url" : "twitter.com\/MozillaScience\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.10634480514573, 8.751929746948882 ]
  },
  "id_str" : "695181969643167744",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch btw, see you this evening? Otherwise I\u2019ll be in town until Sunday as well. https:\/\/t.co\/2SRDZ9kfb6",
  "id" : 695181969643167744,
  "created_at" : "2016-02-04 09:47:52 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 14, 26 ],
      "id_str" : "52747896",
      "id" : 52747896
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 51, 63 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "695137008675459073",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11404119932152, 8.753438288553234 ]
  },
  "id_str" : "695176363427368960",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @helgerausch search your email, iirc @helgerausch sent a how-to last time. On the way to the airport and can\u2019t search myself.",
  "id" : 695176363427368960,
  "in_reply_to_status_id" : 695137008675459073,
  "created_at" : "2016-02-04 09:25:35 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 79 ],
      "url" : "https:\/\/t.co\/33SsSHdxM0",
      "expanded_url" : "http:\/\/thefinchandpea.com\/2016\/01\/27\/art-of-science-frozen-fractals-all-around\/",
      "display_url" : "thefinchandpea.com\/2016\/01\/27\/art\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "695163323873128448",
  "text" : "creating fractal art, using only snowshoes and a compas https:\/\/t.co\/33SsSHdxM0",
  "id" : 695163323873128448,
  "created_at" : "2016-02-04 08:33:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc RobinsonRechavi",
      "screen_name" : "marc_rr",
      "indices" : [ 0, 8 ],
      "id_str" : "454724555",
      "id" : 454724555
    }, {
      "name" : "Iddo Friedberg",
      "screen_name" : "iddux",
      "indices" : [ 9, 15 ],
      "id_str" : "15276911",
      "id" : 15276911
    }, {
      "name" : "Nick Loman",
      "screen_name" : "pathogenomenick",
      "indices" : [ 16, 32 ],
      "id_str" : "85906238",
      "id" : 85906238
    }, {
      "name" : "Lars Juhl Jensen",
      "screen_name" : "larsjuhljensen",
      "indices" : [ 33, 48 ],
      "id_str" : "14962567",
      "id" : 14962567
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "694996382218854402",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11403765407254, 8.75344648586201 ]
  },
  "id_str" : "695000090893754370",
  "in_reply_to_user_id" : 454724555,
  "text" : "@marc_rr @iddux @pathogenomenick @larsjuhljensen let me just like this.",
  "id" : 695000090893754370,
  "in_reply_to_status_id" : 694996382218854402,
  "created_at" : "2016-02-03 21:45:08 +0000",
  "in_reply_to_screen_name" : "marc_rr",
  "in_reply_to_user_id_str" : "454724555",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uD83D\uDD25\uD83D\uDC1C\uD83D\uDC78\uD83C\uDFFC",
      "screen_name" : "fireantprincess",
      "indices" : [ 0, 16 ],
      "id_str" : "77216385",
      "id" : 77216385
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "694956354512015360",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11403950449569, 8.753450224171695 ]
  },
  "id_str" : "694956462007808002",
  "in_reply_to_user_id" : 77216385,
  "text" : "@fireantprincess danke &lt;3",
  "id" : 694956462007808002,
  "in_reply_to_status_id" : 694956354512015360,
  "created_at" : "2016-02-03 18:51:46 +0000",
  "in_reply_to_screen_name" : "fireantprincess",
  "in_reply_to_user_id_str" : "77216385",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "witch@serenity",
      "screen_name" : "_MinaHarker_",
      "indices" : [ 0, 13 ],
      "id_str" : "1068997124",
      "id" : 1068997124
    }, {
      "name" : "\uD83D\uDD25\uD83D\uDC1C\uD83D\uDC78\uD83C\uDFFC",
      "screen_name" : "fireantprincess",
      "indices" : [ 14, 30 ],
      "id_str" : "77216385",
      "id" : 77216385
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "694943290882445312",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11403950449569, 8.753450224171695 ]
  },
  "id_str" : "694955242929127424",
  "in_reply_to_user_id" : 1068997124,
  "text" : "@_MinaHarker_ @fireantprincess +1, will auch :)",
  "id" : 694955242929127424,
  "in_reply_to_status_id" : 694943290882445312,
  "created_at" : "2016-02-03 18:46:56 +0000",
  "in_reply_to_screen_name" : "_MinaHarker_",
  "in_reply_to_user_id_str" : "1068997124",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/QGjftlv2ht",
      "expanded_url" : "https:\/\/twitter.com\/michaelhoffman\/status\/694926792784629761",
      "display_url" : "twitter.com\/michaelhoffman\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11397964641586, 8.753520537703562 ]
  },
  "id_str" : "694950692960788480",
  "text" : "\u00ABLander\u2019s \u201CHeroes of CRISPR\u201D piece is, in this sense, a master class in bullshit.\u00BB https:\/\/t.co\/QGjftlv2ht",
  "id" : 694950692960788480,
  "created_at" : "2016-02-03 18:28:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amy Harmon",
      "screen_name" : "amy_harmon",
      "indices" : [ 3, 14 ],
      "id_str" : "16227629",
      "id" : 16227629
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "694941852118736896",
  "text" : "RT @amy_harmon: Don\u2019t like to use blind quotes, so was hard to convey students\u2019 sense of betrayal. But it was palpable. https:\/\/t.co\/WNc0iM\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 104, 127 ],
        "url" : "https:\/\/t.co\/WNc0iMiCoE",
        "expanded_url" : "http:\/\/www.nytimes.com\/2016\/02\/03\/us\/chicago-professor-resigns-amid-sexual-misconduct-investigation.html?_r=0",
        "display_url" : "nytimes.com\/2016\/02\/03\/us\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "694911816028311552",
    "text" : "Don\u2019t like to use blind quotes, so was hard to convey students\u2019 sense of betrayal. But it was palpable. https:\/\/t.co\/WNc0iMiCoE",
    "id" : 694911816028311552,
    "created_at" : "2016-02-03 15:54:22 +0000",
    "user" : {
      "name" : "Amy Harmon",
      "screen_name" : "amy_harmon",
      "protected" : false,
      "id_str" : "16227629",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/834266859071533063\/dCqR-E9v_normal.jpg",
      "id" : 16227629,
      "verified" : true
    }
  },
  "id" : 694941852118736896,
  "created_at" : "2016-02-03 17:53:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "deepart.io",
      "screen_name" : "deepart_io",
      "indices" : [ 8, 19 ],
      "id_str" : "4188236789",
      "id" : 4188236789
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/694872451541508097\/photo\/1",
      "indices" : [ 41, 64 ],
      "url" : "https:\/\/t.co\/QB6EyXUHpC",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CaSuz93W4AANouB.jpg",
      "id_str" : "694872450325209088",
      "id" : 694872450325209088,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CaSuz93W4AANouB.jpg",
      "sizes" : [ {
        "h" : 500,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 500,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 500,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 500,
        "resize" : "fit",
        "w" : 500
      } ],
      "display_url" : "pic.twitter.com\/QB6EyXUHpC"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "694083744219664384",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.18147867484903, 8.615099132550512 ]
  },
  "id_str" : "694872451541508097",
  "in_reply_to_user_id" : 14286491,
  "text" : "Another @deepart_io try, using Van Gogh. https:\/\/t.co\/QB6EyXUHpC",
  "id" : 694872451541508097,
  "in_reply_to_status_id" : 694083744219664384,
  "created_at" : "2016-02-03 13:17:57 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 3, 12 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "marrakesh",
      "indices" : [ 120, 130 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/fxoL4buSYE",
      "expanded_url" : "https:\/\/juliareda.eu\/2016\/02\/marrakesh-blocking-access-to-knowledge\/",
      "display_url" : "juliareda.eu\/2016\/02\/marrak\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "694848463578730496",
  "text" : "RT @Senficon: A few EU governments are blocking blind people\u2019s access to knowledge. Here\u2019s why. https:\/\/t.co\/fxoL4buSYE #marrakesh https:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Senficon\/status\/694828572607975424\/photo\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/fhNeBNEr14",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CaSG5Z5WQAAUIni.jpg",
        "id_str" : "694828563283984384",
        "id" : 694828563283984384,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CaSG5Z5WQAAUIni.jpg",
        "sizes" : [ {
          "h" : 459,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 540,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 540,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 540,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/fhNeBNEr14"
      } ],
      "hashtags" : [ {
        "text" : "marrakesh",
        "indices" : [ 106, 116 ]
      } ],
      "urls" : [ {
        "indices" : [ 82, 105 ],
        "url" : "https:\/\/t.co\/fxoL4buSYE",
        "expanded_url" : "https:\/\/juliareda.eu\/2016\/02\/marrakesh-blocking-access-to-knowledge\/",
        "display_url" : "juliareda.eu\/2016\/02\/marrak\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "694828572607975424",
    "text" : "A few EU governments are blocking blind people\u2019s access to knowledge. Here\u2019s why. https:\/\/t.co\/fxoL4buSYE #marrakesh https:\/\/t.co\/fhNeBNEr14",
    "id" : 694828572607975424,
    "created_at" : "2016-02-03 10:23:35 +0000",
    "user" : {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "protected" : false,
      "id_str" : "14861745",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/637016870638350336\/QrtPmoul_normal.jpg",
      "id" : 14861745,
      "verified" : true
    }
  },
  "id" : 694848463578730496,
  "created_at" : "2016-02-03 11:42:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dawn Field",
      "screen_name" : "fiedawn",
      "indices" : [ 0, 8 ],
      "id_str" : "18589743",
      "id" : 18589743
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "694828726983495680",
  "geo" : { },
  "id_str" : "694836515596300288",
  "in_reply_to_user_id" : 18589743,
  "text" : "@fiedawn good idea, making some science-shirts, visualising your own data :D",
  "id" : 694836515596300288,
  "in_reply_to_status_id" : 694828726983495680,
  "created_at" : "2016-02-03 10:55:09 +0000",
  "in_reply_to_screen_name" : "fiedawn",
  "in_reply_to_user_id_str" : "18589743",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "694824194673111040",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17247207400786, 8.62751485301168 ]
  },
  "id_str" : "694827024083501056",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot too bad it's not one of the Phallus genus :D",
  "id" : 694827024083501056,
  "in_reply_to_status_id" : 694824194673111040,
  "created_at" : "2016-02-03 10:17:26 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 83 ],
      "url" : "https:\/\/t.co\/T28wrY6aEq",
      "expanded_url" : "https:\/\/www.etsy.com\/listing\/266705538\/lichen-card-moss-card-valentines-day",
      "display_url" : "etsy.com\/listing\/266705\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "694822279834910720",
  "text" : "i\u2019m not one for valentine\u2019s day cards, but this one is cute https:\/\/t.co\/T28wrY6aEq",
  "id" : 694822279834910720,
  "created_at" : "2016-02-03 09:58:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 68 ],
      "url" : "https:\/\/t.co\/GbBNZDPNxj",
      "expanded_url" : "https:\/\/twitter.com\/oken_ne\/status\/692652235054981120",
      "display_url" : "twitter.com\/oken_ne\/status\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "694820391345377280",
  "text" : "This would easily work with my cat as well.  https:\/\/t.co\/GbBNZDPNxj",
  "id" : 694820391345377280,
  "created_at" : "2016-02-03 09:51:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "S\u00F6ren Schewe",
      "screen_name" : "Roterhai",
      "indices" : [ 56, 65 ],
      "id_str" : "25101713",
      "id" : 25101713
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 55 ],
      "url" : "https:\/\/t.co\/VNjOrAnHUc",
      "expanded_url" : "http:\/\/blogs.discovermagazine.com\/inkfish\/2016\/02\/02\/how-not-to-get-killed-by-a-cow\/",
      "display_url" : "blogs.discovermagazine.com\/inkfish\/2016\/0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "694813952887386113",
  "text" : "How not to get killed by a cow. https:\/\/t.co\/VNjOrAnHUc @Roterhai",
  "id" : 694813952887386113,
  "created_at" : "2016-02-03 09:25:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 73 ],
      "url" : "https:\/\/t.co\/ZCMI4aMVz8",
      "expanded_url" : "https:\/\/twitter.com\/BioDataGanache\/status\/694789153872019456",
      "display_url" : "twitter.com\/BioDataGanache\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "694804904616050688",
  "text" : "I\u2019ll stick to a clusterfuck of bioinformaticians. https:\/\/t.co\/ZCMI4aMVz8",
  "id" : 694804904616050688,
  "created_at" : "2016-02-03 08:49:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/694801641636233216\/photo\/1",
      "indices" : [ 39, 62 ],
      "url" : "https:\/\/t.co\/ilsp8Boawf",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CaRuaORWkAAa48f.png",
      "id_str" : "694801639308431360",
      "id" : 694801639308431360,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CaRuaORWkAAa48f.png",
      "sizes" : [ {
        "h" : 441,
        "resize" : "fit",
        "w" : 509
      }, {
        "h" : 441,
        "resize" : "fit",
        "w" : 509
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 441,
        "resize" : "fit",
        "w" : 509
      }, {
        "h" : 441,
        "resize" : "fit",
        "w" : 509
      } ],
      "display_url" : "pic.twitter.com\/ilsp8Boawf"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "694801641636233216",
  "text" : "Playing around with streamgraph for R. https:\/\/t.co\/ilsp8Boawf",
  "id" : 694801641636233216,
  "created_at" : "2016-02-03 08:36:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Repositive.io",
      "screen_name" : "repositiveio",
      "indices" : [ 0, 13 ],
      "id_str" : "3059929578",
      "id" : 3059929578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "694483911313887234",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17660153280008, 8.630075237117062 ]
  },
  "id_str" : "694581972069289984",
  "in_reply_to_user_id" : 3059929578,
  "text" : "@repositiveio that\u2019s great news! Congratulations, well deserved!",
  "id" : 694581972069289984,
  "in_reply_to_status_id" : 694483911313887234,
  "created_at" : "2016-02-02 18:03:41 +0000",
  "in_reply_to_screen_name" : "repositiveio",
  "in_reply_to_user_id_str" : "3059929578",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Eisen",
      "screen_name" : "mbeisen",
      "indices" : [ 0, 8 ],
      "id_str" : "19843630",
      "id" : 19843630
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "694534018088333312",
  "geo" : { },
  "id_str" : "694545189160013825",
  "in_reply_to_user_id" : 19843630,
  "text" : "@mbeisen too bad didn\u2019t get published in the same week as research parasites, heroes of crispr, cladistics etc, to prove journal quality\u2026",
  "id" : 694545189160013825,
  "in_reply_to_status_id" : 694534018088333312,
  "created_at" : "2016-02-02 15:37:31 +0000",
  "in_reply_to_screen_name" : "mbeisen",
  "in_reply_to_user_id_str" : "19843630",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 58 ],
      "url" : "https:\/\/t.co\/rYeBNk70Az",
      "expanded_url" : "http:\/\/i.imgur.com\/VzoGt.jpg",
      "display_url" : "i.imgur.com\/VzoGt.jpg"
    } ]
  },
  "in_reply_to_status_id_str" : "694519224711188480",
  "geo" : { },
  "id_str" : "694519466873462784",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot everything\u2019s under control! https:\/\/t.co\/rYeBNk70Az",
  "id" : 694519466873462784,
  "in_reply_to_status_id" : 694519224711188480,
  "created_at" : "2016-02-02 13:55:19 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 7, 30 ],
      "url" : "https:\/\/t.co\/95fjsma5Xd",
      "expanded_url" : "https:\/\/media3.giphy.com\/media\/ryxqsv4gUBlMQ\/200.gif",
      "display_url" : "media3.giphy.com\/media\/ryxqsv4g\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "694515491390537729",
  "geo" : { },
  "id_str" : "694517239014375424",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot https:\/\/t.co\/95fjsma5Xd",
  "id" : 694517239014375424,
  "in_reply_to_status_id" : 694515491390537729,
  "created_at" : "2016-02-02 13:46:27 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uD83D\uDD25\uD83D\uDC1C\uD83D\uDC78\uD83C\uDFFC",
      "screen_name" : "fireantprincess",
      "indices" : [ 0, 16 ],
      "id_str" : "77216385",
      "id" : 77216385
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "694494127585673216",
  "geo" : { },
  "id_str" : "694494293420064768",
  "in_reply_to_user_id" : 77216385,
  "text" : "@fireantprincess wow, sehr cool. Aber das Original ist ja auch schon super :)",
  "id" : 694494293420064768,
  "in_reply_to_status_id" : 694494127585673216,
  "created_at" : "2016-02-02 12:15:17 +0000",
  "in_reply_to_screen_name" : "fireantprincess",
  "in_reply_to_user_id_str" : "77216385",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kaitlin Thaney \uD83D\uDC81\uD83C\uDFFB",
      "screen_name" : "kaythaney",
      "indices" : [ 0, 10 ],
      "id_str" : "22839233",
      "id" : 22839233
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 74 ],
      "url" : "https:\/\/t.co\/ptV99CfYVN",
      "expanded_url" : "http:\/\/whatshouldwecallgradschool.tumblr.com\/post\/138160401905\/when-i-need-to-analyze-my-collaborators-data",
      "display_url" : "whatshouldwecallgradschool.tumblr.com\/post\/138160401\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "694472744927387648",
  "geo" : { },
  "id_str" : "694475396167909377",
  "in_reply_to_user_id" : 22839233,
  "text" : "@kaythaney open data when it\u2019s not well structured https:\/\/t.co\/ptV99CfYVN",
  "id" : 694475396167909377,
  "in_reply_to_status_id" : 694472744927387648,
  "created_at" : "2016-02-02 11:00:11 +0000",
  "in_reply_to_screen_name" : "kaythaney",
  "in_reply_to_user_id_str" : "22839233",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kaitlin Thaney \uD83D\uDC81\uD83C\uDFFB",
      "screen_name" : "kaythaney",
      "indices" : [ 0, 10 ],
      "id_str" : "22839233",
      "id" : 22839233
    }, {
      "name" : "Mozilla Science Lab",
      "screen_name" : "MozillaScience",
      "indices" : [ 11, 26 ],
      "id_str" : "1428575976",
      "id" : 1428575976
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 61 ],
      "url" : "https:\/\/t.co\/cI91mEcD0x",
      "expanded_url" : "http:\/\/cdn.shopify.com\/s\/files\/1\/0426\/8609\/files\/annoyed_fan_large.gif?5318576807572744525",
      "display_url" : "cdn.shopify.com\/s\/files\/1\/0426\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "694466813904707584",
  "geo" : { },
  "id_str" : "694470346578268160",
  "in_reply_to_user_id" : 22839233,
  "text" : "@kaythaney @MozillaScience p &gt; .05 https:\/\/t.co\/cI91mEcD0x",
  "id" : 694470346578268160,
  "in_reply_to_status_id" : 694466813904707584,
  "created_at" : "2016-02-02 10:40:07 +0000",
  "in_reply_to_screen_name" : "kaythaney",
  "in_reply_to_user_id_str" : "22839233",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Cock",
      "screen_name" : "pjacock",
      "indices" : [ 0, 8 ],
      "id_str" : "58756672",
      "id" : 58756672
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "694461660531154944",
  "geo" : { },
  "id_str" : "694461970590908416",
  "in_reply_to_user_id" : 58756672,
  "text" : "@pjacock I saw your tweet later when catching up on my timeline. I think even if it\u2019s \u201Ejust\u201C advertising it still makes the point.",
  "id" : 694461970590908416,
  "in_reply_to_status_id" : 694461660531154944,
  "created_at" : "2016-02-02 10:06:50 +0000",
  "in_reply_to_screen_name" : "pjacock",
  "in_reply_to_user_id_str" : "58756672",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 71 ],
      "url" : "https:\/\/t.co\/6lriegypIA",
      "expanded_url" : "http:\/\/dogswithtonguestickingoutalittle.tumblr.com\/post\/138503799020\/inter-species-tongue-twinsies",
      "display_url" : "\u2026thtonguestickingoutalittle.tumblr.com\/post\/138503799\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "694457869471739904",
  "text" : "go-to cheer up: \u00ABinter-species tongue twinsies\u00BB https:\/\/t.co\/6lriegypIA",
  "id" : 694457869471739904,
  "created_at" : "2016-02-02 09:50:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "researchparasites",
      "indices" : [ 8, 26 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/VZa0injRkA",
      "expanded_url" : "https:\/\/twitter.com\/lexnederbragt\/status\/694413867527598080",
      "display_url" : "twitter.com\/lexnederbragt\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "694453712018890752",
  "text" : "\u00ABAs two #researchparasites, we have the utmost respect to all of the research groups who raised funds,\u2026\u00BB https:\/\/t.co\/VZa0injRkA",
  "id" : 694453712018890752,
  "created_at" : "2016-02-02 09:34:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "694440837405614080",
  "text" : "Has anyone here experience with using streamgraphs for visualizing their metagenomes?",
  "id" : 694440837405614080,
  "created_at" : "2016-02-02 08:42:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u2766",
      "screen_name" : "daniel_bohrer",
      "indices" : [ 0, 14 ],
      "id_str" : "237942141",
      "id" : 237942141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "694314509192843264",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17214955343814, 8.62785796063697 ]
  },
  "id_str" : "694433037766037504",
  "in_reply_to_user_id" : 237942141,
  "text" : "@daniel_bohrer I think so. :)",
  "id" : 694433037766037504,
  "in_reply_to_status_id" : 694314509192843264,
  "created_at" : "2016-02-02 08:11:52 +0000",
  "in_reply_to_screen_name" : "daniel_bohrer",
  "in_reply_to_user_id_str" : "237942141",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "694226245031215104",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11080591967754, 8.744913474500441 ]
  },
  "id_str" : "694226862113964032",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC at first i wondered whether it\u2019s just another name for anatomy.",
  "id" : 694226862113964032,
  "in_reply_to_status_id" : 694226245031215104,
  "created_at" : "2016-02-01 18:32:36 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11085208654578, 8.74487852614306 ]
  },
  "id_str" : "694226613035204610",
  "text" : "\u00ABAre they still tuning their instruments or did they already start their improvisation?\u00BB our local art scene.",
  "id" : 694226613035204610,
  "created_at" : "2016-02-01 18:31:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1108606918873, 8.744856689539093 ]
  },
  "id_str" : "694222871665729537",
  "text" : "Finally figured out for which study program I\u2019m enrolled in for nearly 3 years now: it\u2019s human geography. I\u2019ve no clue what that even means.",
  "id" : 694222871665729537,
  "created_at" : "2016-02-01 18:16:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/694209205755080704\/photo\/1",
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/shbEMo2nr2",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CaJTmCvWkAAKy0A.jpg",
      "id_str" : "694209205604093952",
      "id" : 694209205604093952,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CaJTmCvWkAAKy0A.jpg",
      "sizes" : [ {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1002,
        "resize" : "fit",
        "w" : 1336
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1002,
        "resize" : "fit",
        "w" : 1336
      } ],
      "display_url" : "pic.twitter.com\/shbEMo2nr2"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.110907, 8.744789 ]
  },
  "id_str" : "694209205755080704",
  "text" : "German for beginners: this sign advised you not to clean your intestine using pressurized air. https:\/\/t.co\/shbEMo2nr2",
  "id" : 694209205755080704,
  "created_at" : "2016-02-01 17:22:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Denker",
      "screen_name" : "Phaidr0s",
      "indices" : [ 0, 9 ],
      "id_str" : "40466433",
      "id" : 40466433
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "694170575321829376",
  "geo" : { },
  "id_str" : "694173602934059008",
  "in_reply_to_user_id" : 40466433,
  "text" : "@Phaidr0s wer weiss was danach passiert w\u00E4re!",
  "id" : 694173602934059008,
  "in_reply_to_status_id" : 694170575321829376,
  "created_at" : "2016-02-01 15:00:58 +0000",
  "in_reply_to_screen_name" : "Phaidr0s",
  "in_reply_to_user_id_str" : "40466433",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 94, 101 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/viAq47DWGZ",
      "expanded_url" : "https:\/\/twitter.com\/quominus\/status\/694165831064887296",
      "display_url" : "twitter.com\/quominus\/statu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "694173296305278976",
  "text" : "The only thing \u2018shit-disturbing\u2019 here what kind of person is presiding over the R foundation\u2026 #rstats https:\/\/t.co\/viAq47DWGZ",
  "id" : 694173296305278976,
  "created_at" : "2016-02-01 14:59:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Denker",
      "screen_name" : "Phaidr0s",
      "indices" : [ 0, 9 ],
      "id_str" : "40466433",
      "id" : 40466433
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "694170368009977857",
  "geo" : { },
  "id_str" : "694170445197791235",
  "in_reply_to_user_id" : 40466433,
  "text" : "@Phaidr0s \u00FCber rein akademische Dinge vermute ich? ;)",
  "id" : 694170445197791235,
  "in_reply_to_status_id" : 694170368009977857,
  "created_at" : "2016-02-01 14:48:25 +0000",
  "in_reply_to_screen_name" : "Phaidr0s",
  "in_reply_to_user_id_str" : "40466433",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elsa Panciroli",
      "screen_name" : "gsciencelady",
      "indices" : [ 3, 16 ],
      "id_str" : "34032998",
      "id" : 34032998
    }, {
      "name" : "Daurmith",
      "screen_name" : "Daurmith",
      "indices" : [ 120, 129 ],
      "id_str" : "10637592",
      "id" : 10637592
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "694160534183219200",
  "text" : "RT @gsciencelady: Brilliant bios of male scientists, written the way people too-often write about female scientists. By @Daurmith https:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Daurmith",
        "screen_name" : "Daurmith",
        "indices" : [ 102, 111 ],
        "id_str" : "10637592",
        "id" : 10637592
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/gsciencelady\/status\/694077235397939200\/photo\/1",
        "indices" : [ 112, 135 ],
        "url" : "https:\/\/t.co\/72hycxT4pE",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CaCfyGGWwAA-LkM.jpg",
        "id_str" : "693730025594601472",
        "id" : 693730025594601472,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CaCfyGGWwAA-LkM.jpg",
        "sizes" : [ {
          "h" : 664,
          "resize" : "fit",
          "w" : 442
        }, {
          "h" : 664,
          "resize" : "fit",
          "w" : 442
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 664,
          "resize" : "fit",
          "w" : 442
        }, {
          "h" : 664,
          "resize" : "fit",
          "w" : 442
        } ],
        "display_url" : "pic.twitter.com\/72hycxT4pE"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "694077235397939200",
    "text" : "Brilliant bios of male scientists, written the way people too-often write about female scientists. By @Daurmith https:\/\/t.co\/72hycxT4pE",
    "id" : 694077235397939200,
    "created_at" : "2016-02-01 08:38:02 +0000",
    "user" : {
      "name" : "Elsa Panciroli",
      "screen_name" : "gsciencelady",
      "protected" : false,
      "id_str" : "34032998",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/907297988959199233\/EU8uZsTj_normal.jpg",
      "id" : 34032998,
      "verified" : false
    }
  },
  "id" : 694160534183219200,
  "created_at" : "2016-02-01 14:09:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "694155703603314690",
  "text" : "Booked yet another set of flights to Berlin. \u2708\uFE0F",
  "id" : 694155703603314690,
  "created_at" : "2016-02-01 13:49:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Torsten Seemann",
      "screen_name" : "torstenseemann",
      "indices" : [ 0, 15 ],
      "id_str" : "42558652",
      "id" : 42558652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "694111699838726144",
  "geo" : { },
  "id_str" : "694111814515302400",
  "in_reply_to_user_id" : 42558652,
  "text" : "@torstenseemann nope, but I really want to fix that. ;)",
  "id" : 694111814515302400,
  "in_reply_to_status_id" : 694111699838726144,
  "created_at" : "2016-02-01 10:55:27 +0000",
  "in_reply_to_screen_name" : "torstenseemann",
  "in_reply_to_user_id_str" : "42558652",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 88 ],
      "url" : "https:\/\/t.co\/CVwQBQR8Np",
      "expanded_url" : "https:\/\/twitter.com\/fudgecrumpet\/status\/694096691486662656",
      "display_url" : "twitter.com\/fudgecrumpet\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "694108516039155712",
  "text" : "I know huge parts of Germany that should be plastered with them. https:\/\/t.co\/CVwQBQR8Np",
  "id" : 694108516039155712,
  "created_at" : "2016-02-01 10:42:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/694083744219664384\/photo\/1",
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/pGfADbCFGG",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CaHhfGBWQAAqWi_.jpg",
      "id_str" : "694083741900226560",
      "id" : 694083741900226560,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CaHhfGBWQAAqWi_.jpg",
      "sizes" : [ {
        "h" : 500,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 500,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 500,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 500,
        "resize" : "fit",
        "w" : 500
      } ],
      "display_url" : "pic.twitter.com\/pGfADbCFGG"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 72 ],
      "url" : "https:\/\/t.co\/3mFqhmD7fI",
      "expanded_url" : "http:\/\/deepart.io\/",
      "display_url" : "deepart.io"
    } ]
  },
  "geo" : { },
  "id_str" : "694083744219664384",
  "text" : "Played around with deepart, which is pretty fun. https:\/\/t.co\/3mFqhmD7fI https:\/\/t.co\/pGfADbCFGG",
  "id" : 694083744219664384,
  "created_at" : "2016-02-01 09:03:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 74 ],
      "url" : "https:\/\/t.co\/6IfCXERzda",
      "expanded_url" : "http:\/\/thebloodvoyage.tumblr.com\/post\/138410565161\/the-fuegians-hid-themselves-behind-the-scars-the",
      "display_url" : "thebloodvoyage.tumblr.com\/post\/138410565\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "694082694645465088",
  "text" : "A somewhat believable mix of Darwin &amp; McCarthy https:\/\/t.co\/6IfCXERzda",
  "id" : 694082694645465088,
  "created_at" : "2016-02-01 08:59:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "694081542042357760",
  "geo" : { },
  "id_str" : "694081701186764800",
  "in_reply_to_user_id" : 14286491,
  "text" : "From the comments there: \u00ABSomeone should write an article called 'The Heroes of Cladistics' and submit it to Cell.\u00BB",
  "id" : 694081701186764800,
  "in_reply_to_status_id" : 694081542042357760,
  "created_at" : "2016-02-01 08:55:47 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "parsimonygate",
      "indices" : [ 80, 94 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/GyZnw4DfnX",
      "expanded_url" : "https:\/\/m.facebook.com\/permalink.php?story_fbid=937224149693516&id=115402811804635",
      "display_url" : "m.facebook.com\/permalink.php?\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "694081542042357760",
  "text" : "\u00ABMany thanks to them for their courage (or overconfidence).\u00BB Joe Felsenstein on #parsimonygate https:\/\/t.co\/GyZnw4DfnX",
  "id" : 694081542042357760,
  "created_at" : "2016-02-01 08:55:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
} ]