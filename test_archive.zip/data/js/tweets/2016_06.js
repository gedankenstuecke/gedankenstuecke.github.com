Grailbird.data.tweets_2016_06 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "748556350234443776",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ -27.4622176637362, 153.040910359721 ]
  },
  "id_str" : "748629552201506817",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC had a kid sitting right behind me that managed to scream all the way from Frankfurt to Hong Kong \uD83D\uDE02",
  "id" : 748629552201506817,
  "in_reply_to_status_id" : 748556350234443776,
  "created_at" : "2016-06-30 21:29:28 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "smbe16",
      "indices" : [ 20, 27 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "748509879787102210",
  "text" : "Hello Brisbane, any #smbe16 people already around in town for the day tomorrow?",
  "id" : 748509879787102210,
  "created_at" : "2016-06-30 13:33:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chocho Zhang",
      "screen_name" : "chocho_z",
      "indices" : [ 0, 9 ],
      "id_str" : "3221119766",
      "id" : 3221119766
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "748500321198968832",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ -27.46217402330723, 153.0409872376073 ]
  },
  "id_str" : "748501635345707011",
  "in_reply_to_user_id" : 3221119766,
  "text" : "@chocho_z not really a time zone problem. It was off by exactly one day. ;)",
  "id" : 748501635345707011,
  "in_reply_to_status_id" : 748500321198968832,
  "created_at" : "2016-06-30 13:01:11 +0000",
  "in_reply_to_screen_name" : "chocho_z",
  "in_reply_to_user_id_str" : "3221119766",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "748407211907440640",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ -27.4026060011549, 153.111637155002 ]
  },
  "id_str" : "748481638246588416",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez sweet, thanks :)",
  "id" : 748481638246588416,
  "in_reply_to_status_id" : 748407211907440640,
  "created_at" : "2016-06-30 11:41:43 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 0, 8 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "748343492024410117",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ -27.40260785115077, 153.1115009509016 ]
  },
  "id_str" : "748481570374311937",
  "in_reply_to_user_id" : 3865005196,
  "text" : "@o_guest good to know that I\u2019m not alone with that.",
  "id" : 748481570374311937,
  "in_reply_to_status_id" : 748343492024410117,
  "created_at" : "2016-06-30 11:41:27 +0000",
  "in_reply_to_screen_name" : "o_guest",
  "in_reply_to_user_id_str" : "3865005196",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 0, 8 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "748339486522740736",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 22.31469372823279, 113.9238990708893 ]
  },
  "id_str" : "748341931566981120",
  "in_reply_to_user_id" : 3865005196,
  "text" : "@o_guest I still feel pretty displaced at times.",
  "id" : 748341931566981120,
  "in_reply_to_status_id" : 748339486522740736,
  "created_at" : "2016-06-30 02:26:34 +0000",
  "in_reply_to_screen_name" : "o_guest",
  "in_reply_to_user_id_str" : "3865005196",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "748326329221672960",
  "geo" : { },
  "id_str" : "748328835398045697",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer Beutelkamele, why not.",
  "id" : 748328835398045697,
  "in_reply_to_status_id" : 748326329221672960,
  "created_at" : "2016-06-30 01:34:32 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Edmunds",
      "screen_name" : "SCEdmunds",
      "indices" : [ 0, 10 ],
      "id_str" : "176024190",
      "id" : 176024190
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "748326473614823424",
  "geo" : { },
  "id_str" : "748326657585356800",
  "in_reply_to_user_id" : 176024190,
  "text" : "@SCEdmunds \uD83D\uDC4B (too bad that the layover time didn\u2019t allow to come over for a visit!)",
  "id" : 748326657585356800,
  "in_reply_to_status_id" : 748326473614823424,
  "created_at" : "2016-06-30 01:25:53 +0000",
  "in_reply_to_screen_name" : "SCEdmunds",
  "in_reply_to_user_id_str" : "176024190",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 22.31443145314447, 113.9244449325967 ]
  },
  "id_str" : "748318581234892800",
  "text" : "\u00ABPSA: Due to recent outbreaks of the avian flu: avoid touching birds, poultry and camels on your travels.\u00BB Not a taxonomist, but\u2026",
  "id" : 748318581234892800,
  "created_at" : "2016-06-30 00:53:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 0, 8 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "748307040121028608",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 22.31456498773981, 113.9242007676372 ]
  },
  "id_str" : "748318039628603392",
  "in_reply_to_user_id" : 3865005196,
  "text" : "@o_guest the queer\/bisexual numbers are also sobering :\/ (and totally get the reason for it)",
  "id" : 748318039628603392,
  "in_reply_to_status_id" : 748307040121028608,
  "created_at" : "2016-06-30 00:51:38 +0000",
  "in_reply_to_screen_name" : "o_guest",
  "in_reply_to_user_id_str" : "3865005196",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 3, 11 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/MkIJi0yXI1",
      "expanded_url" : "http:\/\/www.pride.com\/pride\/2016\/6\/28\/startling-one-third-lgbtq-women-dont-feel-welcomed-pride-events#.V3Ri1EFuDT0.twitter",
      "display_url" : "pride.com\/pride\/2016\/6\/2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "748317718286200832",
  "text" : "RT @o_guest: TRUTH: A Startling One Third of LGBTQ Women Don't Feel Welcomed at Pride Events https:\/\/t.co\/MkIJi0yXI1",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 80, 103 ],
        "url" : "https:\/\/t.co\/MkIJi0yXI1",
        "expanded_url" : "http:\/\/www.pride.com\/pride\/2016\/6\/28\/startling-one-third-lgbtq-women-dont-feel-welcomed-pride-events#.V3Ri1EFuDT0.twitter",
        "display_url" : "pride.com\/pride\/2016\/6\/2\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "748307040121028608",
    "text" : "TRUTH: A Startling One Third of LGBTQ Women Don't Feel Welcomed at Pride Events https:\/\/t.co\/MkIJi0yXI1",
    "id" : 748307040121028608,
    "created_at" : "2016-06-30 00:07:55 +0000",
    "user" : {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "protected" : false,
      "id_str" : "3865005196",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/844972791732584453\/mdSj6vOd_normal.jpg",
      "id" : 3865005196,
      "verified" : false
    }
  },
  "id" : 748317718286200832,
  "created_at" : "2016-06-30 00:50:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/748317455513051136\/photo\/1",
      "indices" : [ 24, 47 ],
      "url" : "https:\/\/t.co\/eiSuBgXRKK",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CmKOv20VEAEX2_2.jpg",
      "id_str" : "748317440916918273",
      "id" : 748317440916918273,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CmKOv20VEAEX2_2.jpg",
      "sizes" : [ {
        "h" : 454,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 454,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 454,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 301,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/eiSuBgXRKK"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 22.31459312354656, 113.9241526300061 ]
  },
  "id_str" : "748317455513051136",
  "text" : "Waiting for HKG \u2708\uFE0F BNE. https:\/\/t.co\/eiSuBgXRKK",
  "id" : 748317455513051136,
  "created_at" : "2016-06-30 00:49:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patti Jones",
      "screen_name" : "DrPattiJones",
      "indices" : [ 3, 16 ],
      "id_str" : "61382651",
      "id" : 61382651
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/l6fTKpXTv3",
      "expanded_url" : "https:\/\/www.buzzfeed.com\/azeenghorayshi\/michael-katze-investigation?utm_term=.nsLOk62yp",
      "display_url" : "buzzfeed.com\/azeenghorayshi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "748292922521444352",
  "text" : "RT @DrPattiJones: OH. \u201CHe Thinks He\u2019s Untouchable\u201D: Sexual Harassment Case Exposes Renowned Ebola Scientist https:\/\/t.co\/l6fTKpXTv3 via @az\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Azeen Ghorayshi",
        "screen_name" : "azeen",
        "indices" : [ 118, 124 ],
        "id_str" : "256722290",
        "id" : 256722290
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 90, 113 ],
        "url" : "https:\/\/t.co\/l6fTKpXTv3",
        "expanded_url" : "https:\/\/www.buzzfeed.com\/azeenghorayshi\/michael-katze-investigation?utm_term=.nsLOk62yp",
        "display_url" : "buzzfeed.com\/azeenghorayshi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "748291558949142528",
    "text" : "OH. \u201CHe Thinks He\u2019s Untouchable\u201D: Sexual Harassment Case Exposes Renowned Ebola Scientist https:\/\/t.co\/l6fTKpXTv3 via @azeen",
    "id" : 748291558949142528,
    "created_at" : "2016-06-29 23:06:24 +0000",
    "user" : {
      "name" : "Patti Jones",
      "screen_name" : "DrPattiJones",
      "protected" : false,
      "id_str" : "61382651",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/695644184531742720\/QnAf1ViT_normal.jpg",
      "id" : 61382651,
      "verified" : false
    }
  },
  "id" : 748292922521444352,
  "created_at" : "2016-06-29 23:11:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 22.31617649318418, 113.9336552119103 ]
  },
  "id_str" : "748284112960520192",
  "text" : "Approaching HKG always looks so nice. \uD83D\uDC96",
  "id" : 748284112960520192,
  "created_at" : "2016-06-29 22:36:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/748124372448251904\/photo\/1",
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/xl6kIWHWNc",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CmHfJQMWIAA9me_.jpg",
      "id_str" : "748124363178778624",
      "id" : 748124363178778624,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CmHfJQMWIAA9me_.jpg",
      "sizes" : [ {
        "h" : 384,
        "resize" : "fit",
        "w" : 512
      }, {
        "h" : 384,
        "resize" : "fit",
        "w" : 512
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 384,
        "resize" : "fit",
        "w" : 512
      }, {
        "h" : 384,
        "resize" : "fit",
        "w" : 512
      } ],
      "display_url" : "pic.twitter.com\/xl6kIWHWNc"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.05039404616031, 8.595273527370987 ]
  },
  "id_str" : "748124372448251904",
  "text" : "Oh, I didn\u2019t know they adjust the in-flight entertainment according to the news. https:\/\/t.co\/xl6kIWHWNc",
  "id" : 748124372448251904,
  "created_at" : "2016-06-29 12:02:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anneli Friberg",
      "screen_name" : "fribban",
      "indices" : [ 3, 11 ],
      "id_str" : "18388956",
      "id" : 18388956
    }, {
      "name" : "Martin Malmsten",
      "screen_name" : "geckomarma",
      "indices" : [ 33, 44 ],
      "id_str" : "15700443",
      "id" : 15700443
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/fribban\/status\/748076273667289088\/photo\/1",
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/bssJ8TxX54",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CmGzY3OWMAAeQpI.jpg",
      "id_str" : "748076252842569728",
      "id" : 748076252842569728,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CmGzY3OWMAAeQpI.jpg",
      "sizes" : [ {
        "h" : 1590,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 528,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1590,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 932,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/bssJ8TxX54"
    } ],
    "hashtags" : [ {
      "text" : "Liber2016",
      "indices" : [ 101, 111 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "748117645241761792",
  "text" : "RT @fribban: It is possible that @geckomarma has presented the best slide at the conference, so far! #Liber2016 https:\/\/t.co\/bssJ8TxX54",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Martin Malmsten",
        "screen_name" : "geckomarma",
        "indices" : [ 20, 31 ],
        "id_str" : "15700443",
        "id" : 15700443
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/fribban\/status\/748076273667289088\/photo\/1",
        "indices" : [ 99, 122 ],
        "url" : "https:\/\/t.co\/bssJ8TxX54",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CmGzY3OWMAAeQpI.jpg",
        "id_str" : "748076252842569728",
        "id" : 748076252842569728,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CmGzY3OWMAAeQpI.jpg",
        "sizes" : [ {
          "h" : 1590,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 528,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1590,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 932,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/bssJ8TxX54"
      } ],
      "hashtags" : [ {
        "text" : "Liber2016",
        "indices" : [ 88, 98 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "748076273667289088",
    "text" : "It is possible that @geckomarma has presented the best slide at the conference, so far! #Liber2016 https:\/\/t.co\/bssJ8TxX54",
    "id" : 748076273667289088,
    "created_at" : "2016-06-29 08:50:56 +0000",
    "user" : {
      "name" : "Anneli Friberg",
      "screen_name" : "fribban",
      "protected" : false,
      "id_str" : "18388956",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/903662172902973440\/Tj1pcUa0_normal.jpg",
      "id" : 18388956,
      "verified" : false
    }
  },
  "id" : 748117645241761792,
  "created_at" : "2016-06-29 11:35:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.04916806352775, 8.589634414437496 ]
  },
  "id_str" : "748115917725380608",
  "text" : "Now: FRA \u2708\uFE0F HKG on CX288.",
  "id" : 748115917725380608,
  "created_at" : "2016-06-29 11:28:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrick Rauscher",
      "screen_name" : "prauscher",
      "indices" : [ 0, 10 ],
      "id_str" : "74155696",
      "id" : 74155696
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/748105326952611842\/photo\/1",
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/yZOlYx5cPW",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CmHN0qfWgAAdBWE.jpg",
      "id_str" : "748105317762891776",
      "id" : 748105317762891776,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CmHN0qfWgAAdBWE.jpg",
      "sizes" : [ {
        "h" : 384,
        "resize" : "fit",
        "w" : 512
      }, {
        "h" : 384,
        "resize" : "fit",
        "w" : 512
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 384,
        "resize" : "fit",
        "w" : 512
      }, {
        "h" : 384,
        "resize" : "fit",
        "w" : 512
      } ],
      "display_url" : "pic.twitter.com\/yZOlYx5cPW"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "748103440442732545",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.05189514160154, 8.587905883789059 ]
  },
  "id_str" : "748105326952611842",
  "in_reply_to_user_id" : 74155696,
  "text" : "@prauscher erinnert mich das ich dir noch was senden wollte! Falls das zu deiner Altersgruppe passt :p https:\/\/t.co\/yZOlYx5cPW",
  "id" : 748105326952611842,
  "in_reply_to_status_id" : 748103440442732545,
  "created_at" : "2016-06-29 10:46:23 +0000",
  "in_reply_to_screen_name" : "prauscher",
  "in_reply_to_user_id_str" : "74155696",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.05189514160165, 8.587905883789059 ]
  },
  "id_str" : "748104723320930304",
  "text" : "\u00ABThe Pen Type-A. Amusing airport security all around the world.\u00BB should be their slogan.",
  "id" : 748104723320930304,
  "created_at" : "2016-06-29 10:43:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Beth \uD83D\uDC3A",
      "screen_name" : "PhdGeek",
      "indices" : [ 0, 8 ],
      "id_str" : "27841081",
      "id" : 27841081
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "748093712211775489",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.05412292480467, 8.587905883789059 ]
  },
  "id_str" : "748093840280666112",
  "in_reply_to_user_id" : 27841081,
  "text" : "@PhdGeek yes, do it! Would be great to (hopefully) meet there!",
  "id" : 748093840280666112,
  "in_reply_to_status_id" : 748093712211775489,
  "created_at" : "2016-06-29 10:00:45 +0000",
  "in_reply_to_screen_name" : "PhdGeek",
  "in_reply_to_user_id_str" : "27841081",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chocho Zhang",
      "screen_name" : "chocho_z",
      "indices" : [ 0, 9 ],
      "id_str" : "3221119766",
      "id" : 3221119766
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "748087432898240512",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.05412292480467, 8.587905883789059 ]
  },
  "id_str" : "748092561642950656",
  "in_reply_to_user_id" : 3221119766,
  "text" : "@chocho_z \uD83C\uDF89\uD83C\uDF89",
  "id" : 748092561642950656,
  "in_reply_to_status_id" : 748087432898240512,
  "created_at" : "2016-06-29 09:55:40 +0000",
  "in_reply_to_screen_name" : "chocho_z",
  "in_reply_to_user_id_str" : "3221119766",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "C\u24D0meronNeylon",
      "screen_name" : "CameronNeylon",
      "indices" : [ 0, 14 ],
      "id_str" : "12984852",
      "id" : 12984852
    }, {
      "name" : "amber thomas",
      "screen_name" : "ambrouk",
      "indices" : [ 15, 23 ],
      "id_str" : "14700993",
      "id" : 14700993
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "748063093339598849",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.05412292480466, 8.587905883789055 ]
  },
  "id_str" : "748090217182150657",
  "in_reply_to_user_id" : 12984852,
  "text" : "@CameronNeylon @ambrouk should be fine, had those on my bags for years without them giving me trouble. (My looks on the other hand\u2026)",
  "id" : 748090217182150657,
  "in_reply_to_status_id" : 748063093339598849,
  "created_at" : "2016-06-29 09:46:21 +0000",
  "in_reply_to_screen_name" : "CameronNeylon",
  "in_reply_to_user_id_str" : "12984852",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 0, 10 ],
      "id_str" : "14700783",
      "id" : 14700783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "748060059142336512",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.05412292479954, 8.587905883786163 ]
  },
  "id_str" : "748089775790428160",
  "in_reply_to_user_id" : 14700783,
  "text" : "@Fischblog passend dazu sitze ich gerade am Flughafen und warte aufs Boarding gen Brisbane. \uD83D\uDE0A",
  "id" : 748089775790428160,
  "in_reply_to_status_id" : 748060059142336512,
  "created_at" : "2016-06-29 09:44:36 +0000",
  "in_reply_to_screen_name" : "Fischblog",
  "in_reply_to_user_id_str" : "14700783",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.05412292480467, 8.587905883789057 ]
  },
  "id_str" : "748083988758151168",
  "text" : "This must be the first time that a guy gave me his phone number because I was wearing Vibrams. \uD83D\uDE02",
  "id" : 748083988758151168,
  "created_at" : "2016-06-29 09:21:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mack eubanks",
      "screen_name" : "quominus",
      "indices" : [ 0, 9 ],
      "id_str" : "817667268096262146",
      "id" : 817667268096262146
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "747931520900472832",
  "text" : "@quominus let me know if you found those. Will be happy to write an article about the experience afterwards as well.",
  "id" : 747931520900472832,
  "created_at" : "2016-06-28 23:15:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Iara VPS",
      "screen_name" : "iaravps",
      "indices" : [ 0, 8 ],
      "id_str" : "173881525",
      "id" : 173881525
    }, {
      "name" : "Arjun Raj",
      "screen_name" : "arjunrajlab",
      "indices" : [ 9, 21 ],
      "id_str" : "1492807728",
      "id" : 1492807728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "747929673385021440",
  "geo" : { },
  "id_str" : "747930354770640896",
  "in_reply_to_user_id" : 173881525,
  "text" : "@iaravps @arjunrajlab yes, i think that\u2019s my stance quite often: preemptively criticising your own work can be very disarming!",
  "id" : 747930354770640896,
  "in_reply_to_status_id" : 747929673385021440,
  "created_at" : "2016-06-28 23:11:07 +0000",
  "in_reply_to_screen_name" : "iaravps",
  "in_reply_to_user_id_str" : "173881525",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/hwLLDk6dTe",
      "expanded_url" : "https:\/\/twitter.com\/arjunrajlab\/status\/747800038957539328",
      "display_url" : "twitter.com\/arjunrajlab\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "747927418350993410",
  "text" : "on being honest: \u00ABit makes people think you\u2019re smart if you show you\u2019ve already thought about all various problems.\u00BB https:\/\/t.co\/hwLLDk6dTe",
  "id" : 747927418350993410,
  "created_at" : "2016-06-28 22:59:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3164",
      "screen_name" : "neingeist",
      "indices" : [ 0, 10 ],
      "id_str" : "11193712",
      "id" : 11193712
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "747867783703199744",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11403021830168, 8.753362830357927 ]
  },
  "id_str" : "747868123479613446",
  "in_reply_to_user_id" : 11193712,
  "text" : "@neingeist I noticed my calendar-snafu (that would have gotten me there a day late) some hours before the actual flight and made it.",
  "id" : 747868123479613446,
  "in_reply_to_status_id" : 747867783703199744,
  "created_at" : "2016-06-28 19:03:50 +0000",
  "in_reply_to_screen_name" : "neingeist",
  "in_reply_to_user_id_str" : "11193712",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11390924269888, 8.753563939133082 ]
  },
  "id_str" : "747867414713466880",
  "text" : "Since my near-miss of a \u2708\uFE0F to BOSC last year: Two days prior to flights I get nightmares of showing up at the airport a day too late.",
  "id" : 747867414713466880,
  "created_at" : "2016-06-28 19:01:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Egle Ramanauskaite \u2623",
      "screen_name" : "Seplute",
      "indices" : [ 0, 8 ],
      "id_str" : "188833865",
      "id" : 188833865
    }, {
      "name" : "figshare",
      "screen_name" : "figshare",
      "indices" : [ 44, 53 ],
      "id_str" : "224631899",
      "id" : 224631899
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "747751063734915072",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17233075548803, 8.627593553548804 ]
  },
  "id_str" : "747780056429244417",
  "in_reply_to_user_id" : 188833865,
  "text" : "@Seplute easiest could be to upload them to @figshare. Free for small enough data and gets you a DOI.",
  "id" : 747780056429244417,
  "in_reply_to_status_id" : 747751063734915072,
  "created_at" : "2016-06-28 13:13:53 +0000",
  "in_reply_to_screen_name" : "Seplute",
  "in_reply_to_user_id_str" : "188833865",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35926631008053, 8.587862532710963 ]
  },
  "id_str" : "747539641503522816",
  "text" : "\u00ABAll went well, he even liked cooking for me. Unfortunately he wasn\u2019t very good at it and so I got food poising\u2026\u00BB",
  "id" : 747539641503522816,
  "created_at" : "2016-06-27 21:18:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 45 ],
      "url" : "https:\/\/t.co\/L39mojKdOW",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BHKskWojuD3\/",
      "display_url" : "instagram.com\/p\/BHKskWojuD3\/"
    } ]
  },
  "geo" : { },
  "id_str" : "747489135657631744",
  "text" : "Ants farming aphids \uD83D\uDC96 https:\/\/t.co\/L39mojKdOW",
  "id" : 747489135657631744,
  "created_at" : "2016-06-27 17:57:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/747487518539522048\/photo\/1",
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/UOmWPuKX5J",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cl-b714WQAAooxy.jpg",
      "id_str" : "747487515544797184",
      "id" : 747487515544797184,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cl-b714WQAAooxy.jpg",
      "sizes" : [ {
        "h" : 851,
        "resize" : "fit",
        "w" : 1134
      }, {
        "h" : 851,
        "resize" : "fit",
        "w" : 1134
      }, {
        "h" : 851,
        "resize" : "fit",
        "w" : 1134
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/UOmWPuKX5J"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.359185, 8.587775 ]
  },
  "id_str" : "747487518539522048",
  "text" : "\u00ABFences for Europe\u00BB not sure whether that's the best or worst slogan these days\u2026 https:\/\/t.co\/UOmWPuKX5J",
  "id" : 747487518539522048,
  "created_at" : "2016-06-27 17:51:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Gelman",
      "screen_name" : "StatModeling",
      "indices" : [ 3, 16 ],
      "id_str" : "214653213",
      "id" : 214653213
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/dxrZl6msL3",
      "expanded_url" : "http:\/\/andrewgelman.com\/2016\/06\/26\/29449\/",
      "display_url" : "andrewgelman.com\/2016\/06\/26\/294\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "747474773161181184",
  "text" : "RT @StatModeling: New post: When are people gonna realize their studies are dead on arrival? https:\/\/t.co\/dxrZl6msL3",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/andrewgelman.com\" rel=\"nofollow\"\u003Eandrewgelman.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 75, 98 ],
        "url" : "https:\/\/t.co\/dxrZl6msL3",
        "expanded_url" : "http:\/\/andrewgelman.com\/2016\/06\/26\/29449\/",
        "display_url" : "andrewgelman.com\/2016\/06\/26\/294\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "747054337323499520",
    "text" : "New post: When are people gonna realize their studies are dead on arrival? https:\/\/t.co\/dxrZl6msL3",
    "id" : 747054337323499520,
    "created_at" : "2016-06-26 13:10:08 +0000",
    "user" : {
      "name" : "Andrew Gelman",
      "screen_name" : "StatModeling",
      "protected" : false,
      "id_str" : "214653213",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/840582074998370309\/KOTyjS2w_normal.jpg",
      "id" : 214653213,
      "verified" : false
    }
  },
  "id" : 747474773161181184,
  "created_at" : "2016-06-27 17:00:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrea Komljenovi\u0107",
      "screen_name" : "antifreezeprot",
      "indices" : [ 0, 15 ],
      "id_str" : "851420822",
      "id" : 851420822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/yduN6RxyVR",
      "expanded_url" : "http:\/\/www.personalizedhealth2016.org\/",
      "display_url" : "personalizedhealth2016.org"
    } ]
  },
  "in_reply_to_status_id_str" : "747405043452755968",
  "geo" : { },
  "id_str" : "747405677266612225",
  "in_reply_to_user_id" : 851420822,
  "text" : "@antifreezeprot \u2026at some point. Plus I\u2019ll be in Geneva in September for https:\/\/t.co\/yduN6RxyVR",
  "id" : 747405677266612225,
  "in_reply_to_status_id" : 747405043452755968,
  "created_at" : "2016-06-27 12:26:14 +0000",
  "in_reply_to_screen_name" : "antifreezeprot",
  "in_reply_to_user_id_str" : "851420822",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrea Komljenovi\u0107",
      "screen_name" : "antifreezeprot",
      "indices" : [ 0, 15 ],
      "id_str" : "851420822",
      "id" : 851420822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "747405043452755968",
  "geo" : { },
  "id_str" : "747405590385803264",
  "in_reply_to_user_id" : 851420822,
  "text" : "@antifreezeprot ah, enjoy! Unfortunately not this time, just in ZRH for an extended weekend. But I\u2019m here \u00B1 regularly, so could come over\u2026",
  "id" : 747405590385803264,
  "in_reply_to_status_id" : 747405043452755968,
  "created_at" : "2016-06-27 12:25:53 +0000",
  "in_reply_to_screen_name" : "antifreezeprot",
  "in_reply_to_user_id_str" : "851420822",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrea Komljenovi\u0107",
      "screen_name" : "antifreezeprot",
      "indices" : [ 0, 15 ],
      "id_str" : "851420822",
      "id" : 851420822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "747403111610847233",
  "geo" : { },
  "id_str" : "747404405591392256",
  "in_reply_to_user_id" : 851420822,
  "text" : "@antifreezeprot congrats! Where are you heading to? :)",
  "id" : 747404405591392256,
  "in_reply_to_status_id" : 747403111610847233,
  "created_at" : "2016-06-27 12:21:11 +0000",
  "in_reply_to_screen_name" : "antifreezeprot",
  "in_reply_to_user_id_str" : "851420822",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "747392750564302849",
  "text" : "TIL: Even what you assume is just fruit juice may contain fish oil as an additive m(",
  "id" : 747392750564302849,
  "created_at" : "2016-06-27 11:34:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "latergram",
      "indices" : [ 20, 30 ]
    } ],
    "urls" : [ {
      "indices" : [ 31, 54 ],
      "url" : "https:\/\/t.co\/AvvuIcVzSo",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BHJ55SRjrSc\/",
      "display_url" : "instagram.com\/p\/BHJ55SRjrSc\/"
    } ]
  },
  "geo" : { },
  "id_str" : "747377704505348096",
  "text" : "A cross with a view #latergram https:\/\/t.co\/AvvuIcVzSo",
  "id" : 747377704505348096,
  "created_at" : "2016-06-27 10:35:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Hahnel",
      "screen_name" : "MarkHahnel",
      "indices" : [ 0, 11 ],
      "id_str" : "160877807",
      "id" : 160877807
    }, {
      "name" : "Joseph McArthur",
      "screen_name" : "Mcarthur_Joe",
      "indices" : [ 12, 25 ],
      "id_str" : "478181304",
      "id" : 478181304
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "747336200399183872",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.3758392061361, 8.545263821562843 ]
  },
  "id_str" : "747348194187685888",
  "in_reply_to_user_id" : 160877807,
  "text" : "@MarkHahnel @Mcarthur_Joe I\u2019ll be in the weekend before. So that could work.",
  "id" : 747348194187685888,
  "in_reply_to_status_id" : 747336200399183872,
  "created_at" : "2016-06-27 08:37:49 +0000",
  "in_reply_to_screen_name" : "MarkHahnel",
  "in_reply_to_user_id_str" : "160877807",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Iara VPS",
      "screen_name" : "iaravps",
      "indices" : [ 0, 8 ],
      "id_str" : "173881525",
      "id" : 173881525
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "747123678442360833",
  "geo" : { },
  "id_str" : "747151655800606720",
  "in_reply_to_user_id" : 173881525,
  "text" : "@iaravps directed microwave transmissions if i\u2019m not mistaken :)",
  "id" : 747151655800606720,
  "in_reply_to_status_id" : 747123678442360833,
  "created_at" : "2016-06-26 19:36:50 +0000",
  "in_reply_to_screen_name" : "iaravps",
  "in_reply_to_user_id_str" : "173881525",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 76 ],
      "url" : "https:\/\/t.co\/LqoS0e53ch",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BHIDWCxj0Zg\/",
      "display_url" : "instagram.com\/p\/BHIDWCxj0Zg\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.0553257504, 8.48424436182 ]
  },
  "id_str" : "747117009306017793",
  "text" : "1,798 m above sea @ Mt Rigi, Swiss Alps, Switzerland https:\/\/t.co\/LqoS0e53ch",
  "id" : 747117009306017793,
  "created_at" : "2016-06-26 17:19:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "746808793137319936",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35932719135157, 8.587975569745806 ]
  },
  "id_str" : "746830546748248064",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC well, maybe tomorrow it\u2019s better  \u00AF\\_(\u30C4)_\/\u00AF",
  "id" : 746830546748248064,
  "in_reply_to_status_id" : 746808793137319936,
  "created_at" : "2016-06-25 22:20:52 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "746770997638987776",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35923335203835, 8.587670247147804 ]
  },
  "id_str" : "746790196486803456",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC indeed. My hiking plans for the day were washed away by the \uD83C\uDF0A\uD83C\uDF29",
  "id" : 746790196486803456,
  "in_reply_to_status_id" : 746770997638987776,
  "created_at" : "2016-06-25 19:40:32 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bi\u24D0nca Kramer",
      "screen_name" : "MsPhelps",
      "indices" : [ 0, 9 ],
      "id_str" : "22963112",
      "id" : 22963112
    }, {
      "name" : "\u24EA Rik Smith-Unna \uD83C\uDDF0\uD83C\uDDEA",
      "screen_name" : "blahah404",
      "indices" : [ 10, 20 ],
      "id_str" : "99173786",
      "id" : 99173786
    }, {
      "name" : "Mike T\u24D0ylor",
      "screen_name" : "MikeTaylor",
      "indices" : [ 21, 32 ],
      "id_str" : "278930750",
      "id" : 278930750
    }, {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 33, 47 ],
      "id_str" : "352650591",
      "id" : 352650591
    }, {
      "name" : "Eric Hellman",
      "screen_name" : "gluejar",
      "indices" : [ 48, 56 ],
      "id_str" : "31914221",
      "id" : 31914221
    }, {
      "name" : "Sujai Kumar",
      "screen_name" : "sujaik",
      "indices" : [ 57, 64 ],
      "id_str" : "33651124",
      "id" : 33651124
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/746665495022141440\/photo\/1",
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/usSAxpWZ1G",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ClywTqLWAAAfpO4.jpg",
      "id_str" : "746665490022531072",
      "id" : 746665490022531072,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ClywTqLWAAAfpO4.jpg",
      "sizes" : [ {
        "h" : 474,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 523,
        "resize" : "fit",
        "w" : 750
      }, {
        "h" : 523,
        "resize" : "fit",
        "w" : 750
      }, {
        "h" : 523,
        "resize" : "fit",
        "w" : 750
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/usSAxpWZ1G"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "746607601522192384",
  "geo" : { },
  "id_str" : "746665495022141440",
  "in_reply_to_user_id" : 22963112,
  "text" : "@MsPhelps @blahah404 @MikeTaylor @Protohedgehog @gluejar @sujaik may I suggest a different font? https:\/\/t.co\/usSAxpWZ1G",
  "id" : 746665495022141440,
  "in_reply_to_status_id" : 746607601522192384,
  "created_at" : "2016-06-25 11:25:01 +0000",
  "in_reply_to_screen_name" : "MsPhelps",
  "in_reply_to_user_id_str" : "22963112",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "746384874974642176",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35896096103578, 8.587905205794225 ]
  },
  "id_str" : "746429309196210176",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC i got all of 3 hours of sun today before the thunderstorm swept it all away. Fits the \uD83D\uDE2D mood.",
  "id" : 746429309196210176,
  "in_reply_to_status_id" : 746384874974642176,
  "created_at" : "2016-06-24 19:46:29 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35927275324584, 8.58787993591334 ]
  },
  "id_str" : "746359817464332288",
  "text" : "\u00ABTwo people from different EU countries, cuddling up in an non-EU country, to comfort each other about the UK leaving. Weird, isn\u2019t it?\u00BB",
  "id" : 746359817464332288,
  "created_at" : "2016-06-24 15:10:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joseph McArthur",
      "screen_name" : "Mcarthur_Joe",
      "indices" : [ 0, 13 ],
      "id_str" : "478181304",
      "id" : 478181304
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "746276479160418307",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.48144896332964, 8.803236549728366 ]
  },
  "id_str" : "746277463978827776",
  "in_reply_to_user_id" : 478181304,
  "text" : "@Mcarthur_Joe tour!",
  "id" : 746277463978827776,
  "in_reply_to_status_id" : 746276479160418307,
  "created_at" : "2016-06-24 09:43:07 +0000",
  "in_reply_to_screen_name" : "Mcarthur_Joe",
  "in_reply_to_user_id_str" : "478181304",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joseph McArthur",
      "screen_name" : "Mcarthur_Joe",
      "indices" : [ 0, 13 ],
      "id_str" : "478181304",
      "id" : 478181304
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "746276479160418307",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.48766598855004, 8.822690863170495 ]
  },
  "id_str" : "746277355287646208",
  "in_reply_to_user_id" : 478181304,
  "text" : "@Mcarthur_Joe (calling it the goodbye-UK-your)",
  "id" : 746277355287646208,
  "in_reply_to_status_id" : 746276479160418307,
  "created_at" : "2016-06-24 09:42:41 +0000",
  "in_reply_to_screen_name" : "Mcarthur_Joe",
  "in_reply_to_user_id_str" : "478181304",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joseph McArthur",
      "screen_name" : "Mcarthur_Joe",
      "indices" : [ 0, 13 ],
      "id_str" : "478181304",
      "id" : 478181304
    }, {
      "name" : "Mark Hahnel",
      "screen_name" : "MarkHahnel",
      "indices" : [ 69, 80 ],
      "id_str" : "160877807",
      "id" : 160877807
    }, {
      "name" : "Team Mendeley",
      "screen_name" : "mendeley_com",
      "indices" : [ 85, 98 ],
      "id_str" : "15803034",
      "id" : 15803034
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "746276479160418307",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.49868056368874, 8.837477881469612 ]
  },
  "id_str" : "746277225440350208",
  "in_reply_to_user_id" : 478181304,
  "text" : "@Mcarthur_Joe great, keep the date in mind. Also have to see whether @MarkHahnel and @mendeley_com have time for a drink ;)",
  "id" : 746277225440350208,
  "in_reply_to_status_id" : 746276479160418307,
  "created_at" : "2016-06-24 09:42:10 +0000",
  "in_reply_to_screen_name" : "Mcarthur_Joe",
  "in_reply_to_user_id_str" : "478181304",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nyborg",
      "screen_name" : "ny_borg",
      "indices" : [ 0, 8 ],
      "id_str" : "570156398",
      "id" : 570156398
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "746271629337071616",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.50362622183608, 8.84326826781858 ]
  },
  "id_str" : "746277019898478592",
  "in_reply_to_user_id" : 570156398,
  "text" : "@ny_borg what could possibly go wrong?",
  "id" : 746277019898478592,
  "in_reply_to_status_id" : 746271629337071616,
  "created_at" : "2016-06-24 09:41:21 +0000",
  "in_reply_to_screen_name" : "ny_borg",
  "in_reply_to_user_id_str" : "570156398",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joseph McArthur",
      "screen_name" : "Mcarthur_Joe",
      "indices" : [ 0, 13 ],
      "id_str" : "478181304",
      "id" : 478181304
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "746275335252082688",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.58710687612052, 8.89793504030341 ]
  },
  "id_str" : "746275807501361152",
  "in_reply_to_user_id" : 478181304,
  "text" : "@Mcarthur_Joe yeah, in town 18th-22nd. Also still looking for a place to get some work done during the time. :)",
  "id" : 746275807501361152,
  "in_reply_to_status_id" : 746275335252082688,
  "created_at" : "2016-06-24 09:36:32 +0000",
  "in_reply_to_screen_name" : "Mcarthur_Joe",
  "in_reply_to_user_id_str" : "478181304",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joseph McArthur",
      "screen_name" : "Mcarthur_Joe",
      "indices" : [ 0, 13 ],
      "id_str" : "478181304",
      "id" : 478181304
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "746268702555934720",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.6240566941431, 8.912208080300047 ]
  },
  "id_str" : "746275048302977024",
  "in_reply_to_user_id" : 478181304,
  "text" : "@Mcarthur_Joe by the way: I\u2019ll be in London mid-July. Are you around then? :)",
  "id" : 746275048302977024,
  "in_reply_to_status_id" : 746268702555934720,
  "created_at" : "2016-06-24 09:33:31 +0000",
  "in_reply_to_screen_name" : "Mcarthur_Joe",
  "in_reply_to_user_id_str" : "478181304",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 41 ],
      "url" : "https:\/\/t.co\/lGLoCHBGXU",
      "expanded_url" : "http:\/\/thememorypalace.us\/2016\/06\/a-white-horse\/",
      "display_url" : "thememorypalace.us\/2016\/06\/a-whit\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "746274508265426944",
  "text" : "A White Horse \uD83E\uDD84\uD83C\uDF79\uD83D\uDE22 https:\/\/t.co\/lGLoCHBGXU",
  "id" : 746274508265426944,
  "created_at" : "2016-06-24 09:31:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Heather L. Wiencko",
      "screen_name" : "HLWiencko",
      "indices" : [ 0, 10 ],
      "id_str" : "2657942712",
      "id" : 2657942712
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "746251252066033664",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 49.68625165526726, 8.552401140340187 ]
  },
  "id_str" : "746252110585565184",
  "in_reply_to_user_id" : 2657942712,
  "text" : "@HLWiencko \uD83C\uDF78(seems there is no Whiskey emoji proper)",
  "id" : 746252110585565184,
  "in_reply_to_status_id" : 746251252066033664,
  "created_at" : "2016-06-24 08:02:22 +0000",
  "in_reply_to_screen_name" : "HLWiencko",
  "in_reply_to_user_id_str" : "2657942712",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Heather L. Wiencko",
      "screen_name" : "HLWiencko",
      "indices" : [ 0, 10 ],
      "id_str" : "2657942712",
      "id" : 2657942712
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "746250769918234624",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 49.7414634190963, 8.543208455674856 ]
  },
  "id_str" : "746251131857281024",
  "in_reply_to_user_id" : 2657942712,
  "text" : "@HLWiencko still have a collection of USD bills, so I can invite :p",
  "id" : 746251131857281024,
  "in_reply_to_status_id" : 746250769918234624,
  "created_at" : "2016-06-24 07:58:29 +0000",
  "in_reply_to_screen_name" : "HLWiencko",
  "in_reply_to_user_id_str" : "2657942712",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Heather L. Wiencko",
      "screen_name" : "HLWiencko",
      "indices" : [ 0, 10 ],
      "id_str" : "2657942712",
      "id" : 2657942712
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "746250332095844352",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 49.77645430252866, 8.55126480572722 ]
  },
  "id_str" : "746250609427365888",
  "in_reply_to_user_id" : 2657942712,
  "text" : "@HLWiencko all the hugs if wanted. And I guess we\u2019ll need something stronger than coffee at BOSC. :(",
  "id" : 746250609427365888,
  "in_reply_to_status_id" : 746250332095844352,
  "created_at" : "2016-06-24 07:56:24 +0000",
  "in_reply_to_screen_name" : "HLWiencko",
  "in_reply_to_user_id_str" : "2657942712",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 49.81941763316264, 8.582863574855573 ]
  },
  "id_str" : "746250104085032960",
  "text" : "Waking up to the news this morning literally made me want to curl up and cry.",
  "id" : 746250104085032960,
  "created_at" : "2016-06-24 07:54:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/746085147552931840\/photo\/1",
      "indices" : [ 61, 84 ],
      "url" : "https:\/\/t.co\/DNLUGiARJH",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Clqge6wWgAAdwkT.jpg",
      "id_str" : "746085141311815680",
      "id" : 746085141311815680,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Clqge6wWgAAdwkT.jpg",
      "sizes" : [ {
        "h" : 3024,
        "resize" : "fit",
        "w" : 4032
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/DNLUGiARJH"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06092146974994, 8.818461438649164 ]
  },
  "id_str" : "746085147552931840",
  "text" : "I know some patrons who will get mail in the next few weeks. https:\/\/t.co\/DNLUGiARJH",
  "id" : 746085147552931840,
  "created_at" : "2016-06-23 20:58:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 51 ],
      "url" : "https:\/\/t.co\/Gxkw6nBwJv",
      "expanded_url" : "https:\/\/twitter.com\/auremoser\/status\/745630658169606144",
      "display_url" : "twitter.com\/auremoser\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "745985760323571712",
  "text" : "Wow, I\u2019m amazed by this \uD83E\uDD16 \uD83D\uDC96 https:\/\/t.co\/Gxkw6nBwJv",
  "id" : 745985760323571712,
  "created_at" : "2016-06-23 14:23:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 6, 29 ],
      "url" : "https:\/\/t.co\/FDKgJczVSS",
      "expanded_url" : "https:\/\/incubator.duolingo.com\/courses\/he\/en\/status",
      "display_url" : "incubator.duolingo.com\/courses\/he\/en\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17245967599082, 8.627359318889678 ]
  },
  "id_str" : "745930682996826112",
  "text" : "\u05D9\u05D5\u05E4\u05D9! https:\/\/t.co\/FDKgJczVSS",
  "id" : 745930682996826112,
  "created_at" : "2016-06-23 10:45:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael R. Crusoe",
      "screen_name" : "biocrusoe",
      "indices" : [ 3, 13 ],
      "id_str" : "17645638",
      "id" : 17645638
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ISMB16",
      "indices" : [ 15, 22 ]
    }, {
      "text" : "PulseShooting",
      "indices" : [ 71, 85 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "745712484363943936",
  "text" : "RT @biocrusoe: #ISMB16 should acknowledge and honor the victims of the #PulseShooting by..",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ISMB16",
        "indices" : [ 0, 7 ]
      }, {
        "text" : "PulseShooting",
        "indices" : [ 56, 70 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "743711073400872960",
    "text" : "#ISMB16 should acknowledge and honor the victims of the #PulseShooting by..",
    "id" : 743711073400872960,
    "created_at" : "2016-06-17 07:45:12 +0000",
    "user" : {
      "name" : "Michael R. Crusoe",
      "screen_name" : "biocrusoe",
      "protected" : false,
      "id_str" : "17645638",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/485998749311721472\/0yX4CFRV_normal.jpeg",
      "id" : 17645638,
      "verified" : false
    }
  },
  "id" : 745712484363943936,
  "created_at" : "2016-06-22 20:18:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Markus P\u00F6ssel",
      "screen_name" : "mpoessel",
      "indices" : [ 0, 9 ],
      "id_str" : "276597679",
      "id" : 276597679
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 53 ],
      "url" : "https:\/\/t.co\/Seuxvj6KhH",
      "expanded_url" : "http:\/\/www.nature.com\/news\/why-high-profile-journals-have-more-retractions-1.15951",
      "display_url" : "nature.com\/news\/why-high-\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "745711808284065796",
  "geo" : { },
  "id_str" : "745712204578758656",
  "in_reply_to_user_id" : 276597679,
  "text" : "@mpoessel there\u2019s for example https:\/\/t.co\/Seuxvj6KhH",
  "id" : 745712204578758656,
  "in_reply_to_status_id" : 745711808284065796,
  "created_at" : "2016-06-22 20:16:58 +0000",
  "in_reply_to_screen_name" : "mpoessel",
  "in_reply_to_user_id_str" : "276597679",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Markus P\u00F6ssel",
      "screen_name" : "mpoessel",
      "indices" : [ 0, 9 ],
      "id_str" : "276597679",
      "id" : 276597679
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "745710397496365056",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06099349033023, 8.81845863657711 ]
  },
  "id_str" : "745710521584877569",
  "in_reply_to_user_id" : 276597679,
  "text" : "@mpoessel PNAS is the worst offender for this in my book.",
  "id" : 745710521584877569,
  "in_reply_to_status_id" : 745710397496365056,
  "created_at" : "2016-06-22 20:10:17 +0000",
  "in_reply_to_screen_name" : "mpoessel",
  "in_reply_to_user_id_str" : "276597679",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/ZvVlclZTaS",
      "expanded_url" : "https:\/\/twitter.com\/sckottie\/status\/745691542216572928",
      "display_url" : "twitter.com\/sckottie\/statu\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06075010443933, 8.818404714889617 ]
  },
  "id_str" : "745709191579508737",
  "text" : "Unless it was published in Cell, Nature, Science or PNAS. Then it\u2019s too likely that it isn\u2019t a fact. https:\/\/t.co\/ZvVlclZTaS",
  "id" : 745709191579508737,
  "created_at" : "2016-06-22 20:05:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/TEZ5uOk2x2",
      "expanded_url" : "https:\/\/twitter.com\/gluejar\/status\/745682929695752193",
      "display_url" : "twitter.com\/gluejar\/status\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "745697170779672576",
  "text" : "Great summary on the whole fake DOI debacle that Wiley still has to respond to if I didn\u2019t miss anything. https:\/\/t.co\/TEZ5uOk2x2",
  "id" : 745697170779672576,
  "created_at" : "2016-06-22 19:17:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "~ organic linguist ~",
      "screen_name" : "textgruen",
      "indices" : [ 0, 10 ],
      "id_str" : "531766713",
      "id" : 531766713
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 34 ],
      "url" : "https:\/\/t.co\/85f9R3lmqJ",
      "expanded_url" : "http:\/\/bmcecol.biomedcentral.com\/articles\/10.1186\/s12898-016-0083-y",
      "display_url" : "bmcecol.biomedcentral.com\/articles\/10.11\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "745602498744954880",
  "geo" : { },
  "id_str" : "745602879243882496",
  "in_reply_to_user_id" : 531766713,
  "text" : "@textgruen https:\/\/t.co\/85f9R3lmqJ :p",
  "id" : 745602879243882496,
  "in_reply_to_status_id" : 745602498744954880,
  "created_at" : "2016-06-22 13:02:33 +0000",
  "in_reply_to_screen_name" : "textgruen",
  "in_reply_to_user_id_str" : "531766713",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "745600778275000320",
  "text" : "Now I\u2019m even being asked to even do a radio interview on \uD83D\uDC30\uD83D\uDCA9. My life keeps getting weirder and weirder\u2026",
  "id" : 745600778275000320,
  "created_at" : "2016-06-22 12:54:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Head",
      "screen_name" : "betatim",
      "indices" : [ 0, 8 ],
      "id_str" : "18881614",
      "id" : 18881614
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "745555419431604224",
  "geo" : { },
  "id_str" : "745557999771615232",
  "in_reply_to_user_id" : 18881614,
  "text" : "@betatim I\u2019m in the Department of Angewandte Bioinformatik. Go figure :p",
  "id" : 745557999771615232,
  "in_reply_to_status_id" : 745555419431604224,
  "created_at" : "2016-06-22 10:04:13 +0000",
  "in_reply_to_screen_name" : "betatim",
  "in_reply_to_user_id_str" : "18881614",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Head",
      "screen_name" : "betatim",
      "indices" : [ 0, 8 ],
      "id_str" : "18881614",
      "id" : 18881614
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "745548235041759234",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17253101419031, 8.627553125179112 ]
  },
  "id_str" : "745548690132082691",
  "in_reply_to_user_id" : 18881614,
  "text" : "@betatim i just assumed that, the Catalonian didn't appear to be too Academic.",
  "id" : 745548690132082691,
  "in_reply_to_status_id" : 745548235041759234,
  "created_at" : "2016-06-22 09:27:14 +0000",
  "in_reply_to_screen_name" : "betatim",
  "in_reply_to_user_id_str" : "18881614",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Head",
      "screen_name" : "betatim",
      "indices" : [ 0, 8 ],
      "id_str" : "18881614",
      "id" : 18881614
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "745547949959065600",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17253217070822, 8.627551695209684 ]
  },
  "id_str" : "745548081110777858",
  "in_reply_to_user_id" : 18881614,
  "text" : "@betatim no, you can apply, go for it!",
  "id" : 745548081110777858,
  "in_reply_to_status_id" : 745547949959065600,
  "created_at" : "2016-06-22 09:24:48 +0000",
  "in_reply_to_screen_name" : "betatim",
  "in_reply_to_user_id_str" : "18881614",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Head",
      "screen_name" : "betatim",
      "indices" : [ 0, 8 ],
      "id_str" : "18881614",
      "id" : 18881614
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "745545746418544640",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17244263328463, 8.627520338095005 ]
  },
  "id_str" : "745547054018027520",
  "in_reply_to_user_id" : 18881614,
  "text" : "@betatim so far only for the former. I think the latter doesn't have any reviewing in place. But would like to go there next year :)",
  "id" : 745547054018027520,
  "in_reply_to_status_id" : 745545746418544640,
  "created_at" : "2016-06-22 09:20:43 +0000",
  "in_reply_to_screen_name" : "betatim",
  "in_reply_to_user_id_str" : "18881614",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/awd9Kh3VQu",
      "expanded_url" : "https:\/\/twitter.com\/Senficon\/status\/745544767409266688",
      "display_url" : "twitter.com\/Senficon\/statu\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17243812098918, 8.627521714108223 ]
  },
  "id_str" : "745545325406916609",
  "text" : "Traditional publishing. Like a partner who refuses to get a real job and wants you to pay for everything. https:\/\/t.co\/awd9Kh3VQu",
  "id" : 745545325406916609,
  "created_at" : "2016-06-22 09:13:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "745544156588580864",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17236658026258, 8.627570879779134 ]
  },
  "id_str" : "745544547296382976",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon would make for a fun remix of your talk at last year's opencon.",
  "id" : 745544547296382976,
  "in_reply_to_status_id" : 745544156588580864,
  "created_at" : "2016-06-22 09:10:46 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Denker",
      "screen_name" : "Phaidr0s",
      "indices" : [ 0, 9 ],
      "id_str" : "40466433",
      "id" : 40466433
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "745542202307153920",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17243641774751, 8.627514446781133 ]
  },
  "id_str" : "745542320250978304",
  "in_reply_to_user_id" : 40466433,
  "text" : "@Phaidr0s but you'd wish",
  "id" : 745542320250978304,
  "in_reply_to_status_id" : 745542202307153920,
  "created_at" : "2016-06-22 09:01:55 +0000",
  "in_reply_to_screen_name" : "Phaidr0s",
  "in_reply_to_user_id_str" : "40466433",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 41 ],
      "url" : "https:\/\/t.co\/63Zu5WWs99",
      "expanded_url" : "https:\/\/twitter.com\/ithinkwellHugh\/status\/745472304574980096",
      "display_url" : "twitter.com\/ithinkwellHugh\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17243581893243, 8.62751474032127 ]
  },
  "id_str" : "745542065400864768",
  "text" : "Yep, we all suck. https:\/\/t.co\/63Zu5WWs99",
  "id" : 745542065400864768,
  "created_at" : "2016-06-22 09:00:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/gDn9iwNjOh",
      "expanded_url" : "http:\/\/www.opencon2016.org\/",
      "display_url" : "opencon2016.org"
    }, {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/czks0zeKPk",
      "expanded_url" : "https:\/\/opencon.cat\/",
      "display_url" : "opencon.cat"
    } ]
  },
  "geo" : { },
  "id_str" : "745538379119374336",
  "text" : "While going through the applications I fear that people actually mixed up the opencons. https:\/\/t.co\/gDn9iwNjOh vs https:\/\/t.co\/czks0zeKPk",
  "id" : 745538379119374336,
  "created_at" : "2016-06-22 08:46:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "745360243018731522",
  "geo" : { },
  "id_str" : "745361168504602626",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez that gives me some home",
  "id" : 745361168504602626,
  "in_reply_to_status_id" : 745360243018731522,
  "created_at" : "2016-06-21 21:02:05 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 7, 16 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/745359519971151872\/photo\/1",
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/3vTwhLz6GV",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ClgMiCsWMAAobWQ.jpg",
      "id_str" : "745359517307777024",
      "id" : 745359517307777024,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ClgMiCsWMAAobWQ.jpg",
      "sizes" : [ {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/3vTwhLz6GV"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "745359519971151872",
  "text" : "Thanks @eramirez for fixing me up with Gyroscope. Now I can measure exactly how little work-life balance I have. https:\/\/t.co\/3vTwhLz6GV",
  "id" : 745359519971151872,
  "created_at" : "2016-06-21 20:55:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/kGWGCCDTLL",
      "expanded_url" : "http:\/\/sigur-ros.co.uk\/",
      "display_url" : "sigur-ros.co.uk"
    } ]
  },
  "geo" : { },
  "id_str" : "745349823784697856",
  "text" : "Now: What live how Sigur R\u00F3s run red traffic lights and drive though tunnels during their Iceland round-trip https:\/\/t.co\/kGWGCCDTLL",
  "id" : 745349823784697856,
  "created_at" : "2016-06-21 20:17:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Yoder \uD83D\uDD96\uD83C\uDFFB",
      "screen_name" : "JBYoder",
      "indices" : [ 0, 8 ],
      "id_str" : "19984919",
      "id" : 19984919
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "744862461233233923",
  "geo" : { },
  "id_str" : "745324490910011392",
  "in_reply_to_user_id" : 19984919,
  "text" : "@JBYoder well done on the survey, glad to see that \u00ABWhat is your relationship status?\u00BB allows multiple answers :)",
  "id" : 745324490910011392,
  "in_reply_to_status_id" : 744862461233233923,
  "created_at" : "2016-06-21 18:36:20 +0000",
  "in_reply_to_screen_name" : "JBYoder",
  "in_reply_to_user_id_str" : "19984919",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Yoder \uD83D\uDD96\uD83C\uDFFB",
      "screen_name" : "JBYoder",
      "indices" : [ 3, 11 ],
      "id_str" : "19984919",
      "id" : 19984919
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LGBT",
      "indices" : [ 65, 70 ]
    }, {
      "text" : "STEM",
      "indices" : [ 80, 85 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "745196353668657153",
  "text" : "RT @JBYoder: The NEW Queer in STEM survey is open for responses! #LGBT folks in #STEM\u2014AND straight colleagues\u2014can take it here: https:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "LGBT",
        "indices" : [ 52, 57 ]
      }, {
        "text" : "STEM",
        "indices" : [ 67, 72 ]
      } ],
      "urls" : [ {
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/YxTnIAkJ53",
        "expanded_url" : "http:\/\/bit.ly\/queerSTEM2",
        "display_url" : "bit.ly\/queerSTEM2"
      } ]
    },
    "geo" : { },
    "id_str" : "744862461233233923",
    "text" : "The NEW Queer in STEM survey is open for responses! #LGBT folks in #STEM\u2014AND straight colleagues\u2014can take it here: https:\/\/t.co\/YxTnIAkJ53",
    "id" : 744862461233233923,
    "created_at" : "2016-06-20 12:00:24 +0000",
    "user" : {
      "name" : "Jeremy Yoder \uD83D\uDD96\uD83C\uDFFB",
      "screen_name" : "JBYoder",
      "protected" : false,
      "id_str" : "19984919",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/870850169759072256\/r0kxCgGs_normal.jpg",
      "id" : 19984919,
      "verified" : true
    }
  },
  "id" : 745196353668657153,
  "created_at" : "2016-06-21 10:07:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "745195276491710464",
  "text" : "The one thing i hate Goodreads for: the nondescript emails, \u201Eperson X commented your review\u201C, but can\u2019t even read the comment in their app\u2026",
  "id" : 745195276491710464,
  "created_at" : "2016-06-21 10:02:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "the Winnower",
      "screen_name" : "theWinnower",
      "indices" : [ 3, 15 ],
      "id_str" : "748018813",
      "id" : 748018813
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "745010376471896064",
  "text" : "RT @theWinnower: If you don't use the Winnower because of cost, tell us. We're trying to build sustainable platform but are happy to help w\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "745005529865527296",
    "text" : "If you don't use the Winnower because of cost, tell us. We're trying to build sustainable platform but are happy to help waive costs.",
    "id" : 745005529865527296,
    "created_at" : "2016-06-20 21:28:54 +0000",
    "user" : {
      "name" : "the Winnower",
      "screen_name" : "theWinnower",
      "protected" : false,
      "id_str" : "748018813",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/459467186734514177\/xIXadyix_normal.jpeg",
      "id" : 748018813,
      "verified" : false
    }
  },
  "id" : 745010376471896064,
  "created_at" : "2016-06-20 21:48:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BOSC",
      "screen_name" : "OBF_BOSC",
      "indices" : [ 3, 12 ],
      "id_str" : "583180584",
      "id" : 583180584
    }, {
      "name" : "Curoverse",
      "screen_name" : "curoverse",
      "indices" : [ 31, 41 ],
      "id_str" : "2242847599",
      "id" : 2242847599
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BOSC2016",
      "indices" : [ 14, 23 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "745007497816195072",
  "text" : "RT @OBF_BOSC: #BOSC2016 thanks @curoverse for their sponsorship, which helps us lower registration costs for some speakers.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Curoverse",
        "screen_name" : "curoverse",
        "indices" : [ 17, 27 ],
        "id_str" : "2242847599",
        "id" : 2242847599
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BOSC2016",
        "indices" : [ 0, 9 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "744979861677060096",
    "text" : "#BOSC2016 thanks @curoverse for their sponsorship, which helps us lower registration costs for some speakers.",
    "id" : 744979861677060096,
    "created_at" : "2016-06-20 19:46:54 +0000",
    "user" : {
      "name" : "BOSC",
      "screen_name" : "OBF_BOSC",
      "protected" : false,
      "id_str" : "583180584",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2227105401\/BOSC-logo-square_normal.jpg",
      "id" : 583180584,
      "verified" : false
    }
  },
  "id" : 745007497816195072,
  "created_at" : "2016-06-20 21:36:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "M\u24D0rtin W\u24D0gner",
      "screen_name" : "martiwag",
      "indices" : [ 0, 9 ],
      "id_str" : "1162531196",
      "id" : 1162531196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "744976840096362501",
  "geo" : { },
  "id_str" : "744980411860848640",
  "in_reply_to_user_id" : 1162531196,
  "text" : "@martiwag I think this reaction is how you can safely spot biologists from a crowd! :-)",
  "id" : 744980411860848640,
  "in_reply_to_status_id" : 744976840096362501,
  "created_at" : "2016-06-20 19:49:05 +0000",
  "in_reply_to_screen_name" : "martiwag",
  "in_reply_to_user_id_str" : "1162531196",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "M\u24D0rtin W\u24D0gner",
      "screen_name" : "martiwag",
      "indices" : [ 0, 9 ],
      "id_str" : "1162531196",
      "id" : 1162531196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "744975224999915520",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1107046101709, 8.757659448318888 ]
  },
  "id_str" : "744975494240739328",
  "in_reply_to_user_id" : 1162531196,
  "text" : "@martiwag so, how bad was it? ;)",
  "id" : 744975494240739328,
  "in_reply_to_status_id" : 744975224999915520,
  "created_at" : "2016-06-20 19:29:33 +0000",
  "in_reply_to_screen_name" : "martiwag",
  "in_reply_to_user_id_str" : "1162531196",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "smbe16",
      "indices" : [ 35, 42 ]
    } ],
    "urls" : [ {
      "indices" : [ 51, 74 ],
      "url" : "https:\/\/t.co\/XIW2jkS9xN",
      "expanded_url" : "https:\/\/twitter.com\/JBYoder\/status\/744552423876759552",
      "display_url" : "twitter.com\/JBYoder\/status\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11403884554393, 8.75336672448352 ]
  },
  "id_str" : "744969570570616833",
  "text" : "Can we have something like this at #smbe16 please? https:\/\/t.co\/XIW2jkS9xN",
  "id" : 744969570570616833,
  "created_at" : "2016-06-20 19:06:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Yoder \uD83D\uDD96\uD83C\uDFFB",
      "screen_name" : "JBYoder",
      "indices" : [ 0, 8 ],
      "id_str" : "19984919",
      "id" : 19984919
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "744930999981596672",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11403912515698, 8.75336589404291 ]
  },
  "id_str" : "744969267410534400",
  "in_reply_to_user_id" : 19984919,
  "text" : "@JBYoder awesome name \uD83D\uDC96",
  "id" : 744969267410534400,
  "in_reply_to_status_id" : 744930999981596672,
  "created_at" : "2016-06-20 19:04:48 +0000",
  "in_reply_to_screen_name" : "JBYoder",
  "in_reply_to_user_id_str" : "19984919",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/mDTz0r2Dc5",
      "expanded_url" : "http:\/\/www.atlasobscura.com\/articles\/the-colorful-pain-index-of-the-stinging-ants-bees-and-wasps-around-the-world",
      "display_url" : "atlasobscura.com\/articles\/the-c\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "744906125426982912",
  "text" : "Every scientist needs a side project or two. Why not collecting insect stings https:\/\/t.co\/mDTz0r2Dc5",
  "id" : 744906125426982912,
  "created_at" : "2016-06-20 14:53:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bi\u24D0nca Kramer",
      "screen_name" : "MsPhelps",
      "indices" : [ 3, 12 ],
      "id_str" : "22963112",
      "id" : 22963112
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/lFJkYeBgCY",
      "expanded_url" : "https:\/\/im2punt0.wordpress.com\/2016\/06\/20\/sci-hub-access-or-convenience-a-utrecht-case-study-part-2\/",
      "display_url" : "im2punt0.wordpress.com\/2016\/06\/20\/sci\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "744861735648137216",
  "text" : "RT @MsPhelps: Sci-Hub: access or convenience? A Utrecht case study (part 2): https:\/\/t.co\/lFJkYeBgCY",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 63, 86 ],
        "url" : "https:\/\/t.co\/lFJkYeBgCY",
        "expanded_url" : "https:\/\/im2punt0.wordpress.com\/2016\/06\/20\/sci-hub-access-or-convenience-a-utrecht-case-study-part-2\/",
        "display_url" : "im2punt0.wordpress.com\/2016\/06\/20\/sci\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "744858709902368769",
    "text" : "Sci-Hub: access or convenience? A Utrecht case study (part 2): https:\/\/t.co\/lFJkYeBgCY",
    "id" : 744858709902368769,
    "created_at" : "2016-06-20 11:45:29 +0000",
    "user" : {
      "name" : "Bi\u24D0nca Kramer",
      "screen_name" : "MsPhelps",
      "protected" : false,
      "id_str" : "22963112",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/665529153576390660\/ukieWtR4_normal.jpg",
      "id" : 22963112,
      "verified" : false
    }
  },
  "id" : 744861735648137216,
  "created_at" : "2016-06-20 11:57:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bi\u24D0nca Kramer",
      "screen_name" : "MsPhelps",
      "indices" : [ 3, 12 ],
      "id_str" : "22963112",
      "id" : 22963112
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/reLEQcrSX0",
      "expanded_url" : "https:\/\/im2punt0.wordpress.com\/2016\/06\/20\/sci-hub-utrecht-case-study-part-1\/",
      "display_url" : "im2punt0.wordpress.com\/2016\/06\/20\/sci\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "744861578634362880",
  "text" : "RT @MsPhelps: Sci-Hub: access or convenience? A Utrecht case study (part 1) https:\/\/t.co\/reLEQcrSX0",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 62, 85 ],
        "url" : "https:\/\/t.co\/reLEQcrSX0",
        "expanded_url" : "https:\/\/im2punt0.wordpress.com\/2016\/06\/20\/sci-hub-utrecht-case-study-part-1\/",
        "display_url" : "im2punt0.wordpress.com\/2016\/06\/20\/sci\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "744858561386319872",
    "text" : "Sci-Hub: access or convenience? A Utrecht case study (part 1) https:\/\/t.co\/reLEQcrSX0",
    "id" : 744858561386319872,
    "created_at" : "2016-06-20 11:44:54 +0000",
    "user" : {
      "name" : "Bi\u24D0nca Kramer",
      "screen_name" : "MsPhelps",
      "protected" : false,
      "id_str" : "22963112",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/665529153576390660\/ukieWtR4_normal.jpg",
      "id" : 22963112,
      "verified" : false
    }
  },
  "id" : 744861578634362880,
  "created_at" : "2016-06-20 11:56:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthew Hahn",
      "screen_name" : "3rdreviewer",
      "indices" : [ 0, 12 ],
      "id_str" : "2678236062",
      "id" : 2678236062
    }, {
      "name" : "Razib Khan",
      "screen_name" : "razibkhan",
      "indices" : [ 13, 23 ],
      "id_str" : "35304791",
      "id" : 35304791
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "744292149093498881",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06096912888188, 8.818501003811512 ]
  },
  "id_str" : "744301085431635968",
  "in_reply_to_user_id" : 2678236062,
  "text" : "@3rdreviewer @razibkhan betcha some poorly done candidate gene studies and GWAS against this.",
  "id" : 744301085431635968,
  "in_reply_to_status_id" : 744292149093498881,
  "created_at" : "2016-06-18 22:49:41 +0000",
  "in_reply_to_screen_name" : "3rdreviewer",
  "in_reply_to_user_id_str" : "2678236062",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elio Qoshi",
      "screen_name" : "elioqoshi",
      "indices" : [ 0, 10 ],
      "id_str" : "93434375",
      "id" : 93434375
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "744251325395906560",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06097487704057, 8.818443140810047 ]
  },
  "id_str" : "744251434770833408",
  "in_reply_to_user_id" : 93434375,
  "text" : "@elioqoshi nope.js ;)",
  "id" : 744251434770833408,
  "in_reply_to_status_id" : 744251325395906560,
  "created_at" : "2016-06-18 19:32:24 +0000",
  "in_reply_to_screen_name" : "elioqoshi",
  "in_reply_to_user_id_str" : "93434375",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elio Qoshi",
      "screen_name" : "elioqoshi",
      "indices" : [ 0, 10 ],
      "id_str" : "93434375",
      "id" : 93434375
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "744250221295607809",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06094975867314, 8.818637793891893 ]
  },
  "id_str" : "744251170689015808",
  "in_reply_to_user_id" : 93434375,
  "text" : "@elioqoshi neither needs not wants. :p",
  "id" : 744251170689015808,
  "in_reply_to_status_id" : 744250221295607809,
  "created_at" : "2016-06-18 19:31:21 +0000",
  "in_reply_to_screen_name" : "elioqoshi",
  "in_reply_to_user_id_str" : "93434375",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uD83D\uDCABKelsey Merkley \uD83D\uDCAB",
      "screen_name" : "bella_velo",
      "indices" : [ 3, 14 ],
      "id_str" : "6745972",
      "id" : 6745972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 68 ],
      "url" : "https:\/\/t.co\/10Mq8pC7IU",
      "expanded_url" : "http:\/\/www.nytimes.com\/2016\/03\/13\/opinion\/sunday\/emoji-feminism.html?smprod=nytcore-iphone&smid=nytcore-iphone-share",
      "display_url" : "nytimes.com\/2016\/03\/13\/opi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "744249905405923328",
  "text" : "RT @bella_velo: Emoji Feminism - from \uD83D\uDC83\uD83C\uDFFDto \uD83D\uDC27 https:\/\/t.co\/10Mq8pC7IU",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 29, 52 ],
        "url" : "https:\/\/t.co\/10Mq8pC7IU",
        "expanded_url" : "http:\/\/www.nytimes.com\/2016\/03\/13\/opinion\/sunday\/emoji-feminism.html?smprod=nytcore-iphone&smid=nytcore-iphone-share",
        "display_url" : "nytimes.com\/2016\/03\/13\/opi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "744245532197978112",
    "text" : "Emoji Feminism - from \uD83D\uDC83\uD83C\uDFFDto \uD83D\uDC27 https:\/\/t.co\/10Mq8pC7IU",
    "id" : 744245532197978112,
    "created_at" : "2016-06-18 19:08:56 +0000",
    "user" : {
      "name" : "\uD83D\uDCABKelsey Merkley \uD83D\uDCAB",
      "screen_name" : "bella_velo",
      "protected" : false,
      "id_str" : "6745972",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/875913994929934336\/1aiBO2bG_normal.jpg",
      "id" : 6745972,
      "verified" : false
    }
  },
  "id" : 744249905405923328,
  "created_at" : "2016-06-18 19:26:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "undivided@yahoo.de",
      "screen_name" : "undivid_ed",
      "indices" : [ 0, 11 ],
      "id_str" : "438256823",
      "id" : 438256823
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "744226972453199872",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.03306297535416, 8.788615081825245 ]
  },
  "id_str" : "744238954560503808",
  "in_reply_to_user_id" : 438256823,
  "text" : "@undivid_ed time to run around only dressed with glasses in that case :p",
  "id" : 744238954560503808,
  "in_reply_to_status_id" : 744226972453199872,
  "created_at" : "2016-06-18 18:42:48 +0000",
  "in_reply_to_screen_name" : "undivid_ed",
  "in_reply_to_user_id_str" : "438256823",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Denker",
      "screen_name" : "Phaidr0s",
      "indices" : [ 0, 9 ],
      "id_str" : "40466433",
      "id" : 40466433
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/744224544836169729\/photo\/1",
      "indices" : [ 39, 62 ],
      "url" : "https:\/\/t.co\/sFgig5ndiF",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ClQERsyWQAE2jNJ.jpg",
      "id_str" : "744224540549595137",
      "id" : 744224540549595137,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ClQERsyWQAE2jNJ.jpg",
      "sizes" : [ {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      }, {
        "h" : 1280,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 1280,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/sFgig5ndiF"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "744224138240331776",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06094794911148, 8.818453460456217 ]
  },
  "id_str" : "744224544836169729",
  "in_reply_to_user_id" : 40466433,
  "text" : "@Phaidr0s diese z\u00E4hlt aber nicht oder? https:\/\/t.co\/sFgig5ndiF",
  "id" : 744224544836169729,
  "in_reply_to_status_id" : 744224138240331776,
  "created_at" : "2016-06-18 17:45:33 +0000",
  "in_reply_to_screen_name" : "Phaidr0s",
  "in_reply_to_user_id_str" : "40466433",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Denker",
      "screen_name" : "Phaidr0s",
      "indices" : [ 0, 9 ],
      "id_str" : "40466433",
      "id" : 40466433
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "744222327735455744",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06093859170775, 8.818726417469911 ]
  },
  "id_str" : "744223497854025728",
  "in_reply_to_user_id" : 40466433,
  "text" : "@Phaidr0s dann hab ich ja Gl\u00FCck gehabt, bin dann erst bei 3. \u00C4h, der Freund ist dann erst bei 3.",
  "id" : 744223497854025728,
  "in_reply_to_status_id" : 744222327735455744,
  "created_at" : "2016-06-18 17:41:23 +0000",
  "in_reply_to_screen_name" : "Phaidr0s",
  "in_reply_to_user_id_str" : "40466433",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Denker",
      "screen_name" : "Phaidr0s",
      "indices" : [ 0, 9 ],
      "id_str" : "40466433",
      "id" : 40466433
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/744222113758875649\/photo\/1",
      "indices" : [ 18, 41 ],
      "url" : "https:\/\/t.co\/XFvF5W6049",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ClQCEJXXEAECV40.jpg",
      "id_str" : "744222108679606273",
      "id" : 744222108679606273,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ClQCEJXXEAECV40.jpg",
      "sizes" : [ {
        "h" : 960,
        "resize" : "fit",
        "w" : 1280
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 1280
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/XFvF5W6049"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "744221932770328576",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06093517416162, 8.818606194116937 ]
  },
  "id_str" : "744222113758875649",
  "in_reply_to_user_id" : 40466433,
  "text" : "@Phaidr0s mh? \uD83E\uDD13\uD83D\uDE0E\uD83D\uDE0B https:\/\/t.co\/XFvF5W6049",
  "id" : 744222113758875649,
  "in_reply_to_status_id" : 744221932770328576,
  "created_at" : "2016-06-18 17:35:53 +0000",
  "in_reply_to_screen_name" : "Phaidr0s",
  "in_reply_to_user_id_str" : "40466433",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06087610027337, 8.818539239878259 ]
  },
  "id_str" : "744221606831087617",
  "text" : "How many different pairs of glasses may you own without being seen as an eccentric? Asking for a friend.",
  "id" : 744221606831087617,
  "created_at" : "2016-06-18 17:33:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "744206366177320961",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06091086664242, 8.818567134448157 ]
  },
  "id_str" : "744207093113163776",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer could answer Q: how many botched lib preps do you need to get your own genome seq\u2019d?",
  "id" : 744207093113163776,
  "in_reply_to_status_id" : 744206366177320961,
  "created_at" : "2016-06-18 16:36:12 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "744063524519948288",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.10372344557472, 8.766525932663471 ]
  },
  "id_str" : "744162709881692160",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer should make a fun project :D",
  "id" : 744162709881692160,
  "in_reply_to_status_id" : 744063524519948288,
  "created_at" : "2016-06-18 13:39:50 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "samantha based clark",
      "screen_name" : "eltonjohn",
      "indices" : [ 0, 10 ],
      "id_str" : "15661851",
      "id" : 15661851
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "743986579576848384",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06092480980067, 8.81852497442427 ]
  },
  "id_str" : "744102105661706240",
  "in_reply_to_user_id" : 15661851,
  "text" : "@eltonjohn \uD83D\uDE18",
  "id" : 744102105661706240,
  "in_reply_to_status_id" : 743986579576848384,
  "created_at" : "2016-06-18 09:39:01 +0000",
  "in_reply_to_screen_name" : "eltonjohn",
  "in_reply_to_user_id_str" : "15661851",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fabian Mohr",
      "screen_name" : "fabianmohr",
      "indices" : [ 3, 14 ],
      "id_str" : "13183522",
      "id" : 13183522
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "744085307994300417",
  "text" : "RT @fabianmohr: A few stone-still faces in the audience. Great speech by Hasan Minhaj on guns, racism, congress, Trump. https:\/\/t.co\/K0DfvE\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 104, 127 ],
        "url" : "https:\/\/t.co\/K0DfvEyHno",
        "expanded_url" : "https:\/\/youtu.be\/NUymQKZqP6w",
        "display_url" : "youtu.be\/NUymQKZqP6w"
      } ]
    },
    "geo" : { },
    "id_str" : "743926637998252032",
    "text" : "A few stone-still faces in the audience. Great speech by Hasan Minhaj on guns, racism, congress, Trump. https:\/\/t.co\/K0DfvEyHno",
    "id" : 743926637998252032,
    "created_at" : "2016-06-17 22:01:46 +0000",
    "user" : {
      "name" : "Fabian Mohr",
      "screen_name" : "fabianmohr",
      "protected" : false,
      "id_str" : "13183522",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/932352046967246849\/UXOqOF2N_normal.jpg",
      "id" : 13183522,
      "verified" : true
    }
  },
  "id" : 744085307994300417,
  "created_at" : "2016-06-18 08:32:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "743716830234054660",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17246164188374, 8.627353160040546 ]
  },
  "id_str" : "743782812386533376",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer happened to me using CEGMA. Blamed CEGMA back when. But guess there\u2019s some non-deterministic steps involved in general :p",
  "id" : 743782812386533376,
  "in_reply_to_status_id" : 743716830234054660,
  "created_at" : "2016-06-17 12:30:15 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael R. Crusoe",
      "screen_name" : "biocrusoe",
      "indices" : [ 0, 10 ],
      "id_str" : "17645638",
      "id" : 17645638
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "743710036258488321",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17244804824762, 8.62735512819041 ]
  },
  "id_str" : "743781972359716864",
  "in_reply_to_user_id" : 17645638,
  "text" : "@biocrusoe already wondered about that myself. Thanks for bringing it up.",
  "id" : 743781972359716864,
  "in_reply_to_status_id" : 743710036258488321,
  "created_at" : "2016-06-17 12:26:55 +0000",
  "in_reply_to_screen_name" : "biocrusoe",
  "in_reply_to_user_id_str" : "17645638",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael R. Crusoe",
      "screen_name" : "biocrusoe",
      "indices" : [ 3, 13 ],
      "id_str" : "17645638",
      "id" : 17645638
    }, {
      "name" : "BOSC",
      "screen_name" : "OBF_BOSC",
      "indices" : [ 21, 30 ],
      "id_str" : "583180584",
      "id" : 583180584
    }, {
      "name" : "ICSB",
      "screen_name" : "ICSB",
      "indices" : [ 35, 40 ],
      "id_str" : "17287193",
      "id" : 17287193
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ISMB16",
      "indices" : [ 41, 48 ]
    }, {
      "text" : "Pulse",
      "indices" : [ 119, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "743781771444117504",
  "text" : "RT @biocrusoe: Hello @OBF_BOSC and @ICSB #ISMB16 participants: what is the plan to pay our respects to the massacre at #Pulse?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "BOSC",
        "screen_name" : "OBF_BOSC",
        "indices" : [ 6, 15 ],
        "id_str" : "583180584",
        "id" : 583180584
      }, {
        "name" : "ICSB",
        "screen_name" : "ICSB",
        "indices" : [ 20, 25 ],
        "id_str" : "17287193",
        "id" : 17287193
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ISMB16",
        "indices" : [ 26, 33 ]
      }, {
        "text" : "Pulse",
        "indices" : [ 104, 110 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "743710036258488321",
    "text" : "Hello @OBF_BOSC and @ICSB #ISMB16 participants: what is the plan to pay our respects to the massacre at #Pulse?",
    "id" : 743710036258488321,
    "created_at" : "2016-06-17 07:41:04 +0000",
    "user" : {
      "name" : "Michael R. Crusoe",
      "screen_name" : "biocrusoe",
      "protected" : false,
      "id_str" : "17645638",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/485998749311721472\/0yX4CFRV_normal.jpeg",
      "id" : 17645638,
      "verified" : false
    }
  },
  "id" : 743781771444117504,
  "created_at" : "2016-06-17 12:26:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "743703730344755204",
  "text" : "I\u2019ve truly become a cosmopolite. Instead of misnaming me \u2018Sebastian\u2019 people now go for \u2018Bastion\u2019 or \u2018Bastien\u2019.",
  "id" : 743703730344755204,
  "created_at" : "2016-06-17 07:16:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/743560611179683840\/photo\/1",
      "indices" : [ 22, 45 ],
      "url" : "https:\/\/t.co\/6mYPDXhQd0",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ClGobutWYAA3vKY.jpg",
      "id_str" : "743560607841017856",
      "id" : 743560607841017856,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ClGobutWYAA3vKY.jpg",
      "sizes" : [ {
        "h" : 723,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 240,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 424,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 750,
        "resize" : "fit",
        "w" : 2124
      } ],
      "display_url" : "pic.twitter.com\/6mYPDXhQd0"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "743560611179683840",
  "text" : "Adorable children. \uD83C\uDDFA\uD83C\uDDF8 https:\/\/t.co\/6mYPDXhQd0",
  "id" : 743560611179683840,
  "created_at" : "2016-06-16 21:47:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 46 ],
      "url" : "https:\/\/t.co\/FEpIo3nzIi",
      "expanded_url" : "https:\/\/twitter.com\/BeamJake\/status\/742811523630895104",
      "display_url" : "twitter.com\/BeamJake\/statu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "743538304814034944",
  "text" : "\u00AB\u2026and now make it 3D!\u00BB https:\/\/t.co\/FEpIo3nzIi",
  "id" : 743538304814034944,
  "created_at" : "2016-06-16 20:18:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/E4lXGD0OGu",
      "expanded_url" : "http:\/\/www.newyorker.com\/news\/daily-comment\/one-person-one-gun?mbid=rss",
      "display_url" : "newyorker.com\/news\/daily-com\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "743475271521677312",
  "text" : "\u00ABit is easy to make gun terrorism hard. It begins with controlling the weapons that terror loves.\u00BB https:\/\/t.co\/E4lXGD0OGu",
  "id" : 743475271521677312,
  "created_at" : "2016-06-16 16:08:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elizabeth Seiver",
      "screen_name" : "tweetotaler",
      "indices" : [ 0, 12 ],
      "id_str" : "29891068",
      "id" : 29891068
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "743472378554941440",
  "geo" : { },
  "id_str" : "743472593999630336",
  "in_reply_to_user_id" : 29891068,
  "text" : "@tweetotaler best if you\u2019re a regular at one of them and just order \u201Ethe usual\u201C at the wrong one.",
  "id" : 743472593999630336,
  "in_reply_to_status_id" : 743472378554941440,
  "created_at" : "2016-06-16 15:57:34 +0000",
  "in_reply_to_screen_name" : "tweetotaler",
  "in_reply_to_user_id_str" : "29891068",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/85f9R3lmqJ",
      "expanded_url" : "http:\/\/bmcecol.biomedcentral.com\/articles\/10.1186\/s12898-016-0083-y",
      "display_url" : "bmcecol.biomedcentral.com\/articles\/10.11\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "743467178331148288",
  "text" : "My publication list gets weirder by the year: The literal crap you have to deal with when doing a degree in Ecology. https:\/\/t.co\/85f9R3lmqJ",
  "id" : 743467178331148288,
  "created_at" : "2016-06-16 15:36:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/nFjxdvj0yz",
      "expanded_url" : "https:\/\/medium.com\/@violetblue\/but-he-does-good-work-6710df9d9029#.z2mgn44p1",
      "display_url" : "medium.com\/@violetblue\/bu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "743436594321952770",
  "text" : "\u00ABWhen someone harasses, humiliates, discounts, abuses, threatens, stalks, [\u2026], no\u200A\u2014\u200Athey do not do good work\u00BB https:\/\/t.co\/nFjxdvj0yz",
  "id" : 743436594321952770,
  "created_at" : "2016-06-16 13:34:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Iara VPS",
      "screen_name" : "iaravps",
      "indices" : [ 0, 8 ],
      "id_str" : "173881525",
      "id" : 173881525
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "743432914097037312",
  "geo" : { },
  "id_str" : "743433140375531520",
  "in_reply_to_user_id" : 173881525,
  "text" : "@iaravps been to only one, it was mediocre. The other one I\u2019ll visit tonight. Vietnamese friends say it\u2019s the best place in Frankfurt.",
  "id" : 743433140375531520,
  "in_reply_to_status_id" : 743432914097037312,
  "created_at" : "2016-06-16 13:20:47 +0000",
  "in_reply_to_screen_name" : "iaravps",
  "in_reply_to_user_id_str" : "173881525",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17218863732374, 8.627710740776289 ]
  },
  "id_str" : "743412840611090432",
  "text" : "There are two Ph\u1EDF places in Frankfurt, less than 300 meters apart, called \u2018Vipho\u2019 and \u2018VietPho\u2019. Not confusing at all.",
  "id" : 743412840611090432,
  "created_at" : "2016-06-16 12:00:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 47 ],
      "url" : "https:\/\/t.co\/1MNZsBibyQ",
      "expanded_url" : "http:\/\/www.smbc-comics.com\/index.php?id=4141",
      "display_url" : "smbc-comics.com\/index.php?id=4\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "743406152877219840",
  "text" : "AI Ethics for beginners https:\/\/t.co\/1MNZsBibyQ",
  "id" : 743406152877219840,
  "created_at" : "2016-06-16 11:33:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 143 ],
      "url" : "https:\/\/t.co\/f3ir9Mn73a",
      "expanded_url" : "https:\/\/github.com\/openSNP\/snpr\/issues\/289",
      "display_url" : "github.com\/openSNP\/snpr\/i\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "743403726027759621",
  "text" : "Will take a couple of days to fix all SNPs, but allele frequencies &amp; users sharing SNPs will be working again soon! https:\/\/t.co\/f3ir9Mn73a",
  "id" : 743403726027759621,
  "created_at" : "2016-06-16 11:23:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 0, 10 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "743400281925369856",
  "geo" : { },
  "id_str" : "743401505928118272",
  "in_reply_to_user_id" : 1385861262,
  "text" : "@Julie_B92 i\u2019m already maxed out at 8 GB, so the only option left would be to upgrade the machine, which I don\u2019t want.",
  "id" : 743401505928118272,
  "in_reply_to_status_id" : 743400281925369856,
  "created_at" : "2016-06-16 11:15:05 +0000",
  "in_reply_to_screen_name" : "Julie_B92",
  "in_reply_to_user_id_str" : "1385861262",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 0, 10 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/743400060243816449\/photo\/1",
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/40NBlyCTyq",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ClEWaTUWIAEpiiQ.jpg",
      "id_str" : "743400054610862081",
      "id" : 743400054610862081,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ClEWaTUWIAEpiiQ.jpg",
      "sizes" : [ {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 3024,
        "resize" : "fit",
        "w" : 4032
      } ],
      "display_url" : "pic.twitter.com\/40NBlyCTyq"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "743398747539935232",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17245243276766, 8.627350922693173 ]
  },
  "id_str" : "743400060243816449",
  "in_reply_to_user_id" : 1385861262,
  "text" : "@Julie_B92 works nicely so far. Though I think I\u2019m straining my MacBook Air a bit. :p https:\/\/t.co\/40NBlyCTyq",
  "id" : 743400060243816449,
  "in_reply_to_status_id" : 743398747539935232,
  "created_at" : "2016-06-16 11:09:20 +0000",
  "in_reply_to_screen_name" : "Julie_B92",
  "in_reply_to_user_id_str" : "1385861262",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Brechler",
      "screen_name" : "gutsle",
      "indices" : [ 0, 7 ],
      "id_str" : "837535866",
      "id" : 837535866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "743388468340985856",
  "geo" : { },
  "id_str" : "743398612432986112",
  "in_reply_to_user_id" : 837535866,
  "text" : "@gutsle danke!",
  "id" : 743398612432986112,
  "in_reply_to_status_id" : 743388468340985856,
  "created_at" : "2016-06-16 11:03:35 +0000",
  "in_reply_to_screen_name" : "gutsle",
  "in_reply_to_user_id_str" : "837535866",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ciyer",
      "screen_name" : "ciyer",
      "indices" : [ 0, 6 ],
      "id_str" : "14533425",
      "id" : 14533425
    }, {
      "name" : "Henning Krause",
      "screen_name" : "henningkrause",
      "indices" : [ 7, 21 ],
      "id_str" : "21507738",
      "id" : 21507738
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "743392599197769728",
  "geo" : { },
  "id_str" : "743398599707496448",
  "in_reply_to_user_id" : 14533425,
  "text" : "@ciyer @henningkrause thanks!",
  "id" : 743398599707496448,
  "in_reply_to_status_id" : 743392599197769728,
  "created_at" : "2016-06-16 11:03:32 +0000",
  "in_reply_to_screen_name" : "ciyer",
  "in_reply_to_user_id_str" : "14533425",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 0, 10 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 54 ],
      "url" : "https:\/\/t.co\/AEcyQ7kZDv",
      "expanded_url" : "http:\/\/www.duetdisplay.com",
      "display_url" : "duetdisplay.com"
    } ]
  },
  "in_reply_to_status_id_str" : "743396210648682496",
  "geo" : { },
  "id_str" : "743398511010512896",
  "in_reply_to_user_id" : 1385861262,
  "text" : "@Julie_B92 yes, and apparently https:\/\/t.co\/AEcyQ7kZDv is the tool of choice for that.",
  "id" : 743398511010512896,
  "in_reply_to_status_id" : 743396210648682496,
  "created_at" : "2016-06-16 11:03:11 +0000",
  "in_reply_to_screen_name" : "Julie_B92",
  "in_reply_to_user_id_str" : "1385861262",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "lazyweb",
      "indices" : [ 98, 106 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "743382158044237824",
  "text" : "Which App does one want these days to turn an iPad into an external monitor for MacOS these days? #lazyweb",
  "id" : 743382158044237824,
  "created_at" : "2016-06-16 09:58:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Heather L. Wiencko",
      "screen_name" : "HLWiencko",
      "indices" : [ 0, 10 ],
      "id_str" : "2657942712",
      "id" : 2657942712
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "743372149876985856",
  "geo" : { },
  "id_str" : "743372866465439744",
  "in_reply_to_user_id" : 2657942712,
  "text" : "@HLWiencko yes, it\u2019s good if you can share places, then it gets easier.",
  "id" : 743372866465439744,
  "in_reply_to_status_id" : 743372149876985856,
  "created_at" : "2016-06-16 09:21:17 +0000",
  "in_reply_to_screen_name" : "HLWiencko",
  "in_reply_to_user_id_str" : "2657942712",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Heather L. Wiencko",
      "screen_name" : "HLWiencko",
      "indices" : [ 0, 10 ],
      "id_str" : "2657942712",
      "id" : 2657942712
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "743369573932609536",
  "geo" : { },
  "id_str" : "743371590344257536",
  "in_reply_to_user_id" : 2657942712,
  "text" : "@HLWiencko that\u2019s true. Fortunately I was stuck with racist ones only rarely so far.",
  "id" : 743371590344257536,
  "in_reply_to_status_id" : 743369573932609536,
  "created_at" : "2016-06-16 09:16:12 +0000",
  "in_reply_to_screen_name" : "HLWiencko",
  "in_reply_to_user_id_str" : "2657942712",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Heather L. Wiencko",
      "screen_name" : "HLWiencko",
      "indices" : [ 0, 10 ],
      "id_str" : "2657942712",
      "id" : 2657942712
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "743368635167694848",
  "geo" : { },
  "id_str" : "743368863023235072",
  "in_reply_to_user_id" : 2657942712,
  "text" : "@HLWiencko \u201Emight be a good host if you have passing as a straight white person\u201C\u2026",
  "id" : 743368863023235072,
  "in_reply_to_status_id" : 743368635167694848,
  "created_at" : "2016-06-16 09:05:22 +0000",
  "in_reply_to_screen_name" : "HLWiencko",
  "in_reply_to_user_id_str" : "2657942712",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "743367066091130880",
  "text" : "\u00ABI don\u2019t have any preference amongst the Airbnbs you sent.\u00BB \u2013 \u00ABGreat, then I\u2019ll just try to infer which host will be least racist.\u00BB",
  "id" : 743367066091130880,
  "created_at" : "2016-06-16 08:58:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/743352688910340096\/photo\/1",
      "indices" : [ 3, 26 ],
      "url" : "https:\/\/t.co\/XbhOlJ7bd6",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ClDrVFCUoAApUtr.jpg",
      "id_str" : "743352685877829632",
      "id" : 743352685877829632,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ClDrVFCUoAApUtr.jpg",
      "sizes" : [ {
        "h" : 1214,
        "resize" : "fit",
        "w" : 1222
      }, {
        "h" : 676,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1192,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1214,
        "resize" : "fit",
        "w" : 1222
      } ],
      "display_url" : "pic.twitter.com\/XbhOlJ7bd6"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.175642, 8.628968 ]
  },
  "id_str" : "743352688910340096",
  "text" : "\uD83D\uDC96\uD83C\uDFD4 https:\/\/t.co\/XbhOlJ7bd6",
  "id" : 743352688910340096,
  "created_at" : "2016-06-16 08:01:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olafur Palsson",
      "screen_name" : "DrPalssonUNC",
      "indices" : [ 0, 13 ],
      "id_str" : "420496276",
      "id" : 420496276
    }, {
      "name" : "Marcia E Walker \uD83E\uDD8B",
      "screen_name" : "MWEnergy",
      "indices" : [ 14, 23 ],
      "id_str" : "603993442",
      "id" : 603993442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "743196984148918273",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11385033422124, 8.75352476361282 ]
  },
  "id_str" : "743197181729988610",
  "in_reply_to_user_id" : 420496276,
  "text" : "@DrPalssonUNC @MWEnergy yes, the humor is great. And the fish is already on my to-read list. :)",
  "id" : 743197181729988610,
  "in_reply_to_status_id" : 743196984148918273,
  "created_at" : "2016-06-15 21:43:10 +0000",
  "in_reply_to_screen_name" : "DrPalssonUNC",
  "in_reply_to_user_id_str" : "420496276",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marcia E Walker \uD83E\uDD8B",
      "screen_name" : "MWEnergy",
      "indices" : [ 0, 9 ],
      "id_str" : "603993442",
      "id" : 603993442
    }, {
      "name" : "Olafur Palsson",
      "screen_name" : "DrPalssonUNC",
      "indices" : [ 10, 23 ],
      "id_str" : "420496276",
      "id" : 420496276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "743152234448420865",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11386845453305, 8.753514108148677 ]
  },
  "id_str" : "743153634762948616",
  "in_reply_to_user_id" : 603993442,
  "text" : "@MWEnergy @DrPalssonUNC Under the Glacier, the quote\u2019s from it :)",
  "id" : 743153634762948616,
  "in_reply_to_status_id" : 743152234448420865,
  "created_at" : "2016-06-15 18:50:08 +0000",
  "in_reply_to_screen_name" : "MWEnergy",
  "in_reply_to_user_id_str" : "603993442",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marcia E Walker \uD83E\uDD8B",
      "screen_name" : "MWEnergy",
      "indices" : [ 0, 9 ],
      "id_str" : "603993442",
      "id" : 603993442
    }, {
      "name" : "Olafur Palsson",
      "screen_name" : "DrPalssonUNC",
      "indices" : [ 10, 23 ],
      "id_str" : "420496276",
      "id" : 420496276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "743146782633275392",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11290279947431, 8.75381343955841 ]
  },
  "id_str" : "743151635308871681",
  "in_reply_to_user_id" : 603993442,
  "text" : "@MWEnergy @DrPalssonUNC just started reading Laxness and I\u2019m already in love.",
  "id" : 743151635308871681,
  "in_reply_to_status_id" : 743146782633275392,
  "created_at" : "2016-06-15 18:42:11 +0000",
  "in_reply_to_screen_name" : "MWEnergy",
  "in_reply_to_user_id_str" : "603993442",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11381681987928, 8.753535773209649 ]
  },
  "id_str" : "743145137828696064",
  "text" : "\u00ABIcelanders are not particularly hospitable in the sagas, [\u2026], although things improved since coffee was discovered.\u00BB \uD83D\uDE02",
  "id" : 743145137828696064,
  "created_at" : "2016-06-15 18:16:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 0, 14 ],
      "id_str" : "352650591",
      "id" : 352650591
    }, {
      "name" : "\u24EA Chris Hartgerink",
      "screen_name" : "chartgerink",
      "indices" : [ 15, 27 ],
      "id_str" : "439273539",
      "id" : 439273539
    }, {
      "name" : "Joseph McArthur",
      "screen_name" : "Mcarthur_Joe",
      "indices" : [ 28, 41 ],
      "id_str" : "478181304",
      "id" : 478181304
    }, {
      "name" : "Tony Ross-Hellauer",
      "screen_name" : "tonyR_H",
      "indices" : [ 42, 50 ],
      "id_str" : "44890780",
      "id" : 44890780
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "743108526214656000",
  "geo" : { },
  "id_str" : "743108709283422209",
  "in_reply_to_user_id" : 352650591,
  "text" : "@Protohedgehog @chartgerink @Mcarthur_Joe @tonyR_H drunk-dialing for hosting an opencon satellite? :D",
  "id" : 743108709283422209,
  "in_reply_to_status_id" : 743108526214656000,
  "created_at" : "2016-06-15 15:51:37 +0000",
  "in_reply_to_screen_name" : "Protohedgehog",
  "in_reply_to_user_id_str" : "352650591",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u24EA Chris Hartgerink",
      "screen_name" : "chartgerink",
      "indices" : [ 0, 12 ],
      "id_str" : "439273539",
      "id" : 439273539
    }, {
      "name" : "Joseph McArthur",
      "screen_name" : "Mcarthur_Joe",
      "indices" : [ 13, 26 ],
      "id_str" : "478181304",
      "id" : 478181304
    }, {
      "name" : "Tony Ross-Hellauer",
      "screen_name" : "tonyR_H",
      "indices" : [ 27, 35 ],
      "id_str" : "44890780",
      "id" : 44890780
    }, {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 60, 74 ],
      "id_str" : "352650591",
      "id" : 352650591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "743108212577042434",
  "geo" : { },
  "id_str" : "743108371067371520",
  "in_reply_to_user_id" : 439273539,
  "text" : "@chartgerink @Mcarthur_Joe @tonyR_H Sounds like a classical @Protohedgehog to me :D",
  "id" : 743108371067371520,
  "in_reply_to_status_id" : 743108212577042434,
  "created_at" : "2016-06-15 15:50:16 +0000",
  "in_reply_to_screen_name" : "chartgerink",
  "in_reply_to_user_id_str" : "439273539",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 86 ],
      "url" : "https:\/\/t.co\/ppfVD6CrLT",
      "expanded_url" : "https:\/\/twitter.com\/StuartJRitchie\/status\/742992778595082240",
      "display_url" : "twitter.com\/StuartJRitchie\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "743074605712211968",
  "text" : "That\u2019s why I like to use open(.*) in my Twitter biography. \uD83D\uDC49\uD83C\uDF69\uD83D\uDC48 https:\/\/t.co\/ppfVD6CrLT",
  "id" : 743074605712211968,
  "created_at" : "2016-06-15 13:36:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Cock",
      "screen_name" : "pjacock",
      "indices" : [ 0, 8 ],
      "id_str" : "58756672",
      "id" : 58756672
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "743070868209868800",
  "geo" : { },
  "id_str" : "743072086382510080",
  "in_reply_to_user_id" : 58756672,
  "text" : "@pjacock in both cases the blocked time in the calendar is the same. But Apple correctly gives the diverging TZ of departure\/arrival.",
  "id" : 743072086382510080,
  "in_reply_to_status_id" : 743070868209868800,
  "created_at" : "2016-06-15 13:26:05 +0000",
  "in_reply_to_screen_name" : "pjacock",
  "in_reply_to_user_id_str" : "58756672",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Cock",
      "screen_name" : "pjacock",
      "indices" : [ 0, 8 ],
      "id_str" : "58756672",
      "id" : 58756672
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/743071709729804288\/photo\/1",
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/6EZO8TFNt3",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ck_rxx2XIAAoawU.jpg",
      "id_str" : "743071703966883840",
      "id" : 743071703966883840,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ck_rxx2XIAAoawU.jpg",
      "sizes" : [ {
        "h" : 133,
        "resize" : "fit",
        "w" : 281
      }, {
        "h" : 133,
        "resize" : "crop",
        "w" : 133
      }, {
        "h" : 133,
        "resize" : "fit",
        "w" : 281
      }, {
        "h" : 133,
        "resize" : "fit",
        "w" : 281
      }, {
        "h" : 133,
        "resize" : "fit",
        "w" : 281
      } ],
      "display_url" : "pic.twitter.com\/6EZO8TFNt3"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/743071709729804288\/photo\/1",
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/6EZO8TFNt3",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ck_rx_pWYAAxtUO.jpg",
      "id_str" : "743071707670405120",
      "id" : 743071707670405120,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ck_rx_pWYAAxtUO.jpg",
      "sizes" : [ {
        "h" : 241,
        "resize" : "fit",
        "w" : 277
      }, {
        "h" : 241,
        "resize" : "fit",
        "w" : 277
      }, {
        "h" : 241,
        "resize" : "fit",
        "w" : 277
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 241,
        "resize" : "fit",
        "w" : 277
      } ],
      "display_url" : "pic.twitter.com\/6EZO8TFNt3"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "743070868209868800",
  "geo" : { },
  "id_str" : "743071709729804288",
  "in_reply_to_user_id" : 58756672,
  "text" : "@pjacock interestingly Apple seems to have a better grip at extracting from the inbox, c.f. those. https:\/\/t.co\/6EZO8TFNt3",
  "id" : 743071709729804288,
  "in_reply_to_status_id" : 743070868209868800,
  "created_at" : "2016-06-15 13:24:35 +0000",
  "in_reply_to_screen_name" : "pjacock",
  "in_reply_to_user_id_str" : "58756672",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Cock",
      "screen_name" : "pjacock",
      "indices" : [ 0, 8 ],
      "id_str" : "58756672",
      "id" : 58756672
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "743070487446708224",
  "geo" : { },
  "id_str" : "743070660725989376",
  "in_reply_to_user_id" : 58756672,
  "text" : "@pjacock I started just adding all events in the respective TZ, so that they will be shown \u201Ecorrect\u201C relative to local time when arriving.",
  "id" : 743070660725989376,
  "in_reply_to_status_id" : 743070487446708224,
  "created_at" : "2016-06-15 13:20:25 +0000",
  "in_reply_to_screen_name" : "pjacock",
  "in_reply_to_user_id_str" : "58756672",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Cock",
      "screen_name" : "pjacock",
      "indices" : [ 0, 8 ],
      "id_str" : "58756672",
      "id" : 58756672
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "743069945374900224",
  "geo" : { },
  "id_str" : "743070207061659648",
  "in_reply_to_user_id" : 58756672,
  "text" : "@pjacock I did, the layover times seem to fit. Even when crossing the IDL from West to East.",
  "id" : 743070207061659648,
  "in_reply_to_status_id" : 743069945374900224,
  "created_at" : "2016-06-15 13:18:37 +0000",
  "in_reply_to_screen_name" : "pjacock",
  "in_reply_to_user_id_str" : "58756672",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "743069500225028097",
  "text" : "I \uD83D\uDC96 the automatic addition of \u2708\uFE0F from my \uD83D\uDCE5 to Google \uD83D\uDCC5, especially that all TZ magic is handled.",
  "id" : 743069500225028097,
  "created_at" : "2016-06-15 13:15:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "743056636286242817",
  "geo" : { },
  "id_str" : "743059217746120704",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot usually disaster just happens after I booked my flights\/are already at the airport. My \uD83D\uDD2E-skills are great!",
  "id" : 743059217746120704,
  "in_reply_to_status_id" : 743056636286242817,
  "created_at" : "2016-06-15 12:34:57 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emily G, Cville.",
      "screen_name" : "EmilyGorcenski",
      "indices" : [ 0, 15 ],
      "id_str" : "1483064670",
      "id" : 1483064670
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "742855660426137601",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06092320490151, 8.81857669404968 ]
  },
  "id_str" : "742855812373196801",
  "in_reply_to_user_id" : 1483064670,
  "text" : "@EmilyGorcenski no, but I wondered whether there\u2019s any language that has iff implemented like this.",
  "id" : 742855812373196801,
  "in_reply_to_status_id" : 742855660426137601,
  "created_at" : "2016-06-14 23:06:41 +0000",
  "in_reply_to_screen_name" : "EmilyGorcenski",
  "in_reply_to_user_id_str" : "1483064670",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emily G, Cville.",
      "screen_name" : "EmilyGorcenski",
      "indices" : [ 0, 15 ],
      "id_str" : "1483064670",
      "id" : 1483064670
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "742807256467640320",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06082814735656, 8.81855401221552 ]
  },
  "id_str" : "742854759288311808",
  "in_reply_to_user_id" : 1483064670,
  "text" : "@EmilyGorcenski iff :p",
  "id" : 742854759288311808,
  "in_reply_to_status_id" : 742807256467640320,
  "created_at" : "2016-06-14 23:02:30 +0000",
  "in_reply_to_screen_name" : "EmilyGorcenski",
  "in_reply_to_user_id_str" : "1483064670",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06088699829719, 8.818361836565597 ]
  },
  "id_str" : "742853417295564801",
  "text" : "Re-watching a bit of The West Wing Season 1 these days. With timeless topics as the assault rifle ban and LGBTQ-directed hate crimes\u2026",
  "id" : 742853417295564801,
  "created_at" : "2016-06-14 22:57:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charles Bergquist",
      "screen_name" : "cbquist",
      "indices" : [ 3, 11 ],
      "id_str" : "16785742",
      "id" : 16785742
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "742734761211355136",
  "text" : "RT @cbquist: Today's the birthday (1856) of Andrey \"The Chain\"  Markov. Engage in some stochastic processes today in his honor. https:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/cbquist\/status\/742711816569126913\/photo\/1",
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/ERtK2GRMdm",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Ck6kdWzWgAAA2e3.jpg",
        "id_str" : "742711812806836224",
        "id" : 742711812806836224,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ck6kdWzWgAAA2e3.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 599,
          "resize" : "fit",
          "w" : 405
        }, {
          "h" : 599,
          "resize" : "fit",
          "w" : 405
        }, {
          "h" : 599,
          "resize" : "fit",
          "w" : 405
        }, {
          "h" : 599,
          "resize" : "fit",
          "w" : 405
        } ],
        "display_url" : "pic.twitter.com\/ERtK2GRMdm"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "742711816569126913",
    "text" : "Today's the birthday (1856) of Andrey \"The Chain\"  Markov. Engage in some stochastic processes today in his honor. https:\/\/t.co\/ERtK2GRMdm",
    "id" : 742711816569126913,
    "created_at" : "2016-06-14 13:34:30 +0000",
    "user" : {
      "name" : "Charles Bergquist",
      "screen_name" : "cbquist",
      "protected" : false,
      "id_str" : "16785742",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/562454709261172738\/OrQrpDJe_normal.jpeg",
      "id" : 16785742,
      "verified" : true
    }
  },
  "id" : 742734761211355136,
  "created_at" : "2016-06-14 15:05:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 51 ],
      "url" : "https:\/\/t.co\/tUfUMAAsjq",
      "expanded_url" : "https:\/\/twitter.com\/o_guest\/status\/742719015559254016",
      "display_url" : "twitter.com\/o_guest\/status\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723578841105, 8.627609140200725 ]
  },
  "id_str" : "742722739639848960",
  "text" : "This hits so close to home. https:\/\/t.co\/tUfUMAAsjq",
  "id" : 742722739639848960,
  "created_at" : "2016-06-14 14:17:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 44 ],
      "url" : "https:\/\/t.co\/egDABedI8S",
      "expanded_url" : "http:\/\/boingboing.net\/2016\/06\/14\/tom-the-dancing-bug-the-powe.html",
      "display_url" : "boingboing.net\/2016\/06\/14\/tom\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "742706921694728192",
  "text" : "thoughts and prayers https:\/\/t.co\/egDABedI8S",
  "id" : 742706921694728192,
  "created_at" : "2016-06-14 13:15:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Blin",
      "screen_name" : "kaiblin",
      "indices" : [ 0, 8 ],
      "id_str" : "124202458",
      "id" : 124202458
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "742704846239870976",
  "geo" : { },
  "id_str" : "742705237136429056",
  "in_reply_to_user_id" : 124202458,
  "text" : "@kaiblin don\u2019t discount the influence of the microbiome!",
  "id" : 742705237136429056,
  "in_reply_to_status_id" : 742704846239870976,
  "created_at" : "2016-06-14 13:08:21 +0000",
  "in_reply_to_screen_name" : "kaiblin",
  "in_reply_to_user_id_str" : "124202458",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nils M\u00FCller",
      "screen_name" : "Weltenkreuzer",
      "indices" : [ 0, 14 ],
      "id_str" : "8568942",
      "id" : 8568942
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "742683843220672512",
  "geo" : { },
  "id_str" : "742684782048481283",
  "in_reply_to_user_id" : 8568942,
  "text" : "@Weltenkreuzer Im Rhein-Main-Gebiet ist es f\u00FCr ziemlich viele Verbindungen schneller &amp; billiger das Auto zu nehmen statt die Bahnen.",
  "id" : 742684782048481283,
  "in_reply_to_status_id" : 742683843220672512,
  "created_at" : "2016-06-14 11:47:05 +0000",
  "in_reply_to_screen_name" : "Weltenkreuzer",
  "in_reply_to_user_id_str" : "8568942",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robin N. Kok",
      "screen_name" : "robinnkok",
      "indices" : [ 0, 10 ],
      "id_str" : "4841450680",
      "id" : 4841450680
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "742683931397492736",
  "geo" : { },
  "id_str" : "742684458902507520",
  "in_reply_to_user_id" : 4841450680,
  "text" : "@robinnkok i heard great things about the Dutch \uD83D\uDE82 too! My experience with DB is very similar to yours\u2026",
  "id" : 742684458902507520,
  "in_reply_to_status_id" : 742683931397492736,
  "created_at" : "2016-06-14 11:45:48 +0000",
  "in_reply_to_screen_name" : "robinnkok",
  "in_reply_to_user_id_str" : "4841450680",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/N8EjI4eZya",
      "expanded_url" : "https:\/\/twitter.com\/The_Smoking_GNU\/status\/742644515681533952",
      "display_url" : "twitter.com\/The_Smoking_GN\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "742682891310792706",
  "text" : "On the sorry state of public transport around here, where taking \uD83D\uDE99 or \u2708\uFE0F beats \uD83D\uDE82 virtually in all cases\u2026 https:\/\/t.co\/N8EjI4eZya",
  "id" : 742682891310792706,
  "created_at" : "2016-06-14 11:39:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andr\u00E9 Golliez",
      "screen_name" : "golliez",
      "indices" : [ 0, 8 ],
      "id_str" : "156177618",
      "id" : 156177618
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "opendatach",
      "indices" : [ 29, 40 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "742630447079907329",
  "geo" : { },
  "id_str" : "742656632291753984",
  "in_reply_to_user_id" : 156177618,
  "text" : "@golliez sounds like a great #opendatach in general! Nice follow it from here!",
  "id" : 742656632291753984,
  "in_reply_to_status_id" : 742630447079907329,
  "created_at" : "2016-06-14 09:55:13 +0000",
  "in_reply_to_screen_name" : "golliez",
  "in_reply_to_user_id_str" : "156177618",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul-Olivier Dehaye",
      "screen_name" : "podehaye",
      "indices" : [ 0, 9 ],
      "id_str" : "2219841242",
      "id" : 2219841242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "742655734417096704",
  "geo" : { },
  "id_str" : "742655799424655360",
  "in_reply_to_user_id" : 2219841242,
  "text" : "@podehaye yes, but that\u2019s closeish when compared to driving down from Frankfurt for just a day :p",
  "id" : 742655799424655360,
  "in_reply_to_status_id" : 742655734417096704,
  "created_at" : "2016-06-14 09:51:55 +0000",
  "in_reply_to_screen_name" : "podehaye",
  "in_reply_to_user_id_str" : "2219841242",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul-Olivier Dehaye",
      "screen_name" : "podehaye",
      "indices" : [ 0, 9 ],
      "id_str" : "2219841242",
      "id" : 2219841242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "742655366731837440",
  "geo" : { },
  "id_str" : "742655585750024192",
  "in_reply_to_user_id" : 2219841242,
  "text" : "@podehaye just drove from Zurich to Frankfurt this morning. Well, maybe next time.",
  "id" : 742655585750024192,
  "in_reply_to_status_id" : 742655366731837440,
  "created_at" : "2016-06-14 09:51:04 +0000",
  "in_reply_to_screen_name" : "podehaye",
  "in_reply_to_user_id_str" : "2219841242",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul-Olivier Dehaye",
      "screen_name" : "podehaye",
      "indices" : [ 0, 9 ],
      "id_str" : "2219841242",
      "id" : 2219841242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "742627606403633152",
  "geo" : { },
  "id_str" : "742654695840354304",
  "in_reply_to_user_id" : 2219841242,
  "text" : "@podehaye oh no, and i was so close. Wish I had known this earlier!",
  "id" : 742654695840354304,
  "in_reply_to_status_id" : 742627606403633152,
  "created_at" : "2016-06-14 09:47:32 +0000",
  "in_reply_to_screen_name" : "podehaye",
  "in_reply_to_user_id_str" : "2219841242",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bede Constantinides",
      "screen_name" : "beconstant",
      "indices" : [ 0, 11 ],
      "id_str" : "112876914",
      "id" : 112876914
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "742651684975960064",
  "geo" : { },
  "id_str" : "742651849317191680",
  "in_reply_to_user_id" : 112876914,
  "text" : "@beconstant seeing phenotype correlations could be even more fun ;)",
  "id" : 742651849317191680,
  "in_reply_to_status_id" : 742651684975960064,
  "created_at" : "2016-06-14 09:36:13 +0000",
  "in_reply_to_screen_name" : "beconstant",
  "in_reply_to_user_id_str" : "112876914",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mathias Schindler",
      "screen_name" : "presroi",
      "indices" : [ 0, 8 ],
      "id_str" : "20447568",
      "id" : 20447568
    }, {
      "name" : "Richard Poynder",
      "screen_name" : "RickyPo",
      "indices" : [ 9, 17 ],
      "id_str" : "20298671",
      "id" : 20298671
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "742631080516325376",
  "geo" : { },
  "id_str" : "742648756751962112",
  "in_reply_to_user_id" : 20447568,
  "text" : "@presroi @RickyPo thx!",
  "id" : 742648756751962112,
  "in_reply_to_status_id" : 742631080516325376,
  "created_at" : "2016-06-14 09:23:56 +0000",
  "in_reply_to_screen_name" : "presroi",
  "in_reply_to_user_id_str" : "20447568",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/nrYZA18hoe",
      "expanded_url" : "https:\/\/twitter.com\/RickyPo\/status\/742630044187648000",
      "display_url" : "twitter.com\/RickyPo\/status\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "742648735298138112",
  "text" : "I wouldn\u2019t have thought that Myriad Genetics could sink even lower, but they just keep digging\u2026 https:\/\/t.co\/nrYZA18hoe",
  "id" : 742648735298138112,
  "created_at" : "2016-06-14 09:23:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/742647247620427776\/photo\/1",
      "indices" : [ 60, 83 ],
      "url" : "https:\/\/t.co\/Dfcw5kYqj2",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ck5pu6fWEAAt_4y.jpg",
      "id_str" : "742647243258335232",
      "id" : 742647243258335232,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ck5pu6fWEAAt_4y.jpg",
      "sizes" : [ {
        "h" : 1136,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 1136,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 383
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1136,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/Dfcw5kYqj2"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17242668460187, 8.627560657753248 ]
  },
  "id_str" : "742647247620427776",
  "text" : "Always wondered when I would see this phenotype on openSNP. https:\/\/t.co\/Dfcw5kYqj2",
  "id" : 742647247620427776,
  "created_at" : "2016-06-14 09:17:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35925583275444, 8.587698091818082 ]
  },
  "id_str" : "742454753242808320",
  "text" : "\u00ABI like how you talk to your computer while you\u2019re working. But I think \u2018interrogating the data\u2019 wasn\u2019t mean in that way.\u00BB",
  "id" : 742454753242808320,
  "created_at" : "2016-06-13 20:33:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/W6ouOcIFPN",
      "expanded_url" : "http:\/\/www.mycheckpoint.ch",
      "display_url" : "mycheckpoint.ch"
    } ]
  },
  "in_reply_to_status_id_str" : "741693218354520068",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35524731159195, 8.58607483655714 ]
  },
  "id_str" : "742415552522620928",
  "in_reply_to_user_id" : 14286491,
  "text" : "And now the second half of the result is in. No HIV either. Great job you did over the weekend, https:\/\/t.co\/W6ouOcIFPN",
  "id" : 742415552522620928,
  "in_reply_to_status_id" : 741693218354520068,
  "created_at" : "2016-06-13 17:57:15 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 51 ],
      "url" : "https:\/\/t.co\/aRW3SO3Nep",
      "expanded_url" : "https:\/\/twitter.com\/myrmoteras\/status\/742252677669720064",
      "display_url" : "twitter.com\/myrmoteras\/sta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "742316277897830400",
  "text" : "Share now, for just $39.95! https:\/\/t.co\/aRW3SO3Nep",
  "id" : 742316277897830400,
  "created_at" : "2016-06-13 11:22:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/a5CiRevTZl",
      "expanded_url" : "https:\/\/twitter.com\/PhilippBayer\/status\/742180240558985218",
      "display_url" : "twitter.com\/PhilippBayer\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "742297770149679106",
  "text" : "\u00AB\u2026been bitten only 11 times when I (mostly) deserved it.\u00BB I can\u2019t wait to get to Australia! https:\/\/t.co\/a5CiRevTZl",
  "id" : 742297770149679106,
  "created_at" : "2016-06-13 10:09:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Silberman",
      "screen_name" : "stevesilberman",
      "indices" : [ 3, 18 ],
      "id_str" : "18655567",
      "id" : 18655567
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/stevesilberman\/status\/741820956419588096\/photo\/1",
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/Y6DQOLSOrK",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ckt6OhdUoAArF3I.jpg",
      "id_str" : "741820953550692352",
      "id" : 741820953550692352,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ckt6OhdUoAArF3I.jpg",
      "sizes" : [ {
        "h" : 530,
        "resize" : "fit",
        "w" : 694
      }, {
        "h" : 530,
        "resize" : "fit",
        "w" : 694
      }, {
        "h" : 530,
        "resize" : "fit",
        "w" : 694
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 519,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/Y6DQOLSOrK"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 69 ],
      "url" : "https:\/\/t.co\/WvFGmnvnoU",
      "expanded_url" : "https:\/\/www.facebook.com\/startrekmemesdb\/photos\/a.492453107555246.1073741826.492428670891023\/824292507704636\/?type=3&theater",
      "display_url" : "facebook.com\/startrekmemesd\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "741904171893436416",
  "text" : "RT @stevesilberman: Best Star Trek meme ever. https:\/\/t.co\/WvFGmnvnoU https:\/\/t.co\/Y6DQOLSOrK",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/stevesilberman\/status\/741820956419588096\/photo\/1",
        "indices" : [ 50, 73 ],
        "url" : "https:\/\/t.co\/Y6DQOLSOrK",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Ckt6OhdUoAArF3I.jpg",
        "id_str" : "741820953550692352",
        "id" : 741820953550692352,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ckt6OhdUoAArF3I.jpg",
        "sizes" : [ {
          "h" : 530,
          "resize" : "fit",
          "w" : 694
        }, {
          "h" : 530,
          "resize" : "fit",
          "w" : 694
        }, {
          "h" : 530,
          "resize" : "fit",
          "w" : 694
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 519,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/Y6DQOLSOrK"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 26, 49 ],
        "url" : "https:\/\/t.co\/WvFGmnvnoU",
        "expanded_url" : "https:\/\/www.facebook.com\/startrekmemesdb\/photos\/a.492453107555246.1073741826.492428670891023\/824292507704636\/?type=3&theater",
        "display_url" : "facebook.com\/startrekmemesd\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "741820956419588096",
    "text" : "Best Star Trek meme ever. https:\/\/t.co\/WvFGmnvnoU https:\/\/t.co\/Y6DQOLSOrK",
    "id" : 741820956419588096,
    "created_at" : "2016-06-12 02:34:33 +0000",
    "user" : {
      "name" : "Steve Silberman",
      "screen_name" : "stevesilberman",
      "protected" : false,
      "id_str" : "18655567",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/801317729978449920\/1ZDKwlMv_normal.jpg",
      "id" : 18655567,
      "verified" : true
    }
  },
  "id" : 741904171893436416,
  "created_at" : "2016-06-12 08:05:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "741783407055667200",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.3593708338576, 8.587833233757353 ]
  },
  "id_str" : "741900167335579648",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez \uD83D\uDC96\uD83D\uDE0D\uD83C\uDF89",
  "id" : 741900167335579648,
  "in_reply_to_status_id" : 741783407055667200,
  "created_at" : "2016-06-12 07:49:18 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 90 ],
      "url" : "https:\/\/t.co\/g2NQVZ4qR9",
      "expanded_url" : "https:\/\/twitter.com\/susanorlean\/status\/741657212372713472",
      "display_url" : "twitter.com\/susanorlean\/st\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.3591476191716, 8.58778862219599 ]
  },
  "id_str" : "741898179998846977",
  "text" : "\u00ABNow all we need to know is, what\u2019s next to go? The question mark\u00BB https:\/\/t.co\/g2NQVZ4qR9",
  "id" : 741898179998846977,
  "created_at" : "2016-06-12 07:41:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u24EA Rik Smith-Unna \uD83C\uDDF0\uD83C\uDDEA",
      "screen_name" : "blahah404",
      "indices" : [ 0, 10 ],
      "id_str" : "99173786",
      "id" : 99173786
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "741700999954485248",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35927710314617, 8.587810940702408 ]
  },
  "id_str" : "741725103810056192",
  "in_reply_to_user_id" : 99173786,
  "text" : "@blahah404 always good to advertise your own benefits openly?",
  "id" : 741725103810056192,
  "in_reply_to_status_id" : 741700999954485248,
  "created_at" : "2016-06-11 20:13:39 +0000",
  "in_reply_to_screen_name" : "blahah404",
  "in_reply_to_user_id_str" : "99173786",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/741693218354520068\/photo\/1",
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/dsyosZzqZR",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CksGCctWkAA_PNm.jpg",
      "id_str" : "741693202768498688",
      "id" : 741693202768498688,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CksGCctWkAA_PNm.jpg",
      "sizes" : [ {
        "h" : 4032,
        "resize" : "fit",
        "w" : 3024
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      } ],
      "display_url" : "pic.twitter.com\/dsyosZzqZR"
    } ],
    "hashtags" : [ {
      "text" : "zurichpride",
      "indices" : [ 22, 34 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35920932779269, 8.587748601421325 ]
  },
  "id_str" : "741693218354520068",
  "text" : "Free STD tests at the #zurichpride. Guess who doesn\u2019t have syphilis! \uD83C\uDF89\uD83D\uDC4D https:\/\/t.co\/dsyosZzqZR",
  "id" : 741693218354520068,
  "created_at" : "2016-06-11 18:06:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "zurichpride",
      "indices" : [ 29, 41 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.37618076802936, 8.53122803107318 ]
  },
  "id_str" : "741640201441841152",
  "text" : "Peak Pride: Uber joining the #zurichpride.",
  "id" : 741640201441841152,
  "created_at" : "2016-06-11 14:36:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Egle Ramanauskaite \u2623",
      "screen_name" : "Seplute",
      "indices" : [ 0, 8 ],
      "id_str" : "188833865",
      "id" : 188833865
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "741589130639998976",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35917891957831, 8.58777921492575 ]
  },
  "id_str" : "741590918810193921",
  "in_reply_to_user_id" : 188833865,
  "text" : "@Seplute those are fun. Try splashing some water onto the cups as described in Wikipedia!",
  "id" : 741590918810193921,
  "in_reply_to_status_id" : 741589130639998976,
  "created_at" : "2016-06-11 11:20:27 +0000",
  "in_reply_to_screen_name" : "Seplute",
  "in_reply_to_user_id_str" : "188833865",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Egle Ramanauskaite \u2623",
      "screen_name" : "Seplute",
      "indices" : [ 0, 8 ],
      "id_str" : "188833865",
      "id" : 188833865
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "741572380720562176",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35918760509018, 8.587784992987077 ]
  },
  "id_str" : "741586025991016448",
  "in_reply_to_user_id" : 188833865,
  "text" : "@Seplute which is a fungus that disperses its spores by explosively ejecting those white-ish packages inside the nest.",
  "id" : 741586025991016448,
  "in_reply_to_status_id" : 741572380720562176,
  "created_at" : "2016-06-11 11:01:01 +0000",
  "in_reply_to_screen_name" : "Seplute",
  "in_reply_to_user_id_str" : "188833865",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Egle Ramanauskaite \u2623",
      "screen_name" : "Seplute",
      "indices" : [ 0, 8 ],
      "id_str" : "188833865",
      "id" : 188833865
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 92 ],
      "url" : "https:\/\/t.co\/9xNTFllyXn",
      "expanded_url" : "https:\/\/en.m.wikipedia.org\/wiki\/Cyathus_striatus",
      "display_url" : "en.m.wikipedia.org\/wiki\/Cyathus_s\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "741572380720562176",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35924321056745, 8.587831141409874 ]
  },
  "id_str" : "741585850392281088",
  "in_reply_to_user_id" : 188833865,
  "text" : "@Seplute I don\u2019t think so, could be something like Cyathus striatus. https:\/\/t.co\/9xNTFllyXn",
  "id" : 741585850392281088,
  "in_reply_to_status_id" : 741572380720562176,
  "created_at" : "2016-06-11 11:00:19 +0000",
  "in_reply_to_screen_name" : "Seplute",
  "in_reply_to_user_id_str" : "188833865",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35923846062121, 8.5878333505232 ]
  },
  "id_str" : "741431734978420736",
  "text" : "\u00ABI tried scratching you, biting you, putting needles into you. But now I finally know what hurts you: seeing 3D pie charts!\u00BB",
  "id" : 741431734978420736,
  "created_at" : "2016-06-11 00:47:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.36181047283799, 8.597532073043842 ]
  },
  "id_str" : "741327503214686209",
  "text" : "Correctly guesstimated my arrival time, down to the minute. Time to read Twitter, so I can show up late and counter the German stereotypes.",
  "id" : 741327503214686209,
  "created_at" : "2016-06-10 17:53:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 92 ],
      "url" : "https:\/\/t.co\/8Qhv5BVaP5",
      "expanded_url" : "http:\/\/www.theguardian.com\/environment\/2016\/jun\/09\/co2-turned-into-stone-in-iceland-in-climate-change-breakthrough?CMP=Share_iOSApp_Other",
      "display_url" : "theguardian.com\/environment\/20\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "741242458131058688",
  "text" : "Wow: CO2 turned into stone in Iceland in climate change breakthrough https:\/\/t.co\/8Qhv5BVaP5",
  "id" : 741242458131058688,
  "created_at" : "2016-06-10 12:15:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "741234920287178752",
  "geo" : { },
  "id_str" : "741235300953886721",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer guess you were more of the stereotypical diploma student wrt partying. Did my short but intense political career instead :D",
  "id" : 741235300953886721,
  "in_reply_to_status_id" : 741234920287178752,
  "created_at" : "2016-06-10 11:47:21 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/eby8XpU8af",
      "expanded_url" : "https:\/\/twitter.com\/PhilippBayer\/status\/741160221435957248",
      "display_url" : "twitter.com\/PhilippBayer\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "741231141206822912",
  "text" : "This, so much. For me this even lasted until the last year of doing my undergrad. https:\/\/t.co\/eby8XpU8af",
  "id" : 741231141206822912,
  "created_at" : "2016-06-10 11:30:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael R. Crusoe",
      "screen_name" : "biocrusoe",
      "indices" : [ 0, 10 ],
      "id_str" : "17645638",
      "id" : 17645638
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "741035390866456576",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06095690543306, 8.818591731383766 ]
  },
  "id_str" : "741036577162469376",
  "in_reply_to_user_id" : 17645638,
  "text" : "@biocrusoe I\u2019m happy about the small QueerFeministGeek village we had at last years camp to somewhat counteract\u2026",
  "id" : 741036577162469376,
  "in_reply_to_status_id" : 741035390866456576,
  "created_at" : "2016-06-09 22:37:42 +0000",
  "in_reply_to_screen_name" : "biocrusoe",
  "in_reply_to_user_id_str" : "17645638",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael R. Crusoe",
      "screen_name" : "biocrusoe",
      "indices" : [ 0, 10 ],
      "id_str" : "17645638",
      "id" : 17645638
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "741035390866456576",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06095690543306, 8.818591731383766 ]
  },
  "id_str" : "741036383918272512",
  "in_reply_to_user_id" : 17645638,
  "text" : "@biocrusoe it\u2019s sadly really not too surprising. The community at large somehow doesn\u2019t seem to care.",
  "id" : 741036383918272512,
  "in_reply_to_status_id" : 741035390866456576,
  "created_at" : "2016-06-09 22:36:56 +0000",
  "in_reply_to_screen_name" : "biocrusoe",
  "in_reply_to_user_id_str" : "17645638",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/yPRSYuYUsl",
      "expanded_url" : "https:\/\/twitter.com\/DiaKayyali\/status\/741024565032325120",
      "display_url" : "twitter.com\/DiaKayyali\/sta\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06100999858775, 8.818575401011119 ]
  },
  "id_str" : "741034381842731008",
  "text" : "The German hacking scene, showing how to not take a clear stand against rape. Disappointing as expected\u2026 https:\/\/t.co\/yPRSYuYUsl",
  "id" : 741034381842731008,
  "created_at" : "2016-06-09 22:28:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/OzKR38IqSo",
      "expanded_url" : "https:\/\/twitter.com\/PhilippBayer\/status\/740894169258819584",
      "display_url" : "twitter.com\/PhilippBayer\/s\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06075107689916, 8.81852590330718 ]
  },
  "id_str" : "740945272302358528",
  "text" : "Not better or worse than most \u2018trees\u2019 used for supporting HGT events.  \u00AF\\_(\u30C4)_\/\u00AF https:\/\/t.co\/OzKR38IqSo",
  "id" : 740945272302358528,
  "created_at" : "2016-06-09 16:34:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 66 ],
      "url" : "https:\/\/t.co\/4g9TLipknK",
      "expanded_url" : "https:\/\/twitter.com\/OBF_BOSC\/status\/740617126734487552",
      "display_url" : "twitter.com\/OBF_BOSC\/statu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "740907806455402496",
  "text" : "Looking forward to meet many of you there! https:\/\/t.co\/4g9TLipknK",
  "id" : 740907806455402496,
  "created_at" : "2016-06-09 14:06:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Beth \uD83D\uDC3A",
      "screen_name" : "PhdGeek",
      "indices" : [ 0, 8 ],
      "id_str" : "27841081",
      "id" : 27841081
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "740828244895793152",
  "geo" : { },
  "id_str" : "740840508885499904",
  "in_reply_to_user_id" : 27841081,
  "text" : "@PhdGeek that\u2019s like joining two of the coolest careers! \uD83D\uDE0D",
  "id" : 740840508885499904,
  "in_reply_to_status_id" : 740828244895793152,
  "created_at" : "2016-06-09 09:38:36 +0000",
  "in_reply_to_screen_name" : "PhdGeek",
  "in_reply_to_user_id_str" : "27841081",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "740817813837910017",
  "geo" : { },
  "id_str" : "740818123574661121",
  "in_reply_to_user_id" : 14286491,
  "text" : "Sure, let\u2019s stop this. But only after I published these 3 organelle papers\u2026",
  "id" : 740818123574661121,
  "in_reply_to_status_id" : 740817813837910017,
  "created_at" : "2016-06-09 08:09:39 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/okoR29DudH",
      "expanded_url" : "http:\/\/bfg.oxfordjournals.org\/content\/15\/1\/47",
      "display_url" : "bfg.oxfordjournals.org\/content\/15\/1\/47"
    } ]
  },
  "geo" : { },
  "id_str" : "740817813837910017",
  "text" : "\u00ABIs it time to acknowledge that as a research community we have published enough mitochondrial genome papers? \u00BB https:\/\/t.co\/okoR29DudH",
  "id" : 740817813837910017,
  "created_at" : "2016-06-09 08:08:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06092679225845, 8.818515082829462 ]
  },
  "id_str" : "740660703149891584",
  "text" : "My first reaction when a friend told me she had formalized \u2018love\u2019 and plotted her results: \u2018Oh, nice, is that ggplot?\u2019",
  "id" : 740660703149891584,
  "created_at" : "2016-06-08 21:44:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/5SWL1mmGnw",
      "expanded_url" : "https:\/\/twitter.com\/auremoser\/status\/740610772158537728",
      "display_url" : "twitter.com\/auremoser\/stat\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06091246698102, 8.818738977881443 ]
  },
  "id_str" : "740635341825159168",
  "text" : "I want to do this too. Should start doing an app for collecting the data easily. \uD83D\uDE22\u2708\uFE0F https:\/\/t.co\/5SWL1mmGnw",
  "id" : 740635341825159168,
  "created_at" : "2016-06-08 20:03:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Blin",
      "screen_name" : "kaiblin",
      "indices" : [ 0, 8 ],
      "id_str" : "124202458",
      "id" : 124202458
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "740464360640937984",
  "geo" : { },
  "id_str" : "740520638968958976",
  "in_reply_to_user_id" : 124202458,
  "text" : "@kaiblin thanks \uD83D\uDC4D",
  "id" : 740520638968958976,
  "in_reply_to_status_id" : 740464360640937984,
  "created_at" : "2016-06-08 12:27:33 +0000",
  "in_reply_to_screen_name" : "kaiblin",
  "in_reply_to_user_id_str" : "124202458",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elio Qoshi",
      "screen_name" : "elioqoshi",
      "indices" : [ 68, 78 ],
      "id_str" : "93434375",
      "id" : 93434375
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/ZOxhf6oQTY",
      "expanded_url" : "https:\/\/www.patreon.com\/openSNP?ty=h",
      "display_url" : "patreon.com\/openSNP?ty=h"
    } ]
  },
  "geo" : { },
  "id_str" : "740498447070035968",
  "text" : "We also got a new banner for our openSNP Patreon campaign thanks to @elioqoshi! https:\/\/t.co\/ZOxhf6oQTY",
  "id" : 740498447070035968,
  "created_at" : "2016-06-08 10:59:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elio Qoshi",
      "screen_name" : "elioqoshi",
      "indices" : [ 0, 10 ],
      "id_str" : "93434375",
      "id" : 93434375
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "740493086627893248",
  "geo" : { },
  "id_str" : "740498045033447424",
  "in_reply_to_user_id" : 93434375,
  "text" : "@elioqoshi great, thanks so much!",
  "id" : 740498045033447424,
  "in_reply_to_status_id" : 740493086627893248,
  "created_at" : "2016-06-08 10:57:46 +0000",
  "in_reply_to_screen_name" : "elioqoshi",
  "in_reply_to_user_id_str" : "93434375",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elio Qoshi",
      "screen_name" : "elioqoshi",
      "indices" : [ 0, 10 ],
      "id_str" : "93434375",
      "id" : 93434375
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "740477515546959872",
  "geo" : { },
  "id_str" : "740485269007302656",
  "in_reply_to_user_id" : 93434375,
  "text" : "@elioqoshi thanks, could you change it to openSNP? We decided to chip in with the project instead :)",
  "id" : 740485269007302656,
  "in_reply_to_status_id" : 740477515546959872,
  "created_at" : "2016-06-08 10:07:00 +0000",
  "in_reply_to_screen_name" : "elioqoshi",
  "in_reply_to_user_id_str" : "93434375",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elio Qoshi",
      "screen_name" : "elioqoshi",
      "indices" : [ 0, 10 ],
      "id_str" : "93434375",
      "id" : 93434375
    }, {
      "name" : "ura old",
      "screen_name" : "uraworks",
      "indices" : [ 11, 20 ],
      "id_str" : "756103023278092288",
      "id" : 756103023278092288
    }, {
      "name" : "Patreon",
      "screen_name" : "Patreon",
      "indices" : [ 21, 29 ],
      "id_str" : "1228325660",
      "id" : 1228325660
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "740467766646460416",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17242784551961, 8.627458810475868 ]
  },
  "id_str" : "740468588822335489",
  "in_reply_to_user_id" : 93434375,
  "text" : "@elioqoshi @uraworks @Patreon don\u2019t stress yourself about it. All the best for your campaign!",
  "id" : 740468588822335489,
  "in_reply_to_status_id" : 740467766646460416,
  "created_at" : "2016-06-08 09:00:43 +0000",
  "in_reply_to_screen_name" : "elioqoshi",
  "in_reply_to_user_id_str" : "93434375",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ura old",
      "screen_name" : "uraworks",
      "indices" : [ 0, 9 ],
      "id_str" : "756103023278092288",
      "id" : 756103023278092288
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 69 ],
      "url" : "https:\/\/t.co\/ZOxhf6oQTY",
      "expanded_url" : "https:\/\/www.patreon.com\/openSNP?ty=h",
      "display_url" : "patreon.com\/openSNP?ty=h"
    } ]
  },
  "in_reply_to_status_id_str" : "740466821640380416",
  "geo" : { },
  "id_str" : "740467286331543552",
  "in_reply_to_user_id" : 736915438345588736,
  "text" : "@uraworks we\u2019re also on Patreon by the way :p https:\/\/t.co\/ZOxhf6oQTY",
  "id" : 740467286331543552,
  "in_reply_to_status_id" : 740466821640380416,
  "created_at" : "2016-06-08 08:55:32 +0000",
  "in_reply_to_screen_name" : "uracreative",
  "in_reply_to_user_id_str" : "736915438345588736",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leigh Janet Mactavish Honeywell",
      "screen_name" : "hypatiadotca",
      "indices" : [ 3, 16 ],
      "id_str" : "6742522",
      "id" : 6742522
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/zZqI37eiFW",
      "expanded_url" : "http:\/\/hypatia.ca\/2016\/06\/07\/he-said-they-said",
      "display_url" : "hypatia.ca\/2016\/06\/07\/he-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "740436630138392576",
  "text" : "RT @hypatiadotca: \"He said, they said\" - I wrote about what it was like being involved with Jacob. https:\/\/t.co\/zZqI37eiFW",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 81, 104 ],
        "url" : "https:\/\/t.co\/zZqI37eiFW",
        "expanded_url" : "http:\/\/hypatia.ca\/2016\/06\/07\/he-said-they-said",
        "display_url" : "hypatia.ca\/2016\/06\/07\/he-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "740339378233315328",
    "text" : "\"He said, they said\" - I wrote about what it was like being involved with Jacob. https:\/\/t.co\/zZqI37eiFW",
    "id" : 740339378233315328,
    "created_at" : "2016-06-08 00:27:17 +0000",
    "user" : {
      "name" : "Leigh Janet Mactavish Honeywell",
      "screen_name" : "hypatiadotca",
      "protected" : false,
      "id_str" : "6742522",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/777680485501722624\/ZOiZulxt_normal.jpg",
      "id" : 6742522,
      "verified" : true
    }
  },
  "id" : 740436630138392576,
  "created_at" : "2016-06-08 06:53:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Geek Feminism blog",
      "screen_name" : "geekfeminism",
      "indices" : [ 3, 16 ],
      "id_str" : "64809827",
      "id" : 64809827
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/geekfeminism\/status\/739838189146247174\/photo\/1",
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/f50VmQ6sSt",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CkRu6PYVAAAEN8v.jpg",
      "id_str" : "739838185635643392",
      "id" : 739838185635643392,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CkRu6PYVAAAEN8v.jpg",
      "sizes" : [ {
        "h" : 456,
        "resize" : "fit",
        "w" : 300
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 456,
        "resize" : "fit",
        "w" : 300
      }, {
        "h" : 456,
        "resize" : "fit",
        "w" : 300
      }, {
        "h" : 456,
        "resize" : "fit",
        "w" : 300
      } ],
      "display_url" : "pic.twitter.com\/f50VmQ6sSt"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/VCB3ZvTRgo",
      "expanded_url" : "http:\/\/geekfeminism.org\/2016\/06\/06\/kameron-hurleys-the-geek-feminist-revolution",
      "display_url" : "geekfeminism.org\/2016\/06\/06\/kam\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "740304481854849024",
  "text" : "RT @geekfeminism: Kameron Hurley\u2019s \u201CThe Geek Feminist Revolution\u201D available\u00A0today https:\/\/t.co\/VCB3ZvTRgo https:\/\/t.co\/f50VmQ6sSt",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/geekfeminism\/status\/739838189146247174\/photo\/1",
        "indices" : [ 88, 111 ],
        "url" : "https:\/\/t.co\/f50VmQ6sSt",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CkRu6PYVAAAEN8v.jpg",
        "id_str" : "739838185635643392",
        "id" : 739838185635643392,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CkRu6PYVAAAEN8v.jpg",
        "sizes" : [ {
          "h" : 456,
          "resize" : "fit",
          "w" : 300
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 456,
          "resize" : "fit",
          "w" : 300
        }, {
          "h" : 456,
          "resize" : "fit",
          "w" : 300
        }, {
          "h" : 456,
          "resize" : "fit",
          "w" : 300
        } ],
        "display_url" : "pic.twitter.com\/f50VmQ6sSt"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 64, 87 ],
        "url" : "https:\/\/t.co\/VCB3ZvTRgo",
        "expanded_url" : "http:\/\/geekfeminism.org\/2016\/06\/06\/kameron-hurleys-the-geek-feminist-revolution",
        "display_url" : "geekfeminism.org\/2016\/06\/06\/kam\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "739838189146247174",
    "text" : "Kameron Hurley\u2019s \u201CThe Geek Feminist Revolution\u201D available\u00A0today https:\/\/t.co\/VCB3ZvTRgo https:\/\/t.co\/f50VmQ6sSt",
    "id" : 739838189146247174,
    "created_at" : "2016-06-06 15:15:44 +0000",
    "user" : {
      "name" : "Geek Feminism blog",
      "screen_name" : "geekfeminism",
      "protected" : false,
      "id_str" : "64809827",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1472098810\/logo-icon_normal.jpg",
      "id" : 64809827,
      "verified" : false
    }
  },
  "id" : 740304481854849024,
  "created_at" : "2016-06-07 22:08:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 57 ],
      "url" : "https:\/\/t.co\/qYhyotoses",
      "expanded_url" : "http:\/\/www.smbc-comics.com\/index.php?id=4132",
      "display_url" : "smbc-comics.com\/index.php?id=4\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "740192400296038401",
  "text" : "The Monty Hall Trolley Problem \uD83D\uDC10\uD83D\uDE8E https:\/\/t.co\/qYhyotoses",
  "id" : 740192400296038401,
  "created_at" : "2016-06-07 14:43:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 79 ],
      "url" : "https:\/\/t.co\/vaxbdgg7mq",
      "expanded_url" : "http:\/\/blogs.scientificamerican.com\/artful-amoeba\/fungi-in-space\/",
      "display_url" : "blogs.scientificamerican.com\/artful-amoeba\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "740179669207650305",
  "text" : "the first time that non-lichenized fungi went to space! https:\/\/t.co\/vaxbdgg7mq",
  "id" : 740179669207650305,
  "created_at" : "2016-06-07 13:52:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sujai Kumar",
      "screen_name" : "sujaik",
      "indices" : [ 0, 7 ],
      "id_str" : "33651124",
      "id" : 33651124
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "740118425465458688",
  "geo" : { },
  "id_str" : "740118606625820672",
  "in_reply_to_user_id" : 33651124,
  "text" : "@sujaik weird, I\u2019m still unbanned. Maybe subscriber IPs have a larger tolerance?",
  "id" : 740118606625820672,
  "in_reply_to_status_id" : 740118425465458688,
  "created_at" : "2016-06-07 09:50:01 +0000",
  "in_reply_to_screen_name" : "sujaik",
  "in_reply_to_user_id_str" : "33651124",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sujai Kumar",
      "screen_name" : "sujaik",
      "indices" : [ 0, 7 ],
      "id_str" : "33651124",
      "id" : 33651124
    }, {
      "name" : "\u24EA Rik Smith-Unna \uD83C\uDDF0\uD83C\uDDEA",
      "screen_name" : "blahah404",
      "indices" : [ 8, 18 ],
      "id_str" : "99173786",
      "id" : 99173786
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "740118189489684480",
  "geo" : { },
  "id_str" : "740118323430629376",
  "in_reply_to_user_id" : 33651124,
  "text" : "@sujaik @blahah404 could you access it before trying the fake URL?",
  "id" : 740118323430629376,
  "in_reply_to_status_id" : 740118189489684480,
  "created_at" : "2016-06-07 09:48:53 +0000",
  "in_reply_to_screen_name" : "sujaik",
  "in_reply_to_user_id_str" : "33651124",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 0, 14 ],
      "id_str" : "352650591",
      "id" : 352650591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "740093037074874370",
  "geo" : { },
  "id_str" : "740117982576312320",
  "in_reply_to_user_id" : 352650591,
  "text" : "@Protohedgehog for some of us that rules out very little. :p",
  "id" : 740117982576312320,
  "in_reply_to_status_id" : 740093037074874370,
  "created_at" : "2016-06-07 09:47:32 +0000",
  "in_reply_to_screen_name" : "Protohedgehog",
  "in_reply_to_user_id_str" : "352650591",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sujai Kumar",
      "screen_name" : "sujaik",
      "indices" : [ 0, 7 ],
      "id_str" : "33651124",
      "id" : 33651124
    }, {
      "name" : "\u24EA Rik Smith-Unna \uD83C\uDDF0\uD83C\uDDEA",
      "screen_name" : "blahah404",
      "indices" : [ 8, 18 ],
      "id_str" : "99173786",
      "id" : 99173786
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "740116905839759360",
  "geo" : { },
  "id_str" : "740117146588590080",
  "in_reply_to_user_id" : 33651124,
  "text" : "@sujaik @blahah404 but started some larger tests out of curiosity. :p",
  "id" : 740117146588590080,
  "in_reply_to_status_id" : 740116905839759360,
  "created_at" : "2016-06-07 09:44:13 +0000",
  "in_reply_to_screen_name" : "sujaik",
  "in_reply_to_user_id_str" : "33651124",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sujai Kumar",
      "screen_name" : "sujaik",
      "indices" : [ 0, 7 ],
      "id_str" : "33651124",
      "id" : 33651124
    }, {
      "name" : "\u24EA Rik Smith-Unna \uD83C\uDDF0\uD83C\uDDEA",
      "screen_name" : "blahah404",
      "indices" : [ 8, 18 ],
      "id_str" : "99173786",
      "id" : 99173786
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "740116905839759360",
  "geo" : { },
  "id_str" : "740117075163795456",
  "in_reply_to_user_id" : 33651124,
  "text" : "@sujaik @blahah404 so far no IP ban here. Could just remove the Cookie and then go on w\/ same IP.",
  "id" : 740117075163795456,
  "in_reply_to_status_id" : 740116905839759360,
  "created_at" : "2016-06-07 09:43:56 +0000",
  "in_reply_to_screen_name" : "sujaik",
  "in_reply_to_user_id_str" : "33651124",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u24EA Rik Smith-Unna \uD83C\uDDF0\uD83C\uDDEA",
      "screen_name" : "blahah404",
      "indices" : [ 0, 10 ],
      "id_str" : "99173786",
      "id" : 99173786
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "740110024714899456",
  "geo" : { },
  "id_str" : "740110266474565632",
  "in_reply_to_user_id" : 99173786,
  "text" : "@blahah404 sure, not saying that it\u2019s in general just deleting cookies. But instead: if you\u2019re banned can try deleting the s_prevProp*\u2019s",
  "id" : 740110266474565632,
  "in_reply_to_status_id" : 740110024714899456,
  "created_at" : "2016-06-07 09:16:52 +0000",
  "in_reply_to_screen_name" : "blahah404",
  "in_reply_to_user_id_str" : "99173786",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u24EA Rik Smith-Unna \uD83C\uDDF0\uD83C\uDDEA",
      "screen_name" : "blahah404",
      "indices" : [ 82, 92 ],
      "id_str" : "99173786",
      "id" : 99173786
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/740108898712092672\/photo\/1",
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/Wzds8c1lZE",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CkVlHsSWYAAR9Iw.jpg",
      "id_str" : "740108896593928192",
      "id" : 740108896593928192,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CkVlHsSWYAAR9Iw.jpg",
      "sizes" : [ {
        "h" : 335,
        "resize" : "fit",
        "w" : 701
      }, {
        "h" : 325,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 335,
        "resize" : "fit",
        "w" : 701
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 335,
        "resize" : "fit",
        "w" : 701
      } ],
      "display_url" : "pic.twitter.com\/Wzds8c1lZE"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/1vPhhIlXQD",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/740105653390311425",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "740105653390311425",
  "geo" : { },
  "id_str" : "740108898712092672",
  "in_reply_to_user_id" : 14286491,
  "text" : "Was just me for now. Wiley sets a cookie to ban you. Remove this and you\u2019re good. @blahah404 https:\/\/t.co\/1vPhhIlXQD https:\/\/t.co\/Wzds8c1lZE",
  "id" : 740108898712092672,
  "in_reply_to_status_id" : 740105653390311425,
  "created_at" : "2016-06-07 09:11:26 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Goethe-Universit\u00E4t",
      "screen_name" : "goetheuni",
      "indices" : [ 19, 29 ],
      "id_str" : "38180826",
      "id" : 38180826
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/G6MTLQEyuK",
      "expanded_url" : "https:\/\/docs.google.com\/document\/d\/1uTVHPI8r4VO31KihsyiBHsh_gp8jZ38fMvP5nP5XOkw\/edit",
      "display_url" : "docs.google.com\/document\/d\/1uT\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "740105653390311425",
  "text" : "Whops, not sure if @goetheuni or just me is banned from Wiley because I accessed a fake DOI last week. https:\/\/t.co\/G6MTLQEyuK",
  "id" : 740105653390311425,
  "created_at" : "2016-06-07 08:58:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 34 ],
      "url" : "https:\/\/t.co\/4G0MF2adpo",
      "expanded_url" : "https:\/\/media.giphy.com\/media\/3oD3YGIVrRGbe5YGNa\/giphy.gif",
      "display_url" : "media.giphy.com\/media\/3oD3YGIV\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1724046503649, 8.627422770538104 ]
  },
  "id_str" : "740101391897743360",
  "text" : "inbox zero https:\/\/t.co\/4G0MF2adpo",
  "id" : 740101391897743360,
  "created_at" : "2016-06-07 08:41:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 33 ],
      "url" : "https:\/\/t.co\/zgthw9lQVM",
      "expanded_url" : "https:\/\/twitter.com\/matthewherper\/status\/739885258741547008",
      "display_url" : "twitter.com\/matthewherper\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "739921351113330690",
  "text" : "p=0.042 \u2026 https:\/\/t.co\/zgthw9lQVM",
  "id" : 739921351113330690,
  "created_at" : "2016-06-06 20:46:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "A. Murat Eren",
      "screen_name" : "merenbey",
      "indices" : [ 0, 9 ],
      "id_str" : "16029156",
      "id" : 16029156
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "739867741277032448",
  "geo" : { },
  "id_str" : "739867921728589824",
  "in_reply_to_user_id" : 16029156,
  "text" : "@merenbey needs grants in order to fly research subjects across the Atlantic.",
  "id" : 739867921728589824,
  "in_reply_to_status_id" : 739867741277032448,
  "created_at" : "2016-06-06 17:13:53 +0000",
  "in_reply_to_screen_name" : "merenbey",
  "in_reply_to_user_id_str" : "16029156",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "A. Murat Eren",
      "screen_name" : "merenbey",
      "indices" : [ 0, 9 ],
      "id_str" : "16029156",
      "id" : 16029156
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "739862570161602560",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11393797732843, 8.75356237861257 ]
  },
  "id_str" : "739865850388307968",
  "in_reply_to_user_id" : 16029156,
  "text" : "@merenbey we should write a grant on the effects of putpocketing then :p",
  "id" : 739865850388307968,
  "in_reply_to_status_id" : 739862570161602560,
  "created_at" : "2016-06-06 17:05:39 +0000",
  "in_reply_to_screen_name" : "merenbey",
  "in_reply_to_user_id_str" : "16029156",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul-Olivier Dehaye",
      "screen_name" : "podehaye",
      "indices" : [ 0, 9 ],
      "id_str" : "2219841242",
      "id" : 2219841242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "739859773294796800",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11388635134391, 8.75353490398857 ]
  },
  "id_str" : "739860581906255872",
  "in_reply_to_user_id" : 2219841242,
  "text" : "@podehaye oh, that\u2019s cool! Have fun!",
  "id" : 739860581906255872,
  "in_reply_to_status_id" : 739859773294796800,
  "created_at" : "2016-06-06 16:44:43 +0000",
  "in_reply_to_screen_name" : "podehaye",
  "in_reply_to_user_id_str" : "2219841242",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "A. Murat Eren",
      "screen_name" : "merenbey",
      "indices" : [ 0, 9 ],
      "id_str" : "16029156",
      "id" : 16029156
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "739853151495454720",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11388635134391, 8.75353490398857 ]
  },
  "id_str" : "739860517049753601",
  "in_reply_to_user_id" : 16029156,
  "text" : "@merenbey too bad. Maybe I\u2019ll find some excuse to come by Chicago one day.",
  "id" : 739860517049753601,
  "in_reply_to_status_id" : 739853151495454720,
  "created_at" : "2016-06-06 16:44:27 +0000",
  "in_reply_to_screen_name" : "merenbey",
  "in_reply_to_user_id_str" : "16029156",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "A. Murat Eren",
      "screen_name" : "merenbey",
      "indices" : [ 0, 9 ],
      "id_str" : "16029156",
      "id" : 16029156
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "739849622269493249",
  "geo" : { },
  "id_str" : "739849847432466432",
  "in_reply_to_user_id" : 16029156,
  "text" : "@merenbey unfortunately I\u2019m not. Will you be at SMBE or ISMB?",
  "id" : 739849847432466432,
  "in_reply_to_status_id" : 739849622269493249,
  "created_at" : "2016-06-06 16:02:04 +0000",
  "in_reply_to_screen_name" : "merenbey",
  "in_reply_to_user_id_str" : "16029156",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "A. Murat Eren",
      "screen_name" : "merenbey",
      "indices" : [ 0, 9 ],
      "id_str" : "16029156",
      "id" : 16029156
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "739833021055012866",
  "geo" : { },
  "id_str" : "739847977141932032",
  "in_reply_to_user_id" : 16029156,
  "text" : "@merenbey what a beauty!",
  "id" : 739847977141932032,
  "in_reply_to_status_id" : 739833021055012866,
  "created_at" : "2016-06-06 15:54:38 +0000",
  "in_reply_to_screen_name" : "merenbey",
  "in_reply_to_user_id_str" : "16029156",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "opencon",
      "indices" : [ 58, 66 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/8uP5TnFANe",
      "expanded_url" : "https:\/\/twitter.com\/open_con\/status\/739793587035090944",
      "display_url" : "twitter.com\/open_con\/statu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "739818870333186050",
  "text" : "Interested in open*? Then you definitely should apply for #opencon. Last year was a transformative experience! https:\/\/t.co\/8uP5TnFANe",
  "id" : 739818870333186050,
  "created_at" : "2016-06-06 13:58:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul-Olivier Dehaye",
      "screen_name" : "podehaye",
      "indices" : [ 0, 9 ],
      "id_str" : "2219841242",
      "id" : 2219841242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "739788562527313920",
  "geo" : { },
  "id_str" : "739814817930825728",
  "in_reply_to_user_id" : 2219841242,
  "text" : "@podehaye what science are you doing? :D",
  "id" : 739814817930825728,
  "in_reply_to_status_id" : 739788562527313920,
  "created_at" : "2016-06-06 13:42:52 +0000",
  "in_reply_to_screen_name" : "podehaye",
  "in_reply_to_user_id_str" : "2219841242",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mozilla UK",
      "screen_name" : "MozillaUK",
      "indices" : [ 3, 13 ],
      "id_str" : "101318716",
      "id" : 101318716
    }, {
      "name" : "Mozilla Festival",
      "screen_name" : "mozillafestival",
      "indices" : [ 52, 68 ],
      "id_str" : "348416778",
      "id" : 348416778
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/ImtB4djd79",
      "expanded_url" : "http:\/\/mzl.la\/mozfest",
      "display_url" : "mzl.la\/mozfest"
    } ]
  },
  "geo" : { },
  "id_str" : "739813512197877761",
  "text" : "RT @MozillaUK: Want to shape the future of the web? @mozillafestival call for session proposals are open https:\/\/t.co\/ImtB4djd79 https:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Mozilla Festival",
        "screen_name" : "mozillafestival",
        "indices" : [ 37, 53 ],
        "id_str" : "348416778",
        "id" : 348416778
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/MozillaUK\/status\/739757912596336641\/photo\/1",
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/B1ahIDRbzW",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CkQl5igWYAEhSGi.jpg",
        "id_str" : "739757909240864769",
        "id" : 739757909240864769,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CkQl5igWYAEhSGi.jpg",
        "sizes" : [ {
          "h" : 1365,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1365,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/B1ahIDRbzW"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 90, 113 ],
        "url" : "https:\/\/t.co\/ImtB4djd79",
        "expanded_url" : "http:\/\/mzl.la\/mozfest",
        "display_url" : "mzl.la\/mozfest"
      } ]
    },
    "geo" : { },
    "id_str" : "739757912596336641",
    "text" : "Want to shape the future of the web? @mozillafestival call for session proposals are open https:\/\/t.co\/ImtB4djd79 https:\/\/t.co\/B1ahIDRbzW",
    "id" : 739757912596336641,
    "created_at" : "2016-06-06 09:56:45 +0000",
    "user" : {
      "name" : "Mozilla UK",
      "screen_name" : "MozillaUK",
      "protected" : false,
      "id_str" : "101318716",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/662179663444332544\/d6GHZJGr_normal.png",
      "id" : 101318716,
      "verified" : false
    }
  },
  "id" : 739813512197877761,
  "created_at" : "2016-06-06 13:37:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 65 ],
      "url" : "https:\/\/t.co\/ul7akjgtpr",
      "expanded_url" : "http:\/\/time.com\/120751\/robert-capa-dday-photos\/",
      "display_url" : "time.com\/120751\/robert-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "739804448550211584",
  "text" : "How Robert Capa\u2019s D-Day photos were lost. https:\/\/t.co\/ul7akjgtpr",
  "id" : 739804448550211584,
  "created_at" : "2016-06-06 13:01:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luc Henry",
      "screen_name" : "heluc",
      "indices" : [ 0, 6 ],
      "id_str" : "850645992",
      "id" : 850645992
    }, {
      "name" : "Kevin Schawinski",
      "screen_name" : "kevinschawinski",
      "indices" : [ 7, 23 ],
      "id_str" : "242844365",
      "id" : 242844365
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "739670513577037825",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06096291826112, 8.81853503175901 ]
  },
  "id_str" : "739696037728751616",
  "in_reply_to_user_id" : 850645992,
  "text" : "@heluc @kevinschawinski 60\u20AC for 4 GB of 4G traffic here. And there is just no wifi on trains, regardless of whether you pay or not.",
  "id" : 739696037728751616,
  "in_reply_to_status_id" : 739670513577037825,
  "created_at" : "2016-06-06 05:50:52 +0000",
  "in_reply_to_screen_name" : "heluc",
  "in_reply_to_user_id_str" : "850645992",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "739595141133049856",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06083457792446, 8.81853865430936 ]
  },
  "id_str" : "739595334733729794",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon if there was a claim on IP in general. I\u2019d be like \u2018uh, too late, it\u2019s already public domain\u2019!",
  "id" : 739595334733729794,
  "in_reply_to_status_id" : 739595141133049856,
  "created_at" : "2016-06-05 23:10:43 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "739594691092570112",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06083457792446, 8.81853865430936 ]
  },
  "id_str" : "739594911213883392",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon this would actually be one of the things that\u2019d make me quit a job.",
  "id" : 739594911213883392,
  "in_reply_to_status_id" : 739594691092570112,
  "created_at" : "2016-06-05 23:09:02 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "beau",
      "screen_name" : "beaugunderson",
      "indices" : [ 3, 17 ],
      "id_str" : "5746882",
      "id" : 5746882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 63 ],
      "url" : "https:\/\/t.co\/EpzDXtFRjZ",
      "expanded_url" : "https:\/\/twitter.com\/Lahlahlindsey\/status\/738828183928197120",
      "display_url" : "twitter.com\/Lahlahlindsey\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "739550883965505537",
  "text" : "RT @beaugunderson: (tw: rape) holy shit https:\/\/t.co\/EpzDXtFRjZ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 21, 44 ],
        "url" : "https:\/\/t.co\/EpzDXtFRjZ",
        "expanded_url" : "https:\/\/twitter.com\/Lahlahlindsey\/status\/738828183928197120",
        "display_url" : "twitter.com\/Lahlahlindsey\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "739522050931326976",
    "text" : "(tw: rape) holy shit https:\/\/t.co\/EpzDXtFRjZ",
    "id" : 739522050931326976,
    "created_at" : "2016-06-05 18:19:31 +0000",
    "user" : {
      "name" : "beau",
      "screen_name" : "beaugunderson",
      "protected" : false,
      "id_str" : "5746882",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/913840034016399360\/pU3IIxqf_normal.jpg",
      "id" : 5746882,
      "verified" : false
    }
  },
  "id" : 739550883965505537,
  "created_at" : "2016-06-05 20:14:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Razib Khan",
      "screen_name" : "razibkhan",
      "indices" : [ 0, 10 ],
      "id_str" : "35304791",
      "id" : 35304791
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "739544477824634880",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06110976300389, 8.81852280970616 ]
  },
  "id_str" : "739544707123052548",
  "in_reply_to_user_id" : 35304791,
  "text" : "@razibkhan that\u2019s just mean, adding insult to injury!",
  "id" : 739544707123052548,
  "in_reply_to_status_id" : 739544477824634880,
  "created_at" : "2016-06-05 19:49:32 +0000",
  "in_reply_to_screen_name" : "razibkhan",
  "in_reply_to_user_id_str" : "35304791",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 90 ],
      "url" : "https:\/\/t.co\/Pgs6TQiDxj",
      "expanded_url" : "https:\/\/twitter.com\/kevinschawinski\/status\/739489041444409344",
      "display_url" : "twitter.com\/kevinschawinsk\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06110976300389, 8.81852280970616 ]
  },
  "id_str" : "739544278356111361",
  "text" : "Meanwhile in Germany I don\u2019t even get 3G internet in my apartment\u2026 https:\/\/t.co\/Pgs6TQiDxj",
  "id" : 739544278356111361,
  "created_at" : "2016-06-05 19:47:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrea Bedini",
      "screen_name" : "andreabedini",
      "indices" : [ 0, 13 ],
      "id_str" : "10332182",
      "id" : 10332182
    }, {
      "name" : "Rob Syme",
      "screen_name" : "robsyme",
      "indices" : [ 14, 22 ],
      "id_str" : "15027761",
      "id" : 15027761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "738249952011288576",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06117569663902, 8.818563223822618 ]
  },
  "id_str" : "739542750102716417",
  "in_reply_to_user_id" : 10332182,
  "text" : "@andreabedini @robsyme awesome, how far did you get? :)",
  "id" : 739542750102716417,
  "in_reply_to_status_id" : 738249952011288576,
  "created_at" : "2016-06-05 19:41:46 +0000",
  "in_reply_to_screen_name" : "andreabedini",
  "in_reply_to_user_id_str" : "10332182",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emanuel Wyler",
      "screen_name" : "ewyler",
      "indices" : [ 0, 7 ],
      "id_str" : "122329006",
      "id" : 122329006
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "739536195630292992",
  "geo" : { },
  "id_str" : "739536931428696065",
  "in_reply_to_user_id" : 122329006,
  "text" : "@ewyler I see, that could be a fun project then. At least to get a minimum estimate of off-target effects. :-)",
  "id" : 739536931428696065,
  "in_reply_to_status_id" : 739536195630292992,
  "created_at" : "2016-06-05 19:18:39 +0000",
  "in_reply_to_screen_name" : "ewyler",
  "in_reply_to_user_id_str" : "122329006",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/rwSSMwAEcH",
      "expanded_url" : "http:\/\/www.nature.com\/naturejobs\/science\/articles\/10.1038\/nj7605-141a",
      "display_url" : "nature.com\/naturejobs\/sci\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "739536036771024896",
  "text" : "\u00ABWhenever work in the lab generates IP, everyone in the lab benefits financially from any royalties.\u00BB \uD83D\uDE2D https:\/\/t.co\/rwSSMwAEcH",
  "id" : 739536036771024896,
  "created_at" : "2016-06-05 19:15:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emanuel Wyler",
      "screen_name" : "ewyler",
      "indices" : [ 0, 7 ],
      "id_str" : "122329006",
      "id" : 122329006
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "739534699337502720",
  "geo" : { },
  "id_str" : "739535060806819840",
  "in_reply_to_user_id" : 122329006,
  "text" : "@ewyler out of principle or because you already have the data\/the alternative is too expensive?",
  "id" : 739535060806819840,
  "in_reply_to_status_id" : 739534699337502720,
  "created_at" : "2016-06-05 19:11:13 +0000",
  "in_reply_to_screen_name" : "ewyler",
  "in_reply_to_user_id_str" : "122329006",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emanuel Wyler",
      "screen_name" : "ewyler",
      "indices" : [ 0, 7 ],
      "id_str" : "122329006",
      "id" : 122329006
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "739532641117085697",
  "geo" : { },
  "id_str" : "739534395393081344",
  "in_reply_to_user_id" : 122329006,
  "text" : "@ewyler but seriously, feel often time &amp; money spent in post-processing to get Illumina up to shape could be better invested in long reads",
  "id" : 739534395393081344,
  "in_reply_to_status_id" : 739532641117085697,
  "created_at" : "2016-06-05 19:08:34 +0000",
  "in_reply_to_screen_name" : "ewyler",
  "in_reply_to_user_id_str" : "122329006",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/GVs2xmhjNQ",
      "expanded_url" : "https:\/\/twitter.com\/jasonHoyt\/status\/739435549149302785",
      "display_url" : "twitter.com\/jasonHoyt\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "739532721563799552",
  "text" : "\u00ABmost of these Q\u2019s are pretty naive, a discussion with almost any physicist could have answered these for you\u00BB \uD83D\uDE02 https:\/\/t.co\/GVs2xmhjNQ",
  "id" : 739532721563799552,
  "created_at" : "2016-06-05 19:01:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emanuel Wyler",
      "screen_name" : "ewyler",
      "indices" : [ 0, 7 ],
      "id_str" : "122329006",
      "id" : 122329006
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/WKcY5lec8l",
      "expanded_url" : "http:\/\/biorxiv.org\/content\/early\/2016\/06\/03\/056887",
      "display_url" : "biorxiv.org\/content\/early\/\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "739530976116760576",
  "geo" : { },
  "id_str" : "739532029566562306",
  "in_reply_to_user_id" : 122329006,
  "text" : "@ewyler nope, but then I\u2019m not too interested in HiSeq2000 data any longer. Did you see https:\/\/t.co\/WKcY5lec8l ?",
  "id" : 739532029566562306,
  "in_reply_to_status_id" : 739530976116760576,
  "created_at" : "2016-06-05 18:59:10 +0000",
  "in_reply_to_screen_name" : "ewyler",
  "in_reply_to_user_id_str" : "122329006",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Konrad F\u00F6rstner",
      "screen_name" : "konradfoerstner",
      "indices" : [ 0, 16 ],
      "id_str" : "15150655",
      "id" : 15150655
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "739525354558226432",
  "geo" : { },
  "id_str" : "739527755688235008",
  "in_reply_to_user_id" : 15150655,
  "text" : "@konradfoerstner (also that you won\u2019t be productive at a regular desk ;))",
  "id" : 739527755688235008,
  "in_reply_to_status_id" : 739525354558226432,
  "created_at" : "2016-06-05 18:42:11 +0000",
  "in_reply_to_screen_name" : "konradfoerstner",
  "in_reply_to_user_id_str" : "15150655",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emanuel Wyler",
      "screen_name" : "ewyler",
      "indices" : [ 0, 7 ],
      "id_str" : "122329006",
      "id" : 122329006
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "739525921493942272",
  "geo" : { },
  "id_str" : "739526662749061120",
  "in_reply_to_user_id" : 122329006,
  "text" : "@ewyler let me know if you want\/need any help with it. :-)",
  "id" : 739526662749061120,
  "in_reply_to_status_id" : 739525921493942272,
  "created_at" : "2016-06-05 18:37:50 +0000",
  "in_reply_to_screen_name" : "ewyler",
  "in_reply_to_user_id_str" : "122329006",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/QUvCQN5QJL",
      "expanded_url" : "https:\/\/twitter.com\/konradfoerstner\/status\/739419214902071296",
      "display_url" : "twitter.com\/konradfoerstne\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "739520047807365120",
  "text" : "A big fan of standing desks (have been using them for years too) but I doubt that it\u2019s that simple a story. https:\/\/t.co\/QUvCQN5QJL",
  "id" : 739520047807365120,
  "created_at" : "2016-06-05 18:11:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emanuel Wyler",
      "screen_name" : "ewyler",
      "indices" : [ 0, 7 ],
      "id_str" : "122329006",
      "id" : 122329006
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "739020647024693248",
  "geo" : { },
  "id_str" : "739512713152450560",
  "in_reply_to_user_id" : 122329006,
  "text" : "@ewyler yep, I guess that could work. (Obviously depending on how repetitive indel sites are and what your read length is).",
  "id" : 739512713152450560,
  "in_reply_to_status_id" : 739020647024693248,
  "created_at" : "2016-06-05 17:42:24 +0000",
  "in_reply_to_screen_name" : "ewyler",
  "in_reply_to_user_id_str" : "122329006",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 84 ],
      "url" : "https:\/\/t.co\/132Eyp1FGp",
      "expanded_url" : "https:\/\/twitter.com\/_inundata\/status\/739263563739500544",
      "display_url" : "twitter.com\/_inundata\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "739512447254560768",
  "text" : "Read this before breakfast today and it ruined my whole day\u2026 https:\/\/t.co\/132Eyp1FGp",
  "id" : 739512447254560768,
  "created_at" : "2016-06-05 17:41:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kaitlin Thaney \uD83D\uDC81\uD83C\uDFFB",
      "screen_name" : "kaythaney",
      "indices" : [ 0, 10 ],
      "id_str" : "22839233",
      "id" : 22839233
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "739421893720211456",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.10745665011363, 8.758587162719376 ]
  },
  "id_str" : "739422170603003905",
  "in_reply_to_user_id" : 22839233,
  "text" : "@kaythaney yes, starting May 2017 would be ideal for me :( but well, maybe next year :)",
  "id" : 739422170603003905,
  "in_reply_to_status_id" : 739421893720211456,
  "created_at" : "2016-06-05 11:42:37 +0000",
  "in_reply_to_screen_name" : "kaythaney",
  "in_reply_to_user_id_str" : "22839233",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kaitlin Thaney \uD83D\uDC81\uD83C\uDFFB",
      "screen_name" : "kaythaney",
      "indices" : [ 0, 10 ],
      "id_str" : "22839233",
      "id" : 22839233
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "739421303006990336",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1105353375827, 8.7589463598047 ]
  },
  "id_str" : "739421492971241472",
  "in_reply_to_user_id" : 22839233,
  "text" : "@kaythaney the start date of it would be too close to finishing my PhD to apply.",
  "id" : 739421492971241472,
  "in_reply_to_status_id" : 739421303006990336,
  "created_at" : "2016-06-05 11:39:56 +0000",
  "in_reply_to_screen_name" : "kaythaney",
  "in_reply_to_user_id_str" : "22839233",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 79 ],
      "url" : "https:\/\/t.co\/6oC9xVeh0x",
      "expanded_url" : "https:\/\/twitter.com\/kaythaney\/status\/738822301316218880",
      "display_url" : "twitter.com\/kaythaney\/stat\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.10648571320427, 8.761060437557228 ]
  },
  "id_str" : "739421201743941632",
  "text" : "Nooooo, why must the timing be so bad for me on this \uD83D\uDE31\uD83D\uDE22 https:\/\/t.co\/6oC9xVeh0x",
  "id" : 739421201743941632,
  "created_at" : "2016-06-05 11:38:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sebastian Greiner",
      "screen_name" : "Seb666",
      "indices" : [ 0, 7 ],
      "id_str" : "2365333778",
      "id" : 2365333778
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.10801617533855, 8.765035544978472 ]
  },
  "id_str" : "739414000002289664",
  "in_reply_to_user_id" : 2365333778,
  "text" : "@Seb666 hallo!",
  "id" : 739414000002289664,
  "created_at" : "2016-06-05 11:10:09 +0000",
  "in_reply_to_screen_name" : "Seb666",
  "in_reply_to_user_id_str" : "2365333778",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emanuel Wyler",
      "screen_name" : "ewyler",
      "indices" : [ 0, 7 ],
      "id_str" : "122329006",
      "id" : 122329006
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "738837908212355072",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11399130842895, 8.753487696758 ]
  },
  "id_str" : "738848264158601216",
  "in_reply_to_user_id" : 122329006,
  "text" : "@ewyler so you\u2019d want to do de novo assembly first and map those assembled ctgs later on to the ref?",
  "id" : 738848264158601216,
  "in_reply_to_status_id" : 738837908212355072,
  "created_at" : "2016-06-03 21:42:07 +0000",
  "in_reply_to_screen_name" : "ewyler",
  "in_reply_to_user_id_str" : "122329006",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emanuel Wyler",
      "screen_name" : "ewyler",
      "indices" : [ 0, 7 ],
      "id_str" : "122329006",
      "id" : 122329006
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "738707162793414656",
  "geo" : { },
  "id_str" : "738759835651571712",
  "in_reply_to_user_id" : 122329006,
  "text" : "@ewyler and you\u2019d never even think about doing human de novo assembly using just Illumina data. :D",
  "id" : 738759835651571712,
  "in_reply_to_status_id" : 738707162793414656,
  "created_at" : "2016-06-03 15:50:44 +0000",
  "in_reply_to_screen_name" : "ewyler",
  "in_reply_to_user_id_str" : "122329006",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emanuel Wyler",
      "screen_name" : "ewyler",
      "indices" : [ 0, 7 ],
      "id_str" : "122329006",
      "id" : 122329006
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "738707162793414656",
  "geo" : { },
  "id_str" : "738759679275372547",
  "in_reply_to_user_id" : 122329006,
  "text" : "@ewyler but then the biggest benefit comes from the hybrid capabilities &amp; multi-sized kmers, so useful for Illumina data.",
  "id" : 738759679275372547,
  "in_reply_to_status_id" : 738707162793414656,
  "created_at" : "2016-06-03 15:50:07 +0000",
  "in_reply_to_screen_name" : "ewyler",
  "in_reply_to_user_id_str" : "122329006",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emanuel Wyler",
      "screen_name" : "ewyler",
      "indices" : [ 0, 7 ],
      "id_str" : "122329006",
      "id" : 122329006
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "738707162793414656",
  "geo" : { },
  "id_str" : "738759500459544577",
  "in_reply_to_user_id" : 122329006,
  "text" : "@ewyler yep, WGS assembler. Can work with basically all data (Illumina, PacBio, Nanopore). Only suitable for smaller genomes.",
  "id" : 738759500459544577,
  "in_reply_to_status_id" : 738707162793414656,
  "created_at" : "2016-06-03 15:49:25 +0000",
  "in_reply_to_screen_name" : "ewyler",
  "in_reply_to_user_id_str" : "122329006",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "openSNP team",
      "screen_name" : "openSNPorg",
      "indices" : [ 3, 14 ],
      "id_str" : "380205172",
      "id" : 380205172
    }, {
      "name" : "Genes for Good",
      "screen_name" : "genesforgood",
      "indices" : [ 40, 53 ],
      "id_str" : "2313751399",
      "id" : 2313751399
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "738758935348432896",
  "text" : "RT @openSNPorg: You\u2019re a participant of @genesforgood? We just added support for their files to our system. Donate your genotype at https:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Genes for Good",
        "screen_name" : "genesforgood",
        "indices" : [ 24, 37 ],
        "id_str" : "2313751399",
        "id" : 2313751399
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/fvKtLq6QvQ",
        "expanded_url" : "https:\/\/opensnp.org\/genotypes\/new",
        "display_url" : "opensnp.org\/genotypes\/new"
      } ]
    },
    "geo" : { },
    "id_str" : "738758176212946944",
    "text" : "You\u2019re a participant of @genesforgood? We just added support for their files to our system. Donate your genotype at https:\/\/t.co\/fvKtLq6QvQ",
    "id" : 738758176212946944,
    "created_at" : "2016-06-03 15:44:09 +0000",
    "user" : {
      "name" : "openSNP team",
      "screen_name" : "openSNPorg",
      "protected" : false,
      "id_str" : "380205172",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/735374825187909632\/wJEJW1zW_normal.jpg",
      "id" : 380205172,
      "verified" : false
    }
  },
  "id" : 738758935348432896,
  "created_at" : "2016-06-03 15:47:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/zGpTVRjya4",
      "expanded_url" : "http:\/\/www.newyorker.com\/business\/currency\/the-swiss-vote-on-guaranteed-income-is-about-rich-peoples-problems?mbid=rss",
      "display_url" : "newyorker.com\/business\/curre\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "738757181370204160",
  "text" : "Swiss talk about basic income, as a a utopian vision. In the US it\u2019s a last bulwark against national impoverishment. https:\/\/t.co\/zGpTVRjya4",
  "id" : 738757181370204160,
  "created_at" : "2016-06-03 15:40:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "738671551671898112",
  "geo" : { },
  "id_str" : "738672246298947584",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich Also es hat auch l\u00E4nger \u00FCberlebt, hab es am Ende verschenkt als ich upgraded hab.",
  "id" : 738672246298947584,
  "in_reply_to_status_id" : 738671551671898112,
  "created_at" : "2016-06-03 10:02:42 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "738671551671898112",
  "geo" : { },
  "id_str" : "738672173427118081",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich Die bieten 1 Jahr Garantie. fwiw: Hab dort vor Jahren ein Thinkpad geshoppt was 3+ Jahre bei mir \u00FCberlebt hat. :D",
  "id" : 738672173427118081,
  "in_reply_to_status_id" : 738671551671898112,
  "created_at" : "2016-06-03 10:02:24 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "738671551671898112",
  "geo" : { },
  "id_str" : "738671975321743360",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich Ok, dann such was entsprechend gr\u00F6\u00DFeres, wird im Zweifel sogar billiger. Die X-Series Thinkpads haben aber \u00B1 normale Keyboards.",
  "id" : 738671975321743360,
  "in_reply_to_status_id" : 738671551671898112,
  "created_at" : "2016-06-03 10:01:37 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 74 ],
      "url" : "https:\/\/t.co\/pNaytvs8qJ",
      "expanded_url" : "http:\/\/www.lapstore.de\/a.php\/shop\/lapstore\/lang\/x\/a\/16624\/kw\/Lenovo-ThinkPad-X230-2324-2330-2325-3E9-1A8-UH2",
      "display_url" : "lapstore.de\/a.php\/shop\/lap\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "738670128758444032",
  "geo" : { },
  "id_str" : "738670828674527232",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich klassische Gr\u00F6\u00DFe w\u00E4re? in any case, c.f. https:\/\/t.co\/pNaytvs8qJ",
  "id" : 738670828674527232,
  "in_reply_to_status_id" : 738670128758444032,
  "created_at" : "2016-06-03 09:57:04 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Austin Richardson",
      "screen_name" : "heyaudy",
      "indices" : [ 0, 8 ],
      "id_str" : "14534523",
      "id" : 14534523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/pkD5HpXYGH",
      "expanded_url" : "https:\/\/www.genome.gov\/images\/content\/costpergenome2015_4.jpg",
      "display_url" : "genome.gov\/images\/content\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "738610724784607232",
  "geo" : { },
  "id_str" : "738670259914321920",
  "in_reply_to_user_id" : 14534523,
  "text" : "@heyaudy time it takes to add something to the \u201Eto-read\u201C list vs. time to actually read it. https:\/\/t.co\/pkD5HpXYGH",
  "id" : 738670259914321920,
  "in_reply_to_status_id" : 738610724784607232,
  "created_at" : "2016-06-03 09:54:48 +0000",
  "in_reply_to_screen_name" : "heyaudy",
  "in_reply_to_user_id_str" : "14534523",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "738669769163952128",
  "geo" : { },
  "id_str" : "738669986579939328",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich dann w\u00FCrde ich nach einem g\u00FCnstigen Thinkpad (ggf. gebraucht) Ausschau halten.",
  "id" : 738669986579939328,
  "in_reply_to_status_id" : 738669769163952128,
  "created_at" : "2016-06-03 09:53:43 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "738604065467207680",
  "geo" : { },
  "id_str" : "738669421019992064",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich was sind deine Anforderungen?",
  "id" : 738669421019992064,
  "in_reply_to_status_id" : 738604065467207680,
  "created_at" : "2016-06-03 09:51:28 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/k7s7kz0pNz",
      "expanded_url" : "https:\/\/twitter.com\/spadesassembler\/status\/738048105396854784",
      "display_url" : "twitter.com\/spadesassemble\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "738667078530531329",
  "text" : "Just seeing this. One of my favorite assemblers has just become even better! \uD83D\uDE0D\uD83D\uDC96 https:\/\/t.co\/k7s7kz0pNz",
  "id" : 738667078530531329,
  "created_at" : "2016-06-03 09:42:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rob Schaefer",
      "screen_name" : "CSciBio",
      "indices" : [ 0, 8 ],
      "id_str" : "361319984",
      "id" : 361319984
    }, {
      "name" : "Abby Cabunoc Mayes",
      "screen_name" : "abbycabs",
      "indices" : [ 9, 18 ],
      "id_str" : "395367768",
      "id" : 395367768
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "738500163640008704",
  "geo" : { },
  "id_str" : "738660159992541184",
  "in_reply_to_user_id" : 361319984,
  "text" : "@CSciBio @abbycabs now I\u2019m really missing out!",
  "id" : 738660159992541184,
  "in_reply_to_status_id" : 738500163640008704,
  "created_at" : "2016-06-03 09:14:40 +0000",
  "in_reply_to_screen_name" : "CSciBio",
  "in_reply_to_user_id_str" : "361319984",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "s.e. smith",
      "screen_name" : "realsesmith",
      "indices" : [ 3, 15 ],
      "id_str" : "881921177647669248",
      "id" : 881921177647669248
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/ZBFRSP9B7J",
      "expanded_url" : "http:\/\/www.npr.org\/sections\/thetwo-way\/2016\/06\/02\/480437128\/insect-named-for-ruth-bader-ginsburg-is-step-toward-equality-of-the-6-legged-sex",
      "display_url" : "npr.org\/sections\/thetw\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "738520406940889088",
  "text" : "RT @realsesmith: The story behind that praying mantis named for RBG is even better than you know. https:\/\/t.co\/ZBFRSP9B7J",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 81, 104 ],
        "url" : "https:\/\/t.co\/ZBFRSP9B7J",
        "expanded_url" : "http:\/\/www.npr.org\/sections\/thetwo-way\/2016\/06\/02\/480437128\/insect-named-for-ruth-bader-ginsburg-is-step-toward-equality-of-the-6-legged-sex",
        "display_url" : "npr.org\/sections\/thetw\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "738467241545453569",
    "text" : "The story behind that praying mantis named for RBG is even better than you know. https:\/\/t.co\/ZBFRSP9B7J",
    "id" : 738467241545453569,
    "created_at" : "2016-06-02 20:28:05 +0000",
    "user" : {
      "name" : "s.e. smith",
      "screen_name" : "sesmith",
      "protected" : false,
      "id_str" : "127091266",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/713887487643492352\/pDKvgQGh_normal.jpg",
      "id" : 127091266,
      "verified" : true
    }
  },
  "id" : 738520406940889088,
  "created_at" : "2016-06-02 23:59:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 91, 104 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mozsprint",
      "indices" : [ 44, 54 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/f3ir9Mn73a",
      "expanded_url" : "https:\/\/github.com\/openSNP\/snpr\/issues\/289",
      "display_url" : "github.com\/openSNP\/snpr\/i\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "738513545269268480",
  "text" : "Dev level right before heading to bed after #mozsprint day 1: i\u2019ve no idea what I\u2019m doing! @PhilippBayer your turn \uD83D\uDE02 https:\/\/t.co\/f3ir9Mn73a",
  "id" : 738513545269268480,
  "created_at" : "2016-06-02 23:32:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Austin Richardson",
      "screen_name" : "heyaudy",
      "indices" : [ 0, 8 ],
      "id_str" : "14534523",
      "id" : 14534523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "738390092574687232",
  "geo" : { },
  "id_str" : "738390795850518528",
  "in_reply_to_user_id" : 14534523,
  "text" : "@heyaudy yes, just like you and I are, in a way. Btw. what are you doing with the \uD83D\uDC22 in the \uD83C\uDFDC?",
  "id" : 738390795850518528,
  "in_reply_to_status_id" : 738390092574687232,
  "created_at" : "2016-06-02 15:24:19 +0000",
  "in_reply_to_screen_name" : "heyaudy",
  "in_reply_to_user_id_str" : "14534523",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "738389223049441280",
  "geo" : { },
  "id_str" : "738389389974310912",
  "in_reply_to_user_id" : 14286491,
  "text" : "\u00AB\u2026because it couldn't distinguish between the simulation and the real thing.\u00BB I love the future.",
  "id" : 738389389974310912,
  "in_reply_to_status_id" : 738389223049441280,
  "created_at" : "2016-06-02 15:18:43 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "738389097128071168",
  "geo" : { },
  "id_str" : "738389223049441280",
  "in_reply_to_user_id" : 14286491,
  "text" : "\u00ABWarner had just DMCA'd an artificial reconstruction of a film about artificial intelligence being indistinguishable from humans\u2026\u00BB",
  "id" : 738389223049441280,
  "in_reply_to_status_id" : 738389097128071168,
  "created_at" : "2016-06-02 15:18:04 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 72 ],
      "url" : "https:\/\/t.co\/HiAOQfZy4L",
      "expanded_url" : "http:\/\/www.vox.com\/2016\/6\/1\/11787262\/blade-runner-neural-network-encoding",
      "display_url" : "vox.com\/2016\/6\/1\/11787\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "738389097128071168",
  "text" : "Blade Runner as seen through a neural network \uD83D\uDC96\uD83E\uDD16 https:\/\/t.co\/HiAOQfZy4L",
  "id" : 738389097128071168,
  "created_at" : "2016-06-02 15:17:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marcel Salathe",
      "screen_name" : "marcelsalathe",
      "indices" : [ 0, 14 ],
      "id_str" : "14177696",
      "id" : 14177696
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "738385849969192961",
  "geo" : { },
  "id_str" : "738386953373134848",
  "in_reply_to_user_id" : 14177696,
  "text" : "@marcelsalathe the Red Queen Hypothesis of Penis Enlargement e-Mails.",
  "id" : 738386953373134848,
  "in_reply_to_status_id" : 738385849969192961,
  "created_at" : "2016-06-02 15:09:02 +0000",
  "in_reply_to_screen_name" : "marcelsalathe",
  "in_reply_to_user_id_str" : "14177696",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "the Winnower",
      "screen_name" : "theWinnower",
      "indices" : [ 0, 12 ],
      "id_str" : "748018813",
      "id" : 748018813
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "738384626155130880",
  "geo" : { },
  "id_str" : "738385114963542017",
  "in_reply_to_user_id" : 748018813,
  "text" : "@theWinnower thanks, too bad that Sci-Hub is down right now!",
  "id" : 738385114963542017,
  "in_reply_to_status_id" : 738384626155130880,
  "created_at" : "2016-06-02 15:01:44 +0000",
  "in_reply_to_screen_name" : "theWinnower",
  "in_reply_to_user_id_str" : "748018813",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Schawinski",
      "screen_name" : "kevinschawinski",
      "indices" : [ 0, 16 ],
      "id_str" : "242844365",
      "id" : 242844365
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "738383999886839808",
  "geo" : { },
  "id_str" : "738385023104081921",
  "in_reply_to_user_id" : 242844365,
  "text" : "@kevinschawinski i see what you did there. But why not, the black turtleneck will work much better on you!",
  "id" : 738385023104081921,
  "in_reply_to_status_id" : 738383999886839808,
  "created_at" : "2016-06-02 15:01:22 +0000",
  "in_reply_to_screen_name" : "kevinschawinski",
  "in_reply_to_user_id_str" : "242844365",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Schawinski",
      "screen_name" : "kevinschawinski",
      "indices" : [ 0, 16 ],
      "id_str" : "242844365",
      "id" : 242844365
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "738383441985732608",
  "geo" : { },
  "id_str" : "738383784622559232",
  "in_reply_to_user_id" : 242844365,
  "text" : "@kevinschawinski but you\u2019re by far too settled in to generate much hype, having a fancy title and all. I on the other hand have 0 cred!",
  "id" : 738383784622559232,
  "in_reply_to_status_id" : 738383441985732608,
  "created_at" : "2016-06-02 14:56:27 +0000",
  "in_reply_to_screen_name" : "kevinschawinski",
  "in_reply_to_user_id_str" : "242844365",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Schawinski",
      "screen_name" : "kevinschawinski",
      "indices" : [ 0, 16 ],
      "id_str" : "242844365",
      "id" : 242844365
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "738381931746885632",
  "geo" : { },
  "id_str" : "738383161055383553",
  "in_reply_to_user_id" : 242844365,
  "text" : "@kevinschawinski how come I only get to be CTO? :p",
  "id" : 738383161055383553,
  "in_reply_to_status_id" : 738381931746885632,
  "created_at" : "2016-06-02 14:53:58 +0000",
  "in_reply_to_screen_name" : "kevinschawinski",
  "in_reply_to_user_id_str" : "242844365",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Schawinski",
      "screen_name" : "kevinschawinski",
      "indices" : [ 0, 16 ],
      "id_str" : "242844365",
      "id" : 242844365
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "738381494373208064",
  "geo" : { },
  "id_str" : "738381756475289600",
  "in_reply_to_user_id" : 242844365,
  "text" : "@kevinschawinski midi-chlorians.",
  "id" : 738381756475289600,
  "in_reply_to_status_id" : 738381494373208064,
  "created_at" : "2016-06-02 14:48:23 +0000",
  "in_reply_to_screen_name" : "kevinschawinski",
  "in_reply_to_user_id_str" : "242844365",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Schawinski",
      "screen_name" : "kevinschawinski",
      "indices" : [ 0, 16 ],
      "id_str" : "242844365",
      "id" : 242844365
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "738381020022624257",
  "geo" : { },
  "id_str" : "738381397329620992",
  "in_reply_to_user_id" : 242844365,
  "text" : "@kevinschawinski junk DNA has been called the dark matter of biology so often, i think it\u2019s time to cash in on it.",
  "id" : 738381397329620992,
  "in_reply_to_status_id" : 738381020022624257,
  "created_at" : "2016-06-02 14:46:58 +0000",
  "in_reply_to_screen_name" : "kevinschawinski",
  "in_reply_to_user_id_str" : "242844365",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Schawinski",
      "screen_name" : "kevinschawinski",
      "indices" : [ 0, 16 ],
      "id_str" : "242844365",
      "id" : 242844365
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "738375000164577280",
  "geo" : { },
  "id_str" : "738380311030026241",
  "in_reply_to_user_id" : 242844365,
  "text" : "@kevinschawinski but then: I wish there\u2019d be a day where my net worth drops by $4.5bn to zero.",
  "id" : 738380311030026241,
  "in_reply_to_status_id" : 738375000164577280,
  "created_at" : "2016-06-02 14:42:39 +0000",
  "in_reply_to_screen_name" : "kevinschawinski",
  "in_reply_to_user_id_str" : "242844365",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "the Winnower",
      "screen_name" : "theWinnower",
      "indices" : [ 0, 12 ],
      "id_str" : "748018813",
      "id" : 748018813
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "738378400763645952",
  "geo" : { },
  "id_str" : "738379608840671232",
  "in_reply_to_user_id" : 748018813,
  "text" : "@theWinnower thanks, I wish I could always publish my papers with that voice, rather then having the regular paper-ish tone :p",
  "id" : 738379608840671232,
  "in_reply_to_status_id" : 738378400763645952,
  "created_at" : "2016-06-02 14:39:51 +0000",
  "in_reply_to_screen_name" : "theWinnower",
  "in_reply_to_user_id_str" : "748018813",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "the Winnower",
      "screen_name" : "theWinnower",
      "indices" : [ 0, 12 ],
      "id_str" : "748018813",
      "id" : 748018813
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "738376796081651712",
  "in_reply_to_user_id" : 748018813,
  "text" : "@theWinnower Ah, that explains the huge number of views :D",
  "id" : 738376796081651712,
  "created_at" : "2016-06-02 14:28:41 +0000",
  "in_reply_to_screen_name" : "theWinnower",
  "in_reply_to_user_id_str" : "748018813",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/PWX0su8aaW",
      "expanded_url" : "https:\/\/peerj.com\/articles\/338\/",
      "display_url" : "peerj.com\/articles\/338\/"
    } ]
  },
  "geo" : { },
  "id_str" : "738362435363610624",
  "text" : "once you seriously debate doing a replication of the bee sting study you\u2019ve arrived in academia, right? https:\/\/t.co\/PWX0su8aaW",
  "id" : 738362435363610624,
  "created_at" : "2016-06-02 13:31:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 0, 8 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    }, {
      "name" : "the Winnower",
      "screen_name" : "theWinnower",
      "indices" : [ 9, 21 ],
      "id_str" : "748018813",
      "id" : 748018813
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "738332475919896576",
  "geo" : { },
  "id_str" : "738332649220145152",
  "in_reply_to_user_id" : 3865005196,
  "text" : "@o_guest @theWinnower yep, and financial resources, which limit the other two factors :)",
  "id" : 738332649220145152,
  "in_reply_to_status_id" : 738332475919896576,
  "created_at" : "2016-06-02 11:33:15 +0000",
  "in_reply_to_screen_name" : "o_guest",
  "in_reply_to_user_id_str" : "3865005196",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 0, 8 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    }, {
      "name" : "the Winnower",
      "screen_name" : "theWinnower",
      "indices" : [ 9, 21 ],
      "id_str" : "748018813",
      "id" : 748018813
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "738330696368967680",
  "geo" : { },
  "id_str" : "738332193408307200",
  "in_reply_to_user_id" : 3865005196,
  "text" : "@o_guest @theWinnower sure,just saying there might be constraints\/reasons for initial decision, even if we all don\u2019t like the outcome :D",
  "id" : 738332193408307200,
  "in_reply_to_status_id" : 738330696368967680,
  "created_at" : "2016-06-02 11:31:27 +0000",
  "in_reply_to_screen_name" : "o_guest",
  "in_reply_to_user_id_str" : "3865005196",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 0, 8 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    }, {
      "name" : "the Winnower",
      "screen_name" : "theWinnower",
      "indices" : [ 9, 21 ],
      "id_str" : "748018813",
      "id" : 748018813
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "738330259150524416",
  "geo" : { },
  "id_str" : "738330518383644672",
  "in_reply_to_user_id" : 3865005196,
  "text" : "@o_guest @theWinnower I know, my blog where the article first appeared is responsive. But a larger publishing system is != jekyll. :D",
  "id" : 738330518383644672,
  "in_reply_to_status_id" : 738330259150524416,
  "created_at" : "2016-06-02 11:24:47 +0000",
  "in_reply_to_screen_name" : "o_guest",
  "in_reply_to_user_id_str" : "3865005196",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "the Winnower",
      "screen_name" : "theWinnower",
      "indices" : [ 0, 12 ],
      "id_str" : "748018813",
      "id" : 748018813
    }, {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 13, 21 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "738328924896301057",
  "geo" : { },
  "id_str" : "738329436181921793",
  "in_reply_to_user_id" : 748018813,
  "text" : "@theWinnower @o_guest I think there\u2019s a benefit to releasing early and take it from there.",
  "id" : 738329436181921793,
  "in_reply_to_status_id" : 738328924896301057,
  "created_at" : "2016-06-02 11:20:29 +0000",
  "in_reply_to_screen_name" : "theWinnower",
  "in_reply_to_user_id_str" : "748018813",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "the Winnower",
      "screen_name" : "theWinnower",
      "indices" : [ 0, 12 ],
      "id_str" : "748018813",
      "id" : 748018813
    }, {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 13, 21 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "738328924896301057",
  "geo" : { },
  "id_str" : "738329091334627328",
  "in_reply_to_user_id" : 748018813,
  "text" : "@theWinnower @o_guest for what it\u2019s worth: openSNP has been crap on mobile for 5 years now. Hope we\u2019ll fix it this summer with the GSoC",
  "id" : 738329091334627328,
  "in_reply_to_status_id" : 738328924896301057,
  "created_at" : "2016-06-02 11:19:07 +0000",
  "in_reply_to_screen_name" : "theWinnower",
  "in_reply_to_user_id_str" : "748018813",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "the Winnower",
      "screen_name" : "theWinnower",
      "indices" : [ 0, 12 ],
      "id_str" : "748018813",
      "id" : 748018813
    }, {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 13, 21 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "738320590231195648",
  "geo" : { },
  "id_str" : "738323615616225281",
  "in_reply_to_user_id" : 748018813,
  "text" : "@theWinnower @o_guest awesome! All the best for that!",
  "id" : 738323615616225281,
  "in_reply_to_status_id" : 738320590231195648,
  "created_at" : "2016-06-02 10:57:22 +0000",
  "in_reply_to_screen_name" : "theWinnower",
  "in_reply_to_user_id_str" : "748018813",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/aX99C2yuZ4",
      "expanded_url" : "https:\/\/twitter.com\/BioMickWatson\/status\/738018258033463300",
      "display_url" : "twitter.com\/BioMickWatson\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "738310601324285952",
  "text" : "We don\u2019t create ontologies any longer. We just infer them by some deep learning. https:\/\/t.co\/aX99C2yuZ4",
  "id" : 738310601324285952,
  "created_at" : "2016-06-02 10:05:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "fernanda castano",
      "screen_name" : "ferwen",
      "indices" : [ 3, 10 ],
      "id_str" : "33123688",
      "id" : 33123688
    }, {
      "name" : "Kate Beaton",
      "screen_name" : "beatonna",
      "indices" : [ 44, 53 ],
      "id_str" : "36735522",
      "id" : 36735522
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/ferwen\/status\/738181243263582211\/photo\/1",
      "indices" : [ 54, 77 ],
      "url" : "https:\/\/t.co\/xEBlOarBbE",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cj6L7awWUAABmim.jpg",
      "id_str" : "738181241845993472",
      "id" : 738181241845993472,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cj6L7awWUAABmim.jpg",
      "sizes" : [ {
        "h" : 1956,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 243
      }, {
        "h" : 1956,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 429
      } ],
      "display_url" : "pic.twitter.com\/xEBlOarBbE"
    } ],
    "hashtags" : [ {
      "text" : "TheBoysClub",
      "indices" : [ 28, 40 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "738300955314298882",
  "text" : "RT @ferwen: Mary Anning and #TheBoysClub by @beatonna https:\/\/t.co\/xEBlOarBbE",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Kate Beaton",
        "screen_name" : "beatonna",
        "indices" : [ 32, 41 ],
        "id_str" : "36735522",
        "id" : 36735522
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ferwen\/status\/738181243263582211\/photo\/1",
        "indices" : [ 42, 65 ],
        "url" : "https:\/\/t.co\/xEBlOarBbE",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cj6L7awWUAABmim.jpg",
        "id_str" : "738181241845993472",
        "id" : 738181241845993472,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cj6L7awWUAABmim.jpg",
        "sizes" : [ {
          "h" : 1956,
          "resize" : "fit",
          "w" : 700
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 243
        }, {
          "h" : 1956,
          "resize" : "fit",
          "w" : 700
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 429
        } ],
        "display_url" : "pic.twitter.com\/xEBlOarBbE"
      } ],
      "hashtags" : [ {
        "text" : "TheBoysClub",
        "indices" : [ 16, 28 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "738181243263582211",
    "text" : "Mary Anning and #TheBoysClub by @beatonna https:\/\/t.co\/xEBlOarBbE",
    "id" : 738181243263582211,
    "created_at" : "2016-06-02 01:31:37 +0000",
    "user" : {
      "name" : "fernanda castano",
      "screen_name" : "ferwen",
      "protected" : false,
      "id_str" : "33123688",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/908413180321452033\/JxquZ77e_normal.jpg",
      "id" : 33123688,
      "verified" : false
    }
  },
  "id" : 738300955314298882,
  "created_at" : "2016-06-02 09:27:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 0, 8 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    }, {
      "name" : "the Winnower",
      "screen_name" : "theWinnower",
      "indices" : [ 9, 21 ],
      "id_str" : "748018813",
      "id" : 748018813
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "738288703093739520",
  "geo" : { },
  "id_str" : "738291276253138944",
  "in_reply_to_user_id" : 3865005196,
  "text" : "@o_guest @theWinnower haha yes, that would be awesome!",
  "id" : 738291276253138944,
  "in_reply_to_status_id" : 738288703093739520,
  "created_at" : "2016-06-02 08:48:51 +0000",
  "in_reply_to_screen_name" : "o_guest",
  "in_reply_to_user_id_str" : "3865005196",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "the Winnower",
      "screen_name" : "theWinnower",
      "indices" : [ 47, 59 ],
      "id_str" : "748018813",
      "id" : 748018813
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "scihub",
      "indices" : [ 27, 34 ]
    } ],
    "urls" : [ {
      "indices" : [ 62, 85 ],
      "url" : "https:\/\/t.co\/10q5ALk2kc",
      "expanded_url" : "https:\/\/thewinnower.com\/papers\/4715-correlating-the-sci-hub-data-with-world-bank-indicators-and-identifying-academic-use",
      "display_url" : "thewinnower.com\/papers\/4715-co\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "738275856016134144",
  "text" : "Got the first review on my #scihub analysis on @theWinnower \uD83C\uDF89 https:\/\/t.co\/10q5ALk2kc",
  "id" : 738275856016134144,
  "created_at" : "2016-06-02 07:47:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Wallace",
      "screen_name" : "statacake",
      "indices" : [ 0, 10 ],
      "id_str" : "206278738",
      "id" : 206278738
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "738070004789334017",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06099668170862, 8.818517032001328 ]
  },
  "id_str" : "738126140280299525",
  "in_reply_to_user_id" : 206278738,
  "text" : "@statacake now I can\u2019t get the melody out of my head! *dum dum dum*",
  "id" : 738126140280299525,
  "in_reply_to_status_id" : 738070004789334017,
  "created_at" : "2016-06-01 21:52:40 +0000",
  "in_reply_to_screen_name" : "statacake",
  "in_reply_to_user_id_str" : "206278738",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Wallace",
      "screen_name" : "statacake",
      "indices" : [ 3, 13 ],
      "id_str" : "206278738",
      "id" : 206278738
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "738125300668698624",
  "text" : "RT @statacake: Tidying up an old hold drive and found these 'singalong slides' from a Canadian stats conference. You're welcome. https:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/statacake\/status\/738070004789334017\/photo\/1",
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/WMNIx2aKob",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cj4mwbxXAAA_6S4.jpg",
        "id_str" : "738070002465701888",
        "id" : 738070002465701888,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cj4mwbxXAAA_6S4.jpg",
        "sizes" : [ {
          "h" : 1356,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 1428,
          "resize" : "fit",
          "w" : 2156
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 795,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/WMNIx2aKob"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/statacake\/status\/738070004789334017\/photo\/1",
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/WMNIx2aKob",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cj4mwcAWkAA-D__.jpg",
        "id_str" : "738070002528587776",
        "id" : 738070002528587776,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cj4mwcAWkAA-D__.jpg",
        "sizes" : [ {
          "h" : 418,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1360,
          "resize" : "fit",
          "w" : 2212
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 738,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 1259,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/WMNIx2aKob"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "738070004789334017",
    "text" : "Tidying up an old hold drive and found these 'singalong slides' from a Canadian stats conference. You're welcome. https:\/\/t.co\/WMNIx2aKob",
    "id" : 738070004789334017,
    "created_at" : "2016-06-01 18:09:36 +0000",
    "user" : {
      "name" : "Michael Wallace",
      "screen_name" : "statacake",
      "protected" : false,
      "id_str" : "206278738",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000543224092\/0966b130992c3e87ed7a0c32bbc769a4_normal.png",
      "id" : 206278738,
      "verified" : false
    }
  },
  "id" : 738125300668698624,
  "created_at" : "2016-06-01 21:49:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 14, 23 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "quantifiedself",
      "indices" : [ 43, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 59, 82 ],
      "url" : "https:\/\/t.co\/WVMe3OGXhz",
      "expanded_url" : "https:\/\/twitter.com\/AhistoricalPics\/status\/738063420361084928",
      "display_url" : "twitter.com\/AhistoricalPic\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "738107353212563456",
  "text" : "How I imagine @eramirez when doing serious #quantifiedself https:\/\/t.co\/WVMe3OGXhz",
  "id" : 738107353212563456,
  "created_at" : "2016-06-01 20:38:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Abby Cabunoc Mayes",
      "screen_name" : "abbycabs",
      "indices" : [ 0, 9 ],
      "id_str" : "395367768",
      "id" : 395367768
    }, {
      "name" : "BOSC",
      "screen_name" : "OBF_BOSC",
      "indices" : [ 10, 19 ],
      "id_str" : "583180584",
      "id" : 583180584
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "738066925046091776",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06105059492057, 8.81885271590955 ]
  },
  "id_str" : "738070231629828097",
  "in_reply_to_user_id" : 395367768,
  "text" : "@abbycabs @OBF_BOSC sure, will do!",
  "id" : 738070231629828097,
  "in_reply_to_status_id" : 738066925046091776,
  "created_at" : "2016-06-01 18:10:30 +0000",
  "in_reply_to_screen_name" : "abbycabs",
  "in_reply_to_user_id_str" : "395367768",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Brechler",
      "screen_name" : "gutsle",
      "indices" : [ 0, 7 ],
      "id_str" : "837535866",
      "id" : 837535866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "738060368572993540",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06016969685448, 8.817953746774064 ]
  },
  "id_str" : "738064138417635328",
  "in_reply_to_user_id" : 837535866,
  "text" : "@gutsle gerne:)",
  "id" : 738064138417635328,
  "in_reply_to_status_id" : 738060368572993540,
  "created_at" : "2016-06-01 17:46:17 +0000",
  "in_reply_to_screen_name" : "gutsle",
  "in_reply_to_user_id_str" : "837535866",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "738058740792844288",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11402895571226, 8.75341465826374 ]
  },
  "id_str" : "738059066661081088",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez great, let me check the exact times later!",
  "id" : 738059066661081088,
  "in_reply_to_status_id" : 738058740792844288,
  "created_at" : "2016-06-01 17:26:08 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "738057537413472257",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1140349256897, 8.753432382552315 ]
  },
  "id_str" : "738058633112604672",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez was more wondering whether you\u2019d be in town then!",
  "id" : 738058633112604672,
  "in_reply_to_status_id" : 738057537413472257,
  "created_at" : "2016-06-01 17:24:25 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "738056710611337217",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11403426291098, 8.753424402766367 ]
  },
  "id_str" : "738057313307791362",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez let me check that. By the way: on July 7th I\u2019ll be in LAX for 3 hours!",
  "id" : 738057313307791362,
  "in_reply_to_status_id" : 738056710611337217,
  "created_at" : "2016-06-01 17:19:10 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/738056151988883457\/photo\/1",
      "indices" : [ 15, 38 ],
      "url" : "https:\/\/t.co\/kJr2ZUEsNO",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cj4aJDVW0AA44Bj.jpg",
      "id_str" : "738056131751366656",
      "id" : 738056131751366656,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cj4aJDVW0AA44Bj.jpg",
      "sizes" : [ {
        "h" : 4032,
        "resize" : "fit",
        "w" : 3024
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      } ],
      "display_url" : "pic.twitter.com\/kJr2ZUEsNO"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11403343596833, 8.753424365991119 ]
  },
  "id_str" : "738056151988883457",
  "text" : "Yay, stickers! https:\/\/t.co\/kJr2ZUEsNO",
  "id" : 738056151988883457,
  "created_at" : "2016-06-01 17:14:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kaitlin Thaney \uD83D\uDC81\uD83C\uDFFB",
      "screen_name" : "kaythaney",
      "indices" : [ 3, 13 ],
      "id_str" : "22839233",
      "id" : 22839233
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mozsprint",
      "indices" : [ 49, 59 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "738045984895291393",
  "text" : "RT @kaythaney: There\u2019s something for everyone at #mozsprint - devs, designers, advocates. Have a look at the projects: https:\/\/t.co\/loSfqJY\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "mozsprint",
        "indices" : [ 34, 44 ]
      }, {
        "text" : "openscience",
        "indices" : [ 128, 140 ]
      } ],
      "urls" : [ {
        "indices" : [ 104, 127 ],
        "url" : "https:\/\/t.co\/loSfqJYY0n",
        "expanded_url" : "https:\/\/github.com\/mozillascience\/global-sprint-2016",
        "display_url" : "github.com\/mozillascience\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "737986625167314944",
    "text" : "There\u2019s something for everyone at #mozsprint - devs, designers, advocates. Have a look at the projects: https:\/\/t.co\/loSfqJYY0n #openscience",
    "id" : 737986625167314944,
    "created_at" : "2016-06-01 12:38:17 +0000",
    "user" : {
      "name" : "Kaitlin Thaney \uD83D\uDC81\uD83C\uDFFB",
      "screen_name" : "kaythaney",
      "protected" : false,
      "id_str" : "22839233",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/932288468029509632\/_I0e0wgc_normal.jpg",
      "id" : 22839233,
      "verified" : false
    }
  },
  "id" : 738045984895291393,
  "created_at" : "2016-06-01 16:34:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/AES06t9Fro",
      "expanded_url" : "http:\/\/www.forbes.com\/sites\/matthewherper\/2016\/06\/01\/from-4-5-billion-to-nothing-forbes-revises-estimated-net-worth-of-theranos-founder-elizabeth-holmes\/#250591ba2f29",
      "display_url" : "forbes.com\/sites\/matthewh\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "737973360358002688",
  "text" : "From $4.5 Billion To Nothing: Forbes Revises Estimated Net Worth Of Theranos Founder Elizabeth Holmes https:\/\/t.co\/AES06t9Fro",
  "id" : 737973360358002688,
  "created_at" : "2016-06-01 11:45:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 58 ],
      "url" : "https:\/\/t.co\/TFZYr2HydP",
      "expanded_url" : "https:\/\/twitter.com\/arundurvasula\/status\/737925895227330560",
      "display_url" : "twitter.com\/arundurvasula\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17245074586324, 8.627524991001746 ]
  },
  "id_str" : "737931486045863936",
  "text" : "Happens to everyone at least once. https:\/\/t.co\/TFZYr2HydP",
  "id" : 737931486045863936,
  "created_at" : "2016-06-01 08:59:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rossalyn Warren",
      "screen_name" : "RossalynWarren",
      "indices" : [ 3, 18 ],
      "id_str" : "177661775",
      "id" : 177661775
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/LJR1gXK9sk",
      "expanded_url" : "http:\/\/nyti.ms\/1r25ZWg",
      "display_url" : "nyti.ms\/1r25ZWg"
    } ]
  },
  "geo" : { },
  "id_str" : "737923280355655680",
  "text" : "RT @RossalynWarren: \"keep calm. And yes I'm a feminist.\" - an actors \"feminist\" tattoo causes meltdown in Iran https:\/\/t.co\/LJR1gXK9sk http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/RossalynWarren\/status\/737899211501494272\/photo\/1",
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/K9o8UrzyAn",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cj2LasPXEAAvwd7.jpg",
        "id_str" : "737899204627075072",
        "id" : 737899204627075072,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cj2LasPXEAAvwd7.jpg",
        "sizes" : [ {
          "h" : 560,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 560,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 560,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 381,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/K9o8UrzyAn"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 91, 114 ],
        "url" : "https:\/\/t.co\/LJR1gXK9sk",
        "expanded_url" : "http:\/\/nyti.ms\/1r25ZWg",
        "display_url" : "nyti.ms\/1r25ZWg"
      } ]
    },
    "geo" : { },
    "id_str" : "737899211501494272",
    "text" : "\"keep calm. And yes I'm a feminist.\" - an actors \"feminist\" tattoo causes meltdown in Iran https:\/\/t.co\/LJR1gXK9sk https:\/\/t.co\/K9o8UrzyAn",
    "id" : 737899211501494272,
    "created_at" : "2016-06-01 06:50:56 +0000",
    "user" : {
      "name" : "Rossalyn Warren",
      "screen_name" : "RossalynWarren",
      "protected" : false,
      "id_str" : "177661775",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/927112604664979456\/5U2aTeyE_normal.jpg",
      "id" : 177661775,
      "verified" : true
    }
  },
  "id" : 737923280355655680,
  "created_at" : "2016-06-01 08:26:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Blin",
      "screen_name" : "kaiblin",
      "indices" : [ 0, 8 ],
      "id_str" : "124202458",
      "id" : 124202458
    }, {
      "name" : "Willem van Schaik",
      "screen_name" : "WvSchaik",
      "indices" : [ 9, 18 ],
      "id_str" : "18585425",
      "id" : 18585425
    }, {
      "name" : "Jennifer Gardy",
      "screen_name" : "jennifergardy",
      "indices" : [ 19, 33 ],
      "id_str" : "20478716",
      "id" : 20478716
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "737920436298747907",
  "geo" : { },
  "id_str" : "737921559852109824",
  "in_reply_to_user_id" : 124202458,
  "text" : "@kaiblin @WvSchaik @jennifergardy those pesky Austrians ;)",
  "id" : 737921559852109824,
  "in_reply_to_status_id" : 737920436298747907,
  "created_at" : "2016-06-01 08:19:44 +0000",
  "in_reply_to_screen_name" : "kaiblin",
  "in_reply_to_user_id_str" : "124202458",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Blin",
      "screen_name" : "kaiblin",
      "indices" : [ 0, 8 ],
      "id_str" : "124202458",
      "id" : 124202458
    }, {
      "name" : "Willem van Schaik",
      "screen_name" : "WvSchaik",
      "indices" : [ 9, 18 ],
      "id_str" : "18585425",
      "id" : 18585425
    }, {
      "name" : "Jennifer Gardy",
      "screen_name" : "jennifergardy",
      "indices" : [ 19, 33 ],
      "id_str" : "20478716",
      "id" : 20478716
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 85 ],
      "url" : "https:\/\/t.co\/RZzZQRd3Xu",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/Z52Vkyhwvc\/",
      "display_url" : "instagram.com\/p\/Z52Vkyhwvc\/"
    } ]
  },
  "in_reply_to_status_id_str" : "737875298646102020",
  "geo" : { },
  "id_str" : "737920053455257600",
  "in_reply_to_user_id" : 124202458,
  "text" : "@kaiblin @WvSchaik @jennifergardy happens, this is in my lab: https:\/\/t.co\/RZzZQRd3Xu",
  "id" : 737920053455257600,
  "in_reply_to_status_id" : 737875298646102020,
  "created_at" : "2016-06-01 08:13:45 +0000",
  "in_reply_to_screen_name" : "kaiblin",
  "in_reply_to_user_id_str" : "124202458",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shaun Jackman",
      "screen_name" : "sjackman",
      "indices" : [ 0, 9 ],
      "id_str" : "8779352",
      "id" : 8779352
    }, {
      "name" : "Torsten Seemann",
      "screen_name" : "torstenseemann",
      "indices" : [ 10, 25 ],
      "id_str" : "42558652",
      "id" : 42558652
    }, {
      "name" : "SPAdes assembler",
      "screen_name" : "spadesassembler",
      "indices" : [ 26, 42 ],
      "id_str" : "569820386",
      "id" : 569820386
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "737873214697791489",
  "geo" : { },
  "id_str" : "737919628408696832",
  "in_reply_to_user_id" : 8779352,
  "text" : "@sjackman @torstenseemann @spadesassembler +1 to that wish!",
  "id" : 737919628408696832,
  "in_reply_to_status_id" : 737873214697791489,
  "created_at" : "2016-06-01 08:12:03 +0000",
  "in_reply_to_screen_name" : "sjackman",
  "in_reply_to_user_id_str" : "8779352",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jillemery",
      "screen_name" : "jillemery",
      "indices" : [ 0, 10 ],
      "id_str" : "11385492",
      "id" : 11385492
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "737876124114509825",
  "geo" : { },
  "id_str" : "737915163307823104",
  "in_reply_to_user_id" : 11385492,
  "text" : "@jillemery close: traditional Vietnamese folk song(s) :p",
  "id" : 737915163307823104,
  "in_reply_to_status_id" : 737876124114509825,
  "created_at" : "2016-06-01 07:54:19 +0000",
  "in_reply_to_screen_name" : "jillemery",
  "in_reply_to_user_id_str" : "11385492",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/rcUlGanfXD",
      "expanded_url" : "http:\/\/99percentinvisible.org\/article\/paternoster-lifts-cyclic-chain-elevators-no-buttons-doors-stops\/",
      "display_url" : "99percentinvisible.org\/article\/patern\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "737911366535815169",
  "text" : "99pi on Paternoster Lifts and their heirs, including the Hitachi Magic Elevator. https:\/\/t.co\/rcUlGanfXD",
  "id" : 737911366535815169,
  "created_at" : "2016-06-01 07:39:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Roman Mars",
      "screen_name" : "romanmars",
      "indices" : [ 5, 15 ],
      "id_str" : "8198012",
      "id" : 8198012
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 85 ],
      "url" : "https:\/\/t.co\/0KlcUwktNZ",
      "expanded_url" : "https:\/\/twitter.com\/rands\/status\/737775448978030597",
      "display_url" : "twitter.com\/rands\/status\/7\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11403372697216, 8.75342506261358 ]
  },
  "id_str" : "737782107083317249",
  "text" : "omg, @romanmars, did you see these visual flag stories yet? \uD83D\uDE0D https:\/\/t.co\/0KlcUwktNZ",
  "id" : 737782107083317249,
  "created_at" : "2016-05-31 23:05:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bi\u24D0nca Kramer",
      "screen_name" : "MsPhelps",
      "indices" : [ 0, 9 ],
      "id_str" : "22963112",
      "id" : 22963112
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "737768557656834048",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11379688439609, 8.753633990089721 ]
  },
  "id_str" : "737768920082481152",
  "in_reply_to_user_id" : 22963112,
  "text" : "@MsPhelps nice!",
  "id" : 737768920082481152,
  "in_reply_to_status_id" : 737768557656834048,
  "created_at" : "2016-05-31 22:13:12 +0000",
  "in_reply_to_screen_name" : "MsPhelps",
  "in_reply_to_user_id_str" : "22963112",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bi\u24D0nca Kramer",
      "screen_name" : "MsPhelps",
      "indices" : [ 0, 9 ],
      "id_str" : "22963112",
      "id" : 22963112
    }, {
      "name" : "TITCHENER BOOTY",
      "screen_name" : "titchener",
      "indices" : [ 10, 20 ],
      "id_str" : "774759032636727300",
      "id" : 774759032636727300
    }, {
      "name" : "the Winnower",
      "screen_name" : "theWinnower",
      "indices" : [ 21, 33 ],
      "id_str" : "748018813",
      "id" : 748018813
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "737766930896027648",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11386376539696, 8.753605809712628 ]
  },
  "id_str" : "737767501476581376",
  "in_reply_to_user_id" : 22963112,
  "text" : "@MsPhelps @Titchener @theWinnower fully understand that. If you want any help with the analyses let me know. :)",
  "id" : 737767501476581376,
  "in_reply_to_status_id" : 737766930896027648,
  "created_at" : "2016-05-31 22:07:34 +0000",
  "in_reply_to_screen_name" : "MsPhelps",
  "in_reply_to_user_id_str" : "22963112",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bi\u24D0nca Kramer",
      "screen_name" : "MsPhelps",
      "indices" : [ 0, 9 ],
      "id_str" : "22963112",
      "id" : 22963112
    }, {
      "name" : "TITCHENER BOOTY",
      "screen_name" : "titchener",
      "indices" : [ 10, 20 ],
      "id_str" : "774759032636727300",
      "id" : 774759032636727300
    }, {
      "name" : "the Winnower",
      "screen_name" : "theWinnower",
      "indices" : [ 21, 33 ],
      "id_str" : "748018813",
      "id" : 748018813
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "737765839911452672",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11386847811989, 8.75359903734834 ]
  },
  "id_str" : "737765967850246144",
  "in_reply_to_user_id" : 22963112,
  "text" : "@MsPhelps @Titchener @theWinnower great, looking forward to see that!",
  "id" : 737765967850246144,
  "in_reply_to_status_id" : 737765839911452672,
  "created_at" : "2016-05-31 22:01:28 +0000",
  "in_reply_to_screen_name" : "MsPhelps",
  "in_reply_to_user_id_str" : "22963112",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
} ]