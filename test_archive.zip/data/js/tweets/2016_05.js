Grailbird.data.tweets_2016_05 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "737759774050127872",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11403543448667, 8.753426153929773 ]
  },
  "id_str" : "737760547156983808",
  "in_reply_to_user_id" : 2336311404,
  "text" : "@TAT_ITB thanks, will have a look!",
  "id" : 737760547156983808,
  "in_reply_to_status_id" : 737759774050127872,
  "created_at" : "2016-05-31 21:39:56 +0000",
  "in_reply_to_screen_name" : "HydrogeoITB",
  "in_reply_to_user_id_str" : "2336311404",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "737758688727859200",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11403379273634, 8.753423550509883 ]
  },
  "id_str" : "737758849294295040",
  "in_reply_to_user_id" : 2336311404,
  "text" : "@TAT_ITB if you should find the time and feel like it: a short review on the winnower would be much appreciated!",
  "id" : 737758849294295040,
  "in_reply_to_status_id" : 737758688727859200,
  "created_at" : "2016-05-31 21:33:11 +0000",
  "in_reply_to_screen_name" : "HydrogeoITB",
  "in_reply_to_user_id_str" : "2336311404",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "737756263681953792",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11403124382397, 8.753417958496923 ]
  },
  "id_str" : "737758331369050112",
  "in_reply_to_user_id" : 2336311404,
  "text" : "@TAT_ITB thanks!",
  "id" : 737758331369050112,
  "in_reply_to_status_id" : 737756263681953792,
  "created_at" : "2016-05-31 21:31:07 +0000",
  "in_reply_to_screen_name" : "HydrogeoITB",
  "in_reply_to_user_id_str" : "2336311404",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "the Winnower",
      "screen_name" : "theWinnower",
      "indices" : [ 0, 12 ],
      "id_str" : "748018813",
      "id" : 748018813
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "737742211635417088",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11406363562575, 8.753298061924351 ]
  },
  "id_str" : "737755441002913792",
  "in_reply_to_user_id" : 748018813,
  "text" : "@theWinnower a very similar joke was made in our lab at that point \uD83D\uDE02",
  "id" : 737755441002913792,
  "in_reply_to_status_id" : 737742211635417088,
  "created_at" : "2016-05-31 21:19:38 +0000",
  "in_reply_to_screen_name" : "theWinnower",
  "in_reply_to_user_id_str" : "748018813",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "737734303765925888",
  "text" : "\u00ABLet\u2019s start a band inside our research group\u00BB \u2013 \u00ABI only know a single song on guitar\u00BB \u2013 \u00ABSo we even have a band name: The One-Trick Ponies\u00BB",
  "id" : 737734303765925888,
  "created_at" : "2016-05-31 19:55:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TNT Media Hub",
      "screen_name" : "TNTMediaHub",
      "indices" : [ 75, 87 ],
      "id_str" : "264071434",
      "id" : 264071434
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "737706890378027008",
  "geo" : { },
  "id_str" : "737708087205892097",
  "in_reply_to_user_id" : 14286491,
  "text" : "Only found out because I contacted them &amp; now every day I need to tell @TNTMediaHub that I sent all the documents they need a week ago\u2026",
  "id" : 737708087205892097,
  "in_reply_to_status_id" : 737706890378027008,
  "created_at" : "2016-05-31 18:11:28 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TNT Media Hub",
      "screen_name" : "TNTMediaHub",
      "indices" : [ 17, 29 ],
      "id_str" : "264071434",
      "id" : 264071434
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "737706890378027008",
  "text" : "Now I\u2019m emailing @TNTMediahub 2x a day for info on a package that\u2019s already waiting in customs for 1 month because they didn\u2019t contact me\u2026",
  "id" : 737706890378027008,
  "created_at" : "2016-05-31 18:06:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "737668797335777280",
  "text" : "This literature research is so depressing. Has anyone here ever seen any convincing evidence for horizontal gene transfers into fungi?",
  "id" : 737668797335777280,
  "created_at" : "2016-05-31 15:35:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marcel Salathe",
      "screen_name" : "marcelsalathe",
      "indices" : [ 0, 14 ],
      "id_str" : "14177696",
      "id" : 14177696
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "737553778749018112",
  "geo" : { },
  "id_str" : "737613515402272768",
  "in_reply_to_user_id" : 14177696,
  "text" : "@marcelsalathe oh yes, those two and the personal hotspot: lots of turning it off and on again.",
  "id" : 737613515402272768,
  "in_reply_to_status_id" : 737553778749018112,
  "created_at" : "2016-05-31 11:55:40 +0000",
  "in_reply_to_screen_name" : "marcelsalathe",
  "in_reply_to_user_id_str" : "14177696",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/10q5AL2qVC",
      "expanded_url" : "https:\/\/thewinnower.com\/papers\/4715-correlating-the-sci-hub-data-with-world-bank-indicators-and-identifying-academic-use",
      "display_url" : "thewinnower.com\/papers\/4715-co\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "737609253238636545",
  "text" : "ICYMI: I\u2019m still looking for reviewers for my work on the Sci-Hub data. https:\/\/t.co\/10q5AL2qVC",
  "id" : 737609253238636545,
  "created_at" : "2016-05-31 11:38:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "The_Smoking_GNU",
      "indices" : [ 0, 16 ],
      "id_str" : "14535787",
      "id" : 14535787
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "737600114445803522",
  "geo" : { },
  "id_str" : "737601713725546498",
  "in_reply_to_user_id" : 14535787,
  "text" : "@The_Smoking_GNU It\u2019s not the complete timeline tbh. It\u2019s the last 1000 tweets. Tweetbot can\u2019t background-store more I think.",
  "id" : 737601713725546498,
  "in_reply_to_status_id" : 737600114445803522,
  "created_at" : "2016-05-31 11:08:47 +0000",
  "in_reply_to_screen_name" : "The_Smoking_GNU",
  "in_reply_to_user_id_str" : "14535787",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/medium.com\" rel=\"nofollow\"\u003EMedium\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nazeefa",
      "screen_name" : "NazeefaFatima",
      "indices" : [ 36, 50 ],
      "id_str" : "37054704",
      "id" : 37054704
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/737551924883427330\/photo\/1",
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/amwgVhBuop",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CjxPkORUoAAgeUr.jpg",
      "id_str" : "737551922706554880",
      "id" : 737551922706554880,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CjxPkORUoAAgeUr.jpg",
      "sizes" : [ {
        "h" : 791,
        "resize" : "fit",
        "w" : 750
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 791,
        "resize" : "fit",
        "w" : 750
      }, {
        "h" : 791,
        "resize" : "fit",
        "w" : 750
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 645
      } ],
      "display_url" : "pic.twitter.com\/amwgVhBuop"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 74 ],
      "url" : "https:\/\/t.co\/jXCCSiFVEb",
      "expanded_url" : "https:\/\/medium.com\/@tpoi\/are-you-a-scientist-do-not-learn-how-to-code-just-yet-690528f1da8d#---51-405.ga64f1vrn",
      "display_url" : "medium.com\/@tpoi\/are-you-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "737551924883427330",
  "text" : "Coding while being a scientist. \/HT @nazeefafatima https:\/\/t.co\/jXCCSiFVEb https:\/\/t.co\/amwgVhBuop",
  "id" : 737551924883427330,
  "created_at" : "2016-05-31 07:50:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Iara VPS",
      "screen_name" : "iaravps",
      "indices" : [ 0, 8 ],
      "id_str" : "173881525",
      "id" : 173881525
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "737439845660950533",
  "geo" : { },
  "id_str" : "737440802113265664",
  "in_reply_to_user_id" : 173881525,
  "text" : "@iaravps yes, it happens sometimes. Asking about the last book(s) I read works as well ;)",
  "id" : 737440802113265664,
  "in_reply_to_status_id" : 737439845660950533,
  "created_at" : "2016-05-31 00:29:22 +0000",
  "in_reply_to_screen_name" : "iaravps",
  "in_reply_to_user_id_str" : "173881525",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Iara VPS",
      "screen_name" : "iaravps",
      "indices" : [ 0, 8 ],
      "id_str" : "173881525",
      "id" : 173881525
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "737436773693935616",
  "geo" : { },
  "id_str" : "737437422619873280",
  "in_reply_to_user_id" : 173881525,
  "text" : "@iaravps yes, so far all the good first messages I received made mention of the cat that\u2019s along with me in the profile picture.",
  "id" : 737437422619873280,
  "in_reply_to_status_id" : 737436773693935616,
  "created_at" : "2016-05-31 00:15:57 +0000",
  "in_reply_to_screen_name" : "iaravps",
  "in_reply_to_user_id_str" : "173881525",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 80 ],
      "url" : "https:\/\/t.co\/Hn2ery3TUv",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/737432575086583808",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "737432575086583808",
  "geo" : { },
  "id_str" : "737432822772813824",
  "in_reply_to_user_id" : 14286491,
  "text" : "Also: I\u2019m looking forward to getting some reviews on it! https:\/\/t.co\/Hn2ery3TUv",
  "id" : 737432822772813824,
  "in_reply_to_status_id" : 737432575086583808,
  "created_at" : "2016-05-30 23:57:40 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "the Winnower",
      "screen_name" : "theWinnower",
      "indices" : [ 8, 20 ],
      "id_str" : "748018813",
      "id" : 748018813
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "scihub",
      "indices" : [ 101, 108 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/10q5ALk2kc",
      "expanded_url" : "https:\/\/thewinnower.com\/papers\/4715-correlating-the-sci-hub-data-with-world-bank-indicators-and-identifying-academic-use",
      "display_url" : "thewinnower.com\/papers\/4715-co\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "737432575086583808",
  "text" : "I think @theWinnower has to be my favorite way of publishing, w\/ the nicest editors. Find my work on #scihub there: https:\/\/t.co\/10q5ALk2kc",
  "id" : 737432575086583808,
  "created_at" : "2016-05-30 23:56:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sebastian Greiner",
      "screen_name" : "Seb666",
      "indices" : [ 0, 7 ],
      "id_str" : "2365333778",
      "id" : 2365333778
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "737411974519238656",
  "geo" : { },
  "id_str" : "737412473981132806",
  "in_reply_to_user_id" : 2365333778,
  "text" : "@Seb666 ging mir genauso. :(",
  "id" : 737412473981132806,
  "in_reply_to_status_id" : 737411974519238656,
  "created_at" : "2016-05-30 22:36:48 +0000",
  "in_reply_to_screen_name" : "Seb666",
  "in_reply_to_user_id_str" : "2365333778",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sebastian Greiner",
      "screen_name" : "Seb666",
      "indices" : [ 0, 7 ],
      "id_str" : "2365333778",
      "id" : 2365333778
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "737411510293651456",
  "geo" : { },
  "id_str" : "737411698328539137",
  "in_reply_to_user_id" : 2365333778,
  "text" : "@Seb666 damit dein Notebook jetzt auch vergessen kann welche Sprache du sprichst, nicht nur welche du tippst! \uD83D\uDC4D",
  "id" : 737411698328539137,
  "in_reply_to_status_id" : 737411510293651456,
  "created_at" : "2016-05-30 22:33:43 +0000",
  "in_reply_to_screen_name" : "Seb666",
  "in_reply_to_user_id_str" : "2365333778",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "737403411654709248",
  "text" : "What I wanted to do: Update my blog. What I did instead: Recompiled Ruby because I somehow destroyed RVM on this machine. \u00AF\\_(\u30C4)_\/\u00AF",
  "id" : 737403411654709248,
  "created_at" : "2016-05-30 22:00:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "737385455843442688",
  "text" : "I might have to declare email bankruptcy, but at least I read all of my timeline\u2026",
  "id" : 737385455843442688,
  "created_at" : "2016-05-30 20:49:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emily G, Cville.",
      "screen_name" : "EmilyGorcenski",
      "indices" : [ 0, 15 ],
      "id_str" : "1483064670",
      "id" : 1483064670
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "737377787917504512",
  "geo" : { },
  "id_str" : "737384660846645248",
  "in_reply_to_user_id" : 1483064670,
  "text" : "@EmilyGorcenski the weird things we do in our spare time.",
  "id" : 737384660846645248,
  "in_reply_to_status_id" : 737377787917504512,
  "created_at" : "2016-05-30 20:46:17 +0000",
  "in_reply_to_screen_name" : "EmilyGorcenski",
  "in_reply_to_user_id_str" : "1483064670",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Loman",
      "screen_name" : "pathogenomenick",
      "indices" : [ 0, 16 ],
      "id_str" : "85906238",
      "id" : 85906238
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "737351726383124482",
  "geo" : { },
  "id_str" : "737383070769287168",
  "in_reply_to_user_id" : 85906238,
  "text" : "@pathogenomenick oh, so from now on it\u2019s replacing \uD83D\uDCCE with \u26CFand doing: \u00ABIt looks like you are crafting a letter\u2026\u00BB",
  "id" : 737383070769287168,
  "in_reply_to_status_id" : 737351726383124482,
  "created_at" : "2016-05-30 20:39:58 +0000",
  "in_reply_to_screen_name" : "pathogenomenick",
  "in_reply_to_user_id_str" : "85906238",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bruno Skvorc",
      "screen_name" : "bitfalls",
      "indices" : [ 3, 12 ],
      "id_str" : "125083073",
      "id" : 125083073
    }, {
      "name" : "Elio Qoshi",
      "screen_name" : "elioqoshi",
      "indices" : [ 21, 31 ],
      "id_str" : "93434375",
      "id" : 93434375
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/rks9gFev2i",
      "expanded_url" : "https:\/\/www.patreon.com\/posts\/introducing-5555844",
      "display_url" : "patreon.com\/posts\/introduc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "737382349797793792",
  "text" : "RT @bitfalls: My pal @elioqoshi is doing something fresh with logo design - open sourcing it. Support him! https:\/\/t.co\/rks9gFev2i https:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Elio Qoshi",
        "screen_name" : "elioqoshi",
        "indices" : [ 7, 17 ],
        "id_str" : "93434375",
        "id" : 93434375
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/bitfalls\/status\/737345505529856001\/photo\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/ArzQgYLUG1",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CjuTwrxWgAAI30a.jpg",
        "id_str" : "737345428597932032",
        "id" : 737345428597932032,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CjuTwrxWgAAI30a.jpg",
        "sizes" : [ {
          "h" : 1000,
          "resize" : "fit",
          "w" : 1500
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1000,
          "resize" : "fit",
          "w" : 1500
        } ],
        "display_url" : "pic.twitter.com\/ArzQgYLUG1"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 93, 116 ],
        "url" : "https:\/\/t.co\/rks9gFev2i",
        "expanded_url" : "https:\/\/www.patreon.com\/posts\/introducing-5555844",
        "display_url" : "patreon.com\/posts\/introduc\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "737345505529856001",
    "text" : "My pal @elioqoshi is doing something fresh with logo design - open sourcing it. Support him! https:\/\/t.co\/rks9gFev2i https:\/\/t.co\/ArzQgYLUG1",
    "id" : 737345505529856001,
    "created_at" : "2016-05-30 18:10:42 +0000",
    "user" : {
      "name" : "Bruno Skvorc",
      "screen_name" : "bitfalls",
      "protected" : false,
      "id_str" : "125083073",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/824885268809347072\/qXAJ_ItT_normal.jpg",
      "id" : 125083073,
      "verified" : true
    }
  },
  "id" : 737382349797793792,
  "created_at" : "2016-05-30 20:37:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/XIfoanssb9",
      "expanded_url" : "https:\/\/media2.giphy.com\/media\/y9v6gGKHjBX7W\/200.gif",
      "display_url" : "media2.giphy.com\/media\/y9v6gGKH\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "737357405592358913",
  "text" : "12h of manually curating results, to not accidentally go tardigate v2. Fully get why people like trusting algorithms https:\/\/t.co\/XIfoanssb9",
  "id" : 737357405592358913,
  "created_at" : "2016-05-30 18:57:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 53 ],
      "url" : "https:\/\/t.co\/N4yxZFIVhC",
      "expanded_url" : "https:\/\/twitter.com\/OBF_BOSC\/status\/736238398717845504",
      "display_url" : "twitter.com\/OBF_BOSC\/statu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "737192258399784961",
  "text" : "Really looking forward to it! https:\/\/t.co\/N4yxZFIVhC",
  "id" : 737192258399784961,
  "created_at" : "2016-05-30 08:01:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Iara VPS",
      "screen_name" : "iaravps",
      "indices" : [ 0, 8 ],
      "id_str" : "173881525",
      "id" : 173881525
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "737066838706814976",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11403655426571, 8.753439195654423 ]
  },
  "id_str" : "737166596393828352",
  "in_reply_to_user_id" : 173881525,
  "text" : "@iaravps yes, it\u2019s a very mixed bag of experiences for me. The way people approach you can be just ridiculous.",
  "id" : 737166596393828352,
  "in_reply_to_status_id" : 737066838706814976,
  "created_at" : "2016-05-30 06:19:47 +0000",
  "in_reply_to_screen_name" : "iaravps",
  "in_reply_to_user_id_str" : "173881525",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11403203813215, 8.753414033878816 ]
  },
  "id_str" : "737060341595705346",
  "text" : "\u00ABI found you on OkCupid  searching without a location or interest filter\u2026\u00BB\u2014\u00ABThe \u2018feeling desperate tonight\u2019 settings: \u2018Gimme any of those\u2019!\u00BB",
  "id" : 737060341595705346,
  "created_at" : "2016-05-29 23:17:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert Davey",
      "screen_name" : "froggleston",
      "indices" : [ 0, 12 ],
      "id_str" : "53893339",
      "id" : 53893339
    }, {
      "name" : "Abby Cabunoc Mayes",
      "screen_name" : "abbycabs",
      "indices" : [ 13, 22 ],
      "id_str" : "395367768",
      "id" : 395367768
    }, {
      "name" : "\u24EA Rik Smith-Unna \uD83C\uDDF0\uD83C\uDDEA",
      "screen_name" : "blahah404",
      "indices" : [ 23, 33 ],
      "id_str" : "99173786",
      "id" : 99173786
    }, {
      "name" : "Jure Triglav",
      "screen_name" : "juretriglav",
      "indices" : [ 34, 46 ],
      "id_str" : "15528719",
      "id" : 15528719
    }, {
      "name" : "Christie Bahlai",
      "screen_name" : "cbahlai",
      "indices" : [ 47, 55 ],
      "id_str" : "958649520",
      "id" : 958649520
    }, {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 56, 64 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "736300730697551872",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11353206841453, 8.754029361050451 ]
  },
  "id_str" : "736309996422635520",
  "in_reply_to_user_id" : 53893339,
  "text" : "@froggleston @abbycabs @blahah404 @juretriglav @cbahlai @o_guest totally my style! :D",
  "id" : 736309996422635520,
  "in_reply_to_status_id" : 736300730697551872,
  "created_at" : "2016-05-27 21:35:57 +0000",
  "in_reply_to_screen_name" : "froggleston",
  "in_reply_to_user_id_str" : "53893339",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Abby Cabunoc Mayes",
      "screen_name" : "abbycabs",
      "indices" : [ 0, 9 ],
      "id_str" : "395367768",
      "id" : 395367768
    }, {
      "name" : "\u24EA Rik Smith-Unna \uD83C\uDDF0\uD83C\uDDEA",
      "screen_name" : "blahah404",
      "indices" : [ 10, 20 ],
      "id_str" : "99173786",
      "id" : 99173786
    }, {
      "name" : "Robert Davey",
      "screen_name" : "froggleston",
      "indices" : [ 21, 33 ],
      "id_str" : "53893339",
      "id" : 53893339
    }, {
      "name" : "Jure Triglav",
      "screen_name" : "juretriglav",
      "indices" : [ 34, 46 ],
      "id_str" : "15528719",
      "id" : 15528719
    }, {
      "name" : "Christie Bahlai",
      "screen_name" : "cbahlai",
      "indices" : [ 47, 55 ],
      "id_str" : "958649520",
      "id" : 958649520
    }, {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 56, 64 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "736290438890586113",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11386883043934, 8.753660216676838 ]
  },
  "id_str" : "736295596802363396",
  "in_reply_to_user_id" : 395367768,
  "text" : "@abbycabs @blahah404 @froggleston @juretriglav @cbahlai @o_guest CC-0 on the back of my hand, same position as Darwin on left?:D",
  "id" : 736295596802363396,
  "in_reply_to_status_id" : 736290438890586113,
  "created_at" : "2016-05-27 20:38:44 +0000",
  "in_reply_to_screen_name" : "abbycabs",
  "in_reply_to_user_id_str" : "395367768",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u24EA Rik Smith-Unna \uD83C\uDDF0\uD83C\uDDEA",
      "screen_name" : "blahah404",
      "indices" : [ 0, 10 ],
      "id_str" : "99173786",
      "id" : 99173786
    }, {
      "name" : "Abby Cabunoc Mayes",
      "screen_name" : "abbycabs",
      "indices" : [ 11, 20 ],
      "id_str" : "395367768",
      "id" : 395367768
    }, {
      "name" : "Robert Davey",
      "screen_name" : "froggleston",
      "indices" : [ 21, 33 ],
      "id_str" : "53893339",
      "id" : 53893339
    }, {
      "name" : "Jure Triglav",
      "screen_name" : "juretriglav",
      "indices" : [ 34, 46 ],
      "id_str" : "15528719",
      "id" : 15528719
    }, {
      "name" : "Christie Bahlai",
      "screen_name" : "cbahlai",
      "indices" : [ 47, 55 ],
      "id_str" : "958649520",
      "id" : 958649520
    }, {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 56, 64 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "736287725767274496",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11406861144827, 8.75328997085832 ]
  },
  "id_str" : "736288112666628096",
  "in_reply_to_user_id" : 99173786,
  "text" : "@blahah404 @abbycabs @froggleston @juretriglav @cbahlai @o_guest still wondering whether the CC logo would make a nice one.",
  "id" : 736288112666628096,
  "in_reply_to_status_id" : 736287725767274496,
  "created_at" : "2016-05-27 20:09:00 +0000",
  "in_reply_to_screen_name" : "blahah404",
  "in_reply_to_user_id_str" : "99173786",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Abby Cabunoc Mayes",
      "screen_name" : "abbycabs",
      "indices" : [ 0, 9 ],
      "id_str" : "395367768",
      "id" : 395367768
    }, {
      "name" : "Robert Davey",
      "screen_name" : "froggleston",
      "indices" : [ 10, 22 ],
      "id_str" : "53893339",
      "id" : 53893339
    }, {
      "name" : "\u24EA Rik Smith-Unna \uD83C\uDDF0\uD83C\uDDEA",
      "screen_name" : "blahah404",
      "indices" : [ 23, 33 ],
      "id_str" : "99173786",
      "id" : 99173786
    }, {
      "name" : "Jure Triglav",
      "screen_name" : "juretriglav",
      "indices" : [ 34, 46 ],
      "id_str" : "15528719",
      "id" : 15528719
    }, {
      "name" : "Christie Bahlai",
      "screen_name" : "cbahlai",
      "indices" : [ 47, 55 ],
      "id_str" : "958649520",
      "id" : 958649520
    }, {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 56, 64 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/736287522041540609\/photo\/1",
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/zn8ZTL3euj",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CjfRmGAXIAAzCre.jpg",
      "id_str" : "736287516475727872",
      "id" : 736287516475727872,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CjfRmGAXIAAzCre.jpg",
      "sizes" : [ {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 4032,
        "resize" : "fit",
        "w" : 3024
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      } ],
      "display_url" : "pic.twitter.com\/zn8ZTL3euj"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "736286747085156354",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11406861144827, 8.75328997085832 ]
  },
  "id_str" : "736287522041540609",
  "in_reply_to_user_id" : 395367768,
  "text" : "@abbycabs @froggleston @blahah404 @juretriglav @cbahlai @o_guest tell me about it it. \uD83D\uDE02 https:\/\/t.co\/zn8ZTL3euj",
  "id" : 736287522041540609,
  "in_reply_to_status_id" : 736286747085156354,
  "created_at" : "2016-05-27 20:06:39 +0000",
  "in_reply_to_screen_name" : "abbycabs",
  "in_reply_to_user_id_str" : "395367768",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert Davey",
      "screen_name" : "froggleston",
      "indices" : [ 0, 12 ],
      "id_str" : "53893339",
      "id" : 53893339
    }, {
      "name" : "\u24EA Rik Smith-Unna \uD83C\uDDF0\uD83C\uDDEA",
      "screen_name" : "blahah404",
      "indices" : [ 13, 23 ],
      "id_str" : "99173786",
      "id" : 99173786
    }, {
      "name" : "Abby Cabunoc Mayes",
      "screen_name" : "abbycabs",
      "indices" : [ 24, 33 ],
      "id_str" : "395367768",
      "id" : 395367768
    }, {
      "name" : "Jure Triglav",
      "screen_name" : "juretriglav",
      "indices" : [ 34, 46 ],
      "id_str" : "15528719",
      "id" : 15528719
    }, {
      "name" : "Christie Bahlai",
      "screen_name" : "cbahlai",
      "indices" : [ 47, 55 ],
      "id_str" : "958649520",
      "id" : 958649520
    }, {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 56, 64 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "736270436678434817",
  "geo" : { },
  "id_str" : "736276156555644928",
  "in_reply_to_user_id" : 53893339,
  "text" : "@froggleston @blahah404 @abbycabs @juretriglav @cbahlai @o_guest thanks, that judgement means a lot! \uD83D\uDE0D",
  "id" : 736276156555644928,
  "in_reply_to_status_id" : 736270436678434817,
  "created_at" : "2016-05-27 19:21:29 +0000",
  "in_reply_to_screen_name" : "froggleston",
  "in_reply_to_user_id_str" : "53893339",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/F1yjCXWKmE",
      "expanded_url" : "https:\/\/twitter.com\/marcelsalathe\/status\/736133301296082945",
      "display_url" : "twitter.com\/marcelsalathe\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "736133524743409665",
  "text" : "What I\u2019ll quote next time someone asks me to put away my mobile phone. https:\/\/t.co\/F1yjCXWKmE",
  "id" : 736133524743409665,
  "created_at" : "2016-05-27 09:54:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "736130577481490432",
  "geo" : { },
  "id_str" : "736131525767499776",
  "in_reply_to_user_id" : 14286491,
  "text" : "Oh, and \u201Ea museum\u201C in this context means Berlin\u2019s Natural history museum. Germany\u2019s second-largest of its kind\u2026",
  "id" : 736131525767499776,
  "in_reply_to_status_id" : 736130577481490432,
  "created_at" : "2016-05-27 09:46:47 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/6W1L6mPDfx",
      "expanded_url" : "https:\/\/twitter.com\/blahah404\/status\/736129963745783808",
      "display_url" : "twitter.com\/blahah404\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "736130577481490432",
  "text" : "My favorite is that \u201Ecitizen\u201C science is represented by a professor who\u2019s additionally Director of a museum. https:\/\/t.co\/6W1L6mPDfx",
  "id" : 736130577481490432,
  "created_at" : "2016-05-27 09:43:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Velterop \u24D0 \uD83C\uDDEA\uD83C\uDDFA\uD83D\uDD36",
      "screen_name" : "Villavelius",
      "indices" : [ 3, 15 ],
      "id_str" : "72249574",
      "id" : 72249574
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 67 ],
      "url" : "https:\/\/t.co\/8FiAGw8kBO",
      "expanded_url" : "http:\/\/gu.com\/p\/4jgfd\/stw",
      "display_url" : "gu.com\/p\/4jgfd\/stw"
    } ]
  },
  "geo" : { },
  "id_str" : "736103682043957248",
  "text" : "RT @Villavelius: \u201CThe men who live as dogs\u201D https:\/\/t.co\/8FiAGw8kBO \u2014 What an amazing world we live in.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 27, 50 ],
        "url" : "https:\/\/t.co\/8FiAGw8kBO",
        "expanded_url" : "http:\/\/gu.com\/p\/4jgfd\/stw",
        "display_url" : "gu.com\/p\/4jgfd\/stw"
      } ]
    },
    "geo" : { },
    "id_str" : "736102863949025280",
    "text" : "\u201CThe men who live as dogs\u201D https:\/\/t.co\/8FiAGw8kBO \u2014 What an amazing world we live in.",
    "id" : 736102863949025280,
    "created_at" : "2016-05-27 07:52:53 +0000",
    "user" : {
      "name" : "Velterop \u24D0 \uD83C\uDDEA\uD83C\uDDFA\uD83D\uDD36",
      "screen_name" : "Villavelius",
      "protected" : false,
      "id_str" : "72249574",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/863354284653649920\/ZZQI6uVM_normal.jpg",
      "id" : 72249574,
      "verified" : true
    }
  },
  "id" : 736103682043957248,
  "created_at" : "2016-05-27 07:56:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "735930202698698753",
  "geo" : { },
  "id_str" : "735930295355117570",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch Sweet!",
  "id" : 735930295355117570,
  "in_reply_to_status_id" : 735930202698698753,
  "created_at" : "2016-05-26 20:27:09 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BOSC",
      "screen_name" : "OBF_BOSC",
      "indices" : [ 3, 12 ],
      "id_str" : "583180584",
      "id" : 583180584
    }, {
      "name" : "ISCB News",
      "screen_name" : "iscb",
      "indices" : [ 65, 70 ],
      "id_str" : "96111619",
      "id" : 96111619
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BOSC2016",
      "indices" : [ 75, 84 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/PNLM8ciqw0",
      "expanded_url" : "https:\/\/www.iscb.org\/ismb2016-registration",
      "display_url" : "iscb.org\/ismb2016-regis\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "735918385066807301",
  "text" : "RT @OBF_BOSC: One more week for early discounted registration at @iscb and #BOSC2016! https:\/\/t.co\/PNLM8ciqw0",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "ISCB News",
        "screen_name" : "iscb",
        "indices" : [ 51, 56 ],
        "id_str" : "96111619",
        "id" : 96111619
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BOSC2016",
        "indices" : [ 61, 70 ]
      } ],
      "urls" : [ {
        "indices" : [ 72, 95 ],
        "url" : "https:\/\/t.co\/PNLM8ciqw0",
        "expanded_url" : "https:\/\/www.iscb.org\/ismb2016-registration",
        "display_url" : "iscb.org\/ismb2016-regis\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "735875595582636033",
    "text" : "One more week for early discounted registration at @iscb and #BOSC2016! https:\/\/t.co\/PNLM8ciqw0",
    "id" : 735875595582636033,
    "created_at" : "2016-05-26 16:49:48 +0000",
    "user" : {
      "name" : "BOSC",
      "screen_name" : "OBF_BOSC",
      "protected" : false,
      "id_str" : "583180584",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2227105401\/BOSC-logo-square_normal.jpg",
      "id" : 583180584,
      "verified" : false
    }
  },
  "id" : 735918385066807301,
  "created_at" : "2016-05-26 19:39:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 10, 22 ],
      "id_str" : "52747896",
      "id" : 52747896
    }, {
      "name" : "Paul-Olivier Dehaye",
      "screen_name" : "podehaye",
      "indices" : [ 23, 32 ],
      "id_str" : "2219841242",
      "id" : 2219841242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "735910404828844034",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11419282624839, 8.752177155061998 ]
  },
  "id_str" : "735910815224762369",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon @helgerausch @podehaye my attempts to make it in the OSPP were \u2018not retained\u2019, so it\u2019s more direct action  \u00AF\\_(\u30C4)_\/\u00AF",
  "id" : 735910815224762369,
  "in_reply_to_status_id" : 735910404828844034,
  "created_at" : "2016-05-26 19:09:45 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 10, 22 ],
      "id_str" : "52747896",
      "id" : 52747896
    }, {
      "name" : "Paul-Olivier Dehaye",
      "screen_name" : "podehaye",
      "indices" : [ 23, 32 ],
      "id_str" : "2219841242",
      "id" : 2219841242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "735908201074397185",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11269264507973, 8.755096807560344 ]
  },
  "id_str" : "735909257191755776",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon @helgerausch @podehaye well, we already ID which papers are OA. So could do a sci-hub one for the others :p",
  "id" : 735909257191755776,
  "in_reply_to_status_id" : 735908201074397185,
  "created_at" : "2016-05-26 19:03:34 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 10, 22 ],
      "id_str" : "52747896",
      "id" : 52747896
    }, {
      "name" : "Paul-Olivier Dehaye",
      "screen_name" : "podehaye",
      "indices" : [ 23, 32 ],
      "id_str" : "2219841242",
      "id" : 2219841242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "735905912968359936",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.10898594283509, 8.762567974635179 ]
  },
  "id_str" : "735907081836986368",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon @helgerausch @podehaye so the recommendation is wait for the ruling and rename the button label? :p",
  "id" : 735907081836986368,
  "in_reply_to_status_id" : 735905912968359936,
  "created_at" : "2016-05-26 18:54:55 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 10, 22 ],
      "id_str" : "52747896",
      "id" : 52747896
    }, {
      "name" : "Paul-Olivier Dehaye",
      "screen_name" : "podehaye",
      "indices" : [ 23, 32 ],
      "id_str" : "2219841242",
      "id" : 2219841242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "735904532530647040",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.10684534712505, 8.771569987921561 ]
  },
  "id_str" : "735904755692797952",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon @helgerausch @podehaye but you don\u2019t recommend direct links so far either?",
  "id" : 735904755692797952,
  "in_reply_to_status_id" : 735904532530647040,
  "created_at" : "2016-05-26 18:45:40 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    }, {
      "name" : "Paul-Olivier Dehaye",
      "screen_name" : "podehaye",
      "indices" : [ 10, 19 ],
      "id_str" : "2219841242",
      "id" : 2219841242
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 20, 32 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "735903521086812161",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.10417941830443, 8.77228967766292 ]
  },
  "id_str" : "735903776025022469",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon @podehaye @helgerausch I want that app!",
  "id" : 735903776025022469,
  "in_reply_to_status_id" : 735903521086812161,
  "created_at" : "2016-05-26 18:41:47 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 10, 22 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "735902280889868290",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.10251829999369, 8.775420391552585 ]
  },
  "id_str" : "735902788052455424",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon @helgerausch so if we just add a button \u201Cbreak the law and get the paper!\u201D we are fine? \uD83E\uDD14",
  "id" : 735902788052455424,
  "in_reply_to_status_id" : 735902280889868290,
  "created_at" : "2016-05-26 18:37:51 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 77, 86 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "735899816975323136",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.10242603274918, 8.775688991233842 ]
  },
  "id_str" : "735899973531914241",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch don\u2019t know, but maybe some copyright expert could enlighten us? @Senficon :p",
  "id" : 735899973531914241,
  "in_reply_to_status_id" : 735899816975323136,
  "created_at" : "2016-05-26 18:26:40 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "735898685658304512",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.10242181122781, 8.775686055620557 ]
  },
  "id_str" : "735899329601376258",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch and nice, how long are you staying? :)",
  "id" : 735899329601376258,
  "in_reply_to_status_id" : 735898685658304512,
  "created_at" : "2016-05-26 18:24:07 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "735898685658304512",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.10239475450628, 8.775729915148725 ]
  },
  "id_str" : "735899261720797185",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch to go one level more meta? :p but seriously: as an additional link?",
  "id" : 735899261720797185,
  "in_reply_to_status_id" : 735898685658304512,
  "created_at" : "2016-05-26 18:23:50 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 36 ],
      "url" : "https:\/\/t.co\/pWOCv0O83o",
      "expanded_url" : "https:\/\/twitter.com\/torproject\/status\/728588803447885825",
      "display_url" : "twitter.com\/torproject\/sta\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "735895463568756738",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.10238696686442, 8.775793654721667 ]
  },
  "id_str" : "735896467622203394",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch https:\/\/t.co\/pWOCv0O83o :) (you\u2019re in Scotland?!)",
  "id" : 735896467622203394,
  "in_reply_to_status_id" : 735895463568756738,
  "created_at" : "2016-05-26 18:12:44 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mrgunn",
      "screen_name" : "mrgunn",
      "indices" : [ 0, 7 ],
      "id_str" : "15237935",
      "id" : 15237935
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "735855626320904193",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11380741504966, 8.753514356340295 ]
  },
  "id_str" : "735856805369249792",
  "in_reply_to_user_id" : 15237935,
  "text" : "@mrgunn using the Mendeley-API to get the DOIs which are then linked to sci-hub, sounds like an ironic art project already :p",
  "id" : 735856805369249792,
  "in_reply_to_status_id" : 735855626320904193,
  "created_at" : "2016-05-26 15:35:08 +0000",
  "in_reply_to_screen_name" : "mrgunn",
  "in_reply_to_user_id_str" : "15237935",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mrgunn",
      "screen_name" : "mrgunn",
      "indices" : [ 0, 7 ],
      "id_str" : "15237935",
      "id" : 15237935
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "735855626320904193",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11391231642799, 8.753340317129188 ]
  },
  "id_str" : "735855990269218816",
  "in_reply_to_user_id" : 15237935,
  "text" : "@mrgunn it can\u2019t have taken you all these years to figure that one out! \uD83D\uDE0A",
  "id" : 735855990269218816,
  "in_reply_to_status_id" : 735855626320904193,
  "created_at" : "2016-05-26 15:31:54 +0000",
  "in_reply_to_screen_name" : "mrgunn",
  "in_reply_to_user_id_str" : "15237935",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mugwump",
      "screen_name" : "ozaed",
      "indices" : [ 0, 6 ],
      "id_str" : "15806521",
      "id" : 15806521
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "735852596531974145",
  "geo" : { },
  "id_str" : "735853183700983809",
  "in_reply_to_user_id" : 15806521,
  "text" : "@ozaed and at least while it\u2019s last it would be a nice service for all non-academic users.",
  "id" : 735853183700983809,
  "in_reply_to_status_id" : 735852596531974145,
  "created_at" : "2016-05-26 15:20:45 +0000",
  "in_reply_to_screen_name" : "ozaed",
  "in_reply_to_user_id_str" : "15806521",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mugwump",
      "screen_name" : "ozaed",
      "indices" : [ 0, 6 ],
      "id_str" : "15806521",
      "id" : 15806521
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "735852596531974145",
  "geo" : { },
  "id_str" : "735853110447464450",
  "in_reply_to_user_id" : 15806521,
  "text" : "@ozaed sure, but then we could just go back to resolving DOIs as usual. Would be more like giving the \uD83D\uDD95to closed access for a while :P",
  "id" : 735853110447464450,
  "in_reply_to_status_id" : 735852596531974145,
  "created_at" : "2016-05-26 15:20:27 +0000",
  "in_reply_to_screen_name" : "ozaed",
  "in_reply_to_user_id_str" : "15806521",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mugwump",
      "screen_name" : "ozaed",
      "indices" : [ 0, 6 ],
      "id_str" : "15806521",
      "id" : 15806521
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "735851528335020032",
  "geo" : { },
  "id_str" : "735851680009424896",
  "in_reply_to_user_id" : 15806521,
  "text" : "@ozaed well, that would be updating a single env variable from time to time :p",
  "id" : 735851680009424896,
  "in_reply_to_status_id" : 735851528335020032,
  "created_at" : "2016-05-26 15:14:46 +0000",
  "in_reply_to_screen_name" : "ozaed",
  "in_reply_to_user_id_str" : "15806521",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "735851163350892544",
  "text" : "Wonder whether openSNP should replace all regular DOI links with Sci-Hub links, just for the fun of it.",
  "id" : 735851163350892544,
  "created_at" : "2016-05-26 15:12:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Pardy",
      "screen_name" : "BrianPardy",
      "indices" : [ 0, 11 ],
      "id_str" : "611699110",
      "id" : 611699110
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "735847750798036992",
  "geo" : { },
  "id_str" : "735848162443857920",
  "in_reply_to_user_id" : 611699110,
  "text" : "@BrianPardy yes, but would be interesting to see whether \u201Eperceived scientific-ness\u201C makes a diff. in efficiency",
  "id" : 735848162443857920,
  "in_reply_to_status_id" : 735847750798036992,
  "created_at" : "2016-05-26 15:00:47 +0000",
  "in_reply_to_screen_name" : "BrianPardy",
  "in_reply_to_user_id_str" : "611699110",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Pardy",
      "screen_name" : "BrianPardy",
      "indices" : [ 0, 11 ],
      "id_str" : "611699110",
      "id" : 611699110
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "735845792276189184",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11403953801128, 8.753419299096755 ]
  },
  "id_str" : "735847215739076613",
  "in_reply_to_user_id" : 611699110,
  "text" : "@BrianPardy diff would be interesting to see. As I suspect that racists will use whatever othering-criteria they can make up for their end",
  "id" : 735847215739076613,
  "in_reply_to_status_id" : 735845792276189184,
  "created_at" : "2016-05-26 14:57:02 +0000",
  "in_reply_to_screen_name" : "BrianPardy",
  "in_reply_to_user_id_str" : "611699110",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Pardy",
      "screen_name" : "BrianPardy",
      "indices" : [ 0, 11 ],
      "id_str" : "611699110",
      "id" : 611699110
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "735845792276189184",
  "geo" : { },
  "id_str" : "735847027431636992",
  "in_reply_to_user_id" : 611699110,
  "text" : "@BrianPardy yes, just proves (again) that othering works, but remains completely unclear whether genetic othering != cultural\/ethnic etc.",
  "id" : 735847027431636992,
  "in_reply_to_status_id" : 735845792276189184,
  "created_at" : "2016-05-26 14:56:17 +0000",
  "in_reply_to_screen_name" : "BrianPardy",
  "in_reply_to_user_id_str" : "611699110",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 53 ],
      "url" : "https:\/\/t.co\/bO64ve39Pf",
      "expanded_url" : "http:\/\/sci-hub.cc\/10.1177\/0146167216642196",
      "display_url" : "sci-hub.cc\/10.1177\/014616\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "735845013045809152",
  "geo" : { },
  "id_str" : "735845525522644994",
  "in_reply_to_user_id" : 14286491,
  "text" : "Read the complete study here: https:\/\/t.co\/bO64ve39Pf",
  "id" : 735845525522644994,
  "in_reply_to_status_id" : 735845013045809152,
  "created_at" : "2016-05-26 14:50:19 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/TQnLgJbpYc",
      "expanded_url" : "http:\/\/blogs.scientificamerican.com\/guest-blog\/can-dna-ancestry-testing-make-you-more-racist\/",
      "display_url" : "blogs.scientificamerican.com\/guest-blog\/can\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "735845013045809152",
  "text" : "\u00ABCan DNA Ancestry Testing Make You More Racist?\u00BB Should be: Can framing to induce otherness make you more racist\u2026 https:\/\/t.co\/TQnLgJbpYc",
  "id" : 735845013045809152,
  "created_at" : "2016-05-26 14:48:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Martin Paul Eve",
      "screen_name" : "martin_eve",
      "indices" : [ 3, 14 ],
      "id_str" : "118747590",
      "id" : 118747590
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/CHNJONVQmH",
      "expanded_url" : "https:\/\/www.timeshighereducation.com\/features\/coping-with-illness",
      "display_url" : "timeshighereducation.com\/features\/copin\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "735770584169123840",
  "text" : "RT @martin_eve: Today is my thirtieth birthday and I have a piece out in the Times Higher on illness and academia https:\/\/t.co\/CHNJONVQmH",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 98, 121 ],
        "url" : "https:\/\/t.co\/CHNJONVQmH",
        "expanded_url" : "https:\/\/www.timeshighereducation.com\/features\/coping-with-illness",
        "display_url" : "timeshighereducation.com\/features\/copin\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "735724728283844610",
    "text" : "Today is my thirtieth birthday and I have a piece out in the Times Higher on illness and academia https:\/\/t.co\/CHNJONVQmH",
    "id" : 735724728283844610,
    "created_at" : "2016-05-26 06:50:18 +0000",
    "user" : {
      "name" : "Martin Paul Eve",
      "screen_name" : "martin_eve",
      "protected" : false,
      "id_str" : "118747590",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/855017454384402432\/rajP3b7b_normal.jpg",
      "id" : 118747590,
      "verified" : false
    }
  },
  "id" : 735770584169123840,
  "created_at" : "2016-05-26 09:52:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony Ross-Hellauer",
      "screen_name" : "tonyR_H",
      "indices" : [ 0, 8 ],
      "id_str" : "44890780",
      "id" : 44890780
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 9, 18 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "735614958491316225",
  "geo" : { },
  "id_str" : "735615680406556673",
  "in_reply_to_user_id" : 44890780,
  "text" : "@tonyR_H @Senficon I knew I had forgotten something!",
  "id" : 735615680406556673,
  "in_reply_to_status_id" : 735614958491316225,
  "created_at" : "2016-05-25 23:36:59 +0000",
  "in_reply_to_screen_name" : "tonyR_H",
  "in_reply_to_user_id_str" : "44890780",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony Ross-Hellauer",
      "screen_name" : "tonyR_H",
      "indices" : [ 0, 8 ],
      "id_str" : "44890780",
      "id" : 44890780
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "735611367277907968",
  "geo" : { },
  "id_str" : "735613033209270272",
  "in_reply_to_user_id" : 44890780,
  "text" : "@tonyR_H thanks, let\u2019s keep our fingers crossed that at least some of us made it.",
  "id" : 735613033209270272,
  "in_reply_to_status_id" : 735611367277907968,
  "created_at" : "2016-05-25 23:26:28 +0000",
  "in_reply_to_screen_name" : "tonyR_H",
  "in_reply_to_user_id_str" : "44890780",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "735609899514630144",
  "geo" : { },
  "id_str" : "735610302696456192",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez yep, I\u2019m really curious to see who\u2019ll end up on it! And on the positive side: I\u2019m already close to being overcommitted\u2026",
  "id" : 735610302696456192,
  "in_reply_to_status_id" : 735609899514630144,
  "created_at" : "2016-05-25 23:15:37 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 34 ],
      "url" : "https:\/\/t.co\/T58ekEvuvU",
      "expanded_url" : "https:\/\/twitter.com\/EvoMRI\/status\/735514188425093120",
      "display_url" : "twitter.com\/EvoMRI\/status\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "735608853526614017",
  "text" : "Same here. https:\/\/t.co\/T58ekEvuvU",
  "id" : 735608853526614017,
  "created_at" : "2016-05-25 23:09:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "scott",
      "screen_name" : "sckottie",
      "indices" : [ 0, 9 ],
      "id_str" : "103004948",
      "id" : 103004948
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "735569687912812544",
  "geo" : { },
  "id_str" : "735569873141694464",
  "in_reply_to_user_id" : 103004948,
  "text" : "@sckottie currently starting a larger ggplot-orgy, so thought it might make sense to go RStudio for it.",
  "id" : 735569873141694464,
  "in_reply_to_status_id" : 735569687912812544,
  "created_at" : "2016-05-25 20:34:58 +0000",
  "in_reply_to_screen_name" : "sckottie",
  "in_reply_to_user_id_str" : "103004948",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "scott",
      "screen_name" : "sckottie",
      "indices" : [ 0, 9 ],
      "id_str" : "103004948",
      "id" : 103004948
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "735565486067462145",
  "geo" : { },
  "id_str" : "735565678263062528",
  "in_reply_to_user_id" : 103004948,
  "text" : "@sckottie after using it for ~30 minutes it still feels very very weird compared to just having a shell.",
  "id" : 735565678263062528,
  "in_reply_to_status_id" : 735565486067462145,
  "created_at" : "2016-05-25 20:18:18 +0000",
  "in_reply_to_screen_name" : "sckottie",
  "in_reply_to_user_id_str" : "103004948",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/EsLazAFHUY",
      "expanded_url" : "http:\/\/ruleofthirds.de\/scihub-part2\/",
      "display_url" : "ruleofthirds.de\/scihub-part2\/"
    } ]
  },
  "in_reply_to_status_id_str" : "735559432550023168",
  "geo" : { },
  "id_str" : "735559717460840448",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez good point. I always abused .RHistory for that. See the GH documentation for my https:\/\/t.co\/EsLazAFHUY posts",
  "id" : 735559717460840448,
  "in_reply_to_status_id" : 735559432550023168,
  "created_at" : "2016-05-25 19:54:37 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "735558346120384514",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11287493635911, 8.75422655605595 ]
  },
  "id_str" : "735559024255619072",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez but let\u2019s see how I\u2019ll adjust. I recently even started liking atom over vim for some things :p",
  "id" : 735559024255619072,
  "in_reply_to_status_id" : 735558346120384514,
  "created_at" : "2016-05-25 19:51:52 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "735558346120384514",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11287493635911, 8.75422655605595 ]
  },
  "id_str" : "735558836279513091",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez for my needs the local cluster always worked fine. And I\u2019m spending 60% of my time in the shell anyhow.",
  "id" : 735558836279513091,
  "in_reply_to_status_id" : 735558346120384514,
  "created_at" : "2016-05-25 19:51:07 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "735556337128574976",
  "text" : "I\u2019m probably late\/last to the party. But I just downloaded RStudio. Feels like betraying my trusty shell. \uD83D\uDC94",
  "id" : 735556337128574976,
  "created_at" : "2016-05-25 19:41:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sharlynn Sweeney",
      "screen_name" : "percolata",
      "indices" : [ 0, 10 ],
      "id_str" : "604785277",
      "id" : 604785277
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "735550475714633729",
  "geo" : { },
  "id_str" : "735551245029638147",
  "in_reply_to_user_id" : 604785277,
  "text" : "@percolata thanks for sharing! :)",
  "id" : 735551245029638147,
  "in_reply_to_status_id" : 735550475714633729,
  "created_at" : "2016-05-25 19:20:57 +0000",
  "in_reply_to_screen_name" : "percolata",
  "in_reply_to_user_id_str" : "604785277",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert Krause",
      "screen_name" : "euleule",
      "indices" : [ 0, 8 ],
      "id_str" : "563152502",
      "id" : 563152502
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/735536986442862592\/photo\/1",
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/8RIeGZh9ky",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CjUm_WHWUAAS6cz.jpg",
      "id_str" : "735536983854960640",
      "id" : 735536983854960640,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CjUm_WHWUAAS6cz.jpg",
      "sizes" : [ {
        "h" : 3024,
        "resize" : "fit",
        "w" : 4032
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/8RIeGZh9ky"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11403627650791, 8.753410730004521 ]
  },
  "id_str" : "735536986442862592",
  "in_reply_to_user_id" : 563152502,
  "text" : "@euleule schaffe es heute nicht. Daf\u00FCr seit 5 Minuten bei mir an der Wand. \uD83D\uDE0D\uD83D\uDC96 https:\/\/t.co\/8RIeGZh9ky",
  "id" : 735536986442862592,
  "created_at" : "2016-05-25 18:24:17 +0000",
  "in_reply_to_screen_name" : "euleule",
  "in_reply_to_user_id_str" : "563152502",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cristine Legare",
      "screen_name" : "CristineLegare",
      "indices" : [ 3, 18 ],
      "id_str" : "728326802",
      "id" : 728326802
    }, {
      "name" : "John Brockman",
      "screen_name" : "edge",
      "indices" : [ 45, 50 ],
      "id_str" : "15125585",
      "id" : 15125585
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/8RbiMqBoWg",
      "expanded_url" : "http:\/\/tinyurl.com\/womeninevolution",
      "display_url" : "tinyurl.com\/womeninevoluti\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "735507152274632705",
  "text" : "RT @CristineLegare: All contributors to this @edge volume are male. List of female evolutionary scientists: https:\/\/t.co\/8RbiMqBoWg https:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "John Brockman",
        "screen_name" : "edge",
        "indices" : [ 25, 30 ],
        "id_str" : "15125585",
        "id" : 15125585
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/CristineLegare\/status\/735470022215114752\/photo\/1",
        "indices" : [ 112, 135 ],
        "url" : "https:\/\/t.co\/MX2UedYcWU",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CjTqFntUYAAb1Kh.jpg",
        "id_str" : "735470021447540736",
        "id" : 735470021447540736,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CjTqFntUYAAb1Kh.jpg",
        "sizes" : [ {
          "h" : 960,
          "resize" : "fit",
          "w" : 720
        }, {
          "h" : 960,
          "resize" : "fit",
          "w" : 720
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 510
        }, {
          "h" : 960,
          "resize" : "fit",
          "w" : 720
        } ],
        "display_url" : "pic.twitter.com\/MX2UedYcWU"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 88, 111 ],
        "url" : "https:\/\/t.co\/8RbiMqBoWg",
        "expanded_url" : "http:\/\/tinyurl.com\/womeninevolution",
        "display_url" : "tinyurl.com\/womeninevoluti\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "735470022215114752",
    "text" : "All contributors to this @edge volume are male. List of female evolutionary scientists: https:\/\/t.co\/8RbiMqBoWg https:\/\/t.co\/MX2UedYcWU",
    "id" : 735470022215114752,
    "created_at" : "2016-05-25 13:58:12 +0000",
    "user" : {
      "name" : "Cristine Legare",
      "screen_name" : "CristineLegare",
      "protected" : false,
      "id_str" : "728326802",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/533488911503208448\/xWezsslc_normal.jpeg",
      "id" : 728326802,
      "verified" : false
    }
  },
  "id" : 735507152274632705,
  "created_at" : "2016-05-25 16:25:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "735492164742840325",
  "geo" : { },
  "id_str" : "735492257483198465",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez now I really need to get my act together!",
  "id" : 735492257483198465,
  "in_reply_to_status_id" : 735492164742840325,
  "created_at" : "2016-05-25 15:26:33 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u24EA Rik Smith-Unna \uD83C\uDDF0\uD83C\uDDEA",
      "screen_name" : "blahah404",
      "indices" : [ 0, 10 ],
      "id_str" : "99173786",
      "id" : 99173786
    }, {
      "name" : "Titus Brown",
      "screen_name" : "ctitusbrown",
      "indices" : [ 11, 23 ],
      "id_str" : "26616462",
      "id" : 26616462
    }, {
      "name" : "Mick Watson",
      "screen_name" : "BioMickWatson",
      "indices" : [ 24, 38 ],
      "id_str" : "228586748",
      "id" : 228586748
    }, {
      "name" : "Richard Sever",
      "screen_name" : "cshperspectives",
      "indices" : [ 39, 55 ],
      "id_str" : "21242028",
      "id" : 21242028
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "735466347489038336",
  "geo" : { },
  "id_str" : "735466438056628224",
  "in_reply_to_user_id" : 99173786,
  "text" : "@blahah404 @ctitusbrown @BioMickWatson @cshperspectives i know, but I at least hoped I had gotten this one \u00B1 right :P",
  "id" : 735466438056628224,
  "in_reply_to_status_id" : 735466347489038336,
  "created_at" : "2016-05-25 13:43:57 +0000",
  "in_reply_to_screen_name" : "blahah404",
  "in_reply_to_user_id_str" : "99173786",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u24EA Rik Smith-Unna \uD83C\uDDF0\uD83C\uDDEA",
      "screen_name" : "blahah404",
      "indices" : [ 0, 10 ],
      "id_str" : "99173786",
      "id" : 99173786
    }, {
      "name" : "Titus Brown",
      "screen_name" : "ctitusbrown",
      "indices" : [ 11, 23 ],
      "id_str" : "26616462",
      "id" : 26616462
    }, {
      "name" : "Mick Watson",
      "screen_name" : "BioMickWatson",
      "indices" : [ 24, 38 ],
      "id_str" : "228586748",
      "id" : 228586748
    }, {
      "name" : "Richard Sever",
      "screen_name" : "cshperspectives",
      "indices" : [ 39, 55 ],
      "id_str" : "21242028",
      "id" : 21242028
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "735465986762117120",
  "geo" : { },
  "id_str" : "735466206489149440",
  "in_reply_to_user_id" : 99173786,
  "text" : "@blahah404 @ctitusbrown @BioMickWatson @cshperspectives yep, though fwiw my gut feeling is that it should be moral. okay  \u00AF\\_(\u30C4)_\/\u00AF",
  "id" : 735466206489149440,
  "in_reply_to_status_id" : 735465986762117120,
  "created_at" : "2016-05-25 13:43:02 +0000",
  "in_reply_to_screen_name" : "blahah404",
  "in_reply_to_user_id_str" : "99173786",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u24EA Rik Smith-Unna \uD83C\uDDF0\uD83C\uDDEA",
      "screen_name" : "blahah404",
      "indices" : [ 0, 10 ],
      "id_str" : "99173786",
      "id" : 99173786
    }, {
      "name" : "Titus Brown",
      "screen_name" : "ctitusbrown",
      "indices" : [ 11, 23 ],
      "id_str" : "26616462",
      "id" : 26616462
    }, {
      "name" : "Mick Watson",
      "screen_name" : "BioMickWatson",
      "indices" : [ 24, 38 ],
      "id_str" : "228586748",
      "id" : 228586748
    }, {
      "name" : "Richard Sever",
      "screen_name" : "cshperspectives",
      "indices" : [ 39, 55 ],
      "id_str" : "21242028",
      "id" : 21242028
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "735465904839000064",
  "geo" : { },
  "id_str" : "735465995863793664",
  "in_reply_to_user_id" : 99173786,
  "text" : "@blahah404 @ctitusbrown @BioMickWatson @cshperspectives phew, thought I\u2019d been getting CC-BY wrong for years :D",
  "id" : 735465995863793664,
  "in_reply_to_status_id" : 735465904839000064,
  "created_at" : "2016-05-25 13:42:12 +0000",
  "in_reply_to_screen_name" : "blahah404",
  "in_reply_to_user_id_str" : "99173786",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u24EA Rik Smith-Unna \uD83C\uDDF0\uD83C\uDDEA",
      "screen_name" : "blahah404",
      "indices" : [ 0, 10 ],
      "id_str" : "99173786",
      "id" : 99173786
    }, {
      "name" : "Titus Brown",
      "screen_name" : "ctitusbrown",
      "indices" : [ 11, 23 ],
      "id_str" : "26616462",
      "id" : 26616462
    }, {
      "name" : "Mick Watson",
      "screen_name" : "BioMickWatson",
      "indices" : [ 24, 38 ],
      "id_str" : "228586748",
      "id" : 228586748
    }, {
      "name" : "Richard Sever",
      "screen_name" : "cshperspectives",
      "indices" : [ 39, 55 ],
      "id_str" : "21242028",
      "id" : 21242028
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 79 ],
      "url" : "https:\/\/t.co\/KgD5rpx5Wx",
      "expanded_url" : "http:\/\/creativecommons.org\/licenses\/by\/1.0\/",
      "display_url" : "creativecommons.org\/licenses\/by\/1.\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "735464829478141952",
  "geo" : { },
  "id_str" : "735465486574624768",
  "in_reply_to_user_id" : 99173786,
  "text" : "@blahah404 @ctitusbrown @BioMickWatson @cshperspectives https:\/\/t.co\/KgD5rpx5Wx ?",
  "id" : 735465486574624768,
  "in_reply_to_status_id" : 735464829478141952,
  "created_at" : "2016-05-25 13:40:10 +0000",
  "in_reply_to_screen_name" : "blahah404",
  "in_reply_to_user_id_str" : "99173786",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Titus Brown",
      "screen_name" : "ctitusbrown",
      "indices" : [ 0, 12 ],
      "id_str" : "26616462",
      "id" : 26616462
    }, {
      "name" : "Mick Watson",
      "screen_name" : "BioMickWatson",
      "indices" : [ 13, 27 ],
      "id_str" : "228586748",
      "id" : 228586748
    }, {
      "name" : "Richard Sever",
      "screen_name" : "cshperspectives",
      "indices" : [ 28, 44 ],
      "id_str" : "21242028",
      "id" : 21242028
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "735463185986162692",
  "geo" : { },
  "id_str" : "735464065494097921",
  "in_reply_to_user_id" : 26616462,
  "text" : "@ctitusbrown @BioMickWatson @cshperspectives only ok if the citation includes a link to the license if I\u2019m not mistaken?",
  "id" : 735464065494097921,
  "in_reply_to_status_id" : 735463185986162692,
  "created_at" : "2016-05-25 13:34:32 +0000",
  "in_reply_to_screen_name" : "ctitusbrown",
  "in_reply_to_user_id_str" : "26616462",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "C\u24D0meronNeylon",
      "screen_name" : "CameronNeylon",
      "indices" : [ 0, 14 ],
      "id_str" : "12984852",
      "id" : 12984852
    }, {
      "name" : "Scholarly Kitchen",
      "screen_name" : "scholarlykitchn",
      "indices" : [ 15, 31 ],
      "id_str" : "119401334",
      "id" : 119401334
    }, {
      "name" : "Marie E McVeigh",
      "screen_name" : "JopieNet",
      "indices" : [ 32, 41 ],
      "id_str" : "371391064",
      "id" : 371391064
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "735437848485171200",
  "geo" : { },
  "id_str" : "735438402259148800",
  "in_reply_to_user_id" : 12984852,
  "text" : "@CameronNeylon @scholarlykitchn @JopieNet yes, but certainly claiming that access isn\u2019t an issue for academics is bogus.",
  "id" : 735438402259148800,
  "in_reply_to_status_id" : 735437848485171200,
  "created_at" : "2016-05-25 11:52:33 +0000",
  "in_reply_to_screen_name" : "CameronNeylon",
  "in_reply_to_user_id_str" : "12984852",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "C\u24D0meronNeylon",
      "screen_name" : "CameronNeylon",
      "indices" : [ 0, 14 ],
      "id_str" : "12984852",
      "id" : 12984852
    }, {
      "name" : "Scholarly Kitchen",
      "screen_name" : "scholarlykitchn",
      "indices" : [ 15, 31 ],
      "id_str" : "119401334",
      "id" : 119401334
    }, {
      "name" : "Marie E McVeigh",
      "screen_name" : "JopieNet",
      "indices" : [ 32, 41 ],
      "id_str" : "371391064",
      "id" : 371391064
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "735437119024435201",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17233383168875, 8.627589635846777 ]
  },
  "id_str" : "735437571635941376",
  "in_reply_to_user_id" : 12984852,
  "text" : "@CameronNeylon @scholarlykitchn @JopieNet sure, but (eq anecdotally) people first try w\/o scihub and only then switch.",
  "id" : 735437571635941376,
  "in_reply_to_status_id" : 735437119024435201,
  "created_at" : "2016-05-25 11:49:15 +0000",
  "in_reply_to_screen_name" : "CameronNeylon",
  "in_reply_to_user_id_str" : "12984852",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "C\u24D0meronNeylon",
      "screen_name" : "CameronNeylon",
      "indices" : [ 0, 14 ],
      "id_str" : "12984852",
      "id" : 12984852
    }, {
      "name" : "Scholarly Kitchen",
      "screen_name" : "scholarlykitchn",
      "indices" : [ 15, 31 ],
      "id_str" : "119401334",
      "id" : 119401334
    }, {
      "name" : "Marie E McVeigh",
      "screen_name" : "JopieNet",
      "indices" : [ 32, 41 ],
      "id_str" : "371391064",
      "id" : 371391064
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "735426484568002560",
  "geo" : { },
  "id_str" : "735436782121160705",
  "in_reply_to_user_id" : 12984852,
  "text" : "@CameronNeylon @scholarlykitchn @JopieNet usage from inside institution: lack of subscription.",
  "id" : 735436782121160705,
  "in_reply_to_status_id" : 735426484568002560,
  "created_at" : "2016-05-25 11:46:07 +0000",
  "in_reply_to_screen_name" : "CameronNeylon",
  "in_reply_to_user_id_str" : "12984852",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "C\u24D0meronNeylon",
      "screen_name" : "CameronNeylon",
      "indices" : [ 0, 14 ],
      "id_str" : "12984852",
      "id" : 12984852
    }, {
      "name" : "Scholarly Kitchen",
      "screen_name" : "scholarlykitchn",
      "indices" : [ 15, 31 ],
      "id_str" : "119401334",
      "id" : 119401334
    }, {
      "name" : "Marie E McVeigh",
      "screen_name" : "JopieNet",
      "indices" : [ 32, 41 ],
      "id_str" : "371391064",
      "id" : 371391064
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "735426484568002560",
  "geo" : { },
  "id_str" : "735436576281530368",
  "in_reply_to_user_id" : 12984852,
  "text" : "@CameronNeylon @scholarlykitchn @JopieNet usage outside institutions: partially because it\u2019s easier than using institutional proxy.",
  "id" : 735436576281530368,
  "in_reply_to_status_id" : 735426484568002560,
  "created_at" : "2016-05-25 11:45:18 +0000",
  "in_reply_to_screen_name" : "CameronNeylon",
  "in_reply_to_user_id_str" : "12984852",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "C\u24D0meronNeylon",
      "screen_name" : "CameronNeylon",
      "indices" : [ 0, 14 ],
      "id_str" : "12984852",
      "id" : 12984852
    }, {
      "name" : "Scholarly Kitchen",
      "screen_name" : "scholarlykitchn",
      "indices" : [ 15, 31 ],
      "id_str" : "119401334",
      "id" : 119401334
    }, {
      "name" : "Marie E McVeigh",
      "screen_name" : "JopieNet",
      "indices" : [ 32, 41 ],
      "id_str" : "371391064",
      "id" : 371391064
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "735426484568002560",
  "geo" : { },
  "id_str" : "735436438846771200",
  "in_reply_to_user_id" : 12984852,
  "text" : "@CameronNeylon @scholarlykitchn @JopieNet depends on whether used from inside or outside their institutions.",
  "id" : 735436438846771200,
  "in_reply_to_status_id" : 735426484568002560,
  "created_at" : "2016-05-25 11:44:45 +0000",
  "in_reply_to_screen_name" : "CameronNeylon",
  "in_reply_to_user_id_str" : "12984852",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hay Kranen",
      "screen_name" : "hayify",
      "indices" : [ 3, 10 ],
      "id_str" : "6257562",
      "id" : 6257562
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "735435912197332992",
  "text" : "RT @hayify: Powerful letter from a Bataclan survivor about the racist remarks by Eagles of Death Metal frontman Jesse Hughes: https:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/aa4jKVhvSR",
        "expanded_url" : "http:\/\/www.theguardian.com\/commentisfree\/2016\/may\/24\/jesse-hughes-eagles-of-death-metal-paris-attacks-bataclan-survivor",
        "display_url" : "theguardian.com\/commentisfree\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "735380275656560642",
    "text" : "Powerful letter from a Bataclan survivor about the racist remarks by Eagles of Death Metal frontman Jesse Hughes: https:\/\/t.co\/aa4jKVhvSR",
    "id" : 735380275656560642,
    "created_at" : "2016-05-25 08:01:35 +0000",
    "user" : {
      "name" : "Hay Kranen",
      "screen_name" : "hayify",
      "protected" : false,
      "id_str" : "6257562",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/495863796242460673\/vFHoh3vJ_normal.jpeg",
      "id" : 6257562,
      "verified" : false
    }
  },
  "id" : 735435912197332992,
  "created_at" : "2016-05-25 11:42:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "C\u24D0meronNeylon",
      "screen_name" : "CameronNeylon",
      "indices" : [ 0, 14 ],
      "id_str" : "12984852",
      "id" : 12984852
    }, {
      "name" : "Scholarly Kitchen",
      "screen_name" : "scholarlykitchn",
      "indices" : [ 15, 31 ],
      "id_str" : "119401334",
      "id" : 119401334
    }, {
      "name" : "Marie E McVeigh",
      "screen_name" : "JopieNet",
      "indices" : [ 32, 41 ],
      "id_str" : "371391064",
      "id" : 371391064
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "735278145465618432",
  "geo" : { },
  "id_str" : "735409955143045120",
  "in_reply_to_user_id" : 12984852,
  "text" : "@CameronNeylon @scholarlykitchn @JopieNet so all the matching is doing is systematically underestimating the total %.",
  "id" : 735409955143045120,
  "in_reply_to_status_id" : 735278145465618432,
  "created_at" : "2016-05-25 09:59:31 +0000",
  "in_reply_to_screen_name" : "CameronNeylon",
  "in_reply_to_user_id_str" : "12984852",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "C\u24D0meronNeylon",
      "screen_name" : "CameronNeylon",
      "indices" : [ 0, 14 ],
      "id_str" : "12984852",
      "id" : 12984852
    }, {
      "name" : "Scholarly Kitchen",
      "screen_name" : "scholarlykitchn",
      "indices" : [ 15, 31 ],
      "id_str" : "119401334",
      "id" : 119401334
    }, {
      "name" : "Marie E McVeigh",
      "screen_name" : "JopieNet",
      "indices" : [ 32, 41 ],
      "id_str" : "371391064",
      "id" : 371391064
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "735278145465618432",
  "geo" : { },
  "id_str" : "735409730865270784",
  "in_reply_to_user_id" : 12984852,
  "text" : "@CameronNeylon @scholarlykitchn @JopieNet completely disagree w\/ the NFL comparison. Uni-IP ranges barely change.",
  "id" : 735409730865270784,
  "in_reply_to_status_id" : 735278145465618432,
  "created_at" : "2016-05-25 09:58:37 +0000",
  "in_reply_to_screen_name" : "CameronNeylon",
  "in_reply_to_user_id_str" : "12984852",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hilmar Lapp",
      "screen_name" : "hlapp",
      "indices" : [ 3, 9 ],
      "id_str" : "19042414",
      "id" : 19042414
    }, {
      "name" : "Michael R. Crusoe",
      "screen_name" : "biocrusoe",
      "indices" : [ 73, 83 ],
      "id_str" : "17645638",
      "id" : 17645638
    }, {
      "name" : "Anurag Priyam",
      "screen_name" : "yeban",
      "indices" : [ 89, 95 ],
      "id_str" : "18527414",
      "id" : 18527414
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "openscience",
      "indices" : [ 96, 108 ]
    } ],
    "urls" : [ {
      "indices" : [ 47, 70 ],
      "url" : "https:\/\/t.co\/CsFANaPXYK",
      "expanded_url" : "https:\/\/github.com\/dimitras",
      "display_url" : "github.com\/dimitras"
    }, {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/Hc7f7gdbCk",
      "expanded_url" : "https:\/\/twitter.com\/obf_news\/status\/735117772514959360",
      "display_url" : "twitter.com\/obf_news\/statu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "735383990899773441",
  "text" : "RT @hlapp: Congrats to Dimitra Saryantopoulou (https:\/\/t.co\/CsFANaPXYK), @biocrusoe, and @yeban #openscience https:\/\/t.co\/Hc7f7gdbCk",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Michael R. Crusoe",
        "screen_name" : "biocrusoe",
        "indices" : [ 62, 72 ],
        "id_str" : "17645638",
        "id" : 17645638
      }, {
        "name" : "Anurag Priyam",
        "screen_name" : "yeban",
        "indices" : [ 78, 84 ],
        "id_str" : "18527414",
        "id" : 18527414
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "openscience",
        "indices" : [ 85, 97 ]
      } ],
      "urls" : [ {
        "indices" : [ 36, 59 ],
        "url" : "https:\/\/t.co\/CsFANaPXYK",
        "expanded_url" : "https:\/\/github.com\/dimitras",
        "display_url" : "github.com\/dimitras"
      }, {
        "indices" : [ 98, 121 ],
        "url" : "https:\/\/t.co\/Hc7f7gdbCk",
        "expanded_url" : "https:\/\/twitter.com\/obf_news\/status\/735117772514959360",
        "display_url" : "twitter.com\/obf_news\/statu\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "735143261942255621",
    "text" : "Congrats to Dimitra Saryantopoulou (https:\/\/t.co\/CsFANaPXYK), @biocrusoe, and @yeban #openscience https:\/\/t.co\/Hc7f7gdbCk",
    "id" : 735143261942255621,
    "created_at" : "2016-05-24 16:19:46 +0000",
    "user" : {
      "name" : "Hilmar Lapp",
      "screen_name" : "hlapp",
      "protected" : false,
      "id_str" : "19042414",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/614959939870703620\/n2C_E0YN_normal.jpg",
      "id" : 19042414,
      "verified" : false
    }
  },
  "id" : 735383990899773441,
  "created_at" : "2016-05-25 08:16:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rayna",
      "screen_name" : "MaliciaRogue",
      "indices" : [ 0, 13 ],
      "id_str" : "189118361",
      "id" : 189118361
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "735348966875930632",
  "geo" : { },
  "id_str" : "735371960532750336",
  "in_reply_to_user_id" : 189118361,
  "text" : "@MaliciaRogue I played a bit around with Shiny for interactive graphs in the past. Never with plotly so far, will have a look :)",
  "id" : 735371960532750336,
  "in_reply_to_status_id" : 735348966875930632,
  "created_at" : "2016-05-25 07:28:32 +0000",
  "in_reply_to_screen_name" : "MaliciaRogue",
  "in_reply_to_user_id_str" : "189118361",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jun Axup",
      "screen_name" : "junaxup",
      "indices" : [ 0, 8 ],
      "id_str" : "19210703",
      "id" : 19210703
    }, {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 9, 18 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "735260772939399169",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06092541841911, 8.818844141016099 ]
  },
  "id_str" : "735359749173219329",
  "in_reply_to_user_id" : 19210703,
  "text" : "@junaxup @eramirez wow this Dr. looks like serious business! Congrats!",
  "id" : 735359749173219329,
  "in_reply_to_status_id" : 735260772939399169,
  "created_at" : "2016-05-25 06:40:01 +0000",
  "in_reply_to_screen_name" : "junaxup",
  "in_reply_to_user_id_str" : "19210703",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rayna",
      "screen_name" : "MaliciaRogue",
      "indices" : [ 0, 13 ],
      "id_str" : "189118361",
      "id" : 189118361
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "735222859434450945",
  "geo" : { },
  "id_str" : "735223189727510528",
  "in_reply_to_user_id" : 189118361,
  "text" : "@MaliciaRogue yes, R + ggplot2. :)",
  "id" : 735223189727510528,
  "in_reply_to_status_id" : 735222859434450945,
  "created_at" : "2016-05-24 21:37:22 +0000",
  "in_reply_to_screen_name" : "MaliciaRogue",
  "in_reply_to_user_id_str" : "189118361",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Edmunds",
      "screen_name" : "SCEdmunds",
      "indices" : [ 0, 10 ],
      "id_str" : "176024190",
      "id" : 176024190
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/CslKy2kvoL",
      "expanded_url" : "http:\/\/ruleofthirds.de\/scihub-part2\/#update-2",
      "display_url" : "ruleofthirds.de\/scihub-part2\/#\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "734965448450531328",
  "geo" : { },
  "id_str" : "735222951138742272",
  "in_reply_to_user_id" : 176024190,
  "text" : "@SCEdmunds Nowruz didn\u2019t work due to time frame, but any other Iranian holidays in here? https:\/\/t.co\/CslKy2kvoL",
  "id" : 735222951138742272,
  "in_reply_to_status_id" : 734965448450531328,
  "created_at" : "2016-05-24 21:36:25 +0000",
  "in_reply_to_screen_name" : "SCEdmunds",
  "in_reply_to_user_id_str" : "176024190",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rayna",
      "screen_name" : "MaliciaRogue",
      "indices" : [ 125, 138 ],
      "id_str" : "189118361",
      "id" : 189118361
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "scihub",
      "indices" : [ 25, 32 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/CslKy2kvoL",
      "expanded_url" : "http:\/\/ruleofthirds.de\/scihub-part2\/#update-2",
      "display_url" : "ruleofthirds.de\/scihub-part2\/#\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "735217666034651136",
  "text" : "And another update to my #scihub article: Splitting time-series by country to see some patterns. https:\/\/t.co\/CslKy2kvoL \/cc @MaliciaRogue",
  "id" : 735217666034651136,
  "created_at" : "2016-05-24 21:15:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elio Qoshi",
      "screen_name" : "elioqoshi",
      "indices" : [ 66, 76 ],
      "id_str" : "93434375",
      "id" : 93434375
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/poRRbE1rzR",
      "expanded_url" : "https:\/\/www.stickermule.com\/artworks\/749959?token=07acb3c63e25ea3a5e4ebc2a650a3b70",
      "display_url" : "stickermule.com\/artworks\/74995\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "735204530669953024",
  "text" : "Look what you might get from me at the next conference. Thanks to @elioqoshi for the design! https:\/\/t.co\/poRRbE1rzR",
  "id" : 735204530669953024,
  "created_at" : "2016-05-24 20:23:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elizabeth Seiver",
      "screen_name" : "tweetotaler",
      "indices" : [ 0, 12 ],
      "id_str" : "29891068",
      "id" : 29891068
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "735180151466668032",
  "geo" : { },
  "id_str" : "735201192578519040",
  "in_reply_to_user_id" : 29891068,
  "text" : "@tweetotaler literally \u201Etwenty o\u2019clock forty-five\u201C. But many would switch back to 12h formatting for such times.",
  "id" : 735201192578519040,
  "in_reply_to_status_id" : 735180151466668032,
  "created_at" : "2016-05-24 20:09:58 +0000",
  "in_reply_to_screen_name" : "tweetotaler",
  "in_reply_to_user_id_str" : "29891068",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "scihub",
      "indices" : [ 40, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/EsLazAFHUY",
      "expanded_url" : "http:\/\/ruleofthirds.de\/scihub-part2\/",
      "display_url" : "ruleofthirds.de\/scihub-part2\/"
    } ]
  },
  "geo" : { },
  "id_str" : "735137265941401600",
  "text" : "At least one person has an idea why the #scihub downloads from universities are seasonal. See at the end: https:\/\/t.co\/EsLazAFHUY",
  "id" : 735137265941401600,
  "created_at" : "2016-05-24 15:55:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rayna",
      "screen_name" : "MaliciaRogue",
      "indices" : [ 0, 13 ],
      "id_str" : "189118361",
      "id" : 189118361
    }, {
      "name" : "Alexander Doria",
      "screen_name" : "Dorialexander",
      "indices" : [ 14, 28 ],
      "id_str" : "276508048",
      "id" : 276508048
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/735134812940472320\/photo\/1",
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/qmOXpAKZQ7",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CjO5Ns6WgAAJSiU.png",
      "id_str" : "735134809236865024",
      "id" : 735134809236865024,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CjO5Ns6WgAAJSiU.png",
      "sizes" : [ {
        "h" : 1085,
        "resize" : "fit",
        "w" : 1952
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1085,
        "resize" : "fit",
        "w" : 1952
      }, {
        "h" : 667,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 378,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/qmOXpAKZQ7"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "735130749792362496",
  "geo" : { },
  "id_str" : "735134812940472320",
  "in_reply_to_user_id" : 189118361,
  "text" : "@MaliciaRogue @Dorialexander that\u2019s for France. But due to the lower data resolution it\u2019s rather crude. https:\/\/t.co\/qmOXpAKZQ7",
  "id" : 735134812940472320,
  "in_reply_to_status_id" : 735130749792362496,
  "created_at" : "2016-05-24 15:46:12 +0000",
  "in_reply_to_screen_name" : "MaliciaRogue",
  "in_reply_to_user_id_str" : "189118361",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Egle Ramanauskaite \u2623",
      "screen_name" : "Seplute",
      "indices" : [ 0, 8 ],
      "id_str" : "188833865",
      "id" : 188833865
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "735129511910576129",
  "geo" : { },
  "id_str" : "735129591413624832",
  "in_reply_to_user_id" : 188833865,
  "text" : "@Seplute I know, just to give positive feedback \uD83D\uDE0D",
  "id" : 735129591413624832,
  "in_reply_to_status_id" : 735129511910576129,
  "created_at" : "2016-05-24 15:25:27 +0000",
  "in_reply_to_screen_name" : "Seplute",
  "in_reply_to_user_id_str" : "188833865",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Egle Ramanauskaite \u2623",
      "screen_name" : "Seplute",
      "indices" : [ 0, 8 ],
      "id_str" : "188833865",
      "id" : 188833865
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "735042939722825728",
  "geo" : { },
  "id_str" : "735129337297555459",
  "in_reply_to_user_id" : 188833865,
  "text" : "@Seplute please keep me in the loop on all things lichens! :D",
  "id" : 735129337297555459,
  "in_reply_to_status_id" : 735042939722825728,
  "created_at" : "2016-05-24 15:24:26 +0000",
  "in_reply_to_screen_name" : "Seplute",
  "in_reply_to_user_id_str" : "188833865",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rayna",
      "screen_name" : "MaliciaRogue",
      "indices" : [ 0, 13 ],
      "id_str" : "189118361",
      "id" : 189118361
    }, {
      "name" : "Alexander Doria",
      "screen_name" : "Dorialexander",
      "indices" : [ 14, 28 ],
      "id_str" : "276508048",
      "id" : 276508048
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "735107709457080320",
  "geo" : { },
  "id_str" : "735120397205708800",
  "in_reply_to_user_id" : 189118361,
  "text" : "@MaliciaRogue @Dorialexander tried plotting per country, hard to do for all in a meaningful way. Which countries would you like to see?",
  "id" : 735120397205708800,
  "in_reply_to_status_id" : 735107709457080320,
  "created_at" : "2016-05-24 14:48:55 +0000",
  "in_reply_to_screen_name" : "MaliciaRogue",
  "in_reply_to_user_id_str" : "189118361",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rayna",
      "screen_name" : "MaliciaRogue",
      "indices" : [ 0, 13 ],
      "id_str" : "189118361",
      "id" : 189118361
    }, {
      "name" : "Alexander Doria",
      "screen_name" : "Dorialexander",
      "indices" : [ 14, 28 ],
      "id_str" : "276508048",
      "id" : 276508048
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "735103997615476736",
  "geo" : { },
  "id_str" : "735105483292483584",
  "in_reply_to_user_id" : 189118361,
  "text" : "@MaliciaRogue @Dorialexander you mean variance by country over time?",
  "id" : 735105483292483584,
  "in_reply_to_status_id" : 735103997615476736,
  "created_at" : "2016-05-24 13:49:39 +0000",
  "in_reply_to_screen_name" : "MaliciaRogue",
  "in_reply_to_user_id_str" : "189118361",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rayna",
      "screen_name" : "MaliciaRogue",
      "indices" : [ 0, 13 ],
      "id_str" : "189118361",
      "id" : 189118361
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "735081745490579456",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17236368364681, 8.627541648988345 ]
  },
  "id_str" : "735099967593910272",
  "in_reply_to_user_id" : 189118361,
  "text" : "@MaliciaRogue glad you like it :-)",
  "id" : 735099967593910272,
  "in_reply_to_status_id" : 735081745490579456,
  "created_at" : "2016-05-24 13:27:44 +0000",
  "in_reply_to_screen_name" : "MaliciaRogue",
  "in_reply_to_user_id_str" : "189118361",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yaniv (((Erlich)))",
      "screen_name" : "erlichya",
      "indices" : [ 0, 9 ],
      "id_str" : "495517322",
      "id" : 495517322
    }, {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 10, 19 ],
      "id_str" : "14245811",
      "id" : 14245811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "735081828365815808",
  "geo" : { },
  "id_str" : "735082111628156929",
  "in_reply_to_user_id" : 495517322,
  "text" : "@erlichya @wilbanks agree on not saving the data in the first place though. With openSNP this is just what we\u2019re doing.",
  "id" : 735082111628156929,
  "in_reply_to_status_id" : 735081828365815808,
  "created_at" : "2016-05-24 12:16:47 +0000",
  "in_reply_to_screen_name" : "erlichya",
  "in_reply_to_user_id_str" : "495517322",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yaniv (((Erlich)))",
      "screen_name" : "erlichya",
      "indices" : [ 0, 9 ],
      "id_str" : "495517322",
      "id" : 495517322
    }, {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 10, 19 ],
      "id_str" : "14245811",
      "id" : 14245811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "735081828365815808",
  "geo" : { },
  "id_str" : "735081932351000576",
  "in_reply_to_user_id" : 495517322,
  "text" : "@erlichya @wilbanks no, the data they released to science is also publicly available and does not contain the addresses.",
  "id" : 735081932351000576,
  "in_reply_to_status_id" : 735081828365815808,
  "created_at" : "2016-05-24 12:16:04 +0000",
  "in_reply_to_screen_name" : "erlichya",
  "in_reply_to_user_id_str" : "495517322",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angela Cochran",
      "screen_name" : "acochran12733",
      "indices" : [ 0, 14 ],
      "id_str" : "555967172",
      "id" : 555967172
    }, {
      "name" : "Richard Poynder",
      "screen_name" : "RickyPo",
      "indices" : [ 15, 23 ],
      "id_str" : "20298671",
      "id" : 20298671
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "735080808441077764",
  "geo" : { },
  "id_str" : "735081473301172225",
  "in_reply_to_user_id" : 555967172,
  "text" : "@acochran12733 @RickyPo happy to help!",
  "id" : 735081473301172225,
  "in_reply_to_status_id" : 735080808441077764,
  "created_at" : "2016-05-24 12:14:15 +0000",
  "in_reply_to_screen_name" : "acochran12733",
  "in_reply_to_user_id_str" : "555967172",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yaniv (((Erlich)))",
      "screen_name" : "erlichya",
      "indices" : [ 0, 9 ],
      "id_str" : "495517322",
      "id" : 495517322
    }, {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 10, 19 ],
      "id_str" : "14245811",
      "id" : 14245811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "735081191297167360",
  "geo" : { },
  "id_str" : "735081433799266306",
  "in_reply_to_user_id" : 495517322,
  "text" : "@erlichya @wilbanks I think you misunderstood\/overread it in my article: Sci-Hub never gave me their addresses.",
  "id" : 735081433799266306,
  "in_reply_to_status_id" : 735081191297167360,
  "created_at" : "2016-05-24 12:14:05 +0000",
  "in_reply_to_screen_name" : "erlichya",
  "in_reply_to_user_id_str" : "495517322",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angela Cochran",
      "screen_name" : "acochran12733",
      "indices" : [ 0, 14 ],
      "id_str" : "555967172",
      "id" : 555967172
    }, {
      "name" : "Richard Poynder",
      "screen_name" : "RickyPo",
      "indices" : [ 15, 23 ],
      "id_str" : "20298671",
      "id" : 20298671
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "735079407396782080",
  "geo" : { },
  "id_str" : "735079639840870400",
  "in_reply_to_user_id" : 555967172,
  "text" : "@acochran12733 @RickyPo yes, so it would underestimate the % university users. As I said: it\u2019s a very conservative estimate :)",
  "id" : 735079639840870400,
  "in_reply_to_status_id" : 735079407396782080,
  "created_at" : "2016-05-24 12:06:57 +0000",
  "in_reply_to_screen_name" : "acochran12733",
  "in_reply_to_user_id_str" : "555967172",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angela Cochran",
      "screen_name" : "acochran12733",
      "indices" : [ 0, 14 ],
      "id_str" : "555967172",
      "id" : 555967172
    }, {
      "name" : "Richard Poynder",
      "screen_name" : "RickyPo",
      "indices" : [ 15, 23 ],
      "id_str" : "20298671",
      "id" : 20298671
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "735077431393067008",
  "geo" : { },
  "id_str" : "735079036825808898",
  "in_reply_to_user_id" : 555967172,
  "text" : "@acochran12733 @RickyPo nope it wasn\u2019t. Just a very simple IP matching. You assume proxies would be inside universities?",
  "id" : 735079036825808898,
  "in_reply_to_status_id" : 735077431393067008,
  "created_at" : "2016-05-24 12:04:34 +0000",
  "in_reply_to_screen_name" : "acochran12733",
  "in_reply_to_user_id_str" : "555967172",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 0, 9 ],
      "id_str" : "14245811",
      "id" : 14245811
    }, {
      "name" : "Dan Hagon",
      "screen_name" : "axiomsofchoice",
      "indices" : [ 10, 25 ],
      "id_str" : "27238310",
      "id" : 27238310
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "735070065683496960",
  "geo" : { },
  "id_str" : "735070955354066944",
  "in_reply_to_user_id" : 14245811,
  "text" : "@wilbanks @axiomsofchoice totally, but I couldn\u2019t find any better\/newer\/larger data source for the IPs. Don\u2019t expect much VPN traffic.",
  "id" : 735070955354066944,
  "in_reply_to_status_id" : 735070065683496960,
  "created_at" : "2016-05-24 11:32:27 +0000",
  "in_reply_to_screen_name" : "wilbanks",
  "in_reply_to_user_id_str" : "14245811",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 61 ],
      "url" : "https:\/\/t.co\/j5oe4ujWpU",
      "expanded_url" : "http:\/\/www.asofterworld.com\/index.php?id=1245",
      "display_url" : "asofterworld.com\/index.php?id=1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "735039257799217152",
  "text" : "I know, it\u2019s still half an hour, but\u2026 https:\/\/t.co\/j5oe4ujWpU",
  "id" : 735039257799217152,
  "created_at" : "2016-05-24 09:26:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amy Hoy \u2728",
      "screen_name" : "amyhoy",
      "indices" : [ 3, 10 ],
      "id_str" : "627213",
      "id" : 627213
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "735034073069039616",
  "text" : "RT @amyhoy: \"if you really love your work, it's easy to work 100-hour weeks!\" i really love donuts, but if i eat a whole box, i realize tha\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/meetedgar.com\" rel=\"nofollow\"\u003EMeet Edgar\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "734021146421649410",
    "text" : "\"if you really love your work, it's easy to work 100-hour weeks!\" i really love donuts, but if i eat a whole box, i realize that i'm stupid.",
    "id" : 734021146421649410,
    "created_at" : "2016-05-21 14:00:53 +0000",
    "user" : {
      "name" : "Amy Hoy \u2728",
      "screen_name" : "amyhoy",
      "protected" : false,
      "id_str" : "627213",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745996047055388672\/Inm0q5___normal.jpg",
      "id" : 627213,
      "verified" : false
    }
  },
  "id" : 735034073069039616,
  "created_at" : "2016-05-24 09:05:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luc Henry",
      "screen_name" : "heluc",
      "indices" : [ 0, 6 ],
      "id_str" : "850645992",
      "id" : 850645992
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "735031947320262656",
  "geo" : { },
  "id_str" : "735032793982504961",
  "in_reply_to_user_id" : 850645992,
  "text" : "@heluc no it isn\u2019t really sustainable (that trip alone will be like 3 tons, so I should plant 15 trees\u2026)",
  "id" : 735032793982504961,
  "in_reply_to_status_id" : 735031947320262656,
  "created_at" : "2016-05-24 09:00:48 +0000",
  "in_reply_to_screen_name" : "heluc",
  "in_reply_to_user_id_str" : "850645992",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luc Henry",
      "screen_name" : "heluc",
      "indices" : [ 0, 6 ],
      "id_str" : "850645992",
      "id" : 850645992
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "735030555415306240",
  "geo" : { },
  "id_str" : "735031291536650240",
  "in_reply_to_user_id" : 850645992,
  "text" : "@heluc this is probably the time where I should say that I\u2019ve been living vegetarian for years by now, right? :p",
  "id" : 735031291536650240,
  "in_reply_to_status_id" : 735030555415306240,
  "created_at" : "2016-05-24 08:54:50 +0000",
  "in_reply_to_screen_name" : "heluc",
  "in_reply_to_user_id_str" : "850645992",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BOSC2016",
      "indices" : [ 92, 101 ]
    }, {
      "text" : "smbe16",
      "indices" : [ 106, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/ZirGkYtD1T",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/734812436667195392",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "734812436667195392",
  "geo" : { },
  "id_str" : "735029448777535492",
  "in_reply_to_user_id" : 14286491,
  "text" : "Managed in the end. FRA \u2708\uFE0F HKG \u2708\uFE0F BNE \u2708\uFE0F LAX \u2708\uFE0F MCO \u2708\uFE0F JFK \u2708\uFE0F FRA it is. Looking forward to #BOSC2016 and #smbe16 \uD83C\uDF89 https:\/\/t.co\/ZirGkYtD1T",
  "id" : 735029448777535492,
  "in_reply_to_status_id" : 734812436667195392,
  "created_at" : "2016-05-24 08:47:31 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony Ross-Hellauer",
      "screen_name" : "tonyR_H",
      "indices" : [ 0, 8 ],
      "id_str" : "44890780",
      "id" : 44890780
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "735024831679336448",
  "geo" : { },
  "id_str" : "735025828661239809",
  "in_reply_to_user_id" : 44890780,
  "text" : "@tonyR_H thanks, glad you like it!",
  "id" : 735025828661239809,
  "in_reply_to_status_id" : 735024831679336448,
  "created_at" : "2016-05-24 08:33:08 +0000",
  "in_reply_to_screen_name" : "tonyR_H",
  "in_reply_to_user_id_str" : "44890780",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony Ross-Hellauer",
      "screen_name" : "tonyR_H",
      "indices" : [ 0, 8 ],
      "id_str" : "44890780",
      "id" : 44890780
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "735022447553064960",
  "geo" : { },
  "id_str" : "735022550414196736",
  "in_reply_to_user_id" : 44890780,
  "text" : "@tonyR_H you missed the link :p",
  "id" : 735022550414196736,
  "in_reply_to_status_id" : 735022447553064960,
  "created_at" : "2016-05-24 08:20:06 +0000",
  "in_reply_to_screen_name" : "tonyR_H",
  "in_reply_to_user_id_str" : "44890780",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "scihub",
      "indices" : [ 71, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/MARkDqAvHl",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/734856933992173568",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "734856933992173568",
  "geo" : { },
  "id_str" : "735022172108918784",
  "in_reply_to_user_id" : 14286491,
  "text" : "For those who missed it yesterday evening: My next steps in looking at #scihub usage &amp; Academia. https:\/\/t.co\/MARkDqAvHl",
  "id" : 735022172108918784,
  "in_reply_to_status_id" : 734856933992173568,
  "created_at" : "2016-05-24 08:18:36 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Austin Richardson",
      "screen_name" : "heyaudy",
      "indices" : [ 0, 8 ],
      "id_str" : "14534523",
      "id" : 14534523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "734995430098886656",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.15909371998382, 8.685716011786168 ]
  },
  "id_str" : "734996509930991616",
  "in_reply_to_user_id" : 14534523,
  "text" : "@heyaudy \uD83D\uDE31",
  "id" : 734996509930991616,
  "in_reply_to_status_id" : 734995430098886656,
  "created_at" : "2016-05-24 06:36:38 +0000",
  "in_reply_to_screen_name" : "heyaudy",
  "in_reply_to_user_id_str" : "14534523",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Edmunds",
      "screen_name" : "SCEdmunds",
      "indices" : [ 0, 10 ],
      "id_str" : "176024190",
      "id" : 176024190
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "734964961613516800",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11403554055852, 8.753418740371547 ]
  },
  "id_str" : "734984633281040384",
  "in_reply_to_user_id" : 176024190,
  "text" : "@SCEdmunds by sleeping less than 6 hours per night. (\u201CGet your PhD with one simple trick: become a vampire!\u201D)",
  "id" : 734984633281040384,
  "in_reply_to_status_id" : 734964961613516800,
  "created_at" : "2016-05-24 05:49:26 +0000",
  "in_reply_to_screen_name" : "SCEdmunds",
  "in_reply_to_user_id_str" : "176024190",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Austin Richardson",
      "screen_name" : "heyaudy",
      "indices" : [ 0, 8 ],
      "id_str" : "14534523",
      "id" : 14534523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "734897732326969344",
  "geo" : { },
  "id_str" : "734897981598670848",
  "in_reply_to_user_id" : 14534523,
  "text" : "@heyaudy \u201Efunctional element, according to ENCODE\u201C :D",
  "id" : 734897981598670848,
  "in_reply_to_status_id" : 734897732326969344,
  "created_at" : "2016-05-24 00:05:07 +0000",
  "in_reply_to_screen_name" : "heyaudy",
  "in_reply_to_user_id_str" : "14534523",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Austin Richardson",
      "screen_name" : "heyaudy",
      "indices" : [ 0, 8 ],
      "id_str" : "14534523",
      "id" : 14534523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "734896371162075140",
  "geo" : { },
  "id_str" : "734896853246955521",
  "in_reply_to_user_id" : 14534523,
  "text" : "@heyaudy next step: hypothetical protein-like precursor.",
  "id" : 734896853246955521,
  "in_reply_to_status_id" : 734896371162075140,
  "created_at" : "2016-05-24 00:00:38 +0000",
  "in_reply_to_screen_name" : "heyaudy",
  "in_reply_to_user_id_str" : "14534523",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/ssT0yT5YK9",
      "expanded_url" : "https:\/\/twitter.com\/heyaudy\/status\/734894416264081408",
      "display_url" : "twitter.com\/heyaudy\/status\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "734895122287104000",
  "text" : "Just what bioinformatics needed, yet another way to annotate things as hypothetical XYZ :D https:\/\/t.co\/ssT0yT5YK9",
  "id" : 734895122287104000,
  "created_at" : "2016-05-23 23:53:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert Davey",
      "screen_name" : "froggleston",
      "indices" : [ 0, 12 ],
      "id_str" : "53893339",
      "id" : 53893339
    }, {
      "name" : "Nick Loman",
      "screen_name" : "pathogenomenick",
      "indices" : [ 13, 29 ],
      "id_str" : "85906238",
      "id" : 85906238
    }, {
      "name" : "Mick Watson",
      "screen_name" : "BioMickWatson",
      "indices" : [ 30, 44 ],
      "id_str" : "228586748",
      "id" : 228586748
    }, {
      "name" : "Matt Loose",
      "screen_name" : "mattloose",
      "indices" : [ 45, 55 ],
      "id_str" : "9325082",
      "id" : 9325082
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/TP9WRwFWY8",
      "expanded_url" : "http:\/\/s187.photobucket.com\/user\/paul3rd_bucket\/media\/paul3rd_bucket%202\/Brad_Byers_Staple_gun2.jpg.html",
      "display_url" : "s187.photobucket.com\/user\/paul3rd_b\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "734881973773160452",
  "geo" : { },
  "id_str" : "734882731755245568",
  "in_reply_to_user_id" : 53893339,
  "text" : "@froggleston @pathogenomenick @BioMickWatson @mattloose how I assume this will end https:\/\/t.co\/TP9WRwFWY8",
  "id" : 734882731755245568,
  "in_reply_to_status_id" : 734881973773160452,
  "created_at" : "2016-05-23 23:04:31 +0000",
  "in_reply_to_screen_name" : "froggleston",
  "in_reply_to_user_id_str" : "53893339",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/9PtO4l6LEZ",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/734878054221287424",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "734878054221287424",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11373836009797, 8.753683337492852 ]
  },
  "id_str" : "734878361714057217",
  "in_reply_to_user_id" : 14286491,
  "text" : "But then, if you ever wondered about my curiosity, that might make an equally good case. https:\/\/t.co\/9PtO4l6LEZ",
  "id" : 734878361714057217,
  "in_reply_to_status_id" : 734878054221287424,
  "created_at" : "2016-05-23 22:47:09 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11374228437242, 8.75367856191029 ]
  },
  "id_str" : "734878054221287424",
  "text" : "Ever wondered about my lack of diplomacy? My mom: \u00ABCan\u2019t you bring your new girlfriend instead of the one we know to grandma\u2019s birthday?\u00BB",
  "id" : 734878054221287424,
  "created_at" : "2016-05-23 22:45:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Corne",
      "screen_name" : "D4ntali0n",
      "indices" : [ 0, 10 ],
      "id_str" : "39760223",
      "id" : 39760223
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "scihub",
      "indices" : [ 77, 84 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "734860882870738944",
  "geo" : { },
  "id_str" : "734861302393393152",
  "in_reply_to_user_id" : 39760223,
  "text" : "@D4ntali0n totally, and just to be clear: I had to download 3 papers through #scihub while in my university office today :p",
  "id" : 734861302393393152,
  "in_reply_to_status_id" : 734860882870738944,
  "created_at" : "2016-05-23 21:39:22 +0000",
  "in_reply_to_screen_name" : "D4ntali0n",
  "in_reply_to_user_id_str" : "39760223",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SciHub",
      "indices" : [ 14, 21 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/EsLazAFHUY",
      "expanded_url" : "http:\/\/ruleofthirds.de\/scihub-part2\/",
      "display_url" : "ruleofthirds.de\/scihub-part2\/"
    } ]
  },
  "geo" : { },
  "id_str" : "734856933992173568",
  "text" : "Analyzing the #SciHub Data Part 2: Who\u2019s downloading pirated papers? Academics do for sure! https:\/\/t.co\/EsLazAFHUY",
  "id" : 734856933992173568,
  "created_at" : "2016-05-23 21:22:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "734812436667195392",
  "geo" : { },
  "id_str" : "734814880046448640",
  "in_reply_to_user_id" : 14286491,
  "text" : "Need to wire money from my regular bank account to my CC to top it up. But due to switching my phone I can\u2019t get the TAN to approve it. m(",
  "id" : 734814880046448640,
  "in_reply_to_status_id" : 734812436667195392,
  "created_at" : "2016-05-23 18:34:54 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 83 ],
      "url" : "https:\/\/t.co\/Q8nG7j2nfs",
      "expanded_url" : "http:\/\/stream1.gifsoup.com\/view5\/2707835\/no-uniform-catch-22-o.gif",
      "display_url" : "stream1.gifsoup.com\/view5\/2707835\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "734812436667195392",
  "text" : "ok, buying this last stupid flight is ending in a catch-22\u2026 https:\/\/t.co\/Q8nG7j2nfs",
  "id" : 734812436667195392,
  "created_at" : "2016-05-23 18:25:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "734682096376090624",
  "geo" : { },
  "id_str" : "734682642252234752",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot and also print it in a nice format :p",
  "id" : 734682642252234752,
  "in_reply_to_status_id" : 734682096376090624,
  "created_at" : "2016-05-23 09:49:26 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "734677351162904576",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot \u201ECongratulations! Your tab Georgia by The Dwells has been approved. Now you may brag about it to your friends.\u201C nice joint work \uD83D\uDE0A",
  "id" : 734677351162904576,
  "created_at" : "2016-05-23 09:28:24 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 88 ],
      "url" : "https:\/\/t.co\/JxP7MaHmzw",
      "expanded_url" : "http:\/\/www.pbs.org\/newshour\/updates\/is-traveling-on-hyperloop-a-ticket-to-puke-city\/",
      "display_url" : "pbs.org\/newshour\/updat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "734675734959169536",
  "text" : "\u201Eis traveling on hyperloop a ticket to puke city?\u201C (spoiler: no) https:\/\/t.co\/JxP7MaHmzw",
  "id" : 734675734959169536,
  "created_at" : "2016-05-23 09:21:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 38 ],
      "url" : "https:\/\/t.co\/34ToI0hTvS",
      "expanded_url" : "https:\/\/en.wikipedia.org\/wiki\/Gross_enrolment_ratio#Example",
      "display_url" : "en.wikipedia.org\/wiki\/Gross_enr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "734665912998055936",
  "text" : "Before reading https:\/\/t.co\/34ToI0hTvS I was briefly confused how Greece managed to consistently have enrolment rates &gt; 100%.",
  "id" : 734665912998055936,
  "created_at" : "2016-05-23 08:42:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/V4WqDqc7QO",
      "expanded_url" : "http:\/\/gifsec.com\/wp-content\/uploads\/GIF\/2015\/01\/Decide-Decision-Decisions-Dont-Know-Flip-Flop-Flipflop-Indecisive-Kristen-Wiig-Maybe-Uncertain-Undecided-Unsure-GIF.gif?gs=a",
      "display_url" : "gifsec.com\/wp-content\/upl\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11404476550658, 8.753444686243265 ]
  },
  "id_str" : "734528380842954757",
  "text" : "ftw you get a very cool data set that you desperately wanna analyze just 5 minutes before you wanted to go to bed. https:\/\/t.co\/V4WqDqc7QO",
  "id" : 734528380842954757,
  "created_at" : "2016-05-22 23:36:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Simon Cockell",
      "screen_name" : "sjcockell",
      "indices" : [ 0, 10 ],
      "id_str" : "15084702",
      "id" : 15084702
    }, {
      "name" : "Peter Cock",
      "screen_name" : "pjacock",
      "indices" : [ 11, 19 ],
      "id_str" : "58756672",
      "id" : 58756672
    }, {
      "name" : "Fitbit Support",
      "screen_name" : "FitbitSupport",
      "indices" : [ 20, 34 ],
      "id_str" : "476258341",
      "id" : 476258341
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "734490877587009537",
  "geo" : { },
  "id_str" : "734491052766334977",
  "in_reply_to_user_id" : 15084702,
  "text" : "@sjcockell @pjacock @FitbitSupport they do have an API, so you can get all your data out from them.",
  "id" : 734491052766334977,
  "in_reply_to_status_id" : 734490877587009537,
  "created_at" : "2016-05-22 21:08:07 +0000",
  "in_reply_to_screen_name" : "sjcockell",
  "in_reply_to_user_id_str" : "15084702",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Cock",
      "screen_name" : "pjacock",
      "indices" : [ 0, 8 ],
      "id_str" : "58756672",
      "id" : 58756672
    }, {
      "name" : "Simon Cockell",
      "screen_name" : "sjcockell",
      "indices" : [ 9, 19 ],
      "id_str" : "15084702",
      "id" : 15084702
    }, {
      "name" : "Fitbit Support",
      "screen_name" : "FitbitSupport",
      "indices" : [ 47, 61 ],
      "id_str" : "476258341",
      "id" : 476258341
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "734485831751204864",
  "geo" : { },
  "id_str" : "734490593355825153",
  "in_reply_to_user_id" : 58756672,
  "text" : "@pjacock @sjcockell both things happened to my @FitbitSupport devices. Stopped replacing\/upgrading them because of it :(",
  "id" : 734490593355825153,
  "in_reply_to_status_id" : 734485831751204864,
  "created_at" : "2016-05-22 21:06:18 +0000",
  "in_reply_to_screen_name" : "pjacock",
  "in_reply_to_user_id_str" : "58756672",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "B.",
      "screen_name" : "Kurfuerstin",
      "indices" : [ 3, 15 ],
      "id_str" : "1321158876",
      "id" : 1321158876
    }, {
      "name" : "Sarah Spain",
      "screen_name" : "SarahSpain",
      "indices" : [ 86, 97 ],
      "id_str" : "18494981",
      "id" : 18494981
    }, {
      "name" : "Julie DiCaro",
      "screen_name" : "JulieDiCaro",
      "indices" : [ 98, 110 ],
      "id_str" : "28565368",
      "id" : 28565368
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "733677882728415236",
  "text" : "RT @Kurfuerstin: Men struggle to read online harassments that female sports reporters @SarahSpain @JulieDiCaro receive daily...\nhttps:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Sarah Spain",
        "screen_name" : "SarahSpain",
        "indices" : [ 69, 80 ],
        "id_str" : "18494981",
        "id" : 18494981
      }, {
        "name" : "Julie DiCaro",
        "screen_name" : "JulieDiCaro",
        "indices" : [ 81, 93 ],
        "id_str" : "28565368",
        "id" : 28565368
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 111, 134 ],
        "url" : "https:\/\/t.co\/HFyTsONtCe",
        "expanded_url" : "https:\/\/www.youtube.com\/watch?v=9tU-D-m2JY8",
        "display_url" : "youtube.com\/watch?v=9tU-D-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "733636054268403712",
    "text" : "Men struggle to read online harassments that female sports reporters @SarahSpain @JulieDiCaro receive daily...\nhttps:\/\/t.co\/HFyTsONtCe",
    "id" : 733636054268403712,
    "created_at" : "2016-05-20 12:30:40 +0000",
    "user" : {
      "name" : "B.",
      "screen_name" : "Kurfuerstin",
      "protected" : false,
      "id_str" : "1321158876",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000746561075\/52d262a9881f32923c4a667ef4d4cf43_normal.jpeg",
      "id" : 1321158876,
      "verified" : false
    }
  },
  "id" : 733677882728415236,
  "created_at" : "2016-05-20 15:16:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Cock",
      "screen_name" : "pjacock",
      "indices" : [ 0, 8 ],
      "id_str" : "58756672",
      "id" : 58756672
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "733661576981585921",
  "geo" : { },
  "id_str" : "733668965910745090",
  "in_reply_to_user_id" : 58756672,
  "text" : "@pjacock seems it\u2019s travel planning day :-)",
  "id" : 733668965910745090,
  "in_reply_to_status_id" : 733661576981585921,
  "created_at" : "2016-05-20 14:41:27 +0000",
  "in_reply_to_screen_name" : "pjacock",
  "in_reply_to_user_id_str" : "58756672",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "733583358605680642",
  "geo" : { },
  "id_str" : "733652203148283904",
  "in_reply_to_user_id" : 14286491,
  "text" : "And there\u2019s FRA \u2708\uFE0F BNE. Now I only need to find a good connection for BNE \u2708\uFE0F MCO.",
  "id" : 733652203148283904,
  "in_reply_to_status_id" : 733583358605680642,
  "created_at" : "2016-05-20 13:34:50 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Egle Ramanauskaite \u2623",
      "screen_name" : "Seplute",
      "indices" : [ 0, 8 ],
      "id_str" : "188833865",
      "id" : 188833865
    }, {
      "name" : "Alice Sheppard",
      "screen_name" : "PenguinGalaxy",
      "indices" : [ 9, 23 ],
      "id_str" : "20635230",
      "id" : 20635230
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "733638592946417664",
  "geo" : { },
  "id_str" : "733638988259590144",
  "in_reply_to_user_id" : 188833865,
  "text" : "@Seplute @PenguinGalaxy I think there\u2019s no timeline yet.",
  "id" : 733638988259590144,
  "in_reply_to_status_id" : 733638592946417664,
  "created_at" : "2016-05-20 12:42:19 +0000",
  "in_reply_to_screen_name" : "Seplute",
  "in_reply_to_user_id_str" : "188833865",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alice Sheppard",
      "screen_name" : "PenguinGalaxy",
      "indices" : [ 0, 14 ],
      "id_str" : "20635230",
      "id" : 20635230
    }, {
      "name" : "Egle Ramanauskaite \u2623",
      "screen_name" : "Seplute",
      "indices" : [ 15, 23 ],
      "id_str" : "188833865",
      "id" : 188833865
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 47 ],
      "url" : "https:\/\/t.co\/zkmvwr5fTh",
      "expanded_url" : "https:\/\/mozillafestival.org\/",
      "display_url" : "mozillafestival.org"
    } ]
  },
  "in_reply_to_status_id_str" : "733637718631157761",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17247700190394, 8.627374826194151 ]
  },
  "id_str" : "733637893722415104",
  "in_reply_to_user_id" : 20635230,
  "text" : "@PenguinGalaxy @Seplute https:\/\/t.co\/zkmvwr5fTh",
  "id" : 733637893722415104,
  "in_reply_to_status_id" : 733637718631157761,
  "created_at" : "2016-05-20 12:37:58 +0000",
  "in_reply_to_screen_name" : "PenguinGalaxy",
  "in_reply_to_user_id_str" : "20635230",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Egle Ramanauskaite \u2623",
      "screen_name" : "Seplute",
      "indices" : [ 0, 8 ],
      "id_str" : "188833865",
      "id" : 188833865
    }, {
      "name" : "Alice Sheppard",
      "screen_name" : "PenguinGalaxy",
      "indices" : [ 9, 23 ],
      "id_str" : "20635230",
      "id" : 20635230
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "733637314900037632",
  "geo" : { },
  "id_str" : "733637600557334528",
  "in_reply_to_user_id" : 188833865,
  "text" : "@Seplute @PenguinGalaxy me too! Hope we\u2019ll find some overlapping conference soon. Mozfest? :D",
  "id" : 733637600557334528,
  "in_reply_to_status_id" : 733637314900037632,
  "created_at" : "2016-05-20 12:36:48 +0000",
  "in_reply_to_screen_name" : "Seplute",
  "in_reply_to_user_id_str" : "188833865",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Egle Ramanauskaite \u2623",
      "screen_name" : "Seplute",
      "indices" : [ 0, 8 ],
      "id_str" : "188833865",
      "id" : 188833865
    }, {
      "name" : "Alice Sheppard",
      "screen_name" : "PenguinGalaxy",
      "indices" : [ 9, 23 ],
      "id_str" : "20635230",
      "id" : 20635230
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "733610491763888128",
  "geo" : { },
  "id_str" : "733635158247657472",
  "in_reply_to_user_id" : 188833865,
  "text" : "@Seplute @PenguinGalaxy now I\u2019m suffering heavy FOMO!",
  "id" : 733635158247657472,
  "in_reply_to_status_id" : 733610491763888128,
  "created_at" : "2016-05-20 12:27:06 +0000",
  "in_reply_to_screen_name" : "Seplute",
  "in_reply_to_user_id_str" : "188833865",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uD83D\uDD25\uD83D\uDC1C\uD83D\uDC78\uD83C\uDFFC",
      "screen_name" : "fireantprincess",
      "indices" : [ 0, 16 ],
      "id_str" : "77216385",
      "id" : 77216385
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 87 ],
      "url" : "https:\/\/t.co\/Ces9kG6DbA",
      "expanded_url" : "http:\/\/www.acgt.me\/blog\/2014\/5\/6\/a-new-jabba-award-for-a-particularly-bogus-bioinformatics-acronym",
      "display_url" : "acgt.me\/blog\/2014\/5\/6\/\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "733596952026185729",
  "geo" : { },
  "id_str" : "733597130196144128",
  "in_reply_to_user_id" : 77216385,
  "text" : "@fireantprincess you can even get an award for things like this https:\/\/t.co\/Ces9kG6DbA :P",
  "id" : 733597130196144128,
  "in_reply_to_status_id" : 733596952026185729,
  "created_at" : "2016-05-20 09:56:00 +0000",
  "in_reply_to_screen_name" : "fireantprincess",
  "in_reply_to_user_id_str" : "77216385",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "733594530512044032",
  "text" : "TIL: \u00ABRING-finger (Really Interesting New Gene) domain\u00BB. I propose: MIDDLE-finger (Mildly Interesting Domain, Low E-value).",
  "id" : 733594530512044032,
  "created_at" : "2016-05-20 09:45:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "733583358605680642",
  "text" : "Booked my first flight, the last leg, for the July conference circus: MCO \u2708\uFE0F FRA. \uD83C\uDF89",
  "id" : 733583358605680642,
  "created_at" : "2016-05-20 09:01:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uD83D\uDCABKelsey Merkley \uD83D\uDCAB",
      "screen_name" : "bella_velo",
      "indices" : [ 3, 14 ],
      "id_str" : "6745972",
      "id" : 6745972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "733578023388119041",
  "text" : "RT @bella_velo: 'Dating sounds a lot like a reoccurring anxiety dream. You'd have to be a masochist not to try to wake yourself up' https:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/pBg9ZY5PWG",
        "expanded_url" : "http:\/\/www.newyorker.com\/magazine\/2016\/05\/23\/why-dating-is-drudgery",
        "display_url" : "newyorker.com\/magazine\/2016\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "733461161174142977",
    "text" : "'Dating sounds a lot like a reoccurring anxiety dream. You'd have to be a masochist not to try to wake yourself up' https:\/\/t.co\/pBg9ZY5PWG",
    "id" : 733461161174142977,
    "created_at" : "2016-05-20 00:55:42 +0000",
    "user" : {
      "name" : "\uD83D\uDCABKelsey Merkley \uD83D\uDCAB",
      "screen_name" : "bella_velo",
      "protected" : false,
      "id_str" : "6745972",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/875913994929934336\/1aiBO2bG_normal.jpg",
      "id" : 6745972,
      "verified" : false
    }
  },
  "id" : 733578023388119041,
  "created_at" : "2016-05-20 08:40:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "733577412898750464",
  "geo" : { },
  "id_str" : "733577881889054723",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer (\u256F\u00B0\u25A1\u00B0)\u256F\uFE35 s\u01DDuoz \u01DD\u026F\u0131\u0287 (it\u2019s decided, I\u2019ll come in to BNE)",
  "id" : 733577881889054723,
  "in_reply_to_status_id" : 733577412898750464,
  "created_at" : "2016-05-20 08:39:30 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 42, 55 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/fkhBhdSjFR",
      "expanded_url" : "https:\/\/twitter.com\/dcousineau\/status\/732638062220566528",
      "display_url" : "twitter.com\/dcousineau\/sta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "733576361835552768",
  "text" : "Why I never understand how late it is for @PhilippBayer at any given time: https:\/\/t.co\/fkhBhdSjFR",
  "id" : 733576361835552768,
  "created_at" : "2016-05-20 08:33:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/hR1dxt5zk1",
      "expanded_url" : "https:\/\/twitter.com\/The_Smoking_GNU\/status\/733440438884012032",
      "display_url" : "twitter.com\/The_Smoking_GN\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17253335993005, 8.627281359974303 ]
  },
  "id_str" : "733575871353610240",
  "text" : "\u00ABthe real melancholy is the fact that America\u2019s political heroes can only exist in a dream sequence\u00BB https:\/\/t.co\/hR1dxt5zk1",
  "id" : 733575871353610240,
  "created_at" : "2016-05-20 08:31:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "smbe16",
      "indices" : [ 56, 63 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11401145082618, 8.753433747469114 ]
  },
  "id_str" : "733542849472401409",
  "text" : "Looks like I will give a presentation on my PhD work at #smbe16. For once I\u2019ll talk fungal genomics and not openSNP. \\o\/",
  "id" : 733542849472401409,
  "created_at" : "2016-05-20 06:20:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/DijIb9QkTE",
      "expanded_url" : "http:\/\/arstechnica.com\/science\/2016\/05\/theranos-corrects-tens-of-thousands-of-blood-tests-voids-2-years-of-edison-results\/",
      "display_url" : "arstechnica.com\/science\/2016\/0\u2026"
    }, {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/1yyVMtuqgr",
      "expanded_url" : "https:\/\/media.giphy.com\/media\/qE7OssOtzKvAI\/giphy.gif",
      "display_url" : "media.giphy.com\/media\/qE7OssOt\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "733316720430075905",
  "text" : "Shocking! Theranos corrects 10,000's of blood tests, voids 2 years of Edison results. https:\/\/t.co\/DijIb9QkTE https:\/\/t.co\/1yyVMtuqgr",
  "id" : 733316720430075905,
  "created_at" : "2016-05-19 15:21:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc RobinsonRechavi",
      "screen_name" : "marc_rr",
      "indices" : [ 0, 8 ],
      "id_str" : "454724555",
      "id" : 454724555
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "733264570115104768",
  "geo" : { },
  "id_str" : "733298050320453632",
  "in_reply_to_user_id" : 454724555,
  "text" : "@marc_rr if you tweet it they\u2019ll never find it.",
  "id" : 733298050320453632,
  "in_reply_to_status_id" : 733264570115104768,
  "created_at" : "2016-05-19 14:07:33 +0000",
  "in_reply_to_screen_name" : "marc_rr",
  "in_reply_to_user_id_str" : "454724555",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 86 ],
      "url" : "https:\/\/t.co\/eJstkVbEDs",
      "expanded_url" : "http:\/\/fivethirtyeight.com\/features\/how-i-acted-like-a-pundit-and-screwed-up-on-donald-trump\/",
      "display_url" : "fivethirtyeight.com\/features\/how-i\u2026"
    }, {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/HdgZz9gN57",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/733249001210978305",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "733249001210978305",
  "geo" : { },
  "id_str" : "733249142995181568",
  "in_reply_to_user_id" : 14286491,
  "text" : "From: How I Acted Like A Pundit And Screwed Up On Donald Trump https:\/\/t.co\/eJstkVbEDs https:\/\/t.co\/HdgZz9gN57",
  "id" : 733249142995181568,
  "in_reply_to_status_id" : 733249001210978305,
  "created_at" : "2016-05-19 10:53:13 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "733249001210978305",
  "text" : "\u00ABWithout a model, we found ourselves rambling around the countryside like all the other pundit-barbarians, randomly setting fire to things.\u00BB",
  "id" : 733249001210978305,
  "created_at" : "2016-05-19 10:52:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 71 ],
      "url" : "https:\/\/t.co\/nkkxOdD4Z3",
      "expanded_url" : "http:\/\/www.incrediblethings.com\/products\/snail-shell-helmets\/",
      "display_url" : "incrediblethings.com\/products\/snail\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "733233873090449409",
  "text" : "I wish I had a good excuse to sport a \uD83D\uDC0C helmet. https:\/\/t.co\/nkkxOdD4Z3",
  "id" : 733233873090449409,
  "created_at" : "2016-05-19 09:52:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 82 ],
      "url" : "https:\/\/t.co\/LBkLox7VHO",
      "expanded_url" : "https:\/\/twitter.com\/pathogenomenick\/status\/733227611346898944",
      "display_url" : "twitter.com\/pathogenomenic\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "733232532657963008",
  "text" : "Do you prefer stabbing yourself in your left or right eye? https:\/\/t.co\/LBkLox7VHO",
  "id" : 733232532657963008,
  "created_at" : "2016-05-19 09:47:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mariya Karimjee",
      "screen_name" : "M_Karimjee",
      "indices" : [ 10, 21 ],
      "id_str" : "30472724",
      "id" : 30472724
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/AgG45HDvzn",
      "expanded_url" : "http:\/\/www.theheartradio.org\/solos\/mariya",
      "display_url" : "theheartradio.org\/solos\/mariya"
    } ]
  },
  "geo" : { },
  "id_str" : "733198051087650816",
  "text" : "Listen to @M_Karimjee\u2019s deeply personal story on Female Genital Mutilation on The Heart: https:\/\/t.co\/AgG45HDvzn",
  "id" : 733198051087650816,
  "created_at" : "2016-05-19 07:30:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 42 ],
      "url" : "https:\/\/t.co\/J3shfw2tJj",
      "expanded_url" : "https:\/\/twitter.com\/j_timmer\/status\/732965885992898560",
      "display_url" : "twitter.com\/j_timmer\/statu\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06082400913696, 8.818436479187623 ]
  },
  "id_str" : "732995392674123776",
  "text" : "My favorite fauna. https:\/\/t.co\/J3shfw2tJj",
  "id" : 732995392674123776,
  "created_at" : "2016-05-18 18:04:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sujai Kumar",
      "screen_name" : "sujaik",
      "indices" : [ 0, 7 ],
      "id_str" : "33651124",
      "id" : 33651124
    }, {
      "name" : "the Winnower",
      "screen_name" : "theWinnower",
      "indices" : [ 8, 20 ],
      "id_str" : "748018813",
      "id" : 748018813
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "732972515711148032",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11401103525609, 8.75342477723548 ]
  },
  "id_str" : "732985133180063744",
  "in_reply_to_user_id" : 33651124,
  "text" : "@sujaik @theWinnower but I feel I missed out on that so far :D",
  "id" : 732985133180063744,
  "in_reply_to_status_id" : 732972515711148032,
  "created_at" : "2016-05-18 17:24:08 +0000",
  "in_reply_to_screen_name" : "sujaik",
  "in_reply_to_user_id_str" : "33651124",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "the Winnower",
      "screen_name" : "theWinnower",
      "indices" : [ 0, 12 ],
      "id_str" : "748018813",
      "id" : 748018813
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "732940715483926528",
  "geo" : { },
  "id_str" : "732957888868683778",
  "in_reply_to_user_id" : 748018813,
  "text" : "@theWinnower don\u2019t tell anyone. Both papers could end up on the Winnower after all :p",
  "id" : 732957888868683778,
  "in_reply_to_status_id" : 732940715483926528,
  "created_at" : "2016-05-18 15:35:53 +0000",
  "in_reply_to_screen_name" : "theWinnower",
  "in_reply_to_user_id_str" : "748018813",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Manuel W\u00FCst",
      "screen_name" : "ManuelWuest",
      "indices" : [ 0, 12 ],
      "id_str" : "88493882",
      "id" : 88493882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "732952361530884097",
  "geo" : { },
  "id_str" : "732952523569520640",
  "in_reply_to_user_id" : 88493882,
  "text" : "@ManuelWuest geht mit .de Reisepass ganz einfach online, Antwort sollte idr in 24h vorliegen.",
  "id" : 732952523569520640,
  "in_reply_to_status_id" : 732952361530884097,
  "created_at" : "2016-05-18 15:14:33 +0000",
  "in_reply_to_screen_name" : "ManuelWuest",
  "in_reply_to_user_id_str" : "88493882",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bored George Church",
      "screen_name" : "BoredSynBio",
      "indices" : [ 3, 15 ],
      "id_str" : "3319162469",
      "id" : 3319162469
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "732942854096605184",
  "text" : "RT @BoredSynBio: When it nanorains it nanopores.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "703639039488991232",
    "text" : "When it nanorains it nanopores.",
    "id" : 703639039488991232,
    "created_at" : "2016-02-27 17:53:14 +0000",
    "user" : {
      "name" : "Bored George Church",
      "screen_name" : "BoredSynBio",
      "protected" : false,
      "id_str" : "3319162469",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/609028654425710592\/EAe_Ulf9_normal.jpg",
      "id" : 3319162469,
      "verified" : false
    }
  },
  "id" : 732942854096605184,
  "created_at" : "2016-05-18 14:36:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "732942512378286081",
  "text" : "Visa for Australia. \u2714",
  "id" : 732942512378286081,
  "created_at" : "2016-05-18 14:34:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert Davey",
      "screen_name" : "froggleston",
      "indices" : [ 0, 12 ],
      "id_str" : "53893339",
      "id" : 53893339
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "732917781121896450",
  "geo" : { },
  "id_str" : "732937560243240961",
  "in_reply_to_user_id" : 53893339,
  "text" : "@froggleston at least in Germany the video is prefaced with an ad for Audi \uD83D\uDE02",
  "id" : 732937560243240961,
  "in_reply_to_status_id" : 732917781121896450,
  "created_at" : "2016-05-18 14:15:06 +0000",
  "in_reply_to_screen_name" : "froggleston",
  "in_reply_to_user_id_str" : "53893339",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/lrh85KZ1Cg",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=GhK6D05EamE",
      "display_url" : "youtube.com\/watch?v=GhK6D0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "732930113151586304",
  "text" : "Sometimes my Instapaper backlog is full of surprises. Today: A song on Excel Funcs. https:\/\/t.co\/lrh85KZ1Cg",
  "id" : 732930113151586304,
  "created_at" : "2016-05-18 13:45:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "732922394466226176",
  "text" : "Things learned from the tardigrades: Would someone like to use my uncleaned data to claim extensive HGT in some organism so I can refute it?",
  "id" : 732922394466226176,
  "created_at" : "2016-05-18 13:14:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 50 ],
      "url" : "https:\/\/t.co\/4bexpSp1Up",
      "expanded_url" : "http:\/\/www.boredpanda.com\/cat-licking-tongue-licki-brush\/",
      "display_url" : "boredpanda.com\/cat-licking-to\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "732890574492213253",
  "text" : "\u201Ecat toy or sex toy?\u201C v0.1 https:\/\/t.co\/4bexpSp1Up",
  "id" : 732890574492213253,
  "created_at" : "2016-05-18 11:08:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/732833399753347073\/photo\/1",
      "indices" : [ 38, 61 ],
      "url" : "https:\/\/t.co\/QisApzbYxE",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CiuMGBlW0AAEBz4.jpg",
      "id_str" : "732833399510061056",
      "id" : 732833399510061056,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CiuMGBlW0AAEBz4.jpg",
      "sizes" : [ {
        "h" : 1353,
        "resize" : "fit",
        "w" : 1804
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1353,
        "resize" : "fit",
        "w" : 1804
      } ],
      "display_url" : "pic.twitter.com\/QisApzbYxE"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172471, 8.627207 ]
  },
  "id_str" : "732833399753347073",
  "text" : "Finally put this thing up on my desk. https:\/\/t.co\/QisApzbYxE",
  "id" : 732833399753347073,
  "created_at" : "2016-05-18 07:21:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul-Olivier Dehaye",
      "screen_name" : "podehaye",
      "indices" : [ 0, 9 ],
      "id_str" : "2219841242",
      "id" : 2219841242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "732716210173956097",
  "geo" : { },
  "id_str" : "732717129405988864",
  "in_reply_to_user_id" : 2219841242,
  "text" : "@podehaye thanks, had to chuckle a bit at the idea that pointing to \u201Epapers in high profile journals\u201C could convince us to collaborate.",
  "id" : 732717129405988864,
  "in_reply_to_status_id" : 732716210173956097,
  "created_at" : "2016-05-17 23:39:11 +0000",
  "in_reply_to_screen_name" : "podehaye",
  "in_reply_to_user_id_str" : "2219841242",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Johannes'fish'Ziemke",
      "screen_name" : "discordianfish",
      "indices" : [ 0, 15 ],
      "id_str" : "21647811",
      "id" : 21647811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "732689803712598016",
  "geo" : { },
  "id_str" : "732690762819903488",
  "in_reply_to_user_id" : 21647811,
  "text" : "@discordianfish will give it a try \uD83C\uDF67\u2615\uFE0F",
  "id" : 732690762819903488,
  "in_reply_to_status_id" : 732689803712598016,
  "created_at" : "2016-05-17 21:54:25 +0000",
  "in_reply_to_screen_name" : "discordianfish",
  "in_reply_to_user_id_str" : "21647811",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul-Olivier Dehaye",
      "screen_name" : "podehaye",
      "indices" : [ 0, 9 ],
      "id_str" : "2219841242",
      "id" : 2219841242
    }, {
      "name" : "mack eubanks",
      "screen_name" : "quominus",
      "indices" : [ 10, 19 ],
      "id_str" : "817667268096262146",
      "id" : 817667268096262146
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "732614049742065665",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17238569050271, 8.627356793567024 ]
  },
  "id_str" : "732614154402562048",
  "in_reply_to_user_id" : 2219841242,
  "text" : "@podehaye @quominus sure, and done! :)",
  "id" : 732614154402562048,
  "in_reply_to_status_id" : 732614049742065665,
  "created_at" : "2016-05-17 16:50:00 +0000",
  "in_reply_to_screen_name" : "podehaye",
  "in_reply_to_user_id_str" : "2219841242",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/LaBSx8yE1E",
      "expanded_url" : "http:\/\/arstechnica.com\/science\/2016\/05\/only-two-kinds-of-sexual-arrangements-are-possible-among-social-animals\/",
      "display_url" : "arstechnica.com\/science\/2016\/0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "732579452706783232",
  "text" : "Only two kinds of sexual arrangements are possible among social animals https:\/\/t.co\/LaBSx8yE1E",
  "id" : 732579452706783232,
  "created_at" : "2016-05-17 14:32:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mack eubanks",
      "screen_name" : "quominus",
      "indices" : [ 0, 9 ],
      "id_str" : "817667268096262146",
      "id" : 817667268096262146
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "732564272161652736",
  "text" : "@quominus many of us are just working in our spare time being citizen scientists as well.",
  "id" : 732564272161652736,
  "created_at" : "2016-05-17 13:31:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul-Olivier Dehaye",
      "screen_name" : "podehaye",
      "indices" : [ 0, 9 ],
      "id_str" : "2219841242",
      "id" : 2219841242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "732272433248534529",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06078440317885, 8.818656015443187 ]
  },
  "id_str" : "732295631889371137",
  "in_reply_to_user_id" : 2219841242,
  "text" : "@podehaye saw that, let me know if you want any help.",
  "id" : 732295631889371137,
  "in_reply_to_status_id" : 732272433248534529,
  "created_at" : "2016-05-16 19:44:18 +0000",
  "in_reply_to_screen_name" : "podehaye",
  "in_reply_to_user_id_str" : "2219841242",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 55 ],
      "url" : "https:\/\/t.co\/P8IQyIvIoP",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BFeZF2Ahwu0\/",
      "display_url" : "instagram.com\/p\/BFeZF2Ahwu0\/"
    } ]
  },
  "geo" : { },
  "id_str" : "732246657795035136",
  "text" : "While they are eating us alive\u2026 https:\/\/t.co\/P8IQyIvIoP",
  "id" : 732246657795035136,
  "created_at" : "2016-05-16 16:29:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/732244353620545536\/photo\/1",
      "indices" : [ 68, 91 ],
      "url" : "https:\/\/t.co\/kH1aX5vAc1",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cil0W_5WwAAQCTZ.jpg",
      "id_str" : "732244352882360320",
      "id" : 732244352882360320,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cil0W_5WwAAQCTZ.jpg",
      "sizes" : [ {
        "h" : 200,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 475,
        "resize" : "fit",
        "w" : 1613
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 475,
        "resize" : "fit",
        "w" : 1613
      }, {
        "h" : 353,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/kH1aX5vAc1"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "732244353620545536",
  "text" : "Feldberg, 876 m over sea level, around 620 m of those done by foot. https:\/\/t.co\/kH1aX5vAc1",
  "id" : 732244353620545536,
  "created_at" : "2016-05-16 16:20:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul-Olivier Dehaye",
      "screen_name" : "podehaye",
      "indices" : [ 0, 9 ],
      "id_str" : "2219841242",
      "id" : 2219841242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "732010103189213184",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06095268432414, 8.81874068040117 ]
  },
  "id_str" : "732146812472201216",
  "in_reply_to_user_id" : 2219841242,
  "text" : "@podehaye wow, it\u2019s gettin worse and worse. Still wanna write something up about it?",
  "id" : 732146812472201216,
  "in_reply_to_status_id" : 732010103189213184,
  "created_at" : "2016-05-16 09:52:57 +0000",
  "in_reply_to_screen_name" : "podehaye",
  "in_reply_to_user_id_str" : "2219841242",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dvzrv",
      "screen_name" : "dvzrv",
      "indices" : [ 0, 6 ],
      "id_str" : "30868098",
      "id" : 30868098
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 78, 84 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "731947069359947776",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06087881600326, 8.818741041009606 ]
  },
  "id_str" : "731948163356078080",
  "in_reply_to_user_id" : 30868098,
  "text" : "@dvzrv it\u2019s the first I bought in like 8 years. And I don\u2019t know for how long @Lobot abstained.",
  "id" : 731948163356078080,
  "in_reply_to_status_id" : 731947069359947776,
  "created_at" : "2016-05-15 20:43:35 +0000",
  "in_reply_to_screen_name" : "dvzrv",
  "in_reply_to_user_id_str" : "30868098",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Denker",
      "screen_name" : "Phaidr0s",
      "indices" : [ 0, 9 ],
      "id_str" : "40466433",
      "id" : 40466433
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "731944464579710981",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06085119587563, 8.818650131461634 ]
  },
  "id_str" : "731945476363304960",
  "in_reply_to_user_id" : 40466433,
  "text" : "@Phaidr0s ist das ein Angebot?",
  "id" : 731945476363304960,
  "in_reply_to_status_id" : 731944464579710981,
  "created_at" : "2016-05-15 20:32:55 +0000",
  "in_reply_to_screen_name" : "Phaidr0s",
  "in_reply_to_user_id_str" : "40466433",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TriploidTree",
      "screen_name" : "TriploidTree",
      "indices" : [ 0, 13 ],
      "id_str" : "14165662",
      "id" : 14165662
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "731945053485203461",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06085119587563, 8.818650131461634 ]
  },
  "id_str" : "731945398621900800",
  "in_reply_to_user_id" : 14165662,
  "text" : "@TriploidTree the best part is that they are advertising \u2018classy steel wire\u2019. I don\u2019t even know what that means.",
  "id" : 731945398621900800,
  "in_reply_to_status_id" : 731945053485203461,
  "created_at" : "2016-05-15 20:32:36 +0000",
  "in_reply_to_screen_name" : "TriploidTree",
  "in_reply_to_user_id_str" : "14165662",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/731944232945078272\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/fFFxEiWIEk",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CihjZiFVEAEt42k.jpg",
      "id_str" : "731944229744742401",
      "id" : 731944229744742401,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CihjZiFVEAEt42k.jpg",
      "sizes" : [ {
        "h" : 207,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 411,
        "resize" : "fit",
        "w" : 1348
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 366,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 411,
        "resize" : "fit",
        "w" : 1348
      } ],
      "display_url" : "pic.twitter.com\/fFFxEiWIEk"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "731944232945078272",
  "text" : "What are the algorithmic recommendations trying to tell me? Hypodermic needles, steel wire, unicorn cookie cutters\u2026 https:\/\/t.co\/fFFxEiWIEk",
  "id" : 731944232945078272,
  "created_at" : "2016-05-15 20:27:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Extinction Symbol",
      "screen_name" : "extinctsymbol",
      "indices" : [ 0, 14 ],
      "id_str" : "522593098",
      "id" : 522593098
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "731921137693818882",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06092907086718, 8.818491513891841 ]
  },
  "id_str" : "731926637936250880",
  "in_reply_to_user_id" : 522593098,
  "text" : "@extinctsymbol and very cool ones! I should go for it. Need to find a nice rendition though \uD83E\uDD14",
  "id" : 731926637936250880,
  "in_reply_to_status_id" : 731921137693818882,
  "created_at" : "2016-05-15 19:18:03 +0000",
  "in_reply_to_screen_name" : "extinctsymbol",
  "in_reply_to_user_id_str" : "522593098",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathan Holliday",
      "screen_name" : "jonnybirder",
      "indices" : [ 0, 12 ],
      "id_str" : "318538660",
      "id" : 318538660
    }, {
      "name" : "Extinction Symbol",
      "screen_name" : "extinctsymbol",
      "indices" : [ 13, 27 ],
      "id_str" : "522593098",
      "id" : 522593098
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "731914304497319936",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.10706749283718, 8.682501269512514 ]
  },
  "id_str" : "731917918770855936",
  "in_reply_to_user_id" : 318538660,
  "text" : "@jonnybirder @extinctsymbol \uD83D\uDC4D",
  "id" : 731917918770855936,
  "in_reply_to_status_id" : 731914304497319936,
  "created_at" : "2016-05-15 18:43:24 +0000",
  "in_reply_to_screen_name" : "jonnybirder",
  "in_reply_to_user_id_str" : "318538660",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathan Holliday",
      "screen_name" : "jonnybirder",
      "indices" : [ 0, 12 ],
      "id_str" : "318538660",
      "id" : 318538660
    }, {
      "name" : "Extinction Symbol",
      "screen_name" : "extinctsymbol",
      "indices" : [ 13, 27 ],
      "id_str" : "522593098",
      "id" : 522593098
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "731912694962475012",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11758598503668, 8.679792825140693 ]
  },
  "id_str" : "731913828187930624",
  "in_reply_to_user_id" : 318538660,
  "text" : "@jonnybirder @extinctsymbol pic please! :)",
  "id" : 731913828187930624,
  "in_reply_to_status_id" : 731912694962475012,
  "created_at" : "2016-05-15 18:27:09 +0000",
  "in_reply_to_screen_name" : "jonnybirder",
  "in_reply_to_user_id_str" : "318538660",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jhermes",
      "screen_name" : "spinfocl",
      "indices" : [ 0, 9 ],
      "id_str" : "214008538",
      "id" : 214008538
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "731885695271354368",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.12028701656698, 8.68003266992389 ]
  },
  "id_str" : "731891096305930241",
  "in_reply_to_user_id" : 214008538,
  "text" : "@spinfocl das ist mit meinen Evolutions-Tattoos schon passiert mit Dawkins und Kutschera :p",
  "id" : 731891096305930241,
  "in_reply_to_status_id" : 731885695271354368,
  "created_at" : "2016-05-15 16:56:49 +0000",
  "in_reply_to_screen_name" : "spinfocl",
  "in_reply_to_user_id_str" : "214008538",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katha",
      "screen_name" : "kathakatze",
      "indices" : [ 0, 11 ],
      "id_str" : "541170257",
      "id" : 541170257
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "731880923843702784",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.09971918730218, 8.68929191915732 ]
  },
  "id_str" : "731881230334083072",
  "in_reply_to_user_id" : 541170257,
  "text" : "@kathakatze na gut, 2\/3 mindestens? :)",
  "id" : 731881230334083072,
  "in_reply_to_status_id" : 731880923843702784,
  "created_at" : "2016-05-15 16:17:37 +0000",
  "in_reply_to_screen_name" : "kathakatze",
  "in_reply_to_user_id_str" : "541170257",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Johannes'fish'Ziemke",
      "screen_name" : "discordianfish",
      "indices" : [ 0, 15 ],
      "id_str" : "21647811",
      "id" : 21647811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "731873685901062146",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.10018756596499, 8.6912910636534 ]
  },
  "id_str" : "731880967699189760",
  "in_reply_to_user_id" : 21647811,
  "text" : "@discordianfish are they as good as the sound? :)",
  "id" : 731880967699189760,
  "in_reply_to_status_id" : 731873685901062146,
  "created_at" : "2016-05-15 16:16:35 +0000",
  "in_reply_to_screen_name" : "discordianfish",
  "in_reply_to_user_id_str" : "21647811",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katha",
      "screen_name" : "kathakatze",
      "indices" : [ 0, 11 ],
      "id_str" : "541170257",
      "id" : 541170257
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "731880217485164544",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.08666609668121, 8.692353145310753 ]
  },
  "id_str" : "731880488583987200",
  "in_reply_to_user_id" : 541170257,
  "text" : "@kathakatze die sowieso 95% der Leute nicht sehen k\u00F6nnen? Und mein Client auch nicht erstellen kann? :p",
  "id" : 731880488583987200,
  "in_reply_to_status_id" : 731880217485164544,
  "created_at" : "2016-05-15 16:14:40 +0000",
  "in_reply_to_screen_name" : "kathakatze",
  "in_reply_to_user_id_str" : "541170257",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Extinction Symbol",
      "screen_name" : "extinctsymbol",
      "indices" : [ 20, 34 ],
      "id_str" : "522593098",
      "id" : 522593098
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06832704884006, 8.736766800292521 ]
  },
  "id_str" : "731879706161782784",
  "text" : "Getting a tattoo of @extinctsymbol: yay or nay?",
  "id" : 731879706161782784,
  "created_at" : "2016-05-15 16:11:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mack eubanks",
      "screen_name" : "quominus",
      "indices" : [ 0, 9 ],
      "id_str" : "817667268096262146",
      "id" : 817667268096262146
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06084314154461, 8.819092514994079 ]
  },
  "id_str" : "731839806725050369",
  "text" : "@quominus awesome, congrats!",
  "id" : 731839806725050369,
  "created_at" : "2016-05-15 13:33:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "metro fnord",
      "screen_name" : "linse",
      "indices" : [ 0, 6 ],
      "id_str" : "2206871",
      "id" : 2206871
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "731813165047091200",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06088609442722, 8.818757292491778 ]
  },
  "id_str" : "731816217384734720",
  "in_reply_to_user_id" : 2206871,
  "text" : "@linse awesome,\nCongrats!",
  "id" : 731816217384734720,
  "in_reply_to_status_id" : 731813165047091200,
  "created_at" : "2016-05-15 11:59:17 +0000",
  "in_reply_to_screen_name" : "linse",
  "in_reply_to_user_id_str" : "2206871",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "731735580732735488",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06093225471719, 8.818603649554923 ]
  },
  "id_str" : "731785936598618112",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich schickt .de dann Feindflug? \uD83D\uDE31",
  "id" : 731785936598618112,
  "in_reply_to_status_id" : 731735580732735488,
  "created_at" : "2016-05-15 09:58:57 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Skellett",
      "screen_name" : "Gurdur",
      "indices" : [ 0, 7 ],
      "id_str" : "125928028",
      "id" : 125928028
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "731734047773298688",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06093225471719, 8.818603649554923 ]
  },
  "id_str" : "731785726279487490",
  "in_reply_to_user_id" : 125928028,
  "text" : "@Gurdur looks like Fomes fomentarius (and usually this is the one used for tinder)",
  "id" : 731785726279487490,
  "in_reply_to_status_id" : 731734047773298688,
  "created_at" : "2016-05-15 09:58:07 +0000",
  "in_reply_to_screen_name" : "Gurdur",
  "in_reply_to_user_id_str" : "125928028",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "731530318650458112",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.05971251955001, 8.816267528509755 ]
  },
  "id_str" : "731530801704271872",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich erstaunlicherweise gab es noch weniger Linksh\u00E4nder-Modelle bei den E-Gitarren als bei den Westerngitarren! \uD83D\uDE31",
  "id" : 731530801704271872,
  "in_reply_to_status_id" : 731530318650458112,
  "created_at" : "2016-05-14 17:05:08 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/731529506368958465\/photo\/1",
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/WEn9JP0T2P",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CibqMZ-XIAQvCWU.jpg",
      "id_str" : "731529488346062852",
      "id" : 731529488346062852,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CibqMZ-XIAQvCWU.jpg",
      "sizes" : [ {
        "h" : 3024,
        "resize" : "fit",
        "w" : 4032
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/WEn9JP0T2P"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06091879658677, 8.818653753584657 ]
  },
  "id_str" : "731529506368958465",
  "text" : "Saddle the banjo, we\u2019re riding into the sunset! Or: how Germans think of banjo players. https:\/\/t.co\/WEn9JP0T2P",
  "id" : 731529506368958465,
  "created_at" : "2016-05-14 17:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nyborg",
      "screen_name" : "ny_borg",
      "indices" : [ 0, 8 ],
      "id_str" : "570156398",
      "id" : 570156398
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/731480610708045824\/photo\/1",
      "indices" : [ 16, 39 ],
      "url" : "https:\/\/t.co\/yAiPCqwsHi",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cia9vNAWkAA8j_h.jpg",
      "id_str" : "731480608136925184",
      "id" : 731480608136925184,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cia9vNAWkAA8j_h.jpg",
      "sizes" : [ {
        "h" : 4032,
        "resize" : "fit",
        "w" : 3024
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      } ],
      "display_url" : "pic.twitter.com\/yAiPCqwsHi"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "731480367572647936",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11380790063708, 8.753582055169659 ]
  },
  "id_str" : "731480610708045824",
  "in_reply_to_user_id" : 570156398,
  "text" : "@ny_borg da? :D https:\/\/t.co\/yAiPCqwsHi",
  "id" : 731480610708045824,
  "in_reply_to_status_id" : 731480367572647936,
  "created_at" : "2016-05-14 13:45:42 +0000",
  "in_reply_to_screen_name" : "ny_borg",
  "in_reply_to_user_id_str" : "570156398",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/731479368871088128\/photo\/1",
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/2gB4sKgGkw",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cia8nDZWkAAki6M.jpg",
      "id_str" : "731479368606846976",
      "id" : 731479368606846976,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cia8nDZWkAAki6M.jpg",
      "sizes" : [ {
        "h" : 957,
        "resize" : "fit",
        "w" : 718
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 957,
        "resize" : "fit",
        "w" : 718
      }, {
        "h" : 957,
        "resize" : "fit",
        "w" : 718
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      } ],
      "display_url" : "pic.twitter.com\/2gB4sKgGkw"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "731479368871088128",
  "text" : "Some people might have spent three hours in a music store playing numerous guitars (and left with only two of them). https:\/\/t.co\/2gB4sKgGkw",
  "id" : 731479368871088128,
  "created_at" : "2016-05-14 13:40:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 86 ],
      "url" : "https:\/\/t.co\/c3lMHkzrTL",
      "expanded_url" : "http:\/\/www.atlasobscura.com\/articles\/the-rise-of-the-gay-mafia-a-powerful-cabal-that-never-existed",
      "display_url" : "atlasobscura.com\/articles\/the-r\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "731478450586984448",
  "text" : "The Rise of the Gay Mafia, a Powerful Cabal That Never Existed https:\/\/t.co\/c3lMHkzrTL",
  "id" : 731478450586984448,
  "created_at" : "2016-05-14 13:37:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul-Olivier Dehaye",
      "screen_name" : "podehaye",
      "indices" : [ 0, 9 ],
      "id_str" : "2219841242",
      "id" : 2219841242
    }, {
      "name" : "Amali de Alwis",
      "screen_name" : "amali_d",
      "indices" : [ 10, 18 ],
      "id_str" : "123276494",
      "id" : 123276494
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "731360146648109056",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06100506408859, 8.818546805066955 ]
  },
  "id_str" : "731376738522025984",
  "in_reply_to_user_id" : 2219841242,
  "text" : "@podehaye @amali_d *sigh* it\u2019s the gift that keeps on giving \uD83D\uDE14",
  "id" : 731376738522025984,
  "in_reply_to_status_id" : 731360146648109056,
  "created_at" : "2016-05-14 06:52:57 +0000",
  "in_reply_to_screen_name" : "podehaye",
  "in_reply_to_user_id_str" : "2219841242",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/6hYqvkuS57",
      "expanded_url" : "https:\/\/twitter.com\/pathogenomenick\/status\/731215446641418240",
      "display_url" : "twitter.com\/pathogenomenic\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06084819293611, 8.818663328088972 ]
  },
  "id_str" : "731230910050406400",
  "text" : "The days of overselling \na) synthetic biology \nb) microbiomes\nc) space travel\nd) all of the above\nare finally over! https:\/\/t.co\/6hYqvkuS57",
  "id" : 731230910050406400,
  "created_at" : "2016-05-13 21:13:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mack eubanks",
      "screen_name" : "quominus",
      "indices" : [ 0, 9 ],
      "id_str" : "817667268096262146",
      "id" : 817667268096262146
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06084311255625, 8.81865796425587 ]
  },
  "id_str" : "731228508115046400",
  "text" : "@quominus thanks! \uD83D\uDC36\uD83D\uDC96",
  "id" : 731228508115046400,
  "created_at" : "2016-05-13 21:03:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anil Dash",
      "screen_name" : "anildash",
      "indices" : [ 3, 12 ],
      "id_str" : "36823",
      "id" : 36823
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "731226945703297025",
  "text" : "RT @anildash: Nearly every time Prince attended a tribute in his honor, he dictated that the lineup consist of black women. Yet. https:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/0Qx3qfUxSW",
        "expanded_url" : "https:\/\/twitter.com\/catladyshazza\/status\/730898717549711361",
        "display_url" : "twitter.com\/catladyshazza\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "730916369693298688",
    "text" : "Nearly every time Prince attended a tribute in his honor, he dictated that the lineup consist of black women. Yet. https:\/\/t.co\/0Qx3qfUxSW",
    "id" : 730916369693298688,
    "created_at" : "2016-05-13 00:23:36 +0000",
    "user" : {
      "name" : "Anil Dash",
      "screen_name" : "anildash",
      "protected" : false,
      "id_str" : "36823",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/915191237338177536\/cZoGK6nh_normal.jpg",
      "id" : 36823,
      "verified" : true
    }
  },
  "id" : 731226945703297025,
  "created_at" : "2016-05-13 20:57:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 3, 15 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/LySSYl1CDR",
      "expanded_url" : "https:\/\/www.gq.com\/story\/my-mom-ran-my-tinder",
      "display_url" : "gq.com\/story\/my-mom-r\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "731194732064456704",
  "text" : "RT @helgerausch: This Is What Happened When My Mom Ran My Tinder for a Month \nhttps:\/\/t.co\/LySSYl1CDR",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 61, 84 ],
        "url" : "https:\/\/t.co\/LySSYl1CDR",
        "expanded_url" : "https:\/\/www.gq.com\/story\/my-mom-ran-my-tinder",
        "display_url" : "gq.com\/story\/my-mom-r\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "731178587131379713",
    "text" : "This Is What Happened When My Mom Ran My Tinder for a Month \nhttps:\/\/t.co\/LySSYl1CDR",
    "id" : 731178587131379713,
    "created_at" : "2016-05-13 17:45:34 +0000",
    "user" : {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "protected" : false,
      "id_str" : "52747896",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/841604882352201729\/O7uP_eHQ_normal.jpg",
      "id" : 52747896,
      "verified" : false
    }
  },
  "id" : 731194732064456704,
  "created_at" : "2016-05-13 18:49:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "malech maltz",
      "screen_name" : "malech",
      "indices" : [ 0, 7 ],
      "id_str" : "784085846391713793",
      "id" : 784085846391713793
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/731189577340293120\/photo\/1",
      "indices" : [ 59, 82 ],
      "url" : "https:\/\/t.co\/US9VA3V27W",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CiW1CxLWsAAuWeH.jpg",
      "id_str" : "731189573682900992",
      "id" : 731189573682900992,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CiW1CxLWsAAuWeH.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/US9VA3V27W"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11221465193677, 8.7409696541808 ]
  },
  "id_str" : "731189577340293120",
  "text" : "@malech im Hafen 2 gibt es was f\u00FCr dich im B\u00FCcherschrank \uD83D\uDE02 https:\/\/t.co\/US9VA3V27W",
  "id" : 731189577340293120,
  "created_at" : "2016-05-13 18:29:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/HtTkFqwzs4",
      "expanded_url" : "https:\/\/twitter.com\/surt_lab\/status\/731109003283947521",
      "display_url" : "twitter.com\/surt_lab\/statu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "731114827771457536",
  "text" : "Up Next: \u00ABEvidence for extensive tardigrade genome analyses from the PNAS &amp; bioRxiv archives.\u00BB https:\/\/t.co\/HtTkFqwzs4",
  "id" : 731114827771457536,
  "created_at" : "2016-05-13 13:32:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mack eubanks",
      "screen_name" : "quominus",
      "indices" : [ 0, 9 ],
      "id_str" : "817667268096262146",
      "id" : 817667268096262146
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "openhater",
      "indices" : [ 10, 20 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "731076277122306048",
  "text" : "@quominus #openhater would try to preserve some pun, but isn\u2019t as clear on the topic.",
  "id" : 731076277122306048,
  "created_at" : "2016-05-13 10:59:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mack eubanks",
      "screen_name" : "quominus",
      "indices" : [ 0, 9 ],
      "id_str" : "817667268096262146",
      "id" : 817667268096262146
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "731074803512320001",
  "text" : "@quominus my usual way to solve this is to quoted RT the catch. Preserves structure\/history while acknowledging ones oversight. \uD83D\uDE0A",
  "id" : 731074803512320001,
  "created_at" : "2016-05-13 10:53:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mack eubanks",
      "screen_name" : "quominus",
      "indices" : [ 0, 9 ],
      "id_str" : "817667268096262146",
      "id" : 817667268096262146
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 63 ],
      "url" : "https:\/\/t.co\/yXIKHj57xf",
      "expanded_url" : "https:\/\/ischemgeek.wordpress.com\/2014\/02\/15\/the-case-against-stupid\/",
      "display_url" : "ischemgeek.wordpress.com\/2014\/02\/15\/the\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "731073916962254848",
  "text" : "@quominus fully appreciate the pun, but https:\/\/t.co\/yXIKHj57xf \uD83D\uDE0A",
  "id" : 731073916962254848,
  "created_at" : "2016-05-13 10:49:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul-Olivier Dehaye",
      "screen_name" : "podehaye",
      "indices" : [ 0, 9 ],
      "id_str" : "2219841242",
      "id" : 2219841242
    }, {
      "name" : "Effy Vayena",
      "screen_name" : "EffyVayena",
      "indices" : [ 10, 21 ],
      "id_str" : "397518511",
      "id" : 397518511
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "731042819046031360",
  "geo" : { },
  "id_str" : "731043789226278913",
  "in_reply_to_user_id" : 2219841242,
  "text" : "@podehaye @EffyVayena wow, that part I missed so far.",
  "id" : 731043789226278913,
  "in_reply_to_status_id" : 731042819046031360,
  "created_at" : "2016-05-13 08:49:56 +0000",
  "in_reply_to_screen_name" : "podehaye",
  "in_reply_to_user_id_str" : "2219841242",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hummusday",
      "indices" : [ 23, 33 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/SB9NmOMeMx",
      "expanded_url" : "https:\/\/media.giphy.com\/media\/EcCkpYM8e8xEI\/giphy.gif",
      "display_url" : "media.giphy.com\/media\/EcCkpYM8\u2026"
    }, {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/5yr45VRxtb",
      "expanded_url" : "http:\/\/imgur.com\/1pZMbq4",
      "display_url" : "imgur.com\/1pZMbq4"
    } ]
  },
  "geo" : { },
  "id_str" : "731036960446414848",
  "text" : "Important reminder for #hummusday. There\u2019s no right or wrong way for how to eat it, c.f. https:\/\/t.co\/SB9NmOMeMx and https:\/\/t.co\/5yr45VRxtb",
  "id" : 731036960446414848,
  "created_at" : "2016-05-13 08:22:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 52 ],
      "url" : "https:\/\/t.co\/Tq1MQWgFgs",
      "expanded_url" : "http:\/\/media.tumblr.com\/571696052e02c54a790ebb7c05946e81\/tumblr_inline_mihuuppa1Q1qz4rgp.gif",
      "display_url" : "media.tumblr.com\/571696052e02c5\u2026"
    }, {
      "indices" : [ 53, 76 ],
      "url" : "https:\/\/t.co\/P8dtki0mfi",
      "expanded_url" : "https:\/\/twitter.com\/helgerausch\/status\/731028935916572672",
      "display_url" : "twitter.com\/helgerausch\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "731035352786436096",
  "text" : "I love you, but I\u2019ve chosen\u2026 https:\/\/t.co\/Tq1MQWgFgs https:\/\/t.co\/P8dtki0mfi",
  "id" : 731035352786436096,
  "created_at" : "2016-05-13 08:16:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Effy Vayena",
      "screen_name" : "EffyVayena",
      "indices" : [ 0, 11 ],
      "id_str" : "397518511",
      "id" : 397518511
    }, {
      "name" : "Paul-Olivier Dehaye",
      "screen_name" : "podehaye",
      "indices" : [ 12, 21 ],
      "id_str" : "2219841242",
      "id" : 2219841242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 54 ],
      "url" : "https:\/\/t.co\/BgC3aDolnW",
      "expanded_url" : "http:\/\/emilygorcenski.com\/blog\/when-open-science-isn-t-the-okcupid-data-breach",
      "display_url" : "emilygorcenski.com\/blog\/when-open\u2026"
    }, {
      "indices" : [ 61, 84 ],
      "url" : "https:\/\/t.co\/nQMHiItqsH",
      "expanded_url" : "https:\/\/ironholds.org\/blog\/when-science-goes-bad-consent-data-and-doubling-down-on-the-internet\/",
      "display_url" : "ironholds.org\/blog\/when-scie\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "731027401732456448",
  "geo" : { },
  "id_str" : "731033786117459968",
  "in_reply_to_user_id" : 397518511,
  "text" : "@EffyVayena @podehaye see also https:\/\/t.co\/BgC3aDolnW &amp; https:\/\/t.co\/nQMHiItqsH",
  "id" : 731033786117459968,
  "in_reply_to_status_id" : 731027401732456448,
  "created_at" : "2016-05-13 08:10:11 +0000",
  "in_reply_to_screen_name" : "EffyVayena",
  "in_reply_to_user_id_str" : "397518511",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 72 ],
      "url" : "https:\/\/t.co\/WA5SICnXhz",
      "expanded_url" : "https:\/\/aeon.co\/opinions\/human-sex-is-not-male-or-female-so-what",
      "display_url" : "aeon.co\/opinions\/human\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "731024159606747136",
  "text" : "Human sex is not simply male or female. So what? https:\/\/t.co\/WA5SICnXhz",
  "id" : 731024159606747136,
  "created_at" : "2016-05-13 07:31:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "beau",
      "screen_name" : "beaugunderson",
      "indices" : [ 0, 14 ],
      "id_str" : "5746882",
      "id" : 5746882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "730957248424497152",
  "geo" : { },
  "id_str" : "731023037722722304",
  "in_reply_to_user_id" : 5746882,
  "text" : "@beaugunderson \u201Esorry we\u2019re late, but whale traffic was horrible today!\u201C must be like the best excuse ever\u2122.",
  "id" : 731023037722722304,
  "in_reply_to_status_id" : 730957248424497152,
  "created_at" : "2016-05-13 07:27:28 +0000",
  "in_reply_to_screen_name" : "beaugunderson",
  "in_reply_to_user_id_str" : "5746882",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BOSC2016",
      "indices" : [ 15, 24 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "731016548555599873",
  "text" : "Registered for #BOSC2016. See you in Orlando. \uD83C\uDF89",
  "id" : 731016548555599873,
  "created_at" : "2016-05-13 07:01:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "730925985227378688",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17247042467977, 8.627530974326783 ]
  },
  "id_str" : "731013971701071872",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez congrats! \uD83D\uDC96",
  "id" : 731013971701071872,
  "in_reply_to_status_id" : 730925985227378688,
  "created_at" : "2016-05-13 06:51:27 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/730880968844791808\/photo\/1",
      "indices" : [ 4, 27 ],
      "url" : "https:\/\/t.co\/2HXrV7btKy",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CiScXlnWkAAqU4h.jpg",
      "id_str" : "730880968588955648",
      "id" : 730880968588955648,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CiScXlnWkAAqU4h.jpg",
      "sizes" : [ {
        "h" : 1163,
        "resize" : "fit",
        "w" : 1551
      }, {
        "h" : 1163,
        "resize" : "fit",
        "w" : 1551
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/2HXrV7btKy"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.110489, 8.692825 ]
  },
  "id_str" : "730880968844791808",
  "text" : "\uD83C\uDF0A\uD83D\uDC34\uD83D\uDC96 https:\/\/t.co\/2HXrV7btKy",
  "id" : 730880968844791808,
  "created_at" : "2016-05-12 22:02:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11522106807236, 8.690053212206005 ]
  },
  "id_str" : "730852006567546882",
  "text" : "Now for a live rendition of a 40 minute post-metal doom song.",
  "id" : 730852006567546882,
  "created_at" : "2016-05-12 20:07:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BOSC",
      "screen_name" : "OBF_BOSC",
      "indices" : [ 3, 12 ],
      "id_str" : "583180584",
      "id" : 583180584
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BOSC2016",
      "indices" : [ 23, 32 ]
    }, {
      "text" : "ISMB2016",
      "indices" : [ 120, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "730837182743781380",
  "text" : "RT @OBF_BOSC: Call for #BOSC2016 Late-Breaking Lightning Talks and Posts is open (deadline June 2, also when BOSC &amp; #ISMB2016 early registr\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BOSC2016",
        "indices" : [ 9, 18 ]
      }, {
        "text" : "ISMB2016",
        "indices" : [ 106, 115 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "730836010758754304",
    "text" : "Call for #BOSC2016 Late-Breaking Lightning Talks and Posts is open (deadline June 2, also when BOSC &amp; #ISMB2016 early registration ends)",
    "id" : 730836010758754304,
    "created_at" : "2016-05-12 19:04:17 +0000",
    "user" : {
      "name" : "BOSC",
      "screen_name" : "OBF_BOSC",
      "protected" : false,
      "id_str" : "583180584",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2227105401\/BOSC-logo-square_normal.jpg",
      "id" : 583180584,
      "verified" : false
    }
  },
  "id" : 730837182743781380,
  "created_at" : "2016-05-12 19:08:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mack eubanks",
      "screen_name" : "quominus",
      "indices" : [ 0, 9 ],
      "id_str" : "817667268096262146",
      "id" : 817667268096262146
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11935015623015, 8.679711277617852 ]
  },
  "id_str" : "730815337097252864",
  "text" : "@quominus \uD83D\uDC96",
  "id" : 730815337097252864,
  "created_at" : "2016-05-12 17:42:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert Krause",
      "screen_name" : "euleule",
      "indices" : [ 0, 8 ],
      "id_str" : "563152502",
      "id" : 563152502
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "730807197098233856",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.10819791699139, 8.754185746959095 ]
  },
  "id_str" : "730807956829315072",
  "in_reply_to_user_id" : 563152502,
  "text" : "@euleule ich bin gespannt :3",
  "id" : 730807956829315072,
  "in_reply_to_status_id" : 730807197098233856,
  "created_at" : "2016-05-12 17:12:49 +0000",
  "in_reply_to_screen_name" : "euleule",
  "in_reply_to_user_id_str" : "563152502",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mack eubanks",
      "screen_name" : "quominus",
      "indices" : [ 0, 9 ],
      "id_str" : "817667268096262146",
      "id" : 817667268096262146
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "730783696102510592",
  "text" : "@quominus as you should :D",
  "id" : 730783696102510592,
  "created_at" : "2016-05-12 15:36:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mack eubanks",
      "screen_name" : "quominus",
      "indices" : [ 0, 9 ],
      "id_str" : "817667268096262146",
      "id" : 817667268096262146
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "730779292490211328",
  "text" : "@quominus well done! \uD83D\uDC4D",
  "id" : 730779292490211328,
  "created_at" : "2016-05-12 15:18:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/POgTA59S6w",
      "expanded_url" : "https:\/\/twitter.com\/quominus\/status\/730761013503639553",
      "display_url" : "twitter.com\/quominus\/statu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "730779247623720961",
  "text" : "\u00ABthe doxing of 70,000 people for a fucking paper.\u00BB Where I\u2019ll point people who go \u201Egeez, why do we need IRBs?!\u201C to: https:\/\/t.co\/POgTA59S6w",
  "id" : 730779247623720961,
  "created_at" : "2016-05-12 15:18:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Hummel",
      "screen_name" : "p_humm",
      "indices" : [ 0, 7 ],
      "id_str" : "390742975",
      "id" : 390742975
    }, {
      "name" : "J\u00FCrgen",
      "screen_name" : "juergen_hd",
      "indices" : [ 8, 19 ],
      "id_str" : "80106704",
      "id" : 80106704
    }, {
      "name" : "Antje Findeklee (Unkraut vergeht nicht)",
      "screen_name" : "tre_bol",
      "indices" : [ 20, 28 ],
      "id_str" : "80123679",
      "id" : 80123679
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "730730626333196288",
  "geo" : { },
  "id_str" : "730731766361804800",
  "in_reply_to_user_id" : 390742975,
  "text" : "@p_humm @juergen_hd @tre_bol  ich kenne zumindest keine. Arbeite momentan an Cross-References zu Unis.",
  "id" : 730731766361804800,
  "in_reply_to_status_id" : 730730626333196288,
  "created_at" : "2016-05-12 12:10:04 +0000",
  "in_reply_to_screen_name" : "p_humm",
  "in_reply_to_user_id_str" : "390742975",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OkCupid",
      "screen_name" : "okcupid",
      "indices" : [ 78, 86 ],
      "id_str" : "53543144",
      "id" : 53543144
    }, {
      "name" : "Emily G, Cville.",
      "screen_name" : "EmilyGorcenski",
      "indices" : [ 99, 114 ],
      "id_str" : "1483064670",
      "id" : 1483064670
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/BgC3aDolnW",
      "expanded_url" : "http:\/\/emilygorcenski.com\/blog\/when-open-science-isn-t-the-okcupid-data-breach",
      "display_url" : "emilygorcenski.com\/blog\/when-open\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "730725936337977344",
  "text" : "Wow, missed the ethics cluster fuck on the \u201Eopen science\u201C efforts of scraping @okcupid\u2026 Details by @EmilyGorcenski: https:\/\/t.co\/BgC3aDolnW",
  "id" : 730725936337977344,
  "created_at" : "2016-05-12 11:46:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josefine",
      "screen_name" : "josefine",
      "indices" : [ 42, 51 ],
      "id_str" : "14054240",
      "id" : 14054240
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 89 ],
      "url" : "https:\/\/t.co\/5Kkpzj8T80",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/730716251325116417",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "730716251325116417",
  "geo" : { },
  "id_str" : "730716480900366336",
  "in_reply_to_user_id" : 14286491,
  "text" : "A rather accurate description I\u2019d say. HT @josefine for the link. https:\/\/t.co\/5Kkpzj8T80",
  "id" : 730716480900366336,
  "in_reply_to_status_id" : 730716251325116417,
  "created_at" : "2016-05-12 11:09:19 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/rUlLO1v9iF",
      "expanded_url" : "https:\/\/www.reddit.com\/r\/MapPorn\/comments\/40yi0v\/which_city_with_over_1000000_inhabitanst_do_you\/cyz01uf",
      "display_url" : "reddit.com\/r\/MapPorn\/comm\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "730716251325116417",
  "text" : "\u00ABpeople in Frankfurt live there because of their job (be it being investment banker or drug dealer - no difference)\u00BB https:\/\/t.co\/rUlLO1v9iF",
  "id" : 730716251325116417,
  "created_at" : "2016-05-12 11:08:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrea Komljenovi\u0107",
      "screen_name" : "antifreezeprot",
      "indices" : [ 0, 15 ],
      "id_str" : "851420822",
      "id" : 851420822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "730690159990194176",
  "geo" : { },
  "id_str" : "730697235256750080",
  "in_reply_to_user_id" : 851420822,
  "text" : "@antifreezeprot i think mixing species groups like this is what confuses me. ;)",
  "id" : 730697235256750080,
  "in_reply_to_status_id" : 730690159990194176,
  "created_at" : "2016-05-12 09:52:51 +0000",
  "in_reply_to_screen_name" : "antifreezeprot",
  "in_reply_to_user_id_str" : "851420822",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alice Sheppard",
      "screen_name" : "PenguinGalaxy",
      "indices" : [ 0, 14 ],
      "id_str" : "20635230",
      "id" : 20635230
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "730684185531285504",
  "geo" : { },
  "id_str" : "730684310047588352",
  "in_reply_to_user_id" : 20635230,
  "text" : "@PenguinGalaxy i still your point still applies and it\u2019s even weirder :D",
  "id" : 730684310047588352,
  "in_reply_to_status_id" : 730684185531285504,
  "created_at" : "2016-05-12 09:01:29 +0000",
  "in_reply_to_screen_name" : "PenguinGalaxy",
  "in_reply_to_user_id_str" : "20635230",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alice Sheppard",
      "screen_name" : "PenguinGalaxy",
      "indices" : [ 0, 14 ],
      "id_str" : "20635230",
      "id" : 20635230
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "730683756433055744",
  "geo" : { },
  "id_str" : "730683915522936832",
  "in_reply_to_user_id" : 20635230,
  "text" : "@PenguinGalaxy what if I told you it\u2019s the logo of a tool for annotating genomes? \uD83D\uDE02",
  "id" : 730683915522936832,
  "in_reply_to_status_id" : 730683756433055744,
  "created_at" : "2016-05-12 08:59:55 +0000",
  "in_reply_to_screen_name" : "PenguinGalaxy",
  "in_reply_to_user_id_str" : "20635230",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/730683666536529920\/photo\/1",
      "indices" : [ 69, 92 ],
      "url" : "https:\/\/t.co\/PO51xgLc9B",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CiPo6-JWgAAIcZL.jpg",
      "id_str" : "730683664376430592",
      "id" : 730683664376430592,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CiPo6-JWgAAIcZL.jpg",
      "sizes" : [ {
        "h" : 93,
        "resize" : "fit",
        "w" : 103
      }, {
        "h" : 93,
        "resize" : "fit",
        "w" : 103
      }, {
        "h" : 93,
        "resize" : "crop",
        "w" : 93
      }, {
        "h" : 93,
        "resize" : "fit",
        "w" : 103
      }, {
        "h" : 93,
        "resize" : "fit",
        "w" : 103
      } ],
      "display_url" : "pic.twitter.com\/PO51xgLc9B"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "730683666536529920",
  "text" : "Am I the only one who\u2019s properly weirded out by the BlastKOALA logo? https:\/\/t.co\/PO51xgLc9B",
  "id" : 730683666536529920,
  "created_at" : "2016-05-12 08:58:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Chapman",
      "screen_name" : "chapmangamo",
      "indices" : [ 3, 15 ],
      "id_str" : "30633376",
      "id" : 30633376
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/chapmangamo\/status\/730646663233191936\/photo\/1",
      "indices" : [ 67, 90 ],
      "url" : "https:\/\/t.co\/1bIwtRThg3",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CiPHQ7nWsAEdCwU.jpg",
      "id_str" : "730646658258743297",
      "id" : 730646658258743297,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CiPHQ7nWsAEdCwU.jpg",
      "sizes" : [ {
        "h" : 1100,
        "resize" : "fit",
        "w" : 940
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 581
      }, {
        "h" : 1100,
        "resize" : "fit",
        "w" : 940
      }, {
        "h" : 1100,
        "resize" : "fit",
        "w" : 940
      } ],
      "display_url" : "pic.twitter.com\/1bIwtRThg3"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "730681991646064640",
  "text" : "RT @chapmangamo: \"A good book is a good friend\" \n(Chinese proverb) https:\/\/t.co\/1bIwtRThg3",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/chapmangamo\/status\/730646663233191936\/photo\/1",
        "indices" : [ 50, 73 ],
        "url" : "https:\/\/t.co\/1bIwtRThg3",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CiPHQ7nWsAEdCwU.jpg",
        "id_str" : "730646658258743297",
        "id" : 730646658258743297,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CiPHQ7nWsAEdCwU.jpg",
        "sizes" : [ {
          "h" : 1100,
          "resize" : "fit",
          "w" : 940
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 581
        }, {
          "h" : 1100,
          "resize" : "fit",
          "w" : 940
        }, {
          "h" : 1100,
          "resize" : "fit",
          "w" : 940
        } ],
        "display_url" : "pic.twitter.com\/1bIwtRThg3"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "730646663233191936",
    "text" : "\"A good book is a good friend\" \n(Chinese proverb) https:\/\/t.co\/1bIwtRThg3",
    "id" : 730646663233191936,
    "created_at" : "2016-05-12 06:31:53 +0000",
    "user" : {
      "name" : "James Chapman",
      "screen_name" : "chapmangamo",
      "protected" : false,
      "id_str" : "30633376",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793772420616359937\/gpZg3fEE_normal.jpg",
      "id" : 30633376,
      "verified" : false
    }
  },
  "id" : 730681991646064640,
  "created_at" : "2016-05-12 08:52:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 71 ],
      "url" : "https:\/\/t.co\/a4LBjDMjgG",
      "expanded_url" : "https:\/\/twitter.com\/AcousticTrench\/status\/730598902349463557",
      "display_url" : "twitter.com\/AcousticTrench\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "730669879305588736",
  "text" : "Now I\u2019m waiting for Maple to play Starway next. https:\/\/t.co\/a4LBjDMjgG",
  "id" : 730669879305588736,
  "created_at" : "2016-05-12 08:04:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/lw6MhbL6Uh",
      "expanded_url" : "https:\/\/twitter.com\/PhilippBayer\/status\/730589783127269376",
      "display_url" : "twitter.com\/PhilippBayer\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "730668735313379328",
  "text" : "Basically every single transcriptomics\/genomics paper one way or another. https:\/\/t.co\/lw6MhbL6Uh",
  "id" : 730668735313379328,
  "created_at" : "2016-05-12 07:59:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uD83D\uDCABKelsey Merkley \uD83D\uDCAB",
      "screen_name" : "bella_velo",
      "indices" : [ 3, 14 ],
      "id_str" : "6745972",
      "id" : 6745972
    }, {
      "name" : "Lauren Hermanus",
      "screen_name" : "laurenhermanus",
      "indices" : [ 84, 99 ],
      "id_str" : "161657038",
      "id" : 161657038
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/ZpcKJk7i13",
      "expanded_url" : "http:\/\/mobile.nytimes.com\/2016\/05\/11\/opinion\/if-philosophy-wont-diversify-lets-call-it-what-it-really-is.html?smid=tw-share&referer=http:\/\/lm.facebook.com\/lsr.php?u=http%3A%2F%2Fnyti.ms%2F23GFoe0&ext=1462995688&hash=AcmnhwLdm6OyEj-jEMZAtp1fKVx9LE8OpwzfS4qp2vf9zA&_rdr",
      "display_url" : "mobile.nytimes.com\/2016\/05\/11\/opi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "730516289341562880",
  "text" : "RT @bella_velo: If Philosophy Won\u2019t Diversify, Let\u2019s Call It What It Really Is - CC @laurenhermanus  https:\/\/t.co\/ZpcKJk7i13",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Lauren Hermanus",
        "screen_name" : "laurenhermanus",
        "indices" : [ 68, 83 ],
        "id_str" : "161657038",
        "id" : 161657038
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 85, 108 ],
        "url" : "https:\/\/t.co\/ZpcKJk7i13",
        "expanded_url" : "http:\/\/mobile.nytimes.com\/2016\/05\/11\/opinion\/if-philosophy-wont-diversify-lets-call-it-what-it-really-is.html?smid=tw-share&referer=http:\/\/lm.facebook.com\/lsr.php?u=http%3A%2F%2Fnyti.ms%2F23GFoe0&ext=1462995688&hash=AcmnhwLdm6OyEj-jEMZAtp1fKVx9LE8OpwzfS4qp2vf9zA&_rdr",
        "display_url" : "mobile.nytimes.com\/2016\/05\/11\/opi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "730482796288983043",
    "text" : "If Philosophy Won\u2019t Diversify, Let\u2019s Call It What It Really Is - CC @laurenhermanus  https:\/\/t.co\/ZpcKJk7i13",
    "id" : 730482796288983043,
    "created_at" : "2016-05-11 19:40:45 +0000",
    "user" : {
      "name" : "\uD83D\uDCABKelsey Merkley \uD83D\uDCAB",
      "screen_name" : "bella_velo",
      "protected" : false,
      "id_str" : "6745972",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/875913994929934336\/1aiBO2bG_normal.jpg",
      "id" : 6745972,
      "verified" : false
    }
  },
  "id" : 730516289341562880,
  "created_at" : "2016-05-11 21:53:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Axis of Awesome",
      "screen_name" : "axisofawesome",
      "indices" : [ 3, 17 ],
      "id_str" : "26641872",
      "id" : 26641872
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/UwYjt0JyPb",
      "expanded_url" : "http:\/\/youtu.be\/RtmijUzgXpo?a",
      "display_url" : "youtu.be\/RtmijUzgXpo?a"
    } ]
  },
  "geo" : { },
  "id_str" : "730515484433629185",
  "text" : "RT @axisofawesome: So one member of your band has transitioned. How do you bring up the subject with your audience? https:\/\/t.co\/UwYjt0JyPb",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 97, 120 ],
        "url" : "https:\/\/t.co\/UwYjt0JyPb",
        "expanded_url" : "http:\/\/youtu.be\/RtmijUzgXpo?a",
        "display_url" : "youtu.be\/RtmijUzgXpo?a"
      } ]
    },
    "geo" : { },
    "id_str" : "729483467973660672",
    "text" : "So one member of your band has transitioned. How do you bring up the subject with your audience? https:\/\/t.co\/UwYjt0JyPb",
    "id" : 729483467973660672,
    "created_at" : "2016-05-09 01:29:46 +0000",
    "user" : {
      "name" : "The Axis of Awesome",
      "screen_name" : "axisofawesome",
      "protected" : false,
      "id_str" : "26641872",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1374958239\/image_normal.jpg",
      "id" : 26641872,
      "verified" : true
    }
  },
  "id" : 730515484433629185,
  "created_at" : "2016-05-11 21:50:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "730364223180681218",
  "geo" : { },
  "id_str" : "730405733779554304",
  "in_reply_to_user_id" : 14286491,
  "text" : "A shell script which calls some Python scripts which call some R scripts. \uD83D\uDD2E",
  "id" : 730405733779554304,
  "in_reply_to_status_id" : 730364223180681218,
  "created_at" : "2016-05-11 14:34:31 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Egle Ramanauskaite \u2623",
      "screen_name" : "Seplute",
      "indices" : [ 0, 8 ],
      "id_str" : "188833865",
      "id" : 188833865
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 67 ],
      "url" : "https:\/\/t.co\/yduN6RxyVR",
      "expanded_url" : "http:\/\/www.personalizedhealth2016.org\/",
      "display_url" : "personalizedhealth2016.org"
    } ]
  },
  "in_reply_to_status_id_str" : "730363444055134208",
  "geo" : { },
  "id_str" : "730364744532643840",
  "in_reply_to_user_id" : 188833865,
  "text" : "@Seplute SMBE; BOSC; 4S\/EASST; and this one https:\/\/t.co\/yduN6RxyVR So no overlap so far :D",
  "id" : 730364744532643840,
  "in_reply_to_status_id" : 730363444055134208,
  "created_at" : "2016-05-11 11:51:39 +0000",
  "in_reply_to_screen_name" : "Seplute",
  "in_reply_to_user_id_str" : "188833865",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "730364223180681218",
  "text" : "Organically grown Python code, includes \u201E# wow this is ugly by now\u201C for a reason.",
  "id" : 730364223180681218,
  "created_at" : "2016-05-11 11:49:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 65 ],
      "url" : "https:\/\/t.co\/IoQyiRPfkh",
      "expanded_url" : "http:\/\/www.smbc-comics.com\/index.php?id=4106",
      "display_url" : "smbc-comics.com\/index.php?id=4\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "730341376311885829",
  "text" : "it\u2019s dependent variables all the way down https:\/\/t.co\/IoQyiRPfkh",
  "id" : 730341376311885829,
  "created_at" : "2016-05-11 10:18:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/YIwQBJkiJX",
      "expanded_url" : "http:\/\/biorxiv.org\/content\/early\/2016\/04\/19\/049288",
      "display_url" : "biorxiv.org\/content\/early\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "730302698675900417",
  "text" : "Why you shouldn\u2019t be using outdated databases: Impact of knowledge accumulation on pathway enrichment analysis https:\/\/t.co\/YIwQBJkiJX",
  "id" : 730302698675900417,
  "created_at" : "2016-05-11 07:45:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "supergarv",
      "screen_name" : "supergarv",
      "indices" : [ 0, 10 ],
      "id_str" : "14340395",
      "id" : 14340395
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "730143214083125248",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06085384510811, 8.818732272831804 ]
  },
  "id_str" : "730143375723270145",
  "in_reply_to_user_id" : 14340395,
  "text" : "@supergarv tats\u00E4chlich schaue ich sie gerade zum zweiten Mal alle. Die Soundtracks sind auch super.",
  "id" : 730143375723270145,
  "in_reply_to_status_id" : 730143214083125248,
  "created_at" : "2016-05-10 21:12:00 +0000",
  "in_reply_to_screen_name" : "supergarv",
  "in_reply_to_user_id_str" : "14340395",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "supergarv",
      "screen_name" : "supergarv",
      "indices" : [ 0, 10 ],
      "id_str" : "14340395",
      "id" : 14340395
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "730139299308507142",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06084450230576, 8.8187570906784 ]
  },
  "id_str" : "730141059305607172",
  "in_reply_to_user_id" : 14340395,
  "text" : "@supergarv wie viel von Californication muss ich auswendig kennen damit ich qualified bin? :p",
  "id" : 730141059305607172,
  "in_reply_to_status_id" : 730139299308507142,
  "created_at" : "2016-05-10 21:02:48 +0000",
  "in_reply_to_screen_name" : "supergarv",
  "in_reply_to_user_id_str" : "14340395",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "supergarv",
      "screen_name" : "supergarv",
      "indices" : [ 0, 10 ],
      "id_str" : "14340395",
      "id" : 14340395
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "730138084961075204",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06089531821204, 8.818570151933299 ]
  },
  "id_str" : "730138471285829632",
  "in_reply_to_user_id" : 14340395,
  "text" : "@supergarv Lohnt es sich?",
  "id" : 730138471285829632,
  "in_reply_to_status_id" : 730138084961075204,
  "created_at" : "2016-05-10 20:52:31 +0000",
  "in_reply_to_screen_name" : "supergarv",
  "in_reply_to_user_id_str" : "14340395",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Egle Ramanauskaite \u2623",
      "screen_name" : "Seplute",
      "indices" : [ 0, 8 ],
      "id_str" : "188833865",
      "id" : 188833865
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "730133392369520644",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06078395079529, 8.818521337799062 ]
  },
  "id_str" : "730135320012926976",
  "in_reply_to_user_id" : 188833865,
  "text" : "@Seplute nice! Btw: how does your conference schedule for the future look like? :D",
  "id" : 730135320012926976,
  "in_reply_to_status_id" : 730133392369520644,
  "created_at" : "2016-05-10 20:40:00 +0000",
  "in_reply_to_screen_name" : "Seplute",
  "in_reply_to_user_id_str" : "188833865",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Egle Ramanauskaite \u2623",
      "screen_name" : "Seplute",
      "indices" : [ 0, 8 ],
      "id_str" : "188833865",
      "id" : 188833865
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "730123882850623488",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.10611895476477, 8.68473504670773 ]
  },
  "id_str" : "730124118079750146",
  "in_reply_to_user_id" : 188833865,
  "text" : "@Seplute yes, I know the project. It\u2019s cool!",
  "id" : 730124118079750146,
  "in_reply_to_status_id" : 730123882850623488,
  "created_at" : "2016-05-10 19:55:29 +0000",
  "in_reply_to_screen_name" : "Seplute",
  "in_reply_to_user_id_str" : "188833865",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "729957118103724032",
  "text" : "\u00ABDo you know a bit of HTML?\u00BB \u2013 \u00ABYeah, sure.\u00BB \u2013 \u00ABPerfect, I\u2019ve got a question regarding JavaScript!\u00BB \uD83D\uDE44",
  "id" : 729957118103724032,
  "created_at" : "2016-05-10 08:51:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "729947322977812480",
  "text" : "Funding: collected enough empty bottles in my office that cashing them in for the deposit will allow me to work an additional year on my PhD",
  "id" : 729947322977812480,
  "created_at" : "2016-05-10 08:12:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "N J Clarke",
      "screen_name" : "compay",
      "indices" : [ 0, 7 ],
      "id_str" : "9793782",
      "id" : 9793782
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "729844251257909248",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17421265357717, 8.626875888213206 ]
  },
  "id_str" : "729940880526815232",
  "in_reply_to_user_id" : 9793782,
  "text" : "@compay A+ \uD83D\uDE0A",
  "id" : 729940880526815232,
  "in_reply_to_status_id" : 729844251257909248,
  "created_at" : "2016-05-10 07:47:22 +0000",
  "in_reply_to_screen_name" : "compay",
  "in_reply_to_user_id_str" : "9793782",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ann Loraine",
      "screen_name" : "aloraine205",
      "indices" : [ 3, 15 ],
      "id_str" : "114142293",
      "id" : 114142293
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/Ke1oF7zjFU",
      "expanded_url" : "http:\/\/www.bioinformatics.org\/franklin\/",
      "display_url" : "bioinformatics.org\/franklin\/"
    } ]
  },
  "geo" : { },
  "id_str" : "729926037304389632",
  "text" : "RT @aloraine205: What do you think? Nominate Alexandra Elbakyan of SciHub for Ben Franklin prize https:\/\/t.co\/Ke1oF7zjFU ? Not open source,\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 80, 103 ],
        "url" : "https:\/\/t.co\/Ke1oF7zjFU",
        "expanded_url" : "http:\/\/www.bioinformatics.org\/franklin\/",
        "display_url" : "bioinformatics.org\/franklin\/"
      } ]
    },
    "geo" : { },
    "id_str" : "729832451384676352",
    "text" : "What do you think? Nominate Alexandra Elbakyan of SciHub for Ben Franklin prize https:\/\/t.co\/Ke1oF7zjFU ? Not open source, but open data?",
    "id" : 729832451384676352,
    "created_at" : "2016-05-10 00:36:30 +0000",
    "user" : {
      "name" : "Ann Loraine",
      "screen_name" : "aloraine205",
      "protected" : false,
      "id_str" : "114142293",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2525523774\/olxn00n8niqsbbuq2ful_normal.jpeg",
      "id" : 114142293,
      "verified" : false
    }
  },
  "id" : 729926037304389632,
  "created_at" : "2016-05-10 06:48:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 50 ],
      "url" : "https:\/\/t.co\/gk213uo4HK",
      "expanded_url" : "https:\/\/twitter.com\/MozillaScience\/status\/729783460957556736",
      "display_url" : "twitter.com\/MozillaScience\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06083693728263, 8.818643468523375 ]
  },
  "id_str" : "729787239266459650",
  "text" : "Help us, pretty please? \uD83D\uDC36\uD83D\uDE44 https:\/\/t.co\/gk213uo4HK",
  "id" : 729787239266459650,
  "created_at" : "2016-05-09 21:36:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 86 ],
      "url" : "https:\/\/t.co\/BzI9yEQYOV",
      "expanded_url" : "https:\/\/www.openscienceprize.org\/res\/p\/finalists\/#6",
      "display_url" : "openscienceprize.org\/res\/p\/finalist\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "729699166692200448",
  "text" : "\u201ERadically Open Data Sharing\u201C buzzwording very much? \u00AF\\_(\u30C4)_\/\u00AF https:\/\/t.co\/BzI9yEQYOV",
  "id" : 729699166692200448,
  "created_at" : "2016-05-09 15:46:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "purrrlegon",
      "screen_name" : "pulegon",
      "indices" : [ 0, 8 ],
      "id_str" : "107502279",
      "id" : 107502279
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 86 ],
      "url" : "https:\/\/t.co\/NXhXgsc5u5",
      "expanded_url" : "http:\/\/i1-news.softpedia-static.com\/images\/news2\/Picture-of-the-Day-Lioness-Naps-in-Odd-Seemingly-Uncomfortable-Position-436182-2.jpg",
      "display_url" : "i1-news.softpedia-static.com\/images\/news2\/P\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "729697074120380416",
  "geo" : { },
  "id_str" : "729697884556410880",
  "in_reply_to_user_id" : 107502279,
  "text" : "@pulegon everything\u2019s the right place, if you try hard enough. https:\/\/t.co\/NXhXgsc5u5",
  "id" : 729697884556410880,
  "in_reply_to_status_id" : 729697074120380416,
  "created_at" : "2016-05-09 15:41:47 +0000",
  "in_reply_to_screen_name" : "pulegon",
  "in_reply_to_user_id_str" : "107502279",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Schawinski",
      "screen_name" : "kevinschawinski",
      "indices" : [ 0, 16 ],
      "id_str" : "242844365",
      "id" : 242844365
    }, {
      "name" : "Alice Sheppard",
      "screen_name" : "PenguinGalaxy",
      "indices" : [ 17, 31 ],
      "id_str" : "20635230",
      "id" : 20635230
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "729696204762824704",
  "geo" : { },
  "id_str" : "729696897854746625",
  "in_reply_to_user_id" : 242844365,
  "text" : "@kevinschawinski @PenguinGalaxy No wonder then that Metallica sued them, infringes directly on their \u201EUntil it Sleeps\u201C.",
  "id" : 729696897854746625,
  "in_reply_to_status_id" : 729696204762824704,
  "created_at" : "2016-05-09 15:37:52 +0000",
  "in_reply_to_screen_name" : "kevinschawinski",
  "in_reply_to_user_id_str" : "242844365",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/hMuqoR0b5Y",
      "expanded_url" : "http:\/\/naps.google.com",
      "display_url" : "naps.google.com"
    } ]
  },
  "geo" : { },
  "id_str" : "729694557378580480",
  "text" : "Given how often I mistype it, I can\u2019t believe that there still isn\u2019t a https:\/\/t.co\/hMuqoR0b5Y service.",
  "id" : 729694557378580480,
  "created_at" : "2016-05-09 15:28:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Pardy",
      "screen_name" : "BrianPardy",
      "indices" : [ 0, 11 ],
      "id_str" : "611699110",
      "id" : 611699110
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 22, 35 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "729664637847900161",
  "geo" : { },
  "id_str" : "729669025035395073",
  "in_reply_to_user_id" : 611699110,
  "text" : "@BrianPardy Thanks to @PhilippBayer for reminding me of the status: Our database is still migrating, once that\u2019s done it should work :D",
  "id" : 729669025035395073,
  "in_reply_to_status_id" : 729664637847900161,
  "created_at" : "2016-05-09 13:47:06 +0000",
  "in_reply_to_screen_name" : "BrianPardy",
  "in_reply_to_user_id_str" : "611699110",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Pardy",
      "screen_name" : "BrianPardy",
      "indices" : [ 0, 11 ],
      "id_str" : "611699110",
      "id" : 611699110
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "729661752733016064",
  "geo" : { },
  "id_str" : "729663073791954944",
  "in_reply_to_user_id" : 611699110,
  "text" : "@BrianPardy sorry, totally forgot about it. It\u2019s on my todo again!",
  "id" : 729663073791954944,
  "in_reply_to_status_id" : 729661752733016064,
  "created_at" : "2016-05-09 13:23:27 +0000",
  "in_reply_to_screen_name" : "BrianPardy",
  "in_reply_to_user_id_str" : "611699110",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Blin",
      "screen_name" : "kaiblin",
      "indices" : [ 0, 8 ],
      "id_str" : "124202458",
      "id" : 124202458
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "729660882775646208",
  "geo" : { },
  "id_str" : "729661263681335296",
  "in_reply_to_user_id" : 124202458,
  "text" : "@kaiblin at least for the headers it\u2019s not too bad in our case. But yes :)",
  "id" : 729661263681335296,
  "in_reply_to_status_id" : 729660882775646208,
  "created_at" : "2016-05-09 13:16:16 +0000",
  "in_reply_to_screen_name" : "kaiblin",
  "in_reply_to_user_id_str" : "124202458",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "729658926678028289",
  "geo" : { },
  "id_str" : "729660868837920768",
  "in_reply_to_user_id" : 14286491,
  "text" : "Code Sample: AGACGCAGTCTTCAGCAAGGAAGTGCTGGGAACGCCCTGGAGTGAACCCAGGAAGATGCCTGCAGTGGGT\nGCCAGGGCCCCTCTCCACCGTCCCTGCTGGGCTTCGGGGCCACGCCCGGCCCGGGG",
  "id" : 729660868837920768,
  "in_reply_to_status_id" : 729658926678028289,
  "created_at" : "2016-05-09 13:14:42 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Blin",
      "screen_name" : "kaiblin",
      "indices" : [ 0, 8 ],
      "id_str" : "124202458",
      "id" : 124202458
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "729659557174251520",
  "geo" : { },
  "id_str" : "729659721347682304",
  "in_reply_to_user_id" : 124202458,
  "text" : "@kaiblin fully agree, but to be fair, they give a long disclaimer how it\u2019s probably not an ideal tool.",
  "id" : 729659721347682304,
  "in_reply_to_status_id" : 729659557174251520,
  "created_at" : "2016-05-09 13:10:08 +0000",
  "in_reply_to_screen_name" : "kaiblin",
  "in_reply_to_user_id_str" : "124202458",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/QMoGqCCiFg",
      "expanded_url" : "https:\/\/twitter.com\/teabass\/status\/729572010876125184",
      "display_url" : "twitter.com\/teabass\/status\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "729658926678028289",
  "text" : "openSNP is a solid B if you ignore the (not really applicable) code samples part. https:\/\/t.co\/QMoGqCCiFg",
  "id" : 729658926678028289,
  "created_at" : "2016-05-09 13:06:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 3, 16 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "openSNP team",
      "screen_name" : "openSNPorg",
      "indices" : [ 40, 51 ],
      "id_str" : "380205172",
      "id" : 380205172
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/AhaRwMO6S2",
      "expanded_url" : "https:\/\/github.com\/openSNP\/snpr\/pull\/281",
      "display_url" : "github.com\/openSNP\/snpr\/p\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "729566006193033216",
  "text" : "RT @PhilippBayer: First pull request to @openSNPorg under Google Summer of Code! https:\/\/t.co\/AhaRwMO6S2",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "openSNP team",
        "screen_name" : "openSNPorg",
        "indices" : [ 22, 33 ],
        "id_str" : "380205172",
        "id" : 380205172
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 63, 86 ],
        "url" : "https:\/\/t.co\/AhaRwMO6S2",
        "expanded_url" : "https:\/\/github.com\/openSNP\/snpr\/pull\/281",
        "display_url" : "github.com\/openSNP\/snpr\/p\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "729163030748004353",
    "text" : "First pull request to @openSNPorg under Google Summer of Code! https:\/\/t.co\/AhaRwMO6S2",
    "id" : 729163030748004353,
    "created_at" : "2016-05-08 04:16:28 +0000",
    "user" : {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "protected" : false,
      "id_str" : "121777206",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2013711027\/IMG_1088_normal.png",
      "id" : 121777206,
      "verified" : false
    }
  },
  "id" : 729566006193033216,
  "created_at" : "2016-05-09 06:57:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NOGLSTP",
      "screen_name" : "STEMforEquality",
      "indices" : [ 3, 19 ],
      "id_str" : "1458320232",
      "id" : 1458320232
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/veUOube4x0",
      "expanded_url" : "http:\/\/www.noglstp.org\/programs-projects\/scholarships\/",
      "display_url" : "noglstp.org\/programs-proje\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "729458114240622592",
  "text" : "RT @STEMforEquality: LGBTQ+ STEM students: apply for a scholarship. Ugrad and grad. Deadline June 4 for AY2016-2017. https:\/\/t.co\/veUOube4x0",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 96, 119 ],
        "url" : "https:\/\/t.co\/veUOube4x0",
        "expanded_url" : "http:\/\/www.noglstp.org\/programs-projects\/scholarships\/",
        "display_url" : "noglstp.org\/programs-proje\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "729426268756697090",
    "text" : "LGBTQ+ STEM students: apply for a scholarship. Ugrad and grad. Deadline June 4 for AY2016-2017. https:\/\/t.co\/veUOube4x0",
    "id" : 729426268756697090,
    "created_at" : "2016-05-08 21:42:29 +0000",
    "user" : {
      "name" : "NOGLSTP",
      "screen_name" : "STEMforEquality",
      "protected" : false,
      "id_str" : "1458320232",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/459746344085626880\/KlpF6FDC_normal.jpeg",
      "id" : 1458320232,
      "verified" : false
    }
  },
  "id" : 729458114240622592,
  "created_at" : "2016-05-08 23:49:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 3, 12 ],
      "id_str" : "14245811",
      "id" : 14245811
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/wilbanks\/status\/729349388984799232\/photo\/1",
      "indices" : [ 49, 72 ],
      "url" : "https:\/\/t.co\/Z13X91Sr5e",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ch8rZ59XAAA_rde.jpg",
      "id_str" : "729349388712214528",
      "id" : 729349388712214528,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ch8rZ59XAAA_rde.jpg",
      "sizes" : [ {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/Z13X91Sr5e"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "729451456378605568",
  "text" : "RT @wilbanks: That is the sound of inevitability https:\/\/t.co\/Z13X91Sr5e",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/wilbanks\/status\/729349388984799232\/photo\/1",
        "indices" : [ 35, 58 ],
        "url" : "https:\/\/t.co\/Z13X91Sr5e",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Ch8rZ59XAAA_rde.jpg",
        "id_str" : "729349388712214528",
        "id" : 729349388712214528,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ch8rZ59XAAA_rde.jpg",
        "sizes" : [ {
          "h" : 680,
          "resize" : "fit",
          "w" : 510
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        } ],
        "display_url" : "pic.twitter.com\/Z13X91Sr5e"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "729349388984799232",
    "text" : "That is the sound of inevitability https:\/\/t.co\/Z13X91Sr5e",
    "id" : 729349388984799232,
    "created_at" : "2016-05-08 16:36:59 +0000",
    "user" : {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "protected" : false,
      "id_str" : "14245811",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/925696899566440448\/BUTdp410_normal.jpg",
      "id" : 14245811,
      "verified" : false
    }
  },
  "id" : 729451456378605568,
  "created_at" : "2016-05-08 23:22:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mick Watson",
      "screen_name" : "BioMickWatson",
      "indices" : [ 3, 17 ],
      "id_str" : "228586748",
      "id" : 228586748
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bog16",
      "indices" : [ 107, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/XAVG29rsKT",
      "expanded_url" : "http:\/\/www.bbc.co.uk\/news\/world-us-canada-36240523",
      "display_url" : "bbc.co.uk\/news\/world-us-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "729280816707178496",
  "text" : "RT @BioMickWatson: Python programmers eject passenger on suspicion of being a Perl programmer on flight to #bog16 \n\nhttps:\/\/t.co\/XAVG29rsKT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "bog16",
        "indices" : [ 88, 94 ]
      } ],
      "urls" : [ {
        "indices" : [ 97, 120 ],
        "url" : "https:\/\/t.co\/XAVG29rsKT",
        "expanded_url" : "http:\/\/www.bbc.co.uk\/news\/world-us-canada-36240523",
        "display_url" : "bbc.co.uk\/news\/world-us-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "729269417301946368",
    "text" : "Python programmers eject passenger on suspicion of being a Perl programmer on flight to #bog16 \n\nhttps:\/\/t.co\/XAVG29rsKT",
    "id" : 729269417301946368,
    "created_at" : "2016-05-08 11:19:12 +0000",
    "user" : {
      "name" : "Mick Watson",
      "screen_name" : "BioMickWatson",
      "protected" : false,
      "id_str" : "228586748",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/870214569679093760\/YIZGIDTS_normal.jpg",
      "id" : 228586748,
      "verified" : false
    }
  },
  "id" : 729280816707178496,
  "created_at" : "2016-05-08 12:04:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/729279438299516932\/photo\/1",
      "indices" : [ 23, 46 ],
      "url" : "https:\/\/t.co\/iywx8v9bTL",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ch7rx-qWkAE_nr9.jpg",
      "id_str" : "729279433547354113",
      "id" : 729279433547354113,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ch7rx-qWkAE_nr9.jpg",
      "sizes" : [ {
        "h" : 3024,
        "resize" : "fit",
        "w" : 4032
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/iywx8v9bTL"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35922044950222, 8.587850229967128 ]
  },
  "id_str" : "729279438299516932",
  "text" : "Been there, done that. https:\/\/t.co\/iywx8v9bTL",
  "id" : 729279438299516932,
  "created_at" : "2016-05-08 11:59:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35918968273466, 8.587955680056051 ]
  },
  "id_str" : "729278936442650624",
  "text" : "\u00ABSpeaking of sex with twins, I wanted to show you a picture of my sister.\u00BB not all segues are created equally.",
  "id" : 729278936442650624,
  "created_at" : "2016-05-08 11:57:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35923852951563, 8.587738766217376 ]
  },
  "id_str" : "729077468343238656",
  "text" : "Happy VE Day! \u270C",
  "id" : 729077468343238656,
  "created_at" : "2016-05-07 22:36:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "The_Smoking_GNU",
      "indices" : [ 0, 16 ],
      "id_str" : "14535787",
      "id" : 14535787
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "729031633421127681",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.3592971146953, 8.587803378744379 ]
  },
  "id_str" : "729034000623341568",
  "in_reply_to_user_id" : 14535787,
  "text" : "@The_Smoking_GNU you really got my taste down \uD83D\uDC4D\uD83D\uDE02",
  "id" : 729034000623341568,
  "in_reply_to_status_id" : 729031633421127681,
  "created_at" : "2016-05-07 19:43:45 +0000",
  "in_reply_to_screen_name" : "The_Smoking_GNU",
  "in_reply_to_user_id_str" : "14535787",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/729031350561456133\/photo\/1",
      "indices" : [ 60, 83 ],
      "url" : "https:\/\/t.co\/np9y70Gqww",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ch4KJooWEAEbHYd.jpg",
      "id_str" : "729031350322335745",
      "id" : 729031350322335745,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ch4KJooWEAEbHYd.jpg",
      "sizes" : [ {
        "h" : 934,
        "resize" : "fit",
        "w" : 1245
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 934,
        "resize" : "fit",
        "w" : 1245
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/np9y70Gqww"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35945, 8.587993 ]
  },
  "id_str" : "729031350561456133",
  "text" : "Feynman on the sorry state of psychology. As early as 1947. https:\/\/t.co\/np9y70Gqww",
  "id" : 729031350561456133,
  "created_at" : "2016-05-07 19:33:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "The_Smoking_GNU",
      "indices" : [ 0, 16 ],
      "id_str" : "14535787",
      "id" : 14535787
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "729028076508741632",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35933540775949, 8.587930337550029 ]
  },
  "id_str" : "729031159758372865",
  "in_reply_to_user_id" : 14535787,
  "text" : "@The_Smoking_GNU I really liked Bad Pharma, was one of my favorites in the year it came out! Have fun!",
  "id" : 729031159758372865,
  "in_reply_to_status_id" : 729028076508741632,
  "created_at" : "2016-05-07 19:32:27 +0000",
  "in_reply_to_screen_name" : "The_Smoking_GNU",
  "in_reply_to_user_id_str" : "14535787",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/729026112332894208\/photo\/1",
      "indices" : [ 35, 58 ],
      "url" : "https:\/\/t.co\/nIVlqJa7GA",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ch4FYuvWwAAX2-G.jpg",
      "id_str" : "729026112102252544",
      "id" : 729026112102252544,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ch4FYuvWwAAX2-G.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 346,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 815,
        "resize" : "fit",
        "w" : 1603
      }, {
        "h" : 815,
        "resize" : "fit",
        "w" : 1603
      }, {
        "h" : 610,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/nIVlqJa7GA"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35936, 8.587665 ]
  },
  "id_str" : "729026112332894208",
  "text" : "Feynman on publication bias, 1974. https:\/\/t.co\/nIVlqJa7GA",
  "id" : 729026112332894208,
  "created_at" : "2016-05-07 19:12:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Schawinski",
      "screen_name" : "kevinschawinski",
      "indices" : [ 0, 16 ],
      "id_str" : "242844365",
      "id" : 242844365
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "728991757606785024",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.34905558877551, 8.534443694084729 ]
  },
  "id_str" : "728999148809289728",
  "in_reply_to_user_id" : 242844365,
  "text" : "@kevinschawinski wish I had taken an additional day off for coming by on Monday now!",
  "id" : 728999148809289728,
  "in_reply_to_status_id" : 728991757606785024,
  "created_at" : "2016-05-07 17:25:15 +0000",
  "in_reply_to_screen_name" : "kevinschawinski",
  "in_reply_to_user_id_str" : "242844365",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Schawinski",
      "screen_name" : "kevinschawinski",
      "indices" : [ 0, 16 ],
      "id_str" : "242844365",
      "id" : 242844365
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "728990730216165376",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.34894783916472, 8.534453482204798 ]
  },
  "id_str" : "728990991429079044",
  "in_reply_to_user_id" : 242844365,
  "text" : "@kevinschawinski damn it, I\u2019m going back tomorrow. But I\u2019ll come down again at some point in the nearish future. I\u2019ll let you know in time!",
  "id" : 728990991429079044,
  "in_reply_to_status_id" : 728990730216165376,
  "created_at" : "2016-05-07 16:52:51 +0000",
  "in_reply_to_screen_name" : "kevinschawinski",
  "in_reply_to_user_id_str" : "242844365",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Schawinski",
      "screen_name" : "kevinschawinski",
      "indices" : [ 0, 16 ],
      "id_str" : "242844365",
      "id" : 242844365
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "728921423578828802",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.34889934336748, 8.534317447391665 ]
  },
  "id_str" : "728990518382833664",
  "in_reply_to_user_id" : 242844365,
  "text" : "@kevinschawinski please take me there one day!",
  "id" : 728990518382833664,
  "in_reply_to_status_id" : 728921423578828802,
  "created_at" : "2016-05-07 16:50:58 +0000",
  "in_reply_to_screen_name" : "kevinschawinski",
  "in_reply_to_user_id_str" : "242844365",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Schawinski",
      "screen_name" : "kevinschawinski",
      "indices" : [ 0, 16 ],
      "id_str" : "242844365",
      "id" : 242844365
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "728907069483569152",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35920621740458, 8.587659071644003 ]
  },
  "id_str" : "728919882075607041",
  "in_reply_to_user_id" : 242844365,
  "text" : "@kevinschawinski that\u2019s the Swiss-German phrase for \u2018remove the dog poop\u2019, right?",
  "id" : 728919882075607041,
  "in_reply_to_status_id" : 728907069483569152,
  "created_at" : "2016-05-07 12:10:17 +0000",
  "in_reply_to_screen_name" : "kevinschawinski",
  "in_reply_to_user_id_str" : "242844365",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Schawinski",
      "screen_name" : "kevinschawinski",
      "indices" : [ 0, 16 ],
      "id_str" : "242844365",
      "id" : 242844365
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "728906102302232577",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35922184034673, 8.587643301814111 ]
  },
  "id_str" : "728906551310884865",
  "in_reply_to_user_id" : 242844365,
  "text" : "@kevinschawinski I noticed. I\u2019m still always unsure whether it\u2019s Swiss-German or some other archaic, nearly dead, language :p",
  "id" : 728906551310884865,
  "in_reply_to_status_id" : 728906102302232577,
  "created_at" : "2016-05-07 11:17:18 +0000",
  "in_reply_to_screen_name" : "kevinschawinski",
  "in_reply_to_user_id_str" : "242844365",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.3593180212447, 8.587901658479684 ]
  },
  "id_str" : "728905465451646977",
  "text" : "\u00ABHow\u2019s your German coming along?\u00BB \u2014 \u00ABPretty good, I know \u2018I love you\u2019, \u2018I hate you\u2019 and \u2018Remove the dog poop!\u2019\u00BB",
  "id" : 728905465451646977,
  "created_at" : "2016-05-07 11:13:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 78 ],
      "url" : "https:\/\/t.co\/dv7hhBX6iR",
      "expanded_url" : "https:\/\/twitter.com\/OBF_BOSC\/status\/728691045500751872",
      "display_url" : "twitter.com\/OBF_BOSC\/statu\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.3591476713908, 8.587658839727952 ]
  },
  "id_str" : "728853929543487489",
  "text" : "Our submission on the state of openSNP was accepted. \uD83C\uDF89 https:\/\/t.co\/dv7hhBX6iR",
  "id" : 728853929543487489,
  "created_at" : "2016-05-07 07:48:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sujai Kumar",
      "screen_name" : "sujaik",
      "indices" : [ 0, 7 ],
      "id_str" : "33651124",
      "id" : 33651124
    }, {
      "name" : "Ed Yong",
      "screen_name" : "edyong209",
      "indices" : [ 8, 18 ],
      "id_str" : "19767193",
      "id" : 19767193
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "728852546014617600",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35919068522757, 8.587575997666827 ]
  },
  "id_str" : "728852696145526785",
  "in_reply_to_user_id" : 33651124,
  "text" : "@sujaik @edyong209 we\u2019re looking forward to see you join the collection :D",
  "id" : 728852696145526785,
  "in_reply_to_status_id" : 728852546014617600,
  "created_at" : "2016-05-07 07:43:18 +0000",
  "in_reply_to_screen_name" : "sujaik",
  "in_reply_to_user_id_str" : "33651124",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rose Eveleth \u25B7\u25B7",
      "screen_name" : "roseveleth",
      "indices" : [ 3, 14 ],
      "id_str" : "44903491",
      "id" : 44903491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "728851870131863552",
  "text" : "RT @roseveleth: Sorry, I\u2019m no expert and I don\u2019t mean to be bossy, but I just feel like you should stop telling women how to talk. https:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/5Q7rKKQv6R",
        "expanded_url" : "http:\/\/www.theguardian.com\/lifeandstyle\/2016\/may\/03\/what-women-shouldnt-say-molly-worthen-female-vocabulary",
        "display_url" : "theguardian.com\/lifeandstyle\/2\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "728703771434483717",
    "text" : "Sorry, I\u2019m no expert and I don\u2019t mean to be bossy, but I just feel like you should stop telling women how to talk. https:\/\/t.co\/5Q7rKKQv6R",
    "id" : 728703771434483717,
    "created_at" : "2016-05-06 21:51:32 +0000",
    "user" : {
      "name" : "Rose Eveleth \u25B7\u25B7",
      "screen_name" : "roseveleth",
      "protected" : false,
      "id_str" : "44903491",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/782201676006588416\/GAIXvMwJ_normal.jpg",
      "id" : 44903491,
      "verified" : false
    }
  },
  "id" : 728851870131863552,
  "created_at" : "2016-05-07 07:40:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BOSC",
      "screen_name" : "OBF_BOSC",
      "indices" : [ 3, 12 ],
      "id_str" : "583180584",
      "id" : 583180584
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BOSC2016",
      "indices" : [ 23, 32 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "728848857233272832",
  "text" : "RT @OBF_BOSC: Call for #BOSC2016 Late-Breaking Lightning Talks and posters\nopens next week (deadline June 2, same date ISMB\/BOSC\nearly regi\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BOSC2016",
        "indices" : [ 9, 18 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "728691794439905280",
    "text" : "Call for #BOSC2016 Late-Breaking Lightning Talks and posters\nopens next week (deadline June 2, same date ISMB\/BOSC\nearly registration ends).",
    "id" : 728691794439905280,
    "created_at" : "2016-05-06 21:03:56 +0000",
    "user" : {
      "name" : "BOSC",
      "screen_name" : "OBF_BOSC",
      "protected" : false,
      "id_str" : "583180584",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2227105401\/BOSC-logo-square_normal.jpg",
      "id" : 583180584,
      "verified" : false
    }
  },
  "id" : 728848857233272832,
  "created_at" : "2016-05-07 07:28:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "728668698509230081",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35920174790272, 8.587664585016883 ]
  },
  "id_str" : "728671578628755456",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot not sure if yoga or new trendy martial arts.",
  "id" : 728671578628755456,
  "in_reply_to_status_id" : 728668698509230081,
  "created_at" : "2016-05-06 19:43:37 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 41 ],
      "url" : "https:\/\/t.co\/oy3VfEGKPZ",
      "expanded_url" : "https:\/\/45.media.tumblr.com\/eeb2ce238bfab666f4c809b3b1b3ebdb\/tumblr_nisst221RX1smhspeo1_500.gif",
      "display_url" : "45.media.tumblr.com\/eeb2ce238bfab6\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "728667204212953089",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35920536417976, 8.587669630787893 ]
  },
  "id_str" : "728668409265786881",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot a bit like https:\/\/t.co\/oy3VfEGKPZ",
  "id" : 728668409265786881,
  "in_reply_to_status_id" : 728667204212953089,
  "created_at" : "2016-05-06 19:31:01 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35922769075432, 8.58768063623885 ]
  },
  "id_str" : "728665910979006464",
  "text" : "Things you hear at the Lake Zurich shores: German &amp; Swiss people fighting over (Swiss-)German grammar.",
  "id" : 728665910979006464,
  "created_at" : "2016-05-06 19:21:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uD83D\uDCABKelsey Merkley \uD83D\uDCAB",
      "screen_name" : "bella_velo",
      "indices" : [ 0, 11 ],
      "id_str" : "6745972",
      "id" : 6745972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "728576660015058944",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35929919647791, 8.587703145631638 ]
  },
  "id_str" : "728664767221608448",
  "in_reply_to_user_id" : 6745972,
  "text" : "@bella_velo be prepared!",
  "id" : 728664767221608448,
  "in_reply_to_status_id" : 728576660015058944,
  "created_at" : "2016-05-06 19:16:33 +0000",
  "in_reply_to_screen_name" : "bella_velo",
  "in_reply_to_user_id_str" : "6745972",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uD83D\uDCABKelsey Merkley \uD83D\uDCAB",
      "screen_name" : "bella_velo",
      "indices" : [ 0, 11 ],
      "id_str" : "6745972",
      "id" : 6745972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "728575120839684096",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.359306902479, 8.587820708386388 ]
  },
  "id_str" : "728575488323686400",
  "in_reply_to_user_id" : 6745972,
  "text" : "@bella_velo yes, and the circumstances how it came to that are best discussed over some whiskey.",
  "id" : 728575488323686400,
  "in_reply_to_status_id" : 728575120839684096,
  "created_at" : "2016-05-06 13:21:47 +0000",
  "in_reply_to_screen_name" : "bella_velo",
  "in_reply_to_user_id_str" : "6745972",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uD83D\uDCABKelsey Merkley \uD83D\uDCAB",
      "screen_name" : "bella_velo",
      "indices" : [ 44, 55 ],
      "id_str" : "6745972",
      "id" : 6745972
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/728574272084545536\/photo\/1",
      "indices" : [ 63, 86 ],
      "url" : "https:\/\/t.co\/7w9A17caHv",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ChxqbkcUUAACV7b.jpg",
      "id_str" : "728574261598638080",
      "id" : 728574261598638080,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ChxqbkcUUAACV7b.jpg",
      "sizes" : [ {
        "h" : 680,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 3024,
        "resize" : "fit",
        "w" : 3024
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/7w9A17caHv"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35925088426882, 8.587697081653902 ]
  },
  "id_str" : "728574272084545536",
  "text" : "O Canada, maple syrup for breakfast. Making @bella_velo proud. https:\/\/t.co\/7w9A17caHv",
  "id" : 728574272084545536,
  "created_at" : "2016-05-06 13:16:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "quantifiedself",
      "indices" : [ 22, 37 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35920236876958, 8.587702071075638 ]
  },
  "id_str" : "728543013845225472",
  "text" : "\u00ABMaybe you could do a #quantifiedself study on when break-ups don\u2019t affect your resting heart rate any longer?\u00BB",
  "id" : 728543013845225472,
  "created_at" : "2016-05-06 11:12:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sebasti\u00E1n P. Saaibi",
      "screen_name" : "spsaaibi",
      "indices" : [ 0, 9 ],
      "id_str" : "377439160",
      "id" : 377439160
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "728500878630621184",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35927991820115, 8.588207908133219 ]
  },
  "id_str" : "728540076549013508",
  "in_reply_to_user_id" : 377439160,
  "text" : "@spsaaibi thanks, hadn\u2019t given it a try so far!",
  "id" : 728540076549013508,
  "in_reply_to_status_id" : 728500878630621184,
  "created_at" : "2016-05-06 11:01:04 +0000",
  "in_reply_to_screen_name" : "spsaaibi",
  "in_reply_to_user_id_str" : "377439160",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul-Olivier Dehaye",
      "screen_name" : "podehaye",
      "indices" : [ 0, 9 ],
      "id_str" : "2219841242",
      "id" : 2219841242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "728373809481293824",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35922581214474, 8.587832275906706 ]
  },
  "id_str" : "728498188483743745",
  "in_reply_to_user_id" : 2219841242,
  "text" : "@podehaye thanks, will give it a read :)",
  "id" : 728498188483743745,
  "in_reply_to_status_id" : 728373809481293824,
  "created_at" : "2016-05-06 08:14:37 +0000",
  "in_reply_to_screen_name" : "podehaye",
  "in_reply_to_user_id_str" : "2219841242",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35919804875216, 8.587689094081387 ]
  },
  "id_str" : "728251025619095553",
  "text" : "\u00ABSo, what podcasts did you listen and cry to on your way here?\u00BB",
  "id" : 728251025619095553,
  "created_at" : "2016-05-05 15:52:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "csvconf",
      "indices" : [ 24, 32 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "728140193748819968",
  "text" : "I wish I\u2019d have been at #csvconf, then maybe I\u2019d know what\u2019s the easiest way to get Surveymonkey data into R.",
  "id" : 728140193748819968,
  "created_at" : "2016-05-05 08:32:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/dPFIZnYG3u",
      "expanded_url" : "http:\/\/www.wired.com\/2012\/01\/ban-check-engine-lights\/",
      "display_url" : "wired.com\/2012\/01\/ban-ch\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.86284, 8.784878 ]
  },
  "id_str" : "727899672405282817",
  "text" : "Should tape this onto my dashboard as the light erratically decides to go on\/off. https:\/\/t.co\/dPFIZnYG3u",
  "id" : 727899672405282817,
  "created_at" : "2016-05-04 16:36:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "727872663767617536",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.91926124696519, 8.73127179221132 ]
  },
  "id_str" : "727872949026459648",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich but that\u2019s true for everyone getting a phd.",
  "id" : 727872949026459648,
  "in_reply_to_status_id" : 727872663767617536,
  "created_at" : "2016-05-04 14:50:08 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "727870957218635776",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.9150747377881, 8.713276181378134 ]
  },
  "id_str" : "727871752857133056",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot you wish. (And me too!)",
  "id" : 727871752857133056,
  "in_reply_to_status_id" : 727870957218635776,
  "created_at" : "2016-05-04 14:45:23 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.16666906890475, 8.60834137537387 ]
  },
  "id_str" : "727848607089577985",
  "text" : "Being able to change into more comfortable shoes while driving a a car w\/o cruise control on a highway is a marketable skill, right?",
  "id" : 727848607089577985,
  "created_at" : "2016-05-04 13:13:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 68 ],
      "url" : "https:\/\/t.co\/zLeNeshGzb",
      "expanded_url" : "https:\/\/twitter.com\/tkb\/status\/727839722312241152",
      "display_url" : "twitter.com\/tkb\/status\/727\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "727840334437330945",
  "text" : "The effects of doing research in a nutshell. https:\/\/t.co\/zLeNeshGzb",
  "id" : 727840334437330945,
  "created_at" : "2016-05-04 12:40:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 92 ],
      "url" : "https:\/\/t.co\/uhx8OQIh7R",
      "expanded_url" : "https:\/\/media.giphy.com\/media\/NgAwN6H2GAAms\/giphy.gif",
      "display_url" : "media.giphy.com\/media\/NgAwN6H2\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "727770348620533764",
  "geo" : { },
  "id_str" : "727819070133907457",
  "in_reply_to_user_id" : 14286491,
  "text" : "So I was called a data hoarder today. I prefer the term \u201Ecollector\u201C. https:\/\/t.co\/uhx8OQIh7R",
  "id" : 727819070133907457,
  "in_reply_to_status_id" : 727770348620533764,
  "created_at" : "2016-05-04 11:16:03 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/fPMa2QamFp",
      "expanded_url" : "https:\/\/twitter.com\/auremoser\/status\/727785653912604673",
      "display_url" : "twitter.com\/auremoser\/stat\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17248679021652, 8.6275373967315 ]
  },
  "id_str" : "727793579121360896",
  "text" : "Dogs being shamed for their spreadsheets. It\u2019s so specifically targeted to my fetishes! https:\/\/t.co\/fPMa2QamFp",
  "id" : 727793579121360896,
  "created_at" : "2016-05-04 09:34:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karthik Ram",
      "screen_name" : "_inundata",
      "indices" : [ 3, 13 ],
      "id_str" : "267256091",
      "id" : 267256091
    }, {
      "name" : "Jenny Bryan",
      "screen_name" : "JennyBryan",
      "indices" : [ 27, 38 ],
      "id_str" : "2167059661",
      "id" : 2167059661
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "csvconf",
      "indices" : [ 41, 49 ]
    } ],
    "urls" : [ {
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/YbXg1OjMSc",
      "expanded_url" : "https:\/\/github.com\/jennybc\/2016-05_csvconf-spreadsheets",
      "display_url" : "github.com\/jennybc\/2016-0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "727783031507984384",
  "text" : "RT @_inundata: Slides from @JennyBryan\u2019s #csvconf keynote this morning.\n\nhttps:\/\/t.co\/YbXg1OjMSc",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jenny Bryan",
        "screen_name" : "JennyBryan",
        "indices" : [ 12, 23 ],
        "id_str" : "2167059661",
        "id" : 2167059661
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "csvconf",
        "indices" : [ 26, 34 ]
      } ],
      "urls" : [ {
        "indices" : [ 58, 81 ],
        "url" : "https:\/\/t.co\/YbXg1OjMSc",
        "expanded_url" : "https:\/\/github.com\/jennybc\/2016-05_csvconf-spreadsheets",
        "display_url" : "github.com\/jennybc\/2016-0\u2026"
      } ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 52.52411765209057, 13.38955064279095 ]
    },
    "id_str" : "727780017959227392",
    "text" : "Slides from @JennyBryan\u2019s #csvconf keynote this morning.\n\nhttps:\/\/t.co\/YbXg1OjMSc",
    "id" : 727780017959227392,
    "created_at" : "2016-05-04 08:40:52 +0000",
    "user" : {
      "name" : "Karthik Ram",
      "screen_name" : "_inundata",
      "protected" : false,
      "id_str" : "267256091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/520412914046345216\/Kwa3J7yn_normal.jpeg",
      "id" : 267256091,
      "verified" : false
    }
  },
  "id" : 727783031507984384,
  "created_at" : "2016-05-04 08:52:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Blin",
      "screen_name" : "kaiblin",
      "indices" : [ 0, 8 ],
      "id_str" : "124202458",
      "id" : 124202458
    }, {
      "name" : "Jason Stajich",
      "screen_name" : "hyphaltip",
      "indices" : [ 9, 19 ],
      "id_str" : "14324284",
      "id" : 14324284
    }, {
      "name" : "Karyn MeltzSteinberg",
      "screen_name" : "KMS_Meltzy",
      "indices" : [ 20, 31 ],
      "id_str" : "1425644274",
      "id" : 1425644274
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "727735387469316096",
  "geo" : { },
  "id_str" : "727777791551377409",
  "in_reply_to_user_id" : 124202458,
  "text" : "@kaiblin @hyphaltip @KMS_Meltzy More like \u201Eanalyses were performed using Eppendorf\u2122 pipettes, using custom buffers and chemicals\u201C. \uD83D\uDE22",
  "id" : 727777791551377409,
  "in_reply_to_status_id" : 727735387469316096,
  "created_at" : "2016-05-04 08:32:01 +0000",
  "in_reply_to_screen_name" : "kaiblin",
  "in_reply_to_user_id_str" : "124202458",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/VCZyE2tNqo",
      "expanded_url" : "http:\/\/andrewgelman.com\/2016\/05\/03\/im-all-out-of-clever\/",
      "display_url" : "andrewgelman.com\/2016\/05\/03\/im-\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "727776824013541376",
  "geo" : { },
  "id_str" : "727777411664842752",
  "in_reply_to_user_id" : 14286491,
  "text" : "And read the follow up: \u00ABKnowledgeable reporters don\u2019t waste their time on this, leaving the suckers to write it up\u00BB https:\/\/t.co\/VCZyE2tNqo",
  "id" : 727777411664842752,
  "in_reply_to_status_id" : 727776824013541376,
  "created_at" : "2016-05-04 08:30:31 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/yXcAPywl4O",
      "expanded_url" : "http:\/\/andrewgelman.com\/2016\/05\/03\/ahhhh-ppnas\/",
      "display_url" : "andrewgelman.com\/2016\/05\/03\/ahh\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "727776824013541376",
  "text" : "Read the story about air-rage being induced by the presence of a first class? Think again. https:\/\/t.co\/yXcAPywl4O",
  "id" : 727776824013541376,
  "created_at" : "2016-05-04 08:28:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Chin",
      "screen_name" : "infoecho",
      "indices" : [ 0, 9 ],
      "id_str" : "29575969",
      "id" : 29575969
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "727725908250001413",
  "geo" : { },
  "id_str" : "727773682806992896",
  "in_reply_to_user_id" : 29575969,
  "text" : "@infoecho see you there!",
  "id" : 727773682806992896,
  "in_reply_to_status_id" : 727725908250001413,
  "created_at" : "2016-05-04 08:15:42 +0000",
  "in_reply_to_screen_name" : "infoecho",
  "in_reply_to_user_id_str" : "29575969",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Davide Giacalone",
      "screen_name" : "Davide_Giac",
      "indices" : [ 0, 12 ],
      "id_str" : "3503131779",
      "id" : 3503131779
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "727747723533950978",
  "geo" : { },
  "id_str" : "727770714363838469",
  "in_reply_to_user_id" : 3503131779,
  "text" : "@Davide_Giac thanks!",
  "id" : 727770714363838469,
  "in_reply_to_status_id" : 727747723533950978,
  "created_at" : "2016-05-04 08:03:54 +0000",
  "in_reply_to_screen_name" : "Davide_Giac",
  "in_reply_to_user_id_str" : "3503131779",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "727770348620533764",
  "text" : "(\u256F\u00B0\u25A1\u00B0\uFF09\u256F\uFE35p\u01DDp\u01DD\u01DD\u0254x\u01DD \u0250\u0287onb \u029Es\u0131\u0323p",
  "id" : 727770348620533764,
  "created_at" : "2016-05-04 08:02:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robin Champieux",
      "screen_name" : "rchampieux",
      "indices" : [ 0, 11 ],
      "id_str" : "20653310",
      "id" : 20653310
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "force2016",
      "indices" : [ 33, 43 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/FzEbpI8fd7",
      "expanded_url" : "http:\/\/ruleofthirds.de\/analyzing-scihub-data\/",
      "display_url" : "ruleofthirds.de\/analyzing-scih\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "727632582678970368",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11400664125092, 8.753481437504805 ]
  },
  "id_str" : "727632909876736000",
  "in_reply_to_user_id" : 20653310,
  "text" : "@rchampieux oh, thanks! Going to #force2016 definitely made me motivated to try https:\/\/t.co\/FzEbpI8fd7 :)",
  "id" : 727632909876736000,
  "in_reply_to_status_id" : 727632582678970368,
  "created_at" : "2016-05-03 22:56:19 +0000",
  "in_reply_to_screen_name" : "rchampieux",
  "in_reply_to_user_id_str" : "20653310",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Denker",
      "screen_name" : "Phaidr0s",
      "indices" : [ 0, 9 ],
      "id_str" : "40466433",
      "id" : 40466433
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "727592614950801408",
  "geo" : { },
  "id_str" : "727594777336745984",
  "in_reply_to_user_id" : 40466433,
  "text" : "@Phaidr0s dann hoffe ich mal dass das hete nicht auf mich bezogen war \uD83D\uDE1B",
  "id" : 727594777336745984,
  "in_reply_to_status_id" : 727592614950801408,
  "created_at" : "2016-05-03 20:24:47 +0000",
  "in_reply_to_screen_name" : "Phaidr0s",
  "in_reply_to_user_id_str" : "40466433",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Denker",
      "screen_name" : "Phaidr0s",
      "indices" : [ 0, 9 ],
      "id_str" : "40466433",
      "id" : 40466433
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "727592145885007881",
  "geo" : { },
  "id_str" : "727592190592098305",
  "in_reply_to_user_id" : 40466433,
  "text" : "@Phaidr0s oh, wow!",
  "id" : 727592190592098305,
  "in_reply_to_status_id" : 727592145885007881,
  "created_at" : "2016-05-03 20:14:30 +0000",
  "in_reply_to_screen_name" : "Phaidr0s",
  "in_reply_to_user_id_str" : "40466433",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Denker",
      "screen_name" : "Phaidr0s",
      "indices" : [ 0, 9 ],
      "id_str" : "40466433",
      "id" : 40466433
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "727591571353407490",
  "geo" : { },
  "id_str" : "727591928510992384",
  "in_reply_to_user_id" : 40466433,
  "text" : "@Phaidr0s was mich dran erinnert hat deine Freundschaftsanfrage noch zu beantworten \uD83D\uDE02",
  "id" : 727591928510992384,
  "in_reply_to_status_id" : 727591571353407490,
  "created_at" : "2016-05-03 20:13:28 +0000",
  "in_reply_to_screen_name" : "Phaidr0s",
  "in_reply_to_user_id_str" : "40466433",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Denker",
      "screen_name" : "Phaidr0s",
      "indices" : [ 0, 9 ],
      "id_str" : "40466433",
      "id" : 40466433
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "727590796136943616",
  "geo" : { },
  "id_str" : "727591230687870977",
  "in_reply_to_user_id" : 40466433,
  "text" : "@Phaidr0s ich weiss auch nicht wie man bei dir auf die Idee kommen k\u00F6nnte \uD83D\uDE07",
  "id" : 727591230687870977,
  "in_reply_to_status_id" : 727590796136943616,
  "created_at" : "2016-05-03 20:10:42 +0000",
  "in_reply_to_screen_name" : "Phaidr0s",
  "in_reply_to_user_id_str" : "40466433",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 76 ],
      "url" : "https:\/\/t.co\/ICzqIycbTY",
      "expanded_url" : "https:\/\/twitter.com\/bella_velo\/status\/727565683828129794",
      "display_url" : "twitter.com\/bella_velo\/sta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "727581982826364929",
  "text" : "I want my AirBnB, but for rooms filled with puppies. https:\/\/t.co\/ICzqIycbTY",
  "id" : 727581982826364929,
  "created_at" : "2016-05-03 19:33:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 86 ],
      "url" : "https:\/\/t.co\/2q6Xty9tHL",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=o5E7cG54VoA",
      "display_url" : "youtube.com\/watch?v=o5E7cG\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "727559327725326336",
  "text" : "\u00ABthe internet no longer screams in agony as you dial into it\u2026\u00BB https:\/\/t.co\/2q6Xty9tHL",
  "id" : 727559327725326336,
  "created_at" : "2016-05-03 18:03:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tariq Khokhar",
      "screen_name" : "tkb",
      "indices" : [ 0, 4 ],
      "id_str" : "793517",
      "id" : 793517
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "727530537137623040",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11399819939398, 8.753478847057977 ]
  },
  "id_str" : "727535675558494208",
  "in_reply_to_user_id" : 793517,
  "text" : "@tkb yes, taught a BYOD intro to Python last year and had the very same experience w\/ the Windows machines.",
  "id" : 727535675558494208,
  "in_reply_to_status_id" : 727530537137623040,
  "created_at" : "2016-05-03 16:29:56 +0000",
  "in_reply_to_screen_name" : "tkb",
  "in_reply_to_user_id_str" : "793517",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tariq Khokhar",
      "screen_name" : "tkb",
      "indices" : [ 0, 4 ],
      "id_str" : "793517",
      "id" : 793517
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "727528614997139456",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17233071118535, 8.627616543736584 ]
  },
  "id_str" : "727529198571626496",
  "in_reply_to_user_id" : 793517,
  "text" : "@tkb step 1) cry",
  "id" : 727529198571626496,
  "in_reply_to_status_id" : 727528614997139456,
  "created_at" : "2016-05-03 16:04:12 +0000",
  "in_reply_to_screen_name" : "tkb",
  "in_reply_to_user_id_str" : "793517",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u24EA Chris Hartgerink",
      "screen_name" : "chartgerink",
      "indices" : [ 0, 12 ],
      "id_str" : "439273539",
      "id" : 439273539
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "727521607321800704",
  "geo" : { },
  "id_str" : "727523742864269312",
  "in_reply_to_user_id" : 439273539,
  "text" : "@chartgerink thanks! Just edited the R-code and the added the WB data used for it to the repo as well. :)",
  "id" : 727523742864269312,
  "in_reply_to_status_id" : 727521607321800704,
  "created_at" : "2016-05-03 15:42:31 +0000",
  "in_reply_to_screen_name" : "chartgerink",
  "in_reply_to_user_id_str" : "439273539",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SciHub",
      "indices" : [ 28, 35 ]
    } ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/7VGLQTr5aJ",
      "expanded_url" : "https:\/\/github.com\/gedankenstuecke\/scihub_analysis\/issues\/5",
      "display_url" : "github.com\/gedankenstueck\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "727520016816574464",
  "text" : "Fun to see the issues on my #SciHub analysis grow. Tried to fulfill a first request for an additional analysis. https:\/\/t.co\/7VGLQTr5aJ",
  "id" : 727520016816574464,
  "created_at" : "2016-05-03 15:27:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Akshat Rathi",
      "screen_name" : "AkshatRathi",
      "indices" : [ 0, 12 ],
      "id_str" : "13766492",
      "id" : 13766492
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "727502225224962048",
  "geo" : { },
  "id_str" : "727503039804899328",
  "in_reply_to_user_id" : 13766492,
  "text" : "@AkshatRathi oh, thanks! :)",
  "id" : 727503039804899328,
  "in_reply_to_status_id" : 727502225224962048,
  "created_at" : "2016-05-03 14:20:15 +0000",
  "in_reply_to_screen_name" : "AkshatRathi",
  "in_reply_to_user_id_str" : "13766492",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thomas Charlon",
      "screen_name" : "ThChln",
      "indices" : [ 0, 7 ],
      "id_str" : "1099253149",
      "id" : 1099253149
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "727493433787596804",
  "geo" : { },
  "id_str" : "727494735628275713",
  "in_reply_to_user_id" : 1099253149,
  "text" : "@ThChln all from Nanjing, requested within seconds from each other over a long time. Looks like an error on client or server-side.",
  "id" : 727494735628275713,
  "in_reply_to_status_id" : 727493433787596804,
  "created_at" : "2016-05-03 13:47:15 +0000",
  "in_reply_to_screen_name" : "ThChln",
  "in_reply_to_user_id_str" : "1099253149",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thomas Charlon",
      "screen_name" : "ThChln",
      "indices" : [ 0, 7 ],
      "id_str" : "1099253149",
      "id" : 1099253149
    }, {
      "name" : "Dryad",
      "screen_name" : "datadryad",
      "indices" : [ 8, 18 ],
      "id_str" : "93950513",
      "id" : 93950513
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "727489938934108160",
  "geo" : { },
  "id_str" : "727490589030240256",
  "in_reply_to_user_id" : 1099253149,
  "text" : "@ThChln @datadryad thx, what\u2019s the DOI of that one?",
  "id" : 727490589030240256,
  "in_reply_to_status_id" : 727489938934108160,
  "created_at" : "2016-05-03 13:30:47 +0000",
  "in_reply_to_screen_name" : "ThChln",
  "in_reply_to_user_id_str" : "1099253149",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 81 ],
      "url" : "https:\/\/t.co\/Qt8nozSHB4",
      "expanded_url" : "https:\/\/twitter.com\/brembs\/status\/727485425615552517",
      "display_url" : "twitter.com\/brembs\/status\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "727486040399863808",
  "text" : "Would mean the instant success for all pre-print servers. https:\/\/t.co\/Qt8nozSHB4",
  "id" : 727486040399863808,
  "created_at" : "2016-05-03 13:12:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bi\u24D0nca Kramer",
      "screen_name" : "MsPhelps",
      "indices" : [ 0, 9 ],
      "id_str" : "22963112",
      "id" : 22963112
    }, {
      "name" : "Jeroen Bosman",
      "screen_name" : "jeroenbosman",
      "indices" : [ 10, 23 ],
      "id_str" : "9104202",
      "id" : 9104202
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "727479068036222977",
  "geo" : { },
  "id_str" : "727480853652230153",
  "in_reply_to_user_id" : 22963112,
  "text" : "@MsPhelps @jeroenbosman that\u2019s a great idea! openSNP is participating in it too! :)",
  "id" : 727480853652230153,
  "in_reply_to_status_id" : 727479068036222977,
  "created_at" : "2016-05-03 12:52:06 +0000",
  "in_reply_to_screen_name" : "MsPhelps",
  "in_reply_to_user_id_str" : "22963112",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bi\u24D0nca Kramer",
      "screen_name" : "MsPhelps",
      "indices" : [ 0, 9 ],
      "id_str" : "22963112",
      "id" : 22963112
    }, {
      "name" : "Sci Hub",
      "screen_name" : "Sci_Hub",
      "indices" : [ 10, 18 ],
      "id_str" : "381187236",
      "id" : 381187236
    }, {
      "name" : "Jeroen Bosman",
      "screen_name" : "jeroenbosman",
      "indices" : [ 19, 32 ],
      "id_str" : "9104202",
      "id" : 9104202
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "727476516163059712",
  "geo" : { },
  "id_str" : "727476948776194050",
  "in_reply_to_user_id" : 22963112,
  "text" : "@MsPhelps @Sci_Hub @jeroenbosman I know, I should dig into your data next. ;)",
  "id" : 727476948776194050,
  "in_reply_to_status_id" : 727476516163059712,
  "created_at" : "2016-05-03 12:36:35 +0000",
  "in_reply_to_screen_name" : "MsPhelps",
  "in_reply_to_user_id_str" : "22963112",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bi\u24D0nca Kramer",
      "screen_name" : "MsPhelps",
      "indices" : [ 0, 9 ],
      "id_str" : "22963112",
      "id" : 22963112
    }, {
      "name" : "Sci Hub",
      "screen_name" : "Sci_Hub",
      "indices" : [ 112, 120 ],
      "id_str" : "381187236",
      "id" : 381187236
    }, {
      "name" : "Jeroen Bosman",
      "screen_name" : "jeroenbosman",
      "indices" : [ 124, 137 ],
      "id_str" : "9104202",
      "id" : 9104202
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "727464067632365568",
  "geo" : { },
  "id_str" : "727465236119322624",
  "in_reply_to_user_id" : 22963112,
  "text" : "@MsPhelps I see, the numbers are rather small in general, otherwise one could correlate to the data provided by @sci_hub :) @jeroenbosman",
  "id" : 727465236119322624,
  "in_reply_to_status_id" : 727464067632365568,
  "created_at" : "2016-05-03 11:50:02 +0000",
  "in_reply_to_screen_name" : "MsPhelps",
  "in_reply_to_user_id_str" : "22963112",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeroen Bosman",
      "screen_name" : "jeroenbosman",
      "indices" : [ 0, 13 ],
      "id_str" : "9104202",
      "id" : 9104202
    }, {
      "name" : "Sci Hub",
      "screen_name" : "Sci_Hub",
      "indices" : [ 14, 22 ],
      "id_str" : "381187236",
      "id" : 381187236
    }, {
      "name" : "Bi\u24D0nca Kramer",
      "screen_name" : "MsPhelps",
      "indices" : [ 23, 32 ],
      "id_str" : "22963112",
      "id" : 22963112
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "727458622930825216",
  "geo" : { },
  "id_str" : "727459277321949184",
  "in_reply_to_user_id" : 9104202,
  "text" : "@jeroenbosman @Sci_Hub @MsPhelps that\u2019s interesting, wonder whether there\u2019s a systematic reason for it.",
  "id" : 727459277321949184,
  "in_reply_to_status_id" : 727458622930825216,
  "created_at" : "2016-05-03 11:26:21 +0000",
  "in_reply_to_screen_name" : "jeroenbosman",
  "in_reply_to_user_id_str" : "9104202",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeroen Bosman",
      "screen_name" : "jeroenbosman",
      "indices" : [ 0, 13 ],
      "id_str" : "9104202",
      "id" : 9104202
    }, {
      "name" : "Sci Hub",
      "screen_name" : "Sci_Hub",
      "indices" : [ 14, 22 ],
      "id_str" : "381187236",
      "id" : 381187236
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "727456210170056704",
  "geo" : { },
  "id_str" : "727456507177086976",
  "in_reply_to_user_id" : 9104202,
  "text" : "@jeroenbosman @Sci_Hub yes, exactly! At least for the outliers, where countries like Iran &amp; Greece intuitively make sense.",
  "id" : 727456507177086976,
  "in_reply_to_status_id" : 727456210170056704,
  "created_at" : "2016-05-03 11:15:21 +0000",
  "in_reply_to_screen_name" : "jeroenbosman",
  "in_reply_to_user_id_str" : "9104202",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 3, 16 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/SrFfkXgApW",
      "expanded_url" : "https:\/\/github.com\/gedankenstuecke\/scihub_analysis\/issues\/4",
      "display_url" : "github.com\/gedankenstueck\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "727452905071108096",
  "text" : "RT @PhilippBayer: Surprisingly, there are a few thousand Open Access papers in the SciHub data https:\/\/t.co\/SrFfkXgApW",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 77, 100 ],
        "url" : "https:\/\/t.co\/SrFfkXgApW",
        "expanded_url" : "https:\/\/github.com\/gedankenstuecke\/scihub_analysis\/issues\/4",
        "display_url" : "github.com\/gedankenstueck\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "727451427103068160",
    "text" : "Surprisingly, there are a few thousand Open Access papers in the SciHub data https:\/\/t.co\/SrFfkXgApW",
    "id" : 727451427103068160,
    "created_at" : "2016-05-03 10:55:10 +0000",
    "user" : {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "protected" : false,
      "id_str" : "121777206",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2013711027\/IMG_1088_normal.png",
      "id" : 121777206,
      "verified" : false
    }
  },
  "id" : 727452905071108096,
  "created_at" : "2016-05-03 11:01:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeroen Bosman",
      "screen_name" : "jeroenbosman",
      "indices" : [ 0, 13 ],
      "id_str" : "9104202",
      "id" : 9104202
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/727410817822527488\/photo\/1",
      "indices" : [ 64, 87 ],
      "url" : "https:\/\/t.co\/JiD4XEErmj",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ChhISGRXEAE8xJR.png",
      "id_str" : "727410815578607617",
      "id" : 727410815578607617,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ChhISGRXEAE8xJR.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 777,
        "resize" : "fit",
        "w" : 1398
      }, {
        "h" : 777,
        "resize" : "fit",
        "w" : 1398
      }, {
        "h" : 667,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 378,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/JiD4XEErmj"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "727235428798070784",
  "geo" : { },
  "id_str" : "727410817822527488",
  "in_reply_to_user_id" : 9104202,
  "text" : "@jeroenbosman here\u2019s the distribution of Downloads \/ Pop \/ GDP. https:\/\/t.co\/JiD4XEErmj",
  "id" : 727410817822527488,
  "in_reply_to_status_id" : 727235428798070784,
  "created_at" : "2016-05-03 08:13:48 +0000",
  "in_reply_to_screen_name" : "jeroenbosman",
  "in_reply_to_user_id_str" : "9104202",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robby Kraft",
      "screen_name" : "RobbyKraft",
      "indices" : [ 3, 14 ],
      "id_str" : "56188333",
      "id" : 56188333
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "727409584940421124",
  "text" : "RT @RobbyKraft: scientist: \"does everyone here know what Watson and Crick discovered?\"\nme from back of room: \"Rosalind Franklin's notes\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "727352740825944064",
    "text" : "scientist: \"does everyone here know what Watson and Crick discovered?\"\nme from back of room: \"Rosalind Franklin's notes\"",
    "id" : 727352740825944064,
    "created_at" : "2016-05-03 04:23:01 +0000",
    "user" : {
      "name" : "Robby Kraft",
      "screen_name" : "RobbyKraft",
      "protected" : false,
      "id_str" : "56188333",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1154921447\/Photo_on_2010-10-18_at_01.50__2_normal.jpg",
      "id" : 56188333,
      "verified" : false
    }
  },
  "id" : 727409584940421124,
  "created_at" : "2016-05-03 08:08:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helena",
      "screen_name" : "Helena_LB",
      "indices" : [ 0, 10 ],
      "id_str" : "234309722",
      "id" : 234309722
    }, {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 11, 25 ],
      "id_str" : "352650591",
      "id" : 352650591
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 26, 39 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "\u24EA Rik Smith-Unna \uD83C\uDDF0\uD83C\uDDEA",
      "screen_name" : "blahah404",
      "indices" : [ 40, 50 ],
      "id_str" : "99173786",
      "id" : 99173786
    }, {
      "name" : "Bj\u00F6rn Brembs",
      "screen_name" : "brembs",
      "indices" : [ 51, 58 ],
      "id_str" : "47876842",
      "id" : 47876842
    }, {
      "name" : "John Dupuis",
      "screen_name" : "dupuisj",
      "indices" : [ 59, 67 ],
      "id_str" : "18223968",
      "id" : 18223968
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "727397328420765696",
  "geo" : { },
  "id_str" : "727399228155269120",
  "in_reply_to_user_id" : 234309722,
  "text" : "@Helena_LB @Protohedgehog @PhilippBayer @blahah404 @brembs @dupuisj you know Metallica is out due to their stance on copyright, right? ;)",
  "id" : 727399228155269120,
  "in_reply_to_status_id" : 727397328420765696,
  "created_at" : "2016-05-03 07:27:45 +0000",
  "in_reply_to_screen_name" : "Helena_LB",
  "in_reply_to_user_id_str" : "234309722",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 0, 14 ],
      "id_str" : "352650591",
      "id" : 352650591
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 15, 28 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "\u24EA Rik Smith-Unna \uD83C\uDDF0\uD83C\uDDEA",
      "screen_name" : "blahah404",
      "indices" : [ 29, 39 ],
      "id_str" : "99173786",
      "id" : 99173786
    }, {
      "name" : "Bj\u00F6rn Brembs",
      "screen_name" : "brembs",
      "indices" : [ 40, 47 ],
      "id_str" : "47876842",
      "id" : 47876842
    }, {
      "name" : "John Dupuis",
      "screen_name" : "dupuisj",
      "indices" : [ 48, 56 ],
      "id_str" : "18223968",
      "id" : 18223968
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "727389699959087104",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.15960643538288, 8.690539598473059 ]
  },
  "id_str" : "727393945257435136",
  "in_reply_to_user_id" : 352650591,
  "text" : "@Protohedgehog @PhilippBayer @blahah404 @brembs @dupuisj does this mean we will have to do some kind of Band Aid thing soon?",
  "id" : 727393945257435136,
  "in_reply_to_status_id" : 727389699959087104,
  "created_at" : "2016-05-03 07:06:45 +0000",
  "in_reply_to_screen_name" : "Protohedgehog",
  "in_reply_to_user_id_str" : "352650591",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/6Ngbtc1Xcy",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/727383989028306944",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "727383989028306944",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11401783268858, 8.753452342070668 ]
  },
  "id_str" : "727388480599416833",
  "in_reply_to_user_id" : 14286491,
  "text" : "Also: can we please re-sort this to CSN publications and experts will even have CSNY publications? https:\/\/t.co\/6Ngbtc1Xcy",
  "id" : 727388480599416833,
  "in_reply_to_status_id" : 727383989028306944,
  "created_at" : "2016-05-03 06:45:02 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "727352384033312770",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11401057393824, 8.75344223814737 ]
  },
  "id_str" : "727383989028306944",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer that goes on the CV as a CNS publication :p",
  "id" : 727383989028306944,
  "in_reply_to_status_id" : 727352384033312770,
  "created_at" : "2016-05-03 06:27:11 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeroen Bosman",
      "screen_name" : "jeroenbosman",
      "indices" : [ 0, 13 ],
      "id_str" : "9104202",
      "id" : 9104202
    }, {
      "name" : "Dryad",
      "screen_name" : "datadryad",
      "indices" : [ 14, 24 ],
      "id_str" : "93950513",
      "id" : 93950513
    }, {
      "name" : "World Bank Data",
      "screen_name" : "worldbankdata",
      "indices" : [ 25, 39 ],
      "id_str" : "203332110",
      "id" : 203332110
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "727235428798070784",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.96589386957005, 7.009026455637239 ]
  },
  "id_str" : "727236114839379969",
  "in_reply_to_user_id" : 9104202,
  "text" : "@jeroenbosman @datadryad @worldbankdata let me check that tomorrow when I\u2019m home :)",
  "id" : 727236114839379969,
  "in_reply_to_status_id" : 727235428798070784,
  "created_at" : "2016-05-02 20:39:35 +0000",
  "in_reply_to_screen_name" : "jeroenbosman",
  "in_reply_to_user_id_str" : "9104202",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 71 ],
      "url" : "https:\/\/t.co\/2oqR6YS9vJ",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/726900343553048576",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "726900343553048576",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.96942815929843, 7.016798037198406 ]
  },
  "id_str" : "727228586525114371",
  "in_reply_to_user_id" : 14286491,
  "text" : "Accidentally on the front page of Hacker News \uD83D\uDE02 https:\/\/t.co\/2oqR6YS9vJ",
  "id" : 727228586525114371,
  "in_reply_to_status_id" : 726900343553048576,
  "created_at" : "2016-05-02 20:09:40 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lambert Heller \uD83E\uDD14",
      "screen_name" : "Lambo",
      "indices" : [ 0, 6 ],
      "id_str" : "284553",
      "id" : 284553
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "727160733885190145",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11359802753194, 8.753743319166944 ]
  },
  "id_str" : "727163869966249985",
  "in_reply_to_user_id" : 284553,
  "text" : "@Lambo thanks! :)",
  "id" : 727163869966249985,
  "in_reply_to_status_id" : 727160733885190145,
  "created_at" : "2016-05-02 15:52:31 +0000",
  "in_reply_to_screen_name" : "Lambo",
  "in_reply_to_user_id_str" : "284553",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SciHub",
      "indices" : [ 107, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/2oqR6YS9vJ",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/726900343553048576",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "726900343553048576",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11363152568927, 8.753878390776316 ]
  },
  "id_str" : "727151595700535296",
  "in_reply_to_user_id" : 14286491,
  "text" : "ICYMI: what are good predictors for how much Sci-Hub will be used to access literature in a given country? #SciHub https:\/\/t.co\/2oqR6YS9vJ",
  "id" : 727151595700535296,
  "in_reply_to_status_id" : 726900343553048576,
  "created_at" : "2016-05-02 15:03:44 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/iAs64B7PRX",
      "expanded_url" : "http:\/\/www.vox.com\/2016\/5\/2\/11520288\/pilot-airplane-photos",
      "display_url" : "vox.com\/2016\/5\/2\/11520\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "727121954717708289",
  "text" : "\u00ABEverywhere is going on at once\u00BB The things you learn by flying 747s for a living. https:\/\/t.co\/iAs64B7PRX",
  "id" : 727121954717708289,
  "created_at" : "2016-05-02 13:05:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "727055988445028352",
  "geo" : { },
  "id_str" : "727056196226695169",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot Alpaka-Hoodie + DNA-Tie. Mein Outfit f\u00FCr die Verteidigung steht.",
  "id" : 727056196226695169,
  "in_reply_to_status_id" : 727055988445028352,
  "created_at" : "2016-05-02 08:44:39 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "727053866265645056",
  "geo" : { },
  "id_str" : "727054199486316544",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot Bestellst du mir eins mit? \uD83D\uDE0D",
  "id" : 727054199486316544,
  "in_reply_to_status_id" : 727053866265645056,
  "created_at" : "2016-05-02 08:36:43 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Heather L. Wiencko",
      "screen_name" : "HLWiencko",
      "indices" : [ 0, 10 ],
      "id_str" : "2657942712",
      "id" : 2657942712
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "727050562903130112",
  "geo" : { },
  "id_str" : "727051455891410944",
  "in_reply_to_user_id" : 2657942712,
  "text" : "@HLWiencko and I largely missed out on both series. Maybe that\u2019s why the human experience surprises me that often!",
  "id" : 727051455891410944,
  "in_reply_to_status_id" : 727050562903130112,
  "created_at" : "2016-05-02 08:25:49 +0000",
  "in_reply_to_screen_name" : "HLWiencko",
  "in_reply_to_user_id_str" : "2657942712",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 88 ],
      "url" : "https:\/\/t.co\/oTN5stbSNC",
      "expanded_url" : "https:\/\/twitter.com\/MalvikaSharan\/status\/727049383821336576",
      "display_url" : "twitter.com\/MalvikaSharan\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "727049935154208768",
  "text" : "I didn\u2019t even know there was precedence in pop culture for that! https:\/\/t.co\/oTN5stbSNC",
  "id" : 727049935154208768,
  "created_at" : "2016-05-02 08:19:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u24EA Chris Hartgerink",
      "screen_name" : "chartgerink",
      "indices" : [ 0, 12 ],
      "id_str" : "439273539",
      "id" : 439273539
    }, {
      "name" : "Dryad",
      "screen_name" : "datadryad",
      "indices" : [ 13, 23 ],
      "id_str" : "93950513",
      "id" : 93950513
    }, {
      "name" : "World Bank Data",
      "screen_name" : "worldbankdata",
      "indices" : [ 24, 38 ],
      "id_str" : "203332110",
      "id" : 203332110
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/727037694514176000\/photo\/1",
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/xr835Z4wTz",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Chb07dBU0AEqRNM.png",
      "id_str" : "727037692106559489",
      "id" : 727037692106559489,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Chb07dBU0AEqRNM.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 777,
        "resize" : "fit",
        "w" : 1398
      }, {
        "h" : 777,
        "resize" : "fit",
        "w" : 1398
      }, {
        "h" : 667,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 378,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/xr835Z4wTz"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "727034830370779136",
  "geo" : { },
  "id_str" : "727037694514176000",
  "in_reply_to_user_id" : 439273539,
  "text" : "@chartgerink @datadryad @worldbankdata and here\u2019s correlating GDP w\/ downloads per 1000 capita who have internet. https:\/\/t.co\/xr835Z4wTz",
  "id" : 727037694514176000,
  "in_reply_to_status_id" : 727034830370779136,
  "created_at" : "2016-05-02 07:31:08 +0000",
  "in_reply_to_screen_name" : "chartgerink",
  "in_reply_to_user_id_str" : "439273539",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u24EA Chris Hartgerink",
      "screen_name" : "chartgerink",
      "indices" : [ 0, 12 ],
      "id_str" : "439273539",
      "id" : 439273539
    }, {
      "name" : "Dryad",
      "screen_name" : "datadryad",
      "indices" : [ 13, 23 ],
      "id_str" : "93950513",
      "id" : 93950513
    }, {
      "name" : "World Bank Data",
      "screen_name" : "worldbankdata",
      "indices" : [ 24, 38 ],
      "id_str" : "203332110",
      "id" : 203332110
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "727034830370779136",
  "geo" : { },
  "id_str" : "727037580240404482",
  "in_reply_to_user_id" : 439273539,
  "text" : "@chartgerink @datadryad @worldbankdata thanks for pointing it out though. It\u2019s good to keep in mind.",
  "id" : 727037580240404482,
  "in_reply_to_status_id" : 727034830370779136,
  "created_at" : "2016-05-02 07:30:41 +0000",
  "in_reply_to_screen_name" : "chartgerink",
  "in_reply_to_user_id_str" : "439273539",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u24EA Chris Hartgerink",
      "screen_name" : "chartgerink",
      "indices" : [ 0, 12 ],
      "id_str" : "439273539",
      "id" : 439273539
    }, {
      "name" : "Dryad",
      "screen_name" : "datadryad",
      "indices" : [ 13, 23 ],
      "id_str" : "93950513",
      "id" : 93950513
    }, {
      "name" : "World Bank Data",
      "screen_name" : "worldbankdata",
      "indices" : [ 24, 38 ],
      "id_str" : "203332110",
      "id" : 203332110
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 62 ],
      "url" : "https:\/\/t.co\/bWd0OlS8VP",
      "expanded_url" : "http:\/\/ruleofthirds.de\/assets\/images\/scihub-gdp_vs_internet.png",
      "display_url" : "ruleofthirds.de\/assets\/images\/\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "727014413815975936",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11400171575007, 8.753478154038724 ]
  },
  "id_str" : "727018622812585984",
  "in_reply_to_user_id" : 439273539,
  "text" : "@chartgerink @datadryad @worldbankdata https:\/\/t.co\/bWd0OlS8VP",
  "id" : 727018622812585984,
  "in_reply_to_status_id" : 727014413815975936,
  "created_at" : "2016-05-02 06:15:21 +0000",
  "in_reply_to_screen_name" : "chartgerink",
  "in_reply_to_user_id_str" : "439273539",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angela Cochran",
      "screen_name" : "acochran12733",
      "indices" : [ 0, 14 ],
      "id_str" : "555967172",
      "id" : 555967172
    }, {
      "name" : "Dryad",
      "screen_name" : "datadryad",
      "indices" : [ 15, 25 ],
      "id_str" : "93950513",
      "id" : 93950513
    }, {
      "name" : "World Bank Data",
      "screen_name" : "worldbankdata",
      "indices" : [ 26, 40 ],
      "id_str" : "203332110",
      "id" : 203332110
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "726914145635938304",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11400148016531, 8.75347810114575 ]
  },
  "id_str" : "727018055373602817",
  "in_reply_to_user_id" : 555967172,
  "text" : "@acochran12733 @datadryad @worldbankdata fully agree, really nice to see this in the data.",
  "id" : 727018055373602817,
  "in_reply_to_status_id" : 726914145635938304,
  "created_at" : "2016-05-02 06:13:06 +0000",
  "in_reply_to_screen_name" : "acochran12733",
  "in_reply_to_user_id_str" : "555967172",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u24EA Chris Hartgerink",
      "screen_name" : "chartgerink",
      "indices" : [ 0, 12 ],
      "id_str" : "439273539",
      "id" : 439273539
    }, {
      "name" : "Dryad",
      "screen_name" : "datadryad",
      "indices" : [ 13, 23 ],
      "id_str" : "93950513",
      "id" : 93950513
    }, {
      "name" : "World Bank Data",
      "screen_name" : "worldbankdata",
      "indices" : [ 24, 38 ],
      "id_str" : "203332110",
      "id" : 203332110
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "727015014733864960",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1140014115893, 8.753479346339173 ]
  },
  "id_str" : "727017902394736641",
  "in_reply_to_user_id" : 439273539,
  "text" : "@chartgerink @datadryad @worldbankdata that\u2019s not the assumption. Life expectancy at birth is an indicator for development of a country :)",
  "id" : 727017902394736641,
  "in_reply_to_status_id" : 727015014733864960,
  "created_at" : "2016-05-02 06:12:29 +0000",
  "in_reply_to_screen_name" : "chartgerink",
  "in_reply_to_user_id_str" : "439273539",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u24EA Chris Hartgerink",
      "screen_name" : "chartgerink",
      "indices" : [ 0, 12 ],
      "id_str" : "439273539",
      "id" : 439273539
    }, {
      "name" : "Dryad",
      "screen_name" : "datadryad",
      "indices" : [ 13, 23 ],
      "id_str" : "93950513",
      "id" : 93950513
    }, {
      "name" : "World Bank Data",
      "screen_name" : "worldbankdata",
      "indices" : [ 24, 38 ],
      "id_str" : "203332110",
      "id" : 203332110
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "727014413815975936",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1139473366947, 8.753551613195453 ]
  },
  "id_str" : "727017543664308224",
  "in_reply_to_user_id" : 439273539,
  "text" : "@chartgerink @datadryad @worldbankdata this I explicitly discuss in the article, There\u2019s a graph showing correlation of GDP and Internet acc",
  "id" : 727017543664308224,
  "in_reply_to_status_id" : 727014413815975936,
  "created_at" : "2016-05-02 06:11:04 +0000",
  "in_reply_to_screen_name" : "chartgerink",
  "in_reply_to_user_id_str" : "439273539",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "maxwell ogden",
      "screen_name" : "denormalize",
      "indices" : [ 0, 12 ],
      "id_str" : "12241752",
      "id" : 12241752
    }, {
      "name" : "\u03B8ourkni\u02D0r\u0325",
      "screen_name" : "thorgnyr",
      "indices" : [ 27, 36 ],
      "id_str" : "38015980",
      "id" : 38015980
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "726906040155926528",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11400585515648, 8.753480834765307 ]
  },
  "id_str" : "726906921001844736",
  "in_reply_to_user_id" : 12241752,
  "text" : "@denormalize do the cat of @thorgnyr!",
  "id" : 726906921001844736,
  "in_reply_to_status_id" : 726906040155926528,
  "created_at" : "2016-05-01 22:51:29 +0000",
  "in_reply_to_screen_name" : "denormalize",
  "in_reply_to_user_id_str" : "12241752",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott B. Weingart \uD83E\uDD39",
      "screen_name" : "scott_bot",
      "indices" : [ 0, 10 ],
      "id_str" : "15762276",
      "id" : 15762276
    }, {
      "name" : "Dryad",
      "screen_name" : "datadryad",
      "indices" : [ 11, 21 ],
      "id_str" : "93950513",
      "id" : 93950513
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 83 ],
      "url" : "https:\/\/t.co\/FzEbpI8fd7",
      "expanded_url" : "http:\/\/ruleofthirds.de\/analyzing-scihub-data\/",
      "display_url" : "ruleofthirds.de\/analyzing-scih\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "726816000814010368",
  "geo" : { },
  "id_str" : "726901018953396224",
  "in_reply_to_user_id" : 15762276,
  "text" : "@scott_bot @datadryad nice, wanna join forces? mine\u2019s here: https:\/\/t.co\/FzEbpI8fd7 :)",
  "id" : 726901018953396224,
  "in_reply_to_status_id" : 726816000814010368,
  "created_at" : "2016-05-01 22:28:02 +0000",
  "in_reply_to_screen_name" : "scott_bot",
  "in_reply_to_user_id_str" : "15762276",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dryad",
      "screen_name" : "datadryad",
      "indices" : [ 57, 67 ],
      "id_str" : "93950513",
      "id" : 93950513
    }, {
      "name" : "World Bank Data",
      "screen_name" : "worldbankdata",
      "indices" : [ 89, 103 ],
      "id_str" : "203332110",
      "id" : 203332110
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "scihub",
      "indices" : [ 129, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/FzEbpI8fd7",
      "expanded_url" : "http:\/\/ruleofthirds.de\/analyzing-scihub-data\/",
      "display_url" : "ruleofthirds.de\/analyzing-scih\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "726900343553048576",
  "text" : "Here\u2019s my longer take on analyzing the Sci-Hub data from @datadryad along with data from @worldbankdata. https:\/\/t.co\/FzEbpI8fd7 #scihub",
  "id" : 726900343553048576,
  "created_at" : "2016-05-01 22:25:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fiona Nielsen",
      "screen_name" : "glyn_dk",
      "indices" : [ 0, 8 ],
      "id_str" : "32340834",
      "id" : 32340834
    }, {
      "name" : "TP1024",
      "screen_name" : "tp_1024",
      "indices" : [ 9, 17 ],
      "id_str" : "632102396",
      "id" : 632102396
    }, {
      "name" : "Philipp Hummel",
      "screen_name" : "p_humm",
      "indices" : [ 18, 25 ],
      "id_str" : "390742975",
      "id" : 390742975
    }, {
      "name" : "World Bank Data",
      "screen_name" : "worldbankdata",
      "indices" : [ 26, 40 ],
      "id_str" : "203332110",
      "id" : 203332110
    }, {
      "name" : "Tariq Khokhar",
      "screen_name" : "tkb",
      "indices" : [ 41, 45 ],
      "id_str" : "793517",
      "id" : 793517
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "726894887073931264",
  "geo" : { },
  "id_str" : "726895259154784257",
  "in_reply_to_user_id" : 32340834,
  "text" : "@glyn_dk @tp_1024 @p_humm @worldbankdata @tkb plots are as PDF in the GH repo as well.",
  "id" : 726895259154784257,
  "in_reply_to_status_id" : 726894887073931264,
  "created_at" : "2016-05-01 22:05:09 +0000",
  "in_reply_to_screen_name" : "glyn_dk",
  "in_reply_to_user_id_str" : "32340834",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fiona Nielsen",
      "screen_name" : "glyn_dk",
      "indices" : [ 0, 8 ],
      "id_str" : "32340834",
      "id" : 32340834
    }, {
      "name" : "TP1024",
      "screen_name" : "tp_1024",
      "indices" : [ 9, 17 ],
      "id_str" : "632102396",
      "id" : 632102396
    }, {
      "name" : "Philipp Hummel",
      "screen_name" : "p_humm",
      "indices" : [ 18, 25 ],
      "id_str" : "390742975",
      "id" : 390742975
    }, {
      "name" : "World Bank Data",
      "screen_name" : "worldbankdata",
      "indices" : [ 26, 40 ],
      "id_str" : "203332110",
      "id" : 203332110
    }, {
      "name" : "Tariq Khokhar",
      "screen_name" : "tkb",
      "indices" : [ 41, 45 ],
      "id_str" : "793517",
      "id" : 793517
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "726894887073931264",
  "geo" : { },
  "id_str" : "726895203831959553",
  "in_reply_to_user_id" : 32340834,
  "text" : "@glyn_dk @tp_1024 @p_humm @worldbankdata @tkb sure, happy to provide both! :)",
  "id" : 726895203831959553,
  "in_reply_to_status_id" : 726894887073931264,
  "created_at" : "2016-05-01 22:04:56 +0000",
  "in_reply_to_screen_name" : "glyn_dk",
  "in_reply_to_user_id_str" : "32340834",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fiona Nielsen",
      "screen_name" : "glyn_dk",
      "indices" : [ 0, 8 ],
      "id_str" : "32340834",
      "id" : 32340834
    }, {
      "name" : "TP1024",
      "screen_name" : "tp_1024",
      "indices" : [ 9, 17 ],
      "id_str" : "632102396",
      "id" : 632102396
    }, {
      "name" : "Philipp Hummel",
      "screen_name" : "p_humm",
      "indices" : [ 18, 25 ],
      "id_str" : "390742975",
      "id" : 390742975
    }, {
      "name" : "World Bank Data",
      "screen_name" : "worldbankdata",
      "indices" : [ 26, 40 ],
      "id_str" : "203332110",
      "id" : 203332110
    }, {
      "name" : "Tariq Khokhar",
      "screen_name" : "tkb",
      "indices" : [ 41, 45 ],
      "id_str" : "793517",
      "id" : 793517
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/FzEbpI8fd7",
      "expanded_url" : "http:\/\/ruleofthirds.de\/analyzing-scihub-data\/",
      "display_url" : "ruleofthirds.de\/analyzing-scih\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "726689108739952640",
  "geo" : { },
  "id_str" : "726893354148106245",
  "in_reply_to_user_id" : 32340834,
  "text" : "@glyn_dk @tp_1024 @p_humm @worldbankdata @tkb 3 minutes before midnight my time zone, strictly speaking I\u2019m on time! https:\/\/t.co\/FzEbpI8fd7",
  "id" : 726893354148106245,
  "in_reply_to_status_id" : 726689108739952640,
  "created_at" : "2016-05-01 21:57:35 +0000",
  "in_reply_to_screen_name" : "glyn_dk",
  "in_reply_to_user_id_str" : "32340834",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "infinome",
      "screen_name" : "InfinoMe",
      "indices" : [ 0, 9 ],
      "id_str" : "2362226100",
      "id" : 2362226100
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "726829277774139392",
  "geo" : { },
  "id_str" : "726830326601924608",
  "in_reply_to_user_id" : 2362226100,
  "text" : "@InfinoMe thought about that, but I fear that it will influence how well you can go canoeing in it :p",
  "id" : 726830326601924608,
  "in_reply_to_status_id" : 726829277774139392,
  "created_at" : "2016-05-01 17:47:08 +0000",
  "in_reply_to_screen_name" : "InfinoMe",
  "in_reply_to_user_id_str" : "2362226100",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Schawinski",
      "screen_name" : "kevinschawinski",
      "indices" : [ 0, 16 ],
      "id_str" : "242844365",
      "id" : 242844365
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "726816129801437184",
  "geo" : { },
  "id_str" : "726825163103330304",
  "in_reply_to_user_id" : 242844365,
  "text" : "@kevinschawinski when it comes to legalese that\u2019s what counts, at least in most cases.",
  "id" : 726825163103330304,
  "in_reply_to_status_id" : 726816129801437184,
  "created_at" : "2016-05-01 17:26:37 +0000",
  "in_reply_to_screen_name" : "kevinschawinski",
  "in_reply_to_user_id_str" : "242844365",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 50 ],
      "url" : "https:\/\/t.co\/pWXFM4VFhh",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BE30kbihwuh\/",
      "display_url" : "instagram.com\/p\/BE30kbihwuh\/"
    } ]
  },
  "geo" : { },
  "id_str" : "726818320125714436",
  "text" : "Standing Desks are so 2015 https:\/\/t.co\/pWXFM4VFhh",
  "id" : 726818320125714436,
  "created_at" : "2016-05-01 16:59:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/726815689978339330\/photo\/1",
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/ivs2SDkbN8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ChYrA16XEAEFozk.jpg",
      "id_str" : "726815683338768385",
      "id" : 726815683338768385,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ChYrA16XEAEFozk.jpg",
      "sizes" : [ {
        "h" : 4032,
        "resize" : "fit",
        "w" : 3024
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      } ],
      "display_url" : "pic.twitter.com\/ivs2SDkbN8"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11400060056778, 8.753479459509956 ]
  },
  "id_str" : "726815689978339330",
  "text" : "The landlord told me the house rules wouldn\u2019t allow storing a canoe in the garden, so\u2026 https:\/\/t.co\/ivs2SDkbN8",
  "id" : 726815689978339330,
  "created_at" : "2016-05-01 16:48:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Torsten Seemann",
      "screen_name" : "torstenseemann",
      "indices" : [ 0, 15 ],
      "id_str" : "42558652",
      "id" : 42558652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "726678651115196416",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11011216185713, 8.68558690790675 ]
  },
  "id_str" : "726769727511642112",
  "in_reply_to_user_id" : 42558652,
  "text" : "@torstenseemann bad news: we still have no idea how to interpret any of this.",
  "id" : 726769727511642112,
  "in_reply_to_status_id" : 726678651115196416,
  "created_at" : "2016-05-01 13:46:20 +0000",
  "in_reply_to_screen_name" : "torstenseemann",
  "in_reply_to_user_id_str" : "42558652",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Denker",
      "screen_name" : "Phaidr0s",
      "indices" : [ 0, 9 ],
      "id_str" : "40466433",
      "id" : 40466433
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "726768759281713153",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11012006203248, 8.685548785871989 ]
  },
  "id_str" : "726769167756566528",
  "in_reply_to_user_id" : 40466433,
  "text" : "@Phaidr0s die Jukebox Jewkbox anschauen, nach einem langen Spaziergang durch die Sonne \uD83D\uDE31\u2600\uFE0F",
  "id" : 726769167756566528,
  "in_reply_to_status_id" : 726768759281713153,
  "created_at" : "2016-05-01 13:44:06 +0000",
  "in_reply_to_screen_name" : "Phaidr0s",
  "in_reply_to_user_id_str" : "40466433",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 41 ],
      "url" : "https:\/\/t.co\/jkEMDtggVI",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BE3d6-dhwkt\/",
      "display_url" : "instagram.com\/p\/BE3d6-dhwkt\/"
    } ]
  },
  "geo" : { },
  "id_str" : "726768517958242304",
  "text" : "Hang Up, Sheeple! https:\/\/t.co\/jkEMDtggVI",
  "id" : 726768517958242304,
  "created_at" : "2016-05-01 13:41:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "malech maltz",
      "screen_name" : "malech",
      "indices" : [ 60, 67 ],
      "id_str" : "784085846391713793",
      "id" : 784085846391713793
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/726752903352954880\/photo\/1",
      "indices" : [ 68, 91 ],
      "url" : "https:\/\/t.co\/SZOxJ5Mr4M",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ChXx6jXXEAEuUHd.jpg",
      "id_str" : "726752903118131201",
      "id" : 726752903118131201,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ChXx6jXXEAEuUHd.jpg",
      "sizes" : [ {
        "h" : 1200,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1466,
        "resize" : "fit",
        "w" : 1466
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1466,
        "resize" : "fit",
        "w" : 1466
      } ],
      "display_url" : "pic.twitter.com\/SZOxJ5Mr4M"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.104737, 8.675771 ]
  },
  "id_str" : "726752903352954880",
  "text" : "Walk on the Koscher Side. I need to find a copy of this for @malech https:\/\/t.co\/SZOxJ5Mr4M",
  "id" : 726752903352954880,
  "created_at" : "2016-05-01 12:39:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fiona Nielsen",
      "screen_name" : "glyn_dk",
      "indices" : [ 0, 8 ],
      "id_str" : "32340834",
      "id" : 32340834
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "726716872926892033",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11400542208296, 8.75348104740373 ]
  },
  "id_str" : "726718129481637888",
  "in_reply_to_user_id" : 32340834,
  "text" : "@glyn_dk nice! Will have to come visit Cambridge again one of these days. And now I feel better for abandoning R for a couple of hours!",
  "id" : 726718129481637888,
  "in_reply_to_status_id" : 726716872926892033,
  "created_at" : "2016-05-01 10:21:18 +0000",
  "in_reply_to_screen_name" : "glyn_dk",
  "in_reply_to_user_id_str" : "32340834",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fiona Nielsen",
      "screen_name" : "glyn_dk",
      "indices" : [ 0, 8 ],
      "id_str" : "32340834",
      "id" : 32340834
    }, {
      "name" : "TP1024",
      "screen_name" : "tp_1024",
      "indices" : [ 9, 17 ],
      "id_str" : "632102396",
      "id" : 632102396
    }, {
      "name" : "Philipp Hummel",
      "screen_name" : "p_humm",
      "indices" : [ 18, 25 ],
      "id_str" : "390742975",
      "id" : 390742975
    }, {
      "name" : "World Bank Data",
      "screen_name" : "worldbankdata",
      "indices" : [ 26, 40 ],
      "id_str" : "203332110",
      "id" : 203332110
    }, {
      "name" : "Tariq Khokhar",
      "screen_name" : "tkb",
      "indices" : [ 41, 45 ],
      "id_str" : "793517",
      "id" : 793517
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "726689108739952640",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11394679048512, 8.753569627510455 ]
  },
  "id_str" : "726716492742582272",
  "in_reply_to_user_id" : 32340834,
  "text" : "@glyn_dk @tp_1024 @p_humm @worldbankdata @tkb will be a bit later tonight though. Making use of the good weather first\n:p",
  "id" : 726716492742582272,
  "in_reply_to_status_id" : 726689108739952640,
  "created_at" : "2016-05-01 10:14:48 +0000",
  "in_reply_to_screen_name" : "glyn_dk",
  "in_reply_to_user_id_str" : "32340834",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fiona Nielsen",
      "screen_name" : "glyn_dk",
      "indices" : [ 0, 8 ],
      "id_str" : "32340834",
      "id" : 32340834
    }, {
      "name" : "TP1024",
      "screen_name" : "tp_1024",
      "indices" : [ 9, 17 ],
      "id_str" : "632102396",
      "id" : 632102396
    }, {
      "name" : "Philipp Hummel",
      "screen_name" : "p_humm",
      "indices" : [ 18, 25 ],
      "id_str" : "390742975",
      "id" : 390742975
    }, {
      "name" : "World Bank Data",
      "screen_name" : "worldbankdata",
      "indices" : [ 26, 40 ],
      "id_str" : "203332110",
      "id" : 203332110
    }, {
      "name" : "Tariq Khokhar",
      "screen_name" : "tkb",
      "indices" : [ 41, 45 ],
      "id_str" : "793517",
      "id" : 793517
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "726689108739952640",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11399948834401, 8.753478607140133 ]
  },
  "id_str" : "726689612631035904",
  "in_reply_to_user_id" : 32340834,
  "text" : "@glyn_dk @tp_1024 @p_humm @worldbankdata @tkb yes, working on it :)",
  "id" : 726689612631035904,
  "in_reply_to_status_id" : 726689108739952640,
  "created_at" : "2016-05-01 08:27:59 +0000",
  "in_reply_to_screen_name" : "glyn_dk",
  "in_reply_to_user_id_str" : "32340834",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11392419129919, 8.753581285004396 ]
  },
  "id_str" : "726574229307723777",
  "text" : "\u00ABI\u2019ll head to bed soon. Let me just fire up the R console really quickly.\u00BB Famous last words.",
  "id" : 726574229307723777,
  "created_at" : "2016-05-01 00:49:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
} ]