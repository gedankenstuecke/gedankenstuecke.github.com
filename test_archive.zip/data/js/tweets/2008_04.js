Grailbird.data.tweets_2008_04 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Judith",
      "screen_name" : "Sympatexter",
      "indices" : [ 0, 12 ],
      "id_str" : "6438252",
      "id" : 6438252
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "800418802",
  "geo" : { },
  "id_str" : "800419464",
  "in_reply_to_user_id" : 6438252,
  "text" : "@Sympatexter ich sehs genauso! Find die Dinger auch \u00FCber, liest doch eh niemand.",
  "id" : 800419464,
  "in_reply_to_status_id" : 800418802,
  "created_at" : "2008-04-30 00:00:00 +0000",
  "in_reply_to_screen_name" : "Sympatexter",
  "in_reply_to_user_id_str" : "6438252",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Henning Sch\u00FCrig",
      "screen_name" : "hensch",
      "indices" : [ 0, 7 ],
      "id_str" : "3728881",
      "id" : 3728881
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "800434514",
  "geo" : { },
  "id_str" : "800439444",
  "in_reply_to_user_id" : 3728881,
  "text" : "@hensch leute die auf dem blog die trackbacks lesen zum klicken \u00FCberreden, quasi kostenlos verlinken",
  "id" : 800439444,
  "in_reply_to_status_id" : 800434514,
  "created_at" : "2008-04-30 00:00:00 +0000",
  "in_reply_to_screen_name" : "hensch",
  "in_reply_to_user_id_str" : "3728881",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Henning Sch\u00FCrig",
      "screen_name" : "hensch",
      "indices" : [ 0, 7 ],
      "id_str" : "3728881",
      "id" : 3728881
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "800457085",
  "geo" : { },
  "id_str" : "800512529",
  "in_reply_to_user_id" : 3728881,
  "text" : "@hensch ich meinte den marktwert heben im sinne von kostenlosen verlinkungen. Und genau die kriegt man ja \u00FCber trackbacks",
  "id" : 800512529,
  "in_reply_to_status_id" : 800457085,
  "created_at" : "2008-04-30 00:00:00 +0000",
  "in_reply_to_screen_name" : "hensch",
  "in_reply_to_user_id_str" : "3728881",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Henning Sch\u00FCrig",
      "screen_name" : "hensch",
      "indices" : [ 0, 7 ],
      "id_str" : "3728881",
      "id" : 3728881
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "800526074",
  "geo" : { },
  "id_str" : "800526688",
  "in_reply_to_user_id" : 3728881,
  "text" : "@hensch ich glaube gerade weil es so als werbemittel missbraucht wird, liest es fast niemand mehr",
  "id" : 800526688,
  "in_reply_to_status_id" : 800526074,
  "created_at" : "2008-04-30 00:00:00 +0000",
  "in_reply_to_screen_name" : "hensch",
  "in_reply_to_user_id_str" : "3728881",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Henning Sch\u00FCrig",
      "screen_name" : "hensch",
      "indices" : [ 0, 7 ],
      "id_str" : "3728881",
      "id" : 3728881
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "800530885",
  "geo" : { },
  "id_str" : "800536833",
  "in_reply_to_user_id" : 3728881,
  "text" : "@hensch aber oft seh ich auch trackbacks die zwar zur\u00FCcklinken aber wenig zum eigentlichen artikel beitragen, das is doch auch nur werbung",
  "id" : 800536833,
  "in_reply_to_status_id" : 800530885,
  "created_at" : "2008-04-30 00:00:00 +0000",
  "in_reply_to_screen_name" : "hensch",
  "in_reply_to_user_id_str" : "3728881",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "800564085",
  "text" : "es gibt immer noch lecker essen im fegefeuer",
  "id" : 800564085,
  "created_at" : "2008-04-30 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "panik",
      "indices" : [ 68, 74 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "799361109",
  "text" : "eeeks, schon wieder verschlafen, ich hab die wecker nichtmal geh\u00F6rt #panik",
  "id" : 799361109,
  "created_at" : "2008-04-29 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "799726913",
  "text" : "\"pflanzenw\u00FCrde\" *kopfsch\u00FCttel* http:\/\/tinyurl.com\/5uyvpk",
  "id" : 799726913,
  "created_at" : "2008-04-29 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.cloudhopper.com\/\" rel=\"nofollow\"\u003ECloudhopper\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "798568647",
  "text" : "Grad wird wieder ein Tatort gedreht vor der Uni die zum Polizeipr\u00E4sidium umdeklariert wurde.",
  "id" : 798568647,
  "created_at" : "2008-04-28 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "798859053",
  "text" : "Ah, weder Diebstahl, noch ein verplanter Postbote, nur ein falsch informierter Lieferant, nun kommt die \"Nature\" auch an.",
  "id" : 798859053,
  "created_at" : "2008-04-28 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "798930591",
  "text" : "even more photo-uploading",
  "id" : 798930591,
  "created_at" : "2008-04-28 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "798965785",
  "text" : "mit 7 cent gerade leuten den abend gerettet, doch noch bier gekriegt ;)",
  "id" : 798965785,
  "created_at" : "2008-04-28 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "799031514",
  "text" : "stock beantwortet & geworfen: http:\/\/tinyurl.com\/66t3hj",
  "id" : 799031514,
  "created_at" : "2008-04-28 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "798020872",
  "text" : "mh.. gibts eigentlich ne m\u00F6glichkeit auch die songs die man per streaming \u00FCber winamp h\u00F6rt an last.fm zu scrobbeln?",
  "id" : 798020872,
  "created_at" : "2008-04-27 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "798232547",
  "text" : "puh, den ganzen nachmittag bis gerade \"ZOMBIES!\" von Pegasus gespielt",
  "id" : 798232547,
  "created_at" : "2008-04-27 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "797950282",
  "text" : "guten morgen twitteruser",
  "id" : 797950282,
  "created_at" : "2008-04-27 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Henning Sch\u00FCrig",
      "screen_name" : "hensch",
      "indices" : [ 0, 7 ],
      "id_str" : "3728881",
      "id" : 3728881
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "797948710",
  "geo" : { },
  "id_str" : "797950403",
  "in_reply_to_user_id" : 3728881,
  "text" : "@hensch japs, user der gleiche wie hier :)",
  "id" : 797950403,
  "in_reply_to_status_id" : 797948710,
  "created_at" : "2008-04-27 00:00:00 +0000",
  "in_reply_to_screen_name" : "hensch",
  "in_reply_to_user_id_str" : "3728881",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "797955890",
  "text" : "damn, insufficient storage space for importing all my pictures into lightroom!",
  "id" : 797955890,
  "created_at" : "2008-04-27 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "797960934",
  "text" : "unfreundlich: wenn die erste Nachricht des Tages nicht \"Guten Morgen\" oder eine Begr\u00FC\u00DFung ist sondern \"Fotos schon online?\"",
  "id" : 797960934,
  "created_at" : "2008-04-27 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "797982972",
  "text" : "endg\u00FCltig zeit f\u00FCr eine neue ext. festplatte, tipps bitte",
  "id" : 797982972,
  "created_at" : "2008-04-27 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "797486836",
  "text" : "doch mal langsam mit LaTeX auseinander setzen",
  "id" : 797486836,
  "created_at" : "2008-04-26 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "796684744",
  "text" : "WOCHENENDE!",
  "id" : 796684744,
  "created_at" : "2008-04-25 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "796748586",
  "text" : "meine g\u00FCte was ist youtube bei mir heute wieder lahm...",
  "id" : 796748586,
  "created_at" : "2008-04-25 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "796803154",
  "text" : "langsam nervt es, dass fallout so lumpig auf win xp l\u00E4uft",
  "id" : 796803154,
  "created_at" : "2008-04-25 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "796910879",
  "text" : "Ich bef\u00FCrchte fast, der hausmeister hat die \"nature\" einfach mal entsorgt weil sie zwischen werbemist lag...",
  "id" : 796910879,
  "created_at" : "2008-04-25 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.cloudhopper.com\/\" rel=\"nofollow\"\u003ECloudhopper\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "795787867",
  "text" : "Mit der tickenden Eieruhr in der Tasche wird man angesehen wie ein Terrorist",
  "id" : 795787867,
  "created_at" : "2008-04-24 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "795857552",
  "text" : "schon feierabend, wer schnell arbeitet darf auch schnell gehen oder so",
  "id" : 795857552,
  "created_at" : "2008-04-24 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "795893475",
  "text" : "das alte fallout ist einfach toll",
  "id" : 795893475,
  "created_at" : "2008-04-24 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.cloudhopper.com\/\" rel=\"nofollow\"\u003ECloudhopper\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "796104412",
  "text" : "Entweder die Post hats verrafft oder jemand klaut mir die Nature aus dem Briefkasten. Aber wer w\u00FCrde das wollen?",
  "id" : 796104412,
  "created_at" : "2008-04-24 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.cloudhopper.com\/\" rel=\"nofollow\"\u003ECloudhopper\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "794965294",
  "text" : "So, Studienberatung gehabt. Darf weiter studieren ;)",
  "id" : 794965294,
  "created_at" : "2008-04-23 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "795258257",
  "text" : "phew, diese langen tage in der uni schlauchen",
  "id" : 795258257,
  "created_at" : "2008-04-23 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.cloudhopper.com\/\" rel=\"nofollow\"\u003ECloudhopper\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "795354740",
  "text" : "Ein Jahr in der Uni verlieren ist doof, aber auf 10 Wochenstunden freu ich mich. Mehr Zeit f\u00FCr bloggen & fotografieren!",
  "id" : 795354740,
  "created_at" : "2008-04-23 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.cloudhopper.com\/\" rel=\"nofollow\"\u003ECloudhopper\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "794179817",
  "text" : "Traurig wenn vorlesungen so fad gestaltet sind, dass man trotz spannenden themas einschl\u00E4ft.",
  "id" : 794179817,
  "created_at" : "2008-04-22 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.cloudhopper.com\/\" rel=\"nofollow\"\u003ECloudhopper\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Henning Sch\u00FCrig",
      "screen_name" : "hensch",
      "indices" : [ 0, 7 ],
      "id_str" : "3728881",
      "id" : 3728881
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "794310820",
  "geo" : { },
  "id_str" : "794323871",
  "in_reply_to_user_id" : 3728881,
  "text" : "@hensch haste einfach mal wieder \"on\" gesendet, danach gings bei mir wieder.",
  "id" : 794323871,
  "in_reply_to_status_id" : 794310820,
  "created_at" : "2008-04-22 00:00:00 +0000",
  "in_reply_to_screen_name" : "hensch",
  "in_reply_to_user_id_str" : "3728881",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "794548955",
  "text" : "ab jetzt faul vor dem fernseher & danach ins bettchen",
  "id" : 794548955,
  "created_at" : "2008-04-22 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "793653558",
  "text" : "mal was zu essen besorgen",
  "id" : 793653558,
  "created_at" : "2008-04-21 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "793782987",
  "text" : "gut, dass es pizzadienste gibt, dann muss man nur besteck sp\u00FClen",
  "id" : 793782987,
  "created_at" : "2008-04-21 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "793785094",
  "text" : "DPDs gebahren pakete ohne irgendwo eine mitteilung zu hinterlassen in den hausflur zu stellen beim ersten lieferversuch ist mir suspekt...",
  "id" : 793785094,
  "created_at" : "2008-04-21 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "793790259",
  "text" : "pizza online bestellen ist toll, das system versteht auf jedenfall ganz sicher was man will und die gestoppte zeit : 15 min bis lieferung",
  "id" : 793790259,
  "created_at" : "2008-04-21 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "792883920",
  "text" : "hier ebenfalls ein guter morgen",
  "id" : 792883920,
  "created_at" : "2008-04-20 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "792945535",
  "text" : "und wieder neue fotos: http:\/\/tinyurl.com\/6ecm37",
  "id" : 792945535,
  "created_at" : "2008-04-20 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "raju e",
      "screen_name" : "rajue",
      "indices" : [ 0, 6 ],
      "id_str" : "289833731",
      "id" : 289833731
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "792947063",
  "text" : "@rajue geil! zum xten mal das original durchspielen wird ja auch langweilig :)",
  "id" : 792947063,
  "created_at" : "2008-04-20 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "793024629",
  "text" : "http:\/\/tinyurl.com\/6zotg3 im pers\u00F6nlichen labor, aehm ich meine k\u00FCche",
  "id" : 793024629,
  "created_at" : "2008-04-20 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "792450691",
  "text" : "lustige fotos in der k\u00FCche gemacaht",
  "id" : 792450691,
  "created_at" : "2008-04-19 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "792576165",
  "text" : "erste fotos von gestern: http:\/\/tinyurl.com\/5v642g",
  "id" : 792576165,
  "created_at" : "2008-04-19 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "791915101",
  "text" : "vor der haust\u00FCr wird wieder sand aufgesch\u00FCttet, das heisst es wird wohl wieder beachvolleyball geben, mit grausiger musik f\u00FCr ein wochenende",
  "id" : 791915101,
  "created_at" : "2008-04-18 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "791931576",
  "text" : "gleich gehts zum n\u00E4chsten konzert, victima in borghorst",
  "id" : 791931576,
  "created_at" : "2008-04-18 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "792169342",
  "text" : "wieder da vom konzert, peli cases sind echt eine feine sache um das ganze kameraged\u00F6ns bei sowas zu transportieren",
  "id" : 792169342,
  "created_at" : "2008-04-18 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304F\u308D\u3068\u3089",
      "screen_name" : "chikatze",
      "indices" : [ 0, 9 ],
      "id_str" : "2911368630",
      "id" : 2911368630
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "792172481",
  "geo" : { },
  "id_str" : "792174182",
  "in_reply_to_user_id" : 14165822,
  "text" : "@chikatze ab und zu japs, aber gerade nich",
  "id" : 792174182,
  "in_reply_to_status_id" : 792172481,
  "created_at" : "2008-04-18 00:00:00 +0000",
  "in_reply_to_screen_name" : "Frau_Chikatze",
  "in_reply_to_user_id_str" : "14165822",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "790980675",
  "text" : "heute mal faul, vielleicht mal wieder rausgehen und fotos schiessen",
  "id" : 790980675,
  "created_at" : "2008-04-17 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "larsreineke",
      "screen_name" : "spitblog",
      "indices" : [ 0, 9 ],
      "id_str" : "19142360",
      "id" : 19142360
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "790981114",
  "geo" : { },
  "id_str" : "790982926",
  "in_reply_to_user_id" : 6338182,
  "text" : "@spitblog wie geht das? :P",
  "id" : 790982926,
  "in_reply_to_status_id" : 790981114,
  "created_at" : "2008-04-17 00:00:00 +0000",
  "in_reply_to_screen_name" : "larsreineke",
  "in_reply_to_user_id_str" : "6338182",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "791200548",
  "text" : "schaumstoff zurechtschneiden is ohne elektrische hilfsmittel eine scheiss arbeit",
  "id" : 791200548,
  "created_at" : "2008-04-17 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.cloudhopper.com\/\" rel=\"nofollow\"\u003ECloudhopper\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "790147599",
  "text" : "W\u00FCrds, schon wieder bis 19 Uhr in der Uni, wie soll ich denn so einen Termin beim Zahnarzt kriegen",
  "id" : 790147599,
  "created_at" : "2008-04-16 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.cloudhopper.com\/\" rel=\"nofollow\"\u003ECloudhopper\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Judith",
      "screen_name" : "Sympatexter",
      "indices" : [ 0, 12 ],
      "id_str" : "6438252",
      "id" : 6438252
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "790155413",
  "geo" : { },
  "id_str" : "790156052",
  "in_reply_to_user_id" : 6438252,
  "text" : "@Sympatexter geht mir genauso",
  "id" : 790156052,
  "in_reply_to_status_id" : 790155413,
  "created_at" : "2008-04-16 00:00:00 +0000",
  "in_reply_to_screen_name" : "Sympatexter",
  "in_reply_to_user_id_str" : "6438252",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.cloudhopper.com\/\" rel=\"nofollow\"\u003ECloudhopper\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "790413231",
  "text" : "Endlich auf dem Weg nach Hause",
  "id" : 790413231,
  "created_at" : "2008-04-16 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "790459809",
  "text" : "yeah, neues zero punctuation: http:\/\/tinyurl.com\/4lhpl8",
  "id" : 790459809,
  "created_at" : "2008-04-16 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.cloudhopper.com\/\" rel=\"nofollow\"\u003ECloudhopper\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "789359956",
  "text" : "Vor lauter Uni zu nichts kommen",
  "id" : 789359956,
  "created_at" : "2008-04-15 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "789677221",
  "text" : "wieder da aus der uni",
  "id" : 789677221,
  "created_at" : "2008-04-15 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "789798646",
  "text" : "fotos von den beschmierten: http:\/\/tinyurl.com\/6bjzvb",
  "id" : 789798646,
  "created_at" : "2008-04-15 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "788675909",
  "text" : "guten morgen",
  "id" : 788675909,
  "created_at" : "2008-04-14 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "788700484",
  "text" : "leuten beim verfall zuzusehen ist nicht so lustig",
  "id" : 788700484,
  "created_at" : "2008-04-14 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "788811339",
  "text" : "manchen dozenten sollte man zum schutz der h\u00F6rer als auch aus gr\u00FCnden des selbstschutzes den laserpointer wegnehmen *brutzel*",
  "id" : 788811339,
  "created_at" : "2008-04-14 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "788818832",
  "text" : "irgendwer hier der mobile festplatten zum leersaugen von speicherkarten unterwegs nutzt?",
  "id" : 788818832,
  "created_at" : "2008-04-14 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.cloudhopper.com\/\" rel=\"nofollow\"\u003ECloudhopper\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "788925760",
  "text" : "Um diese Uhrzeit nochmal in die Uni fahren zu m\u00FCssen ist echt nicht sch\u00F6n, vor allem wenn es bis 20 Uhr Bioethik heisst.",
  "id" : 788925760,
  "created_at" : "2008-04-14 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "788347079",
  "text" : "endlich es geschafft ne bewerbung fertigzumachen",
  "id" : 788347079,
  "created_at" : "2008-04-13 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "788231437",
  "text" : "guten morgen, \u00E4h mittag",
  "id" : 788231437,
  "created_at" : "2008-04-13 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "787737060",
  "text" : "kacke, filter in der kaffeemaschine vergessen -&gt; schimmel",
  "id" : 787737060,
  "created_at" : "2008-04-12 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "787792459",
  "text" : "mh irgendwie kommen keine sms mehr von twitter rein",
  "id" : 787792459,
  "created_at" : "2008-04-12 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Henning Sch\u00FCrig",
      "screen_name" : "hensch",
      "indices" : [ 0, 7 ],
      "id_str" : "3728881",
      "id" : 3728881
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "787792399",
  "geo" : { },
  "id_str" : "787794204",
  "in_reply_to_user_id" : 3728881,
  "text" : "@hensch gehts bei dir wieder?",
  "id" : 787794204,
  "in_reply_to_status_id" : 787792399,
  "created_at" : "2008-04-12 00:00:00 +0000",
  "in_reply_to_screen_name" : "hensch",
  "in_reply_to_user_id_str" : "3728881",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Henning Sch\u00FCrig",
      "screen_name" : "hensch",
      "indices" : [ 0, 7 ],
      "id_str" : "3728881",
      "id" : 3728881
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "787808288",
  "geo" : { },
  "id_str" : "787809620",
  "in_reply_to_user_id" : 3728881,
  "text" : "@hensch bei mir seit gestern mittag nicht mehr",
  "id" : 787809620,
  "in_reply_to_status_id" : 787808288,
  "created_at" : "2008-04-12 00:00:00 +0000",
  "in_reply_to_screen_name" : "hensch",
  "in_reply_to_user_id_str" : "3728881",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "787809915",
  "text" : "mal eine frage an die fotografen hier: worin transportiert ihr eure ausr\u00FCstung?",
  "id" : 787809915,
  "created_at" : "2008-04-12 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.cloudhopper.com\/\" rel=\"nofollow\"\u003ECloudhopper\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "787026325",
  "text" : "Das mit dem fr\u00FCh aufstehen hat gar nicht geklappt.. Im Bus zur Arbeit",
  "id" : 787026325,
  "created_at" : "2008-04-11 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "787168076",
  "text" : "grad gebloggt: Uni-Spam - http:\/\/tinyurl.com\/56erzq",
  "id" : 787168076,
  "created_at" : "2008-04-11 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "787203609",
  "text" : "unter die dusche springen",
  "id" : 787203609,
  "created_at" : "2008-04-11 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "787236564",
  "text" : "wie man aus einer ef-s-linse eine ef-linse macht: http:\/\/tinyurl.com\/6chnkz",
  "id" : 787236564,
  "created_at" : "2008-04-11 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304F\u308D\u3068\u3089",
      "screen_name" : "chikatze",
      "indices" : [ 0, 9 ],
      "id_str" : "2911368630",
      "id" : 2911368630
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "787277931",
  "geo" : { },
  "id_str" : "787290845",
  "in_reply_to_user_id" : 14165822,
  "text" : "@Chikatze ja, neulich noch, mich hats interessiert :)http:\/\/tinyurl.com\/6zzebt",
  "id" : 787290845,
  "in_reply_to_status_id" : 787277931,
  "created_at" : "2008-04-11 00:00:00 +0000",
  "in_reply_to_screen_name" : "Frau_Chikatze",
  "in_reply_to_user_id_str" : "14165822",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "787343630",
  "text" : "zeit f\u00FCr den ersten wein",
  "id" : 787343630,
  "created_at" : "2008-04-11 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786436184",
  "text" : "wieder da aus uni & von der arbeit",
  "id" : 786436184,
  "created_at" : "2008-04-10 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786448964",
  "text" : "mein moleskine von modofly ist heute gekommen!",
  "id" : 786448964,
  "created_at" : "2008-04-10 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786514486",
  "text" : "lol, enden einer geschichte, abh\u00E4ngig vom musikgeschmack: http:\/\/tinyurl.com\/674hxu",
  "id" : 786514486,
  "created_at" : "2008-04-10 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.cloudhopper.com\/\" rel=\"nofollow\"\u003ECloudhopper\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786604367",
  "text" : "Fallende Messer aufzufangen ist IMMER eine dumme Idee.",
  "id" : 786604367,
  "created_at" : "2008-04-10 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786796614",
  "text" : "und gute nacht, morgen wieder fr\u00FCh raus (hoffentlich...)",
  "id" : 786796614,
  "created_at" : "2008-04-10 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304F\u308D\u3068\u3089",
      "screen_name" : "chikatze",
      "indices" : [ 0, 9 ],
      "id_str" : "2911368630",
      "id" : 2911368630
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "786794174",
  "geo" : { },
  "id_str" : "786796938",
  "in_reply_to_user_id" : 14165822,
  "text" : "@Chikatze meinst du http:\/\/colorwars2008.com\/ ?",
  "id" : 786796938,
  "in_reply_to_status_id" : 786794174,
  "created_at" : "2008-04-10 00:00:00 +0000",
  "in_reply_to_screen_name" : "Frau_Chikatze",
  "in_reply_to_user_id_str" : "14165822",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786799878",
  "text" : "nun aber wirklich aus mit der kiste",
  "id" : 786799878,
  "created_at" : "2008-04-10 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.cloudhopper.com\/\" rel=\"nofollow\"\u003ECloudhopper\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "raju e",
      "screen_name" : "rajue",
      "indices" : [ 0, 6 ],
      "id_str" : "289833731",
      "id" : 289833731
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "785608287",
  "text" : "@rajue ich auch, erste vorlesung schon verpasst",
  "id" : 785608287,
  "created_at" : "2008-04-09 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "785725435",
  "text" : "wieder da aus der uni",
  "id" : 785725435,
  "created_at" : "2008-04-09 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "785746962",
  "text" : "meine mitbewohnerin ist einfach ne faule schlampe...",
  "id" : 785746962,
  "created_at" : "2008-04-09 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "785799644",
  "text" : "den IE seit ich weissnichtwieviel monaten zum ersten mal gestartet, und prompt st\u00FCrzt er beim laden der startseite ab...",
  "id" : 785799644,
  "created_at" : "2008-04-09 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "785800827",
  "text" : "nahrungsmittel jagen",
  "id" : 785800827,
  "created_at" : "2008-04-09 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "785843369",
  "text" : "beim b\u00E4cker erfolg gehabt",
  "id" : 785843369,
  "created_at" : "2008-04-09 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.cloudhopper.com\/\" rel=\"nofollow\"\u003ECloudhopper\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "784944429",
  "text" : "Ich wei\u00DF nicht wie oft ich schon in Schule & Uni \"Osmose\" gelernt hab.. Und nun schon wieder 2 Stunden lang....",
  "id" : 784944429,
  "created_at" : "2008-04-08 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "784990205",
  "text" : "mein glaube das lehramtsstudenten einfach bl\u00F6d sind best\u00E4tigt sich so oft...",
  "id" : 784990205,
  "created_at" : "2008-04-08 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "785099330",
  "text" : "bewerbungen schreiben is so gar nicht mein ding",
  "id" : 785099330,
  "created_at" : "2008-04-08 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "785146777",
  "text" : "sch\u00F6n, dass die o2-webseite nicht verr\u00E4t an wen man die k\u00FCndigung senden soll und man deshalb anrufen muss :(",
  "id" : 785146777,
  "created_at" : "2008-04-08 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "raju e",
      "screen_name" : "rajue",
      "indices" : [ 0, 6 ],
      "id_str" : "289833731",
      "id" : 289833731
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "785150986",
  "text" : "@rajue danke, aber ich hab da schon angerufen & lass mir nun einen vordruck zum unterschreiben zusenden",
  "id" : 785150986,
  "created_at" : "2008-04-08 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "785152322",
  "text" : "bleibt nun die frage wo ich nach vertragslaufzeit unterkommen werde",
  "id" : 785152322,
  "created_at" : "2008-04-08 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "785197196",
  "text" : "kann man eigentlich global den sms-empfang f\u00FCr alle leute die ich followe einstellen?",
  "id" : 785197196,
  "created_at" : "2008-04-08 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "784254508",
  "text" : "ah, recht fr\u00FCh auf sein und gammeln ist fein",
  "id" : 784254508,
  "created_at" : "2008-04-07 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "784274327",
  "text" : "vor dem leeren editor sitzen",
  "id" : 784274327,
  "created_at" : "2008-04-07 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Henning Sch\u00FCrig",
      "screen_name" : "hensch",
      "indices" : [ 0, 7 ],
      "id_str" : "3728881",
      "id" : 3728881
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "784304686",
  "geo" : { },
  "id_str" : "784305616",
  "in_reply_to_user_id" : 3728881,
  "text" : "@hensch: der sch\u00E4tzung w\u00FCrde ich mich anschliessen. in einem gewissen ma\u00DFe hat das doch jeder. Und so schlecht ist Prokrastination ja nich",
  "id" : 784305616,
  "in_reply_to_status_id" : 784304686,
  "created_at" : "2008-04-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "hensch",
  "in_reply_to_user_id_str" : "3728881",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Henning Sch\u00FCrig",
      "screen_name" : "hensch",
      "indices" : [ 0, 7 ],
      "id_str" : "3728881",
      "id" : 3728881
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "784317252",
  "geo" : { },
  "id_str" : "784318836",
  "in_reply_to_user_id" : 3728881,
  "text" : "@hensch du musst von der cd direkt booten",
  "id" : 784318836,
  "in_reply_to_status_id" : 784317252,
  "created_at" : "2008-04-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "hensch",
  "in_reply_to_user_id_str" : "3728881",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "784324072",
  "text" : "ich bin k\u00E4uflich, schreibe gerade am ersten trigami-review",
  "id" : 784324072,
  "created_at" : "2008-04-07 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Henning Sch\u00FCrig",
      "screen_name" : "hensch",
      "indices" : [ 0, 7 ],
      "id_str" : "3728881",
      "id" : 3728881
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "784332515",
  "geo" : { },
  "id_str" : "784332985",
  "in_reply_to_user_id" : 3728881,
  "text" : "@hensch haste das image denn auch bootbar gebrannt? kannste ja \u00FCberpr\u00FCfen mit nem rechner der von cd booten kann",
  "id" : 784332985,
  "in_reply_to_status_id" : 784332515,
  "created_at" : "2008-04-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "hensch",
  "in_reply_to_user_id_str" : "3728881",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Henning Sch\u00FCrig",
      "screen_name" : "hensch",
      "indices" : [ 0, 7 ],
      "id_str" : "3728881",
      "id" : 3728881
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "784332515",
  "geo" : { },
  "id_str" : "784333125",
  "in_reply_to_user_id" : 3728881,
  "text" : "@hensch ok :)",
  "id" : 784333125,
  "in_reply_to_status_id" : 784332515,
  "created_at" : "2008-04-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "hensch",
  "in_reply_to_user_id_str" : "3728881",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "784368524",
  "text" : "mal wieder raustapsen, fotografieren",
  "id" : 784368524,
  "created_at" : "2008-04-07 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "784474708",
  "text" : "doh, parkticket bekommen, 15\u20AC",
  "id" : 784474708,
  "created_at" : "2008-04-07 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "784550226",
  "text" : "mal wieder was abseits konzerten & gitarren hochgeladen: http:\/\/tinyurl.com\/6qbwab",
  "id" : 784550226,
  "created_at" : "2008-04-07 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "784582849",
  "text" : "bah, ich hasse html dichten, vor allem im editor",
  "id" : 784582849,
  "created_at" : "2008-04-07 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "783640244",
  "text" : "nu ins bett",
  "id" : 783640244,
  "created_at" : "2008-04-06 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.cloudhopper.com\/\" rel=\"nofollow\"\u003ECloudhopper\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "783828079",
  "text" : "Geburtstagsfeier in der Verwandschaft...",
  "id" : 783828079,
  "created_at" : "2008-04-06 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "783971420",
  "text" : "so, alle protokolle geschrieben",
  "id" : 783971420,
  "created_at" : "2008-04-06 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "783389327",
  "text" : "hat irgendwer erfahrung mit peli cases gemacht?",
  "id" : 783389327,
  "created_at" : "2008-04-05 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "783396294",
  "text" : "makaber: \"Nazi_human_experimentation\"  aus en.wiki verlinkt zu \"medizin im nationalsozialismus\" bei de.wiki",
  "id" : 783396294,
  "created_at" : "2008-04-05 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "783399621",
  "text" : "juhu, heute abend wieder munchkin spielen",
  "id" : 783399621,
  "created_at" : "2008-04-05 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "783503458",
  "text" : "name unserer lerngruppe: \"mit minimalaufwand durchs studium - mit Basti & Philipp\", gute idee",
  "id" : 783503458,
  "created_at" : "2008-04-05 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "783312029",
  "text" : "so, die klausur ist geschrieben, soll wohl gereicht haben...",
  "id" : 783312029,
  "created_at" : "2008-04-05 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "eldersign",
      "screen_name" : "eldersign",
      "indices" : [ 0, 10 ],
      "id_str" : "14209202",
      "id" : 14209202
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "783337679",
  "geo" : { },
  "id_str" : "783337829",
  "in_reply_to_user_id" : 14209202,
  "text" : "@eldersign bei mir ist es eis :)",
  "id" : 783337829,
  "in_reply_to_status_id" : 783337679,
  "created_at" : "2008-04-05 00:00:00 +0000",
  "in_reply_to_screen_name" : "eldersign",
  "in_reply_to_user_id_str" : "14209202",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "782705668",
  "text" : "doing some serious work at the university hospital \/ arbeiten im ukm",
  "id" : 782705668,
  "created_at" : "2008-04-04 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Henning Sch\u00FCrig",
      "screen_name" : "hensch",
      "indices" : [ 0, 7 ],
      "id_str" : "3728881",
      "id" : 3728881
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "782710725",
  "geo" : { },
  "id_str" : "782713205",
  "in_reply_to_user_id" : 3728881,
  "text" : "@hensch aye, das kenne ich nur zu gut.",
  "id" : 782713205,
  "in_reply_to_status_id" : 782710725,
  "created_at" : "2008-04-04 00:00:00 +0000",
  "in_reply_to_screen_name" : "hensch",
  "in_reply_to_user_id_str" : "3728881",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "782714822",
  "text" : "Proben katalogisieren ist echt ne arbeit f\u00FCr doofe, die Arbeit mit dem Barcodescanner erinnert an ALDI-Kassen",
  "id" : 782714822,
  "created_at" : "2008-04-04 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "782768618",
  "text" : "oh oh capslock angemacht bevor enzo laden konnte, nun gehts nich mehr aus",
  "id" : 782768618,
  "created_at" : "2008-04-04 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "782797117",
  "text" : "kopfschmerzen haben",
  "id" : 782797117,
  "created_at" : "2008-04-04 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "782853409",
  "text" : "\u00FCberhaupt keine lust zu lernen",
  "id" : 782853409,
  "created_at" : "2008-04-04 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "782865766",
  "text" : "systematiken lernen",
  "id" : 782865766,
  "created_at" : "2008-04-04 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "782936997",
  "text" : "wie ironisch, die packungsbeilage des schmerzmittels f\u00FChrt als nebenwirkung \"kopfschmerzen\" auf..",
  "id" : 782936997,
  "created_at" : "2008-04-04 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "782979168",
  "text" : "Watching TV",
  "id" : 782979168,
  "created_at" : "2008-04-04 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "782052071",
  "text" : "killed a pheasant by hitting it with the car this morning \/ heut morgen nen fasan \u00FCberfahren, was fliegen die dinger auch direkt vor autos",
  "id" : 782052071,
  "created_at" : "2008-04-03 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "782077231",
  "text" : "reading, non-scientific... \/ lesen, unwissenschaftliches",
  "id" : 782077231,
  "created_at" : "2008-04-03 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "782111296",
  "text" : "changing to some science for learning \/ das buch l\u00E4uft ja nich weg, die zeit zur klausur aber ab...",
  "id" : 782111296,
  "created_at" : "2008-04-03 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Henning Sch\u00FCrig",
      "screen_name" : "hensch",
      "indices" : [ 0, 7 ],
      "id_str" : "3728881",
      "id" : 3728881
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "782110846",
  "geo" : { },
  "id_str" : "782111758",
  "in_reply_to_user_id" : 3728881,
  "text" : "@hensch grandioser auftritt, \u00E4hnlich gut \"du siehst wunderh\u00FCbsch aus\" - \"Ich auch!\" :)",
  "id" : 782111758,
  "in_reply_to_status_id" : 782110846,
  "created_at" : "2008-04-03 00:00:00 +0000",
  "in_reply_to_screen_name" : "hensch",
  "in_reply_to_user_id_str" : "3728881",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304F\u308D\u3068\u3089",
      "screen_name" : "chikatze",
      "indices" : [ 0, 9 ],
      "id_str" : "2911368630",
      "id" : 2911368630
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "782125387",
  "geo" : { },
  "id_str" : "782125403",
  "in_reply_to_user_id" : 14165822,
  "text" : "@Chikatze dito, ebenfalls gleicher username bei last.fm",
  "id" : 782125403,
  "in_reply_to_status_id" : 782125387,
  "created_at" : "2008-04-03 00:00:00 +0000",
  "in_reply_to_screen_name" : "Frau_Chikatze",
  "in_reply_to_user_id_str" : "14165822",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "782159856",
  "text" : "even more reading: ecology, genetics, evil evolution, mikrobiology \/ und noch mehr lesen: \u00F6kologie, genetik, evolution, mikrobiologie",
  "id" : 782159856,
  "created_at" : "2008-04-03 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "782195135",
  "text" : "watching gametrailers, a retrospective of final fantasy: http:\/\/2big.at\/89f",
  "id" : 782195135,
  "created_at" : "2008-04-03 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "782234136",
  "text" : "take a look at this, mac-fans: http:\/\/2big.at\/89i \/ Was nich alles in so einen Umschlag reinpasst",
  "id" : 782234136,
  "created_at" : "2008-04-03 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "782248273",
  "text" : "done with ecology + genetics!",
  "id" : 782248273,
  "created_at" : "2008-04-03 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "782295866",
  "text" : "gone scouting \/ pfadfinden",
  "id" : 782295866,
  "created_at" : "2008-04-03 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "782353460",
  "text" : "back!",
  "id" : 782353460,
  "created_at" : "2008-04-03 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "782374260",
  "text" : "gutes n\u00E4chtle zusammen",
  "id" : 782374260,
  "created_at" : "2008-04-03 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "781676705",
  "text" : "trying twitter for procrastination \/ twitter zwecks prokrastination ausprobieren :D",
  "id" : 781676705,
  "created_at" : "2008-04-02 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "781707499",
  "text" : "shutting down for today \/ und aus mit der kiste f\u00FCr heute",
  "id" : 781707499,
  "created_at" : "2008-04-02 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
} ]