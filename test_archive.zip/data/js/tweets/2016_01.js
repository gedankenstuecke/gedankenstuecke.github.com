Grailbird.data.tweets_2016_01 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TheConstructor",
      "screen_name" : "TheConstructor",
      "indices" : [ 0, 15 ],
      "id_str" : "14362840",
      "id" : 14362840
    }, {
      "name" : "Sebastian Greiner",
      "screen_name" : "Seb666",
      "indices" : [ 114, 121 ],
      "id_str" : "2365333778",
      "id" : 2365333778
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "693842045794934786",
  "geo" : { },
  "id_str" : "693842253115170816",
  "in_reply_to_user_id" : 14362840,
  "text" : "@TheConstructor it is, if you go through my tweet archive you see lots of frustrated tweets about it, from me and @Seb666",
  "id" : 693842253115170816,
  "in_reply_to_status_id" : 693842045794934786,
  "created_at" : "2016-01-31 17:04:18 +0000",
  "in_reply_to_screen_name" : "TheConstructor",
  "in_reply_to_user_id_str" : "14362840",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "693839520119308288",
  "text" : "Wow, I installed an OS X update and for the first time in months it didn\u2019t forget all installed keyboard layouts afterwards!",
  "id" : 693839520119308288,
  "created_at" : "2016-01-31 16:53:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "samantha based clark",
      "screen_name" : "eltonjohn",
      "indices" : [ 0, 10 ],
      "id_str" : "15661851",
      "id" : 15661851
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "693604289495879680",
  "geo" : { },
  "id_str" : "693820422610161665",
  "in_reply_to_user_id" : 15661851,
  "text" : "@eltonjohn let\u2019s hope for high quantity one day :D",
  "id" : 693820422610161665,
  "in_reply_to_status_id" : 693604289495879680,
  "created_at" : "2016-01-31 15:37:33 +0000",
  "in_reply_to_screen_name" : "eltonjohn",
  "in_reply_to_user_id_str" : "15661851",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/gh5r9mXNg8",
      "expanded_url" : "http:\/\/i.imgur.com\/h01E3.gif",
      "display_url" : "i.imgur.com\/h01E3.gif"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17582087715552, 8.631626156100554 ]
  },
  "id_str" : "693773358127828992",
  "text" : "Ever since I dropped my phone I have to lick the contacts of the cable when I want to charge it. https:\/\/t.co\/gh5r9mXNg8",
  "id" : 693773358127828992,
  "created_at" : "2016-01-31 12:30:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/YRuTGPnOtl",
      "expanded_url" : "http:\/\/tinyurl.com\/gt8hqf6",
      "display_url" : "tinyurl.com\/gt8hqf6"
    } ]
  },
  "geo" : { },
  "id_str" : "693589867398352896",
  "text" : "RT @valentina_crrr: fun fact: \"the phrase the fourth Industrial Revolution has been around for more than 75 years\" https:\/\/t.co\/YRuTGPnOtl \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Slate",
        "screen_name" : "Slate",
        "indices" : [ 123, 129 ],
        "id_str" : "15164565",
        "id" : 15164565
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 95, 118 ],
        "url" : "https:\/\/t.co\/YRuTGPnOtl",
        "expanded_url" : "http:\/\/tinyurl.com\/gt8hqf6",
        "display_url" : "tinyurl.com\/gt8hqf6"
      } ]
    },
    "geo" : { },
    "id_str" : "693589187618955264",
    "text" : "fun fact: \"the phrase the fourth Industrial Revolution has been around for more than 75 years\" https:\/\/t.co\/YRuTGPnOtl via @slate",
    "id" : 693589187618955264,
    "created_at" : "2016-01-31 00:18:43 +0000",
    "user" : {
      "name" : "Valentina Carraro",
      "screen_name" : "valecrrr",
      "protected" : true,
      "id_str" : "2998662774",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/560360332212727810\/Na4DXAOo_normal.jpeg",
      "id" : 2998662774,
      "verified" : false
    }
  },
  "id" : 693589867398352896,
  "created_at" : "2016-01-31 00:21:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "693551530201473024",
  "geo" : { },
  "id_str" : "693551804995485701",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon that\u2019s the spirit! \uD83D\uDE4F",
  "id" : 693551804995485701,
  "in_reply_to_status_id" : 693551530201473024,
  "created_at" : "2016-01-30 21:50:10 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 85 ],
      "url" : "https:\/\/t.co\/VXgVZSxdMJ",
      "expanded_url" : "http:\/\/www.theatlantic.com\/science\/archive\/2016\/01\/elsevier-academic-publishing-petition\/427059\/?utm_source=SFTwitter",
      "display_url" : "theatlantic.com\/science\/archiv\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "693545261365399553",
  "text" : "how parts of the linguistics community are taking on Elsevier https:\/\/t.co\/VXgVZSxdMJ",
  "id" : 693545261365399553,
  "created_at" : "2016-01-30 21:24:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 89 ],
      "url" : "https:\/\/t.co\/muutWThk2z",
      "expanded_url" : "http:\/\/www.buzzfeed.com\/rossalynwarren\/a-model-is-alerting-girlfriends-of-the-men-who-send-her-dick#.lyDJoVZb9",
      "display_url" : "buzzfeed.com\/rossalynwarren\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11403955369168, 8.753434959459703 ]
  },
  "id_str" : "693540577799979008",
  "text" : "A Model Is Alerting Girlfriends Of The Men Who Send Her Dick\u00A0Pics https:\/\/t.co\/muutWThk2z",
  "id" : 693540577799979008,
  "created_at" : "2016-01-30 21:05:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc RobinsonRechavi",
      "screen_name" : "marc_rr",
      "indices" : [ 3, 11 ],
      "id_str" : "454724555",
      "id" : 454724555
    }, {
      "name" : "Force11.org",
      "screen_name" : "force11rescomm",
      "indices" : [ 17, 32 ],
      "id_str" : "720754110",
      "id" : 720754110
    }, {
      "name" : "Melissa Haendel",
      "screen_name" : "ontowonka",
      "indices" : [ 34, 44 ],
      "id_str" : "777135943",
      "id" : 777135943
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "researchparasites",
      "indices" : [ 68, 86 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "693533667776413696",
  "text" : "RT @marc_rr: For @force11rescomm, @ontowonka pulls no punches about #researchparasites: \"the recent NEJM editorial made me MAD\" https:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Force11.org",
        "screen_name" : "force11rescomm",
        "indices" : [ 4, 19 ],
        "id_str" : "720754110",
        "id" : 720754110
      }, {
        "name" : "Melissa Haendel",
        "screen_name" : "ontowonka",
        "indices" : [ 21, 31 ],
        "id_str" : "777135943",
        "id" : 777135943
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "researchparasites",
        "indices" : [ 55, 73 ]
      } ],
      "urls" : [ {
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/7kA0ZCMOXf",
        "expanded_url" : "https:\/\/www.force11.org\/blog\/may-force11-be-research-parasites",
        "display_url" : "force11.org\/blog\/may-force\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "693530329508925440",
    "text" : "For @force11rescomm, @ontowonka pulls no punches about #researchparasites: \"the recent NEJM editorial made me MAD\" https:\/\/t.co\/7kA0ZCMOXf",
    "id" : 693530329508925440,
    "created_at" : "2016-01-30 20:24:50 +0000",
    "user" : {
      "name" : "Marc RobinsonRechavi",
      "screen_name" : "marc_rr",
      "protected" : false,
      "id_str" : "454724555",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1751744306\/mrr_caricature_normal.jpg",
      "id" : 454724555,
      "verified" : false
    }
  },
  "id" : 693533667776413696,
  "created_at" : "2016-01-30 20:38:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 92 ],
      "url" : "https:\/\/t.co\/mcx2XjqnI0",
      "expanded_url" : "https:\/\/twitter.com\/kai_arzheimer\/status\/693526376343867392",
      "display_url" : "twitter.com\/kai_arzheimer\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "693532098565705729",
  "text" : "if you ever wondered why frequentists and bayesians don\u2019t get along: https:\/\/t.co\/mcx2XjqnI0",
  "id" : 693532098565705729,
  "created_at" : "2016-01-30 20:31:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 84 ],
      "url" : "https:\/\/t.co\/T4rYC51QFi",
      "expanded_url" : "http:\/\/journals.plos.org\/plosone\/article?id=10.1371\/journal.pone.0147941",
      "display_url" : "journals.plos.org\/plosone\/articl\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "693516253617602560",
  "text" : "Comparative\u00A0Analysis of Genome Diversity in Bullmastiff Dogs https:\/\/t.co\/T4rYC51QFi",
  "id" : 693516253617602560,
  "created_at" : "2016-01-30 19:28:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alvaro Sanchez",
      "screen_name" : "asanchez_lab",
      "indices" : [ 3, 16 ],
      "id_str" : "3319374430",
      "id" : 3319374430
    }, {
      "name" : "OfficialSMBE",
      "screen_name" : "OfficialSMBE",
      "indices" : [ 30, 43 ],
      "id_str" : "1120098811",
      "id" : 1120098811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "693448484339486720",
  "text" : "RT @asanchez_lab: Hats off to @OfficialSMBE . Hard to overstate how financially challenging parenthood is for young academics. \nhttps:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "OfficialSMBE",
        "screen_name" : "OfficialSMBE",
        "indices" : [ 12, 25 ],
        "id_str" : "1120098811",
        "id" : 1120098811
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 110, 133 ],
        "url" : "https:\/\/t.co\/BifjApzQvw",
        "expanded_url" : "https:\/\/www.smbe.org\/smbe\/HOME\/TabId\/37\/ArtMID\/1395\/ArticleID\/30\/SMBE-Childcare-Awards-an-update-by-Aoife-McLysaght.aspx",
        "display_url" : "smbe.org\/smbe\/HOME\/TabI\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "692465037466865665",
    "text" : "Hats off to @OfficialSMBE . Hard to overstate how financially challenging parenthood is for young academics. \nhttps:\/\/t.co\/BifjApzQvw",
    "id" : 692465037466865665,
    "created_at" : "2016-01-27 21:51:44 +0000",
    "user" : {
      "name" : "Alvaro Sanchez",
      "screen_name" : "asanchez_lab",
      "protected" : false,
      "id_str" : "3319374430",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/897739407603707904\/VKE4hmi__normal.jpg",
      "id" : 3319374430,
      "verified" : false
    }
  },
  "id" : 693448484339486720,
  "created_at" : "2016-01-30 14:59:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/JVabHlfPVt",
      "expanded_url" : "https:\/\/twitter.com\/DegenRolf\/status\/693330963582042112",
      "display_url" : "twitter.com\/DegenRolf\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "693441633724059648",
  "text" : "\u00ABthere are many reasons why psychology\u2019s status as a science is questionable, but youth is not one of them.\u00BB \uD83D\uDD25\uD83D\uDD25 https:\/\/t.co\/JVabHlfPVt",
  "id" : 693441633724059648,
  "created_at" : "2016-01-30 14:32:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/odrpgxXOAm",
      "expanded_url" : "http:\/\/ecologybits.com\/index.php\/2016\/01\/20\/maybe-we-shouldnt-be-trying-to-read-more\/",
      "display_url" : "ecologybits.com\/index.php\/2016\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "693406195940462592",
  "text" : "Wow, finding papers by journals is so alien to me I actually wondered what TOC might refer to m) https:\/\/t.co\/odrpgxXOAm",
  "id" : 693406195940462592,
  "created_at" : "2016-01-30 12:11:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Torsten Seemann",
      "screen_name" : "torstenseemann",
      "indices" : [ 0, 15 ],
      "id_str" : "42558652",
      "id" : 42558652
    }, {
      "name" : "Nick Loman",
      "screen_name" : "pathogenomenick",
      "indices" : [ 16, 32 ],
      "id_str" : "85906238",
      "id" : 85906238
    }, {
      "name" : "Trevor A. Branch",
      "screen_name" : "TrevorABranch",
      "indices" : [ 33, 47 ],
      "id_str" : "441560048",
      "id" : 441560048
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "693217414943670272",
  "geo" : { },
  "id_str" : "693220491700604928",
  "in_reply_to_user_id" : 42558652,
  "text" : "@torstenseemann @pathogenomenick @TrevorABranch \u201Ebe ultra productive by not doing anything yourself!\u201C",
  "id" : 693220491700604928,
  "in_reply_to_status_id" : 693217414943670272,
  "created_at" : "2016-01-29 23:53:39 +0000",
  "in_reply_to_screen_name" : "torstenseemann",
  "in_reply_to_user_id_str" : "42558652",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jared Decker",
      "screen_name" : "pop_gen_JED",
      "indices" : [ 0, 12 ],
      "id_str" : "229711796",
      "id" : 229711796
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "693208514949357568",
  "geo" : { },
  "id_str" : "693209014239412224",
  "in_reply_to_user_id" : 229711796,
  "text" : "@pop_gen_JED not into sports, but I can relate nevertheless: books, movies etc. all frequently do the trick for me.",
  "id" : 693209014239412224,
  "in_reply_to_status_id" : 693208514949357568,
  "created_at" : "2016-01-29 23:08:02 +0000",
  "in_reply_to_screen_name" : "pop_gen_JED",
  "in_reply_to_user_id_str" : "229711796",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tabitha M. Powledge",
      "screen_name" : "tamfecit",
      "indices" : [ 3, 12 ],
      "id_str" : "20481587",
      "id" : 20481587
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/VyWWeRQ2e3",
      "expanded_url" : "http:\/\/ow.ly\/XH7qN",
      "display_url" : "ow.ly\/XH7qN"
    } ]
  },
  "geo" : { },
  "id_str" : "693189500881768448",
  "text" : "RT @tamfecit: OnScienceBlogs Is Lander's revisionist CRISPR history sexist? https:\/\/t.co\/VyWWeRQ2e3",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 62, 85 ],
        "url" : "https:\/\/t.co\/VyWWeRQ2e3",
        "expanded_url" : "http:\/\/ow.ly\/XH7qN",
        "display_url" : "ow.ly\/XH7qN"
      } ]
    },
    "geo" : { },
    "id_str" : "693156507999936512",
    "text" : "OnScienceBlogs Is Lander's revisionist CRISPR history sexist? https:\/\/t.co\/VyWWeRQ2e3",
    "id" : 693156507999936512,
    "created_at" : "2016-01-29 19:39:24 +0000",
    "user" : {
      "name" : "Tabitha M. Powledge",
      "screen_name" : "tamfecit",
      "protected" : false,
      "id_str" : "20481587",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/546459334\/brainbook_pic_normal.gif",
      "id" : 20481587,
      "verified" : false
    }
  },
  "id" : 693189500881768448,
  "created_at" : "2016-01-29 21:50:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fiona Nielsen",
      "screen_name" : "glyn_dk",
      "indices" : [ 22, 30 ],
      "id_str" : "32340834",
      "id" : 32340834
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 82 ],
      "url" : "https:\/\/t.co\/7KRTSOuz7d",
      "expanded_url" : "http:\/\/www.lastwordonnothing.com\/2016\/01\/28\/visit-with-a-lichenologist\/",
      "display_url" : "lastwordonnothing.com\/2016\/01\/28\/vis\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "693188595218276353",
  "text" : "Urban Lichens. Thanks @glyn_dk for pointing me towards it! https:\/\/t.co\/7KRTSOuz7d",
  "id" : 693188595218276353,
  "created_at" : "2016-01-29 21:46:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Eisen",
      "screen_name" : "mbeisen",
      "indices" : [ 0, 8 ],
      "id_str" : "19843630",
      "id" : 19843630
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "693183563814932480",
  "geo" : { },
  "id_str" : "693185285606240256",
  "in_reply_to_user_id" : 19843630,
  "text" : "@mbeisen \u201Ehow to take care of your mental health.\u201C",
  "id" : 693185285606240256,
  "in_reply_to_status_id" : 693183563814932480,
  "created_at" : "2016-01-29 21:33:45 +0000",
  "in_reply_to_screen_name" : "mbeisen",
  "in_reply_to_user_id_str" : "19843630",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 7, 30 ],
      "url" : "https:\/\/t.co\/mE1eYeb7bG",
      "expanded_url" : "http:\/\/whatshouldwecallgradschool.tumblr.com\/post\/138288537552\/when-my-experiment-shows-no-significant-difference",
      "display_url" : "whatshouldwecallgradschool.tumblr.com\/post\/138288537\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "693183251343654912",
  "text" : "*sigh* https:\/\/t.co\/mE1eYeb7bG",
  "id" : 693183251343654912,
  "created_at" : "2016-01-29 21:25:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Madeleine Price Ball",
      "screen_name" : "madprime",
      "indices" : [ 3, 12 ],
      "id_str" : "71557700",
      "id" : 71557700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "693177525900591105",
  "text" : "RT @madprime: I know a PGP participant whose ALS son seems atypical, seeking genomic investigation. Any advice or leads for him? (RT for le\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "693173582051020802",
    "text" : "I know a PGP participant whose ALS son seems atypical, seeking genomic investigation. Any advice or leads for him? (RT for leads?)",
    "id" : 693173582051020802,
    "created_at" : "2016-01-29 20:47:15 +0000",
    "user" : {
      "name" : "Madeleine Price Ball",
      "screen_name" : "madprime",
      "protected" : false,
      "id_str" : "71557700",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/515539302931910656\/9N7oFHFZ_normal.png",
      "id" : 71557700,
      "verified" : false
    }
  },
  "id" : 693177525900591105,
  "created_at" : "2016-01-29 21:02:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonas",
      "screen_name" : "lsanoj",
      "indices" : [ 0, 7 ],
      "id_str" : "18918915",
      "id" : 18918915
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "693161283449917441",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11404015635747, 8.753450160583055 ]
  },
  "id_str" : "693161515013312512",
  "in_reply_to_user_id" : 18918915,
  "text" : "@lsanoj ach das ist dieses Hafti von dem du immer twitterst?",
  "id" : 693161515013312512,
  "in_reply_to_status_id" : 693161283449917441,
  "created_at" : "2016-01-29 19:59:18 +0000",
  "in_reply_to_screen_name" : "lsanoj",
  "in_reply_to_user_id_str" : "18918915",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zak Greant",
      "screen_name" : "zakgreant",
      "indices" : [ 3, 13 ],
      "id_str" : "17763613",
      "id" : 17763613
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/zakgreant\/status\/692983300219076608\/photo\/1",
      "indices" : [ 52, 75 ],
      "url" : "https:\/\/t.co\/O3Srn22FeD",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CZ34o59W0AA_JKf.png",
      "id_str" : "692983299321548800",
      "id" : 692983299321548800,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CZ34o59W0AA_JKf.png",
      "sizes" : [ {
        "h" : 474,
        "resize" : "fit",
        "w" : 474
      }, {
        "h" : 474,
        "resize" : "fit",
        "w" : 474
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 474,
        "resize" : "fit",
        "w" : 474
      }, {
        "h" : 474,
        "resize" : "fit",
        "w" : 474
      } ],
      "display_url" : "pic.twitter.com\/O3Srn22FeD"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "693156467050938369",
  "text" : "RT @zakgreant: Maslow\u2019s hierarchy of user stories \u2026 https:\/\/t.co\/O3Srn22FeD",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/zakgreant\/status\/692983300219076608\/photo\/1",
        "indices" : [ 37, 60 ],
        "url" : "https:\/\/t.co\/O3Srn22FeD",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CZ34o59W0AA_JKf.png",
        "id_str" : "692983299321548800",
        "id" : 692983299321548800,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CZ34o59W0AA_JKf.png",
        "sizes" : [ {
          "h" : 474,
          "resize" : "fit",
          "w" : 474
        }, {
          "h" : 474,
          "resize" : "fit",
          "w" : 474
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 474,
          "resize" : "fit",
          "w" : 474
        }, {
          "h" : 474,
          "resize" : "fit",
          "w" : 474
        } ],
        "display_url" : "pic.twitter.com\/O3Srn22FeD"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "692983300219076608",
    "text" : "Maslow\u2019s hierarchy of user stories \u2026 https:\/\/t.co\/O3Srn22FeD",
    "id" : 692983300219076608,
    "created_at" : "2016-01-29 08:11:08 +0000",
    "user" : {
      "name" : "Zak Greant",
      "screen_name" : "zakgreant",
      "protected" : false,
      "id_str" : "17763613",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/854762983624515584\/aGguTw0g_normal.jpg",
      "id" : 17763613,
      "verified" : false
    }
  },
  "id" : 693156467050938369,
  "created_at" : "2016-01-29 19:39:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11405610946068, 8.75345248072398 ]
  },
  "id_str" : "693155526969004032",
  "text" : "When you open your inbox and wonder 'when did I enroll for that study!?'",
  "id" : 693155526969004032,
  "created_at" : "2016-01-29 19:35:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 69 ],
      "url" : "https:\/\/t.co\/IzvCBhaOaW",
      "expanded_url" : "https:\/\/twitter.com\/jazzipoo_\/status\/692220056030310403",
      "display_url" : "twitter.com\/jazzipoo_\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "692989893392384000",
  "text" : "Wait, wasn\u2019t Rumsfeld doing iPhone games now? https:\/\/t.co\/IzvCBhaOaW",
  "id" : 692989893392384000,
  "created_at" : "2016-01-29 08:37:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "692983224717463552",
  "geo" : { },
  "id_str" : "692985490958606336",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer well, I guess even with PacBio &amp; nanopore most assemblies still stay at ctg lvl.",
  "id" : 692985490958606336,
  "in_reply_to_status_id" : 692983224717463552,
  "created_at" : "2016-01-29 08:19:50 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "692928235433259008",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17149393288532, 8.627993882718942 ]
  },
  "id_str" : "692982901584089088",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer so I still have hope for my contig assemblies ;)",
  "id" : 692982901584089088,
  "in_reply_to_status_id" : 692928235433259008,
  "created_at" : "2016-01-29 08:09:33 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "maura \"are jack and biz nazis?\" quint",
      "screen_name" : "behindyourback",
      "indices" : [ 3, 18 ],
      "id_str" : "31455711",
      "id" : 31455711
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "692800911505297409",
  "text" : "RT @behindyourback: Donald Trump &amp; Richard Dawkins stare at each other. \"Women &amp; Muslims are gross,\" Trump says. \"Totally,\" nods Dawkins. T\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "692796546048528384",
    "text" : "Donald Trump &amp; Richard Dawkins stare at each other. \"Women &amp; Muslims are gross,\" Trump says. \"Totally,\" nods Dawkins. They passionately kiss",
    "id" : 692796546048528384,
    "created_at" : "2016-01-28 19:49:02 +0000",
    "user" : {
      "name" : "maura \"are jack and biz nazis?\" quint",
      "screen_name" : "behindyourback",
      "protected" : false,
      "id_str" : "31455711",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/617123223101018113\/rRf4L1ai_normal.jpg",
      "id" : 31455711,
      "verified" : true
    }
  },
  "id" : 692800911505297409,
  "created_at" : "2016-01-28 20:06:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 83 ],
      "url" : "https:\/\/t.co\/nCIzzMtlSQ",
      "expanded_url" : "https:\/\/twitter.com\/edyong209\/status\/692718946185777153",
      "display_url" : "twitter.com\/edyong209\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "692727507695620096",
  "text" : "Hypotheses that make you want to punch someone in the face. https:\/\/t.co\/nCIzzMtlSQ",
  "id" : 692727507695620096,
  "created_at" : "2016-01-28 15:14:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 70 ],
      "url" : "https:\/\/t.co\/xdYenqu634",
      "expanded_url" : "http:\/\/99percentinvisible.org\/episode\/fish-cannon\/",
      "display_url" : "99percentinvisible.org\/episode\/fish-c\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "692710920477372417",
  "text" : "i could watch those fish cannon videos all day https:\/\/t.co\/xdYenqu634",
  "id" : 692710920477372417,
  "created_at" : "2016-01-28 14:08:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hans Zauner",
      "screen_name" : "HansZauner",
      "indices" : [ 0, 11 ],
      "id_str" : "995259308",
      "id" : 995259308
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "692692041076232192",
  "geo" : { },
  "id_str" : "692692441820991489",
  "in_reply_to_user_id" : 995259308,
  "text" : "@HansZauner steht im verlinkten Artikel. ;) (Ja, laut Meldung S\u00FCdkurier)",
  "id" : 692692441820991489,
  "in_reply_to_status_id" : 692692041076232192,
  "created_at" : "2016-01-28 12:55:22 +0000",
  "in_reply_to_screen_name" : "HansZauner",
  "in_reply_to_user_id_str" : "995259308",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 48 ],
      "url" : "https:\/\/t.co\/79DHI8HzSg",
      "expanded_url" : "https:\/\/twitter.com\/chapmangamo\/status\/692676481030459392",
      "display_url" : "twitter.com\/chapmangamo\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "692686566418976769",
  "text" : "such a useful phrasebook https:\/\/t.co\/79DHI8HzSg",
  "id" : 692686566418976769,
  "created_at" : "2016-01-28 12:32:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/JXuPAeQshz",
      "expanded_url" : "https:\/\/github.com\/gedankenstuecke\/noti",
      "display_url" : "github.com\/gedankenstueck\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "692646499029749761",
  "text" : "Some of my machines don\u2019t have notify-send installed, so I added a quick workaround to only use pushbullet in noti https:\/\/t.co\/JXuPAeQshz",
  "id" : 692646499029749761,
  "created_at" : "2016-01-28 09:52:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/W2Rb6ADRwS",
      "expanded_url" : "http:\/\/www.rutgerhauer.org\/rutgerhauer.org\/story.php",
      "display_url" : "rutgerhauer.org\/rutgerhauer.or\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "692632018505617408",
  "text" : "TIL: There\u2019s the \u2018Rutger Hauer Starfish Association\u2019 for raising AIDS awareness. https:\/\/t.co\/W2Rb6ADRwS",
  "id" : 692632018505617408,
  "created_at" : "2016-01-28 08:55:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Denker",
      "screen_name" : "Phaidr0s",
      "indices" : [ 0, 9 ],
      "id_str" : "40466433",
      "id" : 40466433
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "692473142074314752",
  "geo" : { },
  "id_str" : "692473406797774848",
  "in_reply_to_user_id" : 40466433,
  "text" : "@Phaidr0s lucky you :)",
  "id" : 692473406797774848,
  "in_reply_to_status_id" : 692473142074314752,
  "created_at" : "2016-01-27 22:25:00 +0000",
  "in_reply_to_screen_name" : "Phaidr0s",
  "in_reply_to_user_id_str" : "40466433",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Denker",
      "screen_name" : "Phaidr0s",
      "indices" : [ 0, 9 ],
      "id_str" : "40466433",
      "id" : 40466433
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "692471103478960128",
  "geo" : { },
  "id_str" : "692471391166271488",
  "in_reply_to_user_id" : 40466433,
  "text" : "@Phaidr0s \u201E43% Match bei OkC\u201C :P",
  "id" : 692471391166271488,
  "in_reply_to_status_id" : 692471103478960128,
  "created_at" : "2016-01-27 22:16:59 +0000",
  "in_reply_to_screen_name" : "Phaidr0s",
  "in_reply_to_user_id_str" : "40466433",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 0, 9 ],
      "id_str" : "14245811",
      "id" : 14245811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "692464092116819972",
  "geo" : { },
  "id_str" : "692467404312543232",
  "in_reply_to_user_id" : 14245811,
  "text" : "@wilbanks can we please stop calling people who don\u2019t show their work scientists?",
  "id" : 692467404312543232,
  "in_reply_to_status_id" : 692464092116819972,
  "created_at" : "2016-01-27 22:01:09 +0000",
  "in_reply_to_screen_name" : "wilbanks",
  "in_reply_to_user_id_str" : "14245811",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mozilla Science Lab",
      "screen_name" : "MozillaScience",
      "indices" : [ 3, 18 ],
      "id_str" : "1428575976",
      "id" : 1428575976
    }, {
      "name" : "BioUno",
      "screen_name" : "biouno",
      "indices" : [ 70, 77 ],
      "id_str" : "1340775810",
      "id" : 1340775810
    }, {
      "name" : "openSNP team",
      "screen_name" : "openSNPorg",
      "indices" : [ 79, 90 ],
      "id_str" : "380205172",
      "id" : 380205172
    }, {
      "name" : "Cytoscape.js",
      "screen_name" : "cytoscapejs",
      "indices" : [ 92, 104 ],
      "id_str" : "845884153",
      "id" : 845884153
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "692378317123641346",
  "text" : "RT @MozillaScience: *TMRW* See how you can contribute to PaperBadger, @biouno, @openSNPorg, @cytoscapejs + more on our project call \n\nhttps\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "BioUno",
        "screen_name" : "biouno",
        "indices" : [ 50, 57 ],
        "id_str" : "1340775810",
        "id" : 1340775810
      }, {
        "name" : "openSNP team",
        "screen_name" : "openSNPorg",
        "indices" : [ 59, 70 ],
        "id_str" : "380205172",
        "id" : 380205172
      }, {
        "name" : "Cytoscape.js",
        "screen_name" : "cytoscapejs",
        "indices" : [ 72, 84 ],
        "id_str" : "845884153",
        "id" : 845884153
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/B7hbHxgjUQ",
        "expanded_url" : "https:\/\/public.etherpad-mozilla.org\/p\/sciencelab-project-call-jan28-2016",
        "display_url" : "public.etherpad-mozilla.org\/p\/sciencelab-p\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "692376557709455360",
    "text" : "*TMRW* See how you can contribute to PaperBadger, @biouno, @openSNPorg, @cytoscapejs + more on our project call \n\nhttps:\/\/t.co\/B7hbHxgjUQ",
    "id" : 692376557709455360,
    "created_at" : "2016-01-27 16:00:09 +0000",
    "user" : {
      "name" : "Mozilla Science Lab",
      "screen_name" : "MozillaScience",
      "protected" : false,
      "id_str" : "1428575976",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/687287790049034240\/lwIk-ZQT_normal.png",
      "id" : 1428575976,
      "verified" : false
    }
  },
  "id" : 692378317123641346,
  "created_at" : "2016-01-27 16:07:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 0, 9 ],
      "id_str" : "14245811",
      "id" : 14245811
    }, {
      "name" : "NEJM",
      "screen_name" : "NEJM",
      "indices" : [ 10, 15 ],
      "id_str" : "25950355",
      "id" : 25950355
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "692374300440010752",
  "geo" : { },
  "id_str" : "692377923102334976",
  "in_reply_to_user_id" : 14245811,
  "text" : "@wilbanks @NEJM I don\u2019t see any image credit. Sid they take the pictures themselves or are they parasiting the work of others?",
  "id" : 692377923102334976,
  "in_reply_to_status_id" : 692374300440010752,
  "created_at" : "2016-01-27 16:05:35 +0000",
  "in_reply_to_screen_name" : "wilbanks",
  "in_reply_to_user_id_str" : "14245811",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 7, 30 ],
      "url" : "https:\/\/t.co\/l96lBydtup",
      "expanded_url" : "http:\/\/i.imgur.com\/YBaorIn.gifv",
      "display_url" : "i.imgur.com\/YBaorIn.gifv"
    } ]
  },
  "geo" : { },
  "id_str" : "692360487854587905",
  "text" : "today: https:\/\/t.co\/l96lBydtup",
  "id" : 692360487854587905,
  "created_at" : "2016-01-27 14:56:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 85 ],
      "url" : "https:\/\/t.co\/ZkZ2Byox7q",
      "expanded_url" : "http:\/\/onlinelibrary.wiley.com\/doi\/10.1111\/mpp.12344\/full",
      "display_url" : "onlinelibrary.wiley.com\/doi\/10.1111\/mp\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "692323440485863424",
  "text" : "Are lichens potential natural reservoirs for plant pathogens? https:\/\/t.co\/ZkZ2Byox7q",
  "id" : 692323440485863424,
  "created_at" : "2016-01-27 12:29:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "692295997972684800",
  "text" : "@stopifnot I\u2019m trying to improve, the least I can do is to own up to my shortcomings.",
  "id" : 692295997972684800,
  "created_at" : "2016-01-27 10:40:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 56 ],
      "url" : "https:\/\/t.co\/NjBaUUolPA",
      "expanded_url" : "https:\/\/twitter.com\/stopifnot\/status\/692286549443084288",
      "display_url" : "twitter.com\/stopifnot\/stat\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17249971589202, 8.62752333312679 ]
  },
  "id_str" : "692287249237610496",
  "text" : "Yes, sorry for failing again! M( https:\/\/t.co\/NjBaUUolPA",
  "id" : 692287249237610496,
  "created_at" : "2016-01-27 10:05:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/Xj43AFMVV4",
      "expanded_url" : "http:\/\/serialmentor.com\/blog\/2016\/1\/24\/I-failed-to-parasitize-an-established-clinical-researcher\/",
      "display_url" : "serialmentor.com\/blog\/2016\/1\/24\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "692285739002916865",
  "text" : "This makes me so angry. Why is this secretive stupidity even allowed to call itself science? https:\/\/t.co\/Xj43AFMVV4",
  "id" : 692285739002916865,
  "created_at" : "2016-01-27 09:59:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 78 ],
      "url" : "https:\/\/t.co\/zDfj3YoJqx",
      "expanded_url" : "https:\/\/twitter.com\/GigaScience\/status\/692267011565604868",
      "display_url" : "twitter.com\/GigaScience\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "692280937405620225",
  "text" : "Great to see the Bauhinia genome team getting started! https:\/\/t.co\/zDfj3YoJqx",
  "id" : 692280937405620225,
  "created_at" : "2016-01-27 09:40:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/K3lZ9KOdku",
      "expanded_url" : "https:\/\/twitter.com\/PhilippBayer\/status\/692262876099264513",
      "display_url" : "twitter.com\/PhilippBayer\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "692279892591955968",
  "text" : "\u00ABTextbooks pit Lamarck against Darwin in a mythical contest from which Darwin emerges victorious\u00BB https:\/\/t.co\/K3lZ9KOdku",
  "id" : 692279892591955968,
  "created_at" : "2016-01-27 09:36:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "692278378347499521",
  "geo" : { },
  "id_str" : "692279212749803520",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC yep, die schleppe ich aber nicht immer mit mir rum ;)",
  "id" : 692279212749803520,
  "in_reply_to_status_id" : 692278378347499521,
  "created_at" : "2016-01-27 09:33:20 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "692276450515361794",
  "geo" : { },
  "id_str" : "692277316928573441",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC I witnessed a huge fight between AE &amp; BE speakers over the concept of slippers once, so I\u2019d rather say \u201Eno\u201C. ;)",
  "id" : 692277316928573441,
  "in_reply_to_status_id" : 692276450515361794,
  "created_at" : "2016-01-27 09:25:48 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 7, 30 ],
      "url" : "https:\/\/t.co\/M2XECO7E8J",
      "expanded_url" : "http:\/\/49.media.tumblr.com\/223a6146a9e8266d16b855954ef5c034\/tumblr_ns26pxiUtF1t7lfy4o4_540.gif",
      "display_url" : "49.media.tumblr.com\/223a6146a9e826\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "692276118037118976",
  "geo" : { },
  "id_str" : "692276545843523585",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot https:\/\/t.co\/M2XECO7E8J",
  "id" : 692276545843523585,
  "in_reply_to_status_id" : 692276118037118976,
  "created_at" : "2016-01-27 09:22:45 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "692223841632915456",
  "geo" : { },
  "id_str" : "692272578677886977",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer congrats!",
  "id" : 692272578677886977,
  "in_reply_to_status_id" : 692223841632915456,
  "created_at" : "2016-01-27 09:06:59 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/qWa4B8q7tA",
      "expanded_url" : "https:\/\/gfycat.com\/SkeletalQueasyJaguarundi",
      "display_url" : "gfycat.com\/SkeletalQueasy\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "692259535755571200",
  "text" : "early morning, trying to get to the bathroom w\/o touching the cold floor too much https:\/\/t.co\/qWa4B8q7tA",
  "id" : 692259535755571200,
  "created_at" : "2016-01-27 08:15:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    }, {
      "name" : "Mozilla Science Lab",
      "screen_name" : "MozillaScience",
      "indices" : [ 10, 25 ],
      "id_str" : "1428575976",
      "id" : 1428575976
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "692065883456413703",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06124258259959, 8.818762769284861 ]
  },
  "id_str" : "692066845831077888",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon @MozillaScience awesome, finally having drinks again :D",
  "id" : 692066845831077888,
  "in_reply_to_status_id" : 692065883456413703,
  "created_at" : "2016-01-26 19:29:28 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 42 ],
      "url" : "https:\/\/t.co\/ZtqUftUO1m",
      "expanded_url" : "https:\/\/twitter.com\/kaythaney\/status\/692053827286102016",
      "display_url" : "twitter.com\/kaythaney\/stat\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06086645096183, 8.81840051161029 ]
  },
  "id_str" : "692064126089166849",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon this! :) https:\/\/t.co\/ZtqUftUO1m",
  "id" : 692064126089166849,
  "created_at" : "2016-01-26 19:18:40 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 49 ],
      "url" : "https:\/\/t.co\/aUrt6FffCZ",
      "expanded_url" : "http:\/\/arstechnica.com\/science\/2016\/01\/why-the-calorie-is-broken\/",
      "display_url" : "arstechnica.com\/science\/2016\/0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "692025652048990208",
  "text" : "Why the calorie is broken https:\/\/t.co\/aUrt6FffCZ",
  "id" : 692025652048990208,
  "created_at" : "2016-01-26 16:45:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/DQ8TJf9laV",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/691620074088722432",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "691620074088722432",
  "geo" : { },
  "id_str" : "692012793025957888",
  "in_reply_to_user_id" : 14286491,
  "text" : "Test setup for now: Let the smartwatch buzz when cluster jobs finish\/fail. https:\/\/t.co\/DQ8TJf9laV",
  "id" : 692012793025957888,
  "in_reply_to_status_id" : 691620074088722432,
  "created_at" : "2016-01-26 15:54:41 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "researchparasites",
      "indices" : [ 25, 43 ]
    } ],
    "urls" : [ {
      "indices" : [ 44, 67 ],
      "url" : "https:\/\/t.co\/xqyRMzv3kL",
      "expanded_url" : "https:\/\/media.giphy.com\/media\/5yLgoczyYq8vVWtDvTq\/giphy.gif",
      "display_url" : "media.giphy.com\/media\/5yLgoczy\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "691987870513549312",
  "text" : "it\u2019s data magicians, not #researchparasites https:\/\/t.co\/xqyRMzv3kL",
  "id" : 691987870513549312,
  "created_at" : "2016-01-26 14:15:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bj\u00F6rn Brembs",
      "screen_name" : "brembs",
      "indices" : [ 0, 7 ],
      "id_str" : "47876842",
      "id" : 47876842
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "691933465869164545",
  "geo" : { },
  "id_str" : "691976331739951104",
  "in_reply_to_user_id" : 47876842,
  "text" : "@brembs ouch, I somehow missed that article. My gut feeling regarding administration is somehow proven there\u2026",
  "id" : 691976331739951104,
  "in_reply_to_status_id" : 691933465869164545,
  "created_at" : "2016-01-26 13:29:48 +0000",
  "in_reply_to_screen_name" : "brembs",
  "in_reply_to_user_id_str" : "47876842",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bj\u00F6rn Brembs",
      "screen_name" : "brembs",
      "indices" : [ 0, 7 ],
      "id_str" : "47876842",
      "id" : 47876842
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "691922488473755648",
  "geo" : { },
  "id_str" : "691923565051011073",
  "in_reply_to_user_id" : 47876842,
  "text" : "@brembs yeah, I\u2019m so sick of it because I expected better from scientists\u2026",
  "id" : 691923565051011073,
  "in_reply_to_status_id" : 691922488473755648,
  "created_at" : "2016-01-26 10:00:07 +0000",
  "in_reply_to_screen_name" : "brembs",
  "in_reply_to_user_id_str" : "47876842",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "the Winnower",
      "screen_name" : "theWinnower",
      "indices" : [ 0, 12 ],
      "id_str" : "748018813",
      "id" : 748018813
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "691919483175333888",
  "geo" : { },
  "id_str" : "691921048439234560",
  "in_reply_to_user_id" : 748018813,
  "text" : "@theWinnower nice!",
  "id" : 691921048439234560,
  "in_reply_to_status_id" : 691919483175333888,
  "created_at" : "2016-01-26 09:50:07 +0000",
  "in_reply_to_screen_name" : "theWinnower",
  "in_reply_to_user_id_str" : "748018813",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "the Winnower",
      "screen_name" : "theWinnower",
      "indices" : [ 0, 12 ],
      "id_str" : "748018813",
      "id" : 748018813
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "691893966460076032",
  "geo" : { },
  "id_str" : "691919302035902464",
  "in_reply_to_user_id" : 748018813,
  "text" : "@theWinnower cool, how long are you staying?",
  "id" : 691919302035902464,
  "in_reply_to_status_id" : 691893966460076032,
  "created_at" : "2016-01-26 09:43:11 +0000",
  "in_reply_to_screen_name" : "theWinnower",
  "in_reply_to_user_id_str" : "748018813",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Edmunds",
      "screen_name" : "SCEdmunds",
      "indices" : [ 0, 10 ],
      "id_str" : "176024190",
      "id" : 176024190
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "691793718123323393",
  "geo" : { },
  "id_str" : "691795390610423809",
  "in_reply_to_user_id" : 176024190,
  "text" : "@SCEdmunds _now_ I\u2019m really curious on what\u2019s happening!",
  "id" : 691795390610423809,
  "in_reply_to_status_id" : 691793718123323393,
  "created_at" : "2016-01-26 01:30:48 +0000",
  "in_reply_to_screen_name" : "SCEdmunds",
  "in_reply_to_user_id_str" : "176024190",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 61 ],
      "url" : "https:\/\/t.co\/IsR6zRZ8aE",
      "expanded_url" : "https:\/\/xkcd.com\/978\/",
      "display_url" : "xkcd.com\/978\/"
    }, {
      "indices" : [ 62, 85 ],
      "url" : "https:\/\/t.co\/3maezHhMfq",
      "expanded_url" : "https:\/\/twitter.com\/michelebusby\/status\/691791615904595972",
      "display_url" : "twitter.com\/michelebusby\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "691792156827217921",
  "text" : "Yes, a perfect example of Citogenesis https:\/\/t.co\/IsR6zRZ8aE https:\/\/t.co\/3maezHhMfq",
  "id" : 691792156827217921,
  "created_at" : "2016-01-26 01:17:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Edmunds",
      "screen_name" : "SCEdmunds",
      "indices" : [ 0, 10 ],
      "id_str" : "176024190",
      "id" : 176024190
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "691790874062233600",
  "geo" : { },
  "id_str" : "691791301910663168",
  "in_reply_to_user_id" : 176024190,
  "text" : "@SCEdmunds you are deliberately trying to make your biography stranger, aren\u2019t you?",
  "id" : 691791301910663168,
  "in_reply_to_status_id" : 691790874062233600,
  "created_at" : "2016-01-26 01:14:33 +0000",
  "in_reply_to_screen_name" : "SCEdmunds",
  "in_reply_to_user_id_str" : "176024190",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John",
      "screen_name" : "JohnTuckerPhD",
      "indices" : [ 0, 14 ],
      "id_str" : "412362576",
      "id" : 412362576
    }, {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 15, 24 ],
      "id_str" : "14245811",
      "id" : 14245811
    }, {
      "name" : "NEJM",
      "screen_name" : "NEJM",
      "indices" : [ 50, 55 ],
      "id_str" : "25950355",
      "id" : 25950355
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "691780301501120512",
  "geo" : { },
  "id_str" : "691780893342617601",
  "in_reply_to_user_id" : 412362576,
  "text" : "@JohnTuckerPhD @wilbanks well, the editors of the @NEJM wanted to be angry in the first place and no discussion\u2026",
  "id" : 691780893342617601,
  "in_reply_to_status_id" : 691780301501120512,
  "created_at" : "2016-01-26 00:33:12 +0000",
  "in_reply_to_screen_name" : "JohnTuckerPhD",
  "in_reply_to_user_id_str" : "412362576",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John",
      "screen_name" : "JohnTuckerPhD",
      "indices" : [ 0, 14 ],
      "id_str" : "412362576",
      "id" : 412362576
    }, {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 15, 24 ],
      "id_str" : "14245811",
      "id" : 14245811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "691779213850996736",
  "geo" : { },
  "id_str" : "691780853026914304",
  "in_reply_to_user_id" : 412362576,
  "text" : "@JohnTuckerPhD @wilbanks and acting like that is just totally intellectually dishonest.",
  "id" : 691780853026914304,
  "in_reply_to_status_id" : 691779213850996736,
  "created_at" : "2016-01-26 00:33:02 +0000",
  "in_reply_to_screen_name" : "JohnTuckerPhD",
  "in_reply_to_user_id_str" : "412362576",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John",
      "screen_name" : "JohnTuckerPhD",
      "indices" : [ 0, 14 ],
      "id_str" : "412362576",
      "id" : 412362576
    }, {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 15, 24 ],
      "id_str" : "14245811",
      "id" : 14245811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "691779213850996736",
  "geo" : { },
  "id_str" : "691780552005914624",
  "in_reply_to_user_id" : 412362576,
  "text" : "@JohnTuckerPhD @wilbanks that\u2019s like \u201Esome people say \u2018all muslims are parasites\u2019, so we shld proceed w\/ caution letting them into country\u201C",
  "id" : 691780552005914624,
  "in_reply_to_status_id" : 691779213850996736,
  "created_at" : "2016-01-26 00:31:50 +0000",
  "in_reply_to_screen_name" : "JohnTuckerPhD",
  "in_reply_to_user_id_str" : "412362576",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John",
      "screen_name" : "JohnTuckerPhD",
      "indices" : [ 0, 14 ],
      "id_str" : "412362576",
      "id" : 412362576
    }, {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 15, 24 ],
      "id_str" : "14245811",
      "id" : 14245811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "691779213850996736",
  "geo" : { },
  "id_str" : "691780195813081088",
  "in_reply_to_user_id" : 412362576,
  "text" : "@JohnTuckerPhD @wilbanks and a \u201Eclarifying statement\u201C not even owning up to their mistake but still clinging to \u201Ebut other people said\u201C.",
  "id" : 691780195813081088,
  "in_reply_to_status_id" : 691779213850996736,
  "created_at" : "2016-01-26 00:30:25 +0000",
  "in_reply_to_screen_name" : "JohnTuckerPhD",
  "in_reply_to_user_id_str" : "412362576",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John",
      "screen_name" : "JohnTuckerPhD",
      "indices" : [ 0, 14 ],
      "id_str" : "412362576",
      "id" : 412362576
    }, {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 15, 24 ],
      "id_str" : "14245811",
      "id" : 14245811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "691779213850996736",
  "geo" : { },
  "id_str" : "691779899854577664",
  "in_reply_to_user_id" : 412362576,
  "text" : "@JohnTuckerPhD @wilbanks I read an editorial in a huge journal clearly approving of the language of those dubious unnamed clin. trialists\u2026",
  "id" : 691779899854577664,
  "in_reply_to_status_id" : 691779213850996736,
  "created_at" : "2016-01-26 00:29:15 +0000",
  "in_reply_to_screen_name" : "JohnTuckerPhD",
  "in_reply_to_user_id_str" : "412362576",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John",
      "screen_name" : "JohnTuckerPhD",
      "indices" : [ 0, 14 ],
      "id_str" : "412362576",
      "id" : 412362576
    }, {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 15, 24 ],
      "id_str" : "14245811",
      "id" : 14245811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "691776482348240897",
  "geo" : { },
  "id_str" : "691777468995342336",
  "in_reply_to_user_id" : 412362576,
  "text" : "@JohnTuckerPhD @wilbanks lolnope, I expect people to apologize for naively using\/reproducing nazi-like language.",
  "id" : 691777468995342336,
  "in_reply_to_status_id" : 691776482348240897,
  "created_at" : "2016-01-26 00:19:35 +0000",
  "in_reply_to_screen_name" : "JohnTuckerPhD",
  "in_reply_to_user_id_str" : "412362576",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "researchparasites",
      "indices" : [ 25, 43 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/hHbWMa5O7Y",
      "expanded_url" : "https:\/\/twitter.com\/NEJM\/status\/691637176954699776",
      "display_url" : "twitter.com\/NEJM\/status\/69\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "691776002662535168",
  "text" : "\u00ABNo, we never called you #researchparasites. We just said other people call scum like you research parasites.\u00BB https:\/\/t.co\/hHbWMa5O7Y",
  "id" : 691776002662535168,
  "created_at" : "2016-01-26 00:13:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "researchparasites",
      "indices" : [ 42, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 62, 85 ],
      "url" : "https:\/\/t.co\/hHbWMa5O7Y",
      "expanded_url" : "https:\/\/twitter.com\/NEJM\/status\/691637176954699776",
      "display_url" : "twitter.com\/NEJM\/status\/69\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "691775439115829250",
  "text" : "what kind of lame non-apology is this re: #researchparasites? https:\/\/t.co\/hHbWMa5O7Y",
  "id" : 691775439115829250,
  "created_at" : "2016-01-26 00:11:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "michael_nielsen",
      "screen_name" : "michael_nielsen",
      "indices" : [ 3, 19 ],
      "id_str" : "15626406",
      "id" : 15626406
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 75 ],
      "url" : "https:\/\/t.co\/cVWqPHNrP1",
      "expanded_url" : "http:\/\/www.nytimes.com\/2016\/01\/26\/business\/marvin-minsky-pioneer-in-artificial-intelligence-dies-at-88.html?_r=0",
      "display_url" : "nytimes.com\/2016\/01\/26\/bus\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "691771073004707840",
  "text" : "RT @michael_nielsen: Marvin Minsky has passed away: https:\/\/t.co\/cVWqPHNrP1 1\/",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 31, 54 ],
        "url" : "https:\/\/t.co\/cVWqPHNrP1",
        "expanded_url" : "http:\/\/www.nytimes.com\/2016\/01\/26\/business\/marvin-minsky-pioneer-in-artificial-intelligence-dies-at-88.html?_r=0",
        "display_url" : "nytimes.com\/2016\/01\/26\/bus\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "691770573249212418",
    "text" : "Marvin Minsky has passed away: https:\/\/t.co\/cVWqPHNrP1 1\/",
    "id" : 691770573249212418,
    "created_at" : "2016-01-25 23:52:11 +0000",
    "user" : {
      "name" : "michael_nielsen",
      "screen_name" : "michael_nielsen",
      "protected" : false,
      "id_str" : "15626406",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2756243281\/6d3d0ade1bd4364b75d7d0151dce38e5_normal.png",
      "id" : 15626406,
      "verified" : false
    }
  },
  "id" : 691771073004707840,
  "created_at" : "2016-01-25 23:54:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arikia\uD83D\uDCAB",
      "screen_name" : "arikia",
      "indices" : [ 0, 7 ],
      "id_str" : "71654283",
      "id" : 71654283
    }, {
      "name" : "Joseph McArthur",
      "screen_name" : "Mcarthur_Joe",
      "indices" : [ 8, 21 ],
      "id_str" : "478181304",
      "id" : 478181304
    }, {
      "name" : "Michael Eisen",
      "screen_name" : "mbeisen",
      "indices" : [ 22, 30 ],
      "id_str" : "19843630",
      "id" : 19843630
    }, {
      "name" : "Open Science",
      "screen_name" : "openscience",
      "indices" : [ 31, 43 ],
      "id_str" : "53560219",
      "id" : 53560219
    }, {
      "name" : "OpenCon",
      "screen_name" : "open_con",
      "indices" : [ 44, 53 ],
      "id_str" : "2452073258",
      "id" : 2452073258
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "691742483601035264",
  "geo" : { },
  "id_str" : "691742625158819841",
  "in_reply_to_user_id" : 71654283,
  "text" : "@arikia @Mcarthur_Joe @mbeisen @openscience @open_con Brussels in Nov 2015.",
  "id" : 691742625158819841,
  "in_reply_to_status_id" : 691742483601035264,
  "created_at" : "2016-01-25 22:01:08 +0000",
  "in_reply_to_screen_name" : "arikia",
  "in_reply_to_user_id_str" : "71654283",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/S7SG9euNZa",
      "expanded_url" : "https:\/\/twitter.com\/replicatedtypo\/status\/691737144314978304",
      "display_url" : "twitter.com\/replicatedtypo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "691738330577420289",
  "text" : "\u00ABI\u2019m skeptical that reducing each language to a point on the map yields a\u00A0proxy for the probability of borrowing.\u00BB https:\/\/t.co\/S7SG9euNZa",
  "id" : 691738330577420289,
  "created_at" : "2016-01-25 21:44:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bi\u1ECA\u1ECAy Meinke",
      "screen_name" : "billymeinke",
      "indices" : [ 0, 12 ],
      "id_str" : "296003222",
      "id" : 296003222
    }, {
      "name" : "Robert Davey",
      "screen_name" : "froggleston",
      "indices" : [ 13, 25 ],
      "id_str" : "53893339",
      "id" : 53893339
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "691730148148666368",
  "geo" : { },
  "id_str" : "691730258949705728",
  "in_reply_to_user_id" : 296003222,
  "text" : "@billymeinke @froggleston pre-mozfest planning session over at your place!",
  "id" : 691730258949705728,
  "in_reply_to_status_id" : 691730148148666368,
  "created_at" : "2016-01-25 21:12:00 +0000",
  "in_reply_to_screen_name" : "billymeinke",
  "in_reply_to_user_id_str" : "296003222",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bi\u1ECA\u1ECAy Meinke",
      "screen_name" : "billymeinke",
      "indices" : [ 0, 12 ],
      "id_str" : "296003222",
      "id" : 296003222
    }, {
      "name" : "Robert Davey",
      "screen_name" : "froggleston",
      "indices" : [ 13, 25 ],
      "id_str" : "53893339",
      "id" : 53893339
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "691728629789667328",
  "geo" : { },
  "id_str" : "691729673840128002",
  "in_reply_to_user_id" : 296003222,
  "text" : "@billymeinke @froggleston I think i wouldn\u2019t be there in time, even if I\u2019d board a plane right now :D",
  "id" : 691729673840128002,
  "in_reply_to_status_id" : 691728629789667328,
  "created_at" : "2016-01-25 21:09:40 +0000",
  "in_reply_to_screen_name" : "billymeinke",
  "in_reply_to_user_id_str" : "296003222",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert Davey",
      "screen_name" : "froggleston",
      "indices" : [ 0, 12 ],
      "id_str" : "53893339",
      "id" : 53893339
    }, {
      "name" : "Bi\u1ECA\u1ECAy Meinke",
      "screen_name" : "billymeinke",
      "indices" : [ 13, 25 ],
      "id_str" : "296003222",
      "id" : 296003222
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "691728493273440257",
  "geo" : { },
  "id_str" : "691728601234935808",
  "in_reply_to_user_id" : 53893339,
  "text" : "@froggleston @billymeinke see, you would feel right at home!",
  "id" : 691728601234935808,
  "in_reply_to_status_id" : 691728493273440257,
  "created_at" : "2016-01-25 21:05:24 +0000",
  "in_reply_to_screen_name" : "froggleston",
  "in_reply_to_user_id_str" : "53893339",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert Davey",
      "screen_name" : "froggleston",
      "indices" : [ 0, 12 ],
      "id_str" : "53893339",
      "id" : 53893339
    }, {
      "name" : "Bi\u1ECA\u1ECAy Meinke",
      "screen_name" : "billymeinke",
      "indices" : [ 13, 25 ],
      "id_str" : "296003222",
      "id" : 296003222
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "691724065367658496",
  "geo" : { },
  "id_str" : "691727827541037056",
  "in_reply_to_user_id" : 53893339,
  "text" : "@froggleston @billymeinke we can switch. I\u2019m sitting on a dark, windy, rainy island &amp; would be happy to help you out (taking1 for the team!)",
  "id" : 691727827541037056,
  "in_reply_to_status_id" : 691724065367658496,
  "created_at" : "2016-01-25 21:02:20 +0000",
  "in_reply_to_screen_name" : "froggleston",
  "in_reply_to_user_id_str" : "53893339",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Eisen",
      "screen_name" : "mbeisen",
      "indices" : [ 40, 48 ],
      "id_str" : "19843630",
      "id" : 19843630
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "opencon",
      "indices" : [ 76, 84 ]
    } ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/qliaAg8X1q",
      "expanded_url" : "https:\/\/twitter.com\/openscience\/status\/691705329348956160",
      "display_url" : "twitter.com\/openscience\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "691706014870196228",
  "text" : "If you\u2019re enjoying the current rants of @mbeisen, watch his presentation at #opencon, different topic, same fun. https:\/\/t.co\/qliaAg8X1q",
  "id" : 691706014870196228,
  "created_at" : "2016-01-25 19:35:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 57 ],
      "url" : "https:\/\/t.co\/Vx7LhBBOPS",
      "expanded_url" : "http:\/\/chapmangamo.tumblr.com\/post\/138024912385\/more-here-twitter-facebook-instagram-shop",
      "display_url" : "chapmangamo.tumblr.com\/post\/138024912\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "691657690674782208",
  "text" : "How to LOL in different languages https:\/\/t.co\/Vx7LhBBOPS",
  "id" : 691657690674782208,
  "created_at" : "2016-01-25 16:23:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 45 ],
      "url" : "https:\/\/t.co\/TWqa9E2xel",
      "expanded_url" : "http:\/\/www.michaeleisen.org\/blog\/?p=1825",
      "display_url" : "michaeleisen.org\/blog\/?p=1825"
    } ]
  },
  "geo" : { },
  "id_str" : "691657108744486913",
  "text" : "The Villain of CRISPR https:\/\/t.co\/TWqa9E2xel",
  "id" : 691657108744486913,
  "created_at" : "2016-01-25 16:21:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/QlaDvVAfaj",
      "expanded_url" : "http:\/\/www.vox.com\/science-and-health\/2016\/1\/22\/10811320\/journalists-social-science",
      "display_url" : "vox.com\/science-and-he\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "691623434934157314",
  "text" : "\u00ABWhat journalists get wrong about social science, according to 20\u00A0scientists\u00BB ignore \u201Esocial\u201C, applies everywhere https:\/\/t.co\/QlaDvVAfaj",
  "id" : 691623434934157314,
  "created_at" : "2016-01-25 14:07:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/QN1XZ0OOzB",
      "expanded_url" : "https:\/\/github.com\/variadico\/noti",
      "display_url" : "github.com\/variadico\/noti"
    } ]
  },
  "geo" : { },
  "id_str" : "691620074088722432",
  "text" : "Notifications on Linux\/Mac when your terminal processes finish, incl. Pushbullet support. https:\/\/t.co\/QN1XZ0OOzB",
  "id" : 691620074088722432,
  "created_at" : "2016-01-25 13:54:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/rV2SrELSHH",
      "expanded_url" : "http:\/\/www.natureconservancy.ca\/en\/blog\/lichen-10-reasons-to-make-it.html",
      "display_url" : "natureconservancy.ca\/en\/blog\/lichen\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "691615037048229890",
  "text" : "\u00ABIt\u2019s like snorkeling in coral reefs, without getting wet.\u00BB 10 reasons to make lichens your new favourite hobby https:\/\/t.co\/rV2SrELSHH",
  "id" : 691615037048229890,
  "created_at" : "2016-01-25 13:34:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "J.B.S. Haldane",
      "screen_name" : "JBS_Haldane",
      "indices" : [ 14, 26 ],
      "id_str" : "1326144174",
      "id" : 1326144174
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "691611420039852032",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17217245742163, 8.627597786487058 ]
  },
  "id_str" : "691613149854879744",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @JBS_Haldane sweet, thanks!",
  "id" : 691613149854879744,
  "in_reply_to_status_id" : 691611420039852032,
  "created_at" : "2016-01-25 13:26:39 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "J.B.S. Haldane",
      "screen_name" : "JBS_Haldane",
      "indices" : [ 11, 23 ],
      "id_str" : "1326144174",
      "id" : 1326144174
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "691610396873113600",
  "text" : "I like how @JBS_Haldane shows God\u2019s inordinate fondness of beetles every single day.",
  "id" : 691610396873113600,
  "created_at" : "2016-01-25 13:15:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sonya Tadrowski",
      "screen_name" : "SonyaTadrowski",
      "indices" : [ 3, 18 ],
      "id_str" : "3659907268",
      "id" : 3659907268
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "691596212458426368",
  "text" : "RT @SonyaTadrowski: Happy birthday to Jane Richardson, the biochemist who developed the ribbon diagram to visualise protein structure! http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SonyaTadrowski\/status\/691574585150410752\/photo\/1",
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/NsxS8QOVdZ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CZj3Tt9UMAQLgff.jpg",
        "id_str" : "691574460927717380",
        "id" : 691574460927717380,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CZj3Tt9UMAQLgff.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 420
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 420
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 420
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 420
        } ],
        "display_url" : "pic.twitter.com\/NsxS8QOVdZ"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/SonyaTadrowski\/status\/691574585150410752\/photo\/1",
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/NsxS8QOVdZ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CZj3a26UcAAOzaD.png",
        "id_str" : "691574583590154240",
        "id" : 691574583590154240,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CZj3a26UcAAOzaD.png",
        "sizes" : [ {
          "h" : 516,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 599,
          "resize" : "fit",
          "w" : 789
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 599,
          "resize" : "fit",
          "w" : 789
        }, {
          "h" : 599,
          "resize" : "fit",
          "w" : 789
        } ],
        "display_url" : "pic.twitter.com\/NsxS8QOVdZ"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/SonyaTadrowski\/status\/691574585150410752\/photo\/1",
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/NsxS8QOVdZ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CZj3U8AUYAAg0c7.jpg",
        "id_str" : "691574481878278144",
        "id" : 691574481878278144,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CZj3U8AUYAAg0c7.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/NsxS8QOVdZ"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "691574585150410752",
    "text" : "Happy birthday to Jane Richardson, the biochemist who developed the ribbon diagram to visualise protein structure! https:\/\/t.co\/NsxS8QOVdZ",
    "id" : 691574585150410752,
    "created_at" : "2016-01-25 10:53:24 +0000",
    "user" : {
      "name" : "Sonya Tadrowski",
      "screen_name" : "SonyaTadrowski",
      "protected" : false,
      "id_str" : "3659907268",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/808564976042446849\/GZqoRisM_normal.jpg",
      "id" : 3659907268,
      "verified" : false
    }
  },
  "id" : 691596212458426368,
  "created_at" : "2016-01-25 12:19:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "691584831432437761",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17779954636535, 8.62432214282776 ]
  },
  "id_str" : "691586994569371648",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer I\u2019d hope so!",
  "id" : 691586994569371648,
  "in_reply_to_status_id" : 691584831432437761,
  "created_at" : "2016-01-25 11:42:43 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Viertausendhertz",
      "screen_name" : "4000hertz",
      "indices" : [ 115, 125 ],
      "id_str" : "3397272850",
      "id" : 3397272850
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "691572935891554304",
  "text" : "2016: \u201EThe first German podcasting network\u201C starts and it features more guys named Christian than women\u2026 Well done @4000hertz!",
  "id" : 691572935891554304,
  "created_at" : "2016-01-25 10:46:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uD83D\uDCABKelsey Merkley \uD83D\uDCAB",
      "screen_name" : "bella_velo",
      "indices" : [ 0, 11 ],
      "id_str" : "6745972",
      "id" : 6745972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/phKNL5y2DN",
      "expanded_url" : "https:\/\/media.giphy.com\/media\/v7L4uQWY8Ntvi\/giphy.gif",
      "display_url" : "media.giphy.com\/media\/v7L4uQWY\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "691556915697041408",
  "geo" : { },
  "id_str" : "691557356832964608",
  "in_reply_to_user_id" : 6745972,
  "text" : "@bella_velo oh, you need more support, in that case let me leave this here. https:\/\/t.co\/phKNL5y2DN",
  "id" : 691557356832964608,
  "in_reply_to_status_id" : 691556915697041408,
  "created_at" : "2016-01-25 09:44:57 +0000",
  "in_reply_to_screen_name" : "bella_velo",
  "in_reply_to_user_id_str" : "6745972",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uD83D\uDCABKelsey Merkley \uD83D\uDCAB",
      "screen_name" : "bella_velo",
      "indices" : [ 0, 11 ],
      "id_str" : "6745972",
      "id" : 6745972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 35 ],
      "url" : "https:\/\/t.co\/Ajg2sl6Xo0",
      "expanded_url" : "https:\/\/media.giphy.com\/media\/Om8iOmzO9NxAY\/giphy.gif",
      "display_url" : "media.giphy.com\/media\/Om8iOmzO\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "691555355671826432",
  "geo" : { },
  "id_str" : "691556703905669120",
  "in_reply_to_user_id" : 6745972,
  "text" : "@bella_velo https:\/\/t.co\/Ajg2sl6Xo0",
  "id" : 691556703905669120,
  "in_reply_to_status_id" : 691555355671826432,
  "created_at" : "2016-01-25 09:42:21 +0000",
  "in_reply_to_screen_name" : "bella_velo",
  "in_reply_to_user_id_str" : "6745972",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "691537804107522048",
  "geo" : { },
  "id_str" : "691551151892885504",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer oh, cmon, if it\u2019s Brassica you can practically throw every name at it &amp; will stick as there\u2019s one fitting B. whateveracea ;)",
  "id" : 691551151892885504,
  "in_reply_to_status_id" : 691537804107522048,
  "created_at" : "2016-01-25 09:20:17 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 36 ],
      "url" : "https:\/\/t.co\/zIiOKIp9S5",
      "expanded_url" : "http:\/\/marxist-cats.tumblr.com\/",
      "display_url" : "marxist-cats.tumblr.com"
    } ]
  },
  "geo" : { },
  "id_str" : "691550278575865857",
  "text" : "Marxist Cats https:\/\/t.co\/zIiOKIp9S5",
  "id" : 691550278575865857,
  "created_at" : "2016-01-25 09:16:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "691544122499424256",
  "text" : "The MEGAN command line mode is really frustrating to use. Is there any *good* manual for it?",
  "id" : 691544122499424256,
  "created_at" : "2016-01-25 08:52:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Torsten Seemann",
      "screen_name" : "torstenseemann",
      "indices" : [ 14, 29 ],
      "id_str" : "42558652",
      "id" : 42558652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/fanhwdOy4m",
      "expanded_url" : "http:\/\/lifehacker.com\/how-to-make-your-smartphone-automatically-unlock-your-s-510592193",
      "display_url" : "lifehacker.com\/how-to-make-yo\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "691469561481146368",
  "geo" : { },
  "id_str" : "691542451773968384",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @torstenseemann are some nearly-ready solutions you could hack together, using smartphone as token https:\/\/t.co\/fanhwdOy4m",
  "id" : 691542451773968384,
  "in_reply_to_status_id" : 691469561481146368,
  "created_at" : "2016-01-25 08:45:43 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 23, 29 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 53 ],
      "url" : "https:\/\/t.co\/bHt3luX9kv",
      "expanded_url" : "https:\/\/twitter.com\/PhilippBayer\/status\/691461977864929280",
      "display_url" : "twitter.com\/PhilippBayer\/s\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17229008002382, 8.627636156019324 ]
  },
  "id_str" : "691535273583366144",
  "text" : "Color and Language \/cc @Lobot https:\/\/t.co\/bHt3luX9kv",
  "id" : 691535273583366144,
  "created_at" : "2016-01-25 08:17:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17165305623402, 8.628102143455692 ]
  },
  "id_str" : "691535083895918592",
  "text" : "Finally got my car repaired, which means my daily commute is shortened by 1 1\/2 hours compared to public transport. \uD83D\uDC96\uD83D\uDE97",
  "id" : 691535083895918592,
  "created_at" : "2016-01-25 08:16:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 0, 9 ],
      "id_str" : "14245811",
      "id" : 14245811
    }, {
      "name" : "Dawn Field",
      "screen_name" : "fiedawn",
      "indices" : [ 10, 18 ],
      "id_str" : "18589743",
      "id" : 18589743
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "691350547987877888",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11403657214604, 8.753431790938672 ]
  },
  "id_str" : "691375658153447425",
  "in_reply_to_user_id" : 14245811,
  "text" : "@wilbanks @fiedawn now I want a snowstorm too, just so I have an excuse!",
  "id" : 691375658153447425,
  "in_reply_to_status_id" : 691350547987877888,
  "created_at" : "2016-01-24 21:42:56 +0000",
  "in_reply_to_screen_name" : "wilbanks",
  "in_reply_to_user_id_str" : "14245811",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nazeefa",
      "screen_name" : "NazeefaFatima",
      "indices" : [ 3, 17 ],
      "id_str" : "37054704",
      "id" : 37054704
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "womeninbioinformatics",
      "indices" : [ 83, 105 ]
    }, {
      "text" : "WomenInSTEM",
      "indices" : [ 106, 118 ]
    } ],
    "urls" : [ {
      "indices" : [ 59, 82 ],
      "url" : "https:\/\/t.co\/mFMtATaqpN",
      "expanded_url" : "https:\/\/twitter.com\/NazeefaFatima\/lists\/bioinformatics-girl-power",
      "display_url" : "twitter.com\/NazeefaFatima\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "691371721958539264",
  "text" : "RT @NazeefaFatima: Women in bioinformatics (Twitter List): https:\/\/t.co\/mFMtATaqpN #womeninbioinformatics #WomenInSTEM",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "womeninbioinformatics",
        "indices" : [ 64, 86 ]
      }, {
        "text" : "WomenInSTEM",
        "indices" : [ 87, 99 ]
      } ],
      "urls" : [ {
        "indices" : [ 40, 63 ],
        "url" : "https:\/\/t.co\/mFMtATaqpN",
        "expanded_url" : "https:\/\/twitter.com\/NazeefaFatima\/lists\/bioinformatics-girl-power",
        "display_url" : "twitter.com\/NazeefaFatima\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "691320597406695428",
    "text" : "Women in bioinformatics (Twitter List): https:\/\/t.co\/mFMtATaqpN #womeninbioinformatics #WomenInSTEM",
    "id" : 691320597406695428,
    "created_at" : "2016-01-24 18:04:09 +0000",
    "user" : {
      "name" : "Nazeefa",
      "screen_name" : "NazeefaFatima",
      "protected" : false,
      "id_str" : "37054704",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/930210077885202432\/DY8D8hGM_normal.jpg",
      "id" : 37054704,
      "verified" : false
    }
  },
  "id" : 691371721958539264,
  "created_at" : "2016-01-24 21:27:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "beau",
      "screen_name" : "beaugunderson",
      "indices" : [ 0, 14 ],
      "id_str" : "5746882",
      "id" : 5746882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "691324708067741696",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1140381723873, 8.753435588810305 ]
  },
  "id_str" : "691326369230356480",
  "in_reply_to_user_id" : 5746882,
  "text" : "@beaugunderson oh noes :( first time this happened to me. The Apple Watch plays nice so far.",
  "id" : 691326369230356480,
  "in_reply_to_status_id" : 691324708067741696,
  "created_at" : "2016-01-24 18:27:05 +0000",
  "in_reply_to_screen_name" : "beaugunderson",
  "in_reply_to_user_id_str" : "5746882",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u24EA Rik Smith-Unna \uD83C\uDDF0\uD83C\uDDEA",
      "screen_name" : "blahah404",
      "indices" : [ 0, 10 ],
      "id_str" : "99173786",
      "id" : 99173786
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "691285446857465856",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11416162226492, 8.750986142353732 ]
  },
  "id_str" : "691287987833929729",
  "in_reply_to_user_id" : 99173786,
  "text" : "@blahah404 who needs usability when you can be a ninja rockstar presenter!",
  "id" : 691287987833929729,
  "in_reply_to_status_id" : 691285446857465856,
  "created_at" : "2016-01-24 15:54:34 +0000",
  "in_reply_to_screen_name" : "blahah404",
  "in_reply_to_user_id_str" : "99173786",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u24EA Rik Smith-Unna \uD83C\uDDF0\uD83C\uDDEA",
      "screen_name" : "blahah404",
      "indices" : [ 48, 58 ],
      "id_str" : "99173786",
      "id" : 99173786
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 84 ],
      "url" : "https:\/\/t.co\/kz8fP9wyzI",
      "expanded_url" : "https:\/\/github.com\/tybenz\/vimdeck",
      "display_url" : "github.com\/tybenz\/vimdeck"
    } ]
  },
  "geo" : { },
  "id_str" : "691284716482359296",
  "text" : "Using vim as a presentation tool. something for @blahah404?  https:\/\/t.co\/kz8fP9wyzI",
  "id" : 691284716482359296,
  "created_at" : "2016-01-24 15:41:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonas",
      "screen_name" : "lsanoj",
      "indices" : [ 0, 7 ],
      "id_str" : "18918915",
      "id" : 18918915
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "691260212498530304",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11403779336867, 8.753438212808772 ]
  },
  "id_str" : "691261963079434241",
  "in_reply_to_user_id" : 18918915,
  "text" : "@lsanoj danke f\u00FCr den Tipp :)",
  "id" : 691261963079434241,
  "in_reply_to_status_id" : 691260212498530304,
  "created_at" : "2016-01-24 14:11:09 +0000",
  "in_reply_to_screen_name" : "lsanoj",
  "in_reply_to_user_id_str" : "18918915",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "691245469708763137",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11403341979904, 8.753365960991239 ]
  },
  "id_str" : "691245897439711232",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC most likely, in the worst case there\u2019s always a paper\/case study to write ;)",
  "id" : 691245897439711232,
  "in_reply_to_status_id" : 691245469708763137,
  "created_at" : "2016-01-24 13:07:19 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "691243097053855744",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11412032790869, 8.75099651886735 ]
  },
  "id_str" : "691243483575754752",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC i only managed to pass out once, overdosing on ether in the lab.",
  "id" : 691243483575754752,
  "in_reply_to_status_id" : 691243097053855744,
  "created_at" : "2016-01-24 12:57:43 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "691242661269913600",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1140397415873, 8.753431252090518 ]
  },
  "id_str" : "691243146735435776",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC that\u2019s because you\u2019re doing psych. Doing biology and quantified self you will end up doing the dermatology bits\u00A0at one point ;)",
  "id" : 691243146735435776,
  "in_reply_to_status_id" : 691242661269913600,
  "created_at" : "2016-01-24 12:56:23 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ToxX",
      "screen_name" : "ToxXInFlames",
      "indices" : [ 0, 13 ],
      "id_str" : "1421360166",
      "id" : 1421360166
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "691241643803066368",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1140397415873, 8.753431252090518 ]
  },
  "id_str" : "691242003196186624",
  "in_reply_to_user_id" : 1421360166,
  "text" : "@ToxXInFlames not sure yet, let\u2019s wait a day and see what happens :D",
  "id" : 691242003196186624,
  "in_reply_to_status_id" : 691241643803066368,
  "created_at" : "2016-01-24 12:51:50 +0000",
  "in_reply_to_screen_name" : "ToxXInFlames",
  "in_reply_to_user_id_str" : "1421360166",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "691241602359169025",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1140397415873, 8.753431252090518 ]
  },
  "id_str" : "691241898573484032",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC sometimes you have to suffer if you want to collect data ;)",
  "id" : 691241898573484032,
  "in_reply_to_status_id" : 691241602359169025,
  "created_at" : "2016-01-24 12:51:25 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fitbit Support",
      "screen_name" : "FitbitSupport",
      "indices" : [ 0, 14 ],
      "id_str" : "476258341",
      "id" : 476258341
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "691232511590989824",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11403660267288, 8.753432193893026 ]
  },
  "id_str" : "691233897259073536",
  "in_reply_to_user_id" : 476258341,
  "text" : "@FitbitSupport will do, thanks.",
  "id" : 691233897259073536,
  "in_reply_to_status_id" : 691232511590989824,
  "created_at" : "2016-01-24 12:19:38 +0000",
  "in_reply_to_screen_name" : "FitbitSupport",
  "in_reply_to_user_id_str" : "476258341",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael R. Crusoe",
      "screen_name" : "biocrusoe",
      "indices" : [ 0, 10 ],
      "id_str" : "17645638",
      "id" : 17645638
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "691231453720547328",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11403660267288, 8.753432193893026 ]
  },
  "id_str" : "691233857358684160",
  "in_reply_to_user_id" : 17645638,
  "text" : "@biocrusoe that\u2019s a first for me :D",
  "id" : 691233857358684160,
  "in_reply_to_status_id" : 691231453720547328,
  "created_at" : "2016-01-24 12:19:28 +0000",
  "in_reply_to_screen_name" : "biocrusoe",
  "in_reply_to_user_id_str" : "17645638",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fitbit",
      "screen_name" : "fitbit",
      "indices" : [ 18, 25 ],
      "id_str" : "17424053",
      "id" : 17424053
    }, {
      "name" : "Fitbit Support",
      "screen_name" : "FitbitSupport",
      "indices" : [ 47, 61 ],
      "id_str" : "476258341",
      "id" : 476258341
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/691231323550261248\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/vFoRgz5pdp",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CZe_OMzW0AAMzNj.jpg",
      "id_str" : "691231318500364288",
      "id" : 691231318500364288,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CZe_OMzW0AAMzNj.jpg",
      "sizes" : [ {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 3264,
        "resize" : "fit",
        "w" : 2448
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      } ],
      "display_url" : "pic.twitter.com\/vFoRgz5pdp"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11421189182448, 8.75330798328738 ]
  },
  "id_str" : "691231323550261248",
  "text" : "After wearing the @fitbit Charge HR. Any tips, @FitbitSupport (shouldn\u2019t this be a thing of the past w\/ the Force)? https:\/\/t.co\/vFoRgz5pdp",
  "id" : 691231323550261248,
  "created_at" : "2016-01-24 12:09:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "691046397865529344",
  "text" : "\u00ABThe maxim that flying time is wasted time liberates me from my anxieties and guilt feelings, and it strips me of all ambitions.\u00BB \uD83D\uDC4D",
  "id" : 691046397865529344,
  "created_at" : "2016-01-23 23:54:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 51 ],
      "url" : "https:\/\/t.co\/S5pjkBlpTl",
      "expanded_url" : "http:\/\/i.imgur.com\/h8lVgAg.gif",
      "display_url" : "i.imgur.com\/h8lVgAg.gif"
    } ]
  },
  "geo" : { },
  "id_str" : "691043873343275014",
  "text" : "improving on the puppy eyes https:\/\/t.co\/S5pjkBlpTl",
  "id" : 691043873343275014,
  "created_at" : "2016-01-23 23:44:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nyborg",
      "screen_name" : "ny_borg",
      "indices" : [ 0, 8 ],
      "id_str" : "570156398",
      "id" : 570156398
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 51 ],
      "url" : "https:\/\/t.co\/veI0jwtSW8",
      "expanded_url" : "http:\/\/netstorage.discovery.com\/feeds\/brightcove\/asset-stills\/dsc\/140148149285314551400401197_YETI_Credible_Authentic_Evidence.jpg",
      "display_url" : "netstorage.discovery.com\/feeds\/brightco\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "691022218940280832",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11403810115213, 8.75342854240899 ]
  },
  "id_str" : "691022517864132609",
  "in_reply_to_user_id" : 570156398,
  "text" : "@ny_borg photo evidence! ;) https:\/\/t.co\/veI0jwtSW8",
  "id" : 691022517864132609,
  "in_reply_to_status_id" : 691022218940280832,
  "created_at" : "2016-01-23 22:19:41 +0000",
  "in_reply_to_screen_name" : "ny_borg",
  "in_reply_to_user_id_str" : "570156398",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Brechler",
      "screen_name" : "gutsle",
      "indices" : [ 0, 7 ],
      "id_str" : "837535866",
      "id" : 837535866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "690988904929959936",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11396375001139, 8.753401140397223 ]
  },
  "id_str" : "690992555505405952",
  "in_reply_to_user_id" : 837535866,
  "text" : "@gutsle und bessere Kandidaten :3",
  "id" : 690992555505405952,
  "in_reply_to_status_id" : 690988904929959936,
  "created_at" : "2016-01-23 20:20:37 +0000",
  "in_reply_to_screen_name" : "gutsle",
  "in_reply_to_user_id_str" : "837535866",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Deb the Author",
      "screen_name" : "DebTheAuthor",
      "indices" : [ 3, 16 ],
      "id_str" : "544612778",
      "id" : 544612778
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/DebTheAuthor\/status\/690965538357559296\/photo\/1",
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/aM6sj7Cqfw",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CZbNfHQUkAEzjTx.jpg",
      "id_str" : "690965527255093249",
      "id" : 690965527255093249,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CZbNfHQUkAEzjTx.jpg",
      "sizes" : [ {
        "h" : 1953,
        "resize" : "fit",
        "w" : 515
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 316
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 179
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1953,
        "resize" : "fit",
        "w" : 515
      } ],
      "display_url" : "pic.twitter.com\/aM6sj7Cqfw"
    } ],
    "hashtags" : [ {
      "text" : "diversitymatters",
      "indices" : [ 34, 51 ]
    }, {
      "text" : "writeinclusively",
      "indices" : [ 52, 69 ]
    }, {
      "text" : "WeNeedDiverseBooks",
      "indices" : [ 70, 89 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "690990757642113025",
  "text" : "RT @DebTheAuthor: This. All. Day. #diversitymatters #writeinclusively #WeNeedDiverseBooks https:\/\/t.co\/aM6sj7Cqfw",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/DebTheAuthor\/status\/690965538357559296\/photo\/1",
        "indices" : [ 72, 95 ],
        "url" : "https:\/\/t.co\/aM6sj7Cqfw",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CZbNfHQUkAEzjTx.jpg",
        "id_str" : "690965527255093249",
        "id" : 690965527255093249,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CZbNfHQUkAEzjTx.jpg",
        "sizes" : [ {
          "h" : 1953,
          "resize" : "fit",
          "w" : 515
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 316
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 179
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1953,
          "resize" : "fit",
          "w" : 515
        } ],
        "display_url" : "pic.twitter.com\/aM6sj7Cqfw"
      } ],
      "hashtags" : [ {
        "text" : "diversitymatters",
        "indices" : [ 16, 33 ]
      }, {
        "text" : "writeinclusively",
        "indices" : [ 34, 51 ]
      }, {
        "text" : "WeNeedDiverseBooks",
        "indices" : [ 52, 71 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "690965538357559296",
    "text" : "This. All. Day. #diversitymatters #writeinclusively #WeNeedDiverseBooks https:\/\/t.co\/aM6sj7Cqfw",
    "id" : 690965538357559296,
    "created_at" : "2016-01-23 18:33:16 +0000",
    "user" : {
      "name" : "Deb the Author",
      "screen_name" : "DebTheAuthor",
      "protected" : false,
      "id_str" : "544612778",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/657566442368274432\/jeQrKYPT_normal.jpg",
      "id" : 544612778,
      "verified" : false
    }
  },
  "id" : 690990757642113025,
  "created_at" : "2016-01-23 20:13:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "snowmaggedon2016",
      "indices" : [ 17, 34 ]
    } ],
    "urls" : [ {
      "indices" : [ 35, 58 ],
      "url" : "https:\/\/t.co\/eJzkJ2W23I",
      "expanded_url" : "https:\/\/twitter.com\/TheBloodVoyage\/status\/690971911514374144",
      "display_url" : "twitter.com\/TheBloodVoyage\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11403853554355, 8.753426372531832 ]
  },
  "id_str" : "690978767116865537",
  "text" : "Just in time for #snowmaggedon2016 https:\/\/t.co\/eJzkJ2W23I",
  "id" : 690978767116865537,
  "created_at" : "2016-01-23 19:25:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Lauer",
      "screen_name" : "Schmidtlepp",
      "indices" : [ 0, 12 ],
      "id_str" : "59085146",
      "id" : 59085146
    }, {
      "name" : "@F0O0",
      "screen_name" : "F0O0",
      "indices" : [ 13, 18 ],
      "id_str" : "105943845",
      "id" : 105943845
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "690932823616790528",
  "geo" : { },
  "id_str" : "690965616962977792",
  "in_reply_to_user_id" : 59085146,
  "text" : "@Schmidtlepp @F0O0 hinterher ist man immer Lauer  \u00AF\\_(\u30C4)_\/\u00AF",
  "id" : 690965616962977792,
  "in_reply_to_status_id" : 690932823616790528,
  "created_at" : "2016-01-23 18:33:35 +0000",
  "in_reply_to_screen_name" : "Schmidtlepp",
  "in_reply_to_user_id_str" : "59085146",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "werwitwe",
      "screen_name" : "nachtrabend",
      "indices" : [ 0, 12 ],
      "id_str" : "1393009718",
      "id" : 1393009718
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "690964223799730179",
  "geo" : { },
  "id_str" : "690964502012108802",
  "in_reply_to_user_id" : 1393009718,
  "text" : "@nachtrabend ich glaube es liegt an irgendwelchen weirden Cookies\/tempor\u00E4ren Files.",
  "id" : 690964502012108802,
  "in_reply_to_status_id" : 690964223799730179,
  "created_at" : "2016-01-23 18:29:09 +0000",
  "in_reply_to_screen_name" : "nachtrabend",
  "in_reply_to_user_id_str" : "1393009718",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "690963179581657088",
  "text" : "If I try to login to PayPal from Chrome it doesn\u2019t work, giving an undefined error, leading me back to start. Using Safari it works.",
  "id" : 690963179581657088,
  "created_at" : "2016-01-23 18:23:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 33 ],
      "url" : "https:\/\/t.co\/wR9uRlDQp0",
      "expanded_url" : "http:\/\/www.smbc-comics.com\/index.php?id=3996",
      "display_url" : "smbc-comics.com\/index.php?id=3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "690940880937750528",
  "text" : "Go Fungi! https:\/\/t.co\/wR9uRlDQp0",
  "id" : 690940880937750528,
  "created_at" : "2016-01-23 16:55:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 53, 59 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 84 ],
      "url" : "https:\/\/t.co\/4107JG5DBX",
      "expanded_url" : "http:\/\/feedproxy.google.com\/~r\/plosone\/PLoSONE\/~3\/o78FNYNtKaA\/info%3Adoi%2F10.1371%2Fjournal.pone.0147073",
      "display_url" : "feedproxy.google.com\/~r\/plosone\/PLo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "690859483128528896",
  "text" : "Large-Scale Analysis of Zipf\u2019s Law in English Texts \/@Lobot  https:\/\/t.co\/4107JG5DBX",
  "id" : 690859483128528896,
  "created_at" : "2016-01-23 11:31:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/7W1j8ThTAr",
      "expanded_url" : "http:\/\/feed.torrentfreak.com\/~r\/Torrentfreak\/~3\/edRQQPaaib4\/",
      "display_url" : "feed.torrentfreak.com\/~r\/Torrentfrea\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "690856731040190464",
  "text" : "This looks like a good way for figuring out how to circumvent the geoblocking of Netflix. https:\/\/t.co\/7W1j8ThTAr",
  "id" : 690856731040190464,
  "created_at" : "2016-01-23 11:20:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 66 ],
      "url" : "https:\/\/t.co\/6QGD1ptnVQ",
      "expanded_url" : "https:\/\/twitter.com\/grahamfarmelo\/status\/690793676642062336",
      "display_url" : "twitter.com\/grahamfarmelo\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11403917439263, 8.753421699132556 ]
  },
  "id_str" : "690845289926803456",
  "text" : "That\u2019s one cool way to fund your research. https:\/\/t.co\/6QGD1ptnVQ",
  "id" : 690845289926803456,
  "created_at" : "2016-01-23 10:35:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 50 ],
      "url" : "https:\/\/t.co\/tr8LeyJtJM",
      "expanded_url" : "https:\/\/en.wikipedia.org\/wiki\/Der_St%C3%BCrmer",
      "display_url" : "en.wikipedia.org\/wiki\/Der_St%C3\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "690537085082681345",
  "geo" : { },
  "id_str" : "690537399974268928",
  "in_reply_to_user_id" : 14286491,
  "text" : "\u2026than \u201EDer St\u00FCrmer\u201C, 1944\u2026 https:\/\/t.co\/tr8LeyJtJM",
  "id" : 690537399974268928,
  "in_reply_to_status_id" : 690537085082681345,
  "created_at" : "2016-01-22 14:12:00 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NEJM",
      "screen_name" : "NEJM",
      "indices" : [ 32, 37 ],
      "id_str" : "25950355",
      "id" : 25950355
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IAmAResearchParasite",
      "indices" : [ 52, 73 ]
    } ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/MhHUuYNeGp",
      "expanded_url" : "https:\/\/s-media-cache-ak0.pinimg.com\/736x\/03\/2f\/91\/032f91f1925ff0ddb4b84270fea20b96.jpg",
      "display_url" : "s-media-cache-ak0.pinimg.com\/736x\/03\/2f\/91\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "690537085082681345",
  "text" : "If you feel the stereotype that @NEJM is using with #IAmAResearchParasite is somehow familiar, look no further\u2026 https:\/\/t.co\/MhHUuYNeGp",
  "id" : 690537085082681345,
  "created_at" : "2016-01-22 14:10:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Viktor Senderov",
      "screen_name" : "vsenderov",
      "indices" : [ 0, 10 ],
      "id_str" : "254318473",
      "id" : 254318473
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "690536808929705984",
  "geo" : { },
  "id_str" : "690537014089904129",
  "in_reply_to_user_id" : 254318473,
  "text" : "@vsenderov thx, will use another image source then",
  "id" : 690537014089904129,
  "in_reply_to_status_id" : 690536808929705984,
  "created_at" : "2016-01-22 14:10:28 +0000",
  "in_reply_to_screen_name" : "vsenderov",
  "in_reply_to_user_id_str" : "254318473",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Barbara Prainsack",
      "screen_name" : "BPrainsack",
      "indices" : [ 3, 14 ],
      "id_str" : "201632630",
      "id" : 201632630
    }, {
      "name" : "PLOS Genetics",
      "screen_name" : "PLOSGenetics",
      "indices" : [ 118, 131 ],
      "id_str" : "388345704",
      "id" : 388345704
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/peSKz6evVU",
      "expanded_url" : "http:\/\/buff.ly\/1nBy9pU",
      "display_url" : "buff.ly\/1nBy9pU"
    } ]
  },
  "geo" : { },
  "id_str" : "690529360919556096",
  "text" : "RT @BPrainsack: Just out: Dyke et al, \u201CConsent Codes: Upholding Standard Data Use Conditions\u201D https:\/\/t.co\/peSKz6evVU @PLOSGenetics",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "PLOS Genetics",
        "screen_name" : "PLOSGenetics",
        "indices" : [ 102, 115 ],
        "id_str" : "388345704",
        "id" : 388345704
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 78, 101 ],
        "url" : "https:\/\/t.co\/peSKz6evVU",
        "expanded_url" : "http:\/\/buff.ly\/1nBy9pU",
        "display_url" : "buff.ly\/1nBy9pU"
      } ]
    },
    "geo" : { },
    "id_str" : "690529099220152320",
    "text" : "Just out: Dyke et al, \u201CConsent Codes: Upholding Standard Data Use Conditions\u201D https:\/\/t.co\/peSKz6evVU @PLOSGenetics",
    "id" : 690529099220152320,
    "created_at" : "2016-01-22 13:39:01 +0000",
    "user" : {
      "name" : "Barbara Prainsack",
      "screen_name" : "BPrainsack",
      "protected" : false,
      "id_str" : "201632630",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/927171665917890561\/w5htgqHc_normal.jpg",
      "id" : 201632630,
      "verified" : false
    }
  },
  "id" : 690529360919556096,
  "created_at" : "2016-01-22 13:40:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "researchparasites",
      "indices" : [ 110, 128 ]
    }, {
      "text" : "cladistics",
      "indices" : [ 129, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "690528719346241536",
  "text" : "This week in \u2018things science doesn\u2019t need anymore\u2019: journals, revisionist history, patents and angry old men\u2026 #researchparasites #cladistics",
  "id" : 690528719346241536,
  "created_at" : "2016-01-22 13:37:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 48 ],
      "url" : "https:\/\/t.co\/YdSAZh3JZS",
      "expanded_url" : "https:\/\/twitter.com\/TheBloodVoyage\/status\/690518993082384384",
      "display_url" : "twitter.com\/TheBloodVoyage\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "690525200425816065",
  "text" : "It\u2019s really either or. \uD83D\uDE02 https:\/\/t.co\/YdSAZh3JZS",
  "id" : 690525200425816065,
  "created_at" : "2016-01-22 13:23:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "690471515779907584",
  "text" : "Sham invites are getting more &amp; more ridiculous: \u201Esolicit your gracious presence as speaker at Exhibition on Natural &amp; Alternative Medicine\u201C",
  "id" : 690471515779907584,
  "created_at" : "2016-01-22 09:50:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "690448439402958848",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11040394213646, 8.69277007936837 ]
  },
  "id_str" : "690449201080078336",
  "in_reply_to_user_id" : 14286491,
  "text" : "Though fitting the picture you\u2019re painting by designating a whole category of people as parasites\u2026",
  "id" : 690449201080078336,
  "in_reply_to_status_id" : 690448439402958848,
  "created_at" : "2016-01-22 08:21:32 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/9q3wsJVqHt",
      "expanded_url" : "https:\/\/giphy.com\/gifs\/uxqGq6fSkfFaE",
      "display_url" : "giphy.com\/gifs\/uxqGq6fSk\u2026"
    }, {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/26m6iaSbxd",
      "expanded_url" : "https:\/\/twitter.com\/russpoldrack\/status\/690395754523918338",
      "display_url" : "twitter.com\/russpoldrack\/s\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11043015346279, 8.692695932518502 ]
  },
  "id_str" : "690448439402958848",
  "text" : "Does science really need this bullshit language of war? sent from the trenches\u2026 https:\/\/t.co\/9q3wsJVqHt https:\/\/t.co\/26m6iaSbxd",
  "id" : 690448439402958848,
  "created_at" : "2016-01-22 08:18:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nazeefa",
      "screen_name" : "NazeefaFatima",
      "indices" : [ 0, 14 ],
      "id_str" : "37054704",
      "id" : 37054704
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "690317725944643588",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11399190017015, 8.753327357944828 ]
  },
  "id_str" : "690317871440924672",
  "in_reply_to_user_id" : 37054704,
  "text" : "@NazeefaFatima over here it\u2019s a page usually.",
  "id" : 690317871440924672,
  "in_reply_to_status_id" : 690317725944643588,
  "created_at" : "2016-01-21 23:39:40 +0000",
  "in_reply_to_screen_name" : "NazeefaFatima",
  "in_reply_to_user_id_str" : "37054704",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 61 ],
      "url" : "https:\/\/t.co\/2a98SL8cFp",
      "expanded_url" : "https:\/\/twitter.com\/martibartfast\/status\/690094459510472704",
      "display_url" : "twitter.com\/martibartfast\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "690280368369459201",
  "text" : "This is Bam, he didn\u2019t listen to Sam. https:\/\/t.co\/2a98SL8cFp",
  "id" : 690280368369459201,
  "created_at" : "2016-01-21 21:10:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/690277830672977920\/photo\/1",
      "indices" : [ 8, 31 ],
      "url" : "https:\/\/t.co\/ep1Ptu6lZE",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CZRcB5PWEAAwyvY.jpg",
      "id_str" : "690277830509334528",
      "id" : 690277830509334528,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CZRcB5PWEAAwyvY.jpg",
      "sizes" : [ {
        "h" : 1353,
        "resize" : "fit",
        "w" : 1352
      }, {
        "h" : 1353,
        "resize" : "fit",
        "w" : 1352
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 679
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 1199
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/ep1Ptu6lZE"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "690277830672977920",
  "text" : "Glitchy https:\/\/t.co\/ep1Ptu6lZE",
  "id" : 690277830672977920,
  "created_at" : "2016-01-21 21:00:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 55 ],
      "url" : "https:\/\/t.co\/vJMpfTt7N0",
      "expanded_url" : "https:\/\/twitter.com\/talyarkoni\/status\/690193020310921216",
      "display_url" : "twitter.com\/talyarkoni\/sta\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11404747059434, 8.753356200621562 ]
  },
  "id_str" : "690242643104763904",
  "text" : "Who bug-tracks the bug tracker? https:\/\/t.co\/vJMpfTt7N0",
  "id" : 690242643104763904,
  "created_at" : "2016-01-21 18:40:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    }, {
      "name" : "Cormac R. McDarwin",
      "screen_name" : "TheBloodVoyage",
      "indices" : [ 7, 22 ],
      "id_str" : "4825733537",
      "id" : 4825733537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "690142775413727232",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11041371399946, 8.692784515049233 ]
  },
  "id_str" : "690195203148357632",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot @TheBloodVoyage should I make that another requirement of the bot? :D",
  "id" : 690195203148357632,
  "in_reply_to_status_id" : 690142775413727232,
  "created_at" : "2016-01-21 15:32:14 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 83 ],
      "url" : "https:\/\/t.co\/NMcWVUJklt",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/690115570042290176",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "690115570042290176",
  "geo" : { },
  "id_str" : "690115815799197696",
  "in_reply_to_user_id" : 14286491,
  "text" : "that somehow ended up sounding like a very academic insult\u2026 https:\/\/t.co\/NMcWVUJklt",
  "id" : 690115815799197696,
  "in_reply_to_status_id" : 690115570042290176,
  "created_at" : "2016-01-21 10:16:46 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 0, 9 ],
      "id_str" : "14245811",
      "id" : 14245811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "689515010746224641",
  "geo" : { },
  "id_str" : "690115570042290176",
  "in_reply_to_user_id" : 14245811,
  "text" : "@wilbanks tried it, no fun: Britney rarely tweets anything long enough to even form a second order markov chain.",
  "id" : 690115570042290176,
  "in_reply_to_status_id" : 689515010746224641,
  "created_at" : "2016-01-21 10:15:48 +0000",
  "in_reply_to_screen_name" : "wilbanks",
  "in_reply_to_user_id_str" : "14245811",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ravna",
      "screen_name" : "Ravna",
      "indices" : [ 0, 6 ],
      "id_str" : "292968981",
      "id" : 292968981
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "690106004202217472",
  "geo" : { },
  "id_str" : "690106959828238336",
  "in_reply_to_user_id" : 292968981,
  "text" : "@Ravna das freut mich :)",
  "id" : 690106959828238336,
  "in_reply_to_status_id" : 690106004202217472,
  "created_at" : "2016-01-21 09:41:35 +0000",
  "in_reply_to_screen_name" : "Ravna",
  "in_reply_to_user_id_str" : "292968981",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonas",
      "screen_name" : "lsanoj",
      "indices" : [ 0, 7 ],
      "id_str" : "18918915",
      "id" : 18918915
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "690102171178770432",
  "geo" : { },
  "id_str" : "690102717612711936",
  "in_reply_to_user_id" : 18918915,
  "text" : "@lsanoj noch ganz :)",
  "id" : 690102717612711936,
  "in_reply_to_status_id" : 690102171178770432,
  "created_at" : "2016-01-21 09:24:44 +0000",
  "in_reply_to_screen_name" : "lsanoj",
  "in_reply_to_user_id_str" : "18918915",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/rvDWmIocpz",
      "expanded_url" : "https:\/\/medium.com\/life-learning\/your-life-is-tetris-stop-playing-it-like-chess-4baac6b2750d#.mcbxj0h5d",
      "display_url" : "medium.com\/life-learning\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "690100937587888128",
  "text" : "\u00ABIt\u2019s repetitive,impossible to win, driven by luck! To me, Tetris became the truest representation of life there is\u00BB https:\/\/t.co\/rvDWmIocpz",
  "id" : 690100937587888128,
  "created_at" : "2016-01-21 09:17:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dierk Haasis",
      "screen_name" : "Evo2Me",
      "indices" : [ 0, 7 ],
      "id_str" : "22910316",
      "id" : 22910316
    }, {
      "name" : "ali",
      "screen_name" : "zoonpolitikon",
      "indices" : [ 8, 22 ],
      "id_str" : "13040652",
      "id" : 13040652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "690093564999630848",
  "geo" : { },
  "id_str" : "690093690296074240",
  "in_reply_to_user_id" : 22910316,
  "text" : "@Evo2Me @zoonpolitikon a series of tubes? :D",
  "id" : 690093690296074240,
  "in_reply_to_status_id" : 690093564999630848,
  "created_at" : "2016-01-21 08:48:51 +0000",
  "in_reply_to_screen_name" : "Evo2Me",
  "in_reply_to_user_id_str" : "22910316",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/yrhR56qvBW",
      "expanded_url" : "http:\/\/www.vox.com\/2016\/1\/20\/10795246\/muslim-parents-islamophobia",
      "display_url" : "vox.com\/2016\/1\/20\/1079\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "690092686158794753",
  "text" : "\u201CThe talk\u201D: 6 Muslim parents on what they tell their kids about\u00A0Islamophobia https:\/\/t.co\/yrhR56qvBW",
  "id" : 690092686158794753,
  "created_at" : "2016-01-21 08:44:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dierk Haasis",
      "screen_name" : "Evo2Me",
      "indices" : [ 0, 7 ],
      "id_str" : "22910316",
      "id" : 22910316
    }, {
      "name" : "ali",
      "screen_name" : "zoonpolitikon",
      "indices" : [ 8, 22 ],
      "id_str" : "13040652",
      "id" : 13040652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "690092315457757184",
  "geo" : { },
  "id_str" : "690092455761412096",
  "in_reply_to_user_id" : 22910316,
  "text" : "@Evo2Me @zoonpolitikon bei EP ist das aber fast by design eingebaut ;)",
  "id" : 690092455761412096,
  "in_reply_to_status_id" : 690092315457757184,
  "created_at" : "2016-01-21 08:43:57 +0000",
  "in_reply_to_screen_name" : "Evo2Me",
  "in_reply_to_user_id_str" : "22910316",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ali",
      "screen_name" : "zoonpolitikon",
      "indices" : [ 0, 14 ],
      "id_str" : "13040652",
      "id" : 13040652
    }, {
      "name" : "Dierk Haasis",
      "screen_name" : "Evo2Me",
      "indices" : [ 15, 22 ],
      "id_str" : "22910316",
      "id" : 22910316
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "690089379906338817",
  "geo" : { },
  "id_str" : "690091965761847296",
  "in_reply_to_user_id" : 13040652,
  "text" : "@zoonpolitikon @Evo2Me und history versucht sich meist nicht an billigem biologismus.",
  "id" : 690091965761847296,
  "in_reply_to_status_id" : 690089379906338817,
  "created_at" : "2016-01-21 08:42:00 +0000",
  "in_reply_to_screen_name" : "zoonpolitikon",
  "in_reply_to_user_id_str" : "13040652",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dierk Haasis",
      "screen_name" : "Evo2Me",
      "indices" : [ 0, 7 ],
      "id_str" : "22910316",
      "id" : 22910316
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "690088012424806400",
  "geo" : { },
  "id_str" : "690088095102963714",
  "in_reply_to_user_id" : 22910316,
  "text" : "@Evo2Me that\u2019s what history generally is, isn\u2019t it? :p",
  "id" : 690088095102963714,
  "in_reply_to_status_id" : 690088012424806400,
  "created_at" : "2016-01-21 08:26:37 +0000",
  "in_reply_to_screen_name" : "Evo2Me",
  "in_reply_to_user_id_str" : "22910316",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/fGYJOsx7W1",
      "expanded_url" : "http:\/\/boingboing.net\/2016\/01\/20\/solving-the-longbow-puzzle.html#more-444444",
      "display_url" : "boingboing.net\/2016\/01\/20\/sol\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "690087749932716033",
  "text" : "Solving the \"Longbow Puzzle\": why did France and Scotland keep their inferior crossbows? https:\/\/t.co\/fGYJOsx7W1",
  "id" : 690087749932716033,
  "created_at" : "2016-01-21 08:25:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1724560199339, 8.62749852995414 ]
  },
  "id_str" : "690080553408839680",
  "text" : "Getting run over by an \u2018urgent medical supplies\u2019-driver. Great way to start the day.",
  "id" : 690080553408839680,
  "created_at" : "2016-01-21 07:56:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Eisen",
      "screen_name" : "mbeisen",
      "indices" : [ 0, 8 ],
      "id_str" : "19843630",
      "id" : 19843630
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "690074339723603968",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17372376326552, 8.62770820079449 ]
  },
  "id_str" : "690079190973050880",
  "in_reply_to_user_id" : 19843630,
  "text" : "@mbeisen \uD83D\uDE4F\uD83D\uDE02",
  "id" : 690079190973050880,
  "in_reply_to_status_id" : 690074339723603968,
  "created_at" : "2016-01-21 07:51:14 +0000",
  "in_reply_to_screen_name" : "mbeisen",
  "in_reply_to_user_id_str" : "19843630",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Eisen",
      "screen_name" : "mbeisen",
      "indices" : [ 0, 8 ],
      "id_str" : "19843630",
      "id" : 19843630
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 32 ],
      "url" : "https:\/\/t.co\/yCPcvofTe2",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/689816039291502592",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "689662679330398209",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11041362607079, 8.69278498736724 ]
  },
  "id_str" : "690073245266137088",
  "in_reply_to_user_id" : 19843630,
  "text" : "@mbeisen https:\/\/t.co\/yCPcvofTe2",
  "id" : 690073245266137088,
  "in_reply_to_status_id" : 689662679330398209,
  "created_at" : "2016-01-21 07:27:37 +0000",
  "in_reply_to_screen_name" : "mbeisen",
  "in_reply_to_user_id_str" : "19843630",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/OpeA4BOske",
      "expanded_url" : "https:\/\/twitter.com\/MicrobiomDigest\/status\/689950090706993153",
      "display_url" : "twitter.com\/MicrobiomDiges\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "689952938765238274",
  "text" : "Taking pipeline bioinformatics to the next level with the Fraud Generator 2.0 https:\/\/t.co\/OpeA4BOske",
  "id" : 689952938765238274,
  "created_at" : "2016-01-20 23:29:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 65 ],
      "url" : "https:\/\/t.co\/9wepFuR60F",
      "expanded_url" : "https:\/\/twitter.com\/mslopatto\/status\/689916138357030912",
      "display_url" : "twitter.com\/mslopatto\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "689918745742032896",
  "text" : "this would make them so much less douchey https:\/\/t.co\/9wepFuR60F",
  "id" : 689918745742032896,
  "created_at" : "2016-01-20 21:13:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonas",
      "screen_name" : "lsanoj",
      "indices" : [ 0, 7 ],
      "id_str" : "18918915",
      "id" : 18918915
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "689907965323776000",
  "geo" : { },
  "id_str" : "689908189526102017",
  "in_reply_to_user_id" : 18918915,
  "text" : "@lsanoj gut das wir irgendwann angefangen haben Jahreszahlen vor die News zu schreiben ;)",
  "id" : 689908189526102017,
  "in_reply_to_status_id" : 689907965323776000,
  "created_at" : "2016-01-20 20:31:44 +0000",
  "in_reply_to_screen_name" : "lsanoj",
  "in_reply_to_user_id_str" : "18918915",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonas",
      "screen_name" : "lsanoj",
      "indices" : [ 0, 7 ],
      "id_str" : "18918915",
      "id" : 18918915
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "689907302539857920",
  "geo" : { },
  "id_str" : "689907449139175429",
  "in_reply_to_user_id" : 18918915,
  "text" : "@lsanoj das sagen bei uns auch alle. Und deshalb ist es Bootstrap ;)",
  "id" : 689907449139175429,
  "in_reply_to_status_id" : 689907302539857920,
  "created_at" : "2016-01-20 20:28:48 +0000",
  "in_reply_to_screen_name" : "lsanoj",
  "in_reply_to_user_id_str" : "18918915",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonas",
      "screen_name" : "lsanoj",
      "indices" : [ 0, 7 ],
      "id_str" : "18918915",
      "id" : 18918915
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "689905634431647744",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11402011098875, 8.753350228054297 ]
  },
  "id_str" : "689906015752581120",
  "in_reply_to_user_id" : 18918915,
  "text" : "@lsanoj ey! :D",
  "id" : 689906015752581120,
  "in_reply_to_status_id" : 689905634431647744,
  "created_at" : "2016-01-20 20:23:06 +0000",
  "in_reply_to_screen_name" : "lsanoj",
  "in_reply_to_user_id_str" : "18918915",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jennifer Ouellette",
      "screen_name" : "JenLucPiquant",
      "indices" : [ 3, 17 ],
      "id_str" : "128292609",
      "id" : 128292609
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/apmp9RqPlM",
      "expanded_url" : "http:\/\/jezebel.com\/how-one-man-tried-to-write-women-out-of-crispr-the-big-1753996281",
      "display_url" : "jezebel.com\/how-one-man-tr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "689857106372116481",
  "text" : "RT @JenLucPiquant: How One Man Tried to Write Women Out of CRISPR, the Biggest Biotech Innovation in Decades https:\/\/t.co\/apmp9RqPlM",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 90, 113 ],
        "url" : "https:\/\/t.co\/apmp9RqPlM",
        "expanded_url" : "http:\/\/jezebel.com\/how-one-man-tried-to-write-women-out-of-crispr-the-big-1753996281",
        "display_url" : "jezebel.com\/how-one-man-tr\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "689855667050528768",
    "text" : "How One Man Tried to Write Women Out of CRISPR, the Biggest Biotech Innovation in Decades https:\/\/t.co\/apmp9RqPlM",
    "id" : 689855667050528768,
    "created_at" : "2016-01-20 17:03:02 +0000",
    "user" : {
      "name" : "Jennifer Ouellette",
      "screen_name" : "JenLucPiquant",
      "protected" : false,
      "id_str" : "128292609",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/525328824133636096\/85rXVsFk_normal.jpeg",
      "id" : 128292609,
      "verified" : true
    }
  },
  "id" : 689857106372116481,
  "created_at" : "2016-01-20 17:08:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "689815542727884800",
  "geo" : { },
  "id_str" : "689816039291502592",
  "in_reply_to_user_id" : 14286491,
  "text" : "tl;dr: Eric Lander for Nobel Prize in Literature.",
  "id" : 689816039291502592,
  "in_reply_to_status_id" : 689815542727884800,
  "created_at" : "2016-01-20 14:25:34 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 88 ],
      "url" : "https:\/\/t.co\/7xIjOsbvXp",
      "expanded_url" : "http:\/\/genotopia.scienceblog.com\/573\/a-whig-history-of-crispr\/",
      "display_url" : "genotopia.scienceblog.com\/573\/a-whig-his\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "689815542727884800",
  "text" : "Now w\/ addendum on the gender dynamics: A Whig History of CRISPR https:\/\/t.co\/7xIjOsbvXp",
  "id" : 689815542727884800,
  "created_at" : "2016-01-20 14:23:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 67 ],
      "url" : "https:\/\/t.co\/XHZ9EKM1FD",
      "expanded_url" : "http:\/\/i.imgur.com\/rkZ1Pm5.jpg",
      "display_url" : "i.imgur.com\/rkZ1Pm5.jpg"
    } ]
  },
  "in_reply_to_status_id_str" : "689806314399219712",
  "geo" : { },
  "id_str" : "689806917544366081",
  "in_reply_to_user_id" : 14286491,
  "text" : "in short: this might happen a bit too often https:\/\/t.co\/XHZ9EKM1FD",
  "id" : 689806917544366081,
  "in_reply_to_status_id" : 689806314399219712,
  "created_at" : "2016-01-20 13:49:19 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/BLIFLVBPnE",
      "expanded_url" : "https:\/\/motherboard.vice.com\/en_uk\/read\/i-tried-to-hack-hours-off-my-sleep-time-by-going-polyphasic",
      "display_url" : "motherboard.vice.com\/en_uk\/read\/i-t\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "689806314399219712",
  "text" : "the big issues with going poly: scheduling &amp; intraday chrononormativity https:\/\/t.co\/BLIFLVBPnE",
  "id" : 689806314399219712,
  "created_at" : "2016-01-20 13:46:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 71 ],
      "url" : "https:\/\/t.co\/lt72Q0iwjY",
      "expanded_url" : "http:\/\/replygif.net\/i\/627.gif",
      "display_url" : "replygif.net\/i\/627.gif"
    } ]
  },
  "in_reply_to_status_id_str" : "689772993426264065",
  "geo" : { },
  "id_str" : "689790231629971456",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer soon, you and me and the internet https:\/\/t.co\/lt72Q0iwjY",
  "id" : 689790231629971456,
  "in_reply_to_status_id" : 689772993426264065,
  "created_at" : "2016-01-20 12:43:01 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "689771535226122240",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17785406090794, 8.631155764988387 ]
  },
  "id_str" : "689772410925662208",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer rad, i didn\u2019t know this folder is still in my Dropbox!",
  "id" : 689772410925662208,
  "in_reply_to_status_id" : 689771535226122240,
  "created_at" : "2016-01-20 11:32:12 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Torsten Seemann",
      "screen_name" : "torstenseemann",
      "indices" : [ 0, 15 ],
      "id_str" : "42558652",
      "id" : 42558652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 90 ],
      "url" : "https:\/\/t.co\/ibxVlOMxYR",
      "expanded_url" : "https:\/\/github.com\/StuntsPT\/4Pipe4\/commit\/a1808cecce7025a3fb90d64a337ccbe08619267a",
      "display_url" : "github.com\/StuntsPT\/4Pipe\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "689763588106420224",
  "geo" : { },
  "id_str" : "689765462884904960",
  "in_reply_to_user_id" : 42558652,
  "text" : "@torstenseemann first commits to the project are from 2012 though. https:\/\/t.co\/ibxVlOMxYR",
  "id" : 689765462884904960,
  "in_reply_to_status_id" : 689763588106420224,
  "created_at" : "2016-01-20 11:04:36 +0000",
  "in_reply_to_screen_name" : "torstenseemann",
  "in_reply_to_user_id_str" : "42558652",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "689751592413728768",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17249257860843, 8.627519062924817 ]
  },
  "id_str" : "689754995592400898",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer oh, could you share? :D",
  "id" : 689754995592400898,
  "in_reply_to_status_id" : 689751592413728768,
  "created_at" : "2016-01-20 10:23:00 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "689660269656571904",
  "geo" : { },
  "id_str" : "689742791128281088",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer must be even more, think we did our first PAML-based work back in 2008? \uD83D\uDE31",
  "id" : 689742791128281088,
  "in_reply_to_status_id" : 689660269656571904,
  "created_at" : "2016-01-20 09:34:30 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cormac R. McDarwin",
      "screen_name" : "TheBloodVoyage",
      "indices" : [ 3, 18 ],
      "id_str" : "4825733537",
      "id" : 4825733537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "689742448436846592",
  "text" : "RT @TheBloodVoyage: But when once on the ground. Who has not been paid; perhaps the alleged reasons were rather more. Narrative of Missiona\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.github.com\/gedankenstuecke\/\" rel=\"nofollow\"\u003EBloodMeridian\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "689733832535334913",
    "text" : "But when once on the ground. Who has not been paid; perhaps the alleged reasons were rather more. Narrative of Missionary Enterprise,.",
    "id" : 689733832535334913,
    "created_at" : "2016-01-20 08:58:54 +0000",
    "user" : {
      "name" : "Cormac R. McDarwin",
      "screen_name" : "TheBloodVoyage",
      "protected" : false,
      "id_str" : "4825733537",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/689413531142217728\/O05elrRt_normal.jpg",
      "id" : 4825733537,
      "verified" : false
    }
  },
  "id" : 689742448436846592,
  "created_at" : "2016-01-20 09:33:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "deray",
      "screen_name" : "deray",
      "indices" : [ 22, 28 ],
      "id_str" : "29417304",
      "id" : 29417304
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "blacklivesmatter",
      "indices" : [ 35, 52 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/ishs01JFBy",
      "expanded_url" : "http:\/\/fusion.net\/story\/256983\/black-lives-matter-deray-mckesson-stephen-colbert-white-privilege\/?utm_source=twitter&utm_medium=social&utm_campaign=socialshare&utm_content=desktop+left",
      "display_url" : "fusion.net\/story\/256983\/b\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "689737705283031040",
  "text" : "Stephen Colbert &amp; @deray about #blacklivesmatter and white privilege on MLK Day https:\/\/t.co\/ishs01JFBy",
  "id" : 689737705283031040,
  "created_at" : "2016-01-20 09:14:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "689736826903396352",
  "geo" : { },
  "id_str" : "689737024996270080",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer if they\u2019d kept you in Australia that would\u2019ve been close to the prison acknowledgement ;)",
  "id" : 689737024996270080,
  "in_reply_to_status_id" : 689736826903396352,
  "created_at" : "2016-01-20 09:11:36 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 3, 16 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 18, 34 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "689736875981021185",
  "text" : "RT @PhilippBayer: @gedankenstuecke My thesis has \"I would like to thank the Au government for making me wait for my visa so I had time to f\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 0, 16 ],
        "id_str" : "14286491",
        "id" : 14286491
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "689735952474963968",
    "geo" : { },
    "id_str" : "689736826903396352",
    "in_reply_to_user_id" : 14286491,
    "text" : "@gedankenstuecke My thesis has \"I would like to thank the Au government for making me wait for my visa so I had time to finish this thesis.\"",
    "id" : 689736826903396352,
    "in_reply_to_status_id" : 689735952474963968,
    "created_at" : "2016-01-20 09:10:48 +0000",
    "in_reply_to_screen_name" : "gedankenstuecke",
    "in_reply_to_user_id_str" : "14286491",
    "user" : {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "protected" : false,
      "id_str" : "121777206",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2013711027\/IMG_1088_normal.png",
      "id" : 121777206,
      "verified" : false
    }
  },
  "id" : 689736875981021185,
  "created_at" : "2016-01-20 09:11:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 121, 144 ],
      "url" : "https:\/\/t.co\/emFW9KPRvS",
      "expanded_url" : "https:\/\/www.timeshighereducation.com\/blog\/best-academic-acknowledgements-ever",
      "display_url" : "timeshighereducation.com\/blog\/best-acad\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "689735952474963968",
  "text" : "Acknowledgements \u00ABWe appreciate the very candid critical insights of 2 anonymous reviewers, M. Gompper, &amp; K. Beard.\u00BB https:\/\/t.co\/emFW9KPRvS",
  "id" : 689735952474963968,
  "created_at" : "2016-01-20 09:07:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 63 ],
      "url" : "https:\/\/t.co\/v1vgiohPZk",
      "expanded_url" : "http:\/\/dnadigest.org\/why-do-i-want-to-share-my-genetic-data\/",
      "display_url" : "dnadigest.org\/why-do-i-want-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "689733661130952704",
  "text" : "Why do I want to share my genetic data? https:\/\/t.co\/v1vgiohPZk",
  "id" : 689733661130952704,
  "created_at" : "2016-01-20 08:58:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cormac R. McDarwin",
      "screen_name" : "TheBloodVoyage",
      "indices" : [ 3, 18 ],
      "id_str" : "4825733537",
      "id" : 4825733537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "689585595530739712",
  "text" : "RT @TheBloodVoyage: The size and there a thousand feet high, and windmills standing on the crest and looked at the Zoological Society. Big \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.github.com\/gedankenstuecke\/\" rel=\"nofollow\"\u003EBloodMeridian\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "689462008060649474",
    "text" : "The size and there a thousand feet high, and windmills standing on the crest and looked at the Zoological Society. Big as life.",
    "id" : 689462008060649474,
    "created_at" : "2016-01-19 14:58:46 +0000",
    "user" : {
      "name" : "Cormac R. McDarwin",
      "screen_name" : "TheBloodVoyage",
      "protected" : false,
      "id_str" : "4825733537",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/689413531142217728\/O05elrRt_normal.jpg",
      "id" : 4825733537,
      "verified" : false
    }
  },
  "id" : 689585595530739712,
  "created_at" : "2016-01-19 23:09:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/MwNFiDbgKU",
      "expanded_url" : "http:\/\/www.theallium.com\/policy\/cladistics-journal-awards-prize-to-eric-lander-for-ability-to-reconstruct-history\/",
      "display_url" : "theallium.com\/policy\/cladist\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "689539107064827905",
  "text" : "Cladistics Journal Awards Prize To Eric Lander For Ability To Reconstruct History https:\/\/t.co\/MwNFiDbgKU",
  "id" : 689539107064827905,
  "created_at" : "2016-01-19 20:05:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 0, 9 ],
      "id_str" : "14245811",
      "id" : 14245811
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 10, 23 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "689515010746224641",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11405171024082, 8.753422220171325 ]
  },
  "id_str" : "689518590433890305",
  "in_reply_to_user_id" : 14245811,
  "text" : "@wilbanks @PhilippBayer sure, only need to get my hands on a plain text file of Suttree, so if you happen to have one ;)",
  "id" : 689518590433890305,
  "in_reply_to_status_id" : 689515010746224641,
  "created_at" : "2016-01-19 18:43:37 +0000",
  "in_reply_to_screen_name" : "wilbanks",
  "in_reply_to_user_id_str" : "14245811",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 0, 9 ],
      "id_str" : "14245811",
      "id" : 14245811
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 62, 75 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "689513831802875904",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11399703656475, 8.753508724991029 ]
  },
  "id_str" : "689514815501529088",
  "in_reply_to_user_id" : 14245811,
  "text" : "@wilbanks that\u2019s good to know, finally I know someone besides @PhilippBayer and me who enjoys him!",
  "id" : 689514815501529088,
  "in_reply_to_status_id" : 689513831802875904,
  "created_at" : "2016-01-19 18:28:37 +0000",
  "in_reply_to_screen_name" : "wilbanks",
  "in_reply_to_user_id_str" : "14245811",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cormac R. McDarwin",
      "screen_name" : "TheBloodVoyage",
      "indices" : [ 25, 40 ],
      "id_str" : "4825733537",
      "id" : 4825733537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/h2rGIRZiB7",
      "expanded_url" : "http:\/\/thebloodvoyage.tumblr.com\/",
      "display_url" : "thebloodvoyage.tumblr.com"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11407582622898, 8.75333884747501 ]
  },
  "id_str" : "689513374091190272",
  "text" : "ICYMI: Did a markov-bot; @TheBloodVoyage mixes McCarthy\u2019s Blood Meridian w\/ Darwin\u2019s Voyage of the Beagle. tumblr: https:\/\/t.co\/h2rGIRZiB7",
  "id" : 689513374091190272,
  "created_at" : "2016-01-19 18:22:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul-Olivier Dehaye",
      "screen_name" : "podehaye",
      "indices" : [ 3, 12 ],
      "id_str" : "2219841242",
      "id" : 2219841242
    }, {
      "name" : "Turn Inc.",
      "screen_name" : "TurnPlatform",
      "indices" : [ 27, 40 ],
      "id_str" : "57069242",
      "id" : 57069242
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EUdataP",
      "indices" : [ 108, 116 ]
    }, {
      "text" : "SafeHarbor",
      "indices" : [ 117, 128 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/hbJNiQ3XIg",
      "expanded_url" : "https:\/\/medium.com\/@pdehaye\/how-i-peeked-at-the-personal-data-a-billion-dollar-company-holds-about-me-61a446642cd9#.pc4rx3bh8",
      "display_url" : "medium.com\/@pdehaye\/how-i\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "689500904110866434",
  "text" : "RT @podehaye: I had to sue @TurnPlatform for access to my personal data, but I won. https:\/\/t.co\/hbJNiQ3XIg #EUdataP #SafeHarbor",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Turn Inc.",
        "screen_name" : "TurnPlatform",
        "indices" : [ 13, 26 ],
        "id_str" : "57069242",
        "id" : 57069242
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "EUdataP",
        "indices" : [ 94, 102 ]
      }, {
        "text" : "SafeHarbor",
        "indices" : [ 103, 114 ]
      } ],
      "urls" : [ {
        "indices" : [ 70, 93 ],
        "url" : "https:\/\/t.co\/hbJNiQ3XIg",
        "expanded_url" : "https:\/\/medium.com\/@pdehaye\/how-i-peeked-at-the-personal-data-a-billion-dollar-company-holds-about-me-61a446642cd9#.pc4rx3bh8",
        "display_url" : "medium.com\/@pdehaye\/how-i\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "689399547685023744",
    "text" : "I had to sue @TurnPlatform for access to my personal data, but I won. https:\/\/t.co\/hbJNiQ3XIg #EUdataP #SafeHarbor",
    "id" : 689399547685023744,
    "created_at" : "2016-01-19 10:50:35 +0000",
    "user" : {
      "name" : "Paul-Olivier Dehaye",
      "screen_name" : "podehaye",
      "protected" : false,
      "id_str" : "2219841242",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/840965162349797376\/7hdkcm04_normal.jpg",
      "id" : 2219841242,
      "verified" : false
    }
  },
  "id" : 689500904110866434,
  "created_at" : "2016-01-19 17:33:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cormac R. McDarwin",
      "screen_name" : "TheBloodVoyage",
      "indices" : [ 26, 41 ],
      "id_str" : "4825733537",
      "id" : 4825733537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/h2rGIRHHcx",
      "expanded_url" : "http:\/\/thebloodvoyage.tumblr.com\/",
      "display_url" : "thebloodvoyage.tumblr.com"
    } ]
  },
  "geo" : { },
  "id_str" : "689458526406586373",
  "text" : "I did a small markov-bot: @TheBloodVoyage mixes McCarthy\u2019s Blood Meridian w\/ Darwin\u2019s Voyage of the Beagle. tumblr: https:\/\/t.co\/h2rGIRHHcx",
  "id" : 689458526406586373,
  "created_at" : "2016-01-19 14:44:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Istar Nil 0x47617921",
      "screen_name" : "istar_nil",
      "indices" : [ 0, 10 ],
      "id_str" : "314234855",
      "id" : 314234855
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 11, 24 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "689302400125960192",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.10943768315513, 8.69948503282331 ]
  },
  "id_str" : "689351690785538048",
  "in_reply_to_user_id" : 314234855,
  "text" : "@istar_nil @PhilippBayer cool, thanks!",
  "id" : 689351690785538048,
  "in_reply_to_status_id" : 689302400125960192,
  "created_at" : "2016-01-19 07:40:25 +0000",
  "in_reply_to_screen_name" : "istar_nil",
  "in_reply_to_user_id_str" : "314234855",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "689295469533507584",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.10223808429512, 8.748914273541768 ]
  },
  "id_str" : "689346770393022464",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer thanks, I shamelessly stole it from someone on Twitter. Some way to feel at least a bit less bad when emailing ppl @ midnight",
  "id" : 689346770393022464,
  "in_reply_to_status_id" : 689295469533507584,
  "created_at" : "2016-01-19 07:20:52 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "689247357427408898",
  "text" : "In the process of writing yet another twitterbot m)",
  "id" : 689247357427408898,
  "created_at" : "2016-01-19 00:45:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nyborg",
      "screen_name" : "ny_borg",
      "indices" : [ 0, 8 ],
      "id_str" : "570156398",
      "id" : 570156398
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "689195594867429376",
  "geo" : { },
  "id_str" : "689195733405282305",
  "in_reply_to_user_id" : 570156398,
  "text" : "@ny_borg feels like home, doesn\u2019t it! :P",
  "id" : 689195733405282305,
  "in_reply_to_status_id" : 689195594867429376,
  "created_at" : "2016-01-18 21:20:42 +0000",
  "in_reply_to_screen_name" : "ny_borg",
  "in_reply_to_user_id_str" : "570156398",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Xeni Jardin \uD83E\uDD2F",
      "screen_name" : "xeni",
      "indices" : [ 3, 8 ],
      "id_str" : "767",
      "id" : 767
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Malheur",
      "indices" : [ 64, 72 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/OocW8mf5aO",
      "expanded_url" : "https:\/\/boingboing.net\/2016\/01\/17\/oregon-domestic-terrorists-now.html",
      "display_url" : "boingboing.net\/2016\/01\/17\/ore\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "689191274998534144",
  "text" : "RT @xeni: Dildo jokes aside, the white terrorists who took over #Malheur are doing real damage. https:\/\/t.co\/OocW8mf5aO https:\/\/t.co\/wmtQ22\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/xeni\/status\/689166444949549056\/photo\/1",
        "indices" : [ 110, 133 ],
        "url" : "https:\/\/t.co\/wmtQ22lajg",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CZBpOuhWUAAOaHJ.png",
        "id_str" : "689166444714676224",
        "id" : 689166444714676224,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CZBpOuhWUAAOaHJ.png",
        "sizes" : [ {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/wmtQ22lajg"
      } ],
      "hashtags" : [ {
        "text" : "Malheur",
        "indices" : [ 54, 62 ]
      } ],
      "urls" : [ {
        "indices" : [ 86, 109 ],
        "url" : "https:\/\/t.co\/OocW8mf5aO",
        "expanded_url" : "https:\/\/boingboing.net\/2016\/01\/17\/oregon-domestic-terrorists-now.html",
        "display_url" : "boingboing.net\/2016\/01\/17\/ore\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "689166444949549056",
    "text" : "Dildo jokes aside, the white terrorists who took over #Malheur are doing real damage. https:\/\/t.co\/OocW8mf5aO https:\/\/t.co\/wmtQ22lajg",
    "id" : 689166444949549056,
    "created_at" : "2016-01-18 19:24:19 +0000",
    "user" : {
      "name" : "Xeni Jardin \uD83E\uDD2F",
      "screen_name" : "xeni",
      "protected" : false,
      "id_str" : "767",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/879456546119311360\/sigIHyFi_normal.jpg",
      "id" : 767,
      "verified" : true
    }
  },
  "id" : 689191274998534144,
  "created_at" : "2016-01-18 21:02:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/0jpjp2MRvY",
      "expanded_url" : "https:\/\/liorpachter.wordpress.com\/2016\/01\/18\/the-heroes-of-crispr\/",
      "display_url" : "liorpachter.wordpress.com\/2016\/01\/18\/the\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "689180134042112000",
  "text" : "\u00ABlesson of his narrative\u00A0is that young persons should not count on leaders in their field to recognize their work\u00BB https:\/\/t.co\/0jpjp2MRvY",
  "id" : 689180134042112000,
  "created_at" : "2016-01-18 20:18:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.10960510279441, 8.665298792601593 ]
  },
  "id_str" : "689166065377652737",
  "text" : "Damn, I really lost my \u2018avoiding people I know, so I can read quietly\u2019-game when on public transport.",
  "id" : 689166065377652737,
  "created_at" : "2016-01-18 19:22:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael R. Crusoe",
      "screen_name" : "biocrusoe",
      "indices" : [ 0, 10 ],
      "id_str" : "17645638",
      "id" : 17645638
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "689163425293946881",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.10708763352812, 8.667303839460244 ]
  },
  "id_str" : "689164267510214656",
  "in_reply_to_user_id" : 17645638,
  "text" : "@biocrusoe and damn, you\u2019re already in Stuttgart? I\u2019m not even close to home yet :D \uD83D\uDE84",
  "id" : 689164267510214656,
  "in_reply_to_status_id" : 689163425293946881,
  "created_at" : "2016-01-18 19:15:40 +0000",
  "in_reply_to_screen_name" : "biocrusoe",
  "in_reply_to_user_id_str" : "17645638",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/zb06ZL3eJY",
      "expanded_url" : "https:\/\/twitter.com\/biocrusoe\/status\/689163425293946881",
      "display_url" : "twitter.com\/biocrusoe\/stat\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.09707040848333, 8.63598197872052 ]
  },
  "id_str" : "689163925783445509",
  "text" : "Always a pleasure to take the Skyline or whatever the train is called with you! https:\/\/t.co\/zb06ZL3eJY",
  "id" : 689163925783445509,
  "created_at" : "2016-01-18 19:14:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helena",
      "screen_name" : "Helena_LB",
      "indices" : [ 3, 13 ],
      "id_str" : "234309722",
      "id" : 234309722
    }, {
      "name" : "Cell at CellPress",
      "screen_name" : "CellCellPress",
      "indices" : [ 59, 73 ],
      "id_str" : "65134016",
      "id" : 65134016
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Helena_LB\/status\/689120164739203072\/photo\/1",
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/37kDwOvxE9",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CZA_IbaWcAEBp7a.png",
      "id_str" : "689120157017468929",
      "id" : 689120157017468929,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CZA_IbaWcAEBp7a.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 418,
        "resize" : "fit",
        "w" : 714
      }, {
        "h" : 418,
        "resize" : "fit",
        "w" : 714
      }, {
        "h" : 398,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 418,
        "resize" : "fit",
        "w" : 714
      } ],
      "display_url" : "pic.twitter.com\/37kDwOvxE9"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/O1wUNidqVH",
      "expanded_url" : "http:\/\/www.ncbi.nlm.nih.gov\/pubmed\/26771483",
      "display_url" : "ncbi.nlm.nih.gov\/pubmed\/26771483"
    } ]
  },
  "geo" : { },
  "id_str" : "689121116191887360",
  "text" : "RT @Helena_LB: Doudna comments on Lander's CRISPR story in @CellCellPress https:\/\/t.co\/O1wUNidqVH https:\/\/t.co\/37kDwOvxE9",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Cell at CellPress",
        "screen_name" : "CellCellPress",
        "indices" : [ 44, 58 ],
        "id_str" : "65134016",
        "id" : 65134016
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Helena_LB\/status\/689120164739203072\/photo\/1",
        "indices" : [ 83, 106 ],
        "url" : "https:\/\/t.co\/37kDwOvxE9",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CZA_IbaWcAEBp7a.png",
        "id_str" : "689120157017468929",
        "id" : 689120157017468929,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CZA_IbaWcAEBp7a.png",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 418,
          "resize" : "fit",
          "w" : 714
        }, {
          "h" : 418,
          "resize" : "fit",
          "w" : 714
        }, {
          "h" : 398,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 418,
          "resize" : "fit",
          "w" : 714
        } ],
        "display_url" : "pic.twitter.com\/37kDwOvxE9"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 59, 82 ],
        "url" : "https:\/\/t.co\/O1wUNidqVH",
        "expanded_url" : "http:\/\/www.ncbi.nlm.nih.gov\/pubmed\/26771483",
        "display_url" : "ncbi.nlm.nih.gov\/pubmed\/26771483"
      } ]
    },
    "geo" : { },
    "id_str" : "689120164739203072",
    "text" : "Doudna comments on Lander's CRISPR story in @CellCellPress https:\/\/t.co\/O1wUNidqVH https:\/\/t.co\/37kDwOvxE9",
    "id" : 689120164739203072,
    "created_at" : "2016-01-18 16:20:25 +0000",
    "user" : {
      "name" : "Helena",
      "screen_name" : "Helena_LB",
      "protected" : false,
      "id_str" : "234309722",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/875644318970634241\/AWFWlhkv_normal.jpg",
      "id" : 234309722,
      "verified" : false
    }
  },
  "id" : 689121116191887360,
  "created_at" : "2016-01-18 16:24:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt MacManes",
      "screen_name" : "macmanes",
      "indices" : [ 0, 9 ],
      "id_str" : "11824072",
      "id" : 11824072
    }, {
      "name" : "Robert Davey",
      "screen_name" : "froggleston",
      "indices" : [ 10, 22 ],
      "id_str" : "53893339",
      "id" : 53893339
    }, {
      "name" : "Titus Brown",
      "screen_name" : "ctitusbrown",
      "indices" : [ 23, 35 ],
      "id_str" : "26616462",
      "id" : 26616462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/PFqTiVfVNJ",
      "expanded_url" : "https:\/\/en.wikipedia.org\/wiki\/Judge_Holden",
      "display_url" : "en.wikipedia.org\/wiki\/Judge_Hol\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "689108343340822532",
  "geo" : { },
  "id_str" : "689109063846727682",
  "in_reply_to_user_id" : 11824072,
  "text" : "@macmanes @froggleston @ctitusbrown straight out of Blood Meridian ;) https:\/\/t.co\/PFqTiVfVNJ",
  "id" : 689109063846727682,
  "in_reply_to_status_id" : 689108343340822532,
  "created_at" : "2016-01-18 15:36:18 +0000",
  "in_reply_to_screen_name" : "macmanes",
  "in_reply_to_user_id_str" : "11824072",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/8gplJPHgd1",
      "expanded_url" : "https:\/\/twitter.com\/Jakob_Err\/status\/689094578884988928",
      "display_url" : "twitter.com\/Jakob_Err\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "689094796082810880",
  "text" : "\u00ABIn it's raw form, TrumpScript is not compatible with Windows, because Trump isn't the type of guy to believe in PC\u00BB https:\/\/t.co\/8gplJPHgd1",
  "id" : 689094796082810880,
  "created_at" : "2016-01-18 14:39:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/vWX88rSC6i",
      "expanded_url" : "https:\/\/twitter.com\/pathogenomenick\/status\/689069245209178112",
      "display_url" : "twitter.com\/pathogenomenic\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "689077380900585473",
  "text" : "Emerging is currently not possible. You didn\u2019t abort the automatic Update. Installing Update 3\/346. https:\/\/t.co\/vWX88rSC6i",
  "id" : 689077380900585473,
  "created_at" : "2016-01-18 13:30:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 68 ],
      "url" : "https:\/\/t.co\/i8SQqwjAMD",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BAriZTrhwg3\/",
      "display_url" : "instagram.com\/p\/BAriZTrhwg3\/"
    } ]
  },
  "geo" : { },
  "id_str" : "689060709393674240",
  "text" : "This happened, again. Worst Robin Hood ever. https:\/\/t.co\/i8SQqwjAMD",
  "id" : 689060709393674240,
  "created_at" : "2016-01-18 12:24:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/vuItFYianT",
      "expanded_url" : "http:\/\/www.npr.org\/2016\/01\/13\/462906419\/everyone-uses-singular-they-whether-they-realize-it-or-not?utm_campaign=storyshare&utm_source=twitter.com&utm_medium=social",
      "display_url" : "npr.org\/2016\/01\/13\/462\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "689036092469817344",
  "text" : "\u00ABThe only problem with singular \"they\" is that some people still think there is one.\u00BB https:\/\/t.co\/vuItFYianT",
  "id" : 689036092469817344,
  "created_at" : "2016-01-18 10:46:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 42, 54 ],
      "id_str" : "52747896",
      "id" : 52747896
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 55, 68 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 69, 75 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/uFe43sWR33",
      "expanded_url" : "https:\/\/twitter.com\/davidweisss\/status\/688899487729856513",
      "display_url" : "twitter.com\/davidweisss\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "689035176291266560",
  "text" : "Sweet, including a mention of openSNP \/cc @helgerausch @PhilippBayer @Lobot https:\/\/t.co\/uFe43sWR33",
  "id" : 689035176291266560,
  "created_at" : "2016-01-18 10:42:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/XvxTxmudeL",
      "expanded_url" : "https:\/\/twitter.com\/TheScienceWeb\/status\/689020261761417216",
      "display_url" : "twitter.com\/TheScienceWeb\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "689021173238231040",
  "text" : "\u00ABCraig Venter is just a stray piece of my ego that broke away and became real.\u00BB \uD83D\uDD90\uD83D\uDD25 https:\/\/t.co\/XvxTxmudeL",
  "id" : 689021173238231040,
  "created_at" : "2016-01-18 09:47:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Beth \uD83D\uDC3A",
      "screen_name" : "PhdGeek",
      "indices" : [ 0, 8 ],
      "id_str" : "27841081",
      "id" : 27841081
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "689017727076421632",
  "geo" : { },
  "id_str" : "689019824308117504",
  "in_reply_to_user_id" : 27841081,
  "text" : "@PhdGeek yeah, I also tried two years back for the young researcher-thingy and failed as well. :( Hope we\u2019ll catch up somewhere else!",
  "id" : 689019824308117504,
  "in_reply_to_status_id" : 689017727076421632,
  "created_at" : "2016-01-18 09:41:42 +0000",
  "in_reply_to_screen_name" : "PhdGeek",
  "in_reply_to_user_id_str" : "27841081",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 7, 30 ],
      "url" : "https:\/\/t.co\/L2xw35saOO",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=OzeqQlP6ySk",
      "display_url" : "youtube.com\/watch?v=OzeqQl\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "689007680158064640",
  "geo" : { },
  "id_str" : "689014967387975680",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot https:\/\/t.co\/L2xw35saOO",
  "id" : 689014967387975680,
  "in_reply_to_status_id" : 689007680158064640,
  "created_at" : "2016-01-18 09:22:24 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Beth \uD83D\uDC3A",
      "screen_name" : "PhdGeek",
      "indices" : [ 0, 8 ],
      "id_str" : "27841081",
      "id" : 27841081
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "689014200136527872",
  "geo" : { },
  "id_str" : "689014390234963968",
  "in_reply_to_user_id" : 27841081,
  "text" : "@PhdGeek what about applying for one of the travel grants? :(",
  "id" : 689014390234963968,
  "in_reply_to_status_id" : 689014200136527872,
  "created_at" : "2016-01-18 09:20:06 +0000",
  "in_reply_to_screen_name" : "PhdGeek",
  "in_reply_to_user_id_str" : "27841081",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Antideppren\u00F6r",
      "screen_name" : "piratefeminist",
      "indices" : [ 0, 15 ],
      "id_str" : "1152407016",
      "id" : 1152407016
    }, {
      "name" : "darth:\u2122",
      "screen_name" : "darth",
      "indices" : [ 16, 22 ],
      "id_str" : "1337271",
      "id" : 1337271
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "689010343155208192",
  "geo" : { },
  "id_str" : "689011934092488704",
  "in_reply_to_user_id" : 1152407016,
  "text" : "@piratefeminist @darth \uD83D\uDC4D(makes you wish the debates were more often. As a European you wake up to a timeline full of funny stuff)",
  "id" : 689011934092488704,
  "in_reply_to_status_id" : 689010343155208192,
  "created_at" : "2016-01-18 09:10:20 +0000",
  "in_reply_to_screen_name" : "piratefeminist",
  "in_reply_to_user_id_str" : "1152407016",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "demdebate",
      "indices" : [ 39, 49 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/iJNa8pFW1D",
      "expanded_url" : "https:\/\/twitter.com\/darth\/status\/688923300391591936",
      "display_url" : "twitter.com\/darth\/status\/6\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "689008534336499712",
  "text" : "Trawling Twitter for gifs posted about #demdebate is how I catch up on US politics. https:\/\/t.co\/iJNa8pFW1D",
  "id" : 689008534336499712,
  "created_at" : "2016-01-18 08:56:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/1xpzW2X2eH",
      "expanded_url" : "https:\/\/peerj.com\/preprints\/1642\/",
      "display_url" : "peerj.com\/preprints\/1642\/"
    } ]
  },
  "geo" : { },
  "id_str" : "688991449199849473",
  "text" : "Distributions of p-values smaller than .05 in Psychology: What is going on? https:\/\/t.co\/1xpzW2X2eH",
  "id" : 688991449199849473,
  "created_at" : "2016-01-18 07:48:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Egle Ramanauskaite \u2623",
      "screen_name" : "Seplute",
      "indices" : [ 0, 8 ],
      "id_str" : "188833865",
      "id" : 188833865
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "688866429475663872",
  "geo" : { },
  "id_str" : "688866583884746753",
  "in_reply_to_user_id" : 188833865,
  "text" : "@Seplute sweet, looking forward to hear about those :)",
  "id" : 688866583884746753,
  "in_reply_to_status_id" : 688866429475663872,
  "created_at" : "2016-01-17 23:32:46 +0000",
  "in_reply_to_screen_name" : "Seplute",
  "in_reply_to_user_id_str" : "188833865",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Egle Ramanauskaite \u2623",
      "screen_name" : "Seplute",
      "indices" : [ 0, 8 ],
      "id_str" : "188833865",
      "id" : 188833865
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "688864543439745024",
  "geo" : { },
  "id_str" : "688864771073032192",
  "in_reply_to_user_id" : 188833865,
  "text" : "@Seplute What did you do to them!? (the lichens, I don\u2019t care for the students ;))",
  "id" : 688864771073032192,
  "in_reply_to_status_id" : 688864543439745024,
  "created_at" : "2016-01-17 23:25:34 +0000",
  "in_reply_to_screen_name" : "Seplute",
  "in_reply_to_user_id_str" : "188833865",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Conner Habib",
      "screen_name" : "ConnerHabib",
      "indices" : [ 0, 12 ],
      "id_str" : "27513314",
      "id" : 27513314
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "688827935722057728",
  "geo" : { },
  "id_str" : "688829644141948928",
  "in_reply_to_user_id" : 27513314,
  "text" : "@ConnerHabib congrats!",
  "id" : 688829644141948928,
  "in_reply_to_status_id" : 688827935722057728,
  "created_at" : "2016-01-17 21:05:59 +0000",
  "in_reply_to_screen_name" : "ConnerHabib",
  "in_reply_to_user_id_str" : "27513314",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "688819600180547584",
  "geo" : { },
  "id_str" : "688819970801856513",
  "in_reply_to_user_id" : 14286491,
  "text" : "Totally makes it sound like childbirth is a great way to meditate\u2026",
  "id" : 688819970801856513,
  "in_reply_to_status_id" : 688819600180547584,
  "created_at" : "2016-01-17 20:27:33 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "688819600180547584",
  "text" : "\u00ABBecause, you know what you get along with 27 stitches on your belly, or seventh- to second-degree tears in your perineum? Perspective.\u00BB",
  "id" : 688819600180547584,
  "created_at" : "2016-01-17 20:26:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 49 ],
      "url" : "https:\/\/t.co\/sooEmjVXEO",
      "expanded_url" : "https:\/\/media.giphy.com\/media\/26tP9kY6AI659gHL2\/giphy.gif",
      "display_url" : "media.giphy.com\/media\/26tP9kY6\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "688789016318210048",
  "text" : "submitting an application https:\/\/t.co\/sooEmjVXEO",
  "id" : 688789016318210048,
  "created_at" : "2016-01-17 18:24:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 66 ],
      "url" : "https:\/\/t.co\/xn131v5UNF",
      "expanded_url" : "https:\/\/media.giphy.com\/media\/WqmYGa2LjQlTG\/giphy.gif",
      "display_url" : "media.giphy.com\/media\/WqmYGa2L\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "688774715368951816",
  "geo" : { },
  "id_str" : "688775301648805888",
  "in_reply_to_user_id" : 14286491,
  "text" : "what the academic genius contest really is https:\/\/t.co\/xn131v5UNF",
  "id" : 688775301648805888,
  "in_reply_to_status_id" : 688774715368951816,
  "created_at" : "2016-01-17 17:30:03 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/iPSsR2atJu",
      "expanded_url" : "http:\/\/opinionator.blogs.nytimes.com\/2016\/01\/11\/when-philosophy-lost-its-way\/?_r=0",
      "display_url" : "opinionator.blogs.nytimes.com\/2016\/01\/11\/whe\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "688774715368951816",
  "text" : "\u00ABphilosophy has aped the sciences by fostering a culture that might be called \u201Cthe genius contest.\u201D\u00BB https:\/\/t.co\/iPSsR2atJu",
  "id" : 688774715368951816,
  "created_at" : "2016-01-17 17:27:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/QBifpcPDEB",
      "expanded_url" : "http:\/\/waitbutwhy.com\/2016\/01\/horizontal-history.html",
      "display_url" : "waitbutwhy.com\/2016\/01\/horizo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "688750946386599936",
  "text" : "Why doing Horizontal History: \"it\u2019s that almost none of us has any idea what the fuck we\u2019re talking about\" https:\/\/t.co\/QBifpcPDEB",
  "id" : 688750946386599936,
  "created_at" : "2016-01-17 15:53:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/xLIGGLKF1S",
      "expanded_url" : "https:\/\/twitter.com\/valentina_crrr\/status\/688707260428599296",
      "display_url" : "twitter.com\/valentina_crrr\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1140506547603, 8.753426461527308 ]
  },
  "id_str" : "688711378790649860",
  "text" : "\u00ABI was the thing that I once joked about becoming: a waitress w\/ a PhD, only now I also felt old waitress w\/ a PhD\u00BB https:\/\/t.co\/xLIGGLKF1S",
  "id" : 688711378790649860,
  "created_at" : "2016-01-17 13:16:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Salon",
      "screen_name" : "Salon",
      "indices" : [ 92, 98 ],
      "id_str" : "16955991",
      "id" : 16955991
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 87 ],
      "url" : "https:\/\/t.co\/QTAbFkWitk",
      "expanded_url" : "http:\/\/www.salon.com\/2015\/12\/20\/sixteen_years_in_academia_made_me_an_a_hole\/",
      "display_url" : "salon.com\/2015\/12\/20\/six\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "688711101056442368",
  "text" : "RT @valentina_crrr: Sixteen years in academia made me an a-hole https:\/\/t.co\/QTAbFkWitk via @Salon",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Salon",
        "screen_name" : "Salon",
        "indices" : [ 72, 78 ],
        "id_str" : "16955991",
        "id" : 16955991
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 44, 67 ],
        "url" : "https:\/\/t.co\/QTAbFkWitk",
        "expanded_url" : "http:\/\/www.salon.com\/2015\/12\/20\/sixteen_years_in_academia_made_me_an_a_hole\/",
        "display_url" : "salon.com\/2015\/12\/20\/six\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "688707260428599296",
    "text" : "Sixteen years in academia made me an a-hole https:\/\/t.co\/QTAbFkWitk via @Salon",
    "id" : 688707260428599296,
    "created_at" : "2016-01-17 12:59:41 +0000",
    "user" : {
      "name" : "Valentina Carraro",
      "screen_name" : "valecrrr",
      "protected" : true,
      "id_str" : "2998662774",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/560360332212727810\/Na4DXAOo_normal.jpeg",
      "id" : 2998662774,
      "verified" : false
    }
  },
  "id" : 688711101056442368,
  "created_at" : "2016-01-17 13:14:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/OvYkamPaWR",
      "expanded_url" : "http:\/\/kieranhealy.org\/blog\/archives\/2016\/01\/16\/two-y-axes",
      "display_url" : "kieranhealy.org\/blog\/archives\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "688705689053720576",
  "text" : "Two Y-Axes: you absolutely shouldn't do it, 'But you can do it in Base R if you insist, like an animal.' https:\/\/t.co\/OvYkamPaWR",
  "id" : 688705689053720576,
  "created_at" : "2016-01-17 12:53:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 123, 146 ],
      "url" : "https:\/\/t.co\/3WBakLINzy",
      "expanded_url" : "https:\/\/www.propublica.org\/article\/muscular-dystrophy-patient-olympic-medalist-same-genetic-mutation",
      "display_url" : "propublica.org\/article\/muscul\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1132, 8.754695 ]
  },
  "id_str" : "688698483478544385",
  "text" : "Great story on DIY&amp;citizen science: The Muscular Dystrophy Patient &amp; Olympic Medalist w\/ the Same Genetic Disorder https:\/\/t.co\/3WBakLINzy",
  "id" : 688698483478544385,
  "created_at" : "2016-01-17 12:24:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 14, 26 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "688648048516333568",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11404761174631, 8.753420210840844 ]
  },
  "id_str" : "688673984209117184",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @helgerausch thanks! :D",
  "id" : 688673984209117184,
  "in_reply_to_status_id" : 688648048516333568,
  "created_at" : "2016-01-17 10:47:27 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dnavid",
      "screen_name" : "davidweisss",
      "indices" : [ 0, 12 ],
      "id_str" : "19355816",
      "id" : 19355816
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "688575964952014848",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11404761174631, 8.753420210840844 ]
  },
  "id_str" : "688673923450433536",
  "in_reply_to_user_id" : 19355816,
  "text" : "@davidweisss hi David, unfortunately not possible right now. We do not check for the version of the chip. You could dl all &amp; check size?",
  "id" : 688673923450433536,
  "in_reply_to_status_id" : 688575964952014848,
  "created_at" : "2016-01-17 10:47:12 +0000",
  "in_reply_to_screen_name" : "davidweisss",
  "in_reply_to_user_id_str" : "19355816",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Conner Habib",
      "screen_name" : "ConnerHabib",
      "indices" : [ 0, 12 ],
      "id_str" : "27513314",
      "id" : 27513314
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "688477140321304577",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11405206432119, 8.753419825345333 ]
  },
  "id_str" : "688477272920190976",
  "in_reply_to_user_id" : 27513314,
  "text" : "@ConnerHabib adaptionist to the bone.",
  "id" : 688477272920190976,
  "in_reply_to_status_id" : 688477140321304577,
  "created_at" : "2016-01-16 21:45:47 +0000",
  "in_reply_to_screen_name" : "ConnerHabib",
  "in_reply_to_user_id_str" : "27513314",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Torsten Seemann",
      "screen_name" : "torstenseemann",
      "indices" : [ 0, 15 ],
      "id_str" : "42558652",
      "id" : 42558652
    }, {
      "name" : "Nicolas Robine",
      "screen_name" : "notSoJunkDNA",
      "indices" : [ 16, 29 ],
      "id_str" : "107174526",
      "id" : 107174526
    }, {
      "name" : "Keith Robison",
      "screen_name" : "OmicsOmicsBlog",
      "indices" : [ 30, 45 ],
      "id_str" : "116867280",
      "id" : 116867280
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "688207979590463488",
  "geo" : { },
  "id_str" : "688323536381935616",
  "in_reply_to_user_id" : 42558652,
  "text" : "@torstenseemann @notSoJunkDNA @OmicsOmicsBlog you don\u2019t wanna know how people all over the world have murdered mine, after spelling it out.",
  "id" : 688323536381935616,
  "in_reply_to_status_id" : 688207979590463488,
  "created_at" : "2016-01-16 11:34:54 +0000",
  "in_reply_to_screen_name" : "torstenseemann",
  "in_reply_to_user_id_str" : "42558652",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FiveThirtyEight",
      "screen_name" : "FiveThirtyEight",
      "indices" : [ 3, 19 ],
      "id_str" : "2303751216",
      "id" : 2303751216
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/FiveThirtyEight\/status\/688187440624869376\/photo\/1",
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/lhhmQBT2uL",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CYymS6hUMAAIgex.jpg",
      "id_str" : "688107686957690880",
      "id" : 688107686957690880,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CYymS6hUMAAIgex.jpg",
      "sizes" : [ {
        "h" : 431,
        "resize" : "fit",
        "w" : 575
      }, {
        "h" : 431,
        "resize" : "fit",
        "w" : 575
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 431,
        "resize" : "fit",
        "w" : 575
      }, {
        "h" : 431,
        "resize" : "fit",
        "w" : 575
      } ],
      "display_url" : "pic.twitter.com\/lhhmQBT2uL"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/oomWd2xNMQ",
      "expanded_url" : "http:\/\/53eig.ht\/1K2hYGV",
      "display_url" : "53eig.ht\/1K2hYGV"
    } ]
  },
  "geo" : { },
  "id_str" : "688321583816044545",
  "text" : "RT @FiveThirtyEight: MSG got a bad rap because of flawed science and xenophobia: https:\/\/t.co\/oomWd2xNMQ https:\/\/t.co\/lhhmQBT2uL",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ads.twitter.com\" rel=\"nofollow\"\u003ETwitter Ads\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FiveThirtyEight\/status\/688187440624869376\/photo\/1",
        "indices" : [ 84, 107 ],
        "url" : "https:\/\/t.co\/lhhmQBT2uL",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CYymS6hUMAAIgex.jpg",
        "id_str" : "688107686957690880",
        "id" : 688107686957690880,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CYymS6hUMAAIgex.jpg",
        "sizes" : [ {
          "h" : 431,
          "resize" : "fit",
          "w" : 575
        }, {
          "h" : 431,
          "resize" : "fit",
          "w" : 575
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 431,
          "resize" : "fit",
          "w" : 575
        }, {
          "h" : 431,
          "resize" : "fit",
          "w" : 575
        } ],
        "display_url" : "pic.twitter.com\/lhhmQBT2uL"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 60, 83 ],
        "url" : "https:\/\/t.co\/oomWd2xNMQ",
        "expanded_url" : "http:\/\/53eig.ht\/1K2hYGV",
        "display_url" : "53eig.ht\/1K2hYGV"
      } ]
    },
    "geo" : { },
    "id_str" : "688187440624869376",
    "text" : "MSG got a bad rap because of flawed science and xenophobia: https:\/\/t.co\/oomWd2xNMQ https:\/\/t.co\/lhhmQBT2uL",
    "id" : 688187440624869376,
    "created_at" : "2016-01-16 02:34:06 +0000",
    "user" : {
      "name" : "FiveThirtyEight",
      "screen_name" : "FiveThirtyEight",
      "protected" : false,
      "id_str" : "2303751216",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/875426588061573121\/lpQG3W6i_normal.jpg",
      "id" : 2303751216,
      "verified" : true
    }
  },
  "id" : 688321583816044545,
  "created_at" : "2016-01-16 11:27:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "688170049706708993",
  "geo" : { },
  "id_str" : "688178981703528448",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC that means you should update your priors ;)",
  "id" : 688178981703528448,
  "in_reply_to_status_id" : 688170049706708993,
  "created_at" : "2016-01-16 02:00:29 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "688138152469368833",
  "geo" : { },
  "id_str" : "688150161449586689",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC you triggered the association, so all credit goes to you ;)",
  "id" : 688150161449586689,
  "in_reply_to_status_id" : 688138152469368833,
  "created_at" : "2016-01-16 00:05:58 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 54 ],
      "url" : "https:\/\/t.co\/z10urwzpmD",
      "expanded_url" : "http:\/\/www.boototom.info\/index.php?2009\/06\/19\/82-dylan-mashed",
      "display_url" : "boototom.info\/index.php?2009\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "688133314876592128",
  "geo" : { },
  "id_str" : "688133380043452416",
  "in_reply_to_user_id" : 14286491,
  "text" : "All of them can be found here: https:\/\/t.co\/z10urwzpmD",
  "id" : 688133380043452416,
  "in_reply_to_status_id" : 688133314876592128,
  "created_at" : "2016-01-15 22:59:17 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 10, 19 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/Bu9p32QBFO",
      "expanded_url" : "http:\/\/www.boototom.info\/dylan\/14-Knockin_on_Ziggys_Door_long.mp3",
      "display_url" : "boototom.info\/dylan\/14-Knock\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "688133314876592128",
  "text" : "Thanks to @SuicideC for reminding me of those mashups from 2009: Knockin\u2019 on Ziggy\u2019s Door https:\/\/t.co\/Bu9p32QBFO (mp3)",
  "id" : 688133314876592128,
  "created_at" : "2016-01-15 22:59:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Conner Habib",
      "screen_name" : "ConnerHabib",
      "indices" : [ 0, 12 ],
      "id_str" : "27513314",
      "id" : 27513314
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "688117622328573952",
  "geo" : { },
  "id_str" : "688117921625718784",
  "in_reply_to_user_id" : 27513314,
  "text" : "@ConnerHabib thanks so much! I\u2019l try to get a copy of Life &amp; Legacy! &lt;3",
  "id" : 688117921625718784,
  "in_reply_to_status_id" : 688117622328573952,
  "created_at" : "2016-01-15 21:57:51 +0000",
  "in_reply_to_screen_name" : "ConnerHabib",
  "in_reply_to_user_id_str" : "27513314",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 56 ],
      "url" : "https:\/\/t.co\/sbtKYpUWck",
      "expanded_url" : "https:\/\/twitter.com\/arundurvasula\/status\/688109438838784004",
      "display_url" : "twitter.com\/arundurvasula\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "688109831249477633",
  "text" : "damn, you did steal my abstract! https:\/\/t.co\/sbtKYpUWck",
  "id" : 688109831249477633,
  "created_at" : "2016-01-15 21:25:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/403HFBlHf8",
      "expanded_url" : "http:\/\/www.buzzfeed.com\/connerhabib\/wanna-be-a-porn-star-youll-need-a-good-name#.xt9WXn0V6",
      "display_url" : "buzzfeed.com\/connerhabib\/wa\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "688102456497053698",
  "text" : "TIL that Lynn Margulis was so much cooler than I previously suspected. https:\/\/t.co\/403HFBlHf8",
  "id" : 688102456497053698,
  "created_at" : "2016-01-15 20:56:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "688073218003988480",
  "text" : "I\u2019m now at an age where my calendar has entries such as \u2018tea time\u2019 and I\u2019m not 100% sure how I feel about this.",
  "id" : 688073218003988480,
  "created_at" : "2016-01-15 19:00:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ratty McRatface \uD83D\uDC00",
      "screen_name" : "godhika",
      "indices" : [ 0, 8 ],
      "id_str" : "96797688",
      "id" : 96797688
    }, {
      "name" : "malech maltz",
      "screen_name" : "malech",
      "indices" : [ 9, 16 ],
      "id_str" : "784085846391713793",
      "id" : 784085846391713793
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 60 ],
      "url" : "https:\/\/t.co\/vVHEfD0VBD",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=4xmckWVPRaI",
      "display_url" : "youtube.com\/watch?v=4xmckW\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "688066972639191040",
  "geo" : { },
  "id_str" : "688072189636128768",
  "in_reply_to_user_id" : 96797688,
  "text" : "@godhika @malech in meinem Kopf mehr https:\/\/t.co\/vVHEfD0VBD",
  "id" : 688072189636128768,
  "in_reply_to_status_id" : 688066972639191040,
  "created_at" : "2016-01-15 18:56:08 +0000",
  "in_reply_to_screen_name" : "godhika",
  "in_reply_to_user_id_str" : "96797688",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "688049790874173441",
  "text" : "\u00ABacademic decisions, the most kinky of all topics.\u00BB \u2013 \u00ABit\u2019s all tease and denial after all\u2026\u00BB",
  "id" : 688049790874173441,
  "created_at" : "2016-01-15 17:27:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "688038263177777152",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.12467991990862, 8.679816266287618 ]
  },
  "id_str" : "688039621142405121",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot naja, da habe ich die Wiper kaputt bekommen und mit m\u00E4nnlicher Hilfe mehr schlecht als recht \u2018gefixt\u2019? :D",
  "id" : 688039621142405121,
  "in_reply_to_status_id" : 688038263177777152,
  "created_at" : "2016-01-15 16:46:43 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "688032506176733184",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.14055234527794, 8.669570033428709 ]
  },
  "id_str" : "688037204497674245",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot von M\u00E4nnern gab es hingegen nur unsolicited advice der falsch war\u2026",
  "id" : 688037204497674245,
  "in_reply_to_status_id" : 688032506176733184,
  "created_at" : "2016-01-15 16:37:07 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "688032506176733184",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.14367083992622, 8.668569989502897 ]
  },
  "id_str" : "688037040483598339",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot wie gut das ich bislang bei Problemen mit meinem Auto immer exklusiv Frauen befragt habe. Mit 100% Erfolgsrate!",
  "id" : 688037040483598339,
  "in_reply_to_status_id" : 688032506176733184,
  "created_at" : "2016-01-15 16:36:28 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Atossa Araxia Abrahamian",
      "screen_name" : "atossaaraxia",
      "indices" : [ 3, 16 ],
      "id_str" : "228437800",
      "id" : 228437800
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/cklbDCbYIo",
      "expanded_url" : "http:\/\/bigstory.ap.org\/929caf1952904b7fb94ea28f8ff65453",
      "display_url" : "bigstory.ap.org\/929caf1952904b\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "688028949658611712",
  "text" : "RT @atossaaraxia: Mos Def was arrested at a South African airport with a World Passport! https:\/\/t.co\/cklbDCbYIo",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 71, 94 ],
        "url" : "https:\/\/t.co\/cklbDCbYIo",
        "expanded_url" : "http:\/\/bigstory.ap.org\/929caf1952904b7fb94ea28f8ff65453",
        "display_url" : "bigstory.ap.org\/929caf1952904b\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "688028774991028225",
    "text" : "Mos Def was arrested at a South African airport with a World Passport! https:\/\/t.co\/cklbDCbYIo",
    "id" : 688028774991028225,
    "created_at" : "2016-01-15 16:03:37 +0000",
    "user" : {
      "name" : "Atossa Araxia Abrahamian",
      "screen_name" : "atossaaraxia",
      "protected" : false,
      "id_str" : "228437800",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/707884522738728960\/VqnZwF27_normal.jpg",
      "id" : 228437800,
      "verified" : true
    }
  },
  "id" : 688028949658611712,
  "created_at" : "2016-01-15 16:04:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Schawinski",
      "screen_name" : "kevinschawinski",
      "indices" : [ 0, 16 ],
      "id_str" : "242844365",
      "id" : 242844365
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "688019701063139328",
  "geo" : { },
  "id_str" : "688019858496294912",
  "in_reply_to_user_id" : 242844365,
  "text" : "@kevinschawinski nah, I dunno, I can see how it can be terrifying and\/or boring for them.",
  "id" : 688019858496294912,
  "in_reply_to_status_id" : 688019701063139328,
  "created_at" : "2016-01-15 15:28:11 +0000",
  "in_reply_to_screen_name" : "kevinschawinski",
  "in_reply_to_user_id_str" : "242844365",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Schawinski",
      "screen_name" : "kevinschawinski",
      "indices" : [ 0, 16 ],
      "id_str" : "242844365",
      "id" : 242844365
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "688019339476398081",
  "geo" : { },
  "id_str" : "688019622797438977",
  "in_reply_to_user_id" : 242844365,
  "text" : "@kevinschawinski I actually don\u2019t mind kids at all. I think it\u2019s great they get the chance to travel :)",
  "id" : 688019622797438977,
  "in_reply_to_status_id" : 688019339476398081,
  "created_at" : "2016-01-15 15:27:15 +0000",
  "in_reply_to_screen_name" : "kevinschawinski",
  "in_reply_to_user_id_str" : "242844365",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/liOulVTj2J",
      "expanded_url" : "https:\/\/twitter.com\/kevinschawinski\/status\/688016890594209793",
      "display_url" : "twitter.com\/kevinschawinsk\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "688019260581507073",
  "text" : "\u00ABNo word on whether other passengers found the turkey better or worse company than a crying baby.\u00BB https:\/\/t.co\/liOulVTj2J",
  "id" : 688019260581507073,
  "created_at" : "2016-01-15 15:25:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 65 ],
      "url" : "https:\/\/t.co\/77SdVgI6zk",
      "expanded_url" : "http:\/\/i.imgur.com\/IpMrzXU.gifv",
      "display_url" : "i.imgur.com\/IpMrzXU.gifv"
    } ]
  },
  "geo" : { },
  "id_str" : "688008674246291456",
  "text" : "waiting for those computations to finish\u2026 https:\/\/t.co\/77SdVgI6zk",
  "id" : 688008674246291456,
  "created_at" : "2016-01-15 14:43:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/AuiN0ZKTTl",
      "expanded_url" : "http:\/\/arstechnica.com\/science\/2016\/01\/dear-mr-president-please-stop-with-these-science-moonshots\/",
      "display_url" : "arstechnica.com\/science\/2016\/0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "688006304045088768",
  "text" : "Dear Mr. President: Please stop with these science moonshots. Find a way to deliver predictable, sustainable funding https:\/\/t.co\/AuiN0ZKTTl",
  "id" : 688006304045088768,
  "created_at" : "2016-01-15 14:34:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonas",
      "screen_name" : "lsanoj",
      "indices" : [ 0, 7 ],
      "id_str" : "18918915",
      "id" : 18918915
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "687999892447473664",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17232015197095, 8.627517851085653 ]
  },
  "id_str" : "688000212468658176",
  "in_reply_to_user_id" : 18918915,
  "text" : "@lsanoj versp\u00E4tetes Geburtstagsgeschenk:D",
  "id" : 688000212468658176,
  "in_reply_to_status_id" : 687999892447473664,
  "created_at" : "2016-01-15 14:10:07 +0000",
  "in_reply_to_screen_name" : "lsanoj",
  "in_reply_to_user_id_str" : "18918915",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "(((Joshi Fischer)))",
      "screen_name" : "thetruemilhouse",
      "indices" : [ 0, 16 ],
      "id_str" : "15171407",
      "id" : 15171407
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "687972098229272576",
  "geo" : { },
  "id_str" : "687976353912745984",
  "in_reply_to_user_id" : 15171407,
  "text" : "@thetruemilhouse i just think we reached the EOD.",
  "id" : 687976353912745984,
  "in_reply_to_status_id" : 687972098229272576,
  "created_at" : "2016-01-15 12:35:19 +0000",
  "in_reply_to_screen_name" : "thetruemilhouse",
  "in_reply_to_user_id_str" : "15171407",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "(((Joshi Fischer)))",
      "screen_name" : "thetruemilhouse",
      "indices" : [ 0, 16 ],
      "id_str" : "15171407",
      "id" : 15171407
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "687968787598028800",
  "geo" : { },
  "id_str" : "687970869969326080",
  "in_reply_to_user_id" : 15171407,
  "text" : "@thetruemilhouse if that\u2019s your point then there\u2019s little reason in discussing it and I\u2019ll be happy to rip off all the poor filmmakers.",
  "id" : 687970869969326080,
  "in_reply_to_status_id" : 687968787598028800,
  "created_at" : "2016-01-15 12:13:31 +0000",
  "in_reply_to_screen_name" : "thetruemilhouse",
  "in_reply_to_user_id_str" : "15171407",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ali",
      "screen_name" : "zoonpolitikon",
      "indices" : [ 0, 14 ],
      "id_str" : "13040652",
      "id" : 13040652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "687950588210987008",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17275112669346, 8.62753961359435 ]
  },
  "id_str" : "687953715320467457",
  "in_reply_to_user_id" : 13040652,
  "text" : "@zoonpolitikon ja, wie gut das wir den gro\u00DFen Humanisten und seine bros haben m(",
  "id" : 687953715320467457,
  "in_reply_to_status_id" : 687950588210987008,
  "created_at" : "2016-01-15 11:05:21 +0000",
  "in_reply_to_screen_name" : "zoonpolitikon",
  "in_reply_to_user_id_str" : "13040652",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ali",
      "screen_name" : "zoonpolitikon",
      "indices" : [ 0, 14 ],
      "id_str" : "13040652",
      "id" : 13040652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "687947334840401922",
  "geo" : { },
  "id_str" : "687948605987131392",
  "in_reply_to_user_id" : 13040652,
  "text" : "@zoonpolitikon makes you wonder how many people he by now turned to religion, just for praying that Dawkins will drop dead rather soon\u2026",
  "id" : 687948605987131392,
  "in_reply_to_status_id" : 687947334840401922,
  "created_at" : "2016-01-15 10:45:03 +0000",
  "in_reply_to_screen_name" : "zoonpolitikon",
  "in_reply_to_user_id_str" : "13040652",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 55 ],
      "url" : "https:\/\/t.co\/6aWPIAU1XL",
      "expanded_url" : "https:\/\/www.tes.com\/sites\/default\/files\/Money.gif",
      "display_url" : "tes.com\/sites\/default\/\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "687927575495196672",
  "geo" : { },
  "id_str" : "687928608736854017",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot do open science, be like https:\/\/t.co\/6aWPIAU1XL",
  "id" : 687928608736854017,
  "in_reply_to_status_id" : 687927575495196672,
  "created_at" : "2016-01-15 09:25:36 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "687926296115064833",
  "text" : "not so fun fact: for downloads &gt;2 GB in size it\u2019s faster if i go to the office by train, download it there and take the train back home\u2026",
  "id" : 687926296115064833,
  "created_at" : "2016-01-15 09:16:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "687924218680455168",
  "text" : "\u00AB\u2019Above all, to thine own self be true.\u2019 [\u2026] I could never have imagined how many different selves I would end up having to be true to.\u00BB",
  "id" : 687924218680455168,
  "created_at" : "2016-01-15 09:08:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "(((Joshi Fischer)))",
      "screen_name" : "thetruemilhouse",
      "indices" : [ 0, 16 ],
      "id_str" : "15171407",
      "id" : 15171407
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "687805797095571456",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.10608935166794, 8.739342751177652 ]
  },
  "id_str" : "687912508645109760",
  "in_reply_to_user_id" : 15171407,
  "text" : "@thetruemilhouse eg ebooks manage that they are virtually all available on Amazon US &amp; DE at the same time. Result: I spend 1k\u20AC\/year.",
  "id" : 687912508645109760,
  "in_reply_to_status_id" : 687805797095571456,
  "created_at" : "2016-01-15 08:21:37 +0000",
  "in_reply_to_screen_name" : "thetruemilhouse",
  "in_reply_to_user_id_str" : "15171407",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "(((Joshi Fischer)))",
      "screen_name" : "thetruemilhouse",
      "indices" : [ 0, 16 ],
      "id_str" : "15171407",
      "id" : 15171407
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "687805797095571456",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.10191063236975, 8.750836686685538 ]
  },
  "id_str" : "687911680920170496",
  "in_reply_to_user_id" : 15171407,
  "text" : "@thetruemilhouse nope, but if the people don\u2019t offer me a way to pay them they obviously don\u2019t want my money.",
  "id" : 687911680920170496,
  "in_reply_to_status_id" : 687805797095571456,
  "created_at" : "2016-01-15 08:18:20 +0000",
  "in_reply_to_screen_name" : "thetruemilhouse",
  "in_reply_to_user_id_str" : "15171407",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "(((Joshi Fischer)))",
      "screen_name" : "thetruemilhouse",
      "indices" : [ 0, 16 ],
      "id_str" : "15171407",
      "id" : 15171407
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "687804749056503808",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1140536050101, 8.753431259577999 ]
  },
  "id_str" : "687804936302780416",
  "in_reply_to_user_id" : 15171407,
  "text" : "@thetruemilhouse ah, so getting around copyright limitations is okay when it\u2019s for paying stuff.",
  "id" : 687804936302780416,
  "in_reply_to_status_id" : 687804749056503808,
  "created_at" : "2016-01-15 01:14:10 +0000",
  "in_reply_to_screen_name" : "thetruemilhouse",
  "in_reply_to_user_id_str" : "15171407",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "(((Joshi Fischer)))",
      "screen_name" : "thetruemilhouse",
      "indices" : [ 0, 16 ],
      "id_str" : "15171407",
      "id" : 15171407
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "687804059378683904",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11395191379162, 8.753578799434626 ]
  },
  "id_str" : "687804628516343809",
  "in_reply_to_user_id" : 15171407,
  "text" : "@thetruemilhouse so in your opinion it\u2019s fine if I just torrent what\u2019s not on German Netflix?",
  "id" : 687804628516343809,
  "in_reply_to_status_id" : 687804059378683904,
  "created_at" : "2016-01-15 01:12:56 +0000",
  "in_reply_to_screen_name" : "thetruemilhouse",
  "in_reply_to_user_id_str" : "15171407",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "(((Joshi Fischer)))",
      "screen_name" : "thetruemilhouse",
      "indices" : [ 0, 16 ],
      "id_str" : "15171407",
      "id" : 15171407
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "687803766704345088",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11389311678979, 8.753613219184746 ]
  },
  "id_str" : "687804363197300736",
  "in_reply_to_user_id" : 15171407,
  "text" : "@thetruemilhouse since when is Netflix available in Germany again?",
  "id" : 687804363197300736,
  "in_reply_to_status_id" : 687803766704345088,
  "created_at" : "2016-01-15 01:11:53 +0000",
  "in_reply_to_screen_name" : "thetruemilhouse",
  "in_reply_to_user_id_str" : "15171407",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "(((Joshi Fischer)))",
      "screen_name" : "thetruemilhouse",
      "indices" : [ 0, 16 ],
      "id_str" : "15171407",
      "id" : 15171407
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "687801978022395904",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11405158750347, 8.753451905789575 ]
  },
  "id_str" : "687802263444795394",
  "in_reply_to_user_id" : 15171407,
  "text" : "@thetruemilhouse well, they would be getting paid just fine if they wouldn\u2019t block people from paying for stuff.",
  "id" : 687802263444795394,
  "in_reply_to_status_id" : 687801978022395904,
  "created_at" : "2016-01-15 01:03:33 +0000",
  "in_reply_to_screen_name" : "thetruemilhouse",
  "in_reply_to_user_id_str" : "15171407",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "(((Joshi Fischer)))",
      "screen_name" : "thetruemilhouse",
      "indices" : [ 0, 16 ],
      "id_str" : "15171407",
      "id" : 15171407
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "687800370861584384",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11405976942581, 8.753437919960994 ]
  },
  "id_str" : "687801118143938562",
  "in_reply_to_user_id" : 15171407,
  "text" : "@thetruemilhouse and still it\u2019s easier to torrent stuff if they follow through with their claims\u2026",
  "id" : 687801118143938562,
  "in_reply_to_status_id" : 687800370861584384,
  "created_at" : "2016-01-15 00:58:59 +0000",
  "in_reply_to_screen_name" : "thetruemilhouse",
  "in_reply_to_user_id_str" : "15171407",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    }, {
      "name" : "ToxX",
      "screen_name" : "ToxXInFlames",
      "indices" : [ 10, 23 ],
      "id_str" : "1421360166",
      "id" : 1421360166
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "687797483112640513",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11390324880708, 8.753457684653844 ]
  },
  "id_str" : "687798543608852481",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC @ToxXInFlames \uD83D\uDE4F",
  "id" : 687798543608852481,
  "in_reply_to_status_id" : 687797483112640513,
  "created_at" : "2016-01-15 00:48:46 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "(((Joshi Fischer)))",
      "screen_name" : "thetruemilhouse",
      "indices" : [ 0, 16 ],
      "id_str" : "15171407",
      "id" : 15171407
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "687797347850555392",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11405959633861, 8.75343211137715 ]
  },
  "id_str" : "687798391636652032",
  "in_reply_to_user_id" : 15171407,
  "text" : "@thetruemilhouse then maybe they should just stop being assholes to people who are trying to give them money?",
  "id" : 687798391636652032,
  "in_reply_to_status_id" : 687797347850555392,
  "created_at" : "2016-01-15 00:48:09 +0000",
  "in_reply_to_screen_name" : "thetruemilhouse",
  "in_reply_to_user_id_str" : "15171407",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "687796666838159360",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11405854776833, 8.7534363992349 ]
  },
  "id_str" : "687796958384226304",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC ouch! \uD83D\uDE14",
  "id" : 687796958384226304,
  "in_reply_to_status_id" : 687796666838159360,
  "created_at" : "2016-01-15 00:42:28 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "(((Joshi Fischer)))",
      "screen_name" : "thetruemilhouse",
      "indices" : [ 0, 16 ],
      "id_str" : "15171407",
      "id" : 15171407
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "687794119738060800",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11405938025442, 8.753427548710205 ]
  },
  "id_str" : "687795177109491712",
  "in_reply_to_user_id" : 15171407,
  "text" : "@thetruemilhouse how to filmmakers profit exactly when I watch their stuff when on vacation using my same Netflix account?",
  "id" : 687795177109491712,
  "in_reply_to_status_id" : 687794119738060800,
  "created_at" : "2016-01-15 00:35:23 +0000",
  "in_reply_to_screen_name" : "thetruemilhouse",
  "in_reply_to_user_id_str" : "15171407",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "(((Joshi Fischer)))",
      "screen_name" : "thetruemilhouse",
      "indices" : [ 0, 16 ],
      "id_str" : "15171407",
      "id" : 15171407
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "687792558836178944",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11405954774315, 8.753425660123824 ]
  },
  "id_str" : "687793043404144640",
  "in_reply_to_user_id" : 15171407,
  "text" : "@thetruemilhouse indeed I am but that\u2019s besides the point. When in another country some content isn\u2019t available, depending on the country.",
  "id" : 687793043404144640,
  "in_reply_to_status_id" : 687792558836178944,
  "created_at" : "2016-01-15 00:26:54 +0000",
  "in_reply_to_screen_name" : "thetruemilhouse",
  "in_reply_to_user_id_str" : "15171407",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 72 ],
      "url" : "https:\/\/t.co\/ZXYrx4UnqP",
      "expanded_url" : "https:\/\/twitter.com\/nickmullen\/status\/687308787028504576",
      "display_url" : "twitter.com\/nickmullen\/sta\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11405942594023, 8.753433622707051 ]
  },
  "id_str" : "687791866385969154",
  "text" : "There\u2019s one option missing: using all four paws. https:\/\/t.co\/ZXYrx4UnqP",
  "id" : 687791866385969154,
  "created_at" : "2016-01-15 00:22:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "(((Joshi Fischer)))",
      "screen_name" : "thetruemilhouse",
      "indices" : [ 0, 16 ],
      "id_str" : "15171407",
      "id" : 15171407
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 17, 26 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "687787574392389632",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11405942594023, 8.753433622707051 ]
  },
  "id_str" : "687791220412837890",
  "in_reply_to_user_id" : 15171407,
  "text" : "@thetruemilhouse @Senficon and there\u2019s tons of brilliant stuff of German Netflix that I can\u2019t watch while traveling and vice versa.",
  "id" : 687791220412837890,
  "in_reply_to_status_id" : 687787574392389632,
  "created_at" : "2016-01-15 00:19:40 +0000",
  "in_reply_to_screen_name" : "thetruemilhouse",
  "in_reply_to_user_id_str" : "15171407",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "The_Smoking_GNU",
      "indices" : [ 0, 16 ],
      "id_str" : "14535787",
      "id" : 14535787
    }, {
      "name" : "(((Joshi Fischer)))",
      "screen_name" : "thetruemilhouse",
      "indices" : [ 17, 33 ],
      "id_str" : "15171407",
      "id" : 15171407
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "687761304648585216",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11405790822702, 8.753431687192625 ]
  },
  "id_str" : "687762457029427200",
  "in_reply_to_user_id" : 14535787,
  "text" : "@The_Smoking_GNU @thetruemilhouse fun fact: right now I\u2019m paying +\/- the same for the VPN and Netflix\u2026",
  "id" : 687762457029427200,
  "in_reply_to_status_id" : 687761304648585216,
  "created_at" : "2016-01-14 22:25:22 +0000",
  "in_reply_to_screen_name" : "The_Smoking_GNU",
  "in_reply_to_user_id_str" : "14535787",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/AmDmid7hE0",
      "expanded_url" : "https:\/\/twitter.com\/Senficon\/status\/687749703543468033",
      "display_url" : "twitter.com\/Senficon\/statu\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11406042370061, 8.75344458785968 ]
  },
  "id_str" : "687757122487103489",
  "text" : "Two weeks after I finally got a Netflix account they want to make it useless? Ok, back to torrents then\u2026 https:\/\/t.co\/AmDmid7hE0",
  "id" : 687757122487103489,
  "created_at" : "2016-01-14 22:04:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 70 ],
      "url" : "https:\/\/t.co\/jQ9lPcvqlW",
      "expanded_url" : "https:\/\/twitter.com\/SarahNEmerson\/status\/687685054135402496",
      "display_url" : "twitter.com\/SarahNEmerson\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11406021227424, 8.75344110897835 ]
  },
  "id_str" : "687717067244613632",
  "text" : "I so hoped for more than a boring thermometer\u2026 https:\/\/t.co\/jQ9lPcvqlW",
  "id" : 687717067244613632,
  "created_at" : "2016-01-14 19:25:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nyborg",
      "screen_name" : "ny_borg",
      "indices" : [ 0, 8 ],
      "id_str" : "570156398",
      "id" : 570156398
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "687680934473252864",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11405867326756, 8.753418733216243 ]
  },
  "id_str" : "687686727444623360",
  "in_reply_to_user_id" : 570156398,
  "text" : "@ny_borg jo :)",
  "id" : 687686727444623360,
  "in_reply_to_status_id" : 687680934473252864,
  "created_at" : "2016-01-14 17:24:27 +0000",
  "in_reply_to_screen_name" : "ny_borg",
  "in_reply_to_user_id_str" : "570156398",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 81, 93 ],
      "id_str" : "52747896",
      "id" : 52747896
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 94, 107 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 76 ],
      "url" : "https:\/\/t.co\/xThf2rODwG",
      "expanded_url" : "https:\/\/gratipay.com\/opensnp\/",
      "display_url" : "gratipay.com\/opensnp\/"
    } ]
  },
  "geo" : { },
  "id_str" : "687670659401560064",
  "text" : "If Patreon isn\u2019t for you: openSNP is now on gratipay https:\/\/t.co\/xThf2rODwG \/cc @helgerausch @PhilippBayer",
  "id" : 687670659401560064,
  "created_at" : "2016-01-14 16:20:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Blin",
      "screen_name" : "kaiblin",
      "indices" : [ 0, 8 ],
      "id_str" : "124202458",
      "id" : 124202458
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "687622312489795586",
  "geo" : { },
  "id_str" : "687623953423175680",
  "in_reply_to_user_id" : 124202458,
  "text" : "@kaiblin yep, Google Groups works good enough :)",
  "id" : 687623953423175680,
  "in_reply_to_status_id" : 687622312489795586,
  "created_at" : "2016-01-14 13:15:00 +0000",
  "in_reply_to_screen_name" : "kaiblin",
  "in_reply_to_user_id_str" : "124202458",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/iCosXYlFdS",
      "expanded_url" : "https:\/\/s-media-cache-ak0.pinimg.com\/originals\/d0\/45\/8e\/d0458eb51a864832897d1c7f7d1d887b.jpg",
      "display_url" : "s-media-cache-ak0.pinimg.com\/originals\/d0\/4\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11405868734986, 8.753419407342497 ]
  },
  "id_str" : "687620343008223232",
  "text" : "https:\/\/t.co\/iCosXYlFdS",
  "id" : 687620343008223232,
  "created_at" : "2016-01-14 13:00:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/2EWs2sIbVu",
      "expanded_url" : "https:\/\/twitter.com\/herrurbach\/status\/687603043362279424",
      "display_url" : "twitter.com\/herrurbach\/sta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "687610652895100929",
  "text" : "\u00ABThe Manarchist understands other peoples\u2019 oppressions better than they do themselves\u00BB all of this\u2026 \uD83D\uDE2Dhttps:\/\/t.co\/2EWs2sIbVu",
  "id" : 687610652895100929,
  "created_at" : "2016-01-14 12:22:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "687591088207585281",
  "text" : "Sweet, first time organizers just say \u201ERight, not having an all-male panel is important. Do you have recommendations?\u201C instead of arguing.",
  "id" : 687591088207585281,
  "created_at" : "2016-01-14 11:04:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Effy Vayena",
      "screen_name" : "EffyVayena",
      "indices" : [ 0, 11 ],
      "id_str" : "397518511",
      "id" : 397518511
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 12, 25 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "687445333647994880",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11405885108518, 8.75343412730539 ]
  },
  "id_str" : "687534060042858496",
  "in_reply_to_user_id" : 397518511,
  "text" : "@EffyVayena @PhilippBayer yes, but no citation of the paper :)",
  "id" : 687534060042858496,
  "in_reply_to_status_id" : 687445333647994880,
  "created_at" : "2016-01-14 07:17:48 +0000",
  "in_reply_to_screen_name" : "EffyVayena",
  "in_reply_to_user_id_str" : "397518511",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Effy Vayena",
      "screen_name" : "EffyVayena",
      "indices" : [ 69, 80 ],
      "id_str" : "397518511",
      "id" : 397518511
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "687435178470412289",
  "geo" : { },
  "id_str" : "687436355190812673",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer thanks! :) Maybe the next time openSNP could be cited, @EffyVayena? :)",
  "id" : 687436355190812673,
  "in_reply_to_status_id" : 687435178470412289,
  "created_at" : "2016-01-14 00:49:33 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/0pCNQADc3Q",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=h-li3KlTtTA",
      "display_url" : "youtube.com\/watch?v=h-li3K\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "687407961250086912",
  "text" : "We are now faced with the fact that tomorrow is today. We are confronted with the fierce urgency of now https:\/\/t.co\/0pCNQADc3Q",
  "id" : 687407961250086912,
  "created_at" : "2016-01-13 22:56:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/c6wehp877g",
      "expanded_url" : "https:\/\/twitter.com\/widdowquinn\/status\/687376631535648770",
      "display_url" : "twitter.com\/widdowquinn\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "687378316781875201",
  "text" : "Ouch, even I\u2019m already old enough to have made it through 3 \u201Enext-generation\u201C cycles by now\u2026 https:\/\/t.co\/c6wehp877g",
  "id" : 687378316781875201,
  "created_at" : "2016-01-13 20:58:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/1o3s3GNGJG",
      "expanded_url" : "http:\/\/limdauto.github.io\/posts\/2015-11-15-on-vietnamese-writing.html",
      "display_url" : "limdauto.github.io\/posts\/2015-11-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "687376790508146692",
  "text" : "\u00ABto understand that you cannot fight off hunger and poverty without fighting off illiteracy, I salute them\u00BB https:\/\/t.co\/1o3s3GNGJG",
  "id" : 687376790508146692,
  "created_at" : "2016-01-13 20:52:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Izabella Laba",
      "screen_name" : "ilaba",
      "indices" : [ 3, 9 ],
      "id_str" : "122780488",
      "id" : 122780488
    }, {
      "name" : "Azeen Ghorayshi",
      "screen_name" : "azeen",
      "indices" : [ 127, 133 ],
      "id_str" : "256722290",
      "id" : 256722290
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "687363751578841088",
  "text" : "RT @ilaba: Should men be allowed in the lab? I mean, they fall in love with you, then fire you because they can't handle it... @azeen @sean\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Azeen Ghorayshi",
        "screen_name" : "azeen",
        "indices" : [ 116, 122 ],
        "id_str" : "256722290",
        "id" : 256722290
      }, {
        "name" : "Sean Carroll",
        "screen_name" : "seanmcarroll",
        "indices" : [ 123, 136 ],
        "id_str" : "21611239",
        "id" : 21611239
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "687154106025115648",
    "geo" : { },
    "id_str" : "687155435019743232",
    "in_reply_to_user_id" : 122780488,
    "text" : "Should men be allowed in the lab? I mean, they fall in love with you, then fire you because they can't handle it... @azeen @seanmcarroll",
    "id" : 687155435019743232,
    "in_reply_to_status_id" : 687154106025115648,
    "created_at" : "2016-01-13 06:13:17 +0000",
    "in_reply_to_screen_name" : "ilaba",
    "in_reply_to_user_id_str" : "122780488",
    "user" : {
      "name" : "Izabella Laba",
      "screen_name" : "ilaba",
      "protected" : false,
      "id_str" : "122780488",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/616357952211939329\/bR9ODBgm_normal.jpg",
      "id" : 122780488,
      "verified" : false
    }
  },
  "id" : 687363751578841088,
  "created_at" : "2016-01-13 20:01:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/futnk6TVNJ",
      "expanded_url" : "http:\/\/journals.plos.org\/plosone\/article?id=10.1371\/journal.pone.0143047",
      "display_url" : "journals.plos.org\/plosone\/articl\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "687361060769280000",
  "text" : "Using eye tracking of dogs to see how they interpret facial expressions https:\/\/t.co\/futnk6TVNJ",
  "id" : 687361060769280000,
  "created_at" : "2016-01-13 19:50:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jack A Gilbert",
      "screen_name" : "gilbertjacka",
      "indices" : [ 0, 13 ],
      "id_str" : "223529798",
      "id" : 223529798
    }, {
      "name" : "Holly Ganz",
      "screen_name" : "hollyhganz",
      "indices" : [ 14, 25 ],
      "id_str" : "23547345",
      "id" : 23547345
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "687347779157520385",
  "geo" : { },
  "id_str" : "687348209144983554",
  "in_reply_to_user_id" : 223529798,
  "text" : "@gilbertjacka @hollyhganz oh yes, I will!",
  "id" : 687348209144983554,
  "in_reply_to_status_id" : 687347779157520385,
  "created_at" : "2016-01-13 18:59:18 +0000",
  "in_reply_to_screen_name" : "gilbertjacka",
  "in_reply_to_user_id_str" : "223529798",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Holly Ganz",
      "screen_name" : "hollyhganz",
      "indices" : [ 0, 11 ],
      "id_str" : "23547345",
      "id" : 23547345
    }, {
      "name" : "Jack A Gilbert",
      "screen_name" : "gilbertjacka",
      "indices" : [ 12, 25 ],
      "id_str" : "223529798",
      "id" : 223529798
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "687345668017405954",
  "geo" : { },
  "id_str" : "687346526729957376",
  "in_reply_to_user_id" : 23547345,
  "text" : "@hollyhganz @gilbertjacka me too, do poor grad students from europe qualify? :D",
  "id" : 687346526729957376,
  "in_reply_to_status_id" : 687345668017405954,
  "created_at" : "2016-01-13 18:52:36 +0000",
  "in_reply_to_screen_name" : "hollyhganz",
  "in_reply_to_user_id_str" : "23547345",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 66 ],
      "url" : "https:\/\/t.co\/aMUepMFxLE",
      "expanded_url" : "https:\/\/twitter.com\/hullodave\/status\/687293796736958464",
      "display_url" : "twitter.com\/hullodave\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "687296664600731648",
  "text" : "On the battle psychology of Stormtroopers: https:\/\/t.co\/aMUepMFxLE",
  "id" : 687296664600731648,
  "created_at" : "2016-01-13 15:34:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/9NRBAFxkNx",
      "expanded_url" : "http:\/\/travislongcore.net\/2016\/01\/09\/i-stand-with-linda-sue-beck-the-attack-on-science-at-malheur-national-wildlife-refuge\/?utm_content=buffer2119b&utm_medium=social&utm_source=twitter.com&utm_campaign=buffer",
      "display_url" : "travislongcore.net\/2016\/01\/09\/i-s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "687289642169839616",
  "text" : "I Stand with Linda Sue Beck: The Attack on Science at Malheur National Wildlife\u00A0Refuge https:\/\/t.co\/9NRBAFxkNx",
  "id" : 687289642169839616,
  "created_at" : "2016-01-13 15:06:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uD83D\uDCABKelsey Merkley \uD83D\uDCAB",
      "screen_name" : "bella_velo",
      "indices" : [ 0, 11 ],
      "id_str" : "6745972",
      "id" : 6745972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "687269655975751680",
  "geo" : { },
  "id_str" : "687270490050850817",
  "in_reply_to_user_id" : 6745972,
  "text" : "@bella_velo so: good call!",
  "id" : 687270490050850817,
  "in_reply_to_status_id" : 687269655975751680,
  "created_at" : "2016-01-13 13:50:28 +0000",
  "in_reply_to_screen_name" : "bella_velo",
  "in_reply_to_user_id_str" : "6745972",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uD83D\uDCABKelsey Merkley \uD83D\uDCAB",
      "screen_name" : "bella_velo",
      "indices" : [ 0, 11 ],
      "id_str" : "6745972",
      "id" : 6745972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "687269655975751680",
  "geo" : { },
  "id_str" : "687270470270464000",
  "in_reply_to_user_id" : 6745972,
  "text" : "@bella_velo there\u2019s a German book in which a discussion of a friend and me wanting to buy (illegally) strong lasers from China is featured.",
  "id" : 687270470270464000,
  "in_reply_to_status_id" : 687269655975751680,
  "created_at" : "2016-01-13 13:50:23 +0000",
  "in_reply_to_screen_name" : "bella_velo",
  "in_reply_to_user_id_str" : "6745972",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 55 ],
      "url" : "https:\/\/t.co\/ZzjKKgzJoh",
      "expanded_url" : "https:\/\/i.imgur.com\/feZLKRY.gifv",
      "display_url" : "i.imgur.com\/feZLKRY.gifv"
    } ]
  },
  "geo" : { },
  "id_str" : "687269383606022144",
  "text" : "tempted to try this on the cats https:\/\/t.co\/ZzjKKgzJoh",
  "id" : 687269383606022144,
  "created_at" : "2016-01-13 13:46:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "687255519204130816",
  "geo" : { },
  "id_str" : "687255952601563136",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot now I\u2019m a bit curious\u2026",
  "id" : 687255952601563136,
  "in_reply_to_status_id" : 687255519204130816,
  "created_at" : "2016-01-13 12:52:42 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "687244904448290817",
  "geo" : { },
  "id_str" : "687248000310218752",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot ph\u1EDF-p ph\u1EDF-p ph\u1EDF-p!",
  "id" : 687248000310218752,
  "in_reply_to_status_id" : 687244904448290817,
  "created_at" : "2016-01-13 12:21:06 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 47 ],
      "url" : "https:\/\/t.co\/GQNYA6utnS",
      "expanded_url" : "http:\/\/omicsomics.blogspot.de\/2016\/01\/illuminas-unveils-firefly.html",
      "display_url" : "omicsomics.blogspot.de\/2016\/01\/illumi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "687228690103726080",
  "text" : "On the Illumina Firefly https:\/\/t.co\/GQNYA6utnS",
  "id" : 687228690103726080,
  "created_at" : "2016-01-13 11:04:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 0, 14 ],
      "id_str" : "352650591",
      "id" : 352650591
    }, {
      "name" : "\u24EA Rik Smith-Unna \uD83C\uDDF0\uD83C\uDDEA",
      "screen_name" : "blahah404",
      "indices" : [ 15, 25 ],
      "id_str" : "99173786",
      "id" : 99173786
    }, {
      "name" : "Mozilla Science Lab",
      "screen_name" : "MozillaScience",
      "indices" : [ 26, 41 ],
      "id_str" : "1428575976",
      "id" : 1428575976
    }, {
      "name" : "Steph\u24D0nie Wright",
      "screen_name" : "shefw",
      "indices" : [ 42, 48 ],
      "id_str" : "48636190",
      "id" : 48636190
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mozwow",
      "indices" : [ 49, 56 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "687224832853962753",
  "geo" : { },
  "id_str" : "687225510968082432",
  "in_reply_to_user_id" : 352650591,
  "text" : "@Protohedgehog @blahah404 @MozillaScience @shefw #mozwow is fine by me. Just wanted to make sure to not start a competing one :)",
  "id" : 687225510968082432,
  "in_reply_to_status_id" : 687224832853962753,
  "created_at" : "2016-01-13 10:51:44 +0000",
  "in_reply_to_screen_name" : "Protohedgehog",
  "in_reply_to_user_id_str" : "352650591",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u24EA Rik Smith-Unna \uD83C\uDDF0\uD83C\uDDEA",
      "screen_name" : "blahah404",
      "indices" : [ 61, 71 ],
      "id_str" : "99173786",
      "id" : 99173786
    }, {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 72, 86 ],
      "id_str" : "352650591",
      "id" : 352650591
    }, {
      "name" : "Mozilla Science Lab",
      "screen_name" : "MozillaScience",
      "indices" : [ 87, 102 ],
      "id_str" : "1428575976",
      "id" : 1428575976
    }, {
      "name" : "Steph\u24D0nie Wright",
      "screen_name" : "shefw",
      "indices" : [ 103, 109 ],
      "id_str" : "48636190",
      "id" : 48636190
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "687224630566871040",
  "text" : "Found a room for MozWOW \uD83D\uDC4D Btw: is there already a hashtag? \uD83D\uDE0A @blahah404 @Protohedgehog @MozillaScience @shefw",
  "id" : 687224630566871040,
  "created_at" : "2016-01-13 10:48:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 44 ],
      "url" : "https:\/\/t.co\/mjDcirww5S",
      "expanded_url" : "http:\/\/www.bespokeclothing.biz\/images\/thumbs\/large\/images\/products\/chunk\/ss13\/tshirt_nuts.jpg",
      "display_url" : "bespokeclothing.biz\/images\/thumbs\/\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "687215911154126849",
  "geo" : { },
  "id_str" : "687217354636439552",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot i don\u2019t even! https:\/\/t.co\/mjDcirww5S",
  "id" : 687217354636439552,
  "in_reply_to_status_id" : 687215911154126849,
  "created_at" : "2016-01-13 10:19:19 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/rtgILValdn",
      "expanded_url" : "https:\/\/image.spreadshirtmedia.com\/image-server\/v1\/compositions\/106457299\/views\/1,width=235,height=235,appearanceId=16,backgroundColor=f9f9f9,version=1440417743\/Squirrel-Whisperer-T-Shirts.jpg",
      "display_url" : "image.spreadshirtmedia.com\/image-server\/v\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "687215911154126849",
  "geo" : { },
  "id_str" : "687216641709596673",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot werde jetzt nur noch mit so einem t-shirt bekleidet in deine neue Wohnung gehen. https:\/\/t.co\/rtgILValdn",
  "id" : 687216641709596673,
  "in_reply_to_status_id" : 687215911154126849,
  "created_at" : "2016-01-13 10:16:29 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/lgJaXKuvza",
      "expanded_url" : "https:\/\/twitter.com\/The_Smoking_GNU\/status\/687063154266927104",
      "display_url" : "twitter.com\/The_Smoking_GN\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "687202933717512192",
  "text" : "The interactive graphs available inside the movie are a pretty cool idea! https:\/\/t.co\/lgJaXKuvza",
  "id" : 687202933717512192,
  "created_at" : "2016-01-13 09:22:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11404762518207, 8.753417845425984 ]
  },
  "id_str" : "687038601796956161",
  "text" : "@stopifnot :D das charred geht auch ohne offene Flamme:)",
  "id" : 687038601796956161,
  "created_at" : "2016-01-12 22:29:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11405925500912, 8.75343113790434 ]
  },
  "id_str" : "687035185892700160",
  "text" : "@stopifnot wir haben es bislang einfach in der hei\u00DFen Pfanne gemacht :)",
  "id" : 687035185892700160,
  "created_at" : "2016-01-12 22:15:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 34 ],
      "url" : "https:\/\/t.co\/pX3VeLe0Qi",
      "expanded_url" : "http:\/\/www.thekitchn.com\/recipe-vegetarian-pho-vietnamese-noodle-soup-recipes-from-the-kitchn-107312",
      "display_url" : "thekitchn.com\/recipe-vegetar\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11405907846889, 8.753426472999555 ]
  },
  "id_str" : "687033487749181440",
  "text" : "@stopifnot https:\/\/t.co\/pX3VeLe0Qi :)",
  "id" : 687033487749181440,
  "created_at" : "2016-01-12 22:08:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nyborg",
      "screen_name" : "ny_borg",
      "indices" : [ 0, 8 ],
      "id_str" : "570156398",
      "id" : 570156398
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "687031311094136832",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11405907846889, 8.753426472999555 ]
  },
  "id_str" : "687033372678483969",
  "in_reply_to_user_id" : 570156398,
  "text" : "@ny_borg same recipe you and I used :D",
  "id" : 687033372678483969,
  "in_reply_to_status_id" : 687031311094136832,
  "created_at" : "2016-01-12 22:08:15 +0000",
  "in_reply_to_screen_name" : "ny_borg",
  "in_reply_to_user_id_str" : "570156398",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 36 ],
      "url" : "https:\/\/t.co\/XT9p6O8u1g",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BAdHFbohwkj\/",
      "display_url" : "instagram.com\/p\/BAdHFbohwkj\/"
    } ]
  },
  "geo" : { },
  "id_str" : "687030327320121344",
  "text" : "ph\u1EDF-ntastic! https:\/\/t.co\/XT9p6O8u1g",
  "id" : 687030327320121344,
  "created_at" : "2016-01-12 21:56:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "T. Ryan Gregory",
      "screen_name" : "TRyanGregory",
      "indices" : [ 3, 16 ],
      "id_str" : "151257881",
      "id" : 151257881
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/ctBkrljan9",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=4bE26RPUhn0",
      "display_url" : "youtube.com\/watch?v=4bE26R\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "687016304012820482",
  "text" : "RT @TRyanGregory: In which we read funny comments from student evaluations.\n\nhttps:\/\/t.co\/ctBkrljan9",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 59, 82 ],
        "url" : "https:\/\/t.co\/ctBkrljan9",
        "expanded_url" : "https:\/\/www.youtube.com\/watch?v=4bE26RPUhn0",
        "display_url" : "youtube.com\/watch?v=4bE26R\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "686991460080717828",
    "text" : "In which we read funny comments from student evaluations.\n\nhttps:\/\/t.co\/ctBkrljan9",
    "id" : 686991460080717828,
    "created_at" : "2016-01-12 19:21:42 +0000",
    "user" : {
      "name" : "T. Ryan Gregory",
      "screen_name" : "TRyanGregory",
      "protected" : false,
      "id_str" : "151257881",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/954599622\/TRGDNA_normal.jpg",
      "id" : 151257881,
      "verified" : false
    }
  },
  "id" : 687016304012820482,
  "created_at" : "2016-01-12 21:00:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/i1ep2NheFe",
      "expanded_url" : "https:\/\/twitter.com\/marcelsalathe\/status\/686994240619065344",
      "display_url" : "twitter.com\/marcelsalathe\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11405957203708, 8.753426336385248 ]
  },
  "id_str" : "686998188759318529",
  "text" : "Sequence 7 billion genomes, make them publicly available on openSNP, and have participants phenotype themselves!  https:\/\/t.co\/i1ep2NheFe",
  "id" : 686998188759318529,
  "created_at" : "2016-01-12 19:48:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 92 ],
      "url" : "https:\/\/t.co\/mbMAqQruSm",
      "expanded_url" : "https:\/\/twitter.com\/Senficon\/status\/686927206107463681",
      "display_url" : "twitter.com\/Senficon\/statu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "686934657775087618",
  "text" : "Copyright: The worst \u201EChoose Your Own Adventure\u201C game ever designed. https:\/\/t.co\/mbMAqQruSm",
  "id" : 686934657775087618,
  "created_at" : "2016-01-12 15:35:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Schawinski",
      "screen_name" : "kevinschawinski",
      "indices" : [ 0, 16 ],
      "id_str" : "242844365",
      "id" : 242844365
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "686900484037328896",
  "geo" : { },
  "id_str" : "686900713138577410",
  "in_reply_to_user_id" : 242844365,
  "text" : "@kevinschawinski i know, i know\u2026 biomed is slow to the party as always. evolution &amp; genomics are changing though.",
  "id" : 686900713138577410,
  "in_reply_to_status_id" : 686900484037328896,
  "created_at" : "2016-01-12 13:21:06 +0000",
  "in_reply_to_screen_name" : "kevinschawinski",
  "in_reply_to_user_id_str" : "242844365",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Schawinski",
      "screen_name" : "kevinschawinski",
      "indices" : [ 0, 16 ],
      "id_str" : "242844365",
      "id" : 242844365
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 47 ],
      "url" : "https:\/\/t.co\/cDhaAUcyaE",
      "expanded_url" : "http:\/\/biorxiv.org",
      "display_url" : "biorxiv.org"
    } ]
  },
  "in_reply_to_status_id_str" : "686899640529190912",
  "geo" : { },
  "id_str" : "686900381390082049",
  "in_reply_to_user_id" : 242844365,
  "text" : "@kevinschawinski I hope https:\/\/t.co\/cDhaAUcyaE will have the same effect",
  "id" : 686900381390082049,
  "in_reply_to_status_id" : 686899640529190912,
  "created_at" : "2016-01-12 13:19:47 +0000",
  "in_reply_to_screen_name" : "kevinschawinski",
  "in_reply_to_user_id_str" : "242844365",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Schawinski",
      "screen_name" : "kevinschawinski",
      "indices" : [ 0, 16 ],
      "id_str" : "242844365",
      "id" : 242844365
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "686899201653997568",
  "geo" : { },
  "id_str" : "686899489412628485",
  "in_reply_to_user_id" : 242844365,
  "text" : "@kevinschawinski thing is: I get like at least 5-10 \u201Einvites\u201C for their bogus journals, conferences etc. each day.",
  "id" : 686899489412628485,
  "in_reply_to_status_id" : 686899201653997568,
  "created_at" : "2016-01-12 13:16:14 +0000",
  "in_reply_to_screen_name" : "kevinschawinski",
  "in_reply_to_user_id_str" : "242844365",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/iuvZuStxX7",
      "expanded_url" : "http:\/\/cdn.makeagif.com\/media\/7-30-2015\/nXQlEK.gif",
      "display_url" : "cdn.makeagif.com\/media\/7-30-201\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "686899018673336321",
  "text" : "Should start crowdfundin for my next art project: Kicking the ass of all predatory publishers\/conference organizers https:\/\/t.co\/iuvZuStxX7",
  "id" : 686899018673336321,
  "created_at" : "2016-01-12 13:14:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 89 ],
      "url" : "https:\/\/t.co\/rKFEMGaSbH",
      "expanded_url" : "https:\/\/medium.com\/@benpartridge\/reflections-on-no-onion-january-dfeb68959079#.iu6hbbns6",
      "display_url" : "medium.com\/@benpartridge\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "686896747961053184",
  "text" : "No Onion January: \u00ABwhen I got home from work was \u201Cwhite or red?\u201D\u00BB https:\/\/t.co\/rKFEMGaSbH",
  "id" : 686896747961053184,
  "created_at" : "2016-01-12 13:05:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u24EA Rik Smith-Unna \uD83C\uDDF0\uD83C\uDDEA",
      "screen_name" : "blahah404",
      "indices" : [ 0, 10 ],
      "id_str" : "99173786",
      "id" : 99173786
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "686879723910217732",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.12301521389858, 8.75221339280422 ]
  },
  "id_str" : "686880323418886144",
  "in_reply_to_user_id" : 99173786,
  "text" : "@blahah404 to paraphrase: all assemblies are wrong, but some are useful. ;)",
  "id" : 686880323418886144,
  "in_reply_to_status_id" : 686879723910217732,
  "created_at" : "2016-01-12 12:00:05 +0000",
  "in_reply_to_screen_name" : "blahah404",
  "in_reply_to_user_id_str" : "99173786",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 76 ],
      "url" : "https:\/\/t.co\/5OVcwoAxsi",
      "expanded_url" : "http:\/\/endlesspicdump.com\/original\/i%20cant%20even%20playing%20guitar.gif",
      "display_url" : "endlesspicdump.com\/original\/i%20c\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "686872670856712192",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1139816377308, 8.753285609403047 ]
  },
  "id_str" : "686876241526439937",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot this is why you should always wear protection https:\/\/t.co\/5OVcwoAxsi",
  "id" : 686876241526439937,
  "in_reply_to_status_id" : 686872670856712192,
  "created_at" : "2016-01-12 11:43:52 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u24EA Rik Smith-Unna \uD83C\uDDF0\uD83C\uDDEA",
      "screen_name" : "blahah404",
      "indices" : [ 0, 10 ],
      "id_str" : "99173786",
      "id" : 99173786
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "686872656365367296",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11402964022568, 8.751082723591939 ]
  },
  "id_str" : "686873413537906692",
  "in_reply_to_user_id" : 99173786,
  "text" : "@blahah404 don\u2019t tell me you haven\u2019t had your own fair share of poorly assembled genomes\/transcriptomes :D",
  "id" : 686873413537906692,
  "in_reply_to_status_id" : 686872656365367296,
  "created_at" : "2016-01-12 11:32:37 +0000",
  "in_reply_to_screen_name" : "blahah404",
  "in_reply_to_user_id_str" : "99173786",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u24EA Rik Smith-Unna \uD83C\uDDF0\uD83C\uDDEA",
      "screen_name" : "blahah404",
      "indices" : [ 0, 10 ],
      "id_str" : "99173786",
      "id" : 99173786
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "686865189510189057",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11405976386016, 8.753421939475727 ]
  },
  "id_str" : "686866688877445121",
  "in_reply_to_user_id" : 99173786,
  "text" : "@blahah404 only if you and I are attending ;)",
  "id" : 686866688877445121,
  "in_reply_to_status_id" : 686865189510189057,
  "created_at" : "2016-01-12 11:05:54 +0000",
  "in_reply_to_screen_name" : "blahah404",
  "in_reply_to_user_id_str" : "99173786",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 81 ],
      "url" : "https:\/\/t.co\/Es2C1VNpya",
      "expanded_url" : "https:\/\/twitter.com\/eli_schiff\/status\/686590671864516608",
      "display_url" : "twitter.com\/eli_schiff\/sta\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11405977914133, 8.753423080135407 ]
  },
  "id_str" : "686859359482212352",
  "text" : "The UI which is increasingly getting better is so superb. https:\/\/t.co\/Es2C1VNpya",
  "id" : 686859359482212352,
  "created_at" : "2016-01-12 10:36:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "686858567027134464",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11405977914133, 8.753423080135407 ]
  },
  "id_str" : "686858750943195136",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot nein, weil anrufe so selten nicht in einem angeblich besetzt-stadium landen",
  "id" : 686858750943195136,
  "in_reply_to_status_id" : 686858567027134464,
  "created_at" : "2016-01-12 10:34:22 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "686841750846083072",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.114060076108, 8.753428463676677 ]
  },
  "id_str" : "686856841146593280",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot zumindest dein \uD83D\uDCF1 ist doch schon optimiert darauf. It\u2019s not a bug, it\u2019s a feature. \uD83D\uDE02",
  "id" : 686856841146593280,
  "in_reply_to_status_id" : 686841750846083072,
  "created_at" : "2016-01-12 10:26:46 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 83 ],
      "url" : "https:\/\/t.co\/7VA3cSzC0y",
      "expanded_url" : "https:\/\/twitter.com\/TheScienceWeb\/status\/686005558999003137",
      "display_url" : "twitter.com\/TheScienceWeb\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.114060076108, 8.753428463676677 ]
  },
  "id_str" : "686855768486866944",
  "text" : "Damn, I wish I was at the Poorly Assembled Genomes meeting! https:\/\/t.co\/7VA3cSzC0y",
  "id" : 686855768486866944,
  "created_at" : "2016-01-12 10:22:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paulina Dao",
      "screen_name" : "paulina_dao",
      "indices" : [ 0, 12 ],
      "id_str" : "15974415",
      "id" : 15974415
    }, {
      "name" : "beau",
      "screen_name" : "beaugunderson",
      "indices" : [ 13, 27 ],
      "id_str" : "5746882",
      "id" : 5746882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "686665782575562752",
  "geo" : { },
  "id_str" : "686666598422282240",
  "in_reply_to_user_id" : 15974415,
  "text" : "@paulina_dao @beaugunderson who doesn\u2019t! :)",
  "id" : 686666598422282240,
  "in_reply_to_status_id" : 686665782575562752,
  "created_at" : "2016-01-11 21:50:49 +0000",
  "in_reply_to_screen_name" : "paulina_dao",
  "in_reply_to_user_id_str" : "15974415",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 67 ],
      "url" : "https:\/\/t.co\/xZGBBWWSWr",
      "expanded_url" : "https:\/\/twitter.com\/fuzzyatelin\/status\/686633718446960640",
      "display_url" : "twitter.com\/fuzzyatelin\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "686634113869164544",
  "text" : "I\u2019m just applying right-hand rule to P-bar* https:\/\/t.co\/xZGBBWWSWr",
  "id" : 686634113869164544,
  "created_at" : "2016-01-11 19:41:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 41 ],
      "url" : "https:\/\/t.co\/EGauHCvGNo",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=XDqXLuQxRZs",
      "display_url" : "youtube.com\/watch?v=XDqXLu\u2026"
    }, {
      "indices" : [ 42, 65 ],
      "url" : "https:\/\/t.co\/LOkfFMRa6s",
      "expanded_url" : "https:\/\/twitter.com\/sfkale\/status\/686619499760463872",
      "display_url" : "twitter.com\/sfkale\/status\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "686628014763933696",
  "text" : "SF goes Hollywood https:\/\/t.co\/EGauHCvGNo https:\/\/t.co\/LOkfFMRa6s",
  "id" : 686628014763933696,
  "created_at" : "2016-01-11 19:17:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uD83D\uDD25\uD83D\uDC1C\uD83D\uDC78\uD83C\uDFFC",
      "screen_name" : "fireantprincess",
      "indices" : [ 0, 16 ],
      "id_str" : "77216385",
      "id" : 77216385
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "686583340779044871",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11429801587957, 8.753399010755823 ]
  },
  "id_str" : "686598558271803392",
  "in_reply_to_user_id" : 77216385,
  "text" : "@fireantprincess \uD83D\uDE0D",
  "id" : 686598558271803392,
  "in_reply_to_status_id" : 686583340779044871,
  "created_at" : "2016-01-11 17:20:27 +0000",
  "in_reply_to_screen_name" : "fireantprincess",
  "in_reply_to_user_id_str" : "77216385",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 14, 26 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "686594910661681152",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11358655993837, 8.75439561904292 ]
  },
  "id_str" : "686597584899686404",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @helgerausch this means we\u2019re not growing fast enough ;) seriously though: good job \uD83D\uDC4D\uD83C\uDF89",
  "id" : 686597584899686404,
  "in_reply_to_status_id" : 686594910661681152,
  "created_at" : "2016-01-11 17:16:35 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/JrYZFBWgXF",
      "expanded_url" : "https:\/\/twitter.com\/g_fra\/status\/686560734814285824",
      "display_url" : "twitter.com\/g_fra\/status\/6\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "686563559267037184",
  "text" : "\u00ABpeople worldwide are politely requesting that Tom Waits and David Attenborough go to bed early and take care\u2026\u00BB https:\/\/t.co\/JrYZFBWgXF",
  "id" : 686563559267037184,
  "created_at" : "2016-01-11 15:01:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "survivalinthekilling",
      "indices" : [ 112, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "686548920521093120",
  "text" : "\u00ABIt was all very discouraging. Forced to leave our homes, rifles firing over our heads and terrible music too.\u00BB #survivalinthekilling fileds",
  "id" : 686548920521093120,
  "created_at" : "2016-01-11 14:03:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/CzxSU71WwN",
      "expanded_url" : "http:\/\/www.amjbot.org\/content\/99\/2\/349.long",
      "display_url" : "amjbot.org\/content\/99\/2\/3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "686508475929767936",
  "text" : "Navigating the tip of the genomic iceberg: Next-generation sequencing for plant systematics https:\/\/t.co\/CzxSU71WwN",
  "id" : 686508475929767936,
  "created_at" : "2016-01-11 11:22:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leslie McIntosh",
      "screen_name" : "mcintold",
      "indices" : [ 3, 12 ],
      "id_str" : "18190235",
      "id" : 18190235
    }, {
      "name" : "Karl Broman",
      "screen_name" : "kwbroman",
      "indices" : [ 125, 134 ],
      "id_str" : "1237502864",
      "id" : 1237502864
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/lVGHMRpLFS",
      "expanded_url" : "https:\/\/kbroman.wordpress.com\/2015\/09\/09\/reproducibility-is-hard\/?utm_content=buffer235d5&utm_medium=social&utm_source=twitter.com&utm_campaign=buffer",
      "display_url" : "kbroman.wordpress.com\/2015\/09\/09\/rep\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "686505306025766912",
  "text" : "RT @mcintold: \"...organize the data in the form that you expect to be made public\"\nFrom this gem: https:\/\/t.co\/lVGHMRpLFS by @kwbroman #ope\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Karl Broman",
        "screen_name" : "kwbroman",
        "indices" : [ 111, 120 ],
        "id_str" : "1237502864",
        "id" : 1237502864
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "openscience",
        "indices" : [ 121, 133 ]
      } ],
      "urls" : [ {
        "indices" : [ 84, 107 ],
        "url" : "https:\/\/t.co\/lVGHMRpLFS",
        "expanded_url" : "https:\/\/kbroman.wordpress.com\/2015\/09\/09\/reproducibility-is-hard\/?utm_content=buffer235d5&utm_medium=social&utm_source=twitter.com&utm_campaign=buffer",
        "display_url" : "kbroman.wordpress.com\/2015\/09\/09\/rep\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "686265384287117312",
    "text" : "\"...organize the data in the form that you expect to be made public\"\nFrom this gem: https:\/\/t.co\/lVGHMRpLFS by @kwbroman #openscience",
    "id" : 686265384287117312,
    "created_at" : "2016-01-10 19:16:32 +0000",
    "user" : {
      "name" : "Leslie McIntosh",
      "screen_name" : "mcintold",
      "protected" : false,
      "id_str" : "18190235",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/888407624114257922\/DS_zpugR_normal.jpg",
      "id" : 18190235,
      "verified" : false
    }
  },
  "id" : 686505306025766912,
  "created_at" : "2016-01-11 11:09:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Schawinski",
      "screen_name" : "kevinschawinski",
      "indices" : [ 0, 16 ],
      "id_str" : "242844365",
      "id" : 242844365
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 40 ],
      "url" : "https:\/\/t.co\/LPSU4eZCps",
      "expanded_url" : "https:\/\/youtu.be\/9iafa959JvY?t=30s",
      "display_url" : "youtu.be\/9iafa959JvY?t=\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "686494859159552000",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.114059157058, 8.75342054524463 ]
  },
  "id_str" : "686496401946198016",
  "in_reply_to_user_id" : 242844365,
  "text" : "@kevinschawinski https:\/\/t.co\/LPSU4eZCps",
  "id" : 686496401946198016,
  "in_reply_to_status_id" : 686494859159552000,
  "created_at" : "2016-01-11 10:34:31 +0000",
  "in_reply_to_screen_name" : "kevinschawinski",
  "in_reply_to_user_id_str" : "242844365",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael R. Crusoe",
      "screen_name" : "biocrusoe",
      "indices" : [ 0, 10 ],
      "id_str" : "17645638",
      "id" : 17645638
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "686494681539153920",
  "geo" : { },
  "id_str" : "686494858555600897",
  "in_reply_to_user_id" : 17645638,
  "text" : "@biocrusoe awww, I\u2019m taking those late submissions \uD83D\uDE3B\uD83D\uDC9C",
  "id" : 686494858555600897,
  "in_reply_to_status_id" : 686494681539153920,
  "created_at" : "2016-01-11 10:28:23 +0000",
  "in_reply_to_screen_name" : "biocrusoe",
  "in_reply_to_user_id_str" : "17645638",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/ZHbpZDchhk",
      "expanded_url" : "http:\/\/journals.plos.org\/plosbiology\/article?id=10.1371\/journal.pbio.1002350",
      "display_url" : "journals.plos.org\/plosbiology\/ar\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "686494550651727873",
  "text" : "Forecasting Ecological Genomics: High-Tech Animal Instrumentation Meets High-Throughput Sequencing https:\/\/t.co\/ZHbpZDchhk",
  "id" : 686494550651727873,
  "created_at" : "2016-01-11 10:27:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/BgVl8xi9w0",
      "expanded_url" : "https:\/\/peerj.com\/articles\/1559\/",
      "display_url" : "peerj.com\/articles\/1559\/"
    } ]
  },
  "geo" : { },
  "id_str" : "686490105759006720",
  "text" : "\u00ABhuman-mediated dispersal is the main driving force increasing the risk of [non-native plant] invasion in Iceland\u00BB https:\/\/t.co\/BgVl8xi9w0",
  "id" : 686490105759006720,
  "created_at" : "2016-01-11 10:09:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 62 ],
      "url" : "https:\/\/t.co\/SzgUISEihg",
      "expanded_url" : "http:\/\/whatshouldwecallgradschool.tumblr.com\/post\/137057592126\/from-phd-to-post-doc",
      "display_url" : "whatshouldwecallgradschool.tumblr.com\/post\/137057592\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "686483901087375361",
  "text" : "it always stays like this, doesn\u2019t it? https:\/\/t.co\/SzgUISEihg",
  "id" : 686483901087375361,
  "created_at" : "2016-01-11 09:44:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/E5jQYV9z4F",
      "expanded_url" : "http:\/\/www.nytimes.com\/2016\/01\/07\/fashion\/gifs-donald-trump-hillary-clinton-campaign-season.html?smid=tw-nytimes&smtyp=cur",
      "display_url" : "nytimes.com\/2016\/01\/07\/fas\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "686471875397074944",
  "text" : "\u2018Political GIF editor\u2019, that\u2019s a job title I could envision for myself one day https:\/\/t.co\/E5jQYV9z4F",
  "id" : 686471875397074944,
  "created_at" : "2016-01-11 08:57:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/xKNEcCqlvN",
      "expanded_url" : "https:\/\/twitter.com\/PGorg\/status\/682259915197386752",
      "display_url" : "twitter.com\/PGorg\/status\/6\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "686466398843998208",
  "text" : "Go and nominate people doing great work in participant-centered research. I already submitted my nominations. https:\/\/t.co\/xKNEcCqlvN",
  "id" : 686466398843998208,
  "created_at" : "2016-01-11 08:35:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "beau",
      "screen_name" : "beaugunderson",
      "indices" : [ 0, 14 ],
      "id_str" : "5746882",
      "id" : 5746882
    }, {
      "name" : "Paulina Dao",
      "screen_name" : "paulina_dao",
      "indices" : [ 15, 27 ],
      "id_str" : "15974415",
      "id" : 15974415
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 86 ],
      "url" : "https:\/\/t.co\/JNVi9DXVbx",
      "expanded_url" : "https:\/\/www.flickr.com\/photos\/gedankenstuecke\/6005015226\/in\/dateposted-public\/",
      "display_url" : "flickr.com\/photos\/gedanke\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "686451051675815936",
  "geo" : { },
  "id_str" : "686458476034437120",
  "in_reply_to_user_id" : 5746882,
  "text" : "@beaugunderson @paulina_dao looks so similar to ours! Great :) https:\/\/t.co\/JNVi9DXVbx",
  "id" : 686458476034437120,
  "in_reply_to_status_id" : 686451051675815936,
  "created_at" : "2016-01-11 08:03:49 +0000",
  "in_reply_to_screen_name" : "beaugunderson",
  "in_reply_to_user_id_str" : "5746882",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paulina Dao",
      "screen_name" : "paulina_dao",
      "indices" : [ 0, 12 ],
      "id_str" : "15974415",
      "id" : 15974415
    }, {
      "name" : "beau",
      "screen_name" : "beaugunderson",
      "indices" : [ 13, 27 ],
      "id_str" : "5746882",
      "id" : 5746882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "686441256872837120",
  "geo" : { },
  "id_str" : "686457939981414400",
  "in_reply_to_user_id" : 15974415,
  "text" : "@paulina_dao @beaugunderson thanks! :)",
  "id" : 686457939981414400,
  "in_reply_to_status_id" : 686441256872837120,
  "created_at" : "2016-01-11 08:01:41 +0000",
  "in_reply_to_screen_name" : "paulina_dao",
  "in_reply_to_user_id_str" : "15974415",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "beau",
      "screen_name" : "beaugunderson",
      "indices" : [ 0, 14 ],
      "id_str" : "5746882",
      "id" : 5746882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "686309185923878913",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11405902090827, 8.753428010185928 ]
  },
  "id_str" : "686324259770204161",
  "in_reply_to_user_id" : 5746882,
  "text" : "@beaugunderson thanks so much, you are the best. I helped some class rooms on donorschoose \uD83D\uDE0A\uD83D\uDC96\uD83C\uDF89",
  "id" : 686324259770204161,
  "in_reply_to_status_id" : 686309185923878913,
  "created_at" : "2016-01-10 23:10:29 +0000",
  "in_reply_to_screen_name" : "beaugunderson",
  "in_reply_to_user_id_str" : "5746882",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "beau",
      "screen_name" : "beaugunderson",
      "indices" : [ 0, 14 ],
      "id_str" : "5746882",
      "id" : 5746882
    }, {
      "name" : "catmapper",
      "screen_name" : "catmapper",
      "indices" : [ 15, 25 ],
      "id_str" : "566755910",
      "id" : 566755910
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "686309379738451968",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11405902090827, 8.753428010185928 ]
  },
  "id_str" : "686324090114830336",
  "in_reply_to_user_id" : 5746882,
  "text" : "@beaugunderson @catmapper sweet, really hope I\u2019ll visit Portland this year!",
  "id" : 686324090114830336,
  "in_reply_to_status_id" : 686309379738451968,
  "created_at" : "2016-01-10 23:09:49 +0000",
  "in_reply_to_screen_name" : "beaugunderson",
  "in_reply_to_user_id_str" : "5746882",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonas",
      "screen_name" : "lsanoj",
      "indices" : [ 0, 7 ],
      "id_str" : "18918915",
      "id" : 18918915
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "686304675516264450",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11405902090827, 8.753428010185928 ]
  },
  "id_str" : "686323971726438400",
  "in_reply_to_user_id" : 18918915,
  "text" : "@lsanoj awww! \uD83D\uDC96 hattest du einen sch\u00F6nen Tag? :)",
  "id" : 686323971726438400,
  "in_reply_to_status_id" : 686304675516264450,
  "created_at" : "2016-01-10 23:09:20 +0000",
  "in_reply_to_screen_name" : "lsanoj",
  "in_reply_to_user_id_str" : "18918915",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nazeefa",
      "screen_name" : "NazeefaFatima",
      "indices" : [ 0, 14 ],
      "id_str" : "37054704",
      "id" : 37054704
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "686271057649602560",
  "geo" : { },
  "id_str" : "686271957365579777",
  "in_reply_to_user_id" : 37054704,
  "text" : "@NazeefaFatima thanks so much! \uD83D\uDE3B",
  "id" : 686271957365579777,
  "in_reply_to_status_id" : 686271057649602560,
  "created_at" : "2016-01-10 19:42:39 +0000",
  "in_reply_to_screen_name" : "NazeefaFatima",
  "in_reply_to_user_id_str" : "37054704",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "beau",
      "screen_name" : "beaugunderson",
      "indices" : [ 0, 14 ],
      "id_str" : "5746882",
      "id" : 5746882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "686266612488384513",
  "geo" : { },
  "id_str" : "686271746614411264",
  "in_reply_to_user_id" : 5746882,
  "text" : "@beaugunderson thanks! And no special recommendations for german counterparts. So feel free to use your fav US one :)",
  "id" : 686271746614411264,
  "in_reply_to_status_id" : 686266612488384513,
  "created_at" : "2016-01-10 19:41:49 +0000",
  "in_reply_to_screen_name" : "beaugunderson",
  "in_reply_to_user_id_str" : "5746882",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "undivided@yahoo.de",
      "screen_name" : "undivid_ed",
      "indices" : [ 0, 11 ],
      "id_str" : "438256823",
      "id" : 438256823
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "686262336093556736",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.10901290699162, 8.757204776693914 ]
  },
  "id_str" : "686263011154259968",
  "in_reply_to_user_id" : 438256823,
  "text" : "@undivid_ed I saw those, thanks :D",
  "id" : 686263011154259968,
  "in_reply_to_status_id" : 686262336093556736,
  "created_at" : "2016-01-10 19:07:06 +0000",
  "in_reply_to_screen_name" : "undivid_ed",
  "in_reply_to_user_id_str" : "438256823",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 63 ],
      "url" : "https:\/\/t.co\/7WjSlNAa5Q",
      "expanded_url" : "https:\/\/twitter.com\/beaugunderson\/status\/681039429943734272",
      "display_url" : "twitter.com\/beaugunderson\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.10893710430799, 8.757267891477186 ]
  },
  "id_str" : "686256593239945216",
  "text" : "It\u2019s mine, so please do the same today. https:\/\/t.co\/7WjSlNAa5Q",
  "id" : 686256593239945216,
  "created_at" : "2016-01-10 18:41:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katha",
      "screen_name" : "kathakatze",
      "indices" : [ 0, 11 ],
      "id_str" : "541170257",
      "id" : 541170257
    }, {
      "name" : "malech maltz",
      "screen_name" : "malech",
      "indices" : [ 12, 19 ],
      "id_str" : "784085846391713793",
      "id" : 784085846391713793
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "686226028818219008",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1140591793501, 8.75343792555173 ]
  },
  "id_str" : "686243861899931648",
  "in_reply_to_user_id" : 541170257,
  "text" : "@kathakatze @malech vielen Dank euch beiden :D \uD83C\uDF89",
  "id" : 686243861899931648,
  "in_reply_to_status_id" : 686226028818219008,
  "created_at" : "2016-01-10 17:51:01 +0000",
  "in_reply_to_screen_name" : "kathakatze",
  "in_reply_to_user_id_str" : "541170257",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Wenz",
      "screen_name" : "sparta644",
      "indices" : [ 0, 10 ],
      "id_str" : "17988190",
      "id" : 17988190
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "686226981877329920",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1140591793501, 8.75343792555173 ]
  },
  "id_str" : "686243782585638912",
  "in_reply_to_user_id" : 17988190,
  "text" : "@sparta644 danke :)",
  "id" : 686243782585638912,
  "in_reply_to_status_id" : 686226981877329920,
  "created_at" : "2016-01-10 17:50:42 +0000",
  "in_reply_to_screen_name" : "sparta644",
  "in_reply_to_user_id_str" : "17988190",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Auntie Silke",
      "screen_name" : "TanteSilke",
      "indices" : [ 0, 11 ],
      "id_str" : "56062177",
      "id" : 56062177
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "686228360838660096",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1140591793501, 8.75343792555173 ]
  },
  "id_str" : "686243764503994368",
  "in_reply_to_user_id" : 56062177,
  "text" : "@TanteSilke danke :*",
  "id" : 686243764503994368,
  "in_reply_to_status_id" : 686228360838660096,
  "created_at" : "2016-01-10 17:50:37 +0000",
  "in_reply_to_screen_name" : "TanteSilke",
  "in_reply_to_user_id_str" : "56062177",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christoph Steltner",
      "screen_name" : "nplhse",
      "indices" : [ 0, 7 ],
      "id_str" : "111716214",
      "id" : 111716214
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "686204202763325441",
  "geo" : { },
  "id_str" : "686219408822386688",
  "in_reply_to_user_id" : 111716214,
  "text" : "@nplhse vielen Dank :)",
  "id" : 686219408822386688,
  "in_reply_to_status_id" : 686204202763325441,
  "created_at" : "2016-01-10 16:13:51 +0000",
  "in_reply_to_screen_name" : "nplhse",
  "in_reply_to_user_id_str" : "111716214",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katha",
      "screen_name" : "kathakatze",
      "indices" : [ 0, 11 ],
      "id_str" : "541170257",
      "id" : 541170257
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "686206199201689601",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11406022978333, 8.753425568911833 ]
  },
  "id_str" : "686219388706533376",
  "in_reply_to_user_id" : 541170257,
  "text" : "@kathakatze danke!",
  "id" : 686219388706533376,
  "in_reply_to_status_id" : 686206199201689601,
  "created_at" : "2016-01-10 16:13:46 +0000",
  "in_reply_to_screen_name" : "kathakatze",
  "in_reply_to_user_id_str" : "541170257",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Pardy",
      "screen_name" : "BrianPardy",
      "indices" : [ 0, 11 ],
      "id_str" : "611699110",
      "id" : 611699110
    }, {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 12, 21 ],
      "id_str" : "14245811",
      "id" : 14245811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "686200992942153728",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11405985622495, 8.753430912155599 ]
  },
  "id_str" : "686201333607706624",
  "in_reply_to_user_id" : 611699110,
  "text" : "@BrianPardy @wilbanks great to hear, thx! And you can upload multiple data sets to one account, so eg having 3 diff. SNP chips works as well",
  "id" : 686201333607706624,
  "in_reply_to_status_id" : 686200992942153728,
  "created_at" : "2016-01-10 15:02:01 +0000",
  "in_reply_to_screen_name" : "BrianPardy",
  "in_reply_to_user_id_str" : "611699110",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Pardy",
      "screen_name" : "BrianPardy",
      "indices" : [ 0, 11 ],
      "id_str" : "611699110",
      "id" : 611699110
    }, {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 12, 21 ],
      "id_str" : "14245811",
      "id" : 14245811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "686199125415718912",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11339660613634, 8.754264547385011 ]
  },
  "id_str" : "686199485945507840",
  "in_reply_to_user_id" : 611699110,
  "text" : "@BrianPardy @wilbanks and 23andMe you don\u2019t have to recode, accept numerous formats, including 23andMe straight away.",
  "id" : 686199485945507840,
  "in_reply_to_status_id" : 686199125415718912,
  "created_at" : "2016-01-10 14:54:41 +0000",
  "in_reply_to_screen_name" : "BrianPardy",
  "in_reply_to_user_id_str" : "611699110",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Pardy",
      "screen_name" : "BrianPardy",
      "indices" : [ 0, 11 ],
      "id_str" : "611699110",
      "id" : 611699110
    }, {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 12, 21 ],
      "id_str" : "14245811",
      "id" : 14245811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "686199125415718912",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11404937868745, 8.75345463246472 ]
  },
  "id_str" : "686199379246628867",
  "in_reply_to_user_id" : 611699110,
  "text" : "@BrianPardy @wilbanks you can set links from your user to external services. No API for merging data sets like that yet.",
  "id" : 686199379246628867,
  "in_reply_to_status_id" : 686199125415718912,
  "created_at" : "2016-01-10 14:54:15 +0000",
  "in_reply_to_screen_name" : "BrianPardy",
  "in_reply_to_user_id_str" : "611699110",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Pardy",
      "screen_name" : "BrianPardy",
      "indices" : [ 0, 11 ],
      "id_str" : "611699110",
      "id" : 611699110
    }, {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 12, 21 ],
      "id_str" : "14245811",
      "id" : 14245811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "686196167827451904",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11405913739998, 8.75344110903009 ]
  },
  "id_str" : "686196353127575552",
  "in_reply_to_user_id" : 611699110,
  "text" : "@BrianPardy @wilbanks openSNP does accept generic vcf files ;)",
  "id" : 686196353127575552,
  "in_reply_to_status_id" : 686196167827451904,
  "created_at" : "2016-01-10 14:42:14 +0000",
  "in_reply_to_screen_name" : "BrianPardy",
  "in_reply_to_user_id_str" : "611699110",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Frau Fragmente",
      "screen_name" : "fragmente",
      "indices" : [ 0, 10 ],
      "id_str" : "7207642",
      "id" : 7207642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "686119679463682048",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1140591259511, 8.753439266816956 ]
  },
  "id_str" : "686193757272829952",
  "in_reply_to_user_id" : 7207642,
  "text" : "@fragmente was ein Geburtstagsgeschenk! ;)",
  "id" : 686193757272829952,
  "in_reply_to_status_id" : 686119679463682048,
  "created_at" : "2016-01-10 14:31:55 +0000",
  "in_reply_to_screen_name" : "fragmente",
  "in_reply_to_user_id_str" : "7207642",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 0, 9 ],
      "id_str" : "14245811",
      "id" : 14245811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "686192666053373952",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1140591259511, 8.753439266816956 ]
  },
  "id_str" : "686193028944531457",
  "in_reply_to_user_id" : 14245811,
  "text" : "@wilbanks thanks \uD83D\uDE0D\uD83D\uDC96",
  "id" : 686193028944531457,
  "in_reply_to_status_id" : 686192666053373952,
  "created_at" : "2016-01-10 14:29:01 +0000",
  "in_reply_to_screen_name" : "wilbanks",
  "in_reply_to_user_id_str" : "14245811",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/w8xp8ashvt",
      "expanded_url" : "https:\/\/twitter.com\/wilbanks\/status\/686192666053373952",
      "display_url" : "twitter.com\/wilbanks\/statu\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11405959467258, 8.75343541338519 ]
  },
  "id_str" : "686192991657177088",
  "text" : "All I want for my birthday is the openSNP database to grow to over 2500 data sets https:\/\/t.co\/w8xp8ashvt",
  "id" : 686192991657177088,
  "created_at" : "2016-01-10 14:28:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Liliana Demir \uD83C\uDDEA\uD83C\uDDFA",
      "screen_name" : "Cohnina",
      "indices" : [ 0, 8 ],
      "id_str" : "15438679",
      "id" : 15438679
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "686165060335591425",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.10723965471944, 8.740763832008454 ]
  },
  "id_str" : "686165206393839616",
  "in_reply_to_user_id" : 15438679,
  "text" : "@Cohnina danke! \uD83D\uDE0A",
  "id" : 686165206393839616,
  "in_reply_to_status_id" : 686165060335591425,
  "created_at" : "2016-01-10 12:38:28 +0000",
  "in_reply_to_screen_name" : "Cohnina",
  "in_reply_to_user_id_str" : "15438679",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Frau Fragmente",
      "screen_name" : "fragmente",
      "indices" : [ 0, 10 ],
      "id_str" : "7207642",
      "id" : 7207642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "686104826896330752",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11405959381896, 8.753434467134616 ]
  },
  "id_str" : "686131106823991296",
  "in_reply_to_user_id" : 7207642,
  "text" : "@fragmente Danke &lt;3",
  "id" : 686131106823991296,
  "in_reply_to_status_id" : 686104826896330752,
  "created_at" : "2016-01-10 10:22:58 +0000",
  "in_reply_to_screen_name" : "fragmente",
  "in_reply_to_user_id_str" : "7207642",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "undivided@yahoo.de",
      "screen_name" : "undivid_ed",
      "indices" : [ 0, 11 ],
      "id_str" : "438256823",
      "id" : 438256823
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "685948796350676992",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11405996460572, 8.753442888499197 ]
  },
  "id_str" : "686001672859074564",
  "in_reply_to_user_id" : 438256823,
  "text" : "@undivid_ed danke :)",
  "id" : 686001672859074564,
  "in_reply_to_status_id" : 685948796350676992,
  "created_at" : "2016-01-10 01:48:38 +0000",
  "in_reply_to_screen_name" : "undivid_ed",
  "in_reply_to_user_id_str" : "438256823",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonas",
      "screen_name" : "lsanoj",
      "indices" : [ 0, 7 ],
      "id_str" : "18918915",
      "id" : 18918915
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "685939323187900416",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11400916996539, 8.753518026205867 ]
  },
  "id_str" : "685960481232781312",
  "in_reply_to_user_id" : 18918915,
  "text" : "@lsanoj alles gute, gro\u00DFer! :)",
  "id" : 685960481232781312,
  "in_reply_to_status_id" : 685939323187900416,
  "created_at" : "2016-01-09 23:04:57 +0000",
  "in_reply_to_screen_name" : "lsanoj",
  "in_reply_to_user_id_str" : "18918915",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Balluff",
      "screen_name" : "JohnBalluff",
      "indices" : [ 0, 12 ],
      "id_str" : "740602244",
      "id" : 740602244
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "685858225883856896",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11405920747653, 8.753435962402726 ]
  },
  "id_str" : "685858928421421056",
  "in_reply_to_user_id" : 740602244,
  "text" : "@JohnBalluff leider konnte ich von den stereotyp rassistischen Bildern keins online finden.",
  "id" : 685858928421421056,
  "in_reply_to_status_id" : 685858225883856896,
  "created_at" : "2016-01-09 16:21:25 +0000",
  "in_reply_to_screen_name" : "JohnBalluff",
  "in_reply_to_user_id_str" : "740602244",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Balluff",
      "screen_name" : "JohnBalluff",
      "indices" : [ 0, 12 ],
      "id_str" : "740602244",
      "id" : 740602244
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "685858225883856896",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11404109217048, 8.753457773167293 ]
  },
  "id_str" : "685858573100920832",
  "in_reply_to_user_id" : 740602244,
  "text" : "@JohnBalluff naja, unter dem Deckmantel \u2018Science Center\u2019 nur nackte Frauen zu zeigen (Und iirc keinen einzigen Mann)\u2026",
  "id" : 685858573100920832,
  "in_reply_to_status_id" : 685858225883856896,
  "created_at" : "2016-01-09 16:20:01 +0000",
  "in_reply_to_screen_name" : "JohnBalluff",
  "in_reply_to_user_id_str" : "740602244",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Balluff",
      "screen_name" : "JohnBalluff",
      "indices" : [ 0, 12 ],
      "id_str" : "740602244",
      "id" : 740602244
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 69 ],
      "url" : "https:\/\/t.co\/9JdCnF20qG",
      "expanded_url" : "http:\/\/www.exploramuseum.de\/images\/pressefotos\/anaglypheJessy2_m.jpg",
      "display_url" : "exploramuseum.de\/images\/pressef\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "685855836359491584",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1140600937513, 8.75341904746256 ]
  },
  "id_str" : "685856539954012160",
  "in_reply_to_user_id" : 740602244,
  "text" : "@JohnBalluff ein guter Teil besteht aus sowas https:\/\/t.co\/9JdCnF20qG",
  "id" : 685856539954012160,
  "in_reply_to_status_id" : 685855836359491584,
  "created_at" : "2016-01-09 16:11:56 +0000",
  "in_reply_to_screen_name" : "JohnBalluff",
  "in_reply_to_user_id_str" : "740602244",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "EXPLORA",
      "screen_name" : "exploramuseum",
      "indices" : [ 0, 14 ],
      "id_str" : "79746194",
      "id" : 79746194
    }, {
      "name" : "Katha",
      "screen_name" : "kathakatze",
      "indices" : [ 15, 26 ],
      "id_str" : "541170257",
      "id" : 541170257
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "685854131337191424",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11405959808395, 8.75342162775451 ]
  },
  "id_str" : "685854620887945216",
  "in_reply_to_user_id" : 79746194,
  "text" : "@exploramuseum @kathakatze den Sexismus hingegen nehmen sie an, ja?",
  "id" : 685854620887945216,
  "in_reply_to_status_id" : 685854131337191424,
  "created_at" : "2016-01-09 16:04:18 +0000",
  "in_reply_to_screen_name" : "exploramuseum",
  "in_reply_to_user_id_str" : "79746194",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uD83D\uDCABKelsey Merkley \uD83D\uDCAB",
      "screen_name" : "bella_velo",
      "indices" : [ 0, 11 ],
      "id_str" : "6745972",
      "id" : 6745972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "685853032958029824",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11406107700934, 8.753443122945262 ]
  },
  "id_str" : "685853888449228801",
  "in_reply_to_user_id" : 6745972,
  "text" : "@bella_velo it may even be paleo, cheers! \uD83C\uDF78",
  "id" : 685853888449228801,
  "in_reply_to_status_id" : 685853032958029824,
  "created_at" : "2016-01-09 16:01:24 +0000",
  "in_reply_to_screen_name" : "bella_velo",
  "in_reply_to_user_id_str" : "6745972",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dierk Haasis",
      "screen_name" : "Evo2Me",
      "indices" : [ 0, 7 ],
      "id_str" : "22910316",
      "id" : 22910316
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "685844444885741569",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11405973092572, 8.753419771088993 ]
  },
  "id_str" : "685844887091167237",
  "in_reply_to_user_id" : 22910316,
  "text" : "@Evo2Me vielleicht, vielleicht auch nicht. Wer deren Exponate kennt wird denken k\u00F6nnen das es bei denen System ist\u2026",
  "id" : 685844887091167237,
  "in_reply_to_status_id" : 685844444885741569,
  "created_at" : "2016-01-09 15:25:38 +0000",
  "in_reply_to_screen_name" : "Evo2Me",
  "in_reply_to_user_id_str" : "22910316",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katha",
      "screen_name" : "kathakatze",
      "indices" : [ 0, 11 ],
      "id_str" : "541170257",
      "id" : 541170257
    }, {
      "name" : "EXPLORA",
      "screen_name" : "exploramuseum",
      "indices" : [ 12, 26 ],
      "id_str" : "79746194",
      "id" : 79746194
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "685844177154895872",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11405973092572, 8.753419771088993 ]
  },
  "id_str" : "685844319463444480",
  "in_reply_to_user_id" : 541170257,
  "text" : "@kathakatze @exploramuseum einer der widerlichsten Orte Frankfurts. Und das will schon was heissen :D",
  "id" : 685844319463444480,
  "in_reply_to_status_id" : 685844177154895872,
  "created_at" : "2016-01-09 15:23:22 +0000",
  "in_reply_to_screen_name" : "kathakatze",
  "in_reply_to_user_id_str" : "541170257",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/CwuBcLVd6V",
      "expanded_url" : "https:\/\/twitter.com\/exploramuseum\/status\/685768684070158336",
      "display_url" : "twitter.com\/exploramuseum\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11405977108738, 8.75341966399361 ]
  },
  "id_str" : "685843835625275392",
  "text" : "Auch wenig \u00FCberraschend bei den sexistischen und rassistischen Exponaten die sie in ihrem \u201CMuseum\u201D haben\u2026 https:\/\/t.co\/CwuBcLVd6V",
  "id" : 685843835625275392,
  "created_at" : "2016-01-09 15:21:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11312415895878, 8.755240329093807 ]
  },
  "id_str" : "685832076566880261",
  "text" : "I went to WebMD and now I\u2019m convinced my car has vee-belt cancer!",
  "id" : 685832076566880261,
  "created_at" : "2016-01-09 14:34:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 33 ],
      "url" : "https:\/\/t.co\/YjBfror6Y7",
      "expanded_url" : "http:\/\/dogswithtonguestickingoutalittle.tumblr.com\/",
      "display_url" : "\u2026thtonguestickingoutalittle.tumblr.com"
    } ]
  },
  "geo" : { },
  "id_str" : "685621638545715202",
  "text" : "i\u2019m sold! https:\/\/t.co\/YjBfror6Y7",
  "id" : 685621638545715202,
  "created_at" : "2016-01-09 00:38:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Appropriate Tributes",
      "screen_name" : "godtributes",
      "indices" : [ 0, 12 ],
      "id_str" : "2566358196",
      "id" : 2566358196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "685594630730158081",
  "geo" : { },
  "id_str" : "685594708010221568",
  "in_reply_to_user_id" : 2566358196,
  "text" : "@godtributes poop goddess is best goddess!",
  "id" : 685594708010221568,
  "in_reply_to_status_id" : 685594630730158081,
  "created_at" : "2016-01-08 22:51:30 +0000",
  "in_reply_to_screen_name" : "godtributes",
  "in_reply_to_user_id_str" : "2566358196",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 82 ],
      "url" : "https:\/\/t.co\/bjRrUiqcJI",
      "expanded_url" : "http:\/\/arstechnica.com\/science\/2016\/01\/freeze-dried-poop-pills-being-tested-for-obesity-treatment\/",
      "display_url" : "arstechnica.com\/science\/2016\/0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "685594605941862400",
  "text" : "Freeze-dried poop pills being tested for obesity treatment https:\/\/t.co\/bjRrUiqcJI",
  "id" : 685594605941862400,
  "created_at" : "2016-01-08 22:51:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 71 ],
      "url" : "https:\/\/t.co\/El7otXB3xG",
      "expanded_url" : "http:\/\/www.theatlantic.com\/science\/archive\/2016\/01\/the-incredible-thing-we-do-during-conversations\/422439\/",
      "display_url" : "theatlantic.com\/science\/archiv\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "685582002750406656",
  "text" : "The Incredible Thing We Do During Conversations https:\/\/t.co\/El7otXB3xG",
  "id" : 685582002750406656,
  "created_at" : "2016-01-08 22:01:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Turner",
      "screen_name" : "genetics_blog",
      "indices" : [ 0, 14 ],
      "id_str" : "923639552874557440",
      "id" : 923639552874557440
    }, {
      "name" : "FiveThirtyEight",
      "screen_name" : "FiveThirtyEight",
      "indices" : [ 15, 31 ],
      "id_str" : "2303751216",
      "id" : 2303751216
    }, {
      "name" : "Oliver Roeder",
      "screen_name" : "ollie",
      "indices" : [ 32, 38 ],
      "id_str" : "8593862",
      "id" : 8593862
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "685552614071742465",
  "geo" : { },
  "id_str" : "685576349017370625",
  "in_reply_to_user_id" : 20444825,
  "text" : "@genetics_blog @FiveThirtyEight @ollie I think my simulation might have turned out a good solution as well! Just handed it in :-)",
  "id" : 685576349017370625,
  "in_reply_to_status_id" : 685552614071742465,
  "created_at" : "2016-01-08 21:38:33 +0000",
  "in_reply_to_screen_name" : "strnr",
  "in_reply_to_user_id_str" : "20444825",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/EfWuWpykCU",
      "expanded_url" : "https:\/\/twitter.com\/PicPedant\/status\/685537481274593280",
      "display_url" : "twitter.com\/PicPedant\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "685552038961364993",
  "text" : "What I wish for every day when I see the account RT\u2019d into my timeline. https:\/\/t.co\/EfWuWpykCU",
  "id" : 685552038961364993,
  "created_at" : "2016-01-08 20:01:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "malech maltz",
      "screen_name" : "malech",
      "indices" : [ 0, 7 ],
      "id_str" : "784085846391713793",
      "id" : 784085846391713793
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "685547442780127232",
  "text" : "@malech okay! \uD83D\uDC4D\uD83D\uDE0A",
  "id" : 685547442780127232,
  "created_at" : "2016-01-08 19:43:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "malech maltz",
      "screen_name" : "malech",
      "indices" : [ 0, 7 ],
      "id_str" : "784085846391713793",
      "id" : 784085846391713793
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "685547231370473473",
  "text" : "@malech btw. hast du deine Hose gefunden? \uD83D\uDE09",
  "id" : 685547231370473473,
  "created_at" : "2016-01-08 19:42:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "malech maltz",
      "screen_name" : "malech",
      "indices" : [ 0, 7 ],
      "id_str" : "784085846391713793",
      "id" : 784085846391713793
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "685547152190402560",
  "text" : "@malech danke \uD83D\uDE0D",
  "id" : 685547152190402560,
  "created_at" : "2016-01-08 19:42:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "685515813152002049",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11405611415404, 8.753472268589542 ]
  },
  "id_str" : "685516602817777664",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot waking you up? :p",
  "id" : 685516602817777664,
  "in_reply_to_status_id" : 685515813152002049,
  "created_at" : "2016-01-08 17:41:09 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nazeefa",
      "screen_name" : "NazeefaFatima",
      "indices" : [ 0, 14 ],
      "id_str" : "37054704",
      "id" : 37054704
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "685495875133640709",
  "geo" : { },
  "id_str" : "685496971784765440",
  "in_reply_to_user_id" : 37054704,
  "text" : "@NazeefaFatima if you want to do it, do it. Basically no one feels intelligent enough to do science.",
  "id" : 685496971784765440,
  "in_reply_to_status_id" : 685495875133640709,
  "created_at" : "2016-01-08 16:23:08 +0000",
  "in_reply_to_screen_name" : "NazeefaFatima",
  "in_reply_to_user_id_str" : "37054704",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/aWmjAkhPBL",
      "expanded_url" : "https:\/\/github.com\/gedankenstuecke\/microbiome",
      "display_url" : "github.com\/gedankenstueck\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "685480204500889600",
  "geo" : { },
  "id_str" : "685482832140079104",
  "in_reply_to_user_id" : 14286491,
  "text" : "Related: here\u2019s the latest update on my raw microbiome sequencing data https:\/\/t.co\/aWmjAkhPBL",
  "id" : 685482832140079104,
  "in_reply_to_status_id" : 685480204500889600,
  "created_at" : "2016-01-08 15:26:57 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "685480204500889600",
  "text" : "\u00ABVerrucomicrobia have been found to be elevated in hibernating squirrels\u00BB Those being increased in my most recent gut sample explains a lot.",
  "id" : 685480204500889600,
  "created_at" : "2016-01-08 15:16:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul-Olivier Dehaye",
      "screen_name" : "podehaye",
      "indices" : [ 0, 9 ],
      "id_str" : "2219841242",
      "id" : 2219841242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "685465364659048448",
  "geo" : { },
  "id_str" : "685465517533048832",
  "in_reply_to_user_id" : 2219841242,
  "text" : "@podehaye perfect timing ;)",
  "id" : 685465517533048832,
  "in_reply_to_status_id" : 685465364659048448,
  "created_at" : "2016-01-08 14:18:09 +0000",
  "in_reply_to_screen_name" : "podehaye",
  "in_reply_to_user_id_str" : "2219841242",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katha",
      "screen_name" : "kathakatze",
      "indices" : [ 0, 11 ],
      "id_str" : "541170257",
      "id" : 541170257
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 12, 18 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "685464191310905344",
  "geo" : { },
  "id_str" : "685464333338460160",
  "in_reply_to_user_id" : 541170257,
  "text" : "@kathakatze @Lobot I\u2019m so close to being a doctor, so I guess there\u2019s no need :p",
  "id" : 685464333338460160,
  "in_reply_to_status_id" : 685464191310905344,
  "created_at" : "2016-01-08 14:13:27 +0000",
  "in_reply_to_screen_name" : "kathakatze",
  "in_reply_to_user_id_str" : "541170257",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/685463891745370113\/photo\/1",
      "indices" : [ 43, 66 ],
      "url" : "https:\/\/t.co\/UBIPK8rrIm",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CYNBxrqWcAAiOou.jpg",
      "id_str" : "685463890080198656",
      "id" : 685463890080198656,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CYNBxrqWcAAiOou.jpg",
      "sizes" : [ {
        "h" : 3264,
        "resize" : "fit",
        "w" : 2448
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      } ],
      "display_url" : "pic.twitter.com\/UBIPK8rrIm"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "685463501029142528",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17233811330704, 8.627521802673037 ]
  },
  "id_str" : "685463891745370113",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot don\u2019t worry, I know what I\u2019m doing! https:\/\/t.co\/UBIPK8rrIm",
  "id" : 685463891745370113,
  "in_reply_to_status_id" : 685463501029142528,
  "created_at" : "2016-01-08 14:11:41 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/NcuguzeCNn",
      "expanded_url" : "https:\/\/media0.giphy.com\/media\/zvA0XRNgDa6cw\/200.gif",
      "display_url" : "media0.giphy.com\/media\/zvA0XRNg\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "685450133450952705",
  "text" : "i\u2019m somehow concerned that we\u2019ll try this one day during our office lunch break https:\/\/t.co\/NcuguzeCNn",
  "id" : 685450133450952705,
  "created_at" : "2016-01-08 13:17:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "685411352630947840",
  "geo" : { },
  "id_str" : "685413320216690688",
  "in_reply_to_user_id" : 14286491,
  "text" : "\u00ABSixteen years after it was invented, Golden Rice still isn\u2019t commercially available\u00BB So basically, Greenpeace is still killing the poor.",
  "id" : 685413320216690688,
  "in_reply_to_status_id" : 685411352630947840,
  "created_at" : "2016-01-08 10:50:44 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/yWvw8oZNgV",
      "expanded_url" : "https:\/\/twitter.com\/ennomane\/status\/685387669782814720",
      "display_url" : "twitter.com\/ennomane\/statu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "685411352630947840",
  "text" : "\u00ABWhen you cling to an unsubstantiated belief, even after decades of research, that\u2019s not skepticism. It\u2019s dogma.\u00BB https:\/\/t.co\/yWvw8oZNgV",
  "id" : 685411352630947840,
  "created_at" : "2016-01-08 10:42:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lars Arvestad",
      "screen_name" : "arvestad",
      "indices" : [ 0, 9 ],
      "id_str" : "403987115",
      "id" : 403987115
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "685401197273038848",
  "geo" : { },
  "id_str" : "685402260810141696",
  "in_reply_to_user_id" : 403987115,
  "text" : "@arvestad thanks :)",
  "id" : 685402260810141696,
  "in_reply_to_status_id" : 685401197273038848,
  "created_at" : "2016-01-08 10:06:47 +0000",
  "in_reply_to_screen_name" : "arvestad",
  "in_reply_to_user_id_str" : "403987115",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lars Arvestad",
      "screen_name" : "arvestad",
      "indices" : [ 0, 9 ],
      "id_str" : "403987115",
      "id" : 403987115
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "685400557381660672",
  "geo" : { },
  "id_str" : "685400694887739395",
  "in_reply_to_user_id" : 403987115,
  "text" : "@arvestad this was my answer too, but maybe we can find the solution for \u201Ewhich is the least shitty one\u201C? ;)",
  "id" : 685400694887739395,
  "in_reply_to_status_id" : 685400557381660672,
  "created_at" : "2016-01-08 10:00:34 +0000",
  "in_reply_to_screen_name" : "arvestad",
  "in_reply_to_user_id_str" : "403987115",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/8b2ltF3iom",
      "expanded_url" : "http:\/\/www.ncbi.nlm.nih.gov\/pubmed\/20063824",
      "display_url" : "ncbi.nlm.nih.gov\/pubmed\/20063824"
    } ]
  },
  "in_reply_to_status_id_str" : "685398832981655552",
  "geo" : { },
  "id_str" : "685400271283949568",
  "in_reply_to_user_id" : 14286491,
  "text" : "Found at the same time: Acquired umbilical hernias in four captive polar bears https:\/\/t.co\/8b2ltF3iom",
  "id" : 685400271283949568,
  "in_reply_to_status_id" : 685398832981655552,
  "created_at" : "2016-01-08 09:58:53 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nazeefa",
      "screen_name" : "NazeefaFatima",
      "indices" : [ 0, 14 ],
      "id_str" : "37054704",
      "id" : 37054704
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "685397292208287744",
  "geo" : { },
  "id_str" : "685398861825859584",
  "in_reply_to_user_id" : 37054704,
  "text" : "@NazeefaFatima thanks, will have a look :)",
  "id" : 685398861825859584,
  "in_reply_to_status_id" : 685397292208287744,
  "created_at" : "2016-01-08 09:53:17 +0000",
  "in_reply_to_screen_name" : "NazeefaFatima",
  "in_reply_to_user_id_str" : "37054704",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/YSsDwm207X",
      "expanded_url" : "http:\/\/www.ncbi.nlm.nih.gov\/pubmed\/23550473",
      "display_url" : "ncbi.nlm.nih.gov\/pubmed\/23550473"
    } ]
  },
  "geo" : { },
  "id_str" : "685398832981655552",
  "text" : "Gotta love those case reports: \u00ABAcute hernial strangulation following Wii Fit exercises.\u00BB https:\/\/t.co\/YSsDwm207X",
  "id" : 685398832981655552,
  "created_at" : "2016-01-08 09:53:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bioinformatics",
      "indices" : [ 122, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "685394922812342272",
  "text" : "I was just asked \u00ABwhich secondary-structure predictor would you trust with your life?\u00BB. As I\u2019m completely clueless: Tips? #bioinformatics",
  "id" : 685394922812342272,
  "created_at" : "2016-01-08 09:37:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304E\u3088\u307F\u3069\u3093-hinata",
      "screen_name" : "hinatanococo",
      "indices" : [ 0, 13 ],
      "id_str" : "102026247",
      "id" : 102026247
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "685263836232863746",
  "geo" : { },
  "id_str" : "685266903271653376",
  "in_reply_to_user_id" : 102026247,
  "text" : "@hinatanococo nice try (well, not really) but I\u2019m not interested in your version of holocaust denial. kthxbye",
  "id" : 685266903271653376,
  "in_reply_to_status_id" : 685263836232863746,
  "created_at" : "2016-01-08 01:08:56 +0000",
  "in_reply_to_screen_name" : "hinatanococo",
  "in_reply_to_user_id_str" : "102026247",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Abby Cabunoc Mayes",
      "screen_name" : "abbycabs",
      "indices" : [ 0, 9 ],
      "id_str" : "395367768",
      "id" : 395367768
    }, {
      "name" : "Luke Pacholski",
      "screen_name" : "flukeout",
      "indices" : [ 10, 19 ],
      "id_str" : "19351055",
      "id" : 19351055
    }, {
      "name" : "Mozilla Science Lab",
      "screen_name" : "MozillaScience",
      "indices" : [ 20, 35 ],
      "id_str" : "1428575976",
      "id" : 1428575976
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "685238856761868290",
  "geo" : { },
  "id_str" : "685239807476412416",
  "in_reply_to_user_id" : 395367768,
  "text" : "@abbycabs @flukeout @MozillaScience \uD83D\uDE0D\uD83D\uDC93",
  "id" : 685239807476412416,
  "in_reply_to_status_id" : 685238856761868290,
  "created_at" : "2016-01-07 23:21:15 +0000",
  "in_reply_to_screen_name" : "abbycabs",
  "in_reply_to_user_id_str" : "395367768",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fabian Mohr",
      "screen_name" : "fabianmohr",
      "indices" : [ 3, 14 ],
      "id_str" : "13183522",
      "id" : 13183522
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 77 ],
      "url" : "https:\/\/t.co\/WcmjzdzfGs",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=0XcR-2Cvhvo",
      "display_url" : "youtube.com\/watch?v=0XcR-2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "685235536718630912",
  "text" : "RT @fabianmohr: \"Mom goes to the VR Dinosaur Museum:\" https:\/\/t.co\/WcmjzdzfGs Enjoy.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 38, 61 ],
        "url" : "https:\/\/t.co\/WcmjzdzfGs",
        "expanded_url" : "https:\/\/www.youtube.com\/watch?v=0XcR-2Cvhvo",
        "display_url" : "youtube.com\/watch?v=0XcR-2\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "685234926879412224",
    "text" : "\"Mom goes to the VR Dinosaur Museum:\" https:\/\/t.co\/WcmjzdzfGs Enjoy.",
    "id" : 685234926879412224,
    "created_at" : "2016-01-07 23:01:52 +0000",
    "user" : {
      "name" : "Fabian Mohr",
      "screen_name" : "fabianmohr",
      "protected" : false,
      "id_str" : "13183522",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/932352046967246849\/UXOqOF2N_normal.jpg",
      "id" : 13183522,
      "verified" : true
    }
  },
  "id" : 685235536718630912,
  "created_at" : "2016-01-07 23:04:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 73 ],
      "url" : "https:\/\/t.co\/DwtT25zPvr",
      "expanded_url" : "http:\/\/www.salon.com\/2004\/11\/30\/iris_chang\/",
      "display_url" : "salon.com\/2004\/11\/30\/iri\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "685200701224554498",
  "geo" : { },
  "id_str" : "685217127066923010",
  "in_reply_to_user_id" : 14286491,
  "text" : "Also worth a read: How \u201CIris Chang\u201D became a verb https:\/\/t.co\/DwtT25zPvr",
  "id" : 685217127066923010,
  "in_reply_to_status_id" : 685200701224554498,
  "created_at" : "2016-01-07 21:51:08 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    }, {
      "name" : "\u24EA Rik Smith-Unna \uD83C\uDDF0\uD83C\uDDEA",
      "screen_name" : "blahah404",
      "indices" : [ 10, 20 ],
      "id_str" : "99173786",
      "id" : 99173786
    }, {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 21, 35 ],
      "id_str" : "352650591",
      "id" : 352650591
    }, {
      "name" : "Steph\u24D0nie Wright",
      "screen_name" : "shefw",
      "indices" : [ 36, 42 ],
      "id_str" : "48636190",
      "id" : 48636190
    }, {
      "name" : "\uD83D\uDC9A Aure Moser \uD83D\uDC9A",
      "screen_name" : "auremoser",
      "indices" : [ 43, 53 ],
      "id_str" : "186529934",
      "id" : 186529934
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "685208828867178497",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.10769517165618, 8.76838199795109 ]
  },
  "id_str" : "685209396364849153",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon @blahah404 @Protohedgehog @shefw @auremoser indeed, but not sure whether having breakfast qualifies as \u2018event\u2019 ;)",
  "id" : 685209396364849153,
  "in_reply_to_status_id" : 685208828867178497,
  "created_at" : "2016-01-07 21:20:25 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    }, {
      "name" : "\u24EA Rik Smith-Unna \uD83C\uDDF0\uD83C\uDDEA",
      "screen_name" : "blahah404",
      "indices" : [ 10, 20 ],
      "id_str" : "99173786",
      "id" : 99173786
    }, {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 21, 35 ],
      "id_str" : "352650591",
      "id" : 352650591
    }, {
      "name" : "Steph\u24D0nie Wright",
      "screen_name" : "shefw",
      "indices" : [ 36, 42 ],
      "id_str" : "48636190",
      "id" : 48636190
    }, {
      "name" : "\uD83D\uDC9A Aure Moser \uD83D\uDC9A",
      "screen_name" : "auremoser",
      "indices" : [ 43, 53 ],
      "id_str" : "186529934",
      "id" : 186529934
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "685207325733445632",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.10749425743716, 8.771478859715883 ]
  },
  "id_str" : "685208816493965312",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon @blahah404 @Protohedgehog @shefw @auremoser Rhein\/Main seems to be largely closed science so far :(",
  "id" : 685208816493965312,
  "in_reply_to_status_id" : 685207325733445632,
  "created_at" : "2016-01-07 21:18:07 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    }, {
      "name" : "\u24EA Rik Smith-Unna \uD83C\uDDF0\uD83C\uDDEA",
      "screen_name" : "blahah404",
      "indices" : [ 10, 20 ],
      "id_str" : "99173786",
      "id" : 99173786
    }, {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 21, 35 ],
      "id_str" : "352650591",
      "id" : 352650591
    }, {
      "name" : "Steph\u24D0nie Wright",
      "screen_name" : "shefw",
      "indices" : [ 36, 42 ],
      "id_str" : "48636190",
      "id" : 48636190
    }, {
      "name" : "\uD83D\uDC9A Aure Moser \uD83D\uDC9A",
      "screen_name" : "auremoser",
      "indices" : [ 43, 53 ],
      "id_str" : "186529934",
      "id" : 186529934
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "685207325733445632",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.10763339702981, 8.77273011022133 ]
  },
  "id_str" : "685208647606091778",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon @blahah404 @Protohedgehog @shefw @auremoser sure, but we\u2019ll need external speakers. Otherwise it\u2019s just you&amp;me having breakfast.",
  "id" : 685208647606091778,
  "in_reply_to_status_id" : 685207325733445632,
  "created_at" : "2016-01-07 21:17:26 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    }, {
      "name" : "\u24EA Rik Smith-Unna \uD83C\uDDF0\uD83C\uDDEA",
      "screen_name" : "blahah404",
      "indices" : [ 10, 20 ],
      "id_str" : "99173786",
      "id" : 99173786
    }, {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 21, 35 ],
      "id_str" : "352650591",
      "id" : 352650591
    }, {
      "name" : "Steph\u24D0nie Wright",
      "screen_name" : "shefw",
      "indices" : [ 36, 42 ],
      "id_str" : "48636190",
      "id" : 48636190
    }, {
      "name" : "\uD83D\uDC9A Aure Moser \uD83D\uDC9A",
      "screen_name" : "auremoser",
      "indices" : [ 43, 53 ],
      "id_str" : "186529934",
      "id" : 186529934
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "685206489619951616",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.10781805035668, 8.76742679626566 ]
  },
  "id_str" : "685206735250952193",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon @blahah404 @Protohedgehog @shefw @auremoser nah, first WE of Feb. but I wanted to lobby you re:joining on this weekend ;)",
  "id" : 685206735250952193,
  "in_reply_to_status_id" : 685206489619951616,
  "created_at" : "2016-01-07 21:09:50 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u24EA Rik Smith-Unna \uD83C\uDDF0\uD83C\uDDEA",
      "screen_name" : "blahah404",
      "indices" : [ 0, 10 ],
      "id_str" : "99173786",
      "id" : 99173786
    }, {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 11, 25 ],
      "id_str" : "352650591",
      "id" : 352650591
    }, {
      "name" : "Steph\u24D0nie Wright",
      "screen_name" : "shefw",
      "indices" : [ 26, 32 ],
      "id_str" : "48636190",
      "id" : 48636190
    }, {
      "name" : "\uD83D\uDC9A Aure Moser \uD83D\uDC9A",
      "screen_name" : "auremoser",
      "indices" : [ 33, 43 ],
      "id_str" : "186529934",
      "id" : 186529934
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 44, 53 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/GXOGRgM2Js",
      "expanded_url" : "https:\/\/media2.giphy.com\/media\/fuwcnXOwS0myc\/200.gif",
      "display_url" : "media2.giphy.com\/media\/fuwcnXOw\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "685205310554947584",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.10855456818837, 8.76445163973492 ]
  },
  "id_str" : "685206140704133120",
  "in_reply_to_user_id" : 99173786,
  "text" : "@blahah404 @Protohedgehog @shefw @auremoser @Senficon it\u2019s my birthday on the weekend. will beg, using my best face https:\/\/t.co\/GXOGRgM2Js",
  "id" : 685206140704133120,
  "in_reply_to_status_id" : 685205310554947584,
  "created_at" : "2016-01-07 21:07:29 +0000",
  "in_reply_to_screen_name" : "blahah404",
  "in_reply_to_user_id_str" : "99173786",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 0, 14 ],
      "id_str" : "352650591",
      "id" : 352650591
    }, {
      "name" : "\u24EA Rik Smith-Unna \uD83C\uDDF0\uD83C\uDDEA",
      "screen_name" : "blahah404",
      "indices" : [ 15, 25 ],
      "id_str" : "99173786",
      "id" : 99173786
    }, {
      "name" : "Steph\u24D0nie Wright",
      "screen_name" : "shefw",
      "indices" : [ 26, 32 ],
      "id_str" : "48636190",
      "id" : 48636190
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "685202982019960833",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11147763119089, 8.75811341219466 ]
  },
  "id_str" : "685204963459514368",
  "in_reply_to_user_id" : 352650591,
  "text" : "@Protohedgehog @blahah404 @shefw is there a participant list somewhere? Looks like this will be a \u2018some of my favorite ppl\u2019-meeting!",
  "id" : 685204963459514368,
  "in_reply_to_status_id" : 685202982019960833,
  "created_at" : "2016-01-07 21:02:48 +0000",
  "in_reply_to_screen_name" : "Protohedgehog",
  "in_reply_to_user_id_str" : "352650591",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/SmWg317QA3",
      "expanded_url" : "https:\/\/www.goodreads.com\/review\/show\/1480129501?book_show_action=false",
      "display_url" : "goodreads.com\/review\/show\/14\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "685200701224554498",
  "text" : "just wow, i\u2019m completely blown away by \u2018The Rape of Nanking\u2019. What a terrifying book. Would read again. 5\/5 https:\/\/t.co\/SmWg317QA3",
  "id" : 685200701224554498,
  "created_at" : "2016-01-07 20:45:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 55 ],
      "url" : "https:\/\/t.co\/44zC6tUM4H",
      "expanded_url" : "https:\/\/twitter.com\/edyong209\/status\/685124235212271619",
      "display_url" : "twitter.com\/edyong209\/stat\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11405975277915, 8.753423137374057 ]
  },
  "id_str" : "685152647960260608",
  "text" : "Nooo! Those poor cute things! \uD83D\uDE2D https:\/\/t.co\/44zC6tUM4H",
  "id" : 685152647960260608,
  "created_at" : "2016-01-07 17:34:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonas",
      "screen_name" : "lsanoj",
      "indices" : [ 0, 7 ],
      "id_str" : "18918915",
      "id" : 18918915
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "685151351840620546",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11420229992969, 8.75095160006641 ]
  },
  "id_str" : "685151667445182464",
  "in_reply_to_user_id" : 18918915,
  "text" : "@lsanoj das hat mich schon mal gerettet als ich den Ausstieg in Mainz verpasst habe :D",
  "id" : 685151667445182464,
  "in_reply_to_status_id" : 685151351840620546,
  "created_at" : "2016-01-07 17:31:01 +0000",
  "in_reply_to_screen_name" : "lsanoj",
  "in_reply_to_user_id_str" : "18918915",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "685136453920112641",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17647266026337, 8.63007232948879 ]
  },
  "id_str" : "685137008327536640",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer ah, okay. It\u2019s just that I could easily imagine you ending up at the wrong airport. (Or even on the wrong continent!)",
  "id" : 685137008327536640,
  "in_reply_to_status_id" : 685136453920112641,
  "created_at" : "2016-01-07 16:32:46 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "685133433786335233",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17647599088641, 8.630245603741008 ]
  },
  "id_str" : "685135915644223488",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer not to worry you, but shouldn\u2019t you be in SAN? :D",
  "id" : 685135915644223488,
  "in_reply_to_status_id" : 685133433786335233,
  "created_at" : "2016-01-07 16:28:26 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/cIwWnYVHrv",
      "expanded_url" : "https:\/\/twitter.com\/dgmacarthur\/status\/685126407899484160",
      "display_url" : "twitter.com\/dgmacarthur\/st\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17645154608851, 8.630083096188828 ]
  },
  "id_str" : "685127553032556544",
  "text" : "\u00ABHealth-Tech Startups Now Face A \u201CBurden Of Proof\u201D.\u00BB makes you wonder what they were doing\/facing until now! https:\/\/t.co\/cIwWnYVHrv",
  "id" : 685127553032556544,
  "created_at" : "2016-01-07 15:55:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 53 ],
      "url" : "https:\/\/t.co\/AkxTPekM0P",
      "expanded_url" : "https:\/\/twitter.com\/tkb\/status\/685113877093314560",
      "display_url" : "twitter.com\/tkb\/status\/685\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17643874685758, 8.630537832316755 ]
  },
  "id_str" : "685122175196598272",
  "text" : "The times they are a-changin\u2019 https:\/\/t.co\/AkxTPekM0P",
  "id" : 685122175196598272,
  "created_at" : "2016-01-07 15:33:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "undivided@yahoo.de",
      "screen_name" : "undivid_ed",
      "indices" : [ 0, 11 ],
      "id_str" : "438256823",
      "id" : 438256823
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 83 ],
      "url" : "https:\/\/t.co\/LW6NejzFJ6",
      "expanded_url" : "http:\/\/www.buzzfeed.com\/awesomer\/gifs-that-are-so-perfectly-looped-that-its-physically-gra#.tvO7mOMr6",
      "display_url" : "buzzfeed.com\/awesomer\/gifs-\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "685108951680172032",
  "geo" : { },
  "id_str" : "685109352139722752",
  "in_reply_to_user_id" : 438256823,
  "text" : "@undivid_ed \u00E4h, ich dachte an eine perfect loop, mea culpa (https:\/\/t.co\/LW6NejzFJ6). that\u2019s the kind of compliment i like getting :p",
  "id" : 685109352139722752,
  "in_reply_to_status_id" : 685108951680172032,
  "created_at" : "2016-01-07 14:42:52 +0000",
  "in_reply_to_screen_name" : "undivid_ed",
  "in_reply_to_user_id_str" : "438256823",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "undivided@yahoo.de",
      "screen_name" : "undivid_ed",
      "indices" : [ 0, 11 ],
      "id_str" : "438256823",
      "id" : 438256823
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "685107803825016833",
  "geo" : { },
  "id_str" : "685108166812647424",
  "in_reply_to_user_id" : 438256823,
  "text" : "@undivid_ed den synchronen Teil k\u00F6nnte man super in einer Endlosschleife laufen lassen. And oh well, I\u2019ve heard worse!",
  "id" : 685108166812647424,
  "in_reply_to_status_id" : 685107803825016833,
  "created_at" : "2016-01-07 14:38:10 +0000",
  "in_reply_to_screen_name" : "undivid_ed",
  "in_reply_to_user_id_str" : "438256823",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "undivided@yahoo.de",
      "screen_name" : "undivid_ed",
      "indices" : [ 0, 11 ],
      "id_str" : "438256823",
      "id" : 438256823
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "685106561543442432",
  "geo" : { },
  "id_str" : "685107003413364736",
  "in_reply_to_user_id" : 438256823,
  "text" : "@undivid_ed was so ein bisschen vertr\u00E4umtes Schwanzwedeln doch anrichten kann\u2026",
  "id" : 685107003413364736,
  "in_reply_to_status_id" : 685106561543442432,
  "created_at" : "2016-01-07 14:33:32 +0000",
  "in_reply_to_screen_name" : "undivid_ed",
  "in_reply_to_user_id_str" : "438256823",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u24EA Rik Smith-Unna \uD83C\uDDF0\uD83C\uDDEA",
      "screen_name" : "blahah404",
      "indices" : [ 0, 10 ],
      "id_str" : "99173786",
      "id" : 99173786
    }, {
      "name" : "Dan Bolser",
      "screen_name" : "danbolser",
      "indices" : [ 11, 21 ],
      "id_str" : "16325864",
      "id" : 16325864
    }, {
      "name" : "Joey  Lee",
      "screen_name" : "leejoeyk",
      "indices" : [ 22, 31 ],
      "id_str" : "575961466",
      "id" : 575961466
    }, {
      "name" : "\uD83D\uDC9A Aure Moser \uD83D\uDC9A",
      "screen_name" : "auremoser",
      "indices" : [ 32, 42 ],
      "id_str" : "186529934",
      "id" : 186529934
    }, {
      "name" : "David Riordan\uD83D\uDD96",
      "screen_name" : "riordan",
      "indices" : [ 43, 51 ],
      "id_str" : "1281581",
      "id" : 1281581
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/QxsgD9dYhQ",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=vVX-PrBRtTY",
      "display_url" : "youtube.com\/watch?v=vVX-Pr\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "685069032643493889",
  "geo" : { },
  "id_str" : "685069313443782656",
  "in_reply_to_user_id" : 99173786,
  "text" : "@blahah404 @danbolser @leejoeyk @auremoser @riordan did you decide yet? https:\/\/t.co\/QxsgD9dYhQ \uD83D\uDE00",
  "id" : 685069313443782656,
  "in_reply_to_status_id" : 685069032643493889,
  "created_at" : "2016-01-07 12:03:46 +0000",
  "in_reply_to_screen_name" : "blahah404",
  "in_reply_to_user_id_str" : "99173786",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 85 ],
      "url" : "https:\/\/t.co\/uUJcppfpTn",
      "expanded_url" : "https:\/\/twitter.com\/fragmente\/status\/685065344017416192",
      "display_url" : "twitter.com\/fragmente\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "685066683044786176",
  "text" : "omg, i just love the \u2018instrumentation\u2019 of walk off the earth! https:\/\/t.co\/uUJcppfpTn",
  "id" : 685066683044786176,
  "created_at" : "2016-01-07 11:53:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 59 ],
      "url" : "https:\/\/t.co\/lvEUHozIII",
      "expanded_url" : "http:\/\/journals.plos.org\/plosone\/article?id=10.1371\/journal.pone.0144717",
      "display_url" : "journals.plos.org\/plosone\/articl\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "685061515712573441",
  "text" : "Text Mining the History of Medicine https:\/\/t.co\/lvEUHozIII",
  "id" : 685061515712573441,
  "created_at" : "2016-01-07 11:32:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "685041988601774080",
  "geo" : { },
  "id_str" : "685042309336051712",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot my step counts would be way off (also I assume you\u2019d already have told me\/posted a gif of me dreaming)",
  "id" : 685042309336051712,
  "in_reply_to_status_id" : 685041988601774080,
  "created_at" : "2016-01-07 10:16:28 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "685040915233292288",
  "geo" : { },
  "id_str" : "685041555590279168",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot guess who\u2019s also not wearing pants. But still I don\u2019t dream like this!",
  "id" : 685041555590279168,
  "in_reply_to_status_id" : 685040915233292288,
  "created_at" : "2016-01-07 10:13:28 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 45 ],
      "url" : "https:\/\/t.co\/BY73wjv43l",
      "expanded_url" : "http:\/\/i.imgur.com\/36kdntx.gifv",
      "display_url" : "i.imgur.com\/36kdntx.gifv"
    } ]
  },
  "geo" : { },
  "id_str" : "685039270315294721",
  "text" : "i can\u2019t stop watching https:\/\/t.co\/BY73wjv43l",
  "id" : 685039270315294721,
  "created_at" : "2016-01-07 10:04:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "@zeitweise",
      "screen_name" : "zeitweise",
      "indices" : [ 0, 10 ],
      "id_str" : "15494684",
      "id" : 15494684
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "685029844833419264",
  "geo" : { },
  "id_str" : "685038438656131072",
  "in_reply_to_user_id" : 15494684,
  "text" : "@zeitweise Twitter arbeitet hart daran das der Dachs bald wieder bei 10,000 Punkten ist.",
  "id" : 685038438656131072,
  "in_reply_to_status_id" : 685029844833419264,
  "created_at" : "2016-01-07 10:01:05 +0000",
  "in_reply_to_screen_name" : "zeitweise",
  "in_reply_to_user_id_str" : "15494684",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "undivided@yahoo.de",
      "screen_name" : "undivid_ed",
      "indices" : [ 0, 11 ],
      "id_str" : "438256823",
      "id" : 438256823
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "684851894150414336",
  "geo" : { },
  "id_str" : "684853339704717314",
  "in_reply_to_user_id" : 438256823,
  "text" : "@undivid_ed :D actually it doesn\u2019t feel too bad to be out of touch in this case ;)",
  "id" : 684853339704717314,
  "in_reply_to_status_id" : 684851894150414336,
  "created_at" : "2016-01-06 21:45:34 +0000",
  "in_reply_to_screen_name" : "undivid_ed",
  "in_reply_to_user_id_str" : "438256823",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Classics Library",
      "screen_name" : "stephenjenkin",
      "indices" : [ 3, 17 ],
      "id_str" : "316686040",
      "id" : 316686040
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/stephenjenkin\/status\/684614240666267648\/photo\/1",
      "indices" : [ 63, 86 ],
      "url" : "https:\/\/t.co\/OVkACU3odA",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CYA9AY9WQAAxurC.jpg",
      "id_str" : "684614220269371392",
      "id" : 684614220269371392,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CYA9AY9WQAAxurC.jpg",
      "sizes" : [ {
        "h" : 738,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 738,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 490,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 738,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/OVkACU3odA"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 62 ],
      "url" : "https:\/\/t.co\/tVYHcARE9f",
      "expanded_url" : "http:\/\/mostlydeadlanguages.tumblr.com\/post\/136361919078\/cuneiform-cookies-for-the-new-year",
      "display_url" : "mostlydeadlanguages.tumblr.com\/post\/136361919\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "684840706821730304",
  "text" : "RT @stephenjenkin: Cuneiform cookies!\n\nhttps:\/\/t.co\/tVYHcARE9f https:\/\/t.co\/OVkACU3odA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/stephenjenkin\/status\/684614240666267648\/photo\/1",
        "indices" : [ 44, 67 ],
        "url" : "https:\/\/t.co\/OVkACU3odA",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CYA9AY9WQAAxurC.jpg",
        "id_str" : "684614220269371392",
        "id" : 684614220269371392,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CYA9AY9WQAAxurC.jpg",
        "sizes" : [ {
          "h" : 738,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 738,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 490,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 738,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/OVkACU3odA"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 20, 43 ],
        "url" : "https:\/\/t.co\/tVYHcARE9f",
        "expanded_url" : "http:\/\/mostlydeadlanguages.tumblr.com\/post\/136361919078\/cuneiform-cookies-for-the-new-year",
        "display_url" : "mostlydeadlanguages.tumblr.com\/post\/136361919\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "684614240666267648",
    "text" : "Cuneiform cookies!\n\nhttps:\/\/t.co\/tVYHcARE9f https:\/\/t.co\/OVkACU3odA",
    "id" : 684614240666267648,
    "created_at" : "2016-01-06 05:55:29 +0000",
    "user" : {
      "name" : "The Classics Library",
      "screen_name" : "stephenjenkin",
      "protected" : false,
      "id_str" : "316686040",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/925733019272523776\/qVTG4OIZ_normal.jpg",
      "id" : 316686040,
      "verified" : false
    }
  },
  "id" : 684840706821730304,
  "created_at" : "2016-01-06 20:55:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 65 ],
      "url" : "https:\/\/t.co\/7WmxBKSy7h",
      "expanded_url" : "http:\/\/m.huffpost.com\/uk\/entry\/8541674",
      "display_url" : "m.huffpost.com\/uk\/entry\/85416\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11405893647454, 8.75342550523118 ]
  },
  "id_str" : "684835848311967744",
  "text" : "I\u2019m feeling so out of touch with fashion. https:\/\/t.co\/7WmxBKSy7h",
  "id" : 684835848311967744,
  "created_at" : "2016-01-06 20:36:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u24EA Rik Smith-Unna \uD83C\uDDF0\uD83C\uDDEA",
      "screen_name" : "blahah404",
      "indices" : [ 0, 10 ],
      "id_str" : "99173786",
      "id" : 99173786
    }, {
      "name" : "Abby Cabunoc Mayes",
      "screen_name" : "abbycabs",
      "indices" : [ 11, 20 ],
      "id_str" : "395367768",
      "id" : 395367768
    }, {
      "name" : "Mozilla Science Lab",
      "screen_name" : "MozillaScience",
      "indices" : [ 21, 36 ],
      "id_str" : "1428575976",
      "id" : 1428575976
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "684827977604018176",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11406044543161, 8.753446790370486 ]
  },
  "id_str" : "684828318387056640",
  "in_reply_to_user_id" : 99173786,
  "text" : "@blahah404 @abbycabs @MozillaScience yes, collaborate is really working for us. :) and you\u2019re more than welcome to contribute :D",
  "id" : 684828318387056640,
  "in_reply_to_status_id" : 684827977604018176,
  "created_at" : "2016-01-06 20:06:09 +0000",
  "in_reply_to_screen_name" : "blahah404",
  "in_reply_to_user_id_str" : "99173786",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/vine.co\" rel=\"nofollow\"\u003EVine - Make a Scene\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/hOcqWUPROv",
      "expanded_url" : "https:\/\/vine.co\/v\/ihqeDULdMF3",
      "display_url" : "vine.co\/v\/ihqeDULdMF3"
    } ]
  },
  "geo" : { },
  "id_str" : "684775792635691008",
  "text" : "For just 4 euros this meerkat spotlight could be mine. I'm somewhat tempted! https:\/\/t.co\/hOcqWUPROv",
  "id" : 684775792635691008,
  "created_at" : "2016-01-06 16:37:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "684740556468187136",
  "text" : "\u00ABEvery anti-Esperantist auxlanger is convinced he (no need to fret about gender-neutral pronouns on this one) represents a superior product\u00BB",
  "id" : 684740556468187136,
  "created_at" : "2016-01-06 14:17:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 62 ],
      "url" : "https:\/\/t.co\/AszWxCUIuE",
      "expanded_url" : "http:\/\/wals.info\/",
      "display_url" : "wals.info"
    } ]
  },
  "geo" : { },
  "id_str" : "684728674231402496",
  "text" : "The World Atlas of Language Structures https:\/\/t.co\/AszWxCUIuE",
  "id" : 684728674231402496,
  "created_at" : "2016-01-06 13:30:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/g2rCVqAgqQ",
      "expanded_url" : "https:\/\/en.wikipedia.org\/wiki\/Thomas_Urquhart",
      "display_url" : "en.wikipedia.org\/wiki\/Thomas_Ur\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "684716775469150208",
  "text" : "TIL: \u00ABUrquhart died in a fit of laughter on receiving news of the Restoration of Charles II.\u00BB https:\/\/t.co\/g2rCVqAgqQ",
  "id" : 684716775469150208,
  "created_at" : "2016-01-06 12:42:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 75 ],
      "url" : "https:\/\/t.co\/kue0GyXphf",
      "expanded_url" : "https:\/\/media.giphy.com\/media\/PS66xB5cPXKzS\/giphy.gif",
      "display_url" : "media.giphy.com\/media\/PS66xB5c\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "684712784685330432",
  "text" : "we\u2019re having cake overflow errors in the office \\o\/ https:\/\/t.co\/kue0GyXphf",
  "id" : 684712784685330432,
  "created_at" : "2016-01-06 12:27:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tatjana Scheffler",
      "screen_name" : "tschfflr",
      "indices" : [ 0, 9 ],
      "id_str" : "313810815",
      "id" : 313810815
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "684689571091714048",
  "geo" : { },
  "id_str" : "684689594449850368",
  "in_reply_to_user_id" : 313810815,
  "text" : "@tschfflr danke!",
  "id" : 684689594449850368,
  "in_reply_to_status_id" : 684689571091714048,
  "created_at" : "2016-01-06 10:54:54 +0000",
  "in_reply_to_screen_name" : "tschfflr",
  "in_reply_to_user_id_str" : "313810815",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tatjana Scheffler",
      "screen_name" : "tschfflr",
      "indices" : [ 0, 9 ],
      "id_str" : "313810815",
      "id" : 313810815
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "684686875727126528",
  "geo" : { },
  "id_str" : "684687320914747392",
  "in_reply_to_user_id" : 313810815,
  "text" : "@tschfflr sweet, are the materials online somewhere? :)",
  "id" : 684687320914747392,
  "in_reply_to_status_id" : 684686875727126528,
  "created_at" : "2016-01-06 10:45:52 +0000",
  "in_reply_to_screen_name" : "tschfflr",
  "in_reply_to_user_id_str" : "313810815",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Benjamin E. Hardisty",
      "screen_name" : "Priceeqn",
      "indices" : [ 0, 9 ],
      "id_str" : "251423102",
      "id" : 251423102
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 10, 23 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 56 ],
      "url" : "https:\/\/t.co\/7mldWc40C5",
      "expanded_url" : "http:\/\/onlinelibrary.wiley.com\/doi\/10.1002\/ijc.2910200506\/abstract",
      "display_url" : "onlinelibrary.wiley.com\/doi\/10.1002\/ij\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "684667364009365504",
  "geo" : { },
  "id_str" : "684667802641428480",
  "in_reply_to_user_id" : 251423102,
  "text" : "@Priceeqn @PhilippBayer yes, see https:\/\/t.co\/7mldWc40C5",
  "id" : 684667802641428480,
  "in_reply_to_status_id" : 684667364009365504,
  "created_at" : "2016-01-06 09:28:19 +0000",
  "in_reply_to_screen_name" : "Priceeqn",
  "in_reply_to_user_id_str" : "251423102",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Benjamin E. Hardisty",
      "screen_name" : "Priceeqn",
      "indices" : [ 0, 9 ],
      "id_str" : "251423102",
      "id" : 251423102
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 10, 23 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "684666887116992512",
  "geo" : { },
  "id_str" : "684667130298654720",
  "in_reply_to_user_id" : 251423102,
  "text" : "@Priceeqn @PhilippBayer coincidence, just started making the point. yes: ppl have a tumor but ultimately die of other causes.",
  "id" : 684667130298654720,
  "in_reply_to_status_id" : 684666887116992512,
  "created_at" : "2016-01-06 09:25:39 +0000",
  "in_reply_to_screen_name" : "Priceeqn",
  "in_reply_to_user_id_str" : "251423102",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Benjamin E. Hardisty",
      "screen_name" : "Priceeqn",
      "indices" : [ 0, 9 ],
      "id_str" : "251423102",
      "id" : 251423102
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 10, 23 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "684666600889294848",
  "geo" : { },
  "id_str" : "684666927294377984",
  "in_reply_to_user_id" : 251423102,
  "text" : "@Priceeqn @PhilippBayer also comp. prostate cancer, virtually 100% of men have it if your population is old enough.",
  "id" : 684666927294377984,
  "in_reply_to_status_id" : 684666600889294848,
  "created_at" : "2016-01-06 09:24:50 +0000",
  "in_reply_to_screen_name" : "Priceeqn",
  "in_reply_to_user_id_str" : "251423102",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Benjamin E. Hardisty",
      "screen_name" : "Priceeqn",
      "indices" : [ 0, 9 ],
      "id_str" : "251423102",
      "id" : 251423102
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 10, 23 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "684666304607862784",
  "geo" : { },
  "id_str" : "684666578961592321",
  "in_reply_to_user_id" : 251423102,
  "text" : "@Priceeqn @PhilippBayer yes, and circulatory\/respiratory causes also become more likely, probably getting you before a tumor finally does.",
  "id" : 684666578961592321,
  "in_reply_to_status_id" : 684666304607862784,
  "created_at" : "2016-01-06 09:23:27 +0000",
  "in_reply_to_screen_name" : "Priceeqn",
  "in_reply_to_user_id_str" : "251423102",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "684665708542693380",
  "geo" : { },
  "id_str" : "684665843343581185",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer actually I\u2019d have expected this: once you\u2019re old enough cancer will probably spread too slowly to kill you?",
  "id" : 684665843343581185,
  "in_reply_to_status_id" : 684665708542693380,
  "created_at" : "2016-01-06 09:20:32 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ali",
      "screen_name" : "zoonpolitikon",
      "indices" : [ 0, 14 ],
      "id_str" : "13040652",
      "id" : 13040652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "684665288663642112",
  "geo" : { },
  "id_str" : "684665547217342465",
  "in_reply_to_user_id" : 13040652,
  "text" : "@zoonpolitikon yes, give it 10 years and I\u2019m much more likely to die thanks to internal causes\u2026",
  "id" : 684665547217342465,
  "in_reply_to_status_id" : 684665288663642112,
  "created_at" : "2016-01-06 09:19:21 +0000",
  "in_reply_to_screen_name" : "zoonpolitikon",
  "in_reply_to_user_id_str" : "13040652",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/ej9rgaC8iN",
      "expanded_url" : "http:\/\/flowingdata.com\/2016\/01\/05\/causes-of-death\/",
      "display_url" : "flowingdata.com\/2016\/01\/05\/cau\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "684664177110192128",
  "text" : "I\u2019m still at an age where \u201Eexternal causes\u201C are the most likely cause of death https:\/\/t.co\/ej9rgaC8iN",
  "id" : 684664177110192128,
  "created_at" : "2016-01-06 09:13:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 57 ],
      "url" : "https:\/\/t.co\/534i9JdMNN",
      "expanded_url" : "https:\/\/twitter.com\/edyong209\/status\/684647166955098112",
      "display_url" : "twitter.com\/edyong209\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "684663007381684224",
  "text" : "On Nice Parties and Casual Racism https:\/\/t.co\/534i9JdMNN",
  "id" : 684663007381684224,
  "created_at" : "2016-01-06 09:09:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 0, 14 ],
      "id_str" : "352650591",
      "id" : 352650591
    }, {
      "name" : "\u24EA Rik Smith-Unna \uD83C\uDDF0\uD83C\uDDEA",
      "screen_name" : "blahah404",
      "indices" : [ 15, 25 ],
      "id_str" : "99173786",
      "id" : 99173786
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "684512791743574016",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11398689925719, 8.753443408611972 ]
  },
  "id_str" : "684513625294417920",
  "in_reply_to_user_id" : 352650591,
  "text" : "@Protohedgehog @blahah404 or some rap-producibility!",
  "id" : 684513625294417920,
  "in_reply_to_status_id" : 684512791743574016,
  "created_at" : "2016-01-05 23:15:40 +0000",
  "in_reply_to_screen_name" : "Protohedgehog",
  "in_reply_to_user_id_str" : "352650591",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 0, 14 ],
      "id_str" : "352650591",
      "id" : 352650591
    }, {
      "name" : "\u24EA Rik Smith-Unna \uD83C\uDDF0\uD83C\uDDEA",
      "screen_name" : "blahah404",
      "indices" : [ 15, 25 ],
      "id_str" : "99173786",
      "id" : 99173786
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 64 ],
      "url" : "https:\/\/t.co\/DBM5QSA7eD",
      "expanded_url" : "http:\/\/i.kinja-img.com\/gawker-media\/image\/upload\/fet2yanchzeppxonbilf.gif",
      "display_url" : "i.kinja-img.com\/gawker-media\/i\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "684510910891855872",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11405883847267, 8.75342892567362 ]
  },
  "id_str" : "684512594850385921",
  "in_reply_to_user_id" : 352650591,
  "text" : "@Protohedgehog @blahah404 let\u2019s do this! https:\/\/t.co\/DBM5QSA7eD",
  "id" : 684512594850385921,
  "in_reply_to_status_id" : 684510910891855872,
  "created_at" : "2016-01-05 23:11:34 +0000",
  "in_reply_to_screen_name" : "Protohedgehog",
  "in_reply_to_user_id_str" : "352650591",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "@zeitweise",
      "screen_name" : "zeitweise",
      "indices" : [ 0, 10 ],
      "id_str" : "15494684",
      "id" : 15494684
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "684511997887680514",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11405956697198, 8.753436392155217 ]
  },
  "id_str" : "684512139093131264",
  "in_reply_to_user_id" : 15494684,
  "text" : "@zeitweise es ist wirklich sehr kompliziert\u2026",
  "id" : 684512139093131264,
  "in_reply_to_status_id" : 684511997887680514,
  "created_at" : "2016-01-05 23:09:46 +0000",
  "in_reply_to_screen_name" : "zeitweise",
  "in_reply_to_user_id_str" : "15494684",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "684510238817521664",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11405877844832, 8.753421984015183 ]
  },
  "id_str" : "684510389137223680",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot my job is hard and not a joke! \uD83C\uDF4C",
  "id" : 684510389137223680,
  "in_reply_to_status_id" : 684510238817521664,
  "created_at" : "2016-01-05 23:02:49 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 0, 14 ],
      "id_str" : "352650591",
      "id" : 352650591
    }, {
      "name" : "\u24EA Rik Smith-Unna \uD83C\uDDF0\uD83C\uDDEA",
      "screen_name" : "blahah404",
      "indices" : [ 15, 25 ],
      "id_str" : "99173786",
      "id" : 99173786
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "684507507377745920",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11405938458842, 8.753423288508891 ]
  },
  "id_str" : "684508634353668097",
  "in_reply_to_user_id" : 352650591,
  "text" : "@Protohedgehog @blahah404 I should have requested an additional day of vacation in that case \uD83C\uDF7B",
  "id" : 684508634353668097,
  "in_reply_to_status_id" : 684507507377745920,
  "created_at" : "2016-01-05 22:55:50 +0000",
  "in_reply_to_screen_name" : "Protohedgehog",
  "in_reply_to_user_id_str" : "352650591",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 0, 14 ],
      "id_str" : "352650591",
      "id" : 352650591
    }, {
      "name" : "\u24EA Rik Smith-Unna \uD83C\uDDF0\uD83C\uDDEA",
      "screen_name" : "blahah404",
      "indices" : [ 15, 25 ],
      "id_str" : "99173786",
      "id" : 99173786
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "684506905931321344",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11405947912201, 8.753437288822491 ]
  },
  "id_str" : "684507141093351424",
  "in_reply_to_user_id" : 352650591,
  "text" : "@Protohedgehog @blahah404 got a late afternoon flight back on Sunday, so we can party on Saturday \uD83D\uDE02",
  "id" : 684507141093351424,
  "in_reply_to_status_id" : 684506905931321344,
  "created_at" : "2016-01-05 22:49:54 +0000",
  "in_reply_to_screen_name" : "Protohedgehog",
  "in_reply_to_user_id_str" : "352650591",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Sahl",
      "screen_name" : "jason_sahl",
      "indices" : [ 3, 14 ],
      "id_str" : "1092431239",
      "id" : 1092431239
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "684506824196882432",
  "text" : "RT @jason_sahl: NCBI WGS accession \"JUNK\" is an E. coli genome assembly of 8.8Mb and &gt;8000 contigs. Who says NCBI doesn't have a sense of h\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "684454892220465152",
    "text" : "NCBI WGS accession \"JUNK\" is an E. coli genome assembly of 8.8Mb and &gt;8000 contigs. Who says NCBI doesn't have a sense of humor?",
    "id" : 684454892220465152,
    "created_at" : "2016-01-05 19:22:17 +0000",
    "user" : {
      "name" : "Jason Sahl",
      "screen_name" : "jason_sahl",
      "protected" : false,
      "id_str" : "1092431239",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/834977979277070340\/xQAw-TRb_normal.jpg",
      "id" : 1092431239,
      "verified" : false
    }
  },
  "id" : 684506824196882432,
  "created_at" : "2016-01-05 22:48:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u24EA Rik Smith-Unna \uD83C\uDDF0\uD83C\uDDEA",
      "screen_name" : "blahah404",
      "indices" : [ 0, 10 ],
      "id_str" : "99173786",
      "id" : 99173786
    }, {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 11, 25 ],
      "id_str" : "352650591",
      "id" : 352650591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "684497327873224704",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11405947912201, 8.753437288822491 ]
  },
  "id_str" : "684505800736399360",
  "in_reply_to_user_id" : 99173786,
  "text" : "@blahah404 @Protohedgehog looking forward to meet you guys again! \uD83D\uDC4D\uD83D\uDC96",
  "id" : 684505800736399360,
  "in_reply_to_status_id" : 684497327873224704,
  "created_at" : "2016-01-05 22:44:35 +0000",
  "in_reply_to_screen_name" : "blahah404",
  "in_reply_to_user_id_str" : "99173786",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 80 ],
      "url" : "https:\/\/t.co\/LTfKo6rRsW",
      "expanded_url" : "https:\/\/twitter.com\/totenseuche\/status\/684470867997405184",
      "display_url" : "twitter.com\/totenseuche\/st\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11405973267762, 8.753435552329016 ]
  },
  "id_str" : "684502178996858880",
  "text" : "The things scientists have to spend days thinking about. https:\/\/t.co\/LTfKo6rRsW",
  "id" : 684502178996858880,
  "created_at" : "2016-01-05 22:30:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karthik Ram",
      "screen_name" : "_inundata",
      "indices" : [ 7, 17 ],
      "id_str" : "267256091",
      "id" : 267256091
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/hFZPmH6yZs",
      "expanded_url" : "https:\/\/github.com\/karthik\/life-hacks\/blob\/master\/travel.md",
      "display_url" : "github.com\/karthik\/life-h\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "684438809866551296",
  "text" : "Thx to @_inundata\u2019s list I ordered a PlugBug. Always read it as the \u2018smikhut-instead-of-compound-noun\u2019 of butt plug\u2026 https:\/\/t.co\/hFZPmH6yZs",
  "id" : 684438809866551296,
  "created_at" : "2016-01-05 18:18:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uD83C\uDF42\uD83E\uDD83 eevee \uD83E\uDD83\uD83C\uDF42",
      "screen_name" : "eevee",
      "indices" : [ 3, 9 ],
      "id_str" : "14412937",
      "id" : 14412937
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 79 ],
      "url" : "https:\/\/t.co\/quj8oHq0jw",
      "expanded_url" : "http:\/\/eev.ee\/blog\/2016\/01\/04\/shut-up-paul-graham-the-simplified-version\/",
      "display_url" : "eev.ee\/blog\/2016\/01\/0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "684422756784537601",
  "text" : "RT @eevee: Shut Up, Paul Graham: The Simplified Version https:\/\/t.co\/quj8oHq0jw",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 45, 68 ],
        "url" : "https:\/\/t.co\/quj8oHq0jw",
        "expanded_url" : "http:\/\/eev.ee\/blog\/2016\/01\/04\/shut-up-paul-graham-the-simplified-version\/",
        "display_url" : "eev.ee\/blog\/2016\/01\/0\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "684193893844447232",
    "text" : "Shut Up, Paul Graham: The Simplified Version https:\/\/t.co\/quj8oHq0jw",
    "id" : 684193893844447232,
    "created_at" : "2016-01-05 02:05:10 +0000",
    "user" : {
      "name" : "\uD83C\uDF42\uD83E\uDD83 eevee \uD83E\uDD83\uD83C\uDF42",
      "screen_name" : "eevee",
      "protected" : false,
      "id_str" : "14412937",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/870472485321363456\/VjPvng-x_normal.jpg",
      "id" : 14412937,
      "verified" : false
    }
  },
  "id" : 684422756784537601,
  "created_at" : "2016-01-05 17:14:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michelle Oyen",
      "screen_name" : "michelleoyen",
      "indices" : [ 3, 16 ],
      "id_str" : "83589523",
      "id" : 83589523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/uKPQpFqfsj",
      "expanded_url" : "http:\/\/qz.com\/585255",
      "display_url" : "qz.com\/585255"
    } ]
  },
  "geo" : { },
  "id_str" : "684398732910145536",
  "text" : "RT @michelleoyen: This. There's a way to get girls to stick with science\u2013and no, it's not more female role models https:\/\/t.co\/uKPQpFqfsj v\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 96, 119 ],
        "url" : "https:\/\/t.co\/uKPQpFqfsj",
        "expanded_url" : "http:\/\/qz.com\/585255",
        "display_url" : "qz.com\/585255"
      } ]
    },
    "geo" : { },
    "id_str" : "684398405406322688",
    "text" : "This. There's a way to get girls to stick with science\u2013and no, it's not more female role models https:\/\/t.co\/uKPQpFqfsj via qz",
    "id" : 684398405406322688,
    "created_at" : "2016-01-05 15:37:50 +0000",
    "user" : {
      "name" : "Michelle Oyen",
      "screen_name" : "michelleoyen",
      "protected" : false,
      "id_str" : "83589523",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/479579308\/MyPicture_normal.jpg",
      "id" : 83589523,
      "verified" : false
    }
  },
  "id" : 684398732910145536,
  "created_at" : "2016-01-05 15:39:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/vqrDELk1WZ",
      "expanded_url" : "http:\/\/journals.plos.org\/plosbiology\/article?id=10.1371\/journal.pbio.1002339",
      "display_url" : "journals.plos.org\/plosbiology\/ar\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "684387792365961216",
  "text" : "Controlled Access under Review: Improving the Governance of Genomic Data Access https:\/\/t.co\/vqrDELk1WZ",
  "id" : 684387792365961216,
  "created_at" : "2016-01-05 14:55:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Schawinski",
      "screen_name" : "kevinschawinski",
      "indices" : [ 0, 16 ],
      "id_str" : "242844365",
      "id" : 242844365
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 40 ],
      "url" : "https:\/\/t.co\/bNHKI6xDra",
      "expanded_url" : "https:\/\/memecrunch.com\/meme\/164I0\/i-ve-heard-it-both-ways\/image.png?w=400&c=1",
      "display_url" : "memecrunch.com\/meme\/164I0\/i-v\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "684365414684569600",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17235904672629, 8.62749477720144 ]
  },
  "id_str" : "684365550512922624",
  "in_reply_to_user_id" : 242844365,
  "text" : "@kevinschawinski https:\/\/t.co\/bNHKI6xDra",
  "id" : 684365550512922624,
  "in_reply_to_status_id" : 684365414684569600,
  "created_at" : "2016-01-05 13:27:16 +0000",
  "in_reply_to_screen_name" : "kevinschawinski",
  "in_reply_to_user_id_str" : "242844365",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "684364905068277760",
  "text" : "\u00ABIs this legal?!\u00BB \u2013 \u00ABFor your own sake I\u2019d advise that we both forget you\u2019ve ever asked that question.\u00BB",
  "id" : 684364905068277760,
  "created_at" : "2016-01-05 13:24:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Blin",
      "screen_name" : "kaiblin",
      "indices" : [ 0, 8 ],
      "id_str" : "124202458",
      "id" : 124202458
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "684345555758219264",
  "geo" : { },
  "id_str" : "684345934294171649",
  "in_reply_to_user_id" : 124202458,
  "text" : "@kaiblin was the position a better match than in my case? :D",
  "id" : 684345934294171649,
  "in_reply_to_status_id" : 684345555758219264,
  "created_at" : "2016-01-05 12:09:19 +0000",
  "in_reply_to_screen_name" : "kaiblin",
  "in_reply_to_user_id_str" : "124202458",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 92 ],
      "url" : "https:\/\/t.co\/A5AKohZR0e",
      "expanded_url" : "https:\/\/twitter.com\/kaiblin\/status\/684320787973681156",
      "display_url" : "twitter.com\/kaiblin\/status\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "684343386011267072",
  "text" : "Think I might have gotten the same. Also: game development, really?! https:\/\/t.co\/A5AKohZR0e",
  "id" : 684343386011267072,
  "created_at" : "2016-01-05 11:59:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lufthansa",
      "screen_name" : "lufthansa",
      "indices" : [ 21, 31 ],
      "id_str" : "124476322",
      "id" : 124476322
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/E83N7YqlmG",
      "expanded_url" : "http:\/\/i3.kym-cdn.com\/photos\/images\/original\/000\/511\/991\/3a5.jpg",
      "display_url" : "i3.kym-cdn.com\/photos\/images\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "684312305442664448",
  "text" : "Booking flights with @lufthansa again. Well, I guess from Berlin I can walk in the worst case\u2026 https:\/\/t.co\/E83N7YqlmG",
  "id" : 684312305442664448,
  "created_at" : "2016-01-05 09:55:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "684299321215430657",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17234517474383, 8.627550151999754 ]
  },
  "id_str" : "684299704759377920",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot the application forms for my next \u2018conference vacations\u2019 \uD83D\uDE02",
  "id" : 684299704759377920,
  "in_reply_to_status_id" : 684299321215430657,
  "created_at" : "2016-01-05 09:05:37 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/1Viwa5X3P7",
      "expanded_url" : "http:\/\/www.rosincerate.com\/2016\/01\/a-piping-hot-plant-fungus-virus-three.html",
      "display_url" : "rosincerate.com\/2016\/01\/a-pipi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "684295307597840384",
  "text" : "Awesome, I never heard about those before: A piping hot plant-fungus-virus three-way https:\/\/t.co\/1Viwa5X3P7",
  "id" : 684295307597840384,
  "created_at" : "2016-01-05 08:48:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/N1XyQu9W3u",
      "expanded_url" : "http:\/\/journals.plos.org\/plosbiology\/article?id=10.1371\/journal.pbio.1002333",
      "display_url" : "journals.plos.org\/plosbiology\/ar\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "684294461254451200",
  "text" : "Reproducible Research Practices and Transparency across the Biomedical Literature https:\/\/t.co\/N1XyQu9W3u",
  "id" : 684294461254451200,
  "created_at" : "2016-01-05 08:44:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 70 ],
      "url" : "https:\/\/t.co\/hh6vh8E3Sr",
      "expanded_url" : "http:\/\/stream1.gifsoup.com\/view1\/2076253\/big-eyes-puss-in-boots-o.gif",
      "display_url" : "stream1.gifsoup.com\/view1\/2076253\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "684290773278396416",
  "text" : "perfect for use in professional communication: https:\/\/t.co\/hh6vh8E3Sr",
  "id" : 684290773278396416,
  "created_at" : "2016-01-05 08:30:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nazeefa",
      "screen_name" : "NazeefaFatima",
      "indices" : [ 0, 14 ],
      "id_str" : "37054704",
      "id" : 37054704
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "684172208336449536",
  "geo" : { },
  "id_str" : "684172392164409344",
  "in_reply_to_user_id" : 37054704,
  "text" : "@NazeefaFatima \uD83D\uDE0D",
  "id" : 684172392164409344,
  "in_reply_to_status_id" : 684172208336449536,
  "created_at" : "2016-01-05 00:39:44 +0000",
  "in_reply_to_screen_name" : "NazeefaFatima",
  "in_reply_to_user_id_str" : "37054704",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/j9waMEHBsc",
      "expanded_url" : "http:\/\/blog.mothur.org\/2016\/01\/04\/Suck-until-you-dont\/",
      "display_url" : "blog.mothur.org\/2016\/01\/04\/Suc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "684163756386070529",
  "text" : "\u00ABJust remember, you\u2019re going to suck, but it will get better\u00BB advice that works for every walk of life https:\/\/t.co\/j9waMEHBsc",
  "id" : 684163756386070529,
  "created_at" : "2016-01-05 00:05:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Keith Bradnam",
      "screen_name" : "kbradnam",
      "indices" : [ 0, 9 ],
      "id_str" : "17061155",
      "id" : 17061155
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "684103440050601984",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11098127999998, 8.752903119999996 ]
  },
  "id_str" : "684112763065659392",
  "in_reply_to_user_id" : 17061155,
  "text" : "@kbradnam congrats and all the best for the new opportunity!",
  "id" : 684112763065659392,
  "in_reply_to_status_id" : 684103440050601984,
  "created_at" : "2016-01-04 20:42:47 +0000",
  "in_reply_to_screen_name" : "kbradnam",
  "in_reply_to_user_id_str" : "17061155",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 67 ],
      "url" : "https:\/\/t.co\/IVszzEdAW8",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BAIUMRghwl0\/",
      "display_url" : "instagram.com\/p\/BAIUMRghwl0\/"
    } ]
  },
  "geo" : { },
  "id_str" : "684103663023984640",
  "text" : "Avocado-Quinoa salad with tahina and grapes https:\/\/t.co\/IVszzEdAW8",
  "id" : 684103663023984640,
  "created_at" : "2016-01-04 20:06:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 70 ],
      "url" : "https:\/\/t.co\/XeZ6t97bYQ",
      "expanded_url" : "http:\/\/i.imgur.com\/j6oSvMQ.gif",
      "display_url" : "i.imgur.com\/j6oSvMQ.gif"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11236296971339, 8.74751457945327 ]
  },
  "id_str" : "684052788788211712",
  "text" : "Describe your relationship in a single cat gif https:\/\/t.co\/XeZ6t97bYQ",
  "id" : 684052788788211712,
  "created_at" : "2016-01-04 16:44:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/ZGBN48F1FV",
      "expanded_url" : "https:\/\/www.goodreads.com\/user_challenges\/3940723",
      "display_url" : "goodreads.com\/user_challenge\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "684040317784473601",
  "text" : "extrapolating from extremely limited data: i will read 365 books in 2016 https:\/\/t.co\/ZGBN48F1FV",
  "id" : 684040317784473601,
  "created_at" : "2016-01-04 15:54:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Egle Ramanauskaite \u2623",
      "screen_name" : "Seplute",
      "indices" : [ 0, 8 ],
      "id_str" : "188833865",
      "id" : 188833865
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "683985579181260801",
  "geo" : { },
  "id_str" : "684028941867302912",
  "in_reply_to_user_id" : 188833865,
  "text" : "@Seplute congrats! :)",
  "id" : 684028941867302912,
  "in_reply_to_status_id" : 683985579181260801,
  "created_at" : "2016-01-04 15:09:43 +0000",
  "in_reply_to_screen_name" : "Seplute",
  "in_reply_to_user_id_str" : "188833865",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 46 ],
      "url" : "https:\/\/t.co\/68lTSDnsJ2",
      "expanded_url" : "http:\/\/nautil.us\/issue\/22\/slow\/how-to-clock-a-glacier",
      "display_url" : "nautil.us\/issue\/22\/slow\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "684005504662802432",
  "text" : "How To Clock a Glacier https:\/\/t.co\/68lTSDnsJ2",
  "id" : 684005504662802432,
  "created_at" : "2016-01-04 13:36:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/HDL6vcYcGg",
      "expanded_url" : "https:\/\/twitter.com\/Protohedgehog\/status\/683964228458405888",
      "display_url" : "twitter.com\/Protohedgehog\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "683964957621354496",
  "text" : "\u00ABwho on Earth could possibly be so paralyzed by indecision [\u2026], so immune to common sense? I've got it: academics!\u00BB https:\/\/t.co\/HDL6vcYcGg",
  "id" : 683964957621354496,
  "created_at" : "2016-01-04 10:55:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "683951417632002048",
  "geo" : { },
  "id_str" : "683951526080069632",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer just don\u2019t try to pull this off in your own talk (if you give one this year :))",
  "id" : 683951526080069632,
  "in_reply_to_status_id" : 683951417632002048,
  "created_at" : "2016-01-04 10:02:05 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "683950809332097024",
  "geo" : { },
  "id_str" : "683950931382243328",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer don\u2019t forget to draw eyes on your closed eye-lids!",
  "id" : 683950931382243328,
  "in_reply_to_status_id" : 683950809332097024,
  "created_at" : "2016-01-04 09:59:43 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 74 ],
      "url" : "https:\/\/t.co\/ObQGCgjcfM",
      "expanded_url" : "http:\/\/rack.0.mshcdn.com\/media\/ZgkyMDEzLzEwLzA0Lzk2L3RpcmVkY2F0LjBjYTQyLmdpZgpwCXRodW1iCTg1MHg4NTA-CmUJanBn\/94328f4e\/258\/tired-cat.jpg",
      "display_url" : "rack.0.mshcdn.com\/media\/ZgkyMDEz\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "683946131701694465",
  "geo" : { },
  "id_str" : "683947324092116992",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer don\u2019t forget to pack the essentials! https:\/\/t.co\/ObQGCgjcfM",
  "id" : 683947324092116992,
  "in_reply_to_status_id" : 683946131701694465,
  "created_at" : "2016-01-04 09:45:23 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "683944980252127232",
  "geo" : { },
  "id_str" : "683945373119967237",
  "in_reply_to_user_id" : 14286491,
  "text" : "\u00AB[he participated in a circadian clock experiment and] asked to stay in isolation just a few more hours to finish a book he was reading.\u00BB \uD83D\uDC4D",
  "id" : 683945373119967237,
  "in_reply_to_status_id" : 683944980252127232,
  "created_at" : "2016-01-04 09:37:38 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 96, 105 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "quantifiedself",
      "indices" : [ 76, 91 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/5nGwl2YBT1",
      "expanded_url" : "http:\/\/www.vox.com\/science-and-health\/2016\/1\/3\/10693820\/ultimate-quantified-self",
      "display_url" : "vox.com\/science-and-he\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "683944980252127232",
  "text" : "What one man learned from obsessively tracking his vital signs for 48\u00A0years #quantifiedself \/cc @eramirez https:\/\/t.co\/5nGwl2YBT1",
  "id" : 683944980252127232,
  "created_at" : "2016-01-04 09:36:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    }, {
      "name" : "Arikia\uD83D\uDCAB",
      "screen_name" : "arikia",
      "indices" : [ 10, 17 ],
      "id_str" : "71654283",
      "id" : 71654283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 62 ],
      "url" : "https:\/\/t.co\/mq5b3XywO8",
      "expanded_url" : "https:\/\/twitter.com\/lingenhoehl\/status\/683943646744424448",
      "display_url" : "twitter.com\/lingenhoehl\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "683943969559031809",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon @arikia did you see this? :) https:\/\/t.co\/mq5b3XywO8",
  "id" : 683943969559031809,
  "created_at" : "2016-01-04 09:32:04 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "683795071913836544",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1140605674636, 8.753436202838873 ]
  },
  "id_str" : "683820704681312256",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC \uD83D\uDE0D\uD83D\uDC4D",
  "id" : 683820704681312256,
  "in_reply_to_status_id" : 683795071913836544,
  "created_at" : "2016-01-04 01:22:15 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Maryn McKenna",
      "screen_name" : "marynmck",
      "indices" : [ 3, 12 ],
      "id_str" : "15684633",
      "id" : 15684633
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "683791532013518849",
  "text" : "RT @marynmck: \u201CThis is an act of armed sedition against lawful authority\u2026 not \"an expression of anti-government sentiment.\" \u201C https:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\/\" rel=\"nofollow\"\u003EOS X\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 112, 135 ],
        "url" : "https:\/\/t.co\/C6SHCTX16b",
        "expanded_url" : "http:\/\/www.esquire.com\/news-politics\/politics\/news\/a40914\/oregon-bundy-militia\/",
        "display_url" : "esquire.com\/news-politics\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "683789816773779457",
    "text" : "\u201CThis is an act of armed sedition against lawful authority\u2026 not \"an expression of anti-government sentiment.\" \u201C https:\/\/t.co\/C6SHCTX16b",
    "id" : 683789816773779457,
    "created_at" : "2016-01-03 23:19:31 +0000",
    "user" : {
      "name" : "Maryn McKenna",
      "screen_name" : "marynmck",
      "protected" : false,
      "id_str" : "15684633",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/908011072002686981\/308_Nwif_normal.jpg",
      "id" : 15684633,
      "verified" : true
    }
  },
  "id" : 683791532013518849,
  "created_at" : "2016-01-03 23:26:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Weigel Lab",
      "screen_name" : "PlantEvolution",
      "indices" : [ 3, 18 ],
      "id_str" : "100068931",
      "id" : 100068931
    }, {
      "name" : "The New Yorker",
      "screen_name" : "NewYorker",
      "indices" : [ 101, 111 ],
      "id_str" : "14677919",
      "id" : 14677919
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/CHQRa1P7pA",
      "expanded_url" : "http:\/\/buff.ly\/1NYtI11",
      "display_url" : "buff.ly\/1NYtI11"
    } ]
  },
  "geo" : { },
  "id_str" : "683760759181053952",
  "text" : "RT @PlantEvolution: Good read: \"Into the Wild\" McCandless likely died of neurotoxin from wild potato @NewYorker https:\/\/t.co\/CHQRa1P7pA htt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The New Yorker",
        "screen_name" : "NewYorker",
        "indices" : [ 81, 91 ],
        "id_str" : "14677919",
        "id" : 14677919
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/PlantEvolution\/status\/683724830592622592\/photo\/1",
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/tI3R1WoNLN",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CX0UHEIW8AERrfM.jpg",
        "id_str" : "683724830030622721",
        "id" : 683724830030622721,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CX0UHEIW8AERrfM.jpg",
        "sizes" : [ {
          "h" : 385,
          "resize" : "fit",
          "w" : 580
        }, {
          "h" : 385,
          "resize" : "fit",
          "w" : 580
        }, {
          "h" : 385,
          "resize" : "fit",
          "w" : 580
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 385,
          "resize" : "fit",
          "w" : 580
        } ],
        "display_url" : "pic.twitter.com\/tI3R1WoNLN"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 92, 115 ],
        "url" : "https:\/\/t.co\/CHQRa1P7pA",
        "expanded_url" : "http:\/\/buff.ly\/1NYtI11",
        "display_url" : "buff.ly\/1NYtI11"
      } ]
    },
    "geo" : { },
    "id_str" : "683724830592622592",
    "text" : "Good read: \"Into the Wild\" McCandless likely died of neurotoxin from wild potato @NewYorker https:\/\/t.co\/CHQRa1P7pA https:\/\/t.co\/tI3R1WoNLN",
    "id" : 683724830592622592,
    "created_at" : "2016-01-03 19:01:17 +0000",
    "user" : {
      "name" : "Weigel Lab",
      "screen_name" : "PlantEvolution",
      "protected" : false,
      "id_str" : "100068931",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/746204260052787201\/xvz_8gKz_normal.jpg",
      "id" : 100068931,
      "verified" : false
    }
  },
  "id" : 683760759181053952,
  "created_at" : "2016-01-03 21:24:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 64 ],
      "url" : "https:\/\/t.co\/poq4KndNxH",
      "expanded_url" : "https:\/\/twitter.com\/ResearchMark\/status\/683653583900901376",
      "display_url" : "twitter.com\/ResearchMark\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "683718147866816514",
  "text" : "\u00B1 our experience with the openSNP paper. https:\/\/t.co\/poq4KndNxH",
  "id" : 683718147866816514,
  "created_at" : "2016-01-03 18:34:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ttlg",
      "indices" : [ 128, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11405960620182, 8.7534397318094 ]
  },
  "id_str" : "683622591161044994",
  "text" : "\u00AB\u2018Whorfianism\u2019 has largely become an intellectual tax haven for mystical philosophers, fantasists, and post-modern charlatans.\u00BB #ttlg",
  "id" : 683622591161044994,
  "created_at" : "2016-01-03 12:15:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andreas Spiegler",
      "screen_name" : "andreasspiegler",
      "indices" : [ 3, 19 ],
      "id_str" : "14395111",
      "id" : 14395111
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/andreasspiegler\/status\/683374928490528770\/photo\/1",
      "indices" : [ 68, 91 ],
      "url" : "https:\/\/t.co\/3pnL5XU6ap",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CXvV4GMWEAAYOC4.jpg",
      "id_str" : "683374928188542976",
      "id" : 683374928188542976,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CXvV4GMWEAAYOC4.jpg",
      "sizes" : [ {
        "h" : 410,
        "resize" : "fit",
        "w" : 615
      }, {
        "h" : 410,
        "resize" : "fit",
        "w" : 615
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 410,
        "resize" : "fit",
        "w" : 615
      }, {
        "h" : 410,
        "resize" : "fit",
        "w" : 615
      } ],
      "display_url" : "pic.twitter.com\/3pnL5XU6ap"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 67 ],
      "url" : "https:\/\/t.co\/4C75yFJCdN",
      "expanded_url" : "http:\/\/www.theatlantic.com\/technology\/archive\/2015\/01\/why-i-am-not-a-maker\/384767\/",
      "display_url" : "theatlantic.com\/technology\/arc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "683380434475061248",
  "text" : "RT @andreasspiegler: Why I Am Not a Maker - https:\/\/t.co\/4C75yFJCdN https:\/\/t.co\/3pnL5XU6ap",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/andreasspiegler\/status\/683374928490528770\/photo\/1",
        "indices" : [ 47, 70 ],
        "url" : "https:\/\/t.co\/3pnL5XU6ap",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CXvV4GMWEAAYOC4.jpg",
        "id_str" : "683374928188542976",
        "id" : 683374928188542976,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CXvV4GMWEAAYOC4.jpg",
        "sizes" : [ {
          "h" : 410,
          "resize" : "fit",
          "w" : 615
        }, {
          "h" : 410,
          "resize" : "fit",
          "w" : 615
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 410,
          "resize" : "fit",
          "w" : 615
        }, {
          "h" : 410,
          "resize" : "fit",
          "w" : 615
        } ],
        "display_url" : "pic.twitter.com\/3pnL5XU6ap"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 23, 46 ],
        "url" : "https:\/\/t.co\/4C75yFJCdN",
        "expanded_url" : "http:\/\/www.theatlantic.com\/technology\/archive\/2015\/01\/why-i-am-not-a-maker\/384767\/",
        "display_url" : "theatlantic.com\/technology\/arc\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "683374928490528770",
    "text" : "Why I Am Not a Maker - https:\/\/t.co\/4C75yFJCdN https:\/\/t.co\/3pnL5XU6ap",
    "id" : 683374928490528770,
    "created_at" : "2016-01-02 19:50:54 +0000",
    "user" : {
      "name" : "Andreas Spiegler",
      "screen_name" : "andreasspiegler",
      "protected" : false,
      "id_str" : "14395111",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/777206226291654657\/E5wowVJA_normal.jpg",
      "id" : 14395111,
      "verified" : false
    }
  },
  "id" : 683380434475061248,
  "created_at" : "2016-01-02 20:12:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "683366279693099008",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11404252575387, 8.753314904280371 ]
  },
  "id_str" : "683366452729135105",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich I\u2019m down with a cold in my bed. So go figure. :3",
  "id" : 683366452729135105,
  "in_reply_to_status_id" : 683366279693099008,
  "created_at" : "2016-01-02 19:17:13 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "683364029646110720",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11405874404264, 8.75342139357848 ]
  },
  "id_str" : "683364238925152257",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich I\u2019m home, actually have been since end of November or so!",
  "id" : 683364238925152257,
  "in_reply_to_status_id" : 683364029646110720,
  "created_at" : "2016-01-02 19:08:25 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "683360328558718976",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11407072028106, 8.7532789263803 ]
  },
  "id_str" : "683362962342580224",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich there are still two avocados left, so just hurry up :p",
  "id" : 683362962342580224,
  "in_reply_to_status_id" : 683360328558718976,
  "created_at" : "2016-01-02 19:03:21 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 66 ],
      "url" : "https:\/\/t.co\/fpgETW3Ljf",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BADCEbQhwsA\/",
      "display_url" : "instagram.com\/p\/BADCEbQhwsA\/"
    } ]
  },
  "geo" : { },
  "id_str" : "683360123151101952",
  "text" : "Avocado filled with chickpeas and Tahina \uD83D\uDE0D https:\/\/t.co\/fpgETW3Ljf",
  "id" : 683360123151101952,
  "created_at" : "2016-01-02 18:52:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Atossa Araxia Abrahamian",
      "screen_name" : "atossaaraxia",
      "indices" : [ 27, 40 ],
      "id_str" : "228437800",
      "id" : 228437800
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/tivpa7ifx0",
      "expanded_url" : "http:\/\/www.amazon.com\/The-Cosmopolites-What-Citizen-World\/dp\/099097636X",
      "display_url" : "amazon.com\/The-Cosmopolit\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "683359019298361344",
  "text" : "Wow, \"The Cosmopolites\" by @atossaaraxia is one of the best random book store finds I made in a while.  https:\/\/t.co\/tivpa7ifx0",
  "id" : 683359019298361344,
  "created_at" : "2016-01-02 18:47:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Bond",
      "screen_name" : "TheLabAndField",
      "indices" : [ 3, 18 ],
      "id_str" : "1060545835",
      "id" : 1060545835
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/thelabandfield\/status\/683213825655484416\/photo\/1",
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/dSFHntM35C",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CXtDWoHUoAADZeW.jpg",
      "id_str" : "683213824481075200",
      "id" : 683213824481075200,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CXtDWoHUoAADZeW.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/dSFHntM35C"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 88 ],
      "url" : "https:\/\/t.co\/lr83nFqHmE",
      "expanded_url" : "https:\/\/labandfield.wordpress.com\/2016\/01\/02\/landing-an-academic-job-is-like-an-albatross\/",
      "display_url" : "labandfield.wordpress.com\/2016\/01\/02\/lan\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "683345077733863424",
  "text" : "RT @thelabandfield: Landing an academic job is like an\u00A0albatross https:\/\/t.co\/lr83nFqHmE https:\/\/t.co\/dSFHntM35C",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/thelabandfield\/status\/683213825655484416\/photo\/1",
        "indices" : [ 69, 92 ],
        "url" : "https:\/\/t.co\/dSFHntM35C",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CXtDWoHUoAADZeW.jpg",
        "id_str" : "683213824481075200",
        "id" : 683213824481075200,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CXtDWoHUoAADZeW.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/dSFHntM35C"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 45, 68 ],
        "url" : "https:\/\/t.co\/lr83nFqHmE",
        "expanded_url" : "https:\/\/labandfield.wordpress.com\/2016\/01\/02\/landing-an-academic-job-is-like-an-albatross\/",
        "display_url" : "labandfield.wordpress.com\/2016\/01\/02\/lan\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "683213825655484416",
    "text" : "Landing an academic job is like an\u00A0albatross https:\/\/t.co\/lr83nFqHmE https:\/\/t.co\/dSFHntM35C",
    "id" : 683213825655484416,
    "created_at" : "2016-01-02 09:10:44 +0000",
    "user" : {
      "name" : "Alex Bond",
      "screen_name" : "TheLabAndField",
      "protected" : false,
      "id_str" : "1060545835",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/851184072890167297\/jIBXYvtR_normal.jpg",
      "id" : 1060545835,
      "verified" : false
    }
  },
  "id" : 683345077733863424,
  "created_at" : "2016-01-02 17:52:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 62 ],
      "url" : "https:\/\/t.co\/CUftH9hsac",
      "expanded_url" : "https:\/\/twitter.com\/ctitusbrown\/status\/683296004767010816",
      "display_url" : "twitter.com\/ctitusbrown\/st\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11406560131493, 8.753235599855433 ]
  },
  "id_str" : "683343839025827840",
  "text" : "On how hostile academia is to romance\u2026 https:\/\/t.co\/CUftH9hsac",
  "id" : 683343839025827840,
  "created_at" : "2016-01-02 17:47:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex",
      "screen_name" : "Alex_Studi",
      "indices" : [ 0, 11 ],
      "id_str" : "214413946",
      "id" : 214413946
    }, {
      "name" : "Fnordfunk",
      "screen_name" : "Fnordfunk",
      "indices" : [ 12, 22 ],
      "id_str" : "149090725",
      "id" : 149090725
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "683326304737980416",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11407463588684, 8.75338922632289 ]
  },
  "id_str" : "683328543472902149",
  "in_reply_to_user_id" : 214413946,
  "text" : "@Alex_Studi @Fnordfunk hoffe sie gef\u00E4llt :)",
  "id" : 683328543472902149,
  "in_reply_to_status_id" : 683326304737980416,
  "created_at" : "2016-01-02 16:46:35 +0000",
  "in_reply_to_screen_name" : "Alex_Studi",
  "in_reply_to_user_id_str" : "214413946",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/u5nX0ghLdU",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/683060447382208512",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "683060447382208512",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11406015061808, 8.753436065291158 ]
  },
  "id_str" : "683323583658065920",
  "in_reply_to_user_id" : 14286491,
  "text" : "\u00ABI found a huge bottle of personal lubricant while cleaning the bath! Shouldn\u2019t it be in your room?!\u00BB\u2014\u00ABSee Twitter!\u00BB https:\/\/t.co\/u5nX0ghLdU",
  "id" : 683323583658065920,
  "in_reply_to_status_id" : 683060447382208512,
  "created_at" : "2016-01-02 16:26:52 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Turner",
      "screen_name" : "genetics_blog",
      "indices" : [ 3, 17 ],
      "id_str" : "923639552874557440",
      "id" : 923639552874557440
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/dyFGceJyoB",
      "expanded_url" : "https:\/\/twitter.com\/sciencemagazine\/status\/682955226698100737",
      "display_url" : "twitter.com\/sciencemagazin\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "683290258461618176",
  "text" : "RT @genetics_blog: If GO, OMIM, UniProt, Reactome, Flybase, Wormbase, etc all go the way of KEGG, we\u2019re F\u2019d. https:\/\/t.co\/dyFGceJyoB",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 90, 113 ],
        "url" : "https:\/\/t.co\/dyFGceJyoB",
        "expanded_url" : "https:\/\/twitter.com\/sciencemagazine\/status\/682955226698100737",
        "display_url" : "twitter.com\/sciencemagazin\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "683005159102889984",
    "text" : "If GO, OMIM, UniProt, Reactome, Flybase, Wormbase, etc all go the way of KEGG, we\u2019re F\u2019d. https:\/\/t.co\/dyFGceJyoB",
    "id" : 683005159102889984,
    "created_at" : "2016-01-01 19:21:34 +0000",
    "user" : {
      "name" : "Stephen Turner",
      "screen_name" : "strnr",
      "protected" : false,
      "id_str" : "20444825",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/660439762856230913\/ARYE5YB6_normal.jpg",
      "id" : 20444825,
      "verified" : false
    }
  },
  "id" : 683290258461618176,
  "created_at" : "2016-01-02 14:14:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11398496913178, 8.753438708271503 ]
  },
  "id_str" : "683280061882068992",
  "text" : "\u00ABFor us to be governed by an eighteenth-century institution called a nation is obviously insane.\u00BB - Garry Davis in 2012",
  "id" : 683280061882068992,
  "created_at" : "2016-01-02 13:33:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katha",
      "screen_name" : "kathakatze",
      "indices" : [ 0, 11 ],
      "id_str" : "541170257",
      "id" : 541170257
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 12, 18 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "683260488508137472",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11398646004715, 8.753286627185108 ]
  },
  "id_str" : "683261171651207168",
  "in_reply_to_user_id" : 541170257,
  "text" : "@kathakatze @Lobot daf\u00FCr gibt es ja Laserdrucker, aber dann erzeugt man vermutlich ein neues Ozonloch :p",
  "id" : 683261171651207168,
  "in_reply_to_status_id" : 683260488508137472,
  "created_at" : "2016-01-02 12:18:52 +0000",
  "in_reply_to_screen_name" : "kathakatze",
  "in_reply_to_user_id_str" : "541170257",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katha",
      "screen_name" : "kathakatze",
      "indices" : [ 0, 11 ],
      "id_str" : "541170257",
      "id" : 541170257
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 12, 18 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "683260015285800961",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11397625407267, 8.75345373996798 ]
  },
  "id_str" : "683260291107434498",
  "in_reply_to_user_id" : 541170257,
  "text" : "@kathakatze @Lobot \u201Cund jetzt zeig mir an der Flowchart wo dein eindimensionales Erkl\u00E4rungsmodell funktioniert\u201D",
  "id" : 683260291107434498,
  "in_reply_to_status_id" : 683260015285800961,
  "created_at" : "2016-01-02 12:15:22 +0000",
  "in_reply_to_screen_name" : "kathakatze",
  "in_reply_to_user_id_str" : "541170257",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katha",
      "screen_name" : "kathakatze",
      "indices" : [ 0, 11 ],
      "id_str" : "541170257",
      "id" : 541170257
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 12, 18 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "683259125413842946",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11397625407267, 8.75345373996798 ]
  },
  "id_str" : "683259768102883328",
  "in_reply_to_user_id" : 541170257,
  "text" : "@kathakatze @Lobot gerne, dann h\u00F6rt so Cherry-Picking-BS vielleicht irgendwann mal auf.",
  "id" : 683259768102883328,
  "in_reply_to_status_id" : 683259125413842946,
  "created_at" : "2016-01-02 12:13:17 +0000",
  "in_reply_to_screen_name" : "kathakatze",
  "in_reply_to_user_id_str" : "541170257",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katha",
      "screen_name" : "kathakatze",
      "indices" : [ 0, 11 ],
      "id_str" : "541170257",
      "id" : 541170257
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 12, 18 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "683258285609332736",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11405401428805, 8.75338259672679 ]
  },
  "id_str" : "683258604607115264",
  "in_reply_to_user_id" : 541170257,
  "text" : "@kathakatze @Lobot angefangen bei der Antibiotika-Herstellung f\u00FCr die K\u00FChe ;)",
  "id" : 683258604607115264,
  "in_reply_to_status_id" : 683258285609332736,
  "created_at" : "2016-01-02 12:08:40 +0000",
  "in_reply_to_screen_name" : "kathakatze",
  "in_reply_to_user_id_str" : "541170257",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "683254850675687424",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11406667863724, 8.753387282347978 ]
  },
  "id_str" : "683257946109808640",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot wenn man einfach die Produktionsschritte vorher ausblendet auch ein super Vergleich\u2026",
  "id" : 683257946109808640,
  "in_reply_to_status_id" : 683254850675687424,
  "created_at" : "2016-01-02 12:06:03 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Yoder \uD83D\uDD96\uD83C\uDFFB",
      "screen_name" : "JBYoder",
      "indices" : [ 3, 11 ],
      "id_str" : "19984919",
      "id" : 19984919
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "683079187800961025",
  "text" : "RT @JBYoder: It is extremely easy to say this from the comfort of a tenure-track position. And it\u2019s basically tautological. https:\/\/t.co\/z9\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 111, 134 ],
        "url" : "https:\/\/t.co\/z9lkJR8zfu",
        "expanded_url" : "https:\/\/twitter.com\/hormiga\/status\/683067282763845632",
        "display_url" : "twitter.com\/hormiga\/status\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "683072060411674624",
    "text" : "It is extremely easy to say this from the comfort of a tenure-track position. And it\u2019s basically tautological. https:\/\/t.co\/z9lkJR8zfu",
    "id" : 683072060411674624,
    "created_at" : "2016-01-01 23:47:24 +0000",
    "user" : {
      "name" : "Jeremy Yoder \uD83D\uDD96\uD83C\uDFFB",
      "screen_name" : "JBYoder",
      "protected" : false,
      "id_str" : "19984919",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/870850169759072256\/r0kxCgGs_normal.jpg",
      "id" : 19984919,
      "verified" : true
    }
  },
  "id" : 683079187800961025,
  "created_at" : "2016-01-02 00:15:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Yoder \uD83D\uDD96\uD83C\uDFFB",
      "screen_name" : "JBYoder",
      "indices" : [ 0, 8 ],
      "id_str" : "19984919",
      "id" : 19984919
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "683072529712295936",
  "geo" : { },
  "id_str" : "683078934800510976",
  "in_reply_to_user_id" : 19984919,
  "text" : "@JBYoder and if you\u2019re privileged enough to move all over the world and can spend years applying to all those positions\u2026",
  "id" : 683078934800510976,
  "in_reply_to_status_id" : 683072529712295936,
  "created_at" : "2016-01-02 00:14:43 +0000",
  "in_reply_to_screen_name" : "JBYoder",
  "in_reply_to_user_id_str" : "19984919",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 67 ],
      "url" : "https:\/\/t.co\/9Yy2zUt1iF",
      "expanded_url" : "http:\/\/blogs.discovermagazine.com\/neuroskeptic\/2016\/01\/01\/sleep-deprivation-brain\/",
      "display_url" : "blogs.discovermagazine.com\/neuroskeptic\/2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "683072343850270720",
  "text" : "Sleep Deprivation Alters Brain Connectivity https:\/\/t.co\/9Yy2zUt1iF",
  "id" : 683072343850270720,
  "created_at" : "2016-01-01 23:48:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 6, 29 ],
      "url" : "https:\/\/t.co\/NZfw27FNFL",
      "expanded_url" : "http:\/\/www.amberunmasked.com\/wp-content\/uploads\/2015\/12\/Frankie_LubeForEveryone.gif",
      "display_url" : "amberunmasked.com\/wp-content\/upl\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11406144521429, 8.753180560805461 ]
  },
  "id_str" : "683060447382208512",
  "text" : "Word! https:\/\/t.co\/NZfw27FNFL",
  "id" : 683060447382208512,
  "created_at" : "2016-01-01 23:01:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "683009944887640064",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1113579844862, 8.75288315379868 ]
  },
  "id_str" : "683010292343771137",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich one day I will run a campaign with that name!",
  "id" : 683010292343771137,
  "in_reply_to_status_id" : 683009944887640064,
  "created_at" : "2016-01-01 19:41:58 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "683006378043125760",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11407189296435, 8.753292400921138 ]
  },
  "id_str" : "683008756091891716",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich finally a way to make money out of openSNP \uD83D\uDE02",
  "id" : 683008756091891716,
  "in_reply_to_status_id" : 683006378043125760,
  "created_at" : "2016-01-01 19:35:51 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uD83D\uDD25\uD83D\uDC1C\uD83D\uDC78\uD83C\uDFFC",
      "screen_name" : "fireantprincess",
      "indices" : [ 0, 16 ],
      "id_str" : "77216385",
      "id" : 77216385
    }, {
      "name" : "L3viathan",
      "screen_name" : "L3viathan2142",
      "indices" : [ 17, 31 ],
      "id_str" : "23305817",
      "id" : 23305817
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "683001820814438400",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11407189296435, 8.753292400921138 ]
  },
  "id_str" : "683008632070508545",
  "in_reply_to_user_id" : 77216385,
  "text" : "@fireantprincess @L3viathan2142 das ist sehr cool. Aber noch einen Standard entwerfen? ;)",
  "id" : 683008632070508545,
  "in_reply_to_status_id" : 683001820814438400,
  "created_at" : "2016-01-01 19:35:22 +0000",
  "in_reply_to_screen_name" : "fireantprincess",
  "in_reply_to_user_id_str" : "77216385",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uD83D\uDD25\uD83D\uDC1C\uD83D\uDC78\uD83C\uDFFC",
      "screen_name" : "fireantprincess",
      "indices" : [ 0, 16 ],
      "id_str" : "77216385",
      "id" : 77216385
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "683000879943925760",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11405985537863, 8.753425590264847 ]
  },
  "id_str" : "683001111356248068",
  "in_reply_to_user_id" : 77216385,
  "text" : "@fireantprincess eingebunden in openSNP ;)",
  "id" : 683001111356248068,
  "in_reply_to_status_id" : 683000879943925760,
  "created_at" : "2016-01-01 19:05:29 +0000",
  "in_reply_to_screen_name" : "fireantprincess",
  "in_reply_to_user_id_str" : "77216385",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uD83D\uDD25\uD83D\uDC1C\uD83D\uDC78\uD83C\uDFFC",
      "screen_name" : "fireantprincess",
      "indices" : [ 0, 16 ],
      "id_str" : "77216385",
      "id" : 77216385
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "682998058410442752",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11405985537863, 8.753425590264847 ]
  },
  "id_str" : "683000451948765184",
  "in_reply_to_user_id" : 77216385,
  "text" : "@fireantprincess die eigentliche frage ist: wieso habe ich das noch nie gemacht?! :p",
  "id" : 683000451948765184,
  "in_reply_to_status_id" : 682998058410442752,
  "created_at" : "2016-01-01 19:02:51 +0000",
  "in_reply_to_screen_name" : "fireantprincess",
  "in_reply_to_user_id_str" : "77216385",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/d0kaEAukXL",
      "expanded_url" : "https:\/\/twitter.com\/randal_olson\/status\/682985915422240773",
      "display_url" : "twitter.com\/randal_olson\/s\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.10897567947635, 8.75726528416842 ]
  },
  "id_str" : "682995363905679360",
  "text" : "Still wonder how the annotation could be accurately synced to the graph. https:\/\/t.co\/d0kaEAukXL",
  "id" : 682995363905679360,
  "created_at" : "2016-01-01 18:42:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "682982717013798914",
  "geo" : { },
  "id_str" : "682986970927218688",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich pssst! don\u2019t give them ideas!",
  "id" : 682986970927218688,
  "in_reply_to_status_id" : 682982717013798914,
  "created_at" : "2016-01-01 18:09:17 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11405993715685, 8.753426824987693 ]
  },
  "id_str" : "682981519560945664",
  "text" : "\u00ABYou might consider deleting this as the uploaded file is not a DNA data file but a pornographic cartoon picture\u00BB submissions openSNP gets\u2026",
  "id" : 682981519560945664,
  "created_at" : "2016-01-01 17:47:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 78 ],
      "url" : "https:\/\/t.co\/dJVgI3Brnx",
      "expanded_url" : "http:\/\/boingboing.net\/2015\/12\/31\/guesstimate-a-spreadsheet-for.html",
      "display_url" : "boingboing.net\/2015\/12\/31\/gue\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "682973747154948096",
  "text" : "Guesstimate: a spreadsheet for adding up uncertainties https:\/\/t.co\/dJVgI3Brnx",
  "id" : 682973747154948096,
  "created_at" : "2016-01-01 17:16:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "malech maltz",
      "screen_name" : "malech",
      "indices" : [ 0, 7 ],
      "id_str" : "784085846391713793",
      "id" : 784085846391713793
    }, {
      "name" : "Jonas",
      "screen_name" : "lsanoj",
      "indices" : [ 8, 15 ],
      "id_str" : "18918915",
      "id" : 18918915
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 16, 22 ],
      "id_str" : "1492631",
      "id" : 1492631
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 27, 43 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11406711789605, 8.753377276634712 ]
  },
  "id_str" : "682943522404696065",
  "text" : "@malech @lsanoj @Lobot Dr. @gedankenstuecke approves this Message.",
  "id" : 682943522404696065,
  "created_at" : "2016-01-01 15:16:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Quartz",
      "screen_name" : "qz",
      "indices" : [ 3, 6 ],
      "id_str" : "573918122",
      "id" : 573918122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/REtnESaZbT",
      "expanded_url" : "http:\/\/qz.com\/580123",
      "display_url" : "qz.com\/580123"
    } ]
  },
  "geo" : { },
  "id_str" : "682908336669483008",
  "text" : "RT @qz: It's Public Domain Day and once again Americans get almost nothing https:\/\/t.co\/REtnESaZbT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 67, 90 ],
        "url" : "https:\/\/t.co\/REtnESaZbT",
        "expanded_url" : "http:\/\/qz.com\/580123",
        "display_url" : "qz.com\/580123"
      } ]
    },
    "geo" : { },
    "id_str" : "682897827945558021",
    "text" : "It's Public Domain Day and once again Americans get almost nothing https:\/\/t.co\/REtnESaZbT",
    "id" : 682897827945558021,
    "created_at" : "2016-01-01 12:15:04 +0000",
    "user" : {
      "name" : "Quartz",
      "screen_name" : "qz",
      "protected" : false,
      "id_str" : "573918122",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615280495958495232\/nX0-Mypb_normal.png",
      "id" : 573918122,
      "verified" : true
    }
  },
  "id" : 682908336669483008,
  "created_at" : "2016-01-01 12:56:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 53, 59 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 84 ],
      "url" : "https:\/\/t.co\/faLRXm8vLj",
      "expanded_url" : "http:\/\/www.boredpanda.com\/bicycle-highway-autobahn-germany\/",
      "display_url" : "boredpanda.com\/bicycle-highwa\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "682907520667627520",
  "text" : "Germany Opens Part Of A 100 Km Bicycle Superhighway \/@Lobot  https:\/\/t.co\/faLRXm8vLj",
  "id" : 682907520667627520,
  "created_at" : "2016-01-01 12:53:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
} ]