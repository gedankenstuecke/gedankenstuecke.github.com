Grailbird.data.tweets_2017_03 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonas",
      "screen_name" : "lsanoj",
      "indices" : [ 0, 7 ],
      "id_str" : "18918915",
      "id" : 18918915
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "847875774170509314",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11393806271234, 8.75328083610409 ]
  },
  "id_str" : "847875946736758786",
  "in_reply_to_user_id" : 18918915,
  "text" : "@lsanoj close :D",
  "id" : 847875946736758786,
  "in_reply_to_status_id" : 847875774170509314,
  "created_at" : "2017-03-31 18:19:13 +0000",
  "in_reply_to_screen_name" : "lsanoj",
  "in_reply_to_user_id_str" : "18918915",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rae Knowler",
      "screen_name" : "RaeKnowler",
      "indices" : [ 0, 11 ],
      "id_str" : "1244114060",
      "id" : 1244114060
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "847845299020324865",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.04886198358458, 8.7008420658662 ]
  },
  "id_str" : "847845567170588680",
  "in_reply_to_user_id" : 1244114060,
  "text" : "@RaeKnowler only half a year after first contacting them :p",
  "id" : 847845567170588680,
  "in_reply_to_status_id" : 847845299020324865,
  "created_at" : "2017-03-31 16:18:30 +0000",
  "in_reply_to_screen_name" : "RaeKnowler",
  "in_reply_to_user_id_str" : "1244114060",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rae Knowler",
      "screen_name" : "RaeKnowler",
      "indices" : [ 51, 62 ],
      "id_str" : "1244114060",
      "id" : 1244114060
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.05106606815176, 8.697793486933364 ]
  },
  "id_str" : "847843774780895233",
  "text" : "Got a date for my Photo 51 inking: 20th of June. \uD83C\uDF89 @RaeKnowler",
  "id" : 847843774780895233,
  "created_at" : "2017-03-31 16:11:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "847822704166260737",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17232416752844, 8.627518054161927 ]
  },
  "id_str" : "847828110561116160",
  "in_reply_to_user_id" : 14286491,
  "text" : "Anyone wants to take a guess how many of the articles in SciHub are published through Elsevier? \uD83D\uDE02",
  "id" : 847828110561116160,
  "in_reply_to_status_id" : 847822704166260737,
  "created_at" : "2017-03-31 15:09:08 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "847822704166260737",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17238066149708, 8.62750421213604 ]
  },
  "id_str" : "847822877860777984",
  "in_reply_to_user_id" : 14286491,
  "text" : "Hope to have that data released by next week.",
  "id" : 847822877860777984,
  "in_reply_to_status_id" : 847822704166260737,
  "created_at" : "2017-03-31 14:48:20 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/P8lpXt2heA",
      "expanded_url" : "http:\/\/doi.org",
      "display_url" : "doi.org"
    }, {
      "indices" : [ 141, 164 ],
      "url" : "https:\/\/t.co\/lQ7o1ds4WI",
      "expanded_url" : "https:\/\/twitter.com\/marc_rr\/status\/847805118355558400",
      "display_url" : "twitter.com\/marc_rr\/status\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17236413011549, 8.627519185475789 ]
  },
  "id_str" : "847822704166260737",
  "text" : "Somewhat related: After trying to resolve over 99% of the 62 mio SciHub DOI via https:\/\/t.co\/P8lpXt2heA it turns out about 24% of those fail https:\/\/t.co\/lQ7o1ds4WI",
  "id" : 847822704166260737,
  "created_at" : "2017-03-31 14:47:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 42 ],
      "url" : "https:\/\/t.co\/vuZF1phNAZ",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BSThW2QjEaQ\/",
      "display_url" : "instagram.com\/p\/BSThW2QjEaQ\/"
    } ]
  },
  "geo" : { },
  "id_str" : "847810321498746881",
  "text" : "photic yawn effect https:\/\/t.co\/vuZF1phNAZ",
  "id" : 847810321498746881,
  "created_at" : "2017-03-31 13:58:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthew Holden",
      "screen_name" : "mtgholden",
      "indices" : [ 0, 10 ],
      "id_str" : "2900377593",
      "id" : 2900377593
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "847803395406778369",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17232012238409, 8.627523073379265 ]
  },
  "id_str" : "847807228086243329",
  "in_reply_to_user_id" : 2900377593,
  "text" : "@mtgholden hah, of course! Thanks!",
  "id" : 847807228086243329,
  "in_reply_to_status_id" : 847803395406778369,
  "created_at" : "2017-03-31 13:46:09 +0000",
  "in_reply_to_screen_name" : "mtgholden",
  "in_reply_to_user_id_str" : "2900377593",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthew Holden",
      "screen_name" : "mtgholden",
      "indices" : [ 0, 10 ],
      "id_str" : "2900377593",
      "id" : 2900377593
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "847801258316529664",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723401937537, 8.627517822534235 ]
  },
  "id_str" : "847801358543724544",
  "in_reply_to_user_id" : 2900377593,
  "text" : "@mtgholden awesome, can you DM me your preferred email? :)",
  "id" : 847801358543724544,
  "in_reply_to_status_id" : 847801258316529664,
  "created_at" : "2017-03-31 13:22:49 +0000",
  "in_reply_to_screen_name" : "mtgholden",
  "in_reply_to_user_id_str" : "2900377593",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthew Holden",
      "screen_name" : "mtgholden",
      "indices" : [ 0, 10 ],
      "id_str" : "2900377593",
      "id" : 2900377593
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "847562308318396416",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17238381913703, 8.6275108028518 ]
  },
  "id_str" : "847798438314078209",
  "in_reply_to_user_id" : 2900377593,
  "text" : "@mtgholden awesome! The substitution part for RpsL confuses me a bit (as in: can\u2019t follow it). Mind if I contact re question?",
  "id" : 847798438314078209,
  "in_reply_to_status_id" : 847562308318396416,
  "created_at" : "2017-03-31 13:11:13 +0000",
  "in_reply_to_screen_name" : "mtgholden",
  "in_reply_to_user_id_str" : "2900377593",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "daisy",
      "screen_name" : "mermatriarch",
      "indices" : [ 3, 16 ],
      "id_str" : "464735421",
      "id" : 464735421
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "847775581186007040",
  "text" : "RT @mermatriarch: as a bisexual i am unable to go out for meals with anyone. socialising is a nightmare. please help i'm hungry https:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 110, 133 ],
        "url" : "https:\/\/t.co\/PcwbK4TnC5",
        "expanded_url" : "https:\/\/twitter.com\/mattwalshblog\/status\/847267661629214721",
        "display_url" : "twitter.com\/mattwalshblog\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "847435333566201856",
    "text" : "as a bisexual i am unable to go out for meals with anyone. socialising is a nightmare. please help i'm hungry https:\/\/t.co\/PcwbK4TnC5",
    "id" : 847435333566201856,
    "created_at" : "2017-03-30 13:08:22 +0000",
    "user" : {
      "name" : "daisy",
      "screen_name" : "mermatriarch",
      "protected" : false,
      "id_str" : "464735421",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/929763840564383745\/TmRTK9ab_normal.jpg",
      "id" : 464735421,
      "verified" : false
    }
  },
  "id" : 847775581186007040,
  "created_at" : "2017-03-31 11:40:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 128, 151 ],
      "url" : "https:\/\/t.co\/gsbT8i8NrU",
      "expanded_url" : "https:\/\/twitter.com\/tslumley\/status\/847301537315540993",
      "display_url" : "twitter.com\/tslumley\/statu\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17237484122697, 8.62750900526354 ]
  },
  "id_str" : "847770498133929985",
  "text" : "\u00ABYou can teach more statistics than most scientists need to know without using calculus, matrices, or even summation notation.\u00BB https:\/\/t.co\/gsbT8i8NrU",
  "id" : 847770498133929985,
  "created_at" : "2017-03-31 11:20:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Manuel Corpas",
      "screen_name" : "manuelcorpas",
      "indices" : [ 0, 13 ],
      "id_str" : "111020569",
      "id" : 111020569
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "847709552988405761",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17236804417248, 8.627525862677189 ]
  },
  "id_str" : "847710995086585856",
  "in_reply_to_user_id" : 111020569,
  "text" : "@manuelcorpas sure can rank them, but will be highly inaccurate if only ranked based on genomes. That\u2019s all I\u2019m trying to say :-)",
  "id" : 847710995086585856,
  "in_reply_to_status_id" : 847709552988405761,
  "created_at" : "2017-03-31 07:23:45 +0000",
  "in_reply_to_screen_name" : "manuelcorpas",
  "in_reply_to_user_id_str" : "111020569",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Manuel Corpas",
      "screen_name" : "manuelcorpas",
      "indices" : [ 0, 13 ],
      "id_str" : "111020569",
      "id" : 111020569
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "847707776314888193",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723790611879, 8.627523028045772 ]
  },
  "id_str" : "847708210332958721",
  "in_reply_to_user_id" : 111020569,
  "text" : "@manuelcorpas which is why \u201Epredict an individual\u2019s expected health cost based on their genome\u201C will be inaccurate w\/o other information.",
  "id" : 847708210332958721,
  "in_reply_to_status_id" : 847707776314888193,
  "created_at" : "2017-03-31 07:12:41 +0000",
  "in_reply_to_screen_name" : "manuelcorpas",
  "in_reply_to_user_id_str" : "111020569",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Manuel Corpas",
      "screen_name" : "manuelcorpas",
      "indices" : [ 0, 13 ],
      "id_str" : "111020569",
      "id" : 111020569
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "847707238894522370",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723790611879, 8.627523028045772 ]
  },
  "id_str" : "847707492045828097",
  "in_reply_to_user_id" : 111020569,
  "text" : "@manuelcorpas if your health is off way worse due to your socioeconomic situation all the genomics in the world will not help to predict it",
  "id" : 847707492045828097,
  "in_reply_to_status_id" : 847707238894522370,
  "created_at" : "2017-03-31 07:09:50 +0000",
  "in_reply_to_screen_name" : "manuelcorpas",
  "in_reply_to_user_id_str" : "111020569",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Manuel Corpas",
      "screen_name" : "manuelcorpas",
      "indices" : [ 0, 13 ],
      "id_str" : "111020569",
      "id" : 111020569
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "847704012501667840",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723790611879, 8.627523028045772 ]
  },
  "id_str" : "847706089567133696",
  "in_reply_to_user_id" : 111020569,
  "text" : "@manuelcorpas and if predictive value of environment &gt; genetics than it\u2019s hardly genomics that\u2019ll be the predictor :)",
  "id" : 847706089567133696,
  "in_reply_to_status_id" : 847704012501667840,
  "created_at" : "2017-03-31 07:04:16 +0000",
  "in_reply_to_screen_name" : "manuelcorpas",
  "in_reply_to_user_id_str" : "111020569",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Manuel Corpas",
      "screen_name" : "manuelcorpas",
      "indices" : [ 0, 13 ],
      "id_str" : "111020569",
      "id" : 111020569
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 74 ],
      "url" : "https:\/\/t.co\/MbaKPd3LrM",
      "expanded_url" : "https:\/\/linkinghub.elsevier.com\/retrieve\/pii\/S0277-9536(14)00839-9",
      "display_url" : "linkinghub.elsevier.com\/retrieve\/pii\/S\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "847704012501667840",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723790611879, 8.627523028045772 ]
  },
  "id_str" : "847705921765613569",
  "in_reply_to_user_id" : 111020569,
  "text" : "@manuelcorpas that\u2019s not my point, rather this is: https:\/\/t.co\/MbaKPd3LrM",
  "id" : 847705921765613569,
  "in_reply_to_status_id" : 847704012501667840,
  "created_at" : "2017-03-31 07:03:36 +0000",
  "in_reply_to_screen_name" : "manuelcorpas",
  "in_reply_to_user_id_str" : "111020569",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Keith Robison",
      "screen_name" : "OmicsOmicsBlog",
      "indices" : [ 3, 18 ],
      "id_str" : "116867280",
      "id" : 116867280
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/6YgZvLvNSK",
      "expanded_url" : "http:\/\/omicsomics.blogspot.com\/2017\/03\/chromosome-scale-scaffolds-and-state-of.html",
      "display_url" : "omicsomics.blogspot.com\/2017\/03\/chromo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "847704373467598848",
  "text" : "RT @OmicsOmicsBlog: Chromosome-Scale Scaffolds And The State of Genome Assembly https:\/\/t.co\/6YgZvLvNSK",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 60, 83 ],
        "url" : "https:\/\/t.co\/6YgZvLvNSK",
        "expanded_url" : "http:\/\/omicsomics.blogspot.com\/2017\/03\/chromosome-scale-scaffolds-and-state-of.html",
        "display_url" : "omicsomics.blogspot.com\/2017\/03\/chromo\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "847652661193170944",
    "text" : "Chromosome-Scale Scaffolds And The State of Genome Assembly https:\/\/t.co\/6YgZvLvNSK",
    "id" : 847652661193170944,
    "created_at" : "2017-03-31 03:31:57 +0000",
    "user" : {
      "name" : "Keith Robison",
      "screen_name" : "OmicsOmicsBlog",
      "protected" : false,
      "id_str" : "116867280",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/859776960058339329\/c0IznW_h_normal.jpg",
      "id" : 116867280,
      "verified" : false
    }
  },
  "id" : 847704373467598848,
  "created_at" : "2017-03-31 06:57:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/rgeDYtOO6q",
      "expanded_url" : "https:\/\/twitter.com\/manuelcorpas\/status\/847694955380318210",
      "display_url" : "twitter.com\/manuelcorpas\/s\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1714450631445, 8.628066727897965 ]
  },
  "id_str" : "847703205572034560",
  "text" : "Disagree. Environmental and social factors will always limit the predictions. https:\/\/t.co\/rgeDYtOO6q",
  "id" : 847703205572034560,
  "created_at" : "2017-03-31 06:52:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Manuel Corpas",
      "screen_name" : "manuelcorpas",
      "indices" : [ 0, 13 ],
      "id_str" : "111020569",
      "id" : 111020569
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "847692232085782528",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11319735057987, 8.754687433659473 ]
  },
  "id_str" : "847693261770600448",
  "in_reply_to_user_id" : 111020569,
  "text" : "@manuelcorpas define \u201Csoon\u201D :p",
  "id" : 847693261770600448,
  "in_reply_to_status_id" : 847692232085782528,
  "created_at" : "2017-03-31 06:13:17 +0000",
  "in_reply_to_screen_name" : "manuelcorpas",
  "in_reply_to_user_id_str" : "111020569",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Edmunds",
      "screen_name" : "SCEdmunds",
      "indices" : [ 0, 10 ],
      "id_str" : "176024190",
      "id" : 176024190
    }, {
      "name" : "Sequencing.com",
      "screen_name" : "SequencingCom",
      "indices" : [ 11, 25 ],
      "id_str" : "2377808329",
      "id" : 2377808329
    }, {
      "name" : "Repositive.io",
      "screen_name" : "repositiveio",
      "indices" : [ 26, 39 ],
      "id_str" : "3059929578",
      "id" : 3059929578
    }, {
      "name" : "Opendata.ch",
      "screen_name" : "OpendataCH",
      "indices" : [ 100, 111 ],
      "id_str" : "362585949",
      "id" : 362585949
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "847610069797617665",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11323187062898, 8.754243901682848 ]
  },
  "id_str" : "847693121861197824",
  "in_reply_to_user_id" : 176024190,
  "text" : "@SCEdmunds @SequencingCom @repositiveio we did something with the openSNP data two years ago at the @OpendataCH hackathon. :)",
  "id" : 847693121861197824,
  "in_reply_to_status_id" : 847610069797617665,
  "created_at" : "2017-03-31 06:12:44 +0000",
  "in_reply_to_screen_name" : "SCEdmunds",
  "in_reply_to_user_id_str" : "176024190",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "C\u24D0meronNeylon",
      "screen_name" : "CameronNeylon",
      "indices" : [ 3, 17 ],
      "id_str" : "12984852",
      "id" : 12984852
    }, {
      "name" : "Force11.org",
      "screen_name" : "force11rescomm",
      "indices" : [ 85, 100 ],
      "id_str" : "720754110",
      "id" : 720754110
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "847692653902741504",
  "text" : "RT @CameronNeylon: I am getting really quite excited about the courses to be offered @force11rescomm Schol Comms Institute. Reg opens in ar\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Force11.org",
        "screen_name" : "force11rescomm",
        "indices" : [ 66, 81 ],
        "id_str" : "720754110",
        "id" : 720754110
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "fsci",
        "indices" : [ 132, 137 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "847520103159803905",
    "text" : "I am getting really quite excited about the courses to be offered @force11rescomm Schol Comms Institute. Reg opens in around a week #fsci",
    "id" : 847520103159803905,
    "created_at" : "2017-03-30 18:45:13 +0000",
    "user" : {
      "name" : "C\u24D0meronNeylon",
      "screen_name" : "CameronNeylon",
      "protected" : false,
      "id_str" : "12984852",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1766127492\/image1326973990_normal.png",
      "id" : 12984852,
      "verified" : false
    }
  },
  "id" : 847692653902741504,
  "created_at" : "2017-03-31 06:10:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bruno Vieira",
      "screen_name" : "bmpvieira",
      "indices" : [ 0, 10 ],
      "id_str" : "55388565",
      "id" : 55388565
    }, {
      "name" : "Tim Head",
      "screen_name" : "betatim",
      "indices" : [ 11, 19 ],
      "id_str" : "18881614",
      "id" : 18881614
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "847541472866054144",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11391141457167, 8.753184043633961 ]
  },
  "id_str" : "847541928585551872",
  "in_reply_to_user_id" : 55388565,
  "text" : "@bmpvieira @betatim me too!",
  "id" : 847541928585551872,
  "in_reply_to_status_id" : 847541472866054144,
  "created_at" : "2017-03-30 20:11:56 +0000",
  "in_reply_to_screen_name" : "bmpvieira",
  "in_reply_to_user_id_str" : "55388565",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Head",
      "screen_name" : "betatim",
      "indices" : [ 0, 8 ],
      "id_str" : "18881614",
      "id" : 18881614
    }, {
      "name" : "Bruno Vieira",
      "screen_name" : "bmpvieira",
      "indices" : [ 9, 19 ],
      "id_str" : "55388565",
      "id" : 55388565
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "847537677276676098",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11406645951556, 8.753435609041453 ]
  },
  "id_str" : "847540216713924609",
  "in_reply_to_user_id" : 18881614,
  "text" : "@betatim @bmpvieira unfortunately not, will leave the last evening of csvconf. :(",
  "id" : 847540216713924609,
  "in_reply_to_status_id" : 847537677276676098,
  "created_at" : "2017-03-30 20:05:08 +0000",
  "in_reply_to_screen_name" : "betatim",
  "in_reply_to_user_id_str" : "18881614",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bruno Vieira",
      "screen_name" : "bmpvieira",
      "indices" : [ 111, 121 ],
      "id_str" : "55388565",
      "id" : 55388565
    }, {
      "name" : "Tim Head",
      "screen_name" : "betatim",
      "indices" : [ 122, 130 ],
      "id_str" : "18881614",
      "id" : 18881614
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "csvconf",
      "indices" : [ 101, 109 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11406644187531, 8.753435691043316 ]
  },
  "id_str" : "847535975760842752",
  "text" : "My April\/May travel plans just got a bit longer. FRA \u2708\uFE0F SEA \u2708\uFE0F YYZ \u2708\uFE0F PDX \u2708\uFE0F FRA. Who asked me about #csvconf? @bmpvieira @betatim?",
  "id" : 847535975760842752,
  "created_at" : "2017-03-30 19:48:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/MkUs0PL1HR",
      "expanded_url" : "http:\/\/m.dw.com\/en\/gaza-surf-club-how-young-palestinians-find-a-break-in-times-of-war\/a-38169967",
      "display_url" : "m.dw.com\/en\/gaza-surf-c\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11296085086661, 8.743526721381343 ]
  },
  "id_str" : "847531122129084416",
  "text" : "Saw Surf Club Gaza on the opening night here and it\u2019s as great as it sounds. \uD83C\uDFC4\uD83C\uDFAC https:\/\/t.co\/MkUs0PL1HR",
  "id" : 847531122129084416,
  "created_at" : "2017-03-30 19:29:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 4, 27 ],
      "url" : "https:\/\/t.co\/cJIZa9ixZS",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BSRSRsDjgj6\/",
      "display_url" : "instagram.com\/p\/BSRSRsDjgj6\/"
    } ]
  },
  "geo" : { },
  "id_str" : "847495679765127168",
  "text" : "\uD83D\uDEF6\u2693\uFE0F https:\/\/t.co\/cJIZa9ixZS",
  "id" : 847495679765127168,
  "created_at" : "2017-03-30 17:08:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Head",
      "screen_name" : "betatim",
      "indices" : [ 0, 8 ],
      "id_str" : "18881614",
      "id" : 18881614
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "847465334546219008",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17236823674046, 8.62750905299285 ]
  },
  "id_str" : "847465467153219586",
  "in_reply_to_user_id" : 18881614,
  "text" : "@betatim I just had some mid-work ice cream, so I\u2019m finally a bit less grumpy! \uD83C\uDF66",
  "id" : 847465467153219586,
  "in_reply_to_status_id" : 847465334546219008,
  "created_at" : "2017-03-30 15:08:07 +0000",
  "in_reply_to_screen_name" : "betatim",
  "in_reply_to_user_id_str" : "18881614",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Head",
      "screen_name" : "betatim",
      "indices" : [ 0, 8 ],
      "id_str" : "18881614",
      "id" : 18881614
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "847463712910790656",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17236823674046, 8.62750905299285 ]
  },
  "id_str" : "847464979246796800",
  "in_reply_to_user_id" : 18881614,
  "text" : "@betatim I\u2019m still in Frankfurt unfortunately. Maybe next WE though!",
  "id" : 847464979246796800,
  "in_reply_to_status_id" : 847463712910790656,
  "created_at" : "2017-03-30 15:06:10 +0000",
  "in_reply_to_screen_name" : "betatim",
  "in_reply_to_user_id_str" : "18881614",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ali",
      "screen_name" : "zoonpolitikon",
      "indices" : [ 0, 14 ],
      "id_str" : "13040652",
      "id" : 13040652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "847435805903659008",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17235770101948, 8.627511984965558 ]
  },
  "id_str" : "847437211373056001",
  "in_reply_to_user_id" : 13040652,
  "text" : "@zoonpolitikon waiting for which of the two to fail? :p",
  "id" : 847437211373056001,
  "in_reply_to_status_id" : 847435805903659008,
  "created_at" : "2017-03-30 13:15:50 +0000",
  "in_reply_to_screen_name" : "zoonpolitikon",
  "in_reply_to_user_id_str" : "13040652",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/e4Twa376AP",
      "expanded_url" : "https:\/\/twitter.com\/robertkiley\/status\/847426497195327488",
      "display_url" : "twitter.com\/robertkiley\/st\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17158865933322, 8.628599513330151 ]
  },
  "id_str" : "847434565303926790",
  "text" : "So a whole country leaving the EU is faster than Elsevier can change? https:\/\/t.co\/e4Twa376AP",
  "id" : 847434565303926790,
  "created_at" : "2017-03-30 13:05:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "A. Domingues",
      "screen_name" : "keyboardpipette",
      "indices" : [ 0, 16 ],
      "id_str" : "712172447223717888",
      "id" : 712172447223717888
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "847401371569541121",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17237062170628, 8.62750660405804 ]
  },
  "id_str" : "847425287402930176",
  "in_reply_to_user_id" : 712172447223717888,
  "text" : "@keyboardpipette great, thanks!",
  "id" : 847425287402930176,
  "in_reply_to_status_id" : 847401371569541121,
  "created_at" : "2017-03-30 12:28:27 +0000",
  "in_reply_to_screen_name" : "keyboardpipette",
  "in_reply_to_user_id_str" : "712172447223717888",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "A. Domingues",
      "screen_name" : "keyboardpipette",
      "indices" : [ 0, 16 ],
      "id_str" : "712172447223717888",
      "id" : 712172447223717888
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "847397608834220034",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17238110921763, 8.627515694182316 ]
  },
  "id_str" : "847399352158912517",
  "in_reply_to_user_id" : 712172447223717888,
  "text" : "@keyboardpipette am I link-blind and can\u2019t find any link to the app itself due to it? :D",
  "id" : 847399352158912517,
  "in_reply_to_status_id" : 847397608834220034,
  "created_at" : "2017-03-30 10:45:24 +0000",
  "in_reply_to_screen_name" : "keyboardpipette",
  "in_reply_to_user_id_str" : "712172447223717888",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Madeleine Price Ball",
      "screen_name" : "madprime",
      "indices" : [ 0, 9 ],
      "id_str" : "71557700",
      "id" : 71557700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "847139654524702720",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17236759215399, 8.62752447102804 ]
  },
  "id_str" : "847387714546655233",
  "in_reply_to_user_id" : 71557700,
  "text" : "@madprime Looks good!",
  "id" : 847387714546655233,
  "in_reply_to_status_id" : 847139654524702720,
  "created_at" : "2017-03-30 09:59:09 +0000",
  "in_reply_to_screen_name" : "madprime",
  "in_reply_to_user_id_str" : "71557700",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Madeleine Price Ball",
      "screen_name" : "madprime",
      "indices" : [ 0, 9 ],
      "id_str" : "71557700",
      "id" : 71557700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "847139654524702720",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17234874902216, 8.627529896589827 ]
  },
  "id_str" : "847384656345391105",
  "in_reply_to_user_id" : 71557700,
  "text" : "@madprime Ok, uploaded a fresh 23andMe download. Let\u2019s see how it works :)",
  "id" : 847384656345391105,
  "in_reply_to_status_id" : 847139654524702720,
  "created_at" : "2017-03-30 09:47:00 +0000",
  "in_reply_to_screen_name" : "madprime",
  "in_reply_to_user_id_str" : "71557700",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17235429395612, 8.627532761733988 ]
  },
  "id_str" : "847382109438136320",
  "text" : "\u00ABThe BAR domain is banana shaped and binds to the membrane via it\u2019s concave face.\u00BB Now I\u2019m hungry &amp; want a banana to bind to my face.",
  "id" : 847382109438136320,
  "created_at" : "2017-03-30 09:36:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "3nrique0",
      "screen_name" : "3nrique0",
      "indices" : [ 0, 9 ],
      "id_str" : "211509856",
      "id" : 211509856
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "847380383423373316",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17235429395612, 8.627532761733988 ]
  },
  "id_str" : "847381838528106497",
  "in_reply_to_user_id" : 211509856,
  "text" : "@3nrique0 thanks, we already had evolutionary linguistics presentations in the past. :)",
  "id" : 847381838528106497,
  "in_reply_to_status_id" : 847380383423373316,
  "created_at" : "2017-03-30 09:35:48 +0000",
  "in_reply_to_screen_name" : "3nrique0",
  "in_reply_to_user_id_str" : "211509856",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17235035052759, 8.627540818643162 ]
  },
  "id_str" : "847378567625228289",
  "text" : "Gotta present in our journal club next week. Has anyone a recommendation for a cool preprint to present to evolutionary bioinformaticians?",
  "id" : 847378567625228289,
  "created_at" : "2017-03-30 09:22:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/Ji60rGLWsb",
      "expanded_url" : "http:\/\/www.atlasobscura.com\/articles\/mercator-peters-boston-map",
      "display_url" : "atlasobscura.com\/articles\/merca\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17237174879192, 8.627523245314666 ]
  },
  "id_str" : "847375721840254976",
  "text" : "\u00ABWhat the hell is that?\u00BB \u2013 \u00ABIt\u2019s where you\u2019ve been living this whole time.\u00BB https:\/\/t.co\/Ji60rGLWsb",
  "id" : 847375721840254976,
  "created_at" : "2017-03-30 09:11:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sandy stopped keeping up w\/this platform long ago",
      "screen_name" : "thrimpth",
      "indices" : [ 3, 12 ],
      "id_str" : "75367699",
      "id" : 75367699
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/thrimpth\/status\/846380550952767488\/photo\/1",
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/wTjjQP97ai",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/C77yn-TUwAMr47Q.jpg",
      "id_str" : "846380548545101827",
      "id" : 846380548545101827,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C77yn-TUwAMr47Q.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 357,
        "resize" : "fit",
        "w" : 794
      }, {
        "h" : 357,
        "resize" : "fit",
        "w" : 794
      }, {
        "h" : 306,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 357,
        "resize" : "fit",
        "w" : 794
      } ],
      "display_url" : "pic.twitter.com\/wTjjQP97ai"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 82 ],
      "url" : "https:\/\/t.co\/YCCZFXSyft",
      "expanded_url" : "http:\/\/bit.ly\/2mIBzLR",
      "display_url" : "bit.ly\/2mIBzLR"
    } ]
  },
  "geo" : { },
  "id_str" : "847366606036455425",
  "text" : "RT @thrimpth: \"How to Prep for Grad School if You're Poor\" https:\/\/t.co\/YCCZFXSyft https:\/\/t.co\/wTjjQP97ai",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/thrimpth\/status\/846380550952767488\/photo\/1",
        "indices" : [ 69, 92 ],
        "url" : "https:\/\/t.co\/wTjjQP97ai",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/C77yn-TUwAMr47Q.jpg",
        "id_str" : "846380548545101827",
        "id" : 846380548545101827,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C77yn-TUwAMr47Q.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 357,
          "resize" : "fit",
          "w" : 794
        }, {
          "h" : 357,
          "resize" : "fit",
          "w" : 794
        }, {
          "h" : 306,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 357,
          "resize" : "fit",
          "w" : 794
        } ],
        "display_url" : "pic.twitter.com\/wTjjQP97ai"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 45, 68 ],
        "url" : "https:\/\/t.co\/YCCZFXSyft",
        "expanded_url" : "http:\/\/bit.ly\/2mIBzLR",
        "display_url" : "bit.ly\/2mIBzLR"
      } ]
    },
    "geo" : { },
    "id_str" : "846380550952767488",
    "text" : "\"How to Prep for Grad School if You're Poor\" https:\/\/t.co\/YCCZFXSyft https:\/\/t.co\/wTjjQP97ai",
    "id" : 846380550952767488,
    "created_at" : "2017-03-27 15:17:02 +0000",
    "user" : {
      "name" : "Sandy stopped keeping up w\/this platform long ago",
      "screen_name" : "thrimpth",
      "protected" : false,
      "id_str" : "75367699",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/872145557573304326\/5H3QSE3U_normal.jpg",
      "id" : 75367699,
      "verified" : false
    }
  },
  "id" : 847366606036455425,
  "created_at" : "2017-03-30 08:35:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Skellett",
      "screen_name" : "Gurdur",
      "indices" : [ 3, 10 ],
      "id_str" : "125928028",
      "id" : 125928028
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AmericanOdysseyPt6",
      "indices" : [ 79, 98 ]
    }, {
      "text" : "travel",
      "indices" : [ 100, 107 ]
    }, {
      "text" : "TechatticupMine",
      "indices" : [ 109, 125 ]
    }, {
      "text" : "Nevada",
      "indices" : [ 127, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "847334792957788169",
  "text" : "RT @Gurdur: \"God has an inordinate fondness for beetles.\"\n~ J.B.S. Haldane. \n  #AmericanOdysseyPt6, #travel, #TechatticupMine, #Nevada. htt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Gurdur\/status\/847213308881055744\/photo\/1",
        "indices" : [ 124, 147 ],
        "url" : "https:\/\/t.co\/cCQ3DRWZY4",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/C8Hn385XQAMd1sL.jpg",
        "id_str" : "847213153347911683",
        "id" : 847213153347911683,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C8Hn385XQAMd1sL.jpg",
        "sizes" : [ {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 900,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 2457,
          "resize" : "fit",
          "w" : 3276
        } ],
        "display_url" : "pic.twitter.com\/cCQ3DRWZY4"
      } ],
      "hashtags" : [ {
        "text" : "AmericanOdysseyPt6",
        "indices" : [ 67, 86 ]
      }, {
        "text" : "travel",
        "indices" : [ 88, 95 ]
      }, {
        "text" : "TechatticupMine",
        "indices" : [ 97, 113 ]
      }, {
        "text" : "Nevada",
        "indices" : [ 115, 122 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "847212576358277120",
    "geo" : { },
    "id_str" : "847213308881055744",
    "in_reply_to_user_id" : 125928028,
    "text" : "\"God has an inordinate fondness for beetles.\"\n~ J.B.S. Haldane. \n  #AmericanOdysseyPt6, #travel, #TechatticupMine, #Nevada. https:\/\/t.co\/cCQ3DRWZY4",
    "id" : 847213308881055744,
    "in_reply_to_status_id" : 847212576358277120,
    "created_at" : "2017-03-29 22:26:07 +0000",
    "in_reply_to_screen_name" : "Gurdur",
    "in_reply_to_user_id_str" : "125928028",
    "user" : {
      "name" : "Tim Skellett",
      "screen_name" : "Gurdur",
      "protected" : false,
      "id_str" : "125928028",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/721158367398506496\/c4cchuLu_normal.jpg",
      "id" : 125928028,
      "verified" : false
    }
  },
  "id" : 847334792957788169,
  "created_at" : "2017-03-30 06:28:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Madeleine Price Ball",
      "screen_name" : "madprime",
      "indices" : [ 0, 9 ],
      "id_str" : "71557700",
      "id" : 71557700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "847139654524702720",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11406567556469, 8.753442802567553 ]
  },
  "id_str" : "847140323218374657",
  "in_reply_to_user_id" : 71557700,
  "text" : "@madprime sure. Will have to do that tomorrow when back in the office. My internet here sucks too much.",
  "id" : 847140323218374657,
  "in_reply_to_status_id" : 847139654524702720,
  "created_at" : "2017-03-29 17:36:06 +0000",
  "in_reply_to_screen_name" : "madprime",
  "in_reply_to_user_id_str" : "71557700",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Achintya Rao \u2022 \u0C85\u0C9A\u0CBF\u0C82\u0CA4\u0CCD\u0CAF \u0CB0\u0CBE\u0CB5",
      "screen_name" : "RaoOfPhysics",
      "indices" : [ 0, 13 ],
      "id_str" : "67529128",
      "id" : 67529128
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "847092841696382976",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17237509604817, 8.62749038283472 ]
  },
  "id_str" : "847093259839131648",
  "in_reply_to_user_id" : 67529128,
  "text" : "@RaoOfPhysics you, sliding around like the cool kid you are!",
  "id" : 847093259839131648,
  "in_reply_to_status_id" : 847092841696382976,
  "created_at" : "2017-03-29 14:29:06 +0000",
  "in_reply_to_screen_name" : "RaoOfPhysics",
  "in_reply_to_user_id_str" : "67529128",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Achintya Rao \u2022 \u0C85\u0C9A\u0CBF\u0C82\u0CA4\u0CCD\u0CAF \u0CB0\u0CBE\u0CB5",
      "screen_name" : "RaoOfPhysics",
      "indices" : [ 0, 13 ],
      "id_str" : "67529128",
      "id" : 67529128
    }, {
      "name" : "CERN",
      "screen_name" : "CERN",
      "indices" : [ 14, 19 ],
      "id_str" : "15234407",
      "id" : 15234407
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "847084995256684544",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17238976665212, 8.627485506413406 ]
  },
  "id_str" : "847090175515734017",
  "in_reply_to_user_id" : 67529128,
  "text" : "@RaoOfPhysics @CERN that was far easier than expected :P",
  "id" : 847090175515734017,
  "in_reply_to_status_id" : 847084995256684544,
  "created_at" : "2017-03-29 14:16:50 +0000",
  "in_reply_to_screen_name" : "RaoOfPhysics",
  "in_reply_to_user_id_str" : "67529128",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thorbjorg Agustsdott",
      "screen_name" : "fencingtobba",
      "indices" : [ 3, 16 ],
      "id_str" : "2556081796",
      "id" : 2556081796
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Hekla",
      "indices" : [ 18, 24 ]
    }, {
      "text" : "volcano",
      "indices" : [ 25, 33 ]
    }, {
      "text" : "Iceland",
      "indices" : [ 34, 42 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "847086878947987456",
  "text" : "RT @fencingtobba: #Hekla #volcano #Iceland erupted on this day 70 years ago! An eruption that changed the volcano's behaviour.\nhttps:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Hekla",
        "indices" : [ 0, 6 ]
      }, {
        "text" : "volcano",
        "indices" : [ 7, 15 ]
      }, {
        "text" : "Iceland",
        "indices" : [ 16, 24 ]
      } ],
      "urls" : [ {
        "indices" : [ 109, 132 ],
        "url" : "https:\/\/t.co\/fC1InARydv",
        "expanded_url" : "https:\/\/www.youtube.com\/watch?v=oD8c_BN99QE",
        "display_url" : "youtube.com\/watch?v=oD8c_B\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "847017018410881024",
    "text" : "#Hekla #volcano #Iceland erupted on this day 70 years ago! An eruption that changed the volcano's behaviour.\nhttps:\/\/t.co\/fC1InARydv",
    "id" : 847017018410881024,
    "created_at" : "2017-03-29 09:26:08 +0000",
    "user" : {
      "name" : "Thorbjorg Agustsdott",
      "screen_name" : "fencingtobba",
      "protected" : false,
      "id_str" : "2556081796",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/469590898737938432\/OkEMueQ1_normal.jpeg",
      "id" : 2556081796,
      "verified" : false
    }
  },
  "id" : 847086878947987456,
  "created_at" : "2017-03-29 14:03:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Madeleine Price Ball",
      "screen_name" : "madprime",
      "indices" : [ 0, 9 ],
      "id_str" : "71557700",
      "id" : 71557700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 71 ],
      "url" : "https:\/\/t.co\/LASAF9GvQn",
      "expanded_url" : "https:\/\/twitter.com\/tomstafford\/status\/677842156074176512",
      "display_url" : "twitter.com\/tomstafford\/st\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "847077137265971200",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17234277806061, 8.627522304800994 ]
  },
  "id_str" : "847077503239946241",
  "in_reply_to_user_id" : 71557700,
  "text" : "@madprime hence my email signature, copied from https:\/\/t.co\/LASAF9GvQn",
  "id" : 847077503239946241,
  "in_reply_to_status_id" : 847077137265971200,
  "created_at" : "2017-03-29 13:26:29 +0000",
  "in_reply_to_screen_name" : "madprime",
  "in_reply_to_user_id_str" : "71557700",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Madeleine Price Ball",
      "screen_name" : "madprime",
      "indices" : [ 0, 9 ],
      "id_str" : "71557700",
      "id" : 71557700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "847076211406843909",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17234277806061, 8.627522304800994 ]
  },
  "id_str" : "847076429217103875",
  "in_reply_to_user_id" : 71557700,
  "text" : "@madprime thanks, seems it produced a report for now that\u2019s a bit more interesting with the VCF",
  "id" : 847076429217103875,
  "in_reply_to_status_id" : 847076211406843909,
  "created_at" : "2017-03-29 13:22:13 +0000",
  "in_reply_to_screen_name" : "madprime",
  "in_reply_to_user_id_str" : "71557700",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Madeleine Price Ball",
      "screen_name" : "madprime",
      "indices" : [ 0, 9 ],
      "id_str" : "71557700",
      "id" : 71557700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "847076001872068608",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17234277806061, 8.627522304800994 ]
  },
  "id_str" : "847076209666281472",
  "in_reply_to_user_id" : 71557700,
  "text" : "@madprime I was actually wondering about your sleep cycle given my local time! \uD83D\uDE02 And thanks, all the best for your meeting!",
  "id" : 847076209666281472,
  "in_reply_to_status_id" : 847076001872068608,
  "created_at" : "2017-03-29 13:21:20 +0000",
  "in_reply_to_screen_name" : "madprime",
  "in_reply_to_user_id_str" : "71557700",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Madeleine Price Ball",
      "screen_name" : "madprime",
      "indices" : [ 0, 9 ],
      "id_str" : "71557700",
      "id" : 71557700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "847012323067858945",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17238185689377, 8.627517610940444 ]
  },
  "id_str" : "847068924697083904",
  "in_reply_to_user_id" : 71557700,
  "text" : "@madprime pressed the button, let\u2019s see what happens. Also made my exome public now",
  "id" : 847068924697083904,
  "in_reply_to_status_id" : 847012323067858945,
  "created_at" : "2017-03-29 12:52:24 +0000",
  "in_reply_to_screen_name" : "madprime",
  "in_reply_to_user_id_str" : "71557700",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "annakrystalli",
      "screen_name" : "annakrystalli",
      "indices" : [ 0, 14 ],
      "id_str" : "15090415",
      "id" : 15090415
    }, {
      "name" : "Tim Head",
      "screen_name" : "betatim",
      "indices" : [ 15, 23 ],
      "id_str" : "18881614",
      "id" : 18881614
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "847038120298266624",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17235603497343, 8.627508458724693 ]
  },
  "id_str" : "847039931801309184",
  "in_reply_to_user_id" : 15090415,
  "text" : "@annakrystalli @betatim you\u2019re both always welcome to crash here.",
  "id" : 847039931801309184,
  "in_reply_to_status_id" : 847038120298266624,
  "created_at" : "2017-03-29 10:57:11 +0000",
  "in_reply_to_screen_name" : "annakrystalli",
  "in_reply_to_user_id_str" : "15090415",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "annakrystalli",
      "screen_name" : "annakrystalli",
      "indices" : [ 0, 14 ],
      "id_str" : "15090415",
      "id" : 15090415
    }, {
      "name" : "Tim Head",
      "screen_name" : "betatim",
      "indices" : [ 15, 23 ],
      "id_str" : "18881614",
      "id" : 18881614
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/847037709914968064\/photo\/1",
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/Eh43yVxdx8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/C8FITRZXwAAuH9y.jpg",
      "id_str" : "847037700846895104",
      "id" : 847037700846895104,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C8FITRZXwAAuH9y.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/Eh43yVxdx8"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "847037388404785152",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17235271781288, 8.62751839605436 ]
  },
  "id_str" : "847037709914968064",
  "in_reply_to_user_id" : 15090415,
  "text" : "@annakrystalli @betatim doing fine here, but all the best over there. https:\/\/t.co\/Eh43yVxdx8",
  "id" : 847037709914968064,
  "in_reply_to_status_id" : 847037388404785152,
  "created_at" : "2017-03-29 10:48:21 +0000",
  "in_reply_to_screen_name" : "annakrystalli",
  "in_reply_to_user_id_str" : "15090415",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Head",
      "screen_name" : "betatim",
      "indices" : [ 0, 8 ],
      "id_str" : "18881614",
      "id" : 18881614
    }, {
      "name" : "annakrystalli",
      "screen_name" : "annakrystalli",
      "indices" : [ 9, 23 ],
      "id_str" : "15090415",
      "id" : 15090415
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "847036488613285888",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17230153187292, 8.627509519165853 ]
  },
  "id_str" : "847036904533102592",
  "in_reply_to_user_id" : 18881614,
  "text" : "@betatim @annakrystalli \uD83D\uDE0D",
  "id" : 847036904533102592,
  "in_reply_to_status_id" : 847036488613285888,
  "created_at" : "2017-03-29 10:45:09 +0000",
  "in_reply_to_screen_name" : "betatim",
  "in_reply_to_user_id_str" : "18881614",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Madeleine Price Ball",
      "screen_name" : "madprime",
      "indices" : [ 0, 9 ],
      "id_str" : "71557700",
      "id" : 71557700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "847012323067858945",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17230153187292, 8.627509519165853 ]
  },
  "id_str" : "847036746403598336",
  "in_reply_to_user_id" : 71557700,
  "text" : "@madprime still stuck in a long meeting. Will do after that.",
  "id" : 847036746403598336,
  "in_reply_to_status_id" : 847012323067858945,
  "created_at" : "2017-03-29 10:44:32 +0000",
  "in_reply_to_screen_name" : "madprime",
  "in_reply_to_user_id_str" : "71557700",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Madeleine Price Ball",
      "screen_name" : "madprime",
      "indices" : [ 0, 9 ],
      "id_str" : "71557700",
      "id" : 71557700
    }, {
      "name" : "beau",
      "screen_name" : "beaugunderson",
      "indices" : [ 10, 24 ],
      "id_str" : "5746882",
      "id" : 5746882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "847010535145181186",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17234383543888, 8.627514728241577 ]
  },
  "id_str" : "847010896299917312",
  "in_reply_to_user_id" : 71557700,
  "text" : "@madprime @beaugunderson yeah, I know my genome is boring, but that boring? :D",
  "id" : 847010896299917312,
  "in_reply_to_status_id" : 847010535145181186,
  "created_at" : "2017-03-29 09:01:49 +0000",
  "in_reply_to_screen_name" : "madprime",
  "in_reply_to_user_id_str" : "71557700",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Madeleine Price Ball",
      "screen_name" : "madprime",
      "indices" : [ 0, 9 ],
      "id_str" : "71557700",
      "id" : 71557700
    }, {
      "name" : "beau",
      "screen_name" : "beaugunderson",
      "indices" : [ 10, 24 ],
      "id_str" : "5746882",
      "id" : 5746882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "847010104939565056",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17224891720999, 8.627511967981727 ]
  },
  "id_str" : "847010410683383808",
  "in_reply_to_user_id" : 71557700,
  "text" : "@madprime @beaugunderson guess the exome just needs some time for processing?",
  "id" : 847010410683383808,
  "in_reply_to_status_id" : 847010104939565056,
  "created_at" : "2017-03-29 08:59:53 +0000",
  "in_reply_to_screen_name" : "madprime",
  "in_reply_to_user_id_str" : "71557700",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Madeleine Price Ball",
      "screen_name" : "madprime",
      "indices" : [ 0, 9 ],
      "id_str" : "71557700",
      "id" : 71557700
    }, {
      "name" : "beau",
      "screen_name" : "beaugunderson",
      "indices" : [ 10, 24 ],
      "id_str" : "5746882",
      "id" : 5746882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "847009921187139584",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17231254303016, 8.627536806880814 ]
  },
  "id_str" : "847010012744617984",
  "in_reply_to_user_id" : 71557700,
  "text" : "@madprime @beaugunderson nope, managed that just fine. My report is already there :)",
  "id" : 847010012744617984,
  "in_reply_to_status_id" : 847009921187139584,
  "created_at" : "2017-03-29 08:58:18 +0000",
  "in_reply_to_screen_name" : "madprime",
  "in_reply_to_user_id_str" : "71557700",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Madeleine Price Ball",
      "screen_name" : "madprime",
      "indices" : [ 0, 9 ],
      "id_str" : "71557700",
      "id" : 71557700
    }, {
      "name" : "beau",
      "screen_name" : "beaugunderson",
      "indices" : [ 10, 24 ],
      "id_str" : "5746882",
      "id" : 5746882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "847008627785453569",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17231254303016, 8.627536806880814 ]
  },
  "id_str" : "847008934976212993",
  "in_reply_to_user_id" : 71557700,
  "text" : "@madprime @beaugunderson that\u2019s nice. Just uploaded my 23andMe &amp; exome to openhumans and will have a look later!",
  "id" : 847008934976212993,
  "in_reply_to_status_id" : 847008627785453569,
  "created_at" : "2017-03-29 08:54:01 +0000",
  "in_reply_to_screen_name" : "madprime",
  "in_reply_to_user_id_str" : "71557700",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Madeleine Price Ball",
      "screen_name" : "madprime",
      "indices" : [ 0, 9 ],
      "id_str" : "71557700",
      "id" : 71557700
    }, {
      "name" : "beau",
      "screen_name" : "beaugunderson",
      "indices" : [ 10, 24 ],
      "id_str" : "5746882",
      "id" : 5746882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "847006554259894272",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17238613555179, 8.627502687105343 ]
  },
  "id_str" : "847006834070372356",
  "in_reply_to_user_id" : 71557700,
  "text" : "@madprime @beaugunderson I\u2019d love to!",
  "id" : 847006834070372356,
  "in_reply_to_status_id" : 847006554259894272,
  "created_at" : "2017-03-29 08:45:40 +0000",
  "in_reply_to_screen_name" : "madprime",
  "in_reply_to_user_id_str" : "71557700",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Frau Fragmente",
      "screen_name" : "fragmente",
      "indices" : [ 0, 10 ],
      "id_str" : "7207642",
      "id" : 7207642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "846828981580107776",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11406548048364, 8.753435609943745 ]
  },
  "id_str" : "846852423121555461",
  "in_reply_to_user_id" : 7207642,
  "text" : "@fragmente Ich parke normalerweise nicht am Flughafen, aber wenn ich in dem Gang stehe hab ich mich verlaufen auf dem Weg zur Bahn.",
  "id" : 846852423121555461,
  "in_reply_to_status_id" : 846828981580107776,
  "created_at" : "2017-03-28 22:32:06 +0000",
  "in_reply_to_screen_name" : "fragmente",
  "in_reply_to_user_id_str" : "7207642",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Frau Fragmente",
      "screen_name" : "fragmente",
      "indices" : [ 0, 10 ],
      "id_str" : "7207642",
      "id" : 7207642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "846818935479713793",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11406542515438, 8.75343543837099 ]
  },
  "id_str" : "846825632478740482",
  "in_reply_to_user_id" : 7207642,
  "text" : "@fragmente der Abschnitt im FRA in dem ich bis heute verloren gehe.",
  "id" : 846825632478740482,
  "in_reply_to_status_id" : 846818935479713793,
  "created_at" : "2017-03-28 20:45:38 +0000",
  "in_reply_to_screen_name" : "fragmente",
  "in_reply_to_user_id_str" : "7207642",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bob O'Hara",
      "screen_name" : "BobOHara",
      "indices" : [ 3, 12 ],
      "id_str" : "19146944",
      "id" : 19146944
    }, {
      "name" : "SENCKENBERG",
      "screen_name" : "Senckenberg",
      "indices" : [ 26, 38 ],
      "id_str" : "85120200",
      "id" : 85120200
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/YStiMj359F",
      "expanded_url" : "https:\/\/twitter.com\/hormiga\/status\/846811346939260928",
      "display_url" : "twitter.com\/hormiga\/status\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "846823878966087682",
  "text" : "RT @BobOHara: Shit.\n\nHey, @Senckenberg, you're making more space aren't you? https:\/\/t.co\/YStiMj359F",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "SENCKENBERG",
        "screen_name" : "Senckenberg",
        "indices" : [ 12, 24 ],
        "id_str" : "85120200",
        "id" : 85120200
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 63, 86 ],
        "url" : "https:\/\/t.co\/YStiMj359F",
        "expanded_url" : "https:\/\/twitter.com\/hormiga\/status\/846811346939260928",
        "display_url" : "twitter.com\/hormiga\/status\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "846815677684072448",
    "text" : "Shit.\n\nHey, @Senckenberg, you're making more space aren't you? https:\/\/t.co\/YStiMj359F",
    "id" : 846815677684072448,
    "created_at" : "2017-03-28 20:06:05 +0000",
    "user" : {
      "name" : "Bob O'Hara",
      "screen_name" : "BobOHara",
      "protected" : false,
      "id_str" : "19146944",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/624292977\/twitterProfilePhoto_normal.jpg",
      "id" : 19146944,
      "verified" : false
    }
  },
  "id" : 846823878966087682,
  "created_at" : "2017-03-28 20:38:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 3, 12 ],
      "id_str" : "14245811",
      "id" : 14245811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "846816287695290368",
  "text" : "RT @wilbanks: Save me from people who think biology is simple as software. We're all going to die. Every one of us. And that\u2019s ok.\nhttps:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/e834uCFo2N",
        "expanded_url" : "http:\/\/www.newyorker.com\/magazine\/2017\/04\/03\/silicon-valleys-quest-to-live-forever",
        "display_url" : "newyorker.com\/magazine\/2017\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "846351994851921920",
    "text" : "Save me from people who think biology is simple as software. We're all going to die. Every one of us. And that\u2019s ok.\nhttps:\/\/t.co\/e834uCFo2N",
    "id" : 846351994851921920,
    "created_at" : "2017-03-27 13:23:34 +0000",
    "user" : {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "protected" : false,
      "id_str" : "14245811",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/925696899566440448\/BUTdp410_normal.jpg",
      "id" : 14245811,
      "verified" : false
    }
  },
  "id" : 846816287695290368,
  "created_at" : "2017-03-28 20:08:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "A. Domingues",
      "screen_name" : "keyboardpipette",
      "indices" : [ 0, 16 ],
      "id_str" : "712172447223717888",
      "id" : 712172447223717888
    }, {
      "name" : "Alan Rice",
      "screen_name" : "alanmrice",
      "indices" : [ 17, 27 ],
      "id_str" : "6872082",
      "id" : 6872082
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "846798464071675905",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11406512869392, 8.75343638513145 ]
  },
  "id_str" : "846801121679196161",
  "in_reply_to_user_id" : 712172447223717888,
  "text" : "@keyboardpipette @alanmrice I had never heard about it before, so I\u2019m glad I learnt something today :)",
  "id" : 846801121679196161,
  "in_reply_to_status_id" : 846798464071675905,
  "created_at" : "2017-03-28 19:08:14 +0000",
  "in_reply_to_screen_name" : "keyboardpipette",
  "in_reply_to_user_id_str" : "712172447223717888",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "A. Domingues",
      "screen_name" : "keyboardpipette",
      "indices" : [ 0, 16 ],
      "id_str" : "712172447223717888",
      "id" : 712172447223717888
    }, {
      "name" : "Alan Rice",
      "screen_name" : "alanmrice",
      "indices" : [ 65, 75 ],
      "id_str" : "6872082",
      "id" : 6872082
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 40 ],
      "url" : "https:\/\/t.co\/bzk9OZIr7w",
      "expanded_url" : "http:\/\/colororacle.org\/",
      "display_url" : "colororacle.org"
    }, {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/glPElwF0db",
      "expanded_url" : "http:\/\/colorbrewer2.org",
      "display_url" : "colorbrewer2.org"
    } ]
  },
  "in_reply_to_status_id_str" : "846785078881632258",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11406555837279, 8.75343545853897 ]
  },
  "id_str" : "846785341671571456",
  "in_reply_to_user_id" : 712172447223717888,
  "text" : "@keyboardpipette https:\/\/t.co\/bzk9OZIr7w was just recommended by @alanmrice and I like https:\/\/t.co\/glPElwF0db",
  "id" : 846785341671571456,
  "in_reply_to_status_id" : 846785078881632258,
  "created_at" : "2017-03-28 18:05:32 +0000",
  "in_reply_to_screen_name" : "keyboardpipette",
  "in_reply_to_user_id_str" : "712172447223717888",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mathilde Cordellier",
      "screen_name" : "m_cordellier",
      "indices" : [ 0, 13 ],
      "id_str" : "3373710875",
      "id" : 3373710875
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "846750343526539264",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11405415393487, 8.753045689147859 ]
  },
  "id_str" : "846761325497909251",
  "in_reply_to_user_id" : 3373710875,
  "text" : "@m_cordellier I meant lobbying for it at the Uni level. Because also applies for seminars, talks etc.",
  "id" : 846761325497909251,
  "in_reply_to_status_id" : 846750343526539264,
  "created_at" : "2017-03-28 16:30:06 +0000",
  "in_reply_to_screen_name" : "m_cordellier",
  "in_reply_to_user_id_str" : "3373710875",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan CoopEUr",
      "screen_name" : "danielwcooper",
      "indices" : [ 3, 17 ],
      "id_str" : "176412453",
      "id" : 176412453
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "846761034266357762",
  "text" : "RT @danielwcooper: The juxtaposition of these two makes me think that alt-J is just a Jamiroquai covers band for racists. https:\/\/t.co\/bybI\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/danielwcooper\/status\/838667737002094592\/photo\/1",
        "indices" : [ 103, 126 ],
        "url" : "https:\/\/t.co\/bybIXfFCEB",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/C6OLxq2WgAAZtL7.jpg",
        "id_str" : "838667641053151232",
        "id" : 838667641053151232,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C6OLxq2WgAAZtL7.jpg",
        "sizes" : [ {
          "h" : 248,
          "resize" : "fit",
          "w" : 503
        }, {
          "h" : 248,
          "resize" : "fit",
          "w" : 503
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 248,
          "resize" : "fit",
          "w" : 503
        }, {
          "h" : 248,
          "resize" : "fit",
          "w" : 503
        } ],
        "display_url" : "pic.twitter.com\/bybIXfFCEB"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "838667737002094592",
    "text" : "The juxtaposition of these two makes me think that alt-J is just a Jamiroquai covers band for racists. https:\/\/t.co\/bybIXfFCEB",
    "id" : 838667737002094592,
    "created_at" : "2017-03-06 08:29:04 +0000",
    "user" : {
      "name" : "Dan CoopEUr",
      "screen_name" : "danielwcooper",
      "protected" : false,
      "id_str" : "176412453",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/744904659089887232\/7cRCz-OE_normal.jpg",
      "id" : 176412453,
      "verified" : true
    }
  },
  "id" : 846761034266357762,
  "created_at" : "2017-03-28 16:28:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mathilde Cordellier",
      "screen_name" : "m_cordellier",
      "indices" : [ 0, 13 ],
      "id_str" : "3373710875",
      "id" : 3373710875
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "846749132060606464",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17730297411429, 8.629152662477683 ]
  },
  "id_str" : "846749995915206657",
  "in_reply_to_user_id" : 3373710875,
  "text" : "@m_cordellier trying to raise awareness here but to no avail\u2026",
  "id" : 846749995915206657,
  "in_reply_to_status_id" : 846749132060606464,
  "created_at" : "2017-03-28 15:45:05 +0000",
  "in_reply_to_screen_name" : "m_cordellier",
  "in_reply_to_user_id_str" : "3373710875",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Montgomery",
      "screen_name" : "dhmontgomery",
      "indices" : [ 0, 13 ],
      "id_str" : "194351775",
      "id" : 194351775
    }, {
      "name" : "WeRateDogs\u2122",
      "screen_name" : "dog_rates",
      "indices" : [ 14, 24 ],
      "id_str" : "4196983835",
      "id" : 4196983835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/T2JvdxcBkZ",
      "expanded_url" : "http:\/\/ruleofthirds.de\/they-are-good-dogs-indeed\/",
      "display_url" : "ruleofthirds.de\/they-are-good-\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "846725492636090369",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723552625548, 8.627520108700512 ]
  },
  "id_str" : "846732878276956160",
  "in_reply_to_user_id" : 194351775,
  "text" : "@dhmontgomery @dog_rates awesome, had the same idea some while ago! \uD83D\uDE02 https:\/\/t.co\/T2JvdxcBkZ",
  "id" : 846732878276956160,
  "in_reply_to_status_id" : 846725492636090369,
  "created_at" : "2017-03-28 14:37:04 +0000",
  "in_reply_to_screen_name" : "dhmontgomery",
  "in_reply_to_user_id_str" : "194351775",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/4QQWuiuysx",
      "expanded_url" : "http:\/\/www.atlasobscura.com\/articles\/us-passport-history-women",
      "display_url" : "atlasobscura.com\/articles\/us-pa\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17238258724045, 8.627507805519114 ]
  },
  "id_str" : "846721333039960064",
  "text" : "The 1920s Women Who Fought For the Right to Travel Under Their Own Names https:\/\/t.co\/4QQWuiuysx",
  "id" : 846721333039960064,
  "created_at" : "2017-03-28 13:51:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17235444083074, 8.627527234161173 ]
  },
  "id_str" : "846708572029419520",
  "text" : "I wish one day all publishers would put \u201Eneeds to be safe for people who\u2019re color blind\u201C in their figure guidelines\u2026",
  "id" : 846708572029419520,
  "created_at" : "2017-03-28 13:00:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Faith Choyce",
      "screen_name" : "faithchoyce",
      "indices" : [ 3, 15 ],
      "id_str" : "14659092",
      "id" : 14659092
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/faithchoyce\/status\/846115630944141312\/photo\/1",
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/s3a1yis9dK",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/C74Brd2VYAI7Q1Z.jpg",
      "id_str" : "846115626250756098",
      "id" : 846115626250756098,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C74Brd2VYAI7Q1Z.jpg",
      "sizes" : [ {
        "h" : 484,
        "resize" : "fit",
        "w" : 750
      }, {
        "h" : 484,
        "resize" : "fit",
        "w" : 750
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 484,
        "resize" : "fit",
        "w" : 750
      }, {
        "h" : 439,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/s3a1yis9dK"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "846655924462870528",
  "text" : "RT @faithchoyce: Yes, Aaron Sorkin. That is literally exactly what we are saying. https:\/\/t.co\/s3a1yis9dK",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/faithchoyce\/status\/846115630944141312\/photo\/1",
        "indices" : [ 65, 88 ],
        "url" : "https:\/\/t.co\/s3a1yis9dK",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/C74Brd2VYAI7Q1Z.jpg",
        "id_str" : "846115626250756098",
        "id" : 846115626250756098,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C74Brd2VYAI7Q1Z.jpg",
        "sizes" : [ {
          "h" : 484,
          "resize" : "fit",
          "w" : 750
        }, {
          "h" : 484,
          "resize" : "fit",
          "w" : 750
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 484,
          "resize" : "fit",
          "w" : 750
        }, {
          "h" : 439,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/s3a1yis9dK"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "846115630944141312",
    "text" : "Yes, Aaron Sorkin. That is literally exactly what we are saying. https:\/\/t.co\/s3a1yis9dK",
    "id" : 846115630944141312,
    "created_at" : "2017-03-26 21:44:21 +0000",
    "user" : {
      "name" : "Faith Choyce",
      "screen_name" : "faithchoyce",
      "protected" : false,
      "id_str" : "14659092",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/924117216911532033\/w97BnXF2_normal.jpg",
      "id" : 14659092,
      "verified" : false
    }
  },
  "id" : 846655924462870528,
  "created_at" : "2017-03-28 09:31:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "April H.",
      "screen_name" : "AprilHathcock",
      "indices" : [ 0, 14 ],
      "id_str" : "3209949862",
      "id" : 3209949862
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "846498584291954692",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11406548524367, 8.753435494974777 ]
  },
  "id_str" : "846503041104859136",
  "in_reply_to_user_id" : 3209949862,
  "text" : "@AprilHathcock \uD83D\uDC96 for all of these!",
  "id" : 846503041104859136,
  "in_reply_to_status_id" : 846498584291954692,
  "created_at" : "2017-03-27 23:23:46 +0000",
  "in_reply_to_screen_name" : "AprilHathcock",
  "in_reply_to_user_id_str" : "3209949862",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/jYsLg8aYwY",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/846287116267110400",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "846287116267110400",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11406559627161, 8.753435148464746 ]
  },
  "id_str" : "846472389768695808",
  "in_reply_to_user_id" : 14286491,
  "text" : "Reached out about that one: Bone marrow and skin are amongst the things they had in mind. https:\/\/t.co\/jYsLg8aYwY",
  "id" : 846472389768695808,
  "in_reply_to_status_id" : 846287116267110400,
  "created_at" : "2017-03-27 21:21:59 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 68 ],
      "url" : "https:\/\/t.co\/FIGTgIdD57",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BSJrYJBjSVl\/",
      "display_url" : "instagram.com\/p\/BSJrYJBjSVl\/"
    } ]
  },
  "geo" : { },
  "id_str" : "846424974831357953",
  "text" : "Stopping for a quick jam before the sun sets https:\/\/t.co\/FIGTgIdD57",
  "id" : 846424974831357953,
  "created_at" : "2017-03-27 18:13:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Parker Molloy",
      "screen_name" : "ParkerMolloy",
      "indices" : [ 3, 16 ],
      "id_str" : "634734888",
      "id" : 634734888
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/ParkerMolloy\/status\/846402581400354816\/photo\/1",
      "indices" : [ 56, 79 ],
      "url" : "https:\/\/t.co\/fYNZBZSY6X",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/C78GfGcWsAAp-mU.jpg",
      "id_str" : "846402386344194048",
      "id" : 846402386344194048,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C78GfGcWsAAp-mU.jpg",
      "sizes" : [ {
        "h" : 593,
        "resize" : "fit",
        "w" : 677
      }, {
        "h" : 593,
        "resize" : "fit",
        "w" : 677
      }, {
        "h" : 593,
        "resize" : "fit",
        "w" : 677
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 593,
        "resize" : "fit",
        "w" : 677
      } ],
      "display_url" : "pic.twitter.com\/fYNZBZSY6X"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 55 ],
      "url" : "https:\/\/t.co\/z87BCj6BJO",
      "expanded_url" : "http:\/\/www.washingtontimes.com\/news\/2017\/mar\/27\/johnny-rotten-defends-donald-trump-slams-left-wing\/",
      "display_url" : "washingtontimes.com\/news\/2017\/mar\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "846422903348449280",
  "text" : "RT @ParkerMolloy: Punk is dead. https:\/\/t.co\/z87BCj6BJO https:\/\/t.co\/fYNZBZSY6X",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ParkerMolloy\/status\/846402581400354816\/photo\/1",
        "indices" : [ 38, 61 ],
        "url" : "https:\/\/t.co\/fYNZBZSY6X",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/C78GfGcWsAAp-mU.jpg",
        "id_str" : "846402386344194048",
        "id" : 846402386344194048,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C78GfGcWsAAp-mU.jpg",
        "sizes" : [ {
          "h" : 593,
          "resize" : "fit",
          "w" : 677
        }, {
          "h" : 593,
          "resize" : "fit",
          "w" : 677
        }, {
          "h" : 593,
          "resize" : "fit",
          "w" : 677
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 593,
          "resize" : "fit",
          "w" : 677
        } ],
        "display_url" : "pic.twitter.com\/fYNZBZSY6X"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 14, 37 ],
        "url" : "https:\/\/t.co\/z87BCj6BJO",
        "expanded_url" : "http:\/\/www.washingtontimes.com\/news\/2017\/mar\/27\/johnny-rotten-defends-donald-trump-slams-left-wing\/",
        "display_url" : "washingtontimes.com\/news\/2017\/mar\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "846402581400354816",
    "text" : "Punk is dead. https:\/\/t.co\/z87BCj6BJO https:\/\/t.co\/fYNZBZSY6X",
    "id" : 846402581400354816,
    "created_at" : "2017-03-27 16:44:35 +0000",
    "user" : {
      "name" : "Parker Molloy",
      "screen_name" : "ParkerMolloy",
      "protected" : false,
      "id_str" : "634734888",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/903119319843864576\/2gBBl4Fl_normal.jpg",
      "id" : 634734888,
      "verified" : true
    }
  },
  "id" : 846422903348449280,
  "created_at" : "2017-03-27 18:05:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chocho Zhang",
      "screen_name" : "chocho_z",
      "indices" : [ 0, 9 ],
      "id_str" : "3221119766",
      "id" : 3221119766
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "846314358405705728",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17233574185136, 8.627526900875532 ]
  },
  "id_str" : "846325716274860032",
  "in_reply_to_user_id" : 3221119766,
  "text" : "@chocho_z oh, good idea. Not sure whether that\u2019s the reasoning though :)",
  "id" : 846325716274860032,
  "in_reply_to_status_id" : 846314358405705728,
  "created_at" : "2017-03-27 11:39:09 +0000",
  "in_reply_to_screen_name" : "chocho_z",
  "in_reply_to_user_id_str" : "3221119766",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Blin",
      "screen_name" : "kaiblin",
      "indices" : [ 0, 8 ],
      "id_str" : "124202458",
      "id" : 124202458
    }, {
      "name" : "\u24EA Rik Smith-Unna \uD83C\uDDF0\uD83C\uDDEA",
      "screen_name" : "blahah404",
      "indices" : [ 9, 19 ],
      "id_str" : "99173786",
      "id" : 99173786
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "846301665816956929",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17236199099794, 8.62752507951473 ]
  },
  "id_str" : "846304148295438337",
  "in_reply_to_user_id" : 124202458,
  "text" : "@kaiblin @blahah404 didn\u2019t see that language setting :D",
  "id" : 846304148295438337,
  "in_reply_to_status_id" : 846301665816956929,
  "created_at" : "2017-03-27 10:13:27 +0000",
  "in_reply_to_screen_name" : "kaiblin",
  "in_reply_to_user_id_str" : "124202458",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patricia Herterich",
      "screen_name" : "PHerterich",
      "indices" : [ 0, 11 ],
      "id_str" : "402180727",
      "id" : 402180727
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "846295793795563520",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17233085737376, 8.627519785276629 ]
  },
  "id_str" : "846296377776852992",
  "in_reply_to_user_id" : 402180727,
  "text" : "@PHerterich wondered about that too. And the survey also asked about blood donations &amp; genomic data donation. So guess it\u2019s a c&amp;p error :D",
  "id" : 846296377776852992,
  "in_reply_to_status_id" : 846295793795563520,
  "created_at" : "2017-03-27 09:42:34 +0000",
  "in_reply_to_screen_name" : "PHerterich",
  "in_reply_to_user_id_str" : "402180727",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/P8lpXt2heA",
      "expanded_url" : "http:\/\/doi.org",
      "display_url" : "doi.org"
    } ]
  },
  "in_reply_to_status_id_str" : "844557159228755968",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17233085737376, 8.627519785276629 ]
  },
  "id_str" : "846296225259376640",
  "in_reply_to_user_id" : 14286491,
  "text" : "After resolving &gt;50% of the released SciHub DOIs: ~75% could be resolved through https:\/\/t.co\/P8lpXt2heA. Non-resolving ones are clustered.",
  "id" : 846296225259376640,
  "in_reply_to_status_id" : 844557159228755968,
  "created_at" : "2017-03-27 09:41:58 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17233129898342, 8.627538331784987 ]
  },
  "id_str" : "846287116267110400",
  "text" : "Survey asks for organ donor status. Possible answers include \u201EYes, regularly\u201C and \u201EYes, occasionally\u201C. \uD83E\uDD14",
  "id" : 846287116267110400,
  "created_at" : "2017-03-27 09:05:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 0, 14 ],
      "id_str" : "352650591",
      "id" : 352650591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "846044048376786945",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11406751807483, 8.753466749736512 ]
  },
  "id_str" : "846096930660909056",
  "in_reply_to_user_id" : 352650591,
  "text" : "@Protohedgehog awesome. Will have a look tomorrow!",
  "id" : 846096930660909056,
  "in_reply_to_status_id" : 846044048376786945,
  "created_at" : "2017-03-26 20:30:02 +0000",
  "in_reply_to_screen_name" : "Protohedgehog",
  "in_reply_to_user_id_str" : "352650591",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 82 ],
      "url" : "https:\/\/t.co\/gmyIYeraiM",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BSGZhOWjRbP\/",
      "display_url" : "instagram.com\/p\/BSGZhOWjRbP\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.08685, 8.58393 ]
  },
  "id_str" : "845963496378519552",
  "text" : "Listened to The Conspiracy Tree yesterday. \uD83D\uDC96 @ Desche Otto https:\/\/t.co\/gmyIYeraiM",
  "id" : 845963496378519552,
  "created_at" : "2017-03-26 11:39:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 0, 10 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "845740081382117376",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0870811497193, 8.584029564448779 ]
  },
  "id_str" : "845741365845733378",
  "in_reply_to_user_id" : 1385861262,
  "text" : "@Julie_B92 see, good enough to make you very curious :P",
  "id" : 845741365845733378,
  "in_reply_to_status_id" : 845740081382117376,
  "created_at" : "2017-03-25 20:57:09 +0000",
  "in_reply_to_screen_name" : "Julie_B92",
  "in_reply_to_user_id_str" : "1385861262",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.08698879143965, 8.584036555871162 ]
  },
  "id_str" : "845737074309378054",
  "text" : "\u00ABYou ought to write your papers like Buzzfeed articles: We put 15 people into the MRI and you won\u2019t believe what happened next.\u00BB",
  "id" : 845737074309378054,
  "created_at" : "2017-03-25 20:40:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Head",
      "screen_name" : "betatim",
      "indices" : [ 0, 8 ],
      "id_str" : "18881614",
      "id" : 18881614
    }, {
      "name" : "annakrystalli",
      "screen_name" : "annakrystalli",
      "indices" : [ 9, 23 ],
      "id_str" : "15090415",
      "id" : 15090415
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "845689461325357056",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1140636679831, 8.7534448187898 ]
  },
  "id_str" : "845702971073708041",
  "in_reply_to_user_id" : 18881614,
  "text" : "@betatim @annakrystalli we passed a lot of them. But I managed to contain my \uD83C\uDF66 urges until now :D",
  "id" : 845702971073708041,
  "in_reply_to_status_id" : 845689461325357056,
  "created_at" : "2017-03-25 18:24:35 +0000",
  "in_reply_to_screen_name" : "betatim",
  "in_reply_to_user_id_str" : "18881614",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Head",
      "screen_name" : "betatim",
      "indices" : [ 0, 8 ],
      "id_str" : "18881614",
      "id" : 18881614
    }, {
      "name" : "annakrystalli",
      "screen_name" : "annakrystalli",
      "indices" : [ 9, 23 ],
      "id_str" : "15090415",
      "id" : 15090415
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "845617111846338560",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11418544691998, 8.753550471746133 ]
  },
  "id_str" : "845686917358333954",
  "in_reply_to_user_id" : 18881614,
  "text" : "@betatim @annakrystalli that sounds all good. And now I also want ice cream. Walked for 15 km today.",
  "id" : 845686917358333954,
  "in_reply_to_status_id" : 845617111846338560,
  "created_at" : "2017-03-25 17:20:47 +0000",
  "in_reply_to_screen_name" : "betatim",
  "in_reply_to_user_id_str" : "18881614",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 32 ],
      "url" : "https:\/\/t.co\/ihonRCtkmD",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BSEM5Rsj8kw\/",
      "display_url" : "instagram.com\/p\/BSEM5Rsj8kw\/"
    } ]
  },
  "geo" : { },
  "id_str" : "845654254631182336",
  "text" : "In bloom https:\/\/t.co\/ihonRCtkmD",
  "id" : 845654254631182336,
  "created_at" : "2017-03-25 15:11:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11413149613104, 8.753381383067541 ]
  },
  "id_str" : "845598124219551744",
  "text" : "First time of having breakfast outside in the garden this year! \u2615\uFE0F\uD83E\uDD50\uD83E\uDD56\uD83E\uDDC0\uD83C\uDF4C\u2600\uFE0F",
  "id" : 845598124219551744,
  "created_at" : "2017-03-25 11:27:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Teon L Brooks, PhD",
      "screen_name" : "teon_io",
      "indices" : [ 0, 8 ],
      "id_str" : "30960103",
      "id" : 30960103
    }, {
      "name" : "Dano.Morrison()",
      "screen_name" : "SequencedC",
      "indices" : [ 9, 20 ],
      "id_str" : "426779215",
      "id" : 426779215
    }, {
      "name" : "Hao Ye",
      "screen_name" : "Hao_and_Y",
      "indices" : [ 21, 31 ],
      "id_str" : "111093392",
      "id" : 111093392
    }, {
      "name" : "Marion",
      "screen_name" : "marion_leborgne",
      "indices" : [ 32, 48 ],
      "id_str" : "369120974",
      "id" : 369120974
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "845344730854535168",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11406640340427, 8.753439905128104 ]
  },
  "id_str" : "845348576465244160",
  "in_reply_to_user_id" : 30960103,
  "text" : "@teon_io @SequencedC @Hao_and_Y @marion_leborgne for openSNP we just rent a couple of virtual servers outside any cloud as it\u2019s cheaper.",
  "id" : 845348576465244160,
  "in_reply_to_status_id" : 845344730854535168,
  "created_at" : "2017-03-24 18:56:21 +0000",
  "in_reply_to_screen_name" : "teon_io",
  "in_reply_to_user_id_str" : "30960103",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "D Robinson, PhD",
      "screen_name" : "daniellecrobins",
      "indices" : [ 0, 16 ],
      "id_str" : "383289779",
      "id" : 383289779
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "845300522047332352",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11303963489244, 8.75140532326248 ]
  },
  "id_str" : "845300804907155457",
  "in_reply_to_user_id" : 383289779,
  "text" : "@daniellecrobins congrats!\uD83C\uDF7E\uD83C\uDF89",
  "id" : 845300804907155457,
  "in_reply_to_status_id" : 845300522047332352,
  "created_at" : "2017-03-24 15:46:31 +0000",
  "in_reply_to_screen_name" : "daniellecrobins",
  "in_reply_to_user_id_str" : "383289779",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/tWLe7mpKsi",
      "expanded_url" : "https:\/\/arstechnica.com\/science\/2017\/03\/theranos-investors-who-pledge-not-to-sue-get-elizabeth-holmes-shares-for-free\/",
      "display_url" : "arstechnica.com\/science\/2017\/0\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17237594961373, 8.627508143022569 ]
  },
  "id_str" : "845210935874719744",
  "text" : "Desperate moves for 500: \u00ABTheranos investors who pledge not to sue get Elizabeth Holmes\u2019 shares for free\u00BB https:\/\/t.co\/tWLe7mpKsi",
  "id" : 845210935874719744,
  "created_at" : "2017-03-24 09:49:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "S\u033Ce\u0325b\u0353a\u0330s\u032Cti\u035Aa\u0349n\u034E M\u031Fo\u034Drr\u033B",
      "screen_name" : "blinry",
      "indices" : [ 0, 7 ],
      "id_str" : "53749209",
      "id" : 53749209
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "845191575130988544",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17238072795973, 8.627500100880543 ]
  },
  "id_str" : "845196141561987072",
  "in_reply_to_user_id" : 53749209,
  "text" : "@blinry hadn\u2019t known her before I got that print as a gift &lt;3",
  "id" : 845196141561987072,
  "in_reply_to_status_id" : 845191575130988544,
  "created_at" : "2017-03-24 08:50:37 +0000",
  "in_reply_to_screen_name" : "blinry",
  "in_reply_to_user_id_str" : "53749209",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "S\u033Ce\u0325b\u0353a\u0330s\u032Cti\u035Aa\u0349n\u034E M\u031Fo\u034Drr\u033B",
      "screen_name" : "blinry",
      "indices" : [ 0, 7 ],
      "id_str" : "53749209",
      "id" : 53749209
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 41 ],
      "url" : "https:\/\/t.co\/rfc20NJ279",
      "expanded_url" : "http:\/\/www.stasiaburrington.com\/",
      "display_url" : "stasiaburrington.com"
    } ]
  },
  "in_reply_to_status_id_str" : "845190717706162177",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17235809876392, 8.627518051033872 ]
  },
  "id_str" : "845190863663775744",
  "in_reply_to_user_id" : 53749209,
  "text" : "@blinry check out https:\/\/t.co\/rfc20NJ279 all of her work is awesome.",
  "id" : 845190863663775744,
  "in_reply_to_status_id" : 845190717706162177,
  "created_at" : "2017-03-24 08:29:39 +0000",
  "in_reply_to_screen_name" : "blinry",
  "in_reply_to_user_id_str" : "53749209",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/845182656933355520\/photo\/1",
      "indices" : [ 36, 59 ],
      "url" : "https:\/\/t.co\/3Wjck9tO1j",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/C7qxJVXV4AArz2d.jpg",
      "id_str" : "845182653997375488",
      "id" : 845182653997375488,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C7qxJVXV4AArz2d.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      } ],
      "display_url" : "pic.twitter.com\/3Wjck9tO1j"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "845182656933355520",
  "text" : "A thing to wake up to each morning. https:\/\/t.co\/3Wjck9tO1j",
  "id" : 845182656933355520,
  "created_at" : "2017-03-24 07:57:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathan Klassen",
      "screen_name" : "KlassenLab",
      "indices" : [ 3, 14 ],
      "id_str" : "1421096077",
      "id" : 1421096077
    }, {
      "name" : "Titus Brown",
      "screen_name" : "ctitusbrown",
      "indices" : [ 17, 29 ],
      "id_str" : "26616462",
      "id" : 26616462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "845051736939225088",
  "text" : "RT @KlassenLab: .@ctitusbrown \"Even if you can assemble soil, you still don't understand anything\" - annotations are too lousy, we are db d\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Titus Brown",
        "screen_name" : "ctitusbrown",
        "indices" : [ 1, 13 ],
        "id_str" : "26616462",
        "id" : 26616462
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "JGI2017",
        "indices" : [ 132, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "845044846792355840",
    "text" : ".@ctitusbrown \"Even if you can assemble soil, you still don't understand anything\" - annotations are too lousy, we are db dependent #JGI2017",
    "id" : 845044846792355840,
    "created_at" : "2017-03-23 22:49:26 +0000",
    "user" : {
      "name" : "Jonathan Klassen",
      "screen_name" : "KlassenLab",
      "protected" : false,
      "id_str" : "1421096077",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3646045844\/592d1e7e3213d41bfa24aa3e75c27aa7_normal.jpeg",
      "id" : 1421096077,
      "verified" : false
    }
  },
  "id" : 845051736939225088,
  "created_at" : "2017-03-23 23:16:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The West Wing Weekly",
      "screen_name" : "WestWingWeekly",
      "indices" : [ 30, 45 ],
      "id_str" : "3683068757",
      "id" : 3683068757
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/tc8eW2SEGa",
      "expanded_url" : "http:\/\/thewestwingweekly.com\/episodes\/222-part2",
      "display_url" : "thewestwingweekly.com\/episodes\/222-p\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "844981892244013057",
  "text" : "Emotional level: Just hearing @WestWingWeekly speak about Two Cathedrals makes me tear up. https:\/\/t.co\/tc8eW2SEGa",
  "id" : 844981892244013057,
  "created_at" : "2017-03-23 18:39:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Faguy",
      "screen_name" : "fagstein",
      "indices" : [ 3, 12 ],
      "id_str" : "19011260",
      "id" : 19011260
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 84 ],
      "url" : "https:\/\/t.co\/iMz1Lr6yLe",
      "expanded_url" : "https:\/\/twitter.com\/edyong209\/status\/844615944223834115",
      "display_url" : "twitter.com\/edyong209\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "844960023692349440",
  "text" : "RT @fagstein: Science proves Shakira doctrine was incorrect. https:\/\/t.co\/iMz1Lr6yLe",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 47, 70 ],
        "url" : "https:\/\/t.co\/iMz1Lr6yLe",
        "expanded_url" : "https:\/\/twitter.com\/edyong209\/status\/844615944223834115",
        "display_url" : "twitter.com\/edyong209\/stat\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "844634564546965508",
    "text" : "Science proves Shakira doctrine was incorrect. https:\/\/t.co\/iMz1Lr6yLe",
    "id" : 844634564546965508,
    "created_at" : "2017-03-22 19:39:07 +0000",
    "user" : {
      "name" : "Steve Faguy",
      "screen_name" : "fagstein",
      "protected" : false,
      "id_str" : "19011260",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1369127574\/icon_normal.jpg",
      "id" : 19011260,
      "verified" : false
    }
  },
  "id" : 844960023692349440,
  "created_at" : "2017-03-23 17:12:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uD83D\uDC9A Aure Moser \uD83D\uDC9A",
      "screen_name" : "auremoser",
      "indices" : [ 3, 13 ],
      "id_str" : "186529934",
      "id" : 186529934
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "gsoc17",
      "indices" : [ 33, 40 ]
    } ],
    "urls" : [ {
      "indices" : [ 57, 80 ],
      "url" : "https:\/\/t.co\/Msc7NxciMh",
      "expanded_url" : "https:\/\/twitter.com\/MozillaScience\/status\/844951199837278209",
      "display_url" : "twitter.com\/MozillaScience\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "844958257441591296",
  "text" : "RT @auremoser: I'm mentoring for #gsoc17 , check it out! https:\/\/t.co\/Msc7NxciMh",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "gsoc17",
        "indices" : [ 18, 25 ]
      } ],
      "urls" : [ {
        "indices" : [ 42, 65 ],
        "url" : "https:\/\/t.co\/Msc7NxciMh",
        "expanded_url" : "https:\/\/twitter.com\/MozillaScience\/status\/844951199837278209",
        "display_url" : "twitter.com\/MozillaScience\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "844951600674328577",
    "text" : "I'm mentoring for #gsoc17 , check it out! https:\/\/t.co\/Msc7NxciMh",
    "id" : 844951600674328577,
    "created_at" : "2017-03-23 16:38:54 +0000",
    "user" : {
      "name" : "\uD83D\uDC9A Aure Moser \uD83D\uDC9A",
      "screen_name" : "auremoser",
      "protected" : false,
      "id_str" : "186529934",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/723868643688325122\/AHwUDHy3_normal.jpg",
      "id" : 186529934,
      "verified" : false
    }
  },
  "id" : 844958257441591296,
  "created_at" : "2017-03-23 17:05:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 83 ],
      "url" : "https:\/\/t.co\/0SSuKjWDEv",
      "expanded_url" : "http:\/\/biorxiv.org\/content\/early\/2017\/03\/22\/119370",
      "display_url" : "biorxiv.org\/content\/early\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723476969326, 8.627525213644194 ]
  },
  "id_str" : "844949051602817024",
  "text" : "The Readability Of Scientific Texts Is Decreasing Over Time https:\/\/t.co\/0SSuKjWDEv",
  "id" : 844949051602817024,
  "created_at" : "2017-03-23 16:28:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17235479993921, 8.627515468973213 ]
  },
  "id_str" : "844944453550952448",
  "text" : "Why meticulous documentation is important: Going through my lab notebook to rerun an analysis and find \u00AB17. Call it a day and cry\u00BB. \uD83D\uDCDD",
  "id" : 844944453550952448,
  "created_at" : "2017-03-23 16:10:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/verFqWsabz",
      "expanded_url" : "https:\/\/youtu.be\/wWc43RxbUeg?t=29s",
      "display_url" : "youtu.be\/wWc43RxbUeg?t=\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "844834005857972228",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17236599210798, 8.627506408286072 ]
  },
  "id_str" : "844835570396254212",
  "in_reply_to_user_id" : 14286491,
  "text" : "And all we wanted to do is to put it into the microwave, as that\u2019s the closest to wet lab work we can get. https:\/\/t.co\/verFqWsabz",
  "id" : 844835570396254212,
  "in_reply_to_status_id" : 844834005857972228,
  "created_at" : "2017-03-23 08:57:50 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 88 ],
      "url" : "https:\/\/t.co\/JdO8JzTG8s",
      "expanded_url" : "https:\/\/en.wikipedia.org\/wiki\/Chocolate-coated_marshmallow_treats#According_to_Halacha",
      "display_url" : "en.wikipedia.org\/wiki\/Chocolate\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17236598868692, 8.627506415683378 ]
  },
  "id_str" : "844834005857972228",
  "text" : "Who knew that eatings sweets could be such a complicated matter? https:\/\/t.co\/JdO8JzTG8s",
  "id" : 844834005857972228,
  "created_at" : "2017-03-23 08:51:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Hanna, Witchiest Data Witch that ever Witched",
      "screen_name" : "alexhanna",
      "indices" : [ 3, 13 ],
      "id_str" : "661613",
      "id" : 661613
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 64 ],
      "url" : "https:\/\/t.co\/HyrclYzExc",
      "expanded_url" : "https:\/\/twitter.com\/neiltyson\/status\/844596456459816960",
      "display_url" : "twitter.com\/neiltyson\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "844817623288209408",
  "text" : "RT @alexhanna: No.\n\nData. Is. Political. https:\/\/t.co\/HyrclYzExc",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 26, 49 ],
        "url" : "https:\/\/t.co\/HyrclYzExc",
        "expanded_url" : "https:\/\/twitter.com\/neiltyson\/status\/844596456459816960",
        "display_url" : "twitter.com\/neiltyson\/stat\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "844596558523969537",
    "text" : "No.\n\nData. Is. Political. https:\/\/t.co\/HyrclYzExc",
    "id" : 844596558523969537,
    "created_at" : "2017-03-22 17:08:06 +0000",
    "user" : {
      "name" : "Alex Hanna, Witchiest Data Witch that ever Witched",
      "screen_name" : "alexhanna",
      "protected" : false,
      "id_str" : "661613",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/869950014134603777\/80PbZpXI_normal.jpg",
      "id" : 661613,
      "verified" : false
    }
  },
  "id" : 844817623288209408,
  "created_at" : "2017-03-23 07:46:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 87 ],
      "url" : "https:\/\/t.co\/B0g69Hhfs6",
      "expanded_url" : "http:\/\/feeds.plos.org\/~r\/plosbiology\/NewArticles\/~3\/RaFEtkO0UBE\/article",
      "display_url" : "feeds.plos.org\/~r\/plosbiology\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "844681042275504128",
  "text" : "Teaching broader impacts of science with undergraduate research https:\/\/t.co\/B0g69Hhfs6",
  "id" : 844681042275504128,
  "created_at" : "2017-03-22 22:43:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katherine Crocker \uD83C\uDFF4",
      "screen_name" : "cricketcrocker",
      "indices" : [ 3, 18 ],
      "id_str" : "2828796622",
      "id" : 2828796622
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "844678792308252672",
  "text" : "RT @cricketcrocker: There are 3 components to allyship:\n1. Trust (and listening)\n2. Advocacy (and listening)\n3. Consistency (and listening)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "844677890784608256",
    "geo" : { },
    "id_str" : "844677995642130432",
    "in_reply_to_user_id" : 2828796622,
    "text" : "There are 3 components to allyship:\n1. Trust (and listening)\n2. Advocacy (and listening)\n3. Consistency (and listening)",
    "id" : 844677995642130432,
    "in_reply_to_status_id" : 844677890784608256,
    "created_at" : "2017-03-22 22:31:42 +0000",
    "in_reply_to_screen_name" : "cricketcrocker",
    "in_reply_to_user_id_str" : "2828796622",
    "user" : {
      "name" : "Katherine Crocker \uD83C\uDFF4",
      "screen_name" : "cricketcrocker",
      "protected" : false,
      "id_str" : "2828796622",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/706908018076585984\/hvXCrX3F_normal.jpg",
      "id" : 2828796622,
      "verified" : false
    }
  },
  "id" : 844678792308252672,
  "created_at" : "2017-03-22 22:34:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 55 ],
      "url" : "https:\/\/t.co\/HzihqxaG5l",
      "expanded_url" : "https:\/\/twitter.com\/Julie_B92\/status\/844567370588999680",
      "display_url" : "twitter.com\/Julie_B92\/stat\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11393224532628, 8.753497219028276 ]
  },
  "id_str" : "844593543062720512",
  "text" : "My favorite kind of comments. \uD83D\uDE31 https:\/\/t.co\/HzihqxaG5l",
  "id" : 844593543062720512,
  "created_at" : "2017-03-22 16:56:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mozilla Open Leaders",
      "screen_name" : "MozOpenLeaders",
      "indices" : [ 80, 95 ],
      "id_str" : "791070237949034496",
      "id" : 791070237949034496
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mozwow",
      "indices" : [ 19, 26 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11406336962659, 8.753452010234259 ]
  },
  "id_str" : "844592441810468865",
  "text" : "Finished the first #mozwow mentorship call of this season and it was great! Yay @MozOpenLeaders! \uD83C\uDF89\uD83C\uDF8A",
  "id" : 844592441810468865,
  "created_at" : "2017-03-22 16:51:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 82 ],
      "url" : "https:\/\/t.co\/P8lpXt2heA",
      "expanded_url" : "http:\/\/doi.org",
      "display_url" : "doi.org"
    }, {
      "indices" : [ 134, 157 ],
      "url" : "https:\/\/t.co\/TbZNSX5CmW",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/843734339183661056",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "843734339183661056",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17235131303857, 8.627519686834006 ]
  },
  "id_str" : "844557159228755968",
  "in_reply_to_user_id" : 14286491,
  "text" : "So far I tried to resolve ~6 million of these DOIs through https:\/\/t.co\/P8lpXt2heA. Only ~34% could be successfully resolved through. https:\/\/t.co\/TbZNSX5CmW",
  "id" : 844557159228755968,
  "in_reply_to_status_id" : 843734339183661056,
  "created_at" : "2017-03-22 14:31:32 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Meghan Duffy",
      "screen_name" : "duffy_ma",
      "indices" : [ 3, 12 ],
      "id_str" : "453892183",
      "id" : 453892183
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 44 ],
      "url" : "https:\/\/t.co\/KbDwdtAzRL",
      "expanded_url" : "https:\/\/twitter.com\/mbeisen\/status\/844387955795898369",
      "display_url" : "twitter.com\/mbeisen\/status\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "844551190423711744",
  "text" : "RT @duffy_ma: Thread https:\/\/t.co\/KbDwdtAzRL",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 7, 30 ],
        "url" : "https:\/\/t.co\/KbDwdtAzRL",
        "expanded_url" : "https:\/\/twitter.com\/mbeisen\/status\/844387955795898369",
        "display_url" : "twitter.com\/mbeisen\/status\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "844532063801950209",
    "text" : "Thread https:\/\/t.co\/KbDwdtAzRL",
    "id" : 844532063801950209,
    "created_at" : "2017-03-22 12:51:49 +0000",
    "user" : {
      "name" : "Meghan Duffy",
      "screen_name" : "duffy_ma",
      "protected" : false,
      "id_str" : "453892183",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/862413420385251331\/U0ufMi47_normal.jpg",
      "id" : 453892183,
      "verified" : true
    }
  },
  "id" : 844551190423711744,
  "created_at" : "2017-03-22 14:07:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "VALIUM",
      "screen_name" : "alibi_rage",
      "indices" : [ 0, 11 ],
      "id_str" : "971867420",
      "id" : 971867420
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "844548478760091653",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17235044260664, 8.627515521683478 ]
  },
  "id_str" : "844548601376313345",
  "in_reply_to_user_id" : 971867420,
  "text" : "@alibi_rage yay, cool! Mal schauen ob Miezi sie mag.",
  "id" : 844548601376313345,
  "in_reply_to_status_id" : 844548478760091653,
  "created_at" : "2017-03-22 13:57:32 +0000",
  "in_reply_to_screen_name" : "alibi_rage",
  "in_reply_to_user_id_str" : "971867420",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Unstrange Mind",
      "screen_name" : "UnstrangeMind",
      "indices" : [ 3, 17 ],
      "id_str" : "1247751571",
      "id" : 1247751571
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "844543330751057921",
  "text" : "RT @UnstrangeMind: Autistic Shutdown Alters Brain Function. Protect your brain and the brains of those you care about. https:\/\/t.co\/XME1xKQ\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 100, 123 ],
        "url" : "https:\/\/t.co\/XME1xKQrgb",
        "expanded_url" : "http:\/\/unstrangemind.com\/autistic-shutdown-alters-brain-function\/",
        "display_url" : "unstrangemind.com\/autistic-shutd\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "844270628538597377",
    "text" : "Autistic Shutdown Alters Brain Function. Protect your brain and the brains of those you care about. https:\/\/t.co\/XME1xKQrgb",
    "id" : 844270628538597377,
    "created_at" : "2017-03-21 19:32:58 +0000",
    "user" : {
      "name" : "Unstrange Mind",
      "screen_name" : "UnstrangeMind",
      "protected" : false,
      "id_str" : "1247751571",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/880541005354872832\/-wGn7EzQ_normal.jpg",
      "id" : 1247751571,
      "verified" : false
    }
  },
  "id" : 844543330751057921,
  "created_at" : "2017-03-22 13:36:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "VALIUM",
      "screen_name" : "alibi_rage",
      "indices" : [ 0, 11 ],
      "id_str" : "971867420",
      "id" : 971867420
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "842790044461088769",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17234297671533, 8.627541266798092 ]
  },
  "id_str" : "844510386288316416",
  "in_reply_to_user_id" : 971867420,
  "text" : "@alibi_rage steht das Angebot f\u00FCr die Medikamente noch? :D",
  "id" : 844510386288316416,
  "in_reply_to_status_id" : 842790044461088769,
  "created_at" : "2017-03-22 11:25:40 +0000",
  "in_reply_to_screen_name" : "alibi_rage",
  "in_reply_to_user_id_str" : "971867420",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sujai Kumar",
      "screen_name" : "sujaik",
      "indices" : [ 0, 7 ],
      "id_str" : "33651124",
      "id" : 33651124
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "844491370115031040",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172446987269, 8.62756530775842 ]
  },
  "id_str" : "844494943213293568",
  "in_reply_to_user_id" : 33651124,
  "text" : "@sujaik thanks!",
  "id" : 844494943213293568,
  "in_reply_to_status_id" : 844491370115031040,
  "created_at" : "2017-03-22 10:24:19 +0000",
  "in_reply_to_screen_name" : "sujaik",
  "in_reply_to_user_id_str" : "33651124",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Monica Granados",
      "screen_name" : "Monsauce",
      "indices" : [ 0, 9 ],
      "id_str" : "297073565",
      "id" : 297073565
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "844296438972600321",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11406707714389, 8.753440135615694 ]
  },
  "id_str" : "844296650877210629",
  "in_reply_to_user_id" : 297073565,
  "text" : "@Monsauce no pressure! \uD83D\uDE02",
  "id" : 844296650877210629,
  "in_reply_to_status_id" : 844296438972600321,
  "created_at" : "2017-03-21 21:16:22 +0000",
  "in_reply_to_screen_name" : "Monsauce",
  "in_reply_to_user_id_str" : "297073565",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nona Willis Aronowitz",
      "screen_name" : "nona",
      "indices" : [ 3, 8 ],
      "id_str" : "21351460",
      "id" : 21351460
    }, {
      "name" : "collier meyerson",
      "screen_name" : "collier",
      "indices" : [ 24, 32 ],
      "id_str" : "31333373",
      "id" : 31333373
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/A4OXIi1J4w",
      "expanded_url" : "http:\/\/nymag.com\/thecut\/2017\/03\/no-more-dating-white-men.html",
      "display_url" : "nymag.com\/thecut\/2017\/03\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "844203695965458433",
  "text" : "RT @nona: This piece by @collier about dating white dudes in the time of Trump is so so so good read it https:\/\/t.co\/A4OXIi1J4w https:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "collier meyerson",
        "screen_name" : "collier",
        "indices" : [ 14, 22 ],
        "id_str" : "31333373",
        "id" : 31333373
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/nona\/status\/844200568721686528\/photo\/1",
        "indices" : [ 118, 141 ],
        "url" : "https:\/\/t.co\/BkLXy7Pg4W",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/C7cz6_bV4AISBZU.jpg",
        "id_str" : "844200543706800130",
        "id" : 844200543706800130,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C7cz6_bV4AISBZU.jpg",
        "sizes" : [ {
          "h" : 675,
          "resize" : "fit",
          "w" : 750
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 675,
          "resize" : "fit",
          "w" : 750
        }, {
          "h" : 675,
          "resize" : "fit",
          "w" : 750
        }, {
          "h" : 612,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/BkLXy7Pg4W"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 94, 117 ],
        "url" : "https:\/\/t.co\/A4OXIi1J4w",
        "expanded_url" : "http:\/\/nymag.com\/thecut\/2017\/03\/no-more-dating-white-men.html",
        "display_url" : "nymag.com\/thecut\/2017\/03\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "844200568721686528",
    "text" : "This piece by @collier about dating white dudes in the time of Trump is so so so good read it https:\/\/t.co\/A4OXIi1J4w https:\/\/t.co\/BkLXy7Pg4W",
    "id" : 844200568721686528,
    "created_at" : "2017-03-21 14:54:34 +0000",
    "user" : {
      "name" : "Nona Willis Aronowitz",
      "screen_name" : "nona",
      "protected" : false,
      "id_str" : "21351460",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/829838271706497025\/_r71YOVu_normal.jpg",
      "id" : 21351460,
      "verified" : true
    }
  },
  "id" : 844203695965458433,
  "created_at" : "2017-03-21 15:07:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 54 ],
      "url" : "https:\/\/t.co\/Ig2iJcwnBP",
      "expanded_url" : "http:\/\/www.atlasobscura.com\/places\/grimsey-island",
      "display_url" : "atlasobscura.com\/places\/grimsey\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17236012779245, 8.627502373682375 ]
  },
  "id_str" : "844115948193923073",
  "text" : "For the next visit to Iceland: https:\/\/t.co\/Ig2iJcwnBP",
  "id" : 844115948193923073,
  "created_at" : "2017-03-21 09:18:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Schawinski",
      "screen_name" : "kevinschawinski",
      "indices" : [ 0, 16 ],
      "id_str" : "242844365",
      "id" : 242844365
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "844105638930251776",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17236857364917, 8.62751966893842 ]
  },
  "id_str" : "844106707768954880",
  "in_reply_to_user_id" : 242844365,
  "text" : "@kevinschawinski and obsession with national car manufacturers has it\u2019s downsides.",
  "id" : 844106707768954880,
  "in_reply_to_status_id" : 844105638930251776,
  "created_at" : "2017-03-21 08:41:36 +0000",
  "in_reply_to_screen_name" : "kevinschawinski",
  "in_reply_to_user_id_str" : "242844365",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Schawinski",
      "screen_name" : "kevinschawinski",
      "indices" : [ 0, 16 ],
      "id_str" : "242844365",
      "id" : 242844365
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "844100777174089728",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17237680376417, 8.627519660673967 ]
  },
  "id_str" : "844105386357641216",
  "in_reply_to_user_id" : 242844365,
  "text" : "@kevinschawinski here it would be another day that ends in y.",
  "id" : 844105386357641216,
  "in_reply_to_status_id" : 844100777174089728,
  "created_at" : "2017-03-21 08:36:21 +0000",
  "in_reply_to_screen_name" : "kevinschawinski",
  "in_reply_to_user_id_str" : "242844365",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "rob beynon",
      "screen_name" : "astacus",
      "indices" : [ 3, 11 ],
      "id_str" : "397424516",
      "id" : 397424516
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/ZR9TSouqpP",
      "expanded_url" : "https:\/\/twitter.com\/cbquist\/status\/843813353898364928",
      "display_url" : "twitter.com\/cbquist\/status\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "844104587548286976",
  "text" : "RT @astacus: I wonder how many of our students even considered that Menten was a woman? https:\/\/t.co\/ZR9TSouqpP",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 75, 98 ],
        "url" : "https:\/\/t.co\/ZR9TSouqpP",
        "expanded_url" : "https:\/\/twitter.com\/cbquist\/status\/843813353898364928",
        "display_url" : "twitter.com\/cbquist\/status\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "843959733732233217",
    "text" : "I wonder how many of our students even considered that Menten was a woman? https:\/\/t.co\/ZR9TSouqpP",
    "id" : 843959733732233217,
    "created_at" : "2017-03-20 22:57:35 +0000",
    "user" : {
      "name" : "rob beynon",
      "screen_name" : "astacus",
      "protected" : false,
      "id_str" : "397424516",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/912020012457701376\/lmij6gPf_normal.jpg",
      "id" : 397424516,
      "verified" : false
    }
  },
  "id" : 844104587548286976,
  "created_at" : "2017-03-21 08:33:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 67 ],
      "url" : "https:\/\/t.co\/xkY4eF65ax",
      "expanded_url" : "https:\/\/twitter.com\/PhilippBayer\/status\/844076817749180416",
      "display_url" : "twitter.com\/PhilippBayer\/s\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17233660450459, 8.627531490408785 ]
  },
  "id_str" : "844102755060998144",
  "text" : "But which species concept are they using? \uD83D\uDE02 https:\/\/t.co\/xkY4eF65ax",
  "id" : 844102755060998144,
  "created_at" : "2017-03-21 08:25:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "843929569170247681",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11406726999999, 8.753451289999996 ]
  },
  "id_str" : "843940785477341184",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon i\u2019ll let you know what the oldest entries are once I got all those DOIs resolved. :D",
  "id" : 843940785477341184,
  "in_reply_to_status_id" : 843929569170247681,
  "created_at" : "2017-03-20 21:42:17 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Heathers",
      "screen_name" : "jamesheathers",
      "indices" : [ 3, 17 ],
      "id_str" : "368750485",
      "id" : 368750485
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 81 ],
      "url" : "https:\/\/t.co\/TWS9cOIZWH",
      "expanded_url" : "https:\/\/twitter.com\/sTeamTraen\/status\/843890416449736707",
      "display_url" : "twitter.com\/sTeamTraen\/sta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "843940351329079296",
  "text" : "RT @jamesheathers: This is not just data SNAFUs any more. https:\/\/t.co\/TWS9cOIZWH",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 39, 62 ],
        "url" : "https:\/\/t.co\/TWS9cOIZWH",
        "expanded_url" : "https:\/\/twitter.com\/sTeamTraen\/status\/843890416449736707",
        "display_url" : "twitter.com\/sTeamTraen\/sta\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "843906310399705089",
    "text" : "This is not just data SNAFUs any more. https:\/\/t.co\/TWS9cOIZWH",
    "id" : 843906310399705089,
    "created_at" : "2017-03-20 19:25:18 +0000",
    "user" : {
      "name" : "James Heathers",
      "screen_name" : "jamesheathers",
      "protected" : false,
      "id_str" : "368750485",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/837760012382502913\/epVhG9ut_normal.jpg",
      "id" : 368750485,
      "verified" : false
    }
  },
  "id" : 843940351329079296,
  "created_at" : "2017-03-20 21:40:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Preater",
      "screen_name" : "preater",
      "indices" : [ 0, 8 ],
      "id_str" : "17602517",
      "id" : 17602517
    }, {
      "name" : "figshare",
      "screen_name" : "figshare",
      "indices" : [ 9, 18 ],
      "id_str" : "224631899",
      "id" : 224631899
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "843923366096658433",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11406727054025, 8.753451288831652 ]
  },
  "id_str" : "843923514403028992",
  "in_reply_to_user_id" : 17602517,
  "text" : "@preater @figshare that\u2019s what i feared, but I\u2019ll accept that limitation then. Though \u201Ea while\u201C is really a lot for 62 million queries :D",
  "id" : 843923514403028992,
  "in_reply_to_status_id" : 843923366096658433,
  "created_at" : "2017-03-20 20:33:39 +0000",
  "in_reply_to_screen_name" : "preater",
  "in_reply_to_user_id_str" : "17602517",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Preater",
      "screen_name" : "preater",
      "indices" : [ 0, 8 ],
      "id_str" : "17602517",
      "id" : 17602517
    }, {
      "name" : "figshare",
      "screen_name" : "figshare",
      "indices" : [ 76, 85 ],
      "id_str" : "224631899",
      "id" : 224631899
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/10q5ALk2kc",
      "expanded_url" : "https:\/\/thewinnower.com\/papers\/4715-correlating-the-sci-hub-data-with-world-bank-indicators-and-identifying-academic-use",
      "display_url" : "thewinnower.com\/papers\/4715-co\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "843919561179254785",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11406725934926, 8.753451313029833 ]
  },
  "id_str" : "843921244118564866",
  "in_reply_to_user_id" : 17602517,
  "text" : "@preater yeah, I think people saw that in the usage data last year as well. @figshare (btw here my prior work on it: https:\/\/t.co\/10q5ALk2kc",
  "id" : 843921244118564866,
  "in_reply_to_status_id" : 843919561179254785,
  "created_at" : "2017-03-20 20:24:38 +0000",
  "in_reply_to_screen_name" : "preater",
  "in_reply_to_user_id_str" : "17602517",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Preater",
      "screen_name" : "preater",
      "indices" : [ 0, 8 ],
      "id_str" : "17602517",
      "id" : 17602517
    }, {
      "name" : "figshare",
      "screen_name" : "figshare",
      "indices" : [ 9, 18 ],
      "id_str" : "224631899",
      "id" : 224631899
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "843919119330299905",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11364576627518, 8.753934656410825 ]
  },
  "id_str" : "843919461346398208",
  "in_reply_to_user_id" : 17602517,
  "text" : "@preater @figshare will be a while before I can resolve them all. Do you have a recommendation for speeding that up? (Not a librarian here)",
  "id" : 843919461346398208,
  "in_reply_to_status_id" : 843919119330299905,
  "created_at" : "2017-03-20 20:17:33 +0000",
  "in_reply_to_screen_name" : "preater",
  "in_reply_to_user_id_str" : "17602517",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Preater",
      "screen_name" : "preater",
      "indices" : [ 0, 8 ],
      "id_str" : "17602517",
      "id" : 17602517
    }, {
      "name" : "figshare",
      "screen_name" : "figshare",
      "indices" : [ 9, 18 ],
      "id_str" : "224631899",
      "id" : 224631899
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "843914964654067713",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11384496329155, 8.678730863644585 ]
  },
  "id_str" : "843915256204267520",
  "in_reply_to_user_id" : 17602517,
  "text" : "@preater @figshare e.g. Which journals\/publishers are more\/less downloaded from Scihub than expected.",
  "id" : 843915256204267520,
  "in_reply_to_status_id" : 843914964654067713,
  "created_at" : "2017-03-20 20:00:50 +0000",
  "in_reply_to_screen_name" : "preater",
  "in_reply_to_user_id_str" : "17602517",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Preater",
      "screen_name" : "preater",
      "indices" : [ 0, 8 ],
      "id_str" : "17602517",
      "id" : 17602517
    }, {
      "name" : "figshare",
      "screen_name" : "figshare",
      "indices" : [ 9, 18 ],
      "id_str" : "224631899",
      "id" : 224631899
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "843914964654067713",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11385324144759, 8.678747850228445 ]
  },
  "id_str" : "843915120099188736",
  "in_reply_to_user_id" : 17602517,
  "text" : "@preater @figshare nice. I wanna compare how the usage data from last year compares to the total amount of data available.",
  "id" : 843915120099188736,
  "in_reply_to_status_id" : 843914964654067713,
  "created_at" : "2017-03-20 20:00:18 +0000",
  "in_reply_to_screen_name" : "preater",
  "in_reply_to_user_id_str" : "17602517",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Preater",
      "screen_name" : "preater",
      "indices" : [ 0, 8 ],
      "id_str" : "17602517",
      "id" : 17602517
    }, {
      "name" : "figshare",
      "screen_name" : "figshare",
      "indices" : [ 9, 18 ],
      "id_str" : "224631899",
      "id" : 224631899
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "843872269415989248",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11386965367008, 8.678896918227979 ]
  },
  "id_str" : "843913609575092224",
  "in_reply_to_user_id" : 17602517,
  "text" : "@preater @figshare I\u2019m currently resolving all of them for Publisher &amp; journal. What did you do? :)",
  "id" : 843913609575092224,
  "in_reply_to_status_id" : 843872269415989248,
  "created_at" : "2017-03-20 19:54:18 +0000",
  "in_reply_to_screen_name" : "preater",
  "in_reply_to_user_id_str" : "17602517",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "843887545142382592",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11386965367008, 8.678896918227979 ]
  },
  "id_str" : "843913308168241152",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon don\u2019t know how the copyright works for such old things :D",
  "id" : 843913308168241152,
  "in_reply_to_status_id" : 843887545142382592,
  "created_at" : "2017-03-20 19:53:06 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Edmunds",
      "screen_name" : "SCEdmunds",
      "indices" : [ 0, 10 ],
      "id_str" : "176024190",
      "id" : 176024190
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "843835042107342848",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17238491346284, 8.62755745137071 ]
  },
  "id_str" : "843859445725773824",
  "in_reply_to_user_id" : 176024190,
  "text" : "@SCEdmunds that picture looks just like my kind of party!",
  "id" : 843859445725773824,
  "in_reply_to_status_id" : 843835042107342848,
  "created_at" : "2017-03-20 16:19:04 +0000",
  "in_reply_to_screen_name" : "SCEdmunds",
  "in_reply_to_user_id_str" : "176024190",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 79 ],
      "url" : "https:\/\/t.co\/4nCgwZw3Fl",
      "expanded_url" : "https:\/\/media.giphy.com\/media\/Ieo5EZ5jxJhrG\/giphy.gif",
      "display_url" : "media.giphy.com\/media\/Ieo5EZ5j\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17241236603103, 8.62756877215869 ]
  },
  "id_str" : "843854463635017728",
  "text" : "Today I wrote Python, Ruby &amp; R and now I feel like\u2026 https:\/\/t.co\/4nCgwZw3Fl",
  "id" : 843854463635017728,
  "created_at" : "2017-03-20 15:59:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 53 ],
      "url" : "https:\/\/t.co\/bN6JyvF8kJ",
      "expanded_url" : "https:\/\/twitter.com\/aleszubajak\/status\/843803566116626432",
      "display_url" : "twitter.com\/aleszubajak\/st\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17230792215439, 8.627538278867881 ]
  },
  "id_str" : "843846738981126145",
  "text" : "And now mirror it vertically! https:\/\/t.co\/bN6JyvF8kJ",
  "id" : 843846738981126145,
  "created_at" : "2017-03-20 15:28:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Edmunds",
      "screen_name" : "SCEdmunds",
      "indices" : [ 0, 10 ],
      "id_str" : "176024190",
      "id" : 176024190
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "843825756635504642",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17234643707263, 8.627566126691573 ]
  },
  "id_str" : "843825835417260032",
  "in_reply_to_user_id" : 176024190,
  "text" : "@SCEdmunds thanks! Are you properly celebrating today? :-)",
  "id" : 843825835417260032,
  "in_reply_to_status_id" : 843825756635504642,
  "created_at" : "2017-03-20 14:05:31 +0000",
  "in_reply_to_screen_name" : "SCEdmunds",
  "in_reply_to_user_id_str" : "176024190",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Edmunds",
      "screen_name" : "SCEdmunds",
      "indices" : [ 13, 23 ],
      "id_str" : "176024190",
      "id" : 176024190
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17229440343772, 8.627655371022353 ]
  },
  "id_str" : "843781301719220224",
  "text" : "\u0646\u0648\u0631\u0648\u0632 \u0645\u0628\u0627\u0631\u06A9! @SCEdmunds",
  "id" : 843781301719220224,
  "created_at" : "2017-03-20 11:08:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul-Olivier Dehaye",
      "screen_name" : "podehaye",
      "indices" : [ 0, 9 ],
      "id_str" : "2219841242",
      "id" : 2219841242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "843755712501219328",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17237300561493, 8.627561193892163 ]
  },
  "id_str" : "843758144757121024",
  "in_reply_to_user_id" : 2219841242,
  "text" : "@podehaye i think the domain expired at some point some year(s) ago? :D",
  "id" : 843758144757121024,
  "in_reply_to_status_id" : 843755712501219328,
  "created_at" : "2017-03-20 09:36:32 +0000",
  "in_reply_to_screen_name" : "podehaye",
  "in_reply_to_user_id_str" : "2219841242",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Cock",
      "screen_name" : "pjacock",
      "indices" : [ 0, 8 ],
      "id_str" : "58756672",
      "id" : 58756672
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 118, 127 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "843751272113233921",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17239538362075, 8.62757063461557 ]
  },
  "id_str" : "843754234101317632",
  "in_reply_to_user_id" : 58756672,
  "text" : "@pjacock or one would hope, not sure whether they got a blanket copyright for all \u201Edigitized versions\u201C or so? But may @Senficon knows.",
  "id" : 843754234101317632,
  "in_reply_to_status_id" : 843751272113233921,
  "created_at" : "2017-03-20 09:21:00 +0000",
  "in_reply_to_screen_name" : "pjacock",
  "in_reply_to_user_id_str" : "58756672",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 0, 10 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    }, {
      "name" : "David Winter",
      "screen_name" : "TheAtavism",
      "indices" : [ 28, 39 ],
      "id_str" : "19420947",
      "id" : 19420947
    }, {
      "name" : "Joe Cursons",
      "screen_name" : "JoeCursons",
      "indices" : [ 40, 51 ],
      "id_str" : "4350773712",
      "id" : 4350773712
    }, {
      "name" : "Milton Tan",
      "screen_name" : "mt_ur_mind",
      "indices" : [ 52, 63 ],
      "id_str" : "872526996814909440",
      "id" : 872526996814909440
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "843751872414564352",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17238180591887, 8.627571135910372 ]
  },
  "id_str" : "843752069374926848",
  "in_reply_to_user_id" : 1385861262,
  "text" : "@Julie_B92 @Daisy_dellaLuna @TheAtavism @JoeCursons @mt_ur_mind Surprise! \uD83D\uDE02",
  "id" : 843752069374926848,
  "in_reply_to_status_id" : 843751872414564352,
  "created_at" : "2017-03-20 09:12:24 +0000",
  "in_reply_to_screen_name" : "Julie_B92",
  "in_reply_to_user_id_str" : "1385861262",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Cock",
      "screen_name" : "pjacock",
      "indices" : [ 0, 8 ],
      "id_str" : "58756672",
      "id" : 58756672
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "843750620591001600",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17234914166208, 8.627527471312291 ]
  },
  "id_str" : "843750886908313600",
  "in_reply_to_user_id" : 58756672,
  "text" : "@pjacock I think they might have gotten a new copyright on the digitalization of these articles\u2026",
  "id" : 843750886908313600,
  "in_reply_to_status_id" : 843750620591001600,
  "created_at" : "2017-03-20 09:07:42 +0000",
  "in_reply_to_screen_name" : "pjacock",
  "in_reply_to_user_id_str" : "58756672",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "843734339183661056",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17234914166208, 8.627527471312291 ]
  },
  "id_str" : "843750046147461121",
  "in_reply_to_user_id" : 14286491,
  "text" : "Amongst other things in SciHub: JAMA articles from 1894, for which they still would charge me 22.70\u20AC to access them.",
  "id" : 843750046147461121,
  "in_reply_to_status_id" : 843734339183661056,
  "created_at" : "2017-03-20 09:04:21 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul-Olivier Dehaye",
      "screen_name" : "podehaye",
      "indices" : [ 0, 9 ],
      "id_str" : "2219841242",
      "id" : 2219841242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "843747071698124800",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17235724228883, 8.627541291898897 ]
  },
  "id_str" : "843748678309462016",
  "in_reply_to_user_id" : 2219841242,
  "text" : "@podehaye yes\u2026 crawling all of them will take a while, started with that nevertheless\u2026",
  "id" : 843748678309462016,
  "in_reply_to_status_id" : 843747071698124800,
  "created_at" : "2017-03-20 08:58:55 +0000",
  "in_reply_to_screen_name" : "podehaye",
  "in_reply_to_user_id_str" : "2219841242",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul-Olivier Dehaye",
      "screen_name" : "podehaye",
      "indices" : [ 0, 9 ],
      "id_str" : "2219841242",
      "id" : 2219841242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "843743570548981760",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17236988742614, 8.627563752712794 ]
  },
  "id_str" : "843743928738369537",
  "in_reply_to_user_id" : 2219841242,
  "text" : "@podehaye yeah, looked at that and only found \u201Emy DOI resolves to &gt;1 URL\u201C not \u201EI have 62 million DOI, how to resolve all\u201C :D",
  "id" : 843743928738369537,
  "in_reply_to_status_id" : 843743570548981760,
  "created_at" : "2017-03-20 08:40:03 +0000",
  "in_reply_to_screen_name" : "podehaye",
  "in_reply_to_user_id_str" : "2219841242",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul-Olivier Dehaye",
      "screen_name" : "podehaye",
      "indices" : [ 0, 9 ],
      "id_str" : "2219841242",
      "id" : 2219841242
    }, {
      "name" : "the Winnower",
      "screen_name" : "theWinnower",
      "indices" : [ 26, 38 ],
      "id_str" : "748018813",
      "id" : 748018813
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "843737086322708481",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17234026041788, 8.627508345236375 ]
  },
  "id_str" : "843739429525164032",
  "in_reply_to_user_id" : 2219841242,
  "text" : "@podehaye maybe the folks @theWinnower have an idea on that one?",
  "id" : 843739429525164032,
  "in_reply_to_status_id" : 843737086322708481,
  "created_at" : "2017-03-20 08:22:10 +0000",
  "in_reply_to_screen_name" : "podehaye",
  "in_reply_to_user_id_str" : "2219841242",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul-Olivier Dehaye",
      "screen_name" : "podehaye",
      "indices" : [ 0, 9 ],
      "id_str" : "2219841242",
      "id" : 2219841242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "843737086322708481",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723682594839, 8.627517968157482 ]
  },
  "id_str" : "843739315247157248",
  "in_reply_to_user_id" : 2219841242,
  "text" : "@podehaye I\u2019m trying to figure out whether one can do bulk-DOI resolving but couldn\u2019t find anything so far.",
  "id" : 843739315247157248,
  "in_reply_to_status_id" : 843737086322708481,
  "created_at" : "2017-03-20 08:21:43 +0000",
  "in_reply_to_screen_name" : "podehaye",
  "in_reply_to_user_id_str" : "2219841242",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/VfafTCaWRE",
      "expanded_url" : "https:\/\/twitter.com\/Sci_Hub\/status\/843546352219017218",
      "display_url" : "twitter.com\/Sci_Hub\/status\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17236789945873, 8.62751763247448 ]
  },
  "id_str" : "843734339183661056",
  "text" : "Has anyone already translated these to journal names &amp; publishers? https:\/\/t.co\/VfafTCaWRE",
  "id" : 843734339183661056,
  "created_at" : "2017-03-20 08:01:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sci Hub",
      "screen_name" : "Sci_Hub",
      "indices" : [ 46, 54 ],
      "id_str" : "381187236",
      "id" : 381187236
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/KltjDFcCWF",
      "expanded_url" : "https:\/\/twitter.com\/Sci_Hub\/status\/843546352219017218",
      "display_url" : "twitter.com\/Sci_Hub\/status\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "843716194939101184",
  "text" : "RT @petergrabitz: Ever wondered what articles @Sci_Hub has in store? Here is a menu! https:\/\/t.co\/KltjDFcCWF",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Sci Hub",
        "screen_name" : "Sci_Hub",
        "indices" : [ 28, 36 ],
        "id_str" : "381187236",
        "id" : 381187236
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 67, 90 ],
        "url" : "https:\/\/t.co\/KltjDFcCWF",
        "expanded_url" : "https:\/\/twitter.com\/Sci_Hub\/status\/843546352219017218",
        "display_url" : "twitter.com\/Sci_Hub\/status\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "843627394477035520",
    "text" : "Ever wondered what articles @Sci_Hub has in store? Here is a menu! https:\/\/t.co\/KltjDFcCWF",
    "id" : 843627394477035520,
    "created_at" : "2017-03-20 00:56:59 +0000",
    "user" : {
      "name" : "Peter",
      "screen_name" : "PeterRolandG",
      "protected" : false,
      "id_str" : "2396006202",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/636115977894260736\/ZadNq2eK_normal.jpg",
      "id" : 2396006202,
      "verified" : false
    }
  },
  "id" : 843716194939101184,
  "created_at" : "2017-03-20 06:49:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anne Scheel",
      "screen_name" : "annemscheel",
      "indices" : [ 3, 15 ],
      "id_str" : "320376718",
      "id" : 320376718
    }, {
      "name" : "Brad Wyble",
      "screen_name" : "bradpwyble",
      "indices" : [ 17, 28 ],
      "id_str" : "2393183286",
      "id" : 2393183286
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "843607176883191812",
  "text" : "RT @annemscheel: @bradpwyble Have you read that blog post? Two identical 7000-word book chapters? Sloppiness?!\nOr this one? https:\/\/t.co\/gE\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Brad Wyble",
        "screen_name" : "bradpwyble",
        "indices" : [ 0, 11 ],
        "id_str" : "2393183286",
        "id" : 2393183286
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 107, 130 ],
        "url" : "https:\/\/t.co\/gEVtiZKZHC",
        "expanded_url" : "http:\/\/steamtraen.blogspot.de\/2017\/03\/cornell-salutes-americas-teenage-female.html",
        "display_url" : "steamtraen.blogspot.de\/2017\/03\/cornel\u2026"
      } ]
    },
    "in_reply_to_status_id_str" : "842886195054968833",
    "geo" : { },
    "id_str" : "842886861727059971",
    "in_reply_to_user_id" : 2393183286,
    "text" : "@bradpwyble Have you read that blog post? Two identical 7000-word book chapters? Sloppiness?!\nOr this one? https:\/\/t.co\/gEVtiZKZHC",
    "id" : 842886861727059971,
    "in_reply_to_status_id" : 842886195054968833,
    "created_at" : "2017-03-17 23:54:22 +0000",
    "in_reply_to_screen_name" : "bradpwyble",
    "in_reply_to_user_id_str" : "2393183286",
    "user" : {
      "name" : "Anne Scheel",
      "screen_name" : "annemscheel",
      "protected" : false,
      "id_str" : "320376718",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/879074927462277121\/cjwxVBQV_normal.jpg",
      "id" : 320376718,
      "verified" : false
    }
  },
  "id" : 843607176883191812,
  "created_at" : "2017-03-19 23:36:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/veOVnMwcvz",
      "expanded_url" : "https:\/\/twitter.com\/annemscheel\/status\/842862687902203905",
      "display_url" : "twitter.com\/annemscheel\/st\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11392210996494, 8.753306482982111 ]
  },
  "id_str" : "843606741128527873",
  "text" : "If you\u2019ve been following the infamous pizza papers: read this and the resulting thread. https:\/\/t.co\/veOVnMwcvz",
  "id" : 843606741128527873,
  "created_at" : "2017-03-19 23:34:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kate Crawford",
      "screen_name" : "katecrawford",
      "indices" : [ 3, 16 ],
      "id_str" : "19968025",
      "id" : 19968025
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "843604815364194305",
  "text" : "RT @katecrawford: WATSON: I've said things you people wouldn't believe. All those swears will be lost in time, like tears in rain https:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 112, 135 ],
        "url" : "https:\/\/t.co\/pdhPpMFXNI",
        "expanded_url" : "https:\/\/twitter.com\/spectatorindex\/status\/843197841094950913",
        "display_url" : "twitter.com\/spectatorindex\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "843590391844782083",
    "text" : "WATSON: I've said things you people wouldn't believe. All those swears will be lost in time, like tears in rain https:\/\/t.co\/pdhPpMFXNI",
    "id" : 843590391844782083,
    "created_at" : "2017-03-19 22:29:57 +0000",
    "user" : {
      "name" : "Kate Crawford",
      "screen_name" : "katecrawford",
      "protected" : false,
      "id_str" : "19968025",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/844013024809631744\/tvoeKcfV_normal.jpg",
      "id" : 19968025,
      "verified" : true
    }
  },
  "id" : 843604815364194305,
  "created_at" : "2017-03-19 23:27:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 17, 27 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/8r52RKUeWa",
      "expanded_url" : "http:\/\/qb.cshl.edu\/genomescope\/analysis.php?code=example3",
      "display_url" : "qb.cshl.edu\/genomescope\/an\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "843587811559260161",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11406715789838, 8.753435206291195 ]
  },
  "id_str" : "843588122554306561",
  "in_reply_to_user_id" : 1096058449,
  "text" : "@Daisy_dellaLuna @Julie_B92 Jellyfish gives you a histogram for kmer coverages, can use to estimate genome size,c.f. https:\/\/t.co\/8r52RKUeWa",
  "id" : 843588122554306561,
  "in_reply_to_status_id" : 843587811559260161,
  "created_at" : "2017-03-19 22:20:56 +0000",
  "in_reply_to_screen_name" : "itatiVCS",
  "in_reply_to_user_id_str" : "1096058449",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 0, 10 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "843587650447691776",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11406715860713, 8.753435307977993 ]
  },
  "id_str" : "843587737613746176",
  "in_reply_to_user_id" : 1385861262,
  "text" : "@Julie_B92 @Daisy_dellaLuna sure, let\u2019s continue that during a more reasonable hour for Europeans :D",
  "id" : 843587737613746176,
  "in_reply_to_status_id" : 843587650447691776,
  "created_at" : "2017-03-19 22:19:24 +0000",
  "in_reply_to_screen_name" : "Julie_B92",
  "in_reply_to_user_id_str" : "1385861262",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 0, 10 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "843586574218641408",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11406715725103, 8.753435113412614 ]
  },
  "id_str" : "843587388219834372",
  "in_reply_to_user_id" : 1385861262,
  "text" : "@Julie_B92 @Daisy_dellaLuna so would be interesting to see the histogram.",
  "id" : 843587388219834372,
  "in_reply_to_status_id" : 843586574218641408,
  "created_at" : "2017-03-19 22:18:01 +0000",
  "in_reply_to_screen_name" : "Julie_B92",
  "in_reply_to_user_id_str" : "1385861262",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 17, 27 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "843586320912015361",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11406715799474, 8.753435220117353 ]
  },
  "id_str" : "843587335266713600",
  "in_reply_to_user_id" : 1096058449,
  "text" : "@Daisy_dellaLuna @Julie_B92 if you don\u2019t multiply their total length by N you\u2019ll underestimate.",
  "id" : 843587335266713600,
  "in_reply_to_status_id" : 843586320912015361,
  "created_at" : "2017-03-19 22:17:48 +0000",
  "in_reply_to_screen_name" : "itatiVCS",
  "in_reply_to_user_id_str" : "1096058449",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 17, 27 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "843586320912015361",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11406715515045, 8.753434812034262 ]
  },
  "id_str" : "843587227120816129",
  "in_reply_to_user_id" : 1096058449,
  "text" : "@Daisy_dellaLuna @Julie_B92 I think that depends on how you deal w\/ kmers that occur 2\/3\/4\/5\u2026\/n times more than expected.",
  "id" : 843587227120816129,
  "in_reply_to_status_id" : 843586320912015361,
  "created_at" : "2017-03-19 22:17:22 +0000",
  "in_reply_to_screen_name" : "itatiVCS",
  "in_reply_to_user_id_str" : "1096058449",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 17, 27 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "843585108846297092",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11406715582186, 8.753434908364099 ]
  },
  "id_str" : "843585223761772544",
  "in_reply_to_user_id" : 1096058449,
  "text" : "@Daisy_dellaLuna @Julie_B92 seems genomescope uses jellyfish output for the estimation.",
  "id" : 843585223761772544,
  "in_reply_to_status_id" : 843585108846297092,
  "created_at" : "2017-03-19 22:09:25 +0000",
  "in_reply_to_screen_name" : "itatiVCS",
  "in_reply_to_user_id_str" : "1096058449",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 0, 10 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "843584525066256384",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11406715661149, 8.753435021656474 ]
  },
  "id_str" : "843584843363618816",
  "in_reply_to_user_id" : 1385861262,
  "text" : "@Julie_B92 @Daisy_dellaLuna \u2026genome length under inclusion of repeats.",
  "id" : 843584843363618816,
  "in_reply_to_status_id" : 843584525066256384,
  "created_at" : "2017-03-19 22:07:54 +0000",
  "in_reply_to_screen_name" : "Julie_B92",
  "in_reply_to_user_id_str" : "1385861262",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 0, 10 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "843584525066256384",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11406715693771, 8.753435068461142 ]
  },
  "id_str" : "843584657669152770",
  "in_reply_to_user_id" : 1385861262,
  "text" : "@Julie_B92 @Daisy_dellaLuna yeah, but genomescope answers that question. But no clue how it deals w\/ repeats and how it estimates\u2026",
  "id" : 843584657669152770,
  "in_reply_to_status_id" : 843584525066256384,
  "created_at" : "2017-03-19 22:07:10 +0000",
  "in_reply_to_screen_name" : "Julie_B92",
  "in_reply_to_user_id_str" : "1385861262",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 0, 10 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "843583714902900736",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11406715852499, 8.753435296192965 ]
  },
  "id_str" : "843583810491088896",
  "in_reply_to_user_id" : 1385861262,
  "text" : "@Julie_B92 no, what tool did you use for converting your kmer counts into genome size estimate? :)",
  "id" : 843583810491088896,
  "in_reply_to_status_id" : 843583714902900736,
  "created_at" : "2017-03-19 22:03:48 +0000",
  "in_reply_to_screen_name" : "Julie_B92",
  "in_reply_to_user_id_str" : "1385861262",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 0, 10 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "843583371871698944",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11406715369889, 8.753434603758489 ]
  },
  "id_str" : "843583466373615617",
  "in_reply_to_user_id" : 1385861262,
  "text" : "@Julie_B92 well, what did you use for the estimation? :)",
  "id" : 843583466373615617,
  "in_reply_to_status_id" : 843583371871698944,
  "created_at" : "2017-03-19 22:02:26 +0000",
  "in_reply_to_screen_name" : "Julie_B92",
  "in_reply_to_user_id_str" : "1385861262",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 0, 10 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "843575342887567360",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11396811072235, 8.753220827773932 ]
  },
  "id_str" : "843583119840174080",
  "in_reply_to_user_id" : 1385861262,
  "text" : "@Julie_B92 how does your kmer estimate deal with repetitive parts?",
  "id" : 843583119840174080,
  "in_reply_to_status_id" : 843575342887567360,
  "created_at" : "2017-03-19 22:01:03 +0000",
  "in_reply_to_screen_name" : "Julie_B92",
  "in_reply_to_user_id_str" : "1385861262",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 53 ],
      "url" : "https:\/\/t.co\/OD77HFcuMC",
      "expanded_url" : "https:\/\/twitter.com\/EleonoreMayola\/status\/843561847647219712",
      "display_url" : "twitter.com\/EleonoreMayola\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11406984406608, 8.753435058977882 ]
  },
  "id_str" : "843573029095575555",
  "text" : "We should all learn Finnish \uD83D\uDE02 https:\/\/t.co\/OD77HFcuMC",
  "id" : 843573029095575555,
  "created_at" : "2017-03-19 21:20:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 84 ],
      "url" : "https:\/\/t.co\/DeZQwbTrM3",
      "expanded_url" : "https:\/\/magenta.as\/this-is-what-happens-at-a-feminist-edit-a-thon-for-wikipedia-15baea4ac8cd#.3hc24xhuy",
      "display_url" : "magenta.as\/this-is-what-h\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "843521141591425024",
  "text" : "This Is What Happens at a Feminist Edit-a-Thon for Wikipedia https:\/\/t.co\/DeZQwbTrM3",
  "id" : 843521141591425024,
  "created_at" : "2017-03-19 17:54:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 74 ],
      "url" : "https:\/\/t.co\/NJBquZ8iHp",
      "expanded_url" : "https:\/\/www.nytimes.com\/2017\/03\/10\/opinion\/sunday\/can-sleep-deprivation-cure-depression.html?nytmobile=0",
      "display_url" : "nytimes.com\/2017\/03\/10\/opi\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "843512277265498112",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11406716082262, 8.753435024538456 ]
  },
  "id_str" : "843512435319488512",
  "in_reply_to_user_id" : 14286491,
  "text" : "From \u00ABYes, Your Sleep Schedule Is Making You Sick\u00BB https:\/\/t.co\/NJBquZ8iHp",
  "id" : 843512435319488512,
  "in_reply_to_status_id" : 843512277265498112,
  "created_at" : "2017-03-19 17:20:10 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.114067165377, 8.753435023526496 ]
  },
  "id_str" : "843512277265498112",
  "text" : "\u00ABYou cannot patent sleep deprivation or light, so there is little financial incentive to invest in this treatment or research.\u00BB",
  "id" : 843512277265498112,
  "created_at" : "2017-03-19 17:19:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 8, 31 ],
      "url" : "https:\/\/t.co\/jurAapu8yU",
      "expanded_url" : "http:\/\/www.smbc-comics.com\/comic\/a-proposal-2",
      "display_url" : "smbc-comics.com\/comic\/a-propos\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "843431730665132032",
  "text" : "Awkward https:\/\/t.co\/jurAapu8yU",
  "id" : 843431730665132032,
  "created_at" : "2017-03-19 11:59:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ABC News",
      "screen_name" : "ABC",
      "indices" : [ 3, 7 ],
      "id_str" : "28785486",
      "id" : 28785486
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "843225552945401857",
  "text" : "RT @ABC: BREAKING: Legendary rock and roll songwriter and guitarist Chuck Berry dies at 90, St. Charles County Police Department says. http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ABC\/status\/843222685861732353\/photo\/1",
        "indices" : [ 126, 149 ],
        "url" : "https:\/\/t.co\/dKg6P2cAbX",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/C7O6kAFXUAEmWD7.jpg",
        "id_str" : "843222682908971009",
        "id" : 843222682908971009,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C7O6kAFXUAEmWD7.jpg",
        "sizes" : [ {
          "h" : 1311,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 2203,
          "resize" : "fit",
          "w" : 3442
        }, {
          "h" : 435,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/dKg6P2cAbX"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "843222685861732353",
    "text" : "BREAKING: Legendary rock and roll songwriter and guitarist Chuck Berry dies at 90, St. Charles County Police Department says. https:\/\/t.co\/dKg6P2cAbX",
    "id" : 843222685861732353,
    "created_at" : "2017-03-18 22:08:49 +0000",
    "user" : {
      "name" : "ABC News",
      "screen_name" : "ABC",
      "protected" : false,
      "id_str" : "28785486",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/877547979363758080\/ny06RNTT_normal.jpg",
      "id" : 28785486,
      "verified" : true
    }
  },
  "id" : 843225552945401857,
  "created_at" : "2017-03-18 22:20:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nyborg",
      "screen_name" : "ny_borg",
      "indices" : [ 0, 8 ],
      "id_str" : "570156398",
      "id" : 570156398
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "843152560982835201",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11396058783767, 8.753583599582676 ]
  },
  "id_str" : "843210695403585537",
  "in_reply_to_user_id" : 570156398,
  "text" : "@ny_borg I\u2019d prefer the Sword Coast over Skyrim. \uD83D\uDE02",
  "id" : 843210695403585537,
  "in_reply_to_status_id" : 843152560982835201,
  "created_at" : "2017-03-18 21:21:10 +0000",
  "in_reply_to_screen_name" : "ny_borg",
  "in_reply_to_user_id_str" : "570156398",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 4, 13 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/843210313210236928\/photo\/1",
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/o1Q5OPi3ZV",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/C7OvR-OW4AALeez.jpg",
      "id_str" : "843210278544269312",
      "id" : 843210278544269312,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C7OvR-OW4AALeez.jpg",
      "sizes" : [ {
        "h" : 4032,
        "resize" : "fit",
        "w" : 3024
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      } ],
      "display_url" : "pic.twitter.com\/o1Q5OPi3ZV"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11396058783767, 8.753583599582676 ]
  },
  "id_str" : "843210313210236928",
  "text" : "Why @Senficon is my favorite politician, number 1256: bringing over 800 g of delicious Icelandic licorice-chocolate. https:\/\/t.co\/o1Q5OPi3ZV",
  "id" : 843210313210236928,
  "created_at" : "2017-03-18 21:19:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/843140824787509248\/photo\/1",
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/1geiai4yXy",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/C7NwHJKXUAAPCIg.jpg",
      "id_str" : "843140823269199872",
      "id" : 843140823269199872,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C7NwHJKXUAAPCIg.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 576
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 576
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 383
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 576
      } ],
      "display_url" : "pic.twitter.com\/1geiai4yXy"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "843140824787509248",
  "text" : "It's good to see that Google has no clue where I might want to get married. https:\/\/t.co\/1geiai4yXy",
  "id" : 843140824787509248,
  "created_at" : "2017-03-18 16:43:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 3, 11 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "843046027808690177",
  "text" : "RT @o_guest: Blog post on Matlab! Thank you everybody &amp; enjoy! \uD83D\uDE0A\u2728\uD83D\uDC96\n\nI hate Matlab: How an IDE, a language, and a mentality harm\nhttps:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/o_guest\/status\/842794088315404288\/photo\/1",
        "indices" : [ 143, 166 ],
        "url" : "https:\/\/t.co\/h961QVLNuP",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/C7I0Z7fWwAEXseo.png",
        "id_str" : "842793700342284289",
        "id" : 842793700342284289,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C7I0Z7fWwAEXseo.png",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 500,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 500,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 500,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 500,
          "resize" : "fit",
          "w" : 500
        } ],
        "display_url" : "pic.twitter.com\/h961QVLNuP"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 119, 142 ],
        "url" : "https:\/\/t.co\/WEkpxGOCcD",
        "expanded_url" : "http:\/\/neuroplausible.com\/matlab",
        "display_url" : "neuroplausible.com\/matlab"
      } ]
    },
    "geo" : { },
    "id_str" : "842794088315404288",
    "text" : "Blog post on Matlab! Thank you everybody &amp; enjoy! \uD83D\uDE0A\u2728\uD83D\uDC96\n\nI hate Matlab: How an IDE, a language, and a mentality harm\nhttps:\/\/t.co\/WEkpxGOCcD https:\/\/t.co\/h961QVLNuP",
    "id" : 842794088315404288,
    "created_at" : "2017-03-17 17:45:43 +0000",
    "user" : {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "protected" : false,
      "id_str" : "3865005196",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/844972791732584453\/mdSj6vOd_normal.jpg",
      "id" : 3865005196,
      "verified" : false
    }
  },
  "id" : 843046027808690177,
  "created_at" : "2017-03-18 10:26:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nyborg",
      "screen_name" : "ny_borg",
      "indices" : [ 0, 8 ],
      "id_str" : "570156398",
      "id" : 570156398
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "842994924652040193",
  "geo" : { },
  "id_str" : "843042726857887744",
  "in_reply_to_user_id" : 570156398,
  "text" : "@ny_borg und daf\u00FCr muss ich l\u00E4nger auf meine Lakritz-\u00DCberdosis warten?! \uD83D\uDE02",
  "id" : 843042726857887744,
  "in_reply_to_status_id" : 842994924652040193,
  "created_at" : "2017-03-18 10:13:43 +0000",
  "in_reply_to_screen_name" : "ny_borg",
  "in_reply_to_user_id_str" : "570156398",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nyborg",
      "screen_name" : "ny_borg",
      "indices" : [ 0, 8 ],
      "id_str" : "570156398",
      "id" : 570156398
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "842988782781718530",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11406963624624, 8.753433240755927 ]
  },
  "id_str" : "843016519105822721",
  "in_reply_to_user_id" : 570156398,
  "text" : "@ny_borg \uD83D\uDE0D\uD83D\uDC96\uD83D\uDC4D",
  "id" : 843016519105822721,
  "in_reply_to_status_id" : 842988782781718530,
  "created_at" : "2017-03-18 08:29:35 +0000",
  "in_reply_to_screen_name" : "ny_borg",
  "in_reply_to_user_id_str" : "570156398",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 64 ],
      "url" : "https:\/\/t.co\/XhD9N3GaPU",
      "expanded_url" : "https:\/\/instagram.com\/p\/BRwG7KyFXrb\/",
      "display_url" : "instagram.com\/p\/BRwG7KyFXrb\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11397317522216, 8.752920906998918 ]
  },
  "id_str" : "842829947785957376",
  "text" : "Love these not-so-subtle sub-Instagrams. https:\/\/t.co\/XhD9N3GaPU",
  "id" : 842829947785957376,
  "created_at" : "2017-03-17 20:08:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 3, 19 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 90 ],
      "url" : "https:\/\/t.co\/5rnOrAslHG",
      "expanded_url" : "https:\/\/twitter.com\/dog_rates\/status\/842536828276228096",
      "display_url" : "twitter.com\/dog_rates\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "842829537226489859",
  "text" : "RT @gedankenstuecke: Guess who\u2019s more legit than Julian Assange \uD83D\uDC36\uD83D\uDE02 https:\/\/t.co\/5rnOrAslHG",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 46, 69 ],
        "url" : "https:\/\/t.co\/5rnOrAslHG",
        "expanded_url" : "https:\/\/twitter.com\/dog_rates\/status\/842536828276228096",
        "display_url" : "twitter.com\/dog_rates\/stat\u2026"
      } ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 50.12432278499853, 8.917480614469767 ]
    },
    "id_str" : "842635800726704129",
    "text" : "Guess who\u2019s more legit than Julian Assange \uD83D\uDC36\uD83D\uDE02 https:\/\/t.co\/5rnOrAslHG",
    "id" : 842635800726704129,
    "created_at" : "2017-03-17 07:16:44 +0000",
    "user" : {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "protected" : false,
      "id_str" : "14286491",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
      "id" : 14286491,
      "verified" : true
    }
  },
  "id" : 842829537226489859,
  "created_at" : "2017-03-17 20:06:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "VALIUM",
      "screen_name" : "alibi_rage",
      "indices" : [ 0, 11 ],
      "id_str" : "971867420",
      "id" : 971867420
    }, {
      "name" : "Seb in Action!",
      "screen_name" : "SebInAction",
      "indices" : [ 12, 24 ],
      "id_str" : "448328735",
      "id" : 448328735
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "842790044461088769",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11405012169202, 8.753332650796697 ]
  },
  "id_str" : "842829440681951235",
  "in_reply_to_user_id" : 971867420,
  "text" : "@alibi_rage @SebInAction I knew it all along!",
  "id" : 842829440681951235,
  "in_reply_to_status_id" : 842790044461088769,
  "created_at" : "2017-03-17 20:06:12 +0000",
  "in_reply_to_screen_name" : "alibi_rage",
  "in_reply_to_user_id_str" : "971867420",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u24EA Rik Smith-Unna \uD83C\uDDF0\uD83C\uDDEA",
      "screen_name" : "blahah404",
      "indices" : [ 0, 10 ],
      "id_str" : "99173786",
      "id" : 99173786
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "842780573940797441",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11407004925893, 8.753433548194039 ]
  },
  "id_str" : "842780738441437185",
  "in_reply_to_user_id" : 99173786,
  "text" : "@blahah404 can\u2019t wait for the \uD83D\uDCA9 emoji be verified before he is \uD83D\uDE18",
  "id" : 842780738441437185,
  "in_reply_to_status_id" : 842780573940797441,
  "created_at" : "2017-03-17 16:52:40 +0000",
  "in_reply_to_screen_name" : "blahah404",
  "in_reply_to_user_id_str" : "99173786",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Terry McGlynn",
      "screen_name" : "hormiga",
      "indices" : [ 3, 11 ],
      "id_str" : "10328012",
      "id" : 10328012
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "842761981417406465",
  "text" : "RT @hormiga: 1. Dude is in charge\n2. Undergraduates are useless\n3. Everybody is white.\n4. Look at that horrible pipet technique.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "842760884531421185",
    "geo" : { },
    "id_str" : "842761280486342657",
    "in_reply_to_user_id" : 10328012,
    "text" : "1. Dude is in charge\n2. Undergraduates are useless\n3. Everybody is white.\n4. Look at that horrible pipet technique.",
    "id" : 842761280486342657,
    "in_reply_to_status_id" : 842760884531421185,
    "created_at" : "2017-03-17 15:35:21 +0000",
    "in_reply_to_screen_name" : "hormiga",
    "in_reply_to_user_id_str" : "10328012",
    "user" : {
      "name" : "Terry McGlynn",
      "screen_name" : "hormiga",
      "protected" : false,
      "id_str" : "10328012",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/598149093337092096\/YArgwOG7_normal.jpg",
      "id" : 10328012,
      "verified" : true
    }
  },
  "id" : 842761981417406465,
  "created_at" : "2017-03-17 15:38:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Terry McGlynn",
      "screen_name" : "hormiga",
      "indices" : [ 3, 11 ],
      "id_str" : "10328012",
      "id" : 10328012
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/hoLxzvlkFe",
      "expanded_url" : "https:\/\/twitter.com\/sketchscience\/status\/840900998587662336",
      "display_url" : "twitter.com\/sketchscience\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "842761964875124737",
  "text" : "RT @hormiga: This image encapsulates 98% of what we need to fix in the culture of science. https:\/\/t.co\/hoLxzvlkFe",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 78, 101 ],
        "url" : "https:\/\/t.co\/hoLxzvlkFe",
        "expanded_url" : "https:\/\/twitter.com\/sketchscience\/status\/840900998587662336",
        "display_url" : "twitter.com\/sketchscience\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "842760884531421185",
    "text" : "This image encapsulates 98% of what we need to fix in the culture of science. https:\/\/t.co\/hoLxzvlkFe",
    "id" : 842760884531421185,
    "created_at" : "2017-03-17 15:33:47 +0000",
    "user" : {
      "name" : "Terry McGlynn",
      "screen_name" : "hormiga",
      "protected" : false,
      "id_str" : "10328012",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/598149093337092096\/YArgwOG7_normal.jpg",
      "id" : 10328012,
      "verified" : true
    }
  },
  "id" : 842761964875124737,
  "created_at" : "2017-03-17 15:38:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Spotify",
      "screen_name" : "Spotify",
      "indices" : [ 9, 17 ],
      "id_str" : "17230018",
      "id" : 17230018
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17234787331451, 8.62754149887117 ]
  },
  "id_str" : "842757577457000448",
  "text" : "When the @Spotify app loses your login credentials and wants to download all offline available songs again: Downloading 32 of 1703. \uD83D\uDE34",
  "id" : 842757577457000448,
  "created_at" : "2017-03-17 15:20:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "VALIUM",
      "screen_name" : "alibi_rage",
      "indices" : [ 0, 11 ],
      "id_str" : "971867420",
      "id" : 971867420
    }, {
      "name" : "Seb in Action!",
      "screen_name" : "SebInAction",
      "indices" : [ 18, 30 ],
      "id_str" : "448328735",
      "id" : 448328735
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "842746603572285440",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17236610157889, 8.627539836011682 ]
  },
  "id_str" : "842755062334197760",
  "in_reply_to_user_id" : 971867420,
  "text" : "@alibi_rage wurde @SebInAction verh\u00F6rt? :D",
  "id" : 842755062334197760,
  "in_reply_to_status_id" : 842746603572285440,
  "created_at" : "2017-03-17 15:10:39 +0000",
  "in_reply_to_screen_name" : "alibi_rage",
  "in_reply_to_user_id_str" : "971867420",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Effy Vayena",
      "screen_name" : "EffyVayena",
      "indices" : [ 3, 14 ],
      "id_str" : "397518511",
      "id" : 397518511
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Google",
      "indices" : [ 28, 35 ]
    }, {
      "text" : "NHS",
      "indices" : [ 47, 51 ]
    } ],
    "urls" : [ {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/IGLHBbeY8B",
      "expanded_url" : "http:\/\/www.bbc.com\/news\/technology-39301901",
      "display_url" : "bbc.com\/news\/technolog\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "842748091744894977",
  "text" : "RT @EffyVayena: Here we go: #Google DeepMind's #NHS deal under scrutiny https:\/\/t.co\/IGLHBbeY8B",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Google",
        "indices" : [ 12, 19 ]
      }, {
        "text" : "NHS",
        "indices" : [ 31, 35 ]
      } ],
      "urls" : [ {
        "indices" : [ 56, 79 ],
        "url" : "https:\/\/t.co\/IGLHBbeY8B",
        "expanded_url" : "http:\/\/www.bbc.com\/news\/technology-39301901",
        "display_url" : "bbc.com\/news\/technolog\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "842736113211097088",
    "text" : "Here we go: #Google DeepMind's #NHS deal under scrutiny https:\/\/t.co\/IGLHBbeY8B",
    "id" : 842736113211097088,
    "created_at" : "2017-03-17 13:55:21 +0000",
    "user" : {
      "name" : "Effy Vayena",
      "screen_name" : "EffyVayena",
      "protected" : false,
      "id_str" : "397518511",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/837580905615085568\/EBU1zR7D_normal.jpg",
      "id" : 397518511,
      "verified" : false
    }
  },
  "id" : 842748091744894977,
  "created_at" : "2017-03-17 14:42:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Razib Khan",
      "screen_name" : "razibkhan",
      "indices" : [ 0, 10 ],
      "id_str" : "35304791",
      "id" : 35304791
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "842742572409917440",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17238439736614, 8.627593705733027 ]
  },
  "id_str" : "842742921401159681",
  "in_reply_to_user_id" : 35304791,
  "text" : "@razibkhan ah, don\u2019t know any of the authors, but the title weirded me out right out of the gate.",
  "id" : 842742921401159681,
  "in_reply_to_status_id" : 842742572409917440,
  "created_at" : "2017-03-17 14:22:24 +0000",
  "in_reply_to_screen_name" : "razibkhan",
  "in_reply_to_user_id_str" : "35304791",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/wEa5RMEKWv",
      "expanded_url" : "http:\/\/journals.plos.org\/plosgenetics\/article?id=10.1371\/journal.pgen.1006616",
      "display_url" : "journals.plos.org\/plosgenetics\/a\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17234149262861, 8.627544958127137 ]
  },
  "id_str" : "842740794721271809",
  "text" : "Is it just me being irked out by \u201EInvestigating the case of human nose shape\u201C between populations? https:\/\/t.co\/wEa5RMEKWv",
  "id" : 842740794721271809,
  "created_at" : "2017-03-17 14:13:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 0, 10 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "842699277939949568",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17241458699612, 8.627529776209238 ]
  },
  "id_str" : "842706491954155520",
  "in_reply_to_user_id" : 1385861262,
  "text" : "@Julie_B92 does it contain milk? That\u2019s a sin that German hummus companies commit.",
  "id" : 842706491954155520,
  "in_reply_to_status_id" : 842699277939949568,
  "created_at" : "2017-03-17 11:57:39 +0000",
  "in_reply_to_screen_name" : "Julie_B92",
  "in_reply_to_user_id_str" : "1385861262",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 70 ],
      "url" : "https:\/\/t.co\/CIX8UdjcQ7",
      "expanded_url" : "http:\/\/www.atlasobscura.com\/articles\/bad-guinness-pour-canada-ireland",
      "display_url" : "atlasobscura.com\/articles\/bad-g\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1724034142716, 8.627532821906774 ]
  },
  "id_str" : "842691988034064387",
  "text" : "\u00ABJesus wept when he saw our pint of Guinness.\u00BB https:\/\/t.co\/CIX8UdjcQ7",
  "id" : 842691988034064387,
  "created_at" : "2017-03-17 11:00:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GF(\u00AF\\_(\uD83D\uDC2C)_\/\u00AF)",
      "screen_name" : "hdevalence",
      "indices" : [ 3, 14 ],
      "id_str" : "529148230",
      "id" : 529148230
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 72 ],
      "url" : "https:\/\/t.co\/EtbAAB9lDp",
      "expanded_url" : "https:\/\/medium.com\/@hdevalence\/when-hell-kept-on-payroll-somewhere-is-where-you-are-f419d3022d0#.mnoy3ivw7",
      "display_url" : "medium.com\/@hdevalence\/wh\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "842674998338830336",
  "text" : "RT @hdevalence: I wrote about why I quit my PhD: https:\/\/t.co\/EtbAAB9lDp",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 33, 56 ],
        "url" : "https:\/\/t.co\/EtbAAB9lDp",
        "expanded_url" : "https:\/\/medium.com\/@hdevalence\/when-hell-kept-on-payroll-somewhere-is-where-you-are-f419d3022d0#.mnoy3ivw7",
        "display_url" : "medium.com\/@hdevalence\/wh\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "842526511915786240",
    "text" : "I wrote about why I quit my PhD: https:\/\/t.co\/EtbAAB9lDp",
    "id" : 842526511915786240,
    "created_at" : "2017-03-17 00:02:28 +0000",
    "user" : {
      "name" : "GF(\u00AF\\_(\uD83D\uDC2C)_\/\u00AF)",
      "screen_name" : "hdevalence",
      "protected" : false,
      "id_str" : "529148230",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/690675173557702657\/iVh_MJij_normal.jpg",
      "id" : 529148230,
      "verified" : false
    }
  },
  "id" : 842674998338830336,
  "created_at" : "2017-03-17 09:52:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 69 ],
      "url" : "https:\/\/t.co\/5rnOrAslHG",
      "expanded_url" : "https:\/\/twitter.com\/dog_rates\/status\/842536828276228096",
      "display_url" : "twitter.com\/dog_rates\/stat\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.12432278499853, 8.917480614469767 ]
  },
  "id_str" : "842635800726704129",
  "text" : "Guess who\u2019s more legit than Julian Assange \uD83D\uDC36\uD83D\uDE02 https:\/\/t.co\/5rnOrAslHG",
  "id" : 842635800726704129,
  "created_at" : "2017-03-17 07:16:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mozwow",
      "indices" : [ 20, 27 ]
    } ],
    "urls" : [ {
      "indices" : [ 39, 62 ],
      "url" : "https:\/\/t.co\/jihnXg5CWU",
      "expanded_url" : "https:\/\/twitter.com\/frameshiftllc\/status\/842501795930767360",
      "display_url" : "twitter.com\/frameshiftllc\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11406726999999, 8.753451289999996 ]
  },
  "id_str" : "842510976809385984",
  "text" : "Check this one out, #mozwow attendees! https:\/\/t.co\/jihnXg5CWU",
  "id" : 842510976809385984,
  "created_at" : "2017-03-16 23:00:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1140672700004, 8.753451289999116 ]
  },
  "id_str" : "842510451753832449",
  "text" : "\u00ABThe logfiles say I miss you 50% more than you miss me while I\u2019m travelling.\u00BB Everyone should learn regex and text processing.",
  "id" : 842510451753832449,
  "created_at" : "2017-03-16 22:58:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emanuel Wyler",
      "screen_name" : "ewyler",
      "indices" : [ 0, 7 ],
      "id_str" : "122329006",
      "id" : 122329006
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "842489090155184130",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11406727025594, 8.75345128944746 ]
  },
  "id_str" : "842489674392375298",
  "in_reply_to_user_id" : 122329006,
  "text" : "@ewyler oh, hadn\u2019t seen that!",
  "id" : 842489674392375298,
  "in_reply_to_status_id" : 842489090155184130,
  "created_at" : "2017-03-16 21:36:05 +0000",
  "in_reply_to_screen_name" : "ewyler",
  "in_reply_to_user_id_str" : "122329006",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PLOS ONE",
      "screen_name" : "PLOSONE",
      "indices" : [ 30, 38 ],
      "id_str" : "27596259",
      "id" : 27596259
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11406727025594, 8.75345128944746 ]
  },
  "id_str" : "842487602481643523",
  "text" : "Can someone explain to me why @PLOSONE does not accept any reasonable vector graphic formats but rather wants TIFFs for figures?",
  "id" : 842487602481643523,
  "created_at" : "2017-03-16 21:27:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bi\u24D0nca Kramer",
      "screen_name" : "MsPhelps",
      "indices" : [ 3, 12 ],
      "id_str" : "22963112",
      "id" : 22963112
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "scholcomm",
      "indices" : [ 107, 117 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "842483288606474240",
  "text" : "RT @MsPhelps: I'm hearing lots of interest in the idea of decision trees to elucidate paths and choices in #scholcomm - let's make them in\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "scholcomm",
        "indices" : [ 93, 103 ]
      } ],
      "urls" : [ {
        "indices" : [ 137, 160 ],
        "url" : "https:\/\/t.co\/noSQ2CbpCi",
        "expanded_url" : "https:\/\/twitter.com\/force11rescomm\/status\/840262408224546817",
        "display_url" : "twitter.com\/force11rescomm\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "842483118821072897",
    "text" : "I'm hearing lots of interest in the idea of decision trees to elucidate paths and choices in #scholcomm - let's make them in a good way! https:\/\/t.co\/noSQ2CbpCi",
    "id" : 842483118821072897,
    "created_at" : "2017-03-16 21:10:02 +0000",
    "user" : {
      "name" : "Bi\u24D0nca Kramer",
      "screen_name" : "MsPhelps",
      "protected" : false,
      "id_str" : "22963112",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/665529153576390660\/ukieWtR4_normal.jpg",
      "id" : 22963112,
      "verified" : false
    }
  },
  "id" : 842483288606474240,
  "created_at" : "2017-03-16 21:10:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "shereen",
      "screen_name" : "shereeny",
      "indices" : [ 3, 12 ],
      "id_str" : "612159362",
      "id" : 612159362
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/shereeny\/status\/842092159440453638\/photo\/1",
      "indices" : [ 42, 65 ],
      "url" : "https:\/\/t.co\/bqY6F7ObVU",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/C6-2WldXAAkepIM.jpg",
      "id_str" : "842092154470203401",
      "id" : 842092154470203401,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C6-2WldXAAkepIM.jpg",
      "sizes" : [ {
        "h" : 680,
        "resize" : "fit",
        "w" : 650
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 748,
        "resize" : "fit",
        "w" : 715
      }, {
        "h" : 748,
        "resize" : "fit",
        "w" : 715
      }, {
        "h" : 748,
        "resize" : "fit",
        "w" : 715
      } ],
      "display_url" : "pic.twitter.com\/bqY6F7ObVU"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 41 ],
      "url" : "https:\/\/t.co\/O4KNPyhnMx",
      "expanded_url" : "https:\/\/thenib.com\/never-again",
      "display_url" : "thenib.com\/never-again"
    } ]
  },
  "geo" : { },
  "id_str" : "842478978019610624",
  "text" : "RT @shereeny: oof https:\/\/t.co\/O4KNPyhnMx https:\/\/t.co\/bqY6F7ObVU",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/shereeny\/status\/842092159440453638\/photo\/1",
        "indices" : [ 28, 51 ],
        "url" : "https:\/\/t.co\/bqY6F7ObVU",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/C6-2WldXAAkepIM.jpg",
        "id_str" : "842092154470203401",
        "id" : 842092154470203401,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C6-2WldXAAkepIM.jpg",
        "sizes" : [ {
          "h" : 680,
          "resize" : "fit",
          "w" : 650
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 748,
          "resize" : "fit",
          "w" : 715
        }, {
          "h" : 748,
          "resize" : "fit",
          "w" : 715
        }, {
          "h" : 748,
          "resize" : "fit",
          "w" : 715
        } ],
        "display_url" : "pic.twitter.com\/bqY6F7ObVU"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 4, 27 ],
        "url" : "https:\/\/t.co\/O4KNPyhnMx",
        "expanded_url" : "https:\/\/thenib.com\/never-again",
        "display_url" : "thenib.com\/never-again"
      } ]
    },
    "geo" : { },
    "id_str" : "842092159440453638",
    "text" : "oof https:\/\/t.co\/O4KNPyhnMx https:\/\/t.co\/bqY6F7ObVU",
    "id" : 842092159440453638,
    "created_at" : "2017-03-15 19:16:30 +0000",
    "user" : {
      "name" : "shereen",
      "screen_name" : "shereeny",
      "protected" : false,
      "id_str" : "612159362",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/918120246355156992\/KEK9rw7W_normal.jpg",
      "id" : 612159362,
      "verified" : false
    }
  },
  "id" : 842478978019610624,
  "created_at" : "2017-03-16 20:53:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Head",
      "screen_name" : "betatim",
      "indices" : [ 0, 8 ],
      "id_str" : "18881614",
      "id" : 18881614
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "842471607251685376",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11406724817381, 8.753451337117683 ]
  },
  "id_str" : "842472904197574660",
  "in_reply_to_user_id" : 18881614,
  "text" : "@betatim don\u2019t know whether this or \u201Ethe Mark Zuckerberg of\u2026\u201C hurts more :p",
  "id" : 842472904197574660,
  "in_reply_to_status_id" : 842471607251685376,
  "created_at" : "2017-03-16 20:29:27 +0000",
  "in_reply_to_screen_name" : "betatim",
  "in_reply_to_user_id_str" : "18881614",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Monica Munoz-Torres",
      "screen_name" : "monimunozto",
      "indices" : [ 3, 15 ],
      "id_str" : "538714687",
      "id" : 538714687
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BOSC2017",
      "indices" : [ 78, 87 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/Fk2OgPZd57",
      "expanded_url" : "https:\/\/twitter.com\/OBF_BOSC\/status\/838824572652695553",
      "display_url" : "twitter.com\/OBF_BOSC\/statu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "842444439108882432",
  "text" : "RT @monimunozto: Come join us this summer in Prague! Submit your abstract for #BOSC2017. https:\/\/t.co\/Fk2OgPZd57",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BOSC2017",
        "indices" : [ 61, 70 ]
      } ],
      "urls" : [ {
        "indices" : [ 72, 95 ],
        "url" : "https:\/\/t.co\/Fk2OgPZd57",
        "expanded_url" : "https:\/\/twitter.com\/OBF_BOSC\/status\/838824572652695553",
        "display_url" : "twitter.com\/OBF_BOSC\/statu\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "839217466744037376",
    "text" : "Come join us this summer in Prague! Submit your abstract for #BOSC2017. https:\/\/t.co\/Fk2OgPZd57",
    "id" : 839217466744037376,
    "created_at" : "2017-03-07 20:53:30 +0000",
    "user" : {
      "name" : "Monica Munoz-Torres",
      "screen_name" : "monimunozto",
      "protected" : false,
      "id_str" : "538714687",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/713239690309083136\/QlP8BsHj_normal.jpg",
      "id" : 538714687,
      "verified" : false
    }
  },
  "id" : 842444439108882432,
  "created_at" : "2017-03-16 18:36:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Heart",
      "screen_name" : "theheartradio",
      "indices" : [ 3, 17 ],
      "id_str" : "439651218",
      "id" : 439651218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "842437405214969858",
  "text" : "RT @theheartradio: We're proud to feature an ep. from How to Be a Girl. Click through for ways to help protect trans rights. \u2764\uFE0F\n\nhttps:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/theheartradio\/status\/842153001976496128\/photo\/1",
        "indices" : [ 134, 157 ],
        "url" : "https:\/\/t.co\/5VIx3qaIVh",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/C6_s6M9VwAYZqOm.jpg",
        "id_str" : "842152139996643334",
        "id" : 842152139996643334,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C6_s6M9VwAYZqOm.jpg",
        "sizes" : [ {
          "h" : 720,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 1229,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 1229,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 408,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/5VIx3qaIVh"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 110, 133 ],
        "url" : "https:\/\/t.co\/9HXDjXJlD3",
        "expanded_url" : "http:\/\/www.theheartradio.org\/solos\/bathroombill",
        "display_url" : "theheartradio.org\/solos\/bathroom\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "842153001976496128",
    "text" : "We're proud to feature an ep. from How to Be a Girl. Click through for ways to help protect trans rights. \u2764\uFE0F\n\nhttps:\/\/t.co\/9HXDjXJlD3 https:\/\/t.co\/5VIx3qaIVh",
    "id" : 842153001976496128,
    "created_at" : "2017-03-15 23:18:16 +0000",
    "user" : {
      "name" : "The Heart",
      "screen_name" : "theheartradio",
      "protected" : false,
      "id_str" : "439651218",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/524354484097404928\/pZTB369Y_normal.jpeg",
      "id" : 439651218,
      "verified" : true
    }
  },
  "id" : 842437405214969858,
  "created_at" : "2017-03-16 18:08:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 123, 146 ],
      "url" : "https:\/\/t.co\/hUGp7koVOM",
      "expanded_url" : "https:\/\/twitter.com\/kevincollier\/status\/842071609510899727",
      "display_url" : "twitter.com\/kevincollier\/s\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11406942016475, 8.753433552643255 ]
  },
  "id_str" : "842436407381614592",
  "text" : "Didn\u2019t he read the verification requirements? One needs to present a passport outside of an embassy to get the check mark. https:\/\/t.co\/hUGp7koVOM",
  "id" : 842436407381614592,
  "created_at" : "2017-03-16 18:04:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 3, 13 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 45 ],
      "url" : "https:\/\/t.co\/MOLKN3uJYT",
      "expanded_url" : "https:\/\/twitter.com\/kejames\/status\/842351427871756288",
      "display_url" : "twitter.com\/kejames\/status\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "842433674855518208",
  "text" : "RT @Julie_B92: Thread https:\/\/t.co\/MOLKN3uJYT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 7, 30 ],
        "url" : "https:\/\/t.co\/MOLKN3uJYT",
        "expanded_url" : "https:\/\/twitter.com\/kejames\/status\/842351427871756288",
        "display_url" : "twitter.com\/kejames\/status\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "842433466675433473",
    "text" : "Thread https:\/\/t.co\/MOLKN3uJYT",
    "id" : 842433466675433473,
    "created_at" : "2017-03-16 17:52:44 +0000",
    "user" : {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "protected" : false,
      "id_str" : "1385861262",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/813827716151644160\/JvmX-W-T_normal.jpg",
      "id" : 1385861262,
      "verified" : false
    }
  },
  "id" : 842433674855518208,
  "created_at" : "2017-03-16 17:53:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 46 ],
      "url" : "https:\/\/t.co\/YPZIo4ymeK",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BRtNTA6DGyt\/",
      "display_url" : "instagram.com\/p\/BRtNTA6DGyt\/"
    } ]
  },
  "geo" : { },
  "id_str" : "842418179238440960",
  "text" : "For analog note taking https:\/\/t.co\/YPZIo4ymeK",
  "id" : 842418179238440960,
  "created_at" : "2017-03-16 16:51:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Genome Biology",
      "screen_name" : "GenomeBiology",
      "indices" : [ 0, 14 ],
      "id_str" : "115039678",
      "id" : 115039678
    }, {
      "name" : "Mick Watson",
      "screen_name" : "BioMickWatson",
      "indices" : [ 15, 29 ],
      "id_str" : "228586748",
      "id" : 228586748
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "842408725205905409",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17233279448768, 8.627521054177404 ]
  },
  "id_str" : "842410008096718848",
  "in_reply_to_user_id" : 115039678,
  "text" : "@GenomeBiology @BioMickWatson Latest EGGCODE paper says 80% of eggs are tasty.",
  "id" : 842410008096718848,
  "in_reply_to_status_id" : 842408725205905409,
  "created_at" : "2017-03-16 16:19:31 +0000",
  "in_reply_to_screen_name" : "GenomeBiology",
  "in_reply_to_user_id_str" : "115039678",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 71 ],
      "url" : "https:\/\/t.co\/qf9PgW1vVn",
      "expanded_url" : "https:\/\/twitter.com\/TheLabAndField\/status\/842407866996781056",
      "display_url" : "twitter.com\/TheLabAndField\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17235749830717, 8.62752876542664 ]
  },
  "id_str" : "842408280643231744",
  "text" : "brb, just need to incorporate 10 Eggs Genomics\u2122 https:\/\/t.co\/qf9PgW1vVn",
  "id" : 842408280643231744,
  "created_at" : "2017-03-16 16:12:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 68 ],
      "url" : "https:\/\/t.co\/8CgEokTod2",
      "expanded_url" : "https:\/\/twitter.com\/BioMickWatson\/status\/842406576359112704",
      "display_url" : "twitter.com\/BioMickWatson\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17236309805391, 8.627530682702488 ]
  },
  "id_str" : "842407665556967426",
  "text" : "Do it ten times and you get a HiSeq Eggs 10. https:\/\/t.co\/8CgEokTod2",
  "id" : 842407665556967426,
  "created_at" : "2017-03-16 16:10:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uD83D\uDC9A Aure Moser \uD83D\uDC9A",
      "screen_name" : "auremoser",
      "indices" : [ 100, 110 ],
      "id_str" : "186529934",
      "id" : 186529934
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mozwow",
      "indices" : [ 43, 50 ]
    } ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/cljQbMvggh",
      "expanded_url" : "https:\/\/science.mozilla.org\/blog\/2017-wow-wrap-up",
      "display_url" : "science.mozilla.org\/blog\/2017-wow-\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17235829504116, 8.62751512722576 ]
  },
  "id_str" : "842402828974993408",
  "text" : "Read what we were up to in Montreal during #mozwow. It was exactly as much fun as it sounds. Thanks @auremoser! https:\/\/t.co\/cljQbMvggh",
  "id" : 842402828974993408,
  "created_at" : "2017-03-16 15:51:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 78 ],
      "url" : "https:\/\/t.co\/3lDApYF558",
      "expanded_url" : "https:\/\/twitter.com\/andybowers\/status\/817021197196132352",
      "display_url" : "twitter.com\/andybowers\/sta\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17235407686371, 8.627514328757579 ]
  },
  "id_str" : "842395684422709248",
  "text" : "I wish the \u00ABThis American Life Blooper Reel\u00BB was real. https:\/\/t.co\/3lDApYF558",
  "id" : 842395684422709248,
  "created_at" : "2017-03-16 15:22:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uD83D\uDCABKelsey Merkley \uD83D\uDCAB",
      "screen_name" : "bella_velo",
      "indices" : [ 3, 14 ],
      "id_str" : "6745972",
      "id" : 6745972
    }, {
      "name" : "#uctphysics",
      "screen_name" : "uctphysics",
      "indices" : [ 51, 62 ],
      "id_str" : "1843286922",
      "id" : 1843286922
    }, {
      "name" : "Sahal Yacoob",
      "screen_name" : "sahalyacoob",
      "indices" : [ 74, 86 ],
      "id_str" : "3184152466",
      "id" : 3184152466
    }, {
      "name" : "OpenStax",
      "screen_name" : "OpenStax",
      "indices" : [ 92, 101 ],
      "id_str" : "435929732",
      "id" : 435929732
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "opentextbooks",
      "indices" : [ 30, 44 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "842381801700098049",
  "text" : "RT @bella_velo: Check out the #opentextbooks from  @uctphysics adapted by @sahalyacoob from @OpenStax saving to students US$11,531 #OpenTex\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "#uctphysics",
        "screen_name" : "uctphysics",
        "indices" : [ 35, 46 ],
        "id_str" : "1843286922",
        "id" : 1843286922
      }, {
        "name" : "Sahal Yacoob",
        "screen_name" : "sahalyacoob",
        "indices" : [ 58, 70 ],
        "id_str" : "3184152466",
        "id" : 3184152466
      }, {
        "name" : "OpenStax",
        "screen_name" : "OpenStax",
        "indices" : [ 76, 85 ],
        "id_str" : "435929732",
        "id" : 435929732
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/bella_velo\/status\/842380177938239489\/photo\/1",
        "indices" : [ 137, 160 ],
        "url" : "https:\/\/t.co\/lEoJ11U8jw",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/C7C8N_6WkAA0pWQ.jpg",
        "id_str" : "842380078998786048",
        "id" : 842380078998786048,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C7C8N_6WkAA0pWQ.jpg",
        "sizes" : [ {
          "h" : 528,
          "resize" : "fit",
          "w" : 939
        }, {
          "h" : 528,
          "resize" : "fit",
          "w" : 939
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 528,
          "resize" : "fit",
          "w" : 939
        }, {
          "h" : 382,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/lEoJ11U8jw"
      } ],
      "hashtags" : [ {
        "text" : "opentextbooks",
        "indices" : [ 14, 28 ]
      }, {
        "text" : "OpenTextbooks4Africa",
        "indices" : [ 115, 136 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "842380177938239489",
    "text" : "Check out the #opentextbooks from  @uctphysics adapted by @sahalyacoob from @OpenStax saving to students US$11,531 #OpenTextbooks4Africa https:\/\/t.co\/lEoJ11U8jw",
    "id" : 842380177938239489,
    "created_at" : "2017-03-16 14:20:59 +0000",
    "user" : {
      "name" : "\uD83D\uDCABKelsey Merkley \uD83D\uDCAB",
      "screen_name" : "bella_velo",
      "protected" : false,
      "id_str" : "6745972",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/875913994929934336\/1aiBO2bG_normal.jpg",
      "id" : 6745972,
      "verified" : false
    }
  },
  "id" : 842381801700098049,
  "created_at" : "2017-03-16 14:27:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan Rice",
      "screen_name" : "alanmrice",
      "indices" : [ 0, 10 ],
      "id_str" : "6872082",
      "id" : 6872082
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "842349431005552640",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723554791114, 8.627522648353136 ]
  },
  "id_str" : "842354450304008193",
  "in_reply_to_user_id" : 6872082,
  "text" : "@alanmrice tag team! :D",
  "id" : 842354450304008193,
  "in_reply_to_status_id" : 842349431005552640,
  "created_at" : "2017-03-16 12:38:45 +0000",
  "in_reply_to_screen_name" : "alanmrice",
  "in_reply_to_user_id_str" : "6872082",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 36 ],
      "url" : "https:\/\/t.co\/goub5UJOpp",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BRspVHrjX30\/",
      "display_url" : "instagram.com\/p\/BRspVHrjX30\/"
    } ]
  },
  "geo" : { },
  "id_str" : "842339085243023363",
  "text" : "bad hair day https:\/\/t.co\/goub5UJOpp",
  "id" : 842339085243023363,
  "created_at" : "2017-03-16 11:37:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Achintya Rao \u2022 \u0C85\u0C9A\u0CBF\u0C82\u0CA4\u0CCD\u0CAF \u0CB0\u0CBE\u0CB5",
      "screen_name" : "RaoOfPhysics",
      "indices" : [ 0, 13 ],
      "id_str" : "67529128",
      "id" : 67529128
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "842336111141740544",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17234393035256, 8.627534618202718 ]
  },
  "id_str" : "842337378652041217",
  "in_reply_to_user_id" : 67529128,
  "text" : "@RaoOfPhysics let\u2019s see for that. :D",
  "id" : 842337378652041217,
  "in_reply_to_status_id" : 842336111141740544,
  "created_at" : "2017-03-16 11:30:55 +0000",
  "in_reply_to_screen_name" : "RaoOfPhysics",
  "in_reply_to_user_id_str" : "67529128",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dnavid",
      "screen_name" : "davidweisss",
      "indices" : [ 0, 12 ],
      "id_str" : "19355816",
      "id" : 19355816
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "842330230794645505",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17236575921774, 8.627561235221417 ]
  },
  "id_str" : "842334731362480128",
  "in_reply_to_user_id" : 19355816,
  "text" : "@davidweisss yes, totally.",
  "id" : 842334731362480128,
  "in_reply_to_status_id" : 842330230794645505,
  "created_at" : "2017-03-16 11:20:24 +0000",
  "in_reply_to_screen_name" : "davidweisss",
  "in_reply_to_user_id_str" : "19355816",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan Rice",
      "screen_name" : "alanmrice",
      "indices" : [ 0, 10 ],
      "id_str" : "6872082",
      "id" : 6872082
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "842323045398269952",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17240906534447, 8.627729815713709 ]
  },
  "id_str" : "842323737835892739",
  "in_reply_to_user_id" : 6872082,
  "text" : "@alanmrice project reinvent for 2018? :p",
  "id" : 842323737835892739,
  "in_reply_to_status_id" : 842323045398269952,
  "created_at" : "2017-03-16 10:36:43 +0000",
  "in_reply_to_screen_name" : "alanmrice",
  "in_reply_to_user_id_str" : "6872082",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 0, 10 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "842322697858236416",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17238330679191, 8.627711806443283 ]
  },
  "id_str" : "842323620621893632",
  "in_reply_to_user_id" : 1385861262,
  "text" : "@Julie_B92 yes :D",
  "id" : 842323620621893632,
  "in_reply_to_status_id" : 842322697858236416,
  "created_at" : "2017-03-16 10:36:15 +0000",
  "in_reply_to_screen_name" : "Julie_B92",
  "in_reply_to_user_id_str" : "1385861262",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Paul Coxon",
      "screen_name" : "paulcoxon",
      "indices" : [ 3, 13 ],
      "id_str" : "18911432",
      "id" : 18911432
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 81 ],
      "url" : "https:\/\/t.co\/hCN4oYBlXC",
      "expanded_url" : "https:\/\/twitter.com\/davidfrum\/status\/818904498437378048",
      "display_url" : "twitter.com\/davidfrum\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "842321728101613568",
  "text" : "RT @paulcoxon: They also charge \u00A3852 for a colour figure. https:\/\/t.co\/hCN4oYBlXC",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 43, 66 ],
        "url" : "https:\/\/t.co\/hCN4oYBlXC",
        "expanded_url" : "https:\/\/twitter.com\/davidfrum\/status\/818904498437378048",
        "display_url" : "twitter.com\/davidfrum\/stat\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "819207763469488132",
    "text" : "They also charge \u00A3852 for a colour figure. https:\/\/t.co\/hCN4oYBlXC",
    "id" : 819207763469488132,
    "created_at" : "2017-01-11 15:42:05 +0000",
    "user" : {
      "name" : "Dr Paul Coxon",
      "screen_name" : "paulcoxon",
      "protected" : false,
      "id_str" : "18911432",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/636660043312693248\/K6eLUfum_normal.jpg",
      "id" : 18911432,
      "verified" : true
    }
  },
  "id" : 842321728101613568,
  "created_at" : "2017-03-16 10:28:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17224562397377, 8.63034730006767 ]
  },
  "id_str" : "842321312441896964",
  "text" : "Signed the final extension for my contract. So now I\u2019ll be out of job come December instead of May.",
  "id" : 842321312441896964,
  "created_at" : "2017-03-16 10:27:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 0, 10 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "842295588762861569",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17235409239804, 8.627548464909149 ]
  },
  "id_str" : "842318134728101888",
  "in_reply_to_user_id" : 1385861262,
  "text" : "@Julie_B92 I love awk, but every time I use it I have to google how. :D",
  "id" : 842318134728101888,
  "in_reply_to_status_id" : 842295588762861569,
  "created_at" : "2017-03-16 10:14:27 +0000",
  "in_reply_to_screen_name" : "Julie_B92",
  "in_reply_to_user_id_str" : "1385861262",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 0, 10 ],
      "id_str" : "14700783",
      "id" : 14700783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "842293901574692864",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11405273849851, 8.753081349886266 ]
  },
  "id_str" : "842299771117268993",
  "in_reply_to_user_id" : 14700783,
  "text" : "@Fischblog Klartext == die Evidenz ist so transparent das sie nicht existiert.",
  "id" : 842299771117268993,
  "in_reply_to_status_id" : 842293901574692864,
  "created_at" : "2017-03-16 09:01:29 +0000",
  "in_reply_to_screen_name" : "Fischblog",
  "in_reply_to_user_id_str" : "14700783",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arikia\uD83D\uDCAB",
      "screen_name" : "arikia",
      "indices" : [ 0, 7 ],
      "id_str" : "71654283",
      "id" : 71654283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "842252100352540672",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11406907156913, 8.753433157433072 ]
  },
  "id_str" : "842292001760526336",
  "in_reply_to_user_id" : 71654283,
  "text" : "@arikia yay, great to see you again!",
  "id" : 842292001760526336,
  "in_reply_to_status_id" : 842252100352540672,
  "created_at" : "2017-03-16 08:30:36 +0000",
  "in_reply_to_screen_name" : "arikia",
  "in_reply_to_user_id_str" : "71654283",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11406727931733, 8.753451273210532 ]
  },
  "id_str" : "842153907853889536",
  "text" : "Nearly convinced a partner that they\u2019re shorter than me thanks to Bergmann\u2019s rule. Good thing they never heard of Allen\u2019s rule either. \uD83D\uDE02",
  "id" : 842153907853889536,
  "created_at" : "2017-03-15 23:21:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "obfuscated brea",
      "screen_name" : "brielle_55555",
      "indices" : [ 3, 17 ],
      "id_str" : "23026801",
      "id" : 23026801
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/brielle_55555\/status\/842072281778073600\/photo\/1",
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/bo3Q4NKHmw",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/C6-ihz2UwAAwoEm.jpg",
      "id_str" : "842070357079015424",
      "id" : 842070357079015424,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C6-ihz2UwAAwoEm.jpg",
      "sizes" : [ {
        "h" : 544,
        "resize" : "fit",
        "w" : 401
      }, {
        "h" : 544,
        "resize" : "fit",
        "w" : 401
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 544,
        "resize" : "fit",
        "w" : 401
      }, {
        "h" : 544,
        "resize" : "fit",
        "w" : 401
      } ],
      "display_url" : "pic.twitter.com\/bo3Q4NKHmw"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/brielle_55555\/status\/842072281778073600\/photo\/1",
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/bo3Q4NKHmw",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/C6-ihz_VwAAkW_A.jpg",
      "id_str" : "842070357116829696",
      "id" : 842070357116829696,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C6-ihz_VwAAkW_A.jpg",
      "sizes" : [ {
        "h" : 663,
        "resize" : "fit",
        "w" : 406
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 663,
        "resize" : "fit",
        "w" : 406
      }, {
        "h" : 663,
        "resize" : "fit",
        "w" : 406
      }, {
        "h" : 663,
        "resize" : "fit",
        "w" : 406
      } ],
      "display_url" : "pic.twitter.com\/bo3Q4NKHmw"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/brielle_55555\/status\/842072281778073600\/photo\/1",
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/bo3Q4NKHmw",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/C6-j8D2U0AAK1s0.jpg",
      "id_str" : "842071907562213376",
      "id" : 842071907562213376,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C6-j8D2U0AAK1s0.jpg",
      "sizes" : [ {
        "h" : 536,
        "resize" : "fit",
        "w" : 407
      }, {
        "h" : 536,
        "resize" : "fit",
        "w" : 407
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 536,
        "resize" : "fit",
        "w" : 407
      }, {
        "h" : 536,
        "resize" : "fit",
        "w" : 407
      } ],
      "display_url" : "pic.twitter.com\/bo3Q4NKHmw"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/brielle_55555\/status\/842072281778073600\/photo\/1",
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/bo3Q4NKHmw",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/C6-j82LU0AAYQz2.jpg",
      "id_str" : "842071921072066560",
      "id" : 842071921072066560,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C6-j82LU0AAYQz2.jpg",
      "sizes" : [ {
        "h" : 643,
        "resize" : "fit",
        "w" : 406
      }, {
        "h" : 643,
        "resize" : "fit",
        "w" : 406
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 643,
        "resize" : "fit",
        "w" : 406
      }, {
        "h" : 643,
        "resize" : "fit",
        "w" : 406
      } ],
      "display_url" : "pic.twitter.com\/bo3Q4NKHmw"
    } ],
    "hashtags" : [ {
      "text" : "howareYOUlgbt",
      "indices" : [ 75, 89 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "842138027619188736",
  "text" : "RT @brielle_55555: i laughed so hard at these i gave myself a headache. \uD83D\uDE02\n\n#howareYOUlgbt? https:\/\/t.co\/bo3Q4NKHmw",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/brielle_55555\/status\/842072281778073600\/photo\/1",
        "indices" : [ 72, 95 ],
        "url" : "https:\/\/t.co\/bo3Q4NKHmw",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/C6-ihz2UwAAwoEm.jpg",
        "id_str" : "842070357079015424",
        "id" : 842070357079015424,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C6-ihz2UwAAwoEm.jpg",
        "sizes" : [ {
          "h" : 544,
          "resize" : "fit",
          "w" : 401
        }, {
          "h" : 544,
          "resize" : "fit",
          "w" : 401
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 544,
          "resize" : "fit",
          "w" : 401
        }, {
          "h" : 544,
          "resize" : "fit",
          "w" : 401
        } ],
        "display_url" : "pic.twitter.com\/bo3Q4NKHmw"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/brielle_55555\/status\/842072281778073600\/photo\/1",
        "indices" : [ 72, 95 ],
        "url" : "https:\/\/t.co\/bo3Q4NKHmw",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/C6-ihz_VwAAkW_A.jpg",
        "id_str" : "842070357116829696",
        "id" : 842070357116829696,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C6-ihz_VwAAkW_A.jpg",
        "sizes" : [ {
          "h" : 663,
          "resize" : "fit",
          "w" : 406
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 663,
          "resize" : "fit",
          "w" : 406
        }, {
          "h" : 663,
          "resize" : "fit",
          "w" : 406
        }, {
          "h" : 663,
          "resize" : "fit",
          "w" : 406
        } ],
        "display_url" : "pic.twitter.com\/bo3Q4NKHmw"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/brielle_55555\/status\/842072281778073600\/photo\/1",
        "indices" : [ 72, 95 ],
        "url" : "https:\/\/t.co\/bo3Q4NKHmw",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/C6-j8D2U0AAK1s0.jpg",
        "id_str" : "842071907562213376",
        "id" : 842071907562213376,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C6-j8D2U0AAK1s0.jpg",
        "sizes" : [ {
          "h" : 536,
          "resize" : "fit",
          "w" : 407
        }, {
          "h" : 536,
          "resize" : "fit",
          "w" : 407
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 536,
          "resize" : "fit",
          "w" : 407
        }, {
          "h" : 536,
          "resize" : "fit",
          "w" : 407
        } ],
        "display_url" : "pic.twitter.com\/bo3Q4NKHmw"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/brielle_55555\/status\/842072281778073600\/photo\/1",
        "indices" : [ 72, 95 ],
        "url" : "https:\/\/t.co\/bo3Q4NKHmw",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/C6-j82LU0AAYQz2.jpg",
        "id_str" : "842071921072066560",
        "id" : 842071921072066560,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C6-j82LU0AAYQz2.jpg",
        "sizes" : [ {
          "h" : 643,
          "resize" : "fit",
          "w" : 406
        }, {
          "h" : 643,
          "resize" : "fit",
          "w" : 406
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 643,
          "resize" : "fit",
          "w" : 406
        }, {
          "h" : 643,
          "resize" : "fit",
          "w" : 406
        } ],
        "display_url" : "pic.twitter.com\/bo3Q4NKHmw"
      } ],
      "hashtags" : [ {
        "text" : "howareYOUlgbt",
        "indices" : [ 56, 70 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "842072281778073600",
    "text" : "i laughed so hard at these i gave myself a headache. \uD83D\uDE02\n\n#howareYOUlgbt? https:\/\/t.co\/bo3Q4NKHmw",
    "id" : 842072281778073600,
    "created_at" : "2017-03-15 17:57:31 +0000",
    "user" : {
      "name" : "obfuscated brea",
      "screen_name" : "brielle_55555",
      "protected" : false,
      "id_str" : "23026801",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/877229908639965184\/TWHcBLkg_normal.jpg",
      "id" : 23026801,
      "verified" : false
    }
  },
  "id" : 842138027619188736,
  "created_at" : "2017-03-15 22:18:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 3, 12 ],
      "id_str" : "14245811",
      "id" : 14245811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "842079424858206213",
  "text" : "RT @wilbanks: Imagine if all tech co's had to prove their shit was secure+private, that they didn\u2019t hurt their users, and couldn\u2019t overstat\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 141, 164 ],
        "url" : "https:\/\/t.co\/hpb3UjsDiN",
        "expanded_url" : "https:\/\/twitter.com\/chrissyfarr\/status\/841702960560201728",
        "display_url" : "twitter.com\/chrissyfarr\/st\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "841715146770808832",
    "text" : "Imagine if all tech co's had to prove their shit was secure+private, that they didn\u2019t hurt their users, and couldn\u2019t overstate their claims. https:\/\/t.co\/hpb3UjsDiN",
    "id" : 841715146770808832,
    "created_at" : "2017-03-14 18:18:23 +0000",
    "user" : {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "protected" : false,
      "id_str" : "14245811",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/925696899566440448\/BUTdp410_normal.jpg",
      "id" : 14245811,
      "verified" : false
    }
  },
  "id" : 842079424858206213,
  "created_at" : "2017-03-15 18:25:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 86 ],
      "url" : "https:\/\/t.co\/xIQi8wDZvU",
      "expanded_url" : "https:\/\/twitter.com\/auremoser\/status\/842037975189983232",
      "display_url" : "twitter.com\/auremoser\/stat\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17098405551574, 8.627929423227092 ]
  },
  "id_str" : "842051673275174912",
  "text" : "I do, that\u2019s the first sign that someone might find it useful. https:\/\/t.co\/xIQi8wDZvU",
  "id" : 842051673275174912,
  "created_at" : "2017-03-15 16:35:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katharina",
      "screen_name" : "_katsel",
      "indices" : [ 0, 8 ],
      "id_str" : "892038837052076033",
      "id" : 892038837052076033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "842048157336907776",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17240268757519, 8.627529911528722 ]
  },
  "id_str" : "842049006415032320",
  "in_reply_to_user_id" : 730326143295959040,
  "text" : "@_katsel true :D",
  "id" : 842049006415032320,
  "in_reply_to_status_id" : 842048157336907776,
  "created_at" : "2017-03-15 16:25:02 +0000",
  "in_reply_to_screen_name" : "katheyrina",
  "in_reply_to_user_id_str" : "730326143295959040",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katharina",
      "screen_name" : "_katsel",
      "indices" : [ 0, 8 ],
      "id_str" : "892038837052076033",
      "id" : 892038837052076033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "842047620201750528",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17240306908685, 8.627530963162002 ]
  },
  "id_str" : "842047716003840002",
  "in_reply_to_user_id" : 730326143295959040,
  "text" : "@_katsel not really, more like +10 getting off your ass skills. :)",
  "id" : 842047716003840002,
  "in_reply_to_status_id" : 842047620201750528,
  "created_at" : "2017-03-15 16:19:54 +0000",
  "in_reply_to_screen_name" : "katheyrina",
  "in_reply_to_user_id_str" : "730326143295959040",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17237024087517, 8.627539765581934 ]
  },
  "id_str" : "842047274133917696",
  "text" : "When you\u2019ve been procrastinating an analysis because you thought it would take you ages, but turns out it\u2019s only a day\u2019s worth of coding. \uD83C\uDF89",
  "id" : 842047274133917696,
  "created_at" : "2017-03-15 16:18:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 38 ],
      "url" : "https:\/\/t.co\/pHZdQgIL5R",
      "expanded_url" : "http:\/\/www.smbc-comics.com\/comic\/biology-2",
      "display_url" : "smbc-comics.com\/comic\/biology-2"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17238644968698, 8.62753744904867 ]
  },
  "id_str" : "842013331120635905",
  "text" : "Bear Attackome https:\/\/t.co\/pHZdQgIL5R",
  "id" : 842013331120635905,
  "created_at" : "2017-03-15 14:03:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ran Blekhman",
      "screen_name" : "blekhman",
      "indices" : [ 3, 12 ],
      "id_str" : "933330985",
      "id" : 933330985
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/gYDtOvk2aL",
      "expanded_url" : "https:\/\/twitter.com\/lteytelman\/status\/841481018095820800",
      "display_url" : "twitter.com\/lteytelman\/sta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "841909567814545409",
  "text" : "RT @blekhman: This is when he signs his name. Imagine what this person is like as an anonymous reviewer https:\/\/t.co\/gYDtOvk2aL",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 90, 113 ],
        "url" : "https:\/\/t.co\/gYDtOvk2aL",
        "expanded_url" : "https:\/\/twitter.com\/lteytelman\/status\/841481018095820800",
        "display_url" : "twitter.com\/lteytelman\/sta\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "841749101389742080",
    "text" : "This is when he signs his name. Imagine what this person is like as an anonymous reviewer https:\/\/t.co\/gYDtOvk2aL",
    "id" : 841749101389742080,
    "created_at" : "2017-03-14 20:33:19 +0000",
    "user" : {
      "name" : "Ran Blekhman",
      "screen_name" : "blekhman",
      "protected" : false,
      "id_str" : "933330985",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793459932003569665\/73FNsekq_normal.jpg",
      "id" : 933330985,
      "verified" : false
    }
  },
  "id" : 841909567814545409,
  "created_at" : "2017-03-15 07:10:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 91 ],
      "url" : "https:\/\/t.co\/BtvkkzBN3W",
      "expanded_url" : "https:\/\/melmagazine.com\/the-ideal-dick-is-the-boyfriend-dick-e66866eddc00?source=twitterShare-aaeb714c1b80-1489516426",
      "display_url" : "melmagazine.com\/the-ideal-dick\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "841719171855589376",
  "text" : "Don't be a dick, as \u00ABbeing a decent person makes your dick better.\u00BB https:\/\/t.co\/BtvkkzBN3W",
  "id" : 841719171855589376,
  "created_at" : "2017-03-14 18:34:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "latergram",
      "indices" : [ 9, 19 ]
    }, {
      "text" : "mozwow",
      "indices" : [ 52, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/xgnjyrLzDY",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BRoLSpFDBxh\/",
      "display_url" : "instagram.com\/p\/BRoLSpFDBxh\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.4991, -73.5683 ]
  },
  "id_str" : "841710080466784256",
  "text" : "The last #latergram from our open science church at #mozwow @ Mary, Queen of the World Cathedral https:\/\/t.co\/xgnjyrLzDY",
  "id" : 841710080466784256,
  "created_at" : "2017-03-14 17:58:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helena",
      "screen_name" : "Helena_LB",
      "indices" : [ 0, 10 ],
      "id_str" : "234309722",
      "id" : 234309722
    }, {
      "name" : "Sage Bionetworks",
      "screen_name" : "Sagebio",
      "indices" : [ 11, 19 ],
      "id_str" : "130579391",
      "id" : 130579391
    }, {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 20, 34 ],
      "id_str" : "352650591",
      "id" : 352650591
    }, {
      "name" : "Lisa Matthias",
      "screen_name" : "l_matthia",
      "indices" : [ 35, 45 ],
      "id_str" : "734667419055230976",
      "id" : 734667419055230976
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "841697300854525952",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.47114482209695, -0.4526347826546038 ]
  },
  "id_str" : "841702451442937857",
  "in_reply_to_user_id" : 234309722,
  "text" : "@Helena_LB @Sagebio @Protohedgehog @l_matthia I\u2019ll need to go on preemptive diet right now.",
  "id" : 841702451442937857,
  "in_reply_to_status_id" : 841697300854525952,
  "created_at" : "2017-03-14 17:27:57 +0000",
  "in_reply_to_screen_name" : "Helena_LB",
  "in_reply_to_user_id_str" : "234309722",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.51289506465447, -0.1012731606312831 ]
  },
  "id_str" : "841652520699211776",
  "text" : "\u00ABNo barriers to food. Seating downstairs.\u00BB \uD83E\uDD26\u200D\u2640\uFE0F",
  "id" : 841652520699211776,
  "created_at" : "2017-03-14 14:09:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BiK-F",
      "screen_name" : "bik_f_",
      "indices" : [ 0, 7 ],
      "id_str" : "2849770550",
      "id" : 2849770550
    }, {
      "name" : "SENCKENBERG",
      "screen_name" : "Senckenberg",
      "indices" : [ 8, 20 ],
      "id_str" : "85120200",
      "id" : 85120200
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "841635389060317184",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.51104941975085, -0.1083604267155605 ]
  },
  "id_str" : "841638007396536321",
  "in_reply_to_user_id" : 2849770550,
  "text" : "@bik_f_ @Senckenberg no hopes or dreams to begin with, so nothing to flush? \uD83D\uDE02",
  "id" : 841638007396536321,
  "in_reply_to_status_id" : 841635389060317184,
  "created_at" : "2017-03-14 13:11:52 +0000",
  "in_reply_to_screen_name" : "bik_f_",
  "in_reply_to_user_id_str" : "2849770550",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Jens Foell",
      "screen_name" : "fMRI_guy",
      "indices" : [ 0, 9 ],
      "id_str" : "2377958781",
      "id" : 2377958781
    }, {
      "name" : "Real Scientists DE",
      "screen_name" : "realsci_DE",
      "indices" : [ 10, 21 ],
      "id_str" : "810555350944464896",
      "id" : 810555350944464896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "841452830217109504",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.52589043486628, -0.1256767900151952 ]
  },
  "id_str" : "841592356721823744",
  "in_reply_to_user_id" : 2377958781,
  "text" : "@fMRI_guy @realsci_DE klar, kann ich gern machen :)",
  "id" : 841592356721823744,
  "in_reply_to_status_id" : 841452830217109504,
  "created_at" : "2017-03-14 10:10:28 +0000",
  "in_reply_to_screen_name" : "fMRI_guy",
  "in_reply_to_user_id_str" : "2377958781",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/841586979062075392\/photo\/1",
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/FyIkXsYESe",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/C63q20KWcAAsztG.jpg",
      "id_str" : "841586932824043520",
      "id" : 841586932824043520,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C63q20KWcAAsztG.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/FyIkXsYESe"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.52626443193436, -0.1249180175365181 ]
  },
  "id_str" : "841586979062075392",
  "text" : "No hopes or dreams? This hostel isn\u2019t very compatible with PhD students. https:\/\/t.co\/FyIkXsYESe",
  "id" : 841586979062075392,
  "created_at" : "2017-03-14 09:49:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Biotweeps - Brit",
      "screen_name" : "biotweeps",
      "indices" : [ 0, 10 ],
      "id_str" : "2561407350",
      "id" : 2561407350
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "841380189565272069",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.52605127761765, -0.1251866844954946 ]
  },
  "id_str" : "841380359606534144",
  "in_reply_to_user_id" : 2561407350,
  "text" : "@biotweeps \u201Cversion 2.0 crashes much faster than 1.0 does. \uD83D\uDC4D\u201D",
  "id" : 841380359606534144,
  "in_reply_to_status_id" : 841380189565272069,
  "created_at" : "2017-03-13 20:08:04 +0000",
  "in_reply_to_screen_name" : "biotweeps",
  "in_reply_to_user_id_str" : "2561407350",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 82 ],
      "url" : "https:\/\/t.co\/CDxSv2FICp",
      "expanded_url" : "https:\/\/twitter.com\/ctitusbrown\/status\/841379368605642752",
      "display_url" : "twitter.com\/ctitusbrown\/st\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.52614848010687, -0.1250255889451607 ]
  },
  "id_str" : "841380043163074560",
  "text" : "Describes what feels like 75% of all bioinformatics tools. https:\/\/t.co\/CDxSv2FICp",
  "id" : 841380043163074560,
  "created_at" : "2017-03-13 20:06:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mozwow",
      "indices" : [ 30, 37 ]
    }, {
      "text" : "latergram",
      "indices" : [ 38, 48 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/3oAZaktfC4",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BRlj2eLDusq\/",
      "display_url" : "instagram.com\/p\/BRlj2eLDusq\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.4991, -73.5683 ]
  },
  "id_str" : "841341874258497537",
  "text" : "What's your project cult-ure? #mozwow #latergram @ Mary, Queen of the World Cathedral https:\/\/t.co\/3oAZaktfC4",
  "id" : 841341874258497537,
  "created_at" : "2017-03-13 17:35:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Year-round Witch, Em",
      "screen_name" : "emilyagras",
      "indices" : [ 0, 11 ],
      "id_str" : "776916624",
      "id" : 776916624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "841236407838494720",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.50529398293163, -0.07927538754046963 ]
  },
  "id_str" : "841300661203554304",
  "in_reply_to_user_id" : 776916624,
  "text" : "@emilyagras \u05DB\u05DF \uD83D\uDE02",
  "id" : 841300661203554304,
  "in_reply_to_status_id" : 841236407838494720,
  "created_at" : "2017-03-13 14:51:22 +0000",
  "in_reply_to_screen_name" : "emilyagras",
  "in_reply_to_user_id_str" : "776916624",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.52765355884009, -0.1186593837737076 ]
  },
  "id_str" : "841290280972214272",
  "text" : "Having a late breakfast, sitting outside in a park, without freezing at all. \uD83C\uDF89",
  "id" : 841290280972214272,
  "created_at" : "2017-03-13 14:10:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "latergram",
      "indices" : [ 8, 18 ]
    } ],
    "urls" : [ {
      "indices" : [ 38, 61 ],
      "url" : "https:\/\/t.co\/oYpwJh4spb",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BRlEaSJDtrv\/",
      "display_url" : "instagram.com\/p\/BRlEaSJDtrv\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.5, -73.5833 ]
  },
  "id_str" : "841272737553350658",
  "text" : "Watched #latergram @ Montreal, Quebec https:\/\/t.co\/oYpwJh4spb",
  "id" : 841272737553350658,
  "created_at" : "2017-03-13 13:00:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Johannes'fish'Ziemke",
      "screen_name" : "discordianfish",
      "indices" : [ 0, 15 ],
      "id_str" : "21647811",
      "id" : 21647811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "841231116581371904",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.50232682830497, -0.2795886338354909 ]
  },
  "id_str" : "841231307673870336",
  "in_reply_to_user_id" : 21647811,
  "text" : "@discordianfish guess the perception is that it makes them more accountable. But I\u2019ve no clue whether that\u2019s actually the case.",
  "id" : 841231307673870336,
  "in_reply_to_status_id" : 841231116581371904,
  "created_at" : "2017-03-13 10:15:47 +0000",
  "in_reply_to_screen_name" : "discordianfish",
  "in_reply_to_user_id_str" : "21647811",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Johannes'fish'Ziemke",
      "screen_name" : "discordianfish",
      "indices" : [ 0, 15 ],
      "id_str" : "21647811",
      "id" : 21647811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "841229965899227136",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.50459323083191, -0.2833165414634005 ]
  },
  "id_str" : "841230749298749440",
  "in_reply_to_user_id" : 21647811,
  "text" : "@discordianfish people think people running family businesses have more skin in the game compared to public companies?",
  "id" : 841230749298749440,
  "in_reply_to_status_id" : 841229965899227136,
  "created_at" : "2017-03-13 10:13:34 +0000",
  "in_reply_to_screen_name" : "discordianfish",
  "in_reply_to_user_id_str" : "21647811",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/Yu051LE9K7",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BRkvRj5D5X9\/",
      "display_url" : "instagram.com\/p\/BRkvRj5D5X9\/"
    } ]
  },
  "geo" : { },
  "id_str" : "841226263155081216",
  "text" : "Temperature \u2206 to Montreal: +30 \u00B0C. Feels good to have your weather back, London. https:\/\/t.co\/Yu051LE9K7",
  "id" : 841226263155081216,
  "created_at" : "2017-03-13 09:55:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "latergram",
      "indices" : [ 12, 22 ]
    } ],
    "urls" : [ {
      "indices" : [ 42, 65 ],
      "url" : "https:\/\/t.co\/rpJ4hozhpp",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BRksqD-DIcJ\/",
      "display_url" : "instagram.com\/p\/BRksqD-DIcJ\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.5, -73.5833 ]
  },
  "id_str" : "841220507638849536",
  "text" : "Unalignable #latergram @ Montreal, Quebec https:\/\/t.co\/rpJ4hozhpp",
  "id" : 841220507638849536,
  "created_at" : "2017-03-13 09:32:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/uOSD0OLlBE",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BRjo0F2jrEb\/",
      "display_url" : "instagram.com\/p\/BRjo0F2jrEb\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.457938394702, -73.75046071207 ]
  },
  "id_str" : "841071314865655813",
  "text" : "Goodbye Montr\u00E9al, that was a fun and cold trip. @ A\u00E9roport Montr\u00E9al-Trudeau Airport https:\/\/t.co\/uOSD0OLlBE",
  "id" : 841071314865655813,
  "created_at" : "2017-03-12 23:40:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/841059178135355392\/photo\/1",
      "indices" : [ 54, 77 ],
      "url" : "https:\/\/t.co\/4wPRAV4mJR",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/C6wK3WGWYAA-1F2.jpg",
      "id_str" : "841059176352735232",
      "id" : 841059176352735232,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C6wK3WGWYAA-1F2.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/4wPRAV4mJR"
    } ],
    "hashtags" : [ {
      "text" : "mozwow",
      "indices" : [ 44, 51 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "841059178135355392",
  "text" : "That's something we should play at the next #mozwow \uD83D\uDE02 https:\/\/t.co\/4wPRAV4mJR",
  "id" : 841059178135355392,
  "created_at" : "2017-03-12 22:51:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/p5kCSKWkle",
      "expanded_url" : "https:\/\/en.m.wikipedia.org\/wiki\/Underground_City,_Montreal",
      "display_url" : "en.m.wikipedia.org\/wiki\/Undergrou\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.45807029455561, -73.75052943659416 ]
  },
  "id_str" : "841049739005198336",
  "text" : "Spent half the day exploring the Underground City. Must be tons of cyberpunk\/post-apocalyptical fictions about it? https:\/\/t.co\/p5kCSKWkle",
  "id" : 841049739005198336,
  "created_at" : "2017-03-12 22:14:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 50 ],
      "url" : "https:\/\/t.co\/fIpSQMjxMY",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BRjLDE6jR2d\/",
      "display_url" : "instagram.com\/p\/BRjLDE6jR2d\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.5, -73.57 ]
  },
  "id_str" : "841005862210678785",
  "text" : "Frozen @ Downtown Montreal https:\/\/t.co\/fIpSQMjxMY",
  "id" : 841005862210678785,
  "created_at" : "2017-03-12 19:19:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 8, 31 ],
      "url" : "https:\/\/t.co\/EuNCdGUfcs",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BRjHFxPDvmL\/",
      "display_url" : "instagram.com\/p\/BRjHFxPDvmL\/"
    } ]
  },
  "geo" : { },
  "id_str" : "840997158404931586",
  "text" : "Lookout https:\/\/t.co\/EuNCdGUfcs",
  "id" : 840997158404931586,
  "created_at" : "2017-03-12 18:45:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lukas Geiger",
      "screen_name" : "_lgeiger",
      "indices" : [ 0, 9 ],
      "id_str" : "792555550550659072",
      "id" : 792555550550659072
    }, {
      "name" : "Tim Head",
      "screen_name" : "betatim",
      "indices" : [ 10, 18 ],
      "id_str" : "18881614",
      "id" : 18881614
    }, {
      "name" : "Bruno Vieira",
      "screen_name" : "bmpvieira",
      "indices" : [ 19, 29 ],
      "id_str" : "55388565",
      "id" : 55388565
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.49884411920097, -73.57394426417824 ]
  },
  "id_str" : "840970468056272897",
  "in_reply_to_user_id" : 792555550550659072,
  "text" : "@_lgeiger @betatim @bmpvieira and I are having lunch at Mister Steer, 1198 Ste-Catherine Street West. Wanna join?",
  "id" : 840970468056272897,
  "created_at" : "2017-03-12 16:59:18 +0000",
  "in_reply_to_screen_name" : "_lgeiger",
  "in_reply_to_user_id_str" : "792555550550659072",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 55 ],
      "url" : "https:\/\/t.co\/IN9bhm5R9X",
      "expanded_url" : "http:\/\/25.media.tumblr.com\/tumblr_maflqxDG3t1r7klwoo1_500.gif",
      "display_url" : "25.media.tumblr.com\/tumblr_maflqxD\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.51398044764549, -73.57267809158536 ]
  },
  "id_str" : "840932575396913152",
  "text" : "Now for exploring Old Montreal. https:\/\/t.co\/IN9bhm5R9X",
  "id" : 840932575396913152,
  "created_at" : "2017-03-12 14:28:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 0, 10 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "840929829897797633",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.51409556586537, -73.57259215066192 ]
  },
  "id_str" : "840930837650690052",
  "in_reply_to_user_id" : 1385861262,
  "text" : "@Julie_B92 why not both? :p",
  "id" : 840930837650690052,
  "in_reply_to_status_id" : 840929829897797633,
  "created_at" : "2017-03-12 14:21:50 +0000",
  "in_reply_to_screen_name" : "Julie_B92",
  "in_reply_to_user_id_str" : "1385861262",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 0, 10 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "840929280318156802",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.51406133109954, -73.57273590724505 ]
  },
  "id_str" : "840929697773080576",
  "in_reply_to_user_id" : 1385861262,
  "text" : "@Julie_B92 Armadildos dipped in maple syrup-flavored lube. :p",
  "id" : 840929697773080576,
  "in_reply_to_status_id" : 840929280318156802,
  "created_at" : "2017-03-12 14:17:18 +0000",
  "in_reply_to_screen_name" : "Julie_B92",
  "in_reply_to_user_id_str" : "1385861262",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 0, 10 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "840928651977863168",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.51398617238726, -73.57270172458489 ]
  },
  "id_str" : "840929153675337728",
  "in_reply_to_user_id" : 1385861262,
  "text" : "@Julie_B92 can\u2019t unsee that",
  "id" : 840929153675337728,
  "in_reply_to_status_id" : 840928651977863168,
  "created_at" : "2017-03-12 14:15:08 +0000",
  "in_reply_to_screen_name" : "Julie_B92",
  "in_reply_to_user_id_str" : "1385861262",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 0, 10 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "840920764555657216",
  "geo" : { },
  "id_str" : "840920887398395906",
  "in_reply_to_user_id" : 1385861262,
  "text" : "@Julie_B92 an interesting and sticky bunch :D",
  "id" : 840920887398395906,
  "in_reply_to_status_id" : 840920764555657216,
  "created_at" : "2017-03-12 13:42:17 +0000",
  "in_reply_to_screen_name" : "Julie_B92",
  "in_reply_to_user_id_str" : "1385861262",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 0, 10 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "840920224710959104",
  "geo" : { },
  "id_str" : "840920611912339459",
  "in_reply_to_user_id" : 1385861262,
  "text" : "@Julie_B92 guess that's why it's \"flavored\", though when executing the query I found tons of pages asking whether \uD83C\uDF41 syrup makes good lube.",
  "id" : 840920611912339459,
  "in_reply_to_status_id" : 840920224710959104,
  "created_at" : "2017-03-12 13:41:12 +0000",
  "in_reply_to_screen_name" : "Julie_B92",
  "in_reply_to_user_id_str" : "1385861262",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Bond",
      "screen_name" : "TheLabAndField",
      "indices" : [ 0, 15 ],
      "id_str" : "1060545835",
      "id" : 1060545835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "840914969059291138",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.51414690450347, -73.57273679233488 ]
  },
  "id_str" : "840916466211926016",
  "in_reply_to_user_id" : 1060545835,
  "text" : "@TheLabAndField yet another alternative post-academia career idea.",
  "id" : 840916466211926016,
  "in_reply_to_status_id" : 840914969059291138,
  "created_at" : "2017-03-12 13:24:43 +0000",
  "in_reply_to_screen_name" : "TheLabAndField",
  "in_reply_to_user_id_str" : "1060545835",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Penny CS Andrews\uD83D\uDC68\uD83C\uDFFB\u200D\uD83C\uDFA4\uD83C\uDF08\uD83C\uDF84",
      "screen_name" : "pennyb",
      "indices" : [ 0, 7 ],
      "id_str" : "6069772",
      "id" : 6069772
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "840915648352014339",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.51414690450347, -73.57273679233488 ]
  },
  "id_str" : "840916350096855044",
  "in_reply_to_user_id" : 6069772,
  "text" : "@pennyb such a disappointment.",
  "id" : 840916350096855044,
  "in_reply_to_status_id" : 840915648352014339,
  "created_at" : "2017-03-12 13:24:15 +0000",
  "in_reply_to_screen_name" : "pennyb",
  "in_reply_to_user_id_str" : "6069772",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "840914352999976960",
  "text" : "Canadian Google autocompleted my search query to \"maple syrup flavored lube\" and now I'm sad to know it doesn't exist.",
  "id" : 840914352999976960,
  "created_at" : "2017-03-12 13:16:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Monica Granados",
      "screen_name" : "Monsauce",
      "indices" : [ 0, 9 ],
      "id_str" : "297073565",
      "id" : 297073565
    }, {
      "name" : "Lucy Patterson",
      "screen_name" : "lu_cyP",
      "indices" : [ 10, 17 ],
      "id_str" : "99586343",
      "id" : 99586343
    }, {
      "name" : "Teon L Brooks, PhD",
      "screen_name" : "teon_io",
      "indices" : [ 18, 26 ],
      "id_str" : "30960103",
      "id" : 30960103
    }, {
      "name" : "open_epi",
      "screen_name" : "april_cs",
      "indices" : [ 27, 36 ],
      "id_str" : "621133833",
      "id" : 621133833
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "840893790567186432",
  "geo" : { },
  "id_str" : "840896582610444288",
  "in_reply_to_user_id" : 297073565,
  "text" : "@Monsauce @lu_cyP @teon_io @april_cs me too, it was a pleasure!",
  "id" : 840896582610444288,
  "in_reply_to_status_id" : 840893790567186432,
  "created_at" : "2017-03-12 12:05:43 +0000",
  "in_reply_to_screen_name" : "Monsauce",
  "in_reply_to_user_id_str" : "297073565",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lucy Patterson",
      "screen_name" : "lu_cyP",
      "indices" : [ 0, 7 ],
      "id_str" : "99586343",
      "id" : 99586343
    }, {
      "name" : "Teon L Brooks, PhD",
      "screen_name" : "teon_io",
      "indices" : [ 8, 16 ],
      "id_str" : "30960103",
      "id" : 30960103
    }, {
      "name" : "open_epi",
      "screen_name" : "april_cs",
      "indices" : [ 17, 26 ],
      "id_str" : "621133833",
      "id" : 621133833
    }, {
      "name" : "Monica Granados",
      "screen_name" : "Monsauce",
      "indices" : [ 27, 36 ],
      "id_str" : "297073565",
      "id" : 297073565
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "840797194361950213",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.48941840585538, -73.56778915138871 ]
  },
  "id_str" : "840800220506132480",
  "in_reply_to_user_id" : 99586343,
  "text" : "@lu_cyP @teon_io @april_cs @Monsauce great, thanks! And we should do that more often :D",
  "id" : 840800220506132480,
  "in_reply_to_status_id" : 840797194361950213,
  "created_at" : "2017-03-12 05:42:48 +0000",
  "in_reply_to_screen_name" : "lu_cyP",
  "in_reply_to_user_id_str" : "99586343",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "sydney",
      "screen_name" : "syswsi",
      "indices" : [ 0, 7 ],
      "id_str" : "2786240838",
      "id" : 2786240838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 8, 31 ],
      "url" : "https:\/\/t.co\/ZLnpH1EmWq",
      "expanded_url" : "https:\/\/opensnp.org\/",
      "display_url" : "opensnp.org"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.48942281441575, -73.5678231664032 ]
  },
  "id_str" : "840790012954329088",
  "in_reply_to_user_id" : 2786240838,
  "text" : "@syswsi https:\/\/t.co\/ZLnpH1EmWq here you go.",
  "id" : 840790012954329088,
  "created_at" : "2017-03-12 05:02:14 +0000",
  "in_reply_to_screen_name" : "syswsi",
  "in_reply_to_user_id_str" : "2786240838",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.48945388047187, -73.56777880249277 ]
  },
  "id_str" : "840784582811226112",
  "text" : "\u00ABHe\u2019s a Presbyterian, he\u2019s only eating fish!\u00BB",
  "id" : 840784582811226112,
  "created_at" : "2017-03-12 04:40:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mozwow",
      "indices" : [ 12, 19 ]
    } ],
    "urls" : [ {
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/3qxOEUMHPk",
      "expanded_url" : "https:\/\/youtu.be\/hn1VxaMEjRU",
      "display_url" : "youtu.be\/hn1VxaMEjRU"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.51221533816265, -73.57031063368372 ]
  },
  "id_str" : "840653471930023940",
  "text" : "Question at #mozwow: \u00ABAre we the weirdos?!\u00BB Immediately thought of this: https:\/\/t.co\/3qxOEUMHPk",
  "id" : 840653471930023940,
  "created_at" : "2017-03-11 19:59:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Abby Cabunoc Mayes",
      "screen_name" : "abbycabs",
      "indices" : [ 30, 39 ],
      "id_str" : "395367768",
      "id" : 395367768
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mozwow",
      "indices" : [ 70, 77 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/UWw83cXMMK",
      "expanded_url" : "https:\/\/twitter.com\/Hao_and_Y\/status\/840598344141537280",
      "display_url" : "twitter.com\/Hao_and_Y\/stat\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.51215883629116, -73.57050807975752 ]
  },
  "id_str" : "840645207456698368",
  "text" : "That\u2019s what I get for letting @abbycabs decide how to introduce me. \uD83D\uDE02 #mozwow https:\/\/t.co\/UWw83cXMMK",
  "id" : 840645207456698368,
  "created_at" : "2017-03-11 19:26:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jason a. clark",
      "screen_name" : "jaclark",
      "indices" : [ 3, 11 ],
      "id_str" : "1835821",
      "id" : 1835821
    }, {
      "name" : "Mozilla Science Lab",
      "screen_name" : "MozillaScience",
      "indices" : [ 63, 78 ],
      "id_str" : "1428575976",
      "id" : 1428575976
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 106, 122 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mozWOW",
      "indices" : [ 55, 62 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "840614707966930945",
  "text" : "RT @jaclark: Contribution guidelines for Open Projects #mozWOW @MozillaScience\n- Discussion + slides from @gedankenstuecke \nhttps:\/\/t.co\/vh\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Mozilla Science Lab",
        "screen_name" : "MozillaScience",
        "indices" : [ 50, 65 ],
        "id_str" : "1428575976",
        "id" : 1428575976
      }, {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 93, 109 ],
        "id_str" : "14286491",
        "id" : 14286491
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "mozWOW",
        "indices" : [ 42, 49 ]
      } ],
      "urls" : [ {
        "indices" : [ 111, 134 ],
        "url" : "https:\/\/t.co\/vhvMcruZI3",
        "expanded_url" : "https:\/\/docs.google.com\/presentation\/d\/1RpPMi9GkNMyJ3mFCkSC1PtRX74GrzfrDGZPjasrM7rE\/edit?usp=sharing",
        "display_url" : "docs.google.com\/presentation\/d\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "840601445237948417",
    "text" : "Contribution guidelines for Open Projects #mozWOW @MozillaScience\n- Discussion + slides from @gedankenstuecke \nhttps:\/\/t.co\/vhvMcruZI3",
    "id" : 840601445237948417,
    "created_at" : "2017-03-11 16:32:56 +0000",
    "user" : {
      "name" : "jason a. clark",
      "screen_name" : "jaclark",
      "protected" : false,
      "id_str" : "1835821",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/896108103690625028\/kdJwENq2_normal.jpg",
      "id" : 1835821,
      "verified" : false
    }
  },
  "id" : 840614707966930945,
  "created_at" : "2017-03-11 17:25:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uD83D\uDC9A Aure Moser \uD83D\uDC9A",
      "screen_name" : "auremoser",
      "indices" : [ 3, 13 ],
      "id_str" : "186529934",
      "id" : 186529934
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 66, 82 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/auremoser\/status\/840601837233414145\/photo\/1",
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/4UVzQha60w",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/C6pq6RjWkAQwdcP.jpg",
      "id_str" : "840601829834657796",
      "id" : 840601829834657796,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C6pq6RjWkAQwdcP.jpg",
      "sizes" : [ {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/4UVzQha60w"
    } ],
    "hashtags" : [ {
      "text" : "openscience",
      "indices" : [ 42, 54 ]
    }, {
      "text" : "mozwow",
      "indices" : [ 55, 62 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/DZdGPmZnkg",
      "expanded_url" : "https:\/\/mozillascience.github.io\/WOW-2017\/code_of_conduct\/",
      "display_url" : "mozillascience.github.io\/WOW-2017\/code_\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "840614674206973953",
  "text" : "RT @auremoser: Code of Conduct design for #openscience #mozwow w\/ @gedankenstuecke : https:\/\/t.co\/DZdGPmZnkg https:\/\/t.co\/4UVzQha60w",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 51, 67 ],
        "id_str" : "14286491",
        "id" : 14286491
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/auremoser\/status\/840601837233414145\/photo\/1",
        "indices" : [ 94, 117 ],
        "url" : "https:\/\/t.co\/4UVzQha60w",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/C6pq6RjWkAQwdcP.jpg",
        "id_str" : "840601829834657796",
        "id" : 840601829834657796,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C6pq6RjWkAQwdcP.jpg",
        "sizes" : [ {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 900,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/4UVzQha60w"
      } ],
      "hashtags" : [ {
        "text" : "openscience",
        "indices" : [ 27, 39 ]
      }, {
        "text" : "mozwow",
        "indices" : [ 40, 47 ]
      } ],
      "urls" : [ {
        "indices" : [ 70, 93 ],
        "url" : "https:\/\/t.co\/DZdGPmZnkg",
        "expanded_url" : "https:\/\/mozillascience.github.io\/WOW-2017\/code_of_conduct\/",
        "display_url" : "mozillascience.github.io\/WOW-2017\/code_\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "840601837233414145",
    "text" : "Code of Conduct design for #openscience #mozwow w\/ @gedankenstuecke : https:\/\/t.co\/DZdGPmZnkg https:\/\/t.co\/4UVzQha60w",
    "id" : 840601837233414145,
    "created_at" : "2017-03-11 16:34:30 +0000",
    "user" : {
      "name" : "\uD83D\uDC9A Aure Moser \uD83D\uDC9A",
      "screen_name" : "auremoser",
      "protected" : false,
      "id_str" : "186529934",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/723868643688325122\/AHwUDHy3_normal.jpg",
      "id" : 186529934,
      "verified" : false
    }
  },
  "id" : 840614674206973953,
  "created_at" : "2017-03-11 17:25:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Head",
      "screen_name" : "betatim",
      "indices" : [ 5, 13 ],
      "id_str" : "18881614",
      "id" : 18881614
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mozWOW",
      "indices" : [ 81, 88 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/dpM4hcHoJw",
      "expanded_url" : "https:\/\/de.m.wikipedia.org\/wiki\/Oh,_wie_sch%C3%B6n_ist_Panama",
      "display_url" : "de.m.wikipedia.org\/wiki\/Oh,_wie_s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "840573687145332736",
  "text" : "Now: @betatim explaining roadmaps, using classic German literature as an example #mozWOW  https:\/\/t.co\/dpM4hcHoJw",
  "id" : 840573687145332736,
  "created_at" : "2017-03-11 14:42:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mozwow",
      "indices" : [ 35, 42 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "840552321163677696",
  "text" : "A friendly reminder for the \uD83C\uDDEA\uD83C\uDDFAs at #mozwow: \uD83C\uDDE8\uD83C\uDDE6 &amp; \uD83C\uDDFA\uD83C\uDDF8 are going into DST tonight, forwarding your clock by 1h. Good way to miss a \u2708\uFE0F.",
  "id" : 840552321163677696,
  "created_at" : "2017-03-11 13:17:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 62 ],
      "url" : "https:\/\/t.co\/2n9pCjJGDZ",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BRfLYhtjmSi\/",
      "display_url" : "instagram.com\/p\/BRfLYhtjmSi\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.509407522267, -73.571169643052 ]
  },
  "id_str" : "840443645002186752",
  "text" : "Sucking it up @ BENELUX rue Sherbrooke https:\/\/t.co\/2n9pCjJGDZ",
  "id" : 840443645002186752,
  "created_at" : "2017-03-11 06:05:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 0, 14 ],
      "id_str" : "352650591",
      "id" : 352650591
    }, {
      "name" : "Hao Ye",
      "screen_name" : "Hao_and_Y",
      "indices" : [ 15, 25 ],
      "id_str" : "111093392",
      "id" : 111093392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "840422199135621121",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.51335225663489, -73.57124838884627 ]
  },
  "id_str" : "840436892281774081",
  "in_reply_to_user_id" : 352650591,
  "text" : "@Protohedgehog @Hao_and_Y it was me asking about it, see our manuscript. :D",
  "id" : 840436892281774081,
  "in_reply_to_status_id" : 840422199135621121,
  "created_at" : "2017-03-11 05:39:04 +0000",
  "in_reply_to_screen_name" : "Protohedgehog",
  "in_reply_to_user_id_str" : "352650591",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mozwow",
      "indices" : [ 4, 11 ]
    } ],
    "urls" : [ {
      "indices" : [ 51, 74 ],
      "url" : "https:\/\/t.co\/y1AiemGGS1",
      "expanded_url" : "https:\/\/goo.gl\/maps\/dncP4srXzDJ2",
      "display_url" : "goo.gl\/maps\/dncP4srXz\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.51336697186487, -73.57117219680212 ]
  },
  "id_str" : "840390918293319680",
  "text" : "Hey #mozwow, we ended up here: Mckibbins Irish Pub https:\/\/t.co\/y1AiemGGS1",
  "id" : 840390918293319680,
  "created_at" : "2017-03-11 02:36:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "open_epi",
      "screen_name" : "april_cs",
      "indices" : [ 5, 14 ],
      "id_str" : "621133833",
      "id" : 621133833
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mozwow",
      "indices" : [ 96, 103 ]
    } ],
    "urls" : [ {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/tG4UJEeBTA",
      "expanded_url" : "http:\/\/m.imgur.com\/ef4TAV9?r",
      "display_url" : "m.imgur.com\/ef4TAV9?r"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.51222504923886, -73.57037860618429 ]
  },
  "id_str" : "840357308504915968",
  "text" : "Now: @april_cs about The Method, a podcast that nests \u201Copen\u201D like this: https:\/\/t.co\/tG4UJEeBTA #mozwow",
  "id" : 840357308504915968,
  "created_at" : "2017-03-11 00:22:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Timoth\u00E9e Poisot",
      "screen_name" : "tpoi",
      "indices" : [ 35, 40 ],
      "id_str" : "9377892",
      "id" : 9377892
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/840355795351015425\/photo\/1",
      "indices" : [ 69, 92 ],
      "url" : "https:\/\/t.co\/U8fC2GW5zL",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/C6mLI3rWYAQygb0.jpg",
      "id_str" : "840355789982294020",
      "id" : 840355789982294020,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C6mLI3rWYAQygb0.jpg",
      "sizes" : [ {
        "h" : 1863,
        "resize" : "fit",
        "w" : 2861
      }, {
        "h" : 443,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1334,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 781,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/U8fC2GW5zL"
    } ],
    "hashtags" : [ {
      "text" : "mozwow",
      "indices" : [ 61, 68 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.5121077550999, -73.57036454609927 ]
  },
  "id_str" : "840355795351015425",
  "text" : "Rule #1 of the 3 big data rules by @tpoi: it\u2019s not big data. #mozwow https:\/\/t.co\/U8fC2GW5zL",
  "id" : 840355795351015425,
  "created_at" : "2017-03-11 00:16:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "figshare",
      "screen_name" : "figshare",
      "indices" : [ 3, 12 ],
      "id_str" : "224631899",
      "id" : 224631899
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 14, 30 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "840333076446220288",
  "text" : "RT @figshare: @gedankenstuecke That's the one. We're updating our knowledge base so@will make sure that's all in there!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 0, 16 ],
        "id_str" : "14286491",
        "id" : 14286491
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "840332309979119624",
    "geo" : { },
    "id_str" : "840332919218589696",
    "in_reply_to_user_id" : 14286491,
    "text" : "@gedankenstuecke That's the one. We're updating our knowledge base so@will make sure that's all in there!",
    "id" : 840332919218589696,
    "in_reply_to_status_id" : 840332309979119624,
    "created_at" : "2017-03-10 22:45:55 +0000",
    "in_reply_to_screen_name" : "gedankenstuecke",
    "in_reply_to_user_id_str" : "14286491",
    "user" : {
      "name" : "figshare",
      "screen_name" : "figshare",
      "protected" : false,
      "id_str" : "224631899",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1756579306\/spiralsticker_normal.png",
      "id" : 224631899,
      "verified" : true
    }
  },
  "id" : 840333076446220288,
  "created_at" : "2017-03-10 22:46:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "figshare",
      "screen_name" : "figshare",
      "indices" : [ 3, 12 ],
      "id_str" : "224631899",
      "id" : 224631899
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 14, 30 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "840333067143262208",
  "text" : "RT @figshare: @gedankenstuecke The CLOCKSS business model did not support the volume of figshare and Dryad, so we moved to DPN :)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 0, 16 ],
        "id_str" : "14286491",
        "id" : 14286491
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "840313129418575872",
    "geo" : { },
    "id_str" : "840321615699292167",
    "in_reply_to_user_id" : 14286491,
    "text" : "@gedankenstuecke The CLOCKSS business model did not support the volume of figshare and Dryad, so we moved to DPN :)",
    "id" : 840321615699292167,
    "in_reply_to_status_id" : 840313129418575872,
    "created_at" : "2017-03-10 22:01:00 +0000",
    "in_reply_to_screen_name" : "gedankenstuecke",
    "in_reply_to_user_id_str" : "14286491",
    "user" : {
      "name" : "figshare",
      "screen_name" : "figshare",
      "protected" : false,
      "id_str" : "224631899",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1756579306\/spiralsticker_normal.png",
      "id" : 224631899,
      "verified" : true
    }
  },
  "id" : 840333067143262208,
  "created_at" : "2017-03-10 22:46:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "figshare",
      "screen_name" : "figshare",
      "indices" : [ 0, 9 ],
      "id_str" : "224631899",
      "id" : 224631899
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "840332919218589696",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.50944217777597, -73.57113445830576 ]
  },
  "id_str" : "840333059950051329",
  "in_reply_to_user_id" : 224631899,
  "text" : "@figshare great, thanks! \uD83D\uDC96",
  "id" : 840333059950051329,
  "in_reply_to_status_id" : 840332919218589696,
  "created_at" : "2017-03-10 22:46:28 +0000",
  "in_reply_to_screen_name" : "figshare",
  "in_reply_to_user_id_str" : "224631899",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/840333012835401728\/photo\/1",
      "indices" : [ 53, 76 ],
      "url" : "https:\/\/t.co\/eX8K03yGMr",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/C6l2aoTVwAAuOHi.jpg",
      "id_str" : "840333005348519936",
      "id" : 840333005348519936,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C6l2aoTVwAAuOHi.jpg",
      "sizes" : [ {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      }, {
        "h" : 1280,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 1280,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      } ],
      "display_url" : "pic.twitter.com\/eX8K03yGMr"
    } ],
    "hashtags" : [ {
      "text" : "mozwow",
      "indices" : [ 32, 39 ]
    }, {
      "text" : "dailyselfie",
      "indices" : [ 40, 52 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.5093065846665, -73.57113810236746 ]
  },
  "id_str" : "840333012835401728",
  "text" : "Yep, just as snowy as expected. #mozwow #dailyselfie https:\/\/t.co\/eX8K03yGMr",
  "id" : 840333012835401728,
  "created_at" : "2017-03-10 22:46:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "figshare",
      "screen_name" : "figshare",
      "indices" : [ 0, 9 ],
      "id_str" : "224631899",
      "id" : 224631899
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/zTFXLN2U8Y",
      "expanded_url" : "https:\/\/dpn.org\/",
      "display_url" : "dpn.org"
    } ]
  },
  "in_reply_to_status_id_str" : "840321615699292167",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.50937197072741, -73.57110001951672 ]
  },
  "id_str" : "840332309979119624",
  "in_reply_to_user_id" : 224631899,
  "text" : "@figshare ah, thanks, couldn\u2019t find any info on it when searching for it today, so https:\/\/t.co\/zTFXLN2U8Y it is? :)",
  "id" : 840332309979119624,
  "in_reply_to_status_id" : 840321615699292167,
  "created_at" : "2017-03-10 22:43:29 +0000",
  "in_reply_to_screen_name" : "figshare",
  "in_reply_to_user_id_str" : "224631899",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "figshare",
      "screen_name" : "figshare",
      "indices" : [ 66, 75 ],
      "id_str" : "224631899",
      "id" : 224631899
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/GFRQohzyEF",
      "expanded_url" : "https:\/\/support.figshare.com\/support\/solutions\/articles\/6000079089-how-persistent-is-my-research-",
      "display_url" : "support.figshare.com\/support\/soluti\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.51221379451401, -73.56995844208913 ]
  },
  "id_str" : "840313129418575872",
  "text" : "Curious: Does anyone know what happened to the CLOCKSS backup for @figshare? Why stopping in March 2015? https:\/\/t.co\/GFRQohzyEF",
  "id" : 840313129418575872,
  "created_at" : "2017-03-10 21:27:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bruno Vieira",
      "screen_name" : "bmpvieira",
      "indices" : [ 36, 46 ],
      "id_str" : "55388565",
      "id" : 55388565
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/840298648542019589\/photo\/1",
      "indices" : [ 66, 89 ],
      "url" : "https:\/\/t.co\/i1JC4VT1G8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/C6lXKNZXAAAYESx.jpg",
      "id_str" : "840298638387642368",
      "id" : 840298638387642368,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C6lXKNZXAAAYESx.jpg",
      "sizes" : [ {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 3024,
        "resize" : "fit",
        "w" : 4032
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/i1JC4VT1G8"
    } ],
    "hashtags" : [ {
      "text" : "mozwow",
      "indices" : [ 58, 65 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.51220745962172, -73.57020643193923 ]
  },
  "id_str" : "840298648542019589",
  "text" : "Found the coolest keyboard cover on @bmpvieira\u2019s machine. #mozwow https:\/\/t.co\/i1JC4VT1G8",
  "id" : 840298648542019589,
  "created_at" : "2017-03-10 20:29:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nicolas Le Novere",
      "screen_name" : "lenovere",
      "indices" : [ 3, 12 ],
      "id_str" : "110751834",
      "id" : 110751834
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "840282053425913856",
  "text" : "RT @lenovere: \"Pipette biologist. Microscopy biologist. Cell culture biologist. Have you ever heard any of those job titles?\" https:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 112, 135 ],
        "url" : "https:\/\/t.co\/oOVPP5Z0xY",
        "expanded_url" : "http:\/\/journals.plos.org\/plosbiology\/article?id=10.1371\/journal.pbio.2002050",
        "display_url" : "journals.plos.org\/plosbiology\/ar\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "840273962194096130",
    "text" : "\"Pipette biologist. Microscopy biologist. Cell culture biologist. Have you ever heard any of those job titles?\" https:\/\/t.co\/oOVPP5Z0xY",
    "id" : 840273962194096130,
    "created_at" : "2017-03-10 18:51:38 +0000",
    "user" : {
      "name" : "Nicolas Le Novere",
      "screen_name" : "lenovere",
      "protected" : false,
      "id_str" : "110751834",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/662778617638862848\/MmcUpgGi_normal.jpg",
      "id" : 110751834,
      "verified" : false
    }
  },
  "id" : 840282053425913856,
  "created_at" : "2017-03-10 19:23:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mozwow",
      "indices" : [ 113, 120 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/Bk88uNjsz9",
      "expanded_url" : "http:\/\/learngitbranching.js.org\/",
      "display_url" : "learngitbranching.js.org"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.51211472421353, -73.57035107019696 ]
  },
  "id_str" : "840276652814917632",
  "text" : "If you want to learn git branching (the command line-version) in your browser as a game: https:\/\/t.co\/Bk88uNjsz9 #mozwow",
  "id" : 840276652814917632,
  "created_at" : "2017-03-10 19:02:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lucy Patterson",
      "screen_name" : "lu_cyP",
      "indices" : [ 0, 7 ],
      "id_str" : "99586343",
      "id" : 99586343
    }, {
      "name" : "Egle Ramanauskaite \u2623",
      "screen_name" : "Seplute",
      "indices" : [ 8, 16 ],
      "id_str" : "188833865",
      "id" : 188833865
    }, {
      "name" : "Mozilla Open Leaders",
      "screen_name" : "MozOpenLeaders",
      "indices" : [ 17, 32 ],
      "id_str" : "791070237949034496",
      "id" : 791070237949034496
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "840265471186345984",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.51243421334107, -73.57013986203508 ]
  },
  "id_str" : "840265646990589952",
  "in_reply_to_user_id" : 99586343,
  "text" : "@lu_cyP @Seplute @MozOpenLeaders that\u2019s some enthusiasm! \uD83D\uDE02",
  "id" : 840265646990589952,
  "in_reply_to_status_id" : 840265471186345984,
  "created_at" : "2017-03-10 18:18:36 +0000",
  "in_reply_to_screen_name" : "lu_cyP",
  "in_reply_to_user_id_str" : "99586343",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steph\u24D0nie Wright",
      "screen_name" : "shefw",
      "indices" : [ 5, 11 ],
      "id_str" : "48636190",
      "id" : 48636190
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/840265588152893441\/photo\/1",
      "indices" : [ 35, 58 ],
      "url" : "https:\/\/t.co\/1RprvbkyhS",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/C6k5Fm9W0AMhXiD.jpg",
      "id_str" : "840265574001332227",
      "id" : 840265574001332227,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C6k5Fm9W0AMhXiD.jpg",
      "sizes" : [ {
        "h" : 3024,
        "resize" : "fit",
        "w" : 4032
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/1RprvbkyhS"
    } ],
    "hashtags" : [ {
      "text" : "mozwow",
      "indices" : [ 24, 31 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.51218113739331, -73.57028716268854 ]
  },
  "id_str" : "840265588152893441",
  "text" : "Now: @shefw kicking off #mozwow! \uD83D\uDC96 https:\/\/t.co\/1RprvbkyhS",
  "id" : 840265588152893441,
  "created_at" : "2017-03-10 18:18:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Egle Ramanauskaite \u2623",
      "screen_name" : "Seplute",
      "indices" : [ 0, 8 ],
      "id_str" : "188833865",
      "id" : 188833865
    }, {
      "name" : "Lucy Patterson",
      "screen_name" : "lu_cyP",
      "indices" : [ 32, 39 ],
      "id_str" : "99586343",
      "id" : 99586343
    }, {
      "name" : "Mozilla Open Leaders",
      "screen_name" : "MozOpenLeaders",
      "indices" : [ 40, 55 ],
      "id_str" : "791070237949034496",
      "id" : 791070237949034496
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "840260809657847808",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.51216805646631, -73.57030024729804 ]
  },
  "id_str" : "840264930939031552",
  "in_reply_to_user_id" : 188833865,
  "text" : "@Seplute yes, and I will mentor @lu_cyP @MozOpenLeaders! \uD83D\uDE02",
  "id" : 840264930939031552,
  "in_reply_to_status_id" : 840260809657847808,
  "created_at" : "2017-03-10 18:15:45 +0000",
  "in_reply_to_screen_name" : "Seplute",
  "in_reply_to_user_id_str" : "188833865",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mozilla Science Lab",
      "screen_name" : "MozillaScience",
      "indices" : [ 3, 18 ],
      "id_str" : "1428575976",
      "id" : 1428575976
    }, {
      "name" : "Maison Notman House",
      "screen_name" : "notman",
      "indices" : [ 103, 110 ],
      "id_str" : "81349979",
      "id" : 81349979
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/MozillaScience\/status\/840230740625252352\/photo\/1",
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/3bJbka5t4A",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/C6kZZo1WgAIcoy5.jpg",
      "id_str" : "840230733729923074",
      "id" : 840230733729923074,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C6kZZo1WgAIcoy5.jpg",
      "sizes" : [ {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/3bJbka5t4A"
    } ],
    "hashtags" : [ {
      "text" : "mozwow",
      "indices" : [ 42, 49 ]
    }, {
      "text" : "montreal",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "840254681855217664",
  "text" : "RT @MozillaScience: Kicking off our  2017 #mozwow #montreal w\/ mentor training + reflection activities @notman :) https:\/\/t.co\/3bJbka5t4A",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Maison Notman House",
        "screen_name" : "notman",
        "indices" : [ 83, 90 ],
        "id_str" : "81349979",
        "id" : 81349979
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/MozillaScience\/status\/840230740625252352\/photo\/1",
        "indices" : [ 94, 117 ],
        "url" : "https:\/\/t.co\/3bJbka5t4A",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/C6kZZo1WgAIcoy5.jpg",
        "id_str" : "840230733729923074",
        "id" : 840230733729923074,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C6kZZo1WgAIcoy5.jpg",
        "sizes" : [ {
          "h" : 900,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/3bJbka5t4A"
      } ],
      "hashtags" : [ {
        "text" : "mozwow",
        "indices" : [ 22, 29 ]
      }, {
        "text" : "montreal",
        "indices" : [ 30, 39 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "840230740625252352",
    "text" : "Kicking off our  2017 #mozwow #montreal w\/ mentor training + reflection activities @notman :) https:\/\/t.co\/3bJbka5t4A",
    "id" : 840230740625252352,
    "created_at" : "2017-03-10 15:59:53 +0000",
    "user" : {
      "name" : "Mozilla Science Lab",
      "screen_name" : "MozillaScience",
      "protected" : false,
      "id_str" : "1428575976",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/687287790049034240\/lwIk-ZQT_normal.png",
      "id" : 1428575976,
      "verified" : false
    }
  },
  "id" : 840254681855217664,
  "created_at" : "2017-03-10 17:35:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 56 ],
      "url" : "https:\/\/t.co\/MSrdEBgeam",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BRdd-y-D5z4\/",
      "display_url" : "instagram.com\/p\/BRdd-y-D5z4\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.505277777778, -73.568333333333 ]
  },
  "id_str" : "840203080465563648",
  "text" : "Trippy @ St. James United Church https:\/\/t.co\/MSrdEBgeam",
  "id" : 840203080465563648,
  "created_at" : "2017-03-10 14:09:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/840004092730662912\/photo\/1",
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/zlpptCq18j",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/C6hLRSTVoAAfsf_.jpg",
      "id_str" : "840004090847404032",
      "id" : 840004090847404032,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C6hLRSTVoAAfsf_.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/zlpptCq18j"
    } ],
    "hashtags" : [ {
      "text" : "mozWOW",
      "indices" : [ 107, 114 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "840004092730662912",
  "text" : "\u00ABYour hands look tiny compared to that mug.\u00BB \u2014 \u00ABDude, your face looks tiny compared to that mug.\u00BB made it! #mozWOW https:\/\/t.co\/zlpptCq18j",
  "id" : 840004092730662912,
  "created_at" : "2017-03-10 00:59:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Head",
      "screen_name" : "betatim",
      "indices" : [ 0, 8 ],
      "id_str" : "18881614",
      "id" : 18881614
    }, {
      "name" : "Lukas Geiger",
      "screen_name" : "_lgeiger",
      "indices" : [ 9, 18 ],
      "id_str" : "792555550550659072",
      "id" : 792555550550659072
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "839984900954607616",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.45799559653213, -73.75272254266248 ]
  },
  "id_str" : "839986933111627778",
  "in_reply_to_user_id" : 18881614,
  "text" : "@betatim @_lgeiger ok. Maybe give me a google maps link?",
  "id" : 839986933111627778,
  "in_reply_to_status_id" : 839984900954607616,
  "created_at" : "2017-03-09 23:51:05 +0000",
  "in_reply_to_screen_name" : "betatim",
  "in_reply_to_user_id_str" : "18881614",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Head",
      "screen_name" : "betatim",
      "indices" : [ 0, 8 ],
      "id_str" : "18881614",
      "id" : 18881614
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "839945793780006917",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.4601538463024, -73.75674226778115 ]
  },
  "id_str" : "839980409056313347",
  "in_reply_to_user_id" : 18881614,
  "text" : "@betatim touchdown! Let me make it through customs and I\u2019ll head there. How\u2019s our place? :D",
  "id" : 839980409056313347,
  "in_reply_to_status_id" : 839945793780006917,
  "created_at" : "2017-03-09 23:25:10 +0000",
  "in_reply_to_screen_name" : "betatim",
  "in_reply_to_user_id_str" : "18881614",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Head",
      "screen_name" : "betatim",
      "indices" : [ 21, 29 ],
      "id_str" : "18881614",
      "id" : 18881614
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.46869146168041, -0.4849858012698348 ]
  },
  "id_str" : "839876770233008128",
  "text" : "Finally: LHR \u2708\uFE0F YUL. @betatim let me know where you folks are at ~7pm.",
  "id" : 839876770233008128,
  "created_at" : "2017-03-09 16:33:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Head",
      "screen_name" : "betatim",
      "indices" : [ 0, 8 ],
      "id_str" : "18881614",
      "id" : 18881614
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/839876475427905537\/photo\/1",
      "indices" : [ 9, 32 ],
      "url" : "https:\/\/t.co\/DNQDPyikbR",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/C6fXMpeWYAI36tm.jpg",
      "id_str" : "839876467819438082",
      "id" : 839876467819438082,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/C6fXMpeWYAI36tm.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "fit",
        "w" : 330
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 150,
        "resize" : "fit",
        "w" : 330
      }, {
        "h" : 150,
        "resize" : "fit",
        "w" : 330
      }, {
        "h" : 150,
        "resize" : "fit",
        "w" : 330
      } ],
      "display_url" : "pic.twitter.com\/DNQDPyikbR"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "839867252941926400",
  "geo" : { },
  "id_str" : "839876475427905537",
  "in_reply_to_user_id" : 18881614,
  "text" : "@betatim https:\/\/t.co\/DNQDPyikbR",
  "id" : 839876475427905537,
  "in_reply_to_status_id" : 839867252941926400,
  "created_at" : "2017-03-09 16:32:10 +0000",
  "in_reply_to_screen_name" : "betatim",
  "in_reply_to_user_id_str" : "18881614",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Head",
      "screen_name" : "betatim",
      "indices" : [ 0, 8 ],
      "id_str" : "18881614",
      "id" : 18881614
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "839864465537519616",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.46976173695752, -0.4813095917187009 ]
  },
  "id_str" : "839865506391855106",
  "in_reply_to_user_id" : 18881614,
  "text" : "@betatim soon: \u201Chere\u2019s my blogpost on how I got arrested for trying to enter the cockpit\u201D.",
  "id" : 839865506391855106,
  "in_reply_to_status_id" : 839864465537519616,
  "created_at" : "2017-03-09 15:48:35 +0000",
  "in_reply_to_screen_name" : "betatim",
  "in_reply_to_user_id_str" : "18881614",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Head",
      "screen_name" : "betatim",
      "indices" : [ 0, 8 ],
      "id_str" : "18881614",
      "id" : 18881614
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/839864747306680321\/photo\/1",
      "indices" : [ 9, 32 ],
      "url" : "https:\/\/t.co\/BdePv7ttgK",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/C6fMh7DXEAIbqUC.jpg",
      "id_str" : "839864738687422466",
      "id" : 839864738687422466,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/C6fMh7DXEAIbqUC.jpg",
      "sizes" : [ {
        "h" : 274,
        "resize" : "fit",
        "w" : 396
      }, {
        "h" : 274,
        "resize" : "fit",
        "w" : 396
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 274,
        "resize" : "fit",
        "w" : 396
      }, {
        "h" : 274,
        "resize" : "fit",
        "w" : 396
      } ],
      "display_url" : "pic.twitter.com\/BdePv7ttgK"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "839864225120026625",
  "geo" : { },
  "id_str" : "839864747306680321",
  "in_reply_to_user_id" : 18881614,
  "text" : "@betatim https:\/\/t.co\/BdePv7ttgK",
  "id" : 839864747306680321,
  "in_reply_to_status_id" : 839864225120026625,
  "created_at" : "2017-03-09 15:45:34 +0000",
  "in_reply_to_screen_name" : "betatim",
  "in_reply_to_user_id_str" : "18881614",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Head",
      "screen_name" : "betatim",
      "indices" : [ 0, 8 ],
      "id_str" : "18881614",
      "id" : 18881614
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "839863905333702658",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.46965800893248, -0.4812839404698801 ]
  },
  "id_str" : "839864245651128320",
  "in_reply_to_user_id" : 18881614,
  "text" : "@betatim they wouldn\u2019t let me work on the contributor guidelines for the cockpit :P",
  "id" : 839864245651128320,
  "in_reply_to_status_id" : 839863905333702658,
  "created_at" : "2017-03-09 15:43:34 +0000",
  "in_reply_to_screen_name" : "betatim",
  "in_reply_to_user_id_str" : "18881614",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Head",
      "screen_name" : "betatim",
      "indices" : [ 0, 8 ],
      "id_str" : "18881614",
      "id" : 18881614
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "839863603385806849",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.46970452400921, -0.4812836831914878 ]
  },
  "id_str" : "839863813008654336",
  "in_reply_to_user_id" : 18881614,
  "text" : "@betatim yes, boarding should start soon. Make sure they have some drinks and food left for me by the time I arrive :p",
  "id" : 839863813008654336,
  "in_reply_to_status_id" : 839863603385806849,
  "created_at" : "2017-03-09 15:41:51 +0000",
  "in_reply_to_screen_name" : "betatim",
  "in_reply_to_user_id_str" : "18881614",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "intransit",
      "indices" : [ 33, 43 ]
    } ],
    "urls" : [ {
      "indices" : [ 66, 89 ],
      "url" : "https:\/\/t.co\/pOdQ7thGHf",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BRbCxC3joEd\/",
      "display_url" : "instagram.com\/p\/BRbCxC3joEd\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.471739053324, -0.48669206126068 ]
  },
  "id_str" : "839861745527193601",
  "text" : "The shared experience of waiting #intransit @ Heathrow Terminal 5 https:\/\/t.co\/pOdQ7thGHf",
  "id" : 839861745527193601,
  "created_at" : "2017-03-09 15:33:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 41 ],
      "url" : "https:\/\/t.co\/VU0LIjZVe7",
      "expanded_url" : "http:\/\/dogswithtonguestickingoutalittle.tumblr.com\/post\/158121892303\/ernie-does-not-understand-the-concept-of-keeping",
      "display_url" : "\u2026thtonguestickingoutalittle.tumblr.com\/post\/158121892\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.47250240282646, -0.488306686339191 ]
  },
  "id_str" : "839853040588980224",
  "text" : "looks right to me https:\/\/t.co\/VU0LIjZVe7",
  "id" : 839853040588980224,
  "created_at" : "2017-03-09 14:59:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Bond",
      "screen_name" : "TheLabAndField",
      "indices" : [ 0, 15 ],
      "id_str" : "1060545835",
      "id" : 1060545835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "839796292129804288",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.45223480637033, 8.557970672688205 ]
  },
  "id_str" : "839796605792489472",
  "in_reply_to_user_id" : 1060545835,
  "text" : "@TheLabAndField all the best!",
  "id" : 839796605792489472,
  "in_reply_to_status_id" : 839796292129804288,
  "created_at" : "2017-03-09 11:14:48 +0000",
  "in_reply_to_screen_name" : "TheLabAndField",
  "in_reply_to_user_id_str" : "1060545835",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Bond",
      "screen_name" : "TheLabAndField",
      "indices" : [ 0, 15 ],
      "id_str" : "1060545835",
      "id" : 1060545835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "839795982707666944",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.45238955137082, 8.558975402273758 ]
  },
  "id_str" : "839796210382827521",
  "in_reply_to_user_id" : 1060545835,
  "text" : "@TheLabAndField oh no, too bad :(",
  "id" : 839796210382827521,
  "in_reply_to_status_id" : 839795982707666944,
  "created_at" : "2017-03-09 11:13:13 +0000",
  "in_reply_to_screen_name" : "TheLabAndField",
  "in_reply_to_user_id_str" : "1060545835",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Bond",
      "screen_name" : "TheLabAndField",
      "indices" : [ 0, 15 ],
      "id_str" : "1060545835",
      "id" : 1060545835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "839795195629699072",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.4519305164435, 8.558780425751312 ]
  },
  "id_str" : "839795365972967424",
  "in_reply_to_user_id" : 1060545835,
  "text" : "@TheLabAndField just a quick layover today. But I\u2019ll be in London Monday &amp; Tuesday.",
  "id" : 839795365972967424,
  "in_reply_to_status_id" : 839795195629699072,
  "created_at" : "2017-03-09 11:09:52 +0000",
  "in_reply_to_screen_name" : "TheLabAndField",
  "in_reply_to_user_id_str" : "1060545835",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.45228993584501, 8.558980841018206 ]
  },
  "id_str" : "839794503078850560",
  "text" : "ZRH \u2708\uFE0F LHR.",
  "id" : 839794503078850560,
  "created_at" : "2017-03-09 11:06:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Slobodan Radicev",
      "screen_name" : "RadicevSlobodan",
      "indices" : [ 0, 16 ],
      "id_str" : "1718512256",
      "id" : 1718512256
    }, {
      "name" : "Achintya Rao \u2022 \u0C85\u0C9A\u0CBF\u0C82\u0CA4\u0CCD\u0CAF \u0CB0\u0CBE\u0CB5",
      "screen_name" : "RaoOfPhysics",
      "indices" : [ 17, 30 ],
      "id_str" : "67529128",
      "id" : 67529128
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "839770721651941377",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.45029596443425, 8.562157870798087 ]
  },
  "id_str" : "839771057234055169",
  "in_reply_to_user_id" : 1718512256,
  "text" : "@RadicevSlobodan @RaoOfPhysics I\u2019d be a millionaire if I\u2019d get a \u20AC every time I have to explain that bacon is meat too.",
  "id" : 839771057234055169,
  "in_reply_to_status_id" : 839770721651941377,
  "created_at" : "2017-03-09 09:33:16 +0000",
  "in_reply_to_screen_name" : "RadicevSlobodan",
  "in_reply_to_user_id_str" : "1718512256",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. David Shiffman",
      "screen_name" : "WhySharksMatter",
      "indices" : [ 0, 16 ],
      "id_str" : "66182591",
      "id" : 66182591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "839597468635512832",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.45022558237811, 8.562273881548572 ]
  },
  "id_str" : "839770607004893184",
  "in_reply_to_user_id" : 66182591,
  "text" : "@WhySharksMatter just sneak it into your publication list :p",
  "id" : 839770607004893184,
  "in_reply_to_status_id" : 839597468635512832,
  "created_at" : "2017-03-09 09:31:29 +0000",
  "in_reply_to_screen_name" : "WhySharksMatter",
  "in_reply_to_user_id_str" : "66182591",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/ogjSnhT8Nk",
      "expanded_url" : "https:\/\/twitter.com\/MozillaScience\/status\/839550706839248896",
      "display_url" : "twitter.com\/MozillaScience\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.41250566649136, 8.545135057037566 ]
  },
  "id_str" : "839768172559478784",
  "text" : "Just feel that \u201Cthe organization WikiLeaks\u201D is a bit of a mouthful for a single anti-semitic rapist in hiding. https:\/\/t.co\/ogjSnhT8Nk",
  "id" : 839768172559478784,
  "created_at" : "2017-03-09 09:21:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mozilla Science Lab",
      "screen_name" : "MozillaScience",
      "indices" : [ 3, 18 ],
      "id_str" : "1428575976",
      "id" : 1428575976
    }, {
      "name" : "Mozilla",
      "screen_name" : "mozilla",
      "indices" : [ 109, 117 ],
      "id_str" : "106682853",
      "id" : 106682853
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "839767852932562944",
  "text" : "RT @MozillaScience: \"(T)he CIA is undermining the security of the internet \u2013 and so is Wikileaks\". Read full @mozilla statement here: https\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Mozilla",
        "screen_name" : "mozilla",
        "indices" : [ 89, 97 ],
        "id_str" : "106682853",
        "id" : 106682853
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/CXvS6WaPnf",
        "expanded_url" : "https:\/\/mzl.la\/2lZrQvs",
        "display_url" : "mzl.la\/2lZrQvs"
      } ]
    },
    "geo" : { },
    "id_str" : "839550706839248896",
    "text" : "\"(T)he CIA is undermining the security of the internet \u2013 and so is Wikileaks\". Read full @mozilla statement here: https:\/\/t.co\/CXvS6WaPnf",
    "id" : 839550706839248896,
    "created_at" : "2017-03-08 18:57:41 +0000",
    "user" : {
      "name" : "Mozilla Science Lab",
      "screen_name" : "MozillaScience",
      "protected" : false,
      "id_str" : "1428575976",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/687287790049034240\/lwIk-ZQT_normal.png",
      "id" : 1428575976,
      "verified" : false
    }
  },
  "id" : 839767852932562944,
  "created_at" : "2017-03-09 09:20:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Achintya Rao \u2022 \u0C85\u0C9A\u0CBF\u0C82\u0CA4\u0CCD\u0CAF \u0CB0\u0CBE\u0CB5",
      "screen_name" : "RaoOfPhysics",
      "indices" : [ 0, 13 ],
      "id_str" : "67529128",
      "id" : 67529128
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "839752032961560577",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.37821884987532, 8.538184790935167 ]
  },
  "id_str" : "839766503071305729",
  "in_reply_to_user_id" : 67529128,
  "text" : "@RaoOfPhysics it\u2019s still the same where I grew up. And apparently also close to the Swiss border. :D",
  "id" : 839766503071305729,
  "in_reply_to_status_id" : 839752032961560577,
  "created_at" : "2017-03-09 09:15:11 +0000",
  "in_reply_to_screen_name" : "RaoOfPhysics",
  "in_reply_to_user_id_str" : "67529128",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35928257466048, 8.5879117436787 ]
  },
  "id_str" : "839607610869440512",
  "text" : "&lt; 30 minutes after explaining that \u201Cvegetarian\u201D means no \uD83D\uDC1F for me, I accidentally end up buying a sandwich full of undeclared \uD83D\uDC16\u2026 \uD83D\uDE25\uD83E\uDD26\u200D\u2640\uFE0F",
  "id" : 839607610869440512,
  "created_at" : "2017-03-08 22:43:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/839395610889433088\/photo\/1",
      "indices" : [ 33, 56 ],
      "url" : "https:\/\/t.co\/QvYzagVc1T",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/C6YhzqGWgAESDog.jpg",
      "id_str" : "839395551909150721",
      "id" : 839395551909150721,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C6YhzqGWgAESDog.jpg",
      "sizes" : [ {
        "h" : 3024,
        "resize" : "fit",
        "w" : 4032
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/QvYzagVc1T"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/839395610889433088\/photo\/1",
      "indices" : [ 33, 56 ],
      "url" : "https:\/\/t.co\/QvYzagVc1T",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/C6YhzsWWgAA3YR2.jpg",
      "id_str" : "839395552513130496",
      "id" : 839395552513130496,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C6YhzsWWgAA3YR2.jpg",
      "sizes" : [ {
        "h" : 4032,
        "resize" : "fit",
        "w" : 3024
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      } ],
      "display_url" : "pic.twitter.com\/QvYzagVc1T"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17231864383361, 8.627531871940192 ]
  },
  "id_str" : "839395610889433088",
  "text" : "Bioinformatics, the early years. https:\/\/t.co\/QvYzagVc1T",
  "id" : 839395610889433088,
  "created_at" : "2017-03-08 08:41:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/urClptpsgf",
      "expanded_url" : "https:\/\/www.etsy.com\/listing\/511373289\/rainbow-chakra-jewelry-chakra-ring-yoga",
      "display_url" : "etsy.com\/listing\/511373\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1140665797523, 8.753433782756243 ]
  },
  "id_str" : "839262208530006016",
  "text" : "Folks, apparently mosses and lichens have been recruited for the gay agenda! \uD83C\uDF08 https:\/\/t.co\/urClptpsgf",
  "id" : 839262208530006016,
  "created_at" : "2017-03-07 23:51:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Nelson",
      "screen_name" : "blueyedgenes",
      "indices" : [ 0, 13 ],
      "id_str" : "760870811494297600",
      "id" : 760870811494297600
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "839224498700210176",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11390047638379, 8.752942754011803 ]
  },
  "id_str" : "839225619682627585",
  "in_reply_to_user_id" : 760870811494297600,
  "text" : "@blueyedgenes had them for like 3 years now and could never wear them so far as they\u2019re too warm for our winters! So -17\u00B0C should be a test!",
  "id" : 839225619682627585,
  "in_reply_to_status_id" : 839224498700210176,
  "created_at" : "2017-03-07 21:25:54 +0000",
  "in_reply_to_screen_name" : "blueyedgenes",
  "in_reply_to_user_id_str" : "760870811494297600",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "839223748658147328",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11390047638379, 8.752942754011803 ]
  },
  "id_str" : "839225316275077121",
  "in_reply_to_user_id" : 14286491,
  "text" : "One of the best things about them: one of the first students I mentored made them as a thank you for a job they considered well done. \uD83D\uDE02\uD83D\uDE0D",
  "id" : 839225316275077121,
  "in_reply_to_status_id" : 839223748658147328,
  "created_at" : "2017-03-07 21:24:42 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/839223748658147328\/photo\/1",
      "indices" : [ 42, 65 ],
      "url" : "https:\/\/t.co\/Ip8dGhjWEv",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/C6WFhEAWAAEsrLs.jpg",
      "id_str" : "839223708631826433",
      "id" : 839223708631826433,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C6WFhEAWAAEsrLs.jpg",
      "sizes" : [ {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 4032,
        "resize" : "fit",
        "w" : 3024
      } ],
      "display_url" : "pic.twitter.com\/Ip8dGhjWEv"
    } ],
    "hashtags" : [ {
      "text" : "mozWOW",
      "indices" : [ 34, 41 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "839183077943410689",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1140653465612, 8.75343794300232 ]
  },
  "id_str" : "839223748658147328",
  "in_reply_to_user_id" : 14286491,
  "text" : "Packed the DNA mittens. Ready for #mozWOW https:\/\/t.co\/Ip8dGhjWEv",
  "id" : 839223748658147328,
  "in_reply_to_status_id" : 839183077943410689,
  "created_at" : "2017-03-07 21:18:28 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BOSC",
      "screen_name" : "OBF_BOSC",
      "indices" : [ 3, 12 ],
      "id_str" : "583180584",
      "id" : 583180584
    }, {
      "name" : "Hackerspace Prague",
      "screen_name" : "brmlab",
      "indices" : [ 54, 61 ],
      "id_str" : "163493365",
      "id" : 163493365
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BOSC2017",
      "indices" : [ 80, 89 ]
    }, {
      "text" : "CodeFest",
      "indices" : [ 90, 99 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/PrGJcWbuCp",
      "expanded_url" : "https:\/\/www.open-bio.org\/wiki\/Codefest_2017",
      "display_url" : "open-bio.org\/wiki\/Codefest_\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "839213162390040579",
  "text" : "RT @OBF_BOSC: We're delighted that Prague hackerspace @brmlab will host the\npre-#BOSC2017 #CodeFest this July\nhttps:\/\/t.co\/PrGJcWbuCp",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Hackerspace Prague",
        "screen_name" : "brmlab",
        "indices" : [ 40, 47 ],
        "id_str" : "163493365",
        "id" : 163493365
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BOSC2017",
        "indices" : [ 66, 75 ]
      }, {
        "text" : "CodeFest",
        "indices" : [ 76, 85 ]
      } ],
      "urls" : [ {
        "indices" : [ 96, 119 ],
        "url" : "https:\/\/t.co\/PrGJcWbuCp",
        "expanded_url" : "https:\/\/www.open-bio.org\/wiki\/Codefest_2017",
        "display_url" : "open-bio.org\/wiki\/Codefest_\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "839194131591155712",
    "text" : "We're delighted that Prague hackerspace @brmlab will host the\npre-#BOSC2017 #CodeFest this July\nhttps:\/\/t.co\/PrGJcWbuCp",
    "id" : 839194131591155712,
    "created_at" : "2017-03-07 19:20:47 +0000",
    "user" : {
      "name" : "BOSC",
      "screen_name" : "OBF_BOSC",
      "protected" : false,
      "id_str" : "583180584",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2227105401\/BOSC-logo-square_normal.jpg",
      "id" : 583180584,
      "verified" : false
    }
  },
  "id" : 839213162390040579,
  "created_at" : "2017-03-07 20:36:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 70 ],
      "url" : "https:\/\/t.co\/gbZhxdB159",
      "expanded_url" : "https:\/\/twitter.com\/keyboardpipette\/status\/839191654032605185",
      "display_url" : "twitter.com\/keyboardpipett\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11406654948505, 8.753434396263998 ]
  },
  "id_str" : "839212620695601152",
  "text" : "It\u2019s like pie charts, but 485% more confusing. https:\/\/t.co\/gbZhxdB159",
  "id" : 839212620695601152,
  "created_at" : "2017-03-07 20:34:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christie Bahlai",
      "screen_name" : "cbahlai",
      "indices" : [ 0, 8 ],
      "id_str" : "958649520",
      "id" : 958649520
    }, {
      "name" : "Tim Head",
      "screen_name" : "betatim",
      "indices" : [ 9, 17 ],
      "id_str" : "18881614",
      "id" : 18881614
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "839199829544824833",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11406659138019, 8.753434126545235 ]
  },
  "id_str" : "839200758562242566",
  "in_reply_to_user_id" : 958649520,
  "text" : "@cbahlai @betatim yes, too bad you will not be there!",
  "id" : 839200758562242566,
  "in_reply_to_status_id" : 839199829544824833,
  "created_at" : "2017-03-07 19:47:07 +0000",
  "in_reply_to_screen_name" : "cbahlai",
  "in_reply_to_user_id_str" : "958649520",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Head",
      "screen_name" : "betatim",
      "indices" : [ 0, 8 ],
      "id_str" : "18881614",
      "id" : 18881614
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "839198034202361856",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1140666062495, 8.753433795216289 ]
  },
  "id_str" : "839199495061716995",
  "in_reply_to_user_id" : 18881614,
  "text" : "@betatim shall I bring some extra warm clothes for you? :D",
  "id" : 839199495061716995,
  "in_reply_to_status_id" : 839198034202361856,
  "created_at" : "2017-03-07 19:42:05 +0000",
  "in_reply_to_screen_name" : "betatim",
  "in_reply_to_user_id_str" : "18881614",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 0, 10 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "839189370821361664",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1140667736584, 8.753438006929436 ]
  },
  "id_str" : "839189560659705857",
  "in_reply_to_user_id" : 1385861262,
  "text" : "@Julie_B92 Mo\/Tu I will be in London, which will be tropical in comparison :D",
  "id" : 839189560659705857,
  "in_reply_to_status_id" : 839189370821361664,
  "created_at" : "2017-03-07 19:02:37 +0000",
  "in_reply_to_screen_name" : "Julie_B92",
  "in_reply_to_user_id_str" : "1385861262",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 0, 10 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "839188795610259462",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1140667736584, 8.753438006929436 ]
  },
  "id_str" : "839189243620638720",
  "in_reply_to_user_id" : 1385861262,
  "text" : "@Julie_B92 I\u2019m only in town from Thursday to Sunday. So not for me ;)",
  "id" : 839189243620638720,
  "in_reply_to_status_id" : 839188795610259462,
  "created_at" : "2017-03-07 19:01:21 +0000",
  "in_reply_to_screen_name" : "Julie_B92",
  "in_reply_to_user_id_str" : "1385861262",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Head",
      "screen_name" : "betatim",
      "indices" : [ 69, 77 ],
      "id_str" : "18881614",
      "id" : 18881614
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/839183077943410689\/photo\/1",
      "indices" : [ 136, 159 ],
      "url" : "https:\/\/t.co\/aI3dfM2tjp",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/C6Vgig_XEAEIOL2.jpg",
      "id_str" : "839183051661971457",
      "id" : 839183051661971457,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C6Vgig_XEAEIOL2.jpg",
      "sizes" : [ {
        "h" : 1136,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 1136,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 383
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1136,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/aI3dfM2tjp"
    } ],
    "hashtags" : [ {
      "text" : "mozwow",
      "indices" : [ 12, 19 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11405604008218, 8.753374277026404 ]
  },
  "id_str" : "839183077943410689",
  "text" : "Packing for #mozwow today. Until now I had hope that the forecast by @betatim was just off because it was too far in the future. \u2744\uFE0F\uD83D\uDC27\uD83C\uDF28\u2744\uFE0F https:\/\/t.co\/aI3dfM2tjp",
  "id" : 839183077943410689,
  "created_at" : "2017-03-07 18:36:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sebastian Greiner",
      "screen_name" : "Seb666",
      "indices" : [ 0, 7 ],
      "id_str" : "2365333778",
      "id" : 2365333778
    }, {
      "name" : "Lara",
      "screen_name" : "alibi_ranch",
      "indices" : [ 8, 20 ],
      "id_str" : "265371167",
      "id" : 265371167
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "839176022113284097",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.16514516857839, 8.702143665553802 ]
  },
  "id_str" : "839177022987436033",
  "in_reply_to_user_id" : 2365333778,
  "text" : "@Seb666 @alibi_ranch kein \uD83D\uDE18, falls ich noch ansteckend bin. Hat frisches Futter und Wasser. Hat seine 45 Minuten streicheln bekommen:)",
  "id" : 839177022987436033,
  "in_reply_to_status_id" : 839176022113284097,
  "created_at" : "2017-03-07 18:12:48 +0000",
  "in_reply_to_screen_name" : "Seb666",
  "in_reply_to_user_id_str" : "2365333778",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Best Travel",
      "screen_name" : "BestTraveI",
      "indices" : [ 3, 14 ],
      "id_str" : "813498306773053440",
      "id" : 813498306773053440
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/BestTraveI\/status\/838892192278196225\/photo\/1",
      "indices" : [ 40, 63 ],
      "url" : "https:\/\/t.co\/UedoWJOVrV",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/C6RX900WUAAsgG-.jpg",
      "id_str" : "838892150259601408",
      "id" : 838892150259601408,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C6RX900WUAAsgG-.jpg",
      "sizes" : [ {
        "h" : 439,
        "resize" : "fit",
        "w" : 718
      }, {
        "h" : 416,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 439,
        "resize" : "fit",
        "w" : 718
      }, {
        "h" : 439,
        "resize" : "fit",
        "w" : 718
      } ],
      "display_url" : "pic.twitter.com\/UedoWJOVrV"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "839169172072464389",
  "text" : "RT @BestTraveI: The London Eye, England https:\/\/t.co\/UedoWJOVrV",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/BestTraveI\/status\/838892192278196225\/photo\/1",
        "indices" : [ 24, 47 ],
        "url" : "https:\/\/t.co\/UedoWJOVrV",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/C6RX900WUAAsgG-.jpg",
        "id_str" : "838892150259601408",
        "id" : 838892150259601408,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C6RX900WUAAsgG-.jpg",
        "sizes" : [ {
          "h" : 439,
          "resize" : "fit",
          "w" : 718
        }, {
          "h" : 416,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 439,
          "resize" : "fit",
          "w" : 718
        }, {
          "h" : 439,
          "resize" : "fit",
          "w" : 718
        } ],
        "display_url" : "pic.twitter.com\/UedoWJOVrV"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "838892192278196225",
    "text" : "The London Eye, England https:\/\/t.co\/UedoWJOVrV",
    "id" : 838892192278196225,
    "created_at" : "2017-03-06 23:20:59 +0000",
    "user" : {
      "name" : "Best Travel",
      "screen_name" : "BestTraveI",
      "protected" : false,
      "id_str" : "813498306773053440",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838490231032664065\/-ktBh9X9_normal.jpg",
      "id" : 813498306773053440,
      "verified" : false
    }
  },
  "id" : 839169172072464389,
  "created_at" : "2017-03-07 17:41:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lara",
      "screen_name" : "alibi_ranch",
      "indices" : [ 0, 12 ],
      "id_str" : "265371167",
      "id" : 265371167
    }, {
      "name" : "Sebastian Greiner",
      "screen_name" : "Seb666",
      "indices" : [ 13, 20 ],
      "id_str" : "2365333778",
      "id" : 2365333778
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/839168627702116352\/photo\/1",
      "indices" : [ 28, 51 ],
      "url" : "https:\/\/t.co\/bTQLKcprFH",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/C6VTY-GXMAEnmQD.jpg",
      "id_str" : "839168594026115073",
      "id" : 839168594026115073,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C6VTY-GXMAEnmQD.jpg",
      "sizes" : [ {
        "h" : 4032,
        "resize" : "fit",
        "w" : 3024
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      } ],
      "display_url" : "pic.twitter.com\/bTQLKcprFH"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.18834965773875, 8.697961689912432 ]
  },
  "id_str" : "839168627702116352",
  "in_reply_to_user_id" : 265371167,
  "text" : "@alibi_ranch @Seb666 l\u00E4uft! https:\/\/t.co\/bTQLKcprFH",
  "id" : 839168627702116352,
  "created_at" : "2017-03-07 17:39:26 +0000",
  "in_reply_to_screen_name" : "alibi_ranch",
  "in_reply_to_user_id_str" : "265371167",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ship of Fools",
      "screen_name" : "shipoffoolscom",
      "indices" : [ 3, 18 ],
      "id_str" : "35720149",
      "id" : 35720149
    }, {
      "name" : "APILN",
      "screen_name" : "angrypiln",
      "indices" : [ 58, 68 ],
      "id_str" : "183389689",
      "id" : 183389689
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/shipoffoolscom\/status\/839062512142254080\/photo\/1",
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/oOEpKkh7Mj",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/C6TygljWYAIqwBi.jpg",
      "id_str" : "839062072247869442",
      "id" : 839062072247869442,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C6TygljWYAIqwBi.jpg",
      "sizes" : [ {
        "h" : 416,
        "resize" : "fit",
        "w" : 739
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 416,
        "resize" : "fit",
        "w" : 739
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 416,
        "resize" : "fit",
        "w" : 739
      } ],
      "display_url" : "pic.twitter.com\/oOEpKkh7Mj"
    } ],
    "hashtags" : [ {
      "text" : "Lent2017",
      "indices" : [ 43, 52 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "839071102185910276",
  "text" : "RT @shipoffoolscom: Spellchecker says yes. #Lent2017 (via @angrypiln) https:\/\/t.co\/oOEpKkh7Mj",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "APILN",
        "screen_name" : "angrypiln",
        "indices" : [ 38, 48 ],
        "id_str" : "183389689",
        "id" : 183389689
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/shipoffoolscom\/status\/839062512142254080\/photo\/1",
        "indices" : [ 50, 73 ],
        "url" : "https:\/\/t.co\/oOEpKkh7Mj",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/C6TygljWYAIqwBi.jpg",
        "id_str" : "839062072247869442",
        "id" : 839062072247869442,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C6TygljWYAIqwBi.jpg",
        "sizes" : [ {
          "h" : 416,
          "resize" : "fit",
          "w" : 739
        }, {
          "h" : 383,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 416,
          "resize" : "fit",
          "w" : 739
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 416,
          "resize" : "fit",
          "w" : 739
        } ],
        "display_url" : "pic.twitter.com\/oOEpKkh7Mj"
      } ],
      "hashtags" : [ {
        "text" : "Lent2017",
        "indices" : [ 23, 32 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "839062512142254080",
    "text" : "Spellchecker says yes. #Lent2017 (via @angrypiln) https:\/\/t.co\/oOEpKkh7Mj",
    "id" : 839062512142254080,
    "created_at" : "2017-03-07 10:37:46 +0000",
    "user" : {
      "name" : "Ship of Fools",
      "screen_name" : "shipoffoolscom",
      "protected" : false,
      "id_str" : "35720149",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/501767975536308224\/BxTDOXyF_normal.jpeg",
      "id" : 35720149,
      "verified" : false
    }
  },
  "id" : 839071102185910276,
  "created_at" : "2017-03-07 11:11:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/nZses3U5d2",
      "expanded_url" : "http:\/\/www.atlasobscura.com\/places\/dupont-underground",
      "display_url" : "atlasobscura.com\/places\/dupont-\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17237290562859, 8.627495172063746 ]
  },
  "id_str" : "839069945447219200",
  "text" : "Atlas Obscura needs a \u201EI want to visit in 4-8 years\u201C button\u2026 (how did I miss this last year?!) https:\/\/t.co\/nZses3U5d2",
  "id" : 839069945447219200,
  "created_at" : "2017-03-07 11:07:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "annakrystalli",
      "screen_name" : "annakrystalli",
      "indices" : [ 0, 14 ],
      "id_str" : "15090415",
      "id" : 15090415
    }, {
      "name" : "Dr Beth \uD83D\uDC3A",
      "screen_name" : "PhdGeek",
      "indices" : [ 15, 23 ],
      "id_str" : "27841081",
      "id" : 27841081
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "839051379578634240",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17235940582638, 8.627530446871537 ]
  },
  "id_str" : "839057172306722817",
  "in_reply_to_user_id" : 15090415,
  "text" : "@annakrystalli @PhdGeek yay, have fun!",
  "id" : 839057172306722817,
  "in_reply_to_status_id" : 839051379578634240,
  "created_at" : "2017-03-07 10:16:33 +0000",
  "in_reply_to_screen_name" : "annakrystalli",
  "in_reply_to_user_id_str" : "15090415",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sujai Kumar",
      "screen_name" : "sujaik",
      "indices" : [ 3, 10 ],
      "id_str" : "33651124",
      "id" : 33651124
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/GhS21ggfPv",
      "expanded_url" : "https:\/\/gowers.wordpress.com\/2014\/04\/24\/elsevier-journals-some-facts\/",
      "display_url" : "gowers.wordpress.com\/2014\/04\/24\/els\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "839053180197605377",
  "text" : "RT @sujaik: My letter to Elsevier Genomics today, and two links that helped me come to this decision:\n\nhttps:\/\/t.co\/GhS21ggfPv\n\nhttps:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/sujaik\/status\/839037913119789059\/photo\/1",
        "indices" : [ 140, 163 ],
        "url" : "https:\/\/t.co\/Xlbc2nrCQg",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/C6TAYGXWUAAgW8w.jpg",
        "id_str" : "839006950855692288",
        "id" : 839006950855692288,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C6TAYGXWUAAgW8w.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1016,
          "resize" : "fit",
          "w" : 948
        }, {
          "h" : 1016,
          "resize" : "fit",
          "w" : 948
        }, {
          "h" : 1016,
          "resize" : "fit",
          "w" : 948
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 634
        } ],
        "display_url" : "pic.twitter.com\/Xlbc2nrCQg"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 91, 114 ],
        "url" : "https:\/\/t.co\/GhS21ggfPv",
        "expanded_url" : "https:\/\/gowers.wordpress.com\/2014\/04\/24\/elsevier-journals-some-facts\/",
        "display_url" : "gowers.wordpress.com\/2014\/04\/24\/els\u2026"
      }, {
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/ks0zCLuCwk",
        "expanded_url" : "http:\/\/www.talyarkoni.org\/blog\/2016\/12\/12\/why-i-still-wont-review-for-or-publish-with-elsevier-and-think-you-shouldnt-either\/",
        "display_url" : "talyarkoni.org\/blog\/2016\/12\/1\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "839037913119789059",
    "text" : "My letter to Elsevier Genomics today, and two links that helped me come to this decision:\n\nhttps:\/\/t.co\/GhS21ggfPv\n\nhttps:\/\/t.co\/ks0zCLuCwk https:\/\/t.co\/Xlbc2nrCQg",
    "id" : 839037913119789059,
    "created_at" : "2017-03-07 09:00:01 +0000",
    "user" : {
      "name" : "Sujai Kumar",
      "screen_name" : "sujaik",
      "protected" : false,
      "id_str" : "33651124",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/499041232765460480\/J2nyoivC_normal.jpeg",
      "id" : 33651124,
      "verified" : false
    }
  },
  "id" : 839053180197605377,
  "created_at" : "2017-03-07 10:00:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 3, 19 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/Lpw33QXj1a",
      "expanded_url" : "https:\/\/twitter.com\/OBF_BOSC\/status\/838824572652695553",
      "display_url" : "twitter.com\/OBF_BOSC\/statu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "839051613834719232",
  "text" : "RT @gedankenstuecke: Submit your Bioinformatics open source project and speak to one of the most fun crowds I know: https:\/\/t.co\/Lpw33QXj1a",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 95, 118 ],
        "url" : "https:\/\/t.co\/Lpw33QXj1a",
        "expanded_url" : "https:\/\/twitter.com\/OBF_BOSC\/status\/838824572652695553",
        "display_url" : "twitter.com\/OBF_BOSC\/statu\u2026"
      } ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 50.1140698325462, 8.753437786744247 ]
    },
    "id_str" : "838826634891440128",
    "text" : "Submit your Bioinformatics open source project and speak to one of the most fun crowds I know: https:\/\/t.co\/Lpw33QXj1a",
    "id" : 838826634891440128,
    "created_at" : "2017-03-06 19:00:29 +0000",
    "user" : {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "protected" : false,
      "id_str" : "14286491",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
      "id" : 14286491,
      "verified" : true
    }
  },
  "id" : 839051613834719232,
  "created_at" : "2017-03-07 09:54:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Edmunds",
      "screen_name" : "SCEdmunds",
      "indices" : [ 3, 13 ],
      "id_str" : "176024190",
      "id" : 176024190
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "muslimban",
      "indices" : [ 47, 57 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "838906402001334273",
  "text" : "RT @SCEdmunds: Seems more Iranians effected by #muslimban than other countries put together. And it's coming out just before Iranian New Ye\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SCEdmunds\/status\/838905649572478977\/photo\/1",
        "indices" : [ 140, 163 ],
        "url" : "https:\/\/t.co\/aLeAxHIisf",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/C6RkO4FXQAA-s-C.jpg",
        "id_str" : "838905637333581824",
        "id" : 838905637333581824,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C6RkO4FXQAA-s-C.jpg",
        "sizes" : [ {
          "h" : 522,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 522,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 522,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 522,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/aLeAxHIisf"
      } ],
      "hashtags" : [ {
        "text" : "muslimban",
        "indices" : [ 32, 42 ]
      }, {
        "text" : "happynoruz",
        "indices" : [ 128, 139 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "838905649572478977",
    "text" : "Seems more Iranians effected by #muslimban than other countries put together. And it's coming out just before Iranian New Year. #happynoruz https:\/\/t.co\/aLeAxHIisf",
    "id" : 838905649572478977,
    "created_at" : "2017-03-07 00:14:27 +0000",
    "user" : {
      "name" : "Scott Edmunds",
      "screen_name" : "SCEdmunds",
      "protected" : false,
      "id_str" : "176024190",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1098248807\/chess_normal.JPG",
      "id" : 176024190,
      "verified" : false
    }
  },
  "id" : 838906402001334273,
  "created_at" : "2017-03-07 00:17:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "838888391127228417",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11406493131564, 8.753435278749933 ]
  },
  "id_str" : "838900569230147586",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC \uD83D\uDE22",
  "id" : 838900569230147586,
  "in_reply_to_status_id" : 838888391127228417,
  "created_at" : "2017-03-06 23:54:16 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mrgunn",
      "screen_name" : "mrgunn",
      "indices" : [ 0, 7 ],
      "id_str" : "15237935",
      "id" : 15237935
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "838867171753218050",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11406662325356, 8.753433466105315 ]
  },
  "id_str" : "838867677972213769",
  "in_reply_to_user_id" : 15237935,
  "text" : "@mrgunn dunno, I think they were pretty quick to have their agenda set by e.g. Pinker and ignoring anyone else for a good while.",
  "id" : 838867677972213769,
  "in_reply_to_status_id" : 838867171753218050,
  "created_at" : "2017-03-06 21:43:34 +0000",
  "in_reply_to_screen_name" : "mrgunn",
  "in_reply_to_user_id_str" : "15237935",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mrgunn",
      "screen_name" : "mrgunn",
      "indices" : [ 0, 7 ],
      "id_str" : "15237935",
      "id" : 15237935
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "838865600592101377",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1140666191399, 8.753433554174444 ]
  },
  "id_str" : "838866508507975680",
  "in_reply_to_user_id" : 15237935,
  "text" : "@mrgunn don\u2019t worry, it\u2019s not like they\u2019re taking much notice of\/waste time with any criticism. :)",
  "id" : 838866508507975680,
  "in_reply_to_status_id" : 838865600592101377,
  "created_at" : "2017-03-06 21:38:55 +0000",
  "in_reply_to_screen_name" : "mrgunn",
  "in_reply_to_user_id_str" : "15237935",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "March for Science",
      "screen_name" : "ScienceMarchDC",
      "indices" : [ 35, 50 ],
      "id_str" : "823565852922576897",
      "id" : 823565852922576897
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 136, 159 ],
      "url" : "https:\/\/t.co\/pabr3LeFM3",
      "expanded_url" : "https:\/\/twitter.com\/joanwalsh\/status\/838858687682838528",
      "display_url" : "twitter.com\/joanwalsh\/stat\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11406736395077, 8.75343449454109 ]
  },
  "id_str" : "838865158361477120",
  "text" : "Waiting for Jim Watson (cheered by @ScienceMarchDC) to agree with him on it, with people defending how apolitical science is. \u00AF\\_(\u30C4)_\/\u00AF https:\/\/t.co\/pabr3LeFM3",
  "id" : 838865158361477120,
  "created_at" : "2017-03-06 21:33:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Vexed Muddler",
      "screen_name" : "vexedmuddler",
      "indices" : [ 0, 13 ],
      "id_str" : "22200760",
      "id" : 22200760
    }, {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 14, 24 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "838858981275742208",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11406784030869, 8.753434833570179 ]
  },
  "id_str" : "838859182241624064",
  "in_reply_to_user_id" : 22200760,
  "text" : "@vexedmuddler @Julie_B92 aye, seems my temperature has decided to slowly go down to normal at least.",
  "id" : 838859182241624064,
  "in_reply_to_status_id" : 838858981275742208,
  "created_at" : "2017-03-06 21:09:48 +0000",
  "in_reply_to_screen_name" : "vexedmuddler",
  "in_reply_to_user_id_str" : "22200760",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11407178704579, 8.753468266914298 ]
  },
  "id_str" : "838858912061337602",
  "text" : "@kopshtik can we please do this over a coffee when I come to SEA? :D",
  "id" : 838858912061337602,
  "created_at" : "2017-03-06 21:08:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "A. Domingues",
      "screen_name" : "keyboardpipette",
      "indices" : [ 0, 16 ],
      "id_str" : "712172447223717888",
      "id" : 712172447223717888
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "838853910802595840",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11406792040412, 8.753434065130868 ]
  },
  "id_str" : "838854063357849601",
  "in_reply_to_user_id" : 712172447223717888,
  "text" : "@keyboardpipette sequence first, think later? :p",
  "id" : 838854063357849601,
  "in_reply_to_status_id" : 838853910802595840,
  "created_at" : "2017-03-06 20:49:28 +0000",
  "in_reply_to_screen_name" : "keyboardpipette",
  "in_reply_to_user_id_str" : "712172447223717888",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "A. Domingues",
      "screen_name" : "keyboardpipette",
      "indices" : [ 0, 16 ],
      "id_str" : "712172447223717888",
      "id" : 712172447223717888
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "838852895411998720",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11406792040412, 8.753434065130868 ]
  },
  "id_str" : "838853258424774656",
  "in_reply_to_user_id" : 712172447223717888,
  "text" : "@keyboardpipette the not so old problem: too much data, too little time.",
  "id" : 838853258424774656,
  "in_reply_to_status_id" : 838852895411998720,
  "created_at" : "2017-03-06 20:46:16 +0000",
  "in_reply_to_screen_name" : "keyboardpipette",
  "in_reply_to_user_id_str" : "712172447223717888",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "A. Domingues",
      "screen_name" : "keyboardpipette",
      "indices" : [ 0, 16 ],
      "id_str" : "712172447223717888",
      "id" : 712172447223717888
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "838851210836865025",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11406762423204, 8.753434490837625 ]
  },
  "id_str" : "838851380215414785",
  "in_reply_to_user_id" : 712172447223717888,
  "text" : "@keyboardpipette i can share my data if you want some to play around with :p",
  "id" : 838851380215414785,
  "in_reply_to_status_id" : 838851210836865025,
  "created_at" : "2017-03-06 20:38:48 +0000",
  "in_reply_to_screen_name" : "keyboardpipette",
  "in_reply_to_user_id_str" : "712172447223717888",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "A. Domingues",
      "screen_name" : "keyboardpipette",
      "indices" : [ 0, 16 ],
      "id_str" : "712172447223717888",
      "id" : 712172447223717888
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/C0pJ6Rz2Q2",
      "expanded_url" : "http:\/\/ruleofthirds.de\/visualize-geolocations\/",
      "display_url" : "ruleofthirds.de\/visualize-geol\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "838849407953043456",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11402168835188, 8.753288110414564 ]
  },
  "id_str" : "838850349951774720",
  "in_reply_to_user_id" : 712172447223717888,
  "text" : "@keyboardpipette nice, did a similar thing with Twitter geotags and Swarm, see https:\/\/t.co\/C0pJ6Rz2Q2 if that\u2019s your thing :)",
  "id" : 838850349951774720,
  "in_reply_to_status_id" : 838849407953043456,
  "created_at" : "2017-03-06 20:34:43 +0000",
  "in_reply_to_screen_name" : "keyboardpipette",
  "in_reply_to_user_id_str" : "712172447223717888",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Vexed Muddler",
      "screen_name" : "vexedmuddler",
      "indices" : [ 0, 13 ],
      "id_str" : "22200760",
      "id" : 22200760
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "838848307145367553",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11406807075971, 8.753435591313643 ]
  },
  "id_str" : "838848593670864896",
  "in_reply_to_user_id" : 22200760,
  "text" : "@vexedmuddler and thanks for making those! \uD83D\uDC96",
  "id" : 838848593670864896,
  "in_reply_to_status_id" : 838848307145367553,
  "created_at" : "2017-03-06 20:27:44 +0000",
  "in_reply_to_screen_name" : "vexedmuddler",
  "in_reply_to_user_id_str" : "22200760",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Vexed Muddler",
      "screen_name" : "vexedmuddler",
      "indices" : [ 0, 13 ],
      "id_str" : "22200760",
      "id" : 22200760
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "838848219790602242",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11406807075971, 8.753435591313643 ]
  },
  "id_str" : "838848515140894724",
  "in_reply_to_user_id" : 22200760,
  "text" : "@vexedmuddler oh no, get well soon. - sent from another person in the sick bed.",
  "id" : 838848515140894724,
  "in_reply_to_status_id" : 838848219790602242,
  "created_at" : "2017-03-06 20:27:25 +0000",
  "in_reply_to_screen_name" : "vexedmuddler",
  "in_reply_to_user_id_str" : "22200760",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Vexed Muddler",
      "screen_name" : "vexedmuddler",
      "indices" : [ 0, 13 ],
      "id_str" : "22200760",
      "id" : 22200760
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "838552174221230080",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1140685164333, 8.753434272707052 ]
  },
  "id_str" : "838847607699091460",
  "in_reply_to_user_id" : 22200760,
  "text" : "@vexedmuddler BTW: any news on those mitochondria? :D",
  "id" : 838847607699091460,
  "in_reply_to_status_id" : 838552174221230080,
  "created_at" : "2017-03-06 20:23:49 +0000",
  "in_reply_to_screen_name" : "vexedmuddler",
  "in_reply_to_user_id_str" : "22200760",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/Lpw33QXj1a",
      "expanded_url" : "https:\/\/twitter.com\/OBF_BOSC\/status\/838824572652695553",
      "display_url" : "twitter.com\/OBF_BOSC\/statu\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1140698325462, 8.753437786744247 ]
  },
  "id_str" : "838826634891440128",
  "text" : "Submit your Bioinformatics open source project and speak to one of the most fun crowds I know: https:\/\/t.co\/Lpw33QXj1a",
  "id" : 838826634891440128,
  "created_at" : "2017-03-06 19:00:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexander Junge",
      "screen_name" : "JungeAlexander",
      "indices" : [ 0, 15 ],
      "id_str" : "566549406",
      "id" : 566549406
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "838740896455741441",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11282906478743, 8.754355453385335 ]
  },
  "id_str" : "838747177958666241",
  "in_reply_to_user_id" : 566549406,
  "text" : "@JungeAlexander wasn\u2019t this only released after someone pointed that out? Which would make it a pretty post-hoc explanation? ;)",
  "id" : 838747177958666241,
  "in_reply_to_status_id" : 838740896455741441,
  "created_at" : "2017-03-06 13:44:45 +0000",
  "in_reply_to_screen_name" : "JungeAlexander",
  "in_reply_to_user_id_str" : "566549406",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 0, 8 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    }, {
      "name" : "Robert Davey",
      "screen_name" : "froggleston",
      "indices" : [ 9, 21 ],
      "id_str" : "53893339",
      "id" : 53893339
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "838720874819760128",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11407553102122, 8.753441014705489 ]
  },
  "id_str" : "838721072350564352",
  "in_reply_to_user_id" : 3865005196,
  "text" : "@o_guest @froggleston no worries, as said, I\u2019m fine with getting a copy elsewhere. :)",
  "id" : 838721072350564352,
  "in_reply_to_status_id" : 838720874819760128,
  "created_at" : "2017-03-06 12:01:00 +0000",
  "in_reply_to_screen_name" : "o_guest",
  "in_reply_to_user_id_str" : "3865005196",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u03B8ourkni\u02D0r\u0325",
      "screen_name" : "thorgnyr",
      "indices" : [ 0, 9 ],
      "id_str" : "38015980",
      "id" : 38015980
    }, {
      "name" : "Robert",
      "screen_name" : "kventil",
      "indices" : [ 10, 18 ],
      "id_str" : "7431192",
      "id" : 7431192
    }, {
      "name" : "Philip Brechler",
      "screen_name" : "gutsle",
      "indices" : [ 19, 26 ],
      "id_str" : "837535866",
      "id" : 837535866
    }, {
      "name" : "Malin Sandstr\u00F6m",
      "screen_name" : "msandstr",
      "indices" : [ 27, 36 ],
      "id_str" : "23945759",
      "id" : 23945759
    }, {
      "name" : "Roman Lu\u0161trik",
      "screen_name" : "romunov",
      "indices" : [ 37, 45 ],
      "id_str" : "158756964",
      "id" : 158756964
    }, {
      "name" : "Robert Davey",
      "screen_name" : "froggleston",
      "indices" : [ 46, 58 ],
      "id_str" : "53893339",
      "id" : 53893339
    }, {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 59, 67 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "838694499475992576",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11407542935369, 8.75344108838615 ]
  },
  "id_str" : "838720450561736705",
  "in_reply_to_user_id" : 38015980,
  "text" : "@thorgnyr @kventil @gutsle @msandstr @romunov @froggleston @o_guest thanks! you guys are the best!",
  "id" : 838720450561736705,
  "in_reply_to_status_id" : 838694499475992576,
  "created_at" : "2017-03-06 11:58:32 +0000",
  "in_reply_to_screen_name" : "thorgnyr",
  "in_reply_to_user_id_str" : "38015980",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lorraine Chuen",
      "screen_name" : "lorrainechu3n",
      "indices" : [ 3, 17 ],
      "id_str" : "257319757",
      "id" : 257319757
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "838710896746708992",
  "text" : "RT @lorrainechu3n: it's super voyeuristic and white gaze-y; their lives are not for your viewing pleasure or to brag about on social media,\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "838654543516815360",
    "geo" : { },
    "id_str" : "838654821716623361",
    "in_reply_to_user_id" : 257319757,
    "text" : "it's super voyeuristic and white gaze-y; their lives are not for your viewing pleasure or to brag about on social media, please stop.",
    "id" : 838654821716623361,
    "in_reply_to_status_id" : 838654543516815360,
    "created_at" : "2017-03-06 07:37:45 +0000",
    "in_reply_to_screen_name" : "lorrainechu3n",
    "in_reply_to_user_id_str" : "257319757",
    "user" : {
      "name" : "Lorraine Chuen",
      "screen_name" : "lorrainechu3n",
      "protected" : false,
      "id_str" : "257319757",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/926996461719621632\/aBq5xtJy_normal.jpg",
      "id" : 257319757,
      "verified" : false
    }
  },
  "id" : 838710896746708992,
  "created_at" : "2017-03-06 11:20:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lorraine Chuen",
      "screen_name" : "lorrainechu3n",
      "indices" : [ 3, 17 ],
      "id_str" : "257319757",
      "id" : 257319757
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "838710887959642112",
  "text" : "RT @lorrainechu3n: Uhhhhhhh can the white \"friends\" i have on snapchat who are travelling in foreign countries please stop taking secret vi\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "838654543516815360",
    "text" : "Uhhhhhhh can the white \"friends\" i have on snapchat who are travelling in foreign countries please stop taking secret videos of locals?",
    "id" : 838654543516815360,
    "created_at" : "2017-03-06 07:36:39 +0000",
    "user" : {
      "name" : "Lorraine Chuen",
      "screen_name" : "lorrainechu3n",
      "protected" : false,
      "id_str" : "257319757",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/926996461719621632\/aBq5xtJy_normal.jpg",
      "id" : 257319757,
      "verified" : false
    }
  },
  "id" : 838710887959642112,
  "created_at" : "2017-03-06 11:20:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11406853502711, 8.753433392760193 ]
  },
  "id_str" : "838694048240128000",
  "text" : "For someone who\u2019s been out of the TV series game for a while: what to watch on Netflix (or TPB) between fever dreams?",
  "id" : 838694048240128000,
  "created_at" : "2017-03-06 10:13:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "838589883560017922",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11406853502711, 8.753433392760193 ]
  },
  "id_str" : "838693387364614145",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer wait, you managed to get it to run at all? Never worked for me. :D",
  "id" : 838693387364614145,
  "in_reply_to_status_id" : 838589883560017922,
  "created_at" : "2017-03-06 10:11:00 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BMH-British Medieval",
      "screen_name" : "BritishMedieval",
      "indices" : [ 3, 19 ],
      "id_str" : "730830826301210625",
      "id" : 730830826301210625
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/BritishMedieval\/status\/837832774518255616\/photo\/1",
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/ykiwUSVYf0",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/C6CUcycWgAAU3Hg.jpg",
      "id_str" : "837832752988848128",
      "id" : 837832752988848128,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C6CUcycWgAAU3Hg.jpg",
      "sizes" : [ {
        "h" : 478,
        "resize" : "fit",
        "w" : 576
      }, {
        "h" : 478,
        "resize" : "fit",
        "w" : 576
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 478,
        "resize" : "fit",
        "w" : 576
      }, {
        "h" : 478,
        "resize" : "fit",
        "w" : 576
      } ],
      "display_url" : "pic.twitter.com\/ykiwUSVYf0"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "838462530204876804",
  "text" : "RT @BritishMedieval: Nice to see Leicester City Council finally taking appropriate action..... https:\/\/t.co\/ykiwUSVYf0",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/BritishMedieval\/status\/837832774518255616\/photo\/1",
        "indices" : [ 74, 97 ],
        "url" : "https:\/\/t.co\/ykiwUSVYf0",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/C6CUcycWgAAU3Hg.jpg",
        "id_str" : "837832752988848128",
        "id" : 837832752988848128,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C6CUcycWgAAU3Hg.jpg",
        "sizes" : [ {
          "h" : 478,
          "resize" : "fit",
          "w" : 576
        }, {
          "h" : 478,
          "resize" : "fit",
          "w" : 576
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 478,
          "resize" : "fit",
          "w" : 576
        }, {
          "h" : 478,
          "resize" : "fit",
          "w" : 576
        } ],
        "display_url" : "pic.twitter.com\/ykiwUSVYf0"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "837832774518255616",
    "text" : "Nice to see Leicester City Council finally taking appropriate action..... https:\/\/t.co\/ykiwUSVYf0",
    "id" : 837832774518255616,
    "created_at" : "2017-03-04 01:11:14 +0000",
    "user" : {
      "name" : "BMH-British Medieval",
      "screen_name" : "BritishMedieval",
      "protected" : false,
      "id_str" : "730830826301210625",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/731153015177150464\/VPEAjK2i_normal.jpg",
      "id" : 730830826301210625,
      "verified" : false
    }
  },
  "id" : 838462530204876804,
  "created_at" : "2017-03-05 18:53:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sci Curious",
      "screen_name" : "scicurious",
      "indices" : [ 3, 14 ],
      "id_str" : "31443503",
      "id" : 31443503
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 57 ],
      "url" : "https:\/\/t.co\/2g9MDpX2VB",
      "expanded_url" : "https:\/\/twitter.com\/DNLee5\/status\/838431355511967747",
      "display_url" : "twitter.com\/DNLee5\/status\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "838451615900258305",
  "text" : "RT @scicurious: Important thread. https:\/\/t.co\/2g9MDpX2VB",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 18, 41 ],
        "url" : "https:\/\/t.co\/2g9MDpX2VB",
        "expanded_url" : "https:\/\/twitter.com\/DNLee5\/status\/838431355511967747",
        "display_url" : "twitter.com\/DNLee5\/status\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "838451070741458944",
    "text" : "Important thread. https:\/\/t.co\/2g9MDpX2VB",
    "id" : 838451070741458944,
    "created_at" : "2017-03-05 18:08:07 +0000",
    "user" : {
      "name" : "Sci Curious",
      "screen_name" : "scicurious",
      "protected" : false,
      "id_str" : "31443503",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/905120517052620800\/uq2q-fjc_normal.jpg",
      "id" : 31443503,
      "verified" : true
    }
  },
  "id" : 838451615900258305,
  "created_at" : "2017-03-05 18:10:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Brechler",
      "screen_name" : "gutsle",
      "indices" : [ 0, 7 ],
      "id_str" : "837535866",
      "id" : 837535866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "838124251144155136",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11406784090531, 8.753434017555811 ]
  },
  "id_str" : "838150845481041925",
  "in_reply_to_user_id" : 837535866,
  "text" : "@gutsle Danke. Und zum Gl\u00FCck ja :)",
  "id" : 838150845481041925,
  "in_reply_to_status_id" : 838124251144155136,
  "created_at" : "2017-03-04 22:15:08 +0000",
  "in_reply_to_screen_name" : "gutsle",
  "in_reply_to_user_id_str" : "837535866",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Egle Ramanauskaite \u2623",
      "screen_name" : "Seplute",
      "indices" : [ 0, 8 ],
      "id_str" : "188833865",
      "id" : 188833865
    }, {
      "name" : "Michael R. Crusoe",
      "screen_name" : "biocrusoe",
      "indices" : [ 9, 19 ],
      "id_str" : "17645638",
      "id" : 17645638
    }, {
      "name" : "Technarium",
      "screen_name" : "technarium",
      "indices" : [ 20, 31 ],
      "id_str" : "2936916419",
      "id" : 2936916419
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "838077017790763012",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1140683437674, 8.75343374370993 ]
  },
  "id_str" : "838110295562285056",
  "in_reply_to_user_id" : 188833865,
  "text" : "@Seplute @biocrusoe @technarium \uD83D\uDE0D",
  "id" : 838110295562285056,
  "in_reply_to_status_id" : 838077017790763012,
  "created_at" : "2017-03-04 19:34:00 +0000",
  "in_reply_to_screen_name" : "Seplute",
  "in_reply_to_user_id_str" : "188833865",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "838003613670735872",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1140683437674, 8.75343374370993 ]
  },
  "id_str" : "838110044621312003",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC thanks!",
  "id" : 838110044621312003,
  "in_reply_to_status_id" : 838003613670735872,
  "created_at" : "2017-03-04 19:33:00 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Achintya Rao \u2022 \u0C85\u0C9A\u0CBF\u0C82\u0CA4\u0CCD\u0CAF \u0CB0\u0CBE\u0CB5",
      "screen_name" : "RaoOfPhysics",
      "indices" : [ 0, 13 ],
      "id_str" : "67529128",
      "id" : 67529128
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "838014435864227841",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1140683437674, 8.75343374370993 ]
  },
  "id_str" : "838110017492561920",
  "in_reply_to_user_id" : 67529128,
  "text" : "@RaoOfPhysics thanks!",
  "id" : 838110017492561920,
  "in_reply_to_status_id" : 838014435864227841,
  "created_at" : "2017-03-04 19:32:54 +0000",
  "in_reply_to_screen_name" : "RaoOfPhysics",
  "in_reply_to_user_id_str" : "67529128",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 0, 10 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "838009855235485696",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1140683437674, 8.75343374370993 ]
  },
  "id_str" : "838109996344885249",
  "in_reply_to_user_id" : 1385861262,
  "text" : "@Julie_B92 yes, super kind of it.",
  "id" : 838109996344885249,
  "in_reply_to_status_id" : 838009855235485696,
  "created_at" : "2017-03-04 19:32:49 +0000",
  "in_reply_to_screen_name" : "Julie_B92",
  "in_reply_to_user_id_str" : "1385861262",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thyone",
      "screen_name" : "__thyone__",
      "indices" : [ 0, 11 ],
      "id_str" : "929263903",
      "id" : 929263903
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "838022721334296577",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1140683437674, 8.75343374370993 ]
  },
  "id_str" : "838109930309758977",
  "in_reply_to_user_id" : 929263903,
  "text" : "@__thyone__ Danke!",
  "id" : 838109930309758977,
  "in_reply_to_status_id" : 838022721334296577,
  "created_at" : "2017-03-04 19:32:33 +0000",
  "in_reply_to_screen_name" : "__thyone__",
  "in_reply_to_user_id_str" : "929263903",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nyborg",
      "screen_name" : "ny_borg",
      "indices" : [ 0, 8 ],
      "id_str" : "570156398",
      "id" : 570156398
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "838100387722891269",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1140683437674, 8.75343374370993 ]
  },
  "id_str" : "838109897606774786",
  "in_reply_to_user_id" : 570156398,
  "text" : "@ny_borg Danke!",
  "id" : 838109897606774786,
  "in_reply_to_status_id" : 838100387722891269,
  "created_at" : "2017-03-04 19:32:25 +0000",
  "in_reply_to_screen_name" : "ny_borg",
  "in_reply_to_user_id_str" : "570156398",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11397265004666, 8.75345325765977 ]
  },
  "id_str" : "838002863645261824",
  "text" : "Great, the 39\u00B0C fever did wait for late Friday evening to break out. \uD83E\uDD12",
  "id" : 838002863645261824,
  "created_at" : "2017-03-04 12:27:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Head",
      "screen_name" : "betatim",
      "indices" : [ 0, 8 ],
      "id_str" : "18881614",
      "id" : 18881614
    }, {
      "name" : "Mozilla Open Leaders",
      "screen_name" : "MozOpenLeaders",
      "indices" : [ 9, 24 ],
      "id_str" : "791070237949034496",
      "id" : 791070237949034496
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "837719805713084416",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11407749834796, 8.753417965085701 ]
  },
  "id_str" : "837719929721876484",
  "in_reply_to_user_id" : 18881614,
  "text" : "@betatim @MozOpenLeaders \uD83D\uDE0D",
  "id" : 837719929721876484,
  "in_reply_to_status_id" : 837719805713084416,
  "created_at" : "2017-03-03 17:42:49 +0000",
  "in_reply_to_screen_name" : "betatim",
  "in_reply_to_user_id_str" : "18881614",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Head",
      "screen_name" : "betatim",
      "indices" : [ 0, 8 ],
      "id_str" : "18881614",
      "id" : 18881614
    }, {
      "name" : "Mozilla Open Leaders",
      "screen_name" : "MozOpenLeaders",
      "indices" : [ 9, 24 ],
      "id_str" : "791070237949034496",
      "id" : 791070237949034496
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "837680417562054656",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11390470951356, 8.753662904805521 ]
  },
  "id_str" : "837705576163454976",
  "in_reply_to_user_id" : 18881614,
  "text" : "@betatim @MozOpenLeaders yikes, so we\u2019ll need to keep each other warm? :P",
  "id" : 837705576163454976,
  "in_reply_to_status_id" : 837680417562054656,
  "created_at" : "2017-03-03 16:45:47 +0000",
  "in_reply_to_screen_name" : "betatim",
  "in_reply_to_user_id_str" : "18881614",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Madeleine Price Ball",
      "screen_name" : "madprime",
      "indices" : [ 0, 9 ],
      "id_str" : "71557700",
      "id" : 71557700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "837700421829472258",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11406847843853, 8.75343401594358 ]
  },
  "id_str" : "837702177351155714",
  "in_reply_to_user_id" : 71557700,
  "text" : "@madprime absolutely! And from my experience that\u2019s what the assembly all about after all :)",
  "id" : 837702177351155714,
  "in_reply_to_status_id" : 837700421829472258,
  "created_at" : "2017-03-03 16:32:17 +0000",
  "in_reply_to_screen_name" : "madprime",
  "in_reply_to_user_id_str" : "71557700",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Madeleine Price Ball",
      "screen_name" : "madprime",
      "indices" : [ 0, 9 ],
      "id_str" : "71557700",
      "id" : 71557700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "837662114802241536",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11413875215696, 8.753368342741343 ]
  },
  "id_str" : "837700015552360449",
  "in_reply_to_user_id" : 71557700,
  "text" : "@madprime awesome, looking forward to meet again!",
  "id" : 837700015552360449,
  "in_reply_to_status_id" : 837662114802241536,
  "created_at" : "2017-03-03 16:23:42 +0000",
  "in_reply_to_screen_name" : "madprime",
  "in_reply_to_user_id_str" : "71557700",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "andrea thomer",
      "screen_name" : "an_dre_a_",
      "indices" : [ 0, 10 ],
      "id_str" : "15465094",
      "id" : 15465094
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "837699034018086914",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11408725292432, 8.753450810917423 ]
  },
  "id_str" : "837699283143049221",
  "in_reply_to_user_id" : 15465094,
  "text" : "@an_dre_a_ can it suggest a new field I should found? :D",
  "id" : 837699283143049221,
  "in_reply_to_status_id" : 837699034018086914,
  "created_at" : "2017-03-03 16:20:47 +0000",
  "in_reply_to_screen_name" : "an_dre_a_",
  "in_reply_to_user_id_str" : "15465094",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 77 ],
      "url" : "https:\/\/t.co\/wqsoyQFalS",
      "expanded_url" : "https:\/\/twitter.com\/BioMickWatson\/status\/837591358793732096",
      "display_url" : "twitter.com\/BioMickWatson\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11387908835906, 8.75158273615758 ]
  },
  "id_str" : "837698026890231810",
  "text" : "Soon we\u2019ll have the field of academic niche modeling. https:\/\/t.co\/wqsoyQFalS",
  "id" : 837698026890231810,
  "created_at" : "2017-03-03 16:15:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Schawinski",
      "screen_name" : "kevinschawinski",
      "indices" : [ 0, 16 ],
      "id_str" : "242844365",
      "id" : 242844365
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "837571161282215936",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17231274668291, 8.627569834860024 ]
  },
  "id_str" : "837643550812667906",
  "in_reply_to_user_id" : 242844365,
  "text" : "@kevinschawinski cool, where did the two of you meet!?",
  "id" : 837643550812667906,
  "in_reply_to_status_id" : 837571161282215936,
  "created_at" : "2017-03-03 12:39:19 +0000",
  "in_reply_to_screen_name" : "kevinschawinski",
  "in_reply_to_user_id_str" : "242844365",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rae Knowler",
      "screen_name" : "RaeKnowler",
      "indices" : [ 0, 11 ],
      "id_str" : "1244114060",
      "id" : 1244114060
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "837636507900989440",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17236244248961, 8.62752456085707 ]
  },
  "id_str" : "837636637467242496",
  "in_reply_to_user_id" : 1244114060,
  "text" : "@RaeKnowler yes, let\u2019s see what she\u2019ll suggest \uD83D\uDE0D",
  "id" : 837636637467242496,
  "in_reply_to_status_id" : 837636507900989440,
  "created_at" : "2017-03-03 12:11:51 +0000",
  "in_reply_to_screen_name" : "RaeKnowler",
  "in_reply_to_user_id_str" : "1244114060",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rae Knowler",
      "screen_name" : "RaeKnowler",
      "indices" : [ 0, 11 ],
      "id_str" : "1244114060",
      "id" : 1244114060
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "836874095052615680",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17236244248961, 8.62752456085707 ]
  },
  "id_str" : "837636149095108609",
  "in_reply_to_user_id" : 1244114060,
  "text" : "@RaeKnowler worked out, got a date for end of this month! :)",
  "id" : 837636149095108609,
  "in_reply_to_status_id" : 836874095052615680,
  "created_at" : "2017-03-03 12:09:55 +0000",
  "in_reply_to_screen_name" : "RaeKnowler",
  "in_reply_to_user_id_str" : "1244114060",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 142 ],
      "url" : "https:\/\/t.co\/bYUTDazIFU",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/837604180101476352",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "837604180101476352",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17234651743555, 8.627547293691515 ]
  },
  "id_str" : "837604985546342400",
  "in_reply_to_user_id" : 14286491,
  "text" : "This is basically suggesting this workflow: do underpowered study, find impressive false positive result, run to PNAS. https:\/\/t.co\/bYUTDazIFU",
  "id" : 837604985546342400,
  "in_reply_to_status_id" : 837604180101476352,
  "created_at" : "2017-03-03 10:06:05 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/i8Wmn8xGKT",
      "expanded_url" : "http:\/\/journals.plos.org\/plosbiology\/article?id=10.1371\/journal.pbio.2000797",
      "display_url" : "journals.plos.org\/plosbiology\/ar\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17236676037654, 8.627497615723012 ]
  },
  "id_str" : "837604180101476352",
  "text" : "\u00ABthe higher the impact factors of journals in which the studies were published, the lower was the statistical power\u00BB https:\/\/t.co\/i8Wmn8xGKT",
  "id" : 837604180101476352,
  "created_at" : "2017-03-03 10:02:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bi\u24D0nca Kramer",
      "screen_name" : "MsPhelps",
      "indices" : [ 0, 9 ],
      "id_str" : "22963112",
      "id" : 22963112
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "837598644245254144",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17235856882646, 8.627507363727876 ]
  },
  "id_str" : "837601255941898240",
  "in_reply_to_user_id" : 22963112,
  "text" : "@MsPhelps maybe the point \u201Edesertation\u201C gave the person doing it some idea? :p",
  "id" : 837601255941898240,
  "in_reply_to_status_id" : 837598644245254144,
  "created_at" : "2017-03-03 09:51:15 +0000",
  "in_reply_to_screen_name" : "MsPhelps",
  "in_reply_to_user_id_str" : "22963112",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mick Watson",
      "screen_name" : "BioMickWatson",
      "indices" : [ 0, 14 ],
      "id_str" : "228586748",
      "id" : 228586748
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "837592496658087936",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17236977237859, 8.627501262004428 ]
  },
  "id_str" : "837593631498317824",
  "in_reply_to_user_id" : 228586748,
  "text" : "@BioMickWatson I think it\u2019s called IDGAF.",
  "id" : 837593631498317824,
  "in_reply_to_status_id" : 837592496658087936,
  "created_at" : "2017-03-03 09:20:58 +0000",
  "in_reply_to_screen_name" : "BioMickWatson",
  "in_reply_to_user_id_str" : "228586748",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "837455288538103809",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11407950967869, 8.753415651964985 ]
  },
  "id_str" : "837457217263710209",
  "in_reply_to_user_id" : 14286491,
  "text" : "\u00ABOpen the cock bay doors, HAL.\u00BB \u2013 \u00ABI\u2019m sorry, Dave. I\u2019m afraid that\u2019ll cost 2 BTC.\u00BB",
  "id" : 837457217263710209,
  "in_reply_to_status_id" : 837455288538103809,
  "created_at" : "2017-03-03 00:18:54 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/doDEDsFnlF",
      "expanded_url" : "https:\/\/twitter.com\/quinnnorton\/status\/837454101990387712",
      "display_url" : "twitter.com\/quinnnorton\/st\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11407947438538, 8.753415396906275 ]
  },
  "id_str" : "837455288538103809",
  "text" : "Having a \uD83C\uDF46? Good news, soon it can finally be the victim of ransomware. https:\/\/t.co\/doDEDsFnlF",
  "id" : 837455288538103809,
  "created_at" : "2017-03-03 00:11:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David M. Perry",
      "screen_name" : "Lollardfish",
      "indices" : [ 3, 15 ],
      "id_str" : "108094234",
      "id" : 108094234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "837435958551277570",
  "text" : "RT @Lollardfish: Nice: Her and I were just existing. The freedom to simply be yourself in a sea of people who aren\u2019t like you is a freedom\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 138, 161 ],
        "url" : "https:\/\/t.co\/P0FWWKa3JK",
        "expanded_url" : "https:\/\/twitter.com\/ellefs0n\/status\/837408823904202753",
        "display_url" : "twitter.com\/ellefs0n\/statu\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "837431681074270208",
    "text" : "Nice: Her and I were just existing. The freedom to simply be yourself in a sea of people who aren\u2019t like you is a freedom we all deserve. https:\/\/t.co\/P0FWWKa3JK",
    "id" : 837431681074270208,
    "created_at" : "2017-03-02 22:37:26 +0000",
    "user" : {
      "name" : "David M. Perry",
      "screen_name" : "Lollardfish",
      "protected" : false,
      "id_str" : "108094234",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3342950681\/782b24838dc7f5c22e405997772590e2_normal.png",
      "id" : 108094234,
      "verified" : true
    }
  },
  "id" : 837435958551277570,
  "created_at" : "2017-03-02 22:54:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 77 ],
      "url" : "https:\/\/t.co\/nVBZhQkNl6",
      "expanded_url" : "https:\/\/twitter.com\/JBYoder\/status\/837394344520761344",
      "display_url" : "twitter.com\/JBYoder\/status\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11407860396297, 8.753415639716312 ]
  },
  "id_str" : "837395981733924864",
  "text" : "Worse: We\u2019re seriously losing compared to economics?! https:\/\/t.co\/nVBZhQkNl6",
  "id" : 837395981733924864,
  "created_at" : "2017-03-02 20:15:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 0, 10 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    }, {
      "name" : "Sujai Kumar",
      "screen_name" : "sujaik",
      "indices" : [ 11, 18 ],
      "id_str" : "33651124",
      "id" : 33651124
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "837384992309276672",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11397767715297, 8.753586571861542 ]
  },
  "id_str" : "837385320761069571",
  "in_reply_to_user_id" : 1385861262,
  "text" : "@Julie_B92 @sujaik \uD83D\uDC4D just to hint that heterozygosity will increase assembly size, which doesn\u2019t reflect genome size increase :)",
  "id" : 837385320761069571,
  "in_reply_to_status_id" : 837384992309276672,
  "created_at" : "2017-03-02 19:33:12 +0000",
  "in_reply_to_screen_name" : "Julie_B92",
  "in_reply_to_user_id_str" : "1385861262",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 0, 10 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    }, {
      "name" : "Sujai Kumar",
      "screen_name" : "sujaik",
      "indices" : [ 11, 18 ],
      "id_str" : "33651124",
      "id" : 33651124
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "837384584350351364",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11397767715297, 8.753586571861542 ]
  },
  "id_str" : "837384913003347968",
  "in_reply_to_user_id" : 1385861262,
  "text" : "@Julie_B92 @sujaik depends on how the genome size is measured initially. :)",
  "id" : 837384913003347968,
  "in_reply_to_status_id" : 837384584350351364,
  "created_at" : "2017-03-02 19:31:35 +0000",
  "in_reply_to_screen_name" : "Julie_B92",
  "in_reply_to_user_id_str" : "1385861262",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 0, 10 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    }, {
      "name" : "Sujai Kumar",
      "screen_name" : "sujaik",
      "indices" : [ 11, 18 ],
      "id_str" : "33651124",
      "id" : 33651124
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "837383390189993984",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11397767715297, 8.753586571861542 ]
  },
  "id_str" : "837384304003002368",
  "in_reply_to_user_id" : 1385861262,
  "text" : "@Julie_B92 @sujaik the larger the assembly the larger the heterozygosity? ;)",
  "id" : 837384304003002368,
  "in_reply_to_status_id" : 837383390189993984,
  "created_at" : "2017-03-02 19:29:10 +0000",
  "in_reply_to_screen_name" : "Julie_B92",
  "in_reply_to_user_id_str" : "1385861262",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 0, 10 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    }, {
      "name" : "Sujai Kumar",
      "screen_name" : "sujaik",
      "indices" : [ 11, 18 ],
      "id_str" : "33651124",
      "id" : 33651124
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "837382800768655360",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11390144326617, 8.753674220067673 ]
  },
  "id_str" : "837383047699902465",
  "in_reply_to_user_id" : 1385861262,
  "text" : "@Julie_B92 @sujaik homozygous sites: reads from both alleles map. Heterozygous sites: only reads from one allele map -&gt; half of expected cov",
  "id" : 837383047699902465,
  "in_reply_to_status_id" : 837382800768655360,
  "created_at" : "2017-03-02 19:24:11 +0000",
  "in_reply_to_screen_name" : "Julie_B92",
  "in_reply_to_user_id_str" : "1385861262",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 0, 10 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    }, {
      "name" : "Sujai Kumar",
      "screen_name" : "sujaik",
      "indices" : [ 11, 18 ],
      "id_str" : "33651124",
      "id" : 33651124
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "837381300919144448",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11390144326617, 8.753674220067673 ]
  },
  "id_str" : "837382567322136576",
  "in_reply_to_user_id" : 1385861262,
  "text" : "@Julie_B92 @sujaik how are you thinking about it? :)",
  "id" : 837382567322136576,
  "in_reply_to_status_id" : 837381300919144448,
  "created_at" : "2017-03-02 19:22:16 +0000",
  "in_reply_to_screen_name" : "Julie_B92",
  "in_reply_to_user_id_str" : "1385861262",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sujai Kumar",
      "screen_name" : "sujaik",
      "indices" : [ 0, 7 ],
      "id_str" : "33651124",
      "id" : 33651124
    }, {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 8, 18 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "837380182713458688",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11407658387773, 8.753410861522163 ]
  },
  "id_str" : "837380287789150211",
  "in_reply_to_user_id" : 33651124,
  "text" : "@sujaik @Julie_B92 thanks for making me see!",
  "id" : 837380287789150211,
  "in_reply_to_status_id" : 837380182713458688,
  "created_at" : "2017-03-02 19:13:13 +0000",
  "in_reply_to_screen_name" : "sujaik",
  "in_reply_to_user_id_str" : "33651124",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sujai Kumar",
      "screen_name" : "sujaik",
      "indices" : [ 0, 7 ],
      "id_str" : "33651124",
      "id" : 33651124
    }, {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 8, 18 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "837379815560863745",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11407658387773, 8.753410861522163 ]
  },
  "id_str" : "837380087666339841",
  "in_reply_to_user_id" : 33651124,
  "text" : "@sujaik @Julie_B92 gotcha, so bulk is homozygous and smaller heterozygous peak?",
  "id" : 837380087666339841,
  "in_reply_to_status_id" : 837379815560863745,
  "created_at" : "2017-03-02 19:12:25 +0000",
  "in_reply_to_screen_name" : "sujaik",
  "in_reply_to_user_id_str" : "33651124",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 0, 10 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    }, {
      "name" : "Sujai Kumar",
      "screen_name" : "sujaik",
      "indices" : [ 11, 18 ],
      "id_str" : "33651124",
      "id" : 33651124
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "837378231569383428",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11407649915278, 8.753412489813785 ]
  },
  "id_str" : "837378686026416128",
  "in_reply_to_user_id" : 1385861262,
  "text" : "@Julie_B92 @sujaik isn\u2019t the lower one proteo-bacteria?",
  "id" : 837378686026416128,
  "in_reply_to_status_id" : 837378231569383428,
  "created_at" : "2017-03-02 19:06:51 +0000",
  "in_reply_to_screen_name" : "Julie_B92",
  "in_reply_to_user_id_str" : "1385861262",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 0, 10 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    }, {
      "name" : "Sujai Kumar",
      "screen_name" : "sujaik",
      "indices" : [ 11, 18 ],
      "id_str" : "33651124",
      "id" : 33651124
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "837357789521526784",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11417488572198, 8.753541251652644 ]
  },
  "id_str" : "837377905000857601",
  "in_reply_to_user_id" : 1385861262,
  "text" : "@Julie_B92 @sujaik I still don\u2019t see it. Must be the same reason! \uD83D\uDE31",
  "id" : 837377905000857601,
  "in_reply_to_status_id" : 837357789521526784,
  "created_at" : "2017-03-02 19:03:44 +0000",
  "in_reply_to_screen_name" : "Julie_B92",
  "in_reply_to_user_id_str" : "1385861262",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rachel Harriman",
      "screen_name" : "rachel_harry8",
      "indices" : [ 3, 17 ],
      "id_str" : "520576741",
      "id" : 520576741
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/rachel_harry8\/status\/833878909947170816\/photo\/1",
      "indices" : [ 62, 85 ],
      "url" : "https:\/\/t.co\/7GOXFFI7U6",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/C5KIcgOXUAESByX.jpg",
      "id_str" : "833878904284860417",
      "id" : 833878904284860417,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C5KIcgOXUAESByX.jpg",
      "sizes" : [ {
        "h" : 1334,
        "resize" : "fit",
        "w" : 750
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 675
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1334,
        "resize" : "fit",
        "w" : 750
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 382
      } ],
      "display_url" : "pic.twitter.com\/7GOXFFI7U6"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "837372835668557824",
  "text" : "RT @rachel_harry8: \"how are classes going\" \"how is your life\" https:\/\/t.co\/7GOXFFI7U6",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/rachel_harry8\/status\/833878909947170816\/photo\/1",
        "indices" : [ 43, 66 ],
        "url" : "https:\/\/t.co\/7GOXFFI7U6",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/C5KIcgOXUAESByX.jpg",
        "id_str" : "833878904284860417",
        "id" : 833878904284860417,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C5KIcgOXUAESByX.jpg",
        "sizes" : [ {
          "h" : 1334,
          "resize" : "fit",
          "w" : 750
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 675
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1334,
          "resize" : "fit",
          "w" : 750
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 382
        } ],
        "display_url" : "pic.twitter.com\/7GOXFFI7U6"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "833878909947170816",
    "text" : "\"how are classes going\" \"how is your life\" https:\/\/t.co\/7GOXFFI7U6",
    "id" : 833878909947170816,
    "created_at" : "2017-02-21 03:19:59 +0000",
    "user" : {
      "name" : "Rachel Harriman",
      "screen_name" : "rachel_harry8",
      "protected" : false,
      "id_str" : "520576741",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/852020359117197314\/C5GuqM4g_normal.jpg",
      "id" : 520576741,
      "verified" : false
    }
  },
  "id" : 837372835668557824,
  "created_at" : "2017-03-02 18:43:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uD83D\uDC9A Aure Moser \uD83D\uDC9A",
      "screen_name" : "auremoser",
      "indices" : [ 3, 13 ],
      "id_str" : "186529934",
      "id" : 186529934
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mozfest",
      "indices" : [ 44, 52 ]
    } ],
    "urls" : [ {
      "indices" : [ 120, 143 ],
      "url" : "https:\/\/t.co\/GI8kxCyuIw",
      "expanded_url" : "https:\/\/mozillafestival.org\/",
      "display_url" : "mozillafestival.org"
    } ]
  },
  "geo" : { },
  "id_str" : "837323684280926208",
  "text" : "RT @auremoser: Save the dates announced for #mozfest, Oct 27-29th, London, UK, join me for my b-day just after! &lt;3 : https:\/\/t.co\/GI8kxCyuIw",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "mozfest",
        "indices" : [ 29, 37 ]
      } ],
      "urls" : [ {
        "indices" : [ 105, 128 ],
        "url" : "https:\/\/t.co\/GI8kxCyuIw",
        "expanded_url" : "https:\/\/mozillafestival.org\/",
        "display_url" : "mozillafestival.org"
      } ]
    },
    "geo" : { },
    "id_str" : "837314632301887490",
    "text" : "Save the dates announced for #mozfest, Oct 27-29th, London, UK, join me for my b-day just after! &lt;3 : https:\/\/t.co\/GI8kxCyuIw",
    "id" : 837314632301887490,
    "created_at" : "2017-03-02 14:52:19 +0000",
    "user" : {
      "name" : "\uD83D\uDC9A Aure Moser \uD83D\uDC9A",
      "screen_name" : "auremoser",
      "protected" : false,
      "id_str" : "186529934",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/723868643688325122\/AHwUDHy3_normal.jpg",
      "id" : 186529934,
      "verified" : false
    }
  },
  "id" : 837323684280926208,
  "created_at" : "2017-03-02 15:28:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Torsten Seemann",
      "screen_name" : "torstenseemann",
      "indices" : [ 0, 15 ],
      "id_str" : "42558652",
      "id" : 42558652
    }, {
      "name" : "Nick Loman",
      "screen_name" : "pathogenomenick",
      "indices" : [ 16, 32 ],
      "id_str" : "85906238",
      "id" : 85906238
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "837265319349497856",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17235753460092, 8.627530545284785 ]
  },
  "id_str" : "837292828720054272",
  "in_reply_to_user_id" : 42558652,
  "text" : "@torstenseemann @pathogenomenick before seeing the picture I thought it would be \u201EWanna see how small the Minion is? \uD83D\uDD95That small!\u201C \uD83D\uDE02",
  "id" : 837292828720054272,
  "in_reply_to_status_id" : 837265319349497856,
  "created_at" : "2017-03-02 13:25:41 +0000",
  "in_reply_to_screen_name" : "torstenseemann",
  "in_reply_to_user_id_str" : "42558652",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Achintya Rao \u2022 \u0C85\u0C9A\u0CBF\u0C82\u0CA4\u0CCD\u0CAF \u0CB0\u0CBE\u0CB5",
      "screen_name" : "RaoOfPhysics",
      "indices" : [ 0, 13 ],
      "id_str" : "67529128",
      "id" : 67529128
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "837222535511048192",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17233598359806, 8.62757419544533 ]
  },
  "id_str" : "837236556037517314",
  "in_reply_to_user_id" : 67529128,
  "text" : "@RaoOfPhysics \uD83D\uDC4B",
  "id" : 837236556037517314,
  "in_reply_to_status_id" : 837222535511048192,
  "created_at" : "2017-03-02 09:42:04 +0000",
  "in_reply_to_screen_name" : "RaoOfPhysics",
  "in_reply_to_user_id_str" : "67529128",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 0, 10 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    }, {
      "name" : "Sujai Kumar",
      "screen_name" : "sujaik",
      "indices" : [ 11, 18 ],
      "id_str" : "33651124",
      "id" : 33651124
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "837234771063361536",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172372425729, 8.627502664411276 ]
  },
  "id_str" : "837235092242202624",
  "in_reply_to_user_id" : 1385861262,
  "text" : "@Julie_B92 @sujaik maybe plot length distributions of hit vs. no hit to check that in a quick way :)",
  "id" : 837235092242202624,
  "in_reply_to_status_id" : 837234771063361536,
  "created_at" : "2017-03-02 09:36:15 +0000",
  "in_reply_to_screen_name" : "Julie_B92",
  "in_reply_to_user_id_str" : "1385861262",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 0, 10 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    }, {
      "name" : "Sujai Kumar",
      "screen_name" : "sujaik",
      "indices" : [ 11, 18 ],
      "id_str" : "33651124",
      "id" : 33651124
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "837234420620881920",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172372425729, 8.627502664411276 ]
  },
  "id_str" : "837234714989768704",
  "in_reply_to_user_id" : 1385861262,
  "text" : "@Julie_B92 @sujaik \u2026that aren\u2019t having any\/long enough protein-coding regions for your blastx.",
  "id" : 837234714989768704,
  "in_reply_to_status_id" : 837234420620881920,
  "created_at" : "2017-03-02 09:34:45 +0000",
  "in_reply_to_screen_name" : "Julie_B92",
  "in_reply_to_user_id_str" : "1385861262",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 0, 10 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    }, {
      "name" : "Sujai Kumar",
      "screen_name" : "sujaik",
      "indices" : [ 11, 18 ],
      "id_str" : "33651124",
      "id" : 33651124
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "837234420620881920",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172372425729, 8.627502664411276 ]
  },
  "id_str" : "837234599667331073",
  "in_reply_to_user_id" : 1385861262,
  "text" : "@Julie_B92 @sujaik depends on what you put in I\u2019d say: Assume that it\u2019s preferentially extremely short contigs\u2026",
  "id" : 837234599667331073,
  "in_reply_to_status_id" : 837234420620881920,
  "created_at" : "2017-03-02 09:34:18 +0000",
  "in_reply_to_screen_name" : "Julie_B92",
  "in_reply_to_user_id_str" : "1385861262",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 0, 10 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    }, {
      "name" : "Sujai Kumar",
      "screen_name" : "sujaik",
      "indices" : [ 11, 18 ],
      "id_str" : "33651124",
      "id" : 33651124
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "837233755597258752",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17234685116161, 8.627486695115106 ]
  },
  "id_str" : "837234113614602240",
  "in_reply_to_user_id" : 1385861262,
  "text" : "@Julie_B92 @sujaik pretend you\u2019ve never seen it and that PNAS publication could be yours \uD83D\uDE1C",
  "id" : 837234113614602240,
  "in_reply_to_status_id" : 837233755597258752,
  "created_at" : "2017-03-02 09:32:22 +0000",
  "in_reply_to_screen_name" : "Julie_B92",
  "in_reply_to_user_id_str" : "1385861262",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 0, 10 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    }, {
      "name" : "Sujai Kumar",
      "screen_name" : "sujaik",
      "indices" : [ 11, 18 ],
      "id_str" : "33651124",
      "id" : 33651124
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "837233469658914816",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17234685116161, 8.627486695115106 ]
  },
  "id_str" : "837233697246101506",
  "in_reply_to_user_id" : 1385861262,
  "text" : "@Julie_B92 @sujaik awesomesauce!  \uD83D\uDC4D\uD83C\uDF89",
  "id" : 837233697246101506,
  "in_reply_to_status_id" : 837233469658914816,
  "created_at" : "2017-03-02 09:30:43 +0000",
  "in_reply_to_screen_name" : "Julie_B92",
  "in_reply_to_user_id_str" : "1385861262",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexis Verger",
      "screen_name" : "Alexis_Verger",
      "indices" : [ 3, 17 ],
      "id_str" : "526226529",
      "id" : 526226529
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Alexis_Verger\/status\/837211148126666753\/photo\/1",
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/flFkyF8unE",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/C55fFhKWYAETqLC.jpg",
      "id_str" : "837211129143255041",
      "id" : 837211129143255041,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C55fFhKWYAETqLC.jpg",
      "sizes" : [ {
        "h" : 653,
        "resize" : "fit",
        "w" : 814
      }, {
        "h" : 653,
        "resize" : "fit",
        "w" : 814
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 546,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 653,
        "resize" : "fit",
        "w" : 814
      } ],
      "display_url" : "pic.twitter.com\/flFkyF8unE"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/2FqDaFMFi7",
      "expanded_url" : "http:\/\/www.nature.com\/nature\/journal\/v543\/n7643\/full\/543040e.html",
      "display_url" : "nature.com\/nature\/journal\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "837231621157883904",
  "text" : "RT @Alexis_Verger: Hear hear ! Publishing: Reformatting wastes public funds https:\/\/t.co\/2FqDaFMFi7 https:\/\/t.co\/flFkyF8unE",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Alexis_Verger\/status\/837211148126666753\/photo\/1",
        "indices" : [ 81, 104 ],
        "url" : "https:\/\/t.co\/flFkyF8unE",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/C55fFhKWYAETqLC.jpg",
        "id_str" : "837211129143255041",
        "id" : 837211129143255041,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C55fFhKWYAETqLC.jpg",
        "sizes" : [ {
          "h" : 653,
          "resize" : "fit",
          "w" : 814
        }, {
          "h" : 653,
          "resize" : "fit",
          "w" : 814
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 546,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 653,
          "resize" : "fit",
          "w" : 814
        } ],
        "display_url" : "pic.twitter.com\/flFkyF8unE"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 57, 80 ],
        "url" : "https:\/\/t.co\/2FqDaFMFi7",
        "expanded_url" : "http:\/\/www.nature.com\/nature\/journal\/v543\/n7643\/full\/543040e.html",
        "display_url" : "nature.com\/nature\/journal\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "837211148126666753",
    "text" : "Hear hear ! Publishing: Reformatting wastes public funds https:\/\/t.co\/2FqDaFMFi7 https:\/\/t.co\/flFkyF8unE",
    "id" : 837211148126666753,
    "created_at" : "2017-03-02 08:01:07 +0000",
    "user" : {
      "name" : "Alexis Verger",
      "screen_name" : "Alexis_Verger",
      "protected" : false,
      "id_str" : "526226529",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/835124540644687872\/cGunCLz9_normal.jpg",
      "id" : 526226529,
      "verified" : false
    }
  },
  "id" : 837231621157883904,
  "created_at" : "2017-03-02 09:22:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sujai Kumar",
      "screen_name" : "sujaik",
      "indices" : [ 3, 10 ],
      "id_str" : "33651124",
      "id" : 33651124
    }, {
      "name" : "bioRxiv",
      "screen_name" : "biorxivpreprint",
      "indices" : [ 78, 94 ],
      "id_str" : "1949132852",
      "id" : 1949132852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "837231217850339329",
  "text" : "RT @sujaik: We do slow and careful science, and welcome criticism\/comments in @biorxivpreprint comments section. Happy to Skype QA with jou\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "bioRxiv",
        "screen_name" : "biorxivpreprint",
        "indices" : [ 66, 82 ],
        "id_str" : "1949132852",
        "id" : 1949132852
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "837215442750095360",
    "geo" : { },
    "id_str" : "837217031829217280",
    "in_reply_to_user_id" : 33651124,
    "text" : "We do slow and careful science, and welcome criticism\/comments in @biorxivpreprint comments section. Happy to Skype QA with journal clubs",
    "id" : 837217031829217280,
    "in_reply_to_status_id" : 837215442750095360,
    "created_at" : "2017-03-02 08:24:29 +0000",
    "in_reply_to_screen_name" : "sujaik",
    "in_reply_to_user_id_str" : "33651124",
    "user" : {
      "name" : "Sujai Kumar",
      "screen_name" : "sujaik",
      "protected" : false,
      "id_str" : "33651124",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/499041232765460480\/J2nyoivC_normal.jpeg",
      "id" : 33651124,
      "verified" : false
    }
  },
  "id" : 837231217850339329,
  "created_at" : "2017-03-02 09:20:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/cPBvXUuttp",
      "expanded_url" : "https:\/\/media.giphy.com\/media\/T5QOxf0IRjzYQ\/giphy.gif",
      "display_url" : "media.giphy.com\/media\/T5QOxf0I\u2026"
    }, {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/NSsIw5Diso",
      "expanded_url" : "https:\/\/twitter.com\/sujaik\/status\/837205246803918850",
      "display_url" : "twitter.com\/sujaik\/status\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17234363375164, 8.627475405736387 ]
  },
  "id_str" : "837227308104749056",
  "text" : "The section on HGT in tardigrades should just have this as accompanying figure. https:\/\/t.co\/cPBvXUuttp https:\/\/t.co\/NSsIw5Diso",
  "id" : 837227308104749056,
  "created_at" : "2017-03-02 09:05:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 63 ],
      "url" : "https:\/\/t.co\/AuQyypcLsI",
      "expanded_url" : "http:\/\/lithub.com\/a-brief-stop-on-the-road-from-auschwitz\/",
      "display_url" : "lithub.com\/a-brief-stop-o\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17240332553734, 8.627468495526028 ]
  },
  "id_str" : "837217196346589184",
  "text" : "A brief stop on the road from Auschwitz https:\/\/t.co\/AuQyypcLsI",
  "id" : 837217196346589184,
  "created_at" : "2017-03-02 08:25:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/gEIqNS3ZBD",
      "expanded_url" : "https:\/\/twitter.com\/pathogenomenick\/status\/837061736591142916",
      "display_url" : "twitter.com\/pathogenomenic\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11407655019449, 8.75341054687431 ]
  },
  "id_str" : "837064255354585093",
  "text" : "\u00ABAn Inordinate Number of Fondly Sequenced Beetle Genomes\u00BB That\u2019s something I\u2019d buy right away. https:\/\/t.co\/gEIqNS3ZBD",
  "id" : 837064255354585093,
  "created_at" : "2017-03-01 22:17:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Madeleine Price Ball",
      "screen_name" : "madprime",
      "indices" : [ 3, 12 ],
      "id_str" : "71557700",
      "id" : 71557700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/GvvYUEXPPT",
      "expanded_url" : "http:\/\/www.madeleineball.net\/starting-my-fellowship\/",
      "display_url" : "madeleineball.net\/starting-my-fe\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "837060254592532481",
  "text" : "RT @madprime: A new blog and first post!\n\nStarting my Shuttleworth Fellowship to open human health data: https:\/\/t.co\/GvvYUEXPPT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 91, 114 ],
        "url" : "https:\/\/t.co\/GvvYUEXPPT",
        "expanded_url" : "http:\/\/www.madeleineball.net\/starting-my-fellowship\/",
        "display_url" : "madeleineball.net\/starting-my-fe\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "837058595833393153",
    "text" : "A new blog and first post!\n\nStarting my Shuttleworth Fellowship to open human health data: https:\/\/t.co\/GvvYUEXPPT",
    "id" : 837058595833393153,
    "created_at" : "2017-03-01 21:54:55 +0000",
    "user" : {
      "name" : "Madeleine Price Ball",
      "screen_name" : "madprime",
      "protected" : false,
      "id_str" : "71557700",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/515539302931910656\/9N7oFHFZ_normal.png",
      "id" : 71557700,
      "verified" : false
    }
  },
  "id" : 837060254592532481,
  "created_at" : "2017-03-01 22:01:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Madeleine Price Ball",
      "screen_name" : "madprime",
      "indices" : [ 0, 9 ],
      "id_str" : "71557700",
      "id" : 71557700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "837058364353949696",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1140794631667, 8.753415364964502 ]
  },
  "id_str" : "837058467512844288",
  "in_reply_to_user_id" : 71557700,
  "text" : "@madprime whops, send new tweet and I\u2019ll RT again :)",
  "id" : 837058467512844288,
  "in_reply_to_status_id" : 837058364353949696,
  "created_at" : "2017-03-01 21:54:25 +0000",
  "in_reply_to_screen_name" : "madprime",
  "in_reply_to_user_id_str" : "71557700",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "beau",
      "screen_name" : "beaugunderson",
      "indices" : [ 0, 14 ],
      "id_str" : "5746882",
      "id" : 5746882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "837056589022523398",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11407884448905, 8.753414716447494 ]
  },
  "id_str" : "837057443767201797",
  "in_reply_to_user_id" : 5746882,
  "text" : "@beaugunderson probably some technician at BGI, more by contaminating accidents than planned though :P",
  "id" : 837057443767201797,
  "in_reply_to_status_id" : 837056589022523398,
  "created_at" : "2017-03-01 21:50:21 +0000",
  "in_reply_to_screen_name" : "beaugunderson",
  "in_reply_to_user_id_str" : "5746882",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 68 ],
      "url" : "https:\/\/t.co\/k3uwmZyPq5",
      "expanded_url" : "https:\/\/twitter.com\/heyaudy\/status\/837010181305163776",
      "display_url" : "twitter.com\/heyaudy\/status\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11407660835876, 8.753411896483735 ]
  },
  "id_str" : "837019885247074312",
  "text" : "All \u2018omics is waiting and praying after all. https:\/\/t.co\/k3uwmZyPq5",
  "id" : 837019885247074312,
  "created_at" : "2017-03-01 19:21:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Shockey",
      "screen_name" : "nshockey",
      "indices" : [ 3, 12 ],
      "id_str" : "16728620",
      "id" : 16728620
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "836969344517222400",
  "text" : "RT @nshockey: If you offer conf. travel scholarships, *please* offer to book travel on recipients' behalf. Asking them to front $1k+ is har\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "836935944024502273",
    "text" : "If you offer conf. travel scholarships, *please* offer to book travel on recipients' behalf. Asking them to front $1k+ is hardship in itself",
    "id" : 836935944024502273,
    "created_at" : "2017-03-01 13:47:33 +0000",
    "user" : {
      "name" : "Nick Shockey",
      "screen_name" : "nshockey",
      "protected" : false,
      "id_str" : "16728620",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/667705115667800064\/YXtu9bI-_normal.jpg",
      "id" : 16728620,
      "verified" : false
    }
  },
  "id" : 836969344517222400,
  "created_at" : "2017-03-01 16:00:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rae Knowler",
      "screen_name" : "RaeKnowler",
      "indices" : [ 0, 11 ],
      "id_str" : "1244114060",
      "id" : 1244114060
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "836874095052615680",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17235398768265, 8.627445452841068 ]
  },
  "id_str" : "836877858052124672",
  "in_reply_to_user_id" : 1244114060,
  "text" : "@RaeKnowler no problem! For now I\u2019ll hope that the local Frankfurt artist will find some time. :)",
  "id" : 836877858052124672,
  "in_reply_to_status_id" : 836874095052615680,
  "created_at" : "2017-03-01 09:56:44 +0000",
  "in_reply_to_screen_name" : "RaeKnowler",
  "in_reply_to_user_id_str" : "1244114060",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bi\u24D0nca Kramer",
      "screen_name" : "MsPhelps",
      "indices" : [ 0, 9 ],
      "id_str" : "22963112",
      "id" : 22963112
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "836875942681317382",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17237505826723, 8.627522453347467 ]
  },
  "id_str" : "836876191340630021",
  "in_reply_to_user_id" : 22963112,
  "text" : "@MsPhelps sorry, no clue, I\u2019m not even able to take care of my own accounts w\/o external help. :p",
  "id" : 836876191340630021,
  "in_reply_to_status_id" : 836875942681317382,
  "created_at" : "2017-03-01 09:50:07 +0000",
  "in_reply_to_screen_name" : "MsPhelps",
  "in_reply_to_user_id_str" : "22963112",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 91 ],
      "url" : "https:\/\/t.co\/CccTzUaixr",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=qjlgWwB6D2w",
      "display_url" : "youtube.com\/watch?v=qjlgWw\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17236194028664, 8.627428569048753 ]
  },
  "id_str" : "836851675218464768",
  "text" : "Looks like Passenger found his own way to make America great again. https:\/\/t.co\/CccTzUaixr",
  "id" : 836851675218464768,
  "created_at" : "2017-03-01 08:12:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dani Rabaiotti",
      "screen_name" : "DaniRabaiotti",
      "indices" : [ 3, 17 ],
      "id_str" : "636216638",
      "id" : 636216638
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 53 ],
      "url" : "https:\/\/t.co\/6Fn4jMBpHZ",
      "expanded_url" : "https:\/\/twitter.com\/OtherSociology\/status\/836767947745943553",
      "display_url" : "twitter.com\/OtherSociology\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "836840656739909632",
  "text" : "RT @DaniRabaiotti: Thread.\n\n\uD83D\uDE21 https:\/\/t.co\/6Fn4jMBpHZ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 11, 34 ],
        "url" : "https:\/\/t.co\/6Fn4jMBpHZ",
        "expanded_url" : "https:\/\/twitter.com\/OtherSociology\/status\/836767947745943553",
        "display_url" : "twitter.com\/OtherSociology\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "836838767419863041",
    "text" : "Thread.\n\n\uD83D\uDE21 https:\/\/t.co\/6Fn4jMBpHZ",
    "id" : 836838767419863041,
    "created_at" : "2017-03-01 07:21:24 +0000",
    "user" : {
      "name" : "Dani Rabaiotti",
      "screen_name" : "DaniRabaiotti",
      "protected" : false,
      "id_str" : "636216638",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/926387348354617344\/knjAV6uc_normal.jpg",
      "id" : 636216638,
      "verified" : false
    }
  },
  "id" : 836840656739909632,
  "created_at" : "2017-03-01 07:28:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rae Knowler",
      "screen_name" : "RaeKnowler",
      "indices" : [ 0, 11 ],
      "id_str" : "1244114060",
      "id" : 1244114060
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "836835371480657920",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11398760843255, 8.75313581025938 ]
  },
  "id_str" : "836836773321981952",
  "in_reply_to_user_id" : 1244114060,
  "text" : "@RaeKnowler thanks! Unfortunately they don\u2019t seem to have any female artists in residence :(",
  "id" : 836836773321981952,
  "in_reply_to_status_id" : 836835371480657920,
  "created_at" : "2017-03-01 07:13:29 +0000",
  "in_reply_to_screen_name" : "RaeKnowler",
  "in_reply_to_user_id_str" : "1244114060",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rae Knowler",
      "screen_name" : "RaeKnowler",
      "indices" : [ 0, 11 ],
      "id_str" : "1244114060",
      "id" : 1244114060
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "836831282504036353",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11407675494395, 8.753413198324244 ]
  },
  "id_str" : "836833111795171333",
  "in_reply_to_user_id" : 1244114060,
  "text" : "@RaeKnowler thanks. Will do! Otherwise, if you have a recommendation for an artist in ZRH I\u2019d be happy to hear it. \uD83D\uDE0A",
  "id" : 836833111795171333,
  "in_reply_to_status_id" : 836831282504036353,
  "created_at" : "2017-03-01 06:58:56 +0000",
  "in_reply_to_screen_name" : "RaeKnowler",
  "in_reply_to_user_id_str" : "1244114060",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
} ]